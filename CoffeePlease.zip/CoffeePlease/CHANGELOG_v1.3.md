V.1.3

MUSIC & SEASONS
- New music, 10 new tracks :) enjoy! The title screen, cafe and Evening Chill play them in random order, and Rush Hour has its own track. The coffee supply shop tune is unchanged
- New Music tab in the shop with 2 vinyl records, Halloween music and Christmas music ($180 each). Each has 2 seasonal tracks, and only one can be on at a time
- Halloween music brings the fall vibe: it rains, gets cloudy and the leaves are always falling
- Christmas music brings the winter vibe: it snows in the window all day, with no leaves
- Halloween music swaps Matcha for Pumpkin Spice! Christmas music swaps it for Hot Cocoa! Customers order them with ingredients that fit (milk and sugar, and for Pumpkin Spice sometimes espresso)
- Customers leave season reviews in the shop when the music is on ("It's so spooky in here and I love it!", "The festive vibes are so nice")
- Music can't be bought or switched from when the receipt is cranked until the pickup bell is rung. Any other time it can
- In the cafe, it now goes back and forth between busy and quiet: after a busy spell (or sooner when the line is full or 4 or more cups are dirty), nobody new walks in until the line is served, then the register stays empty for 10 to 15 seconds so you can do the dishes (3 stars and up)
- Rush Hour: the countdown beeps are gone and the alarm clock rings when time is up. Ice drinks are a bit more common

NEW PETS
- 4 new turtles: Green turtle, Box turtle, Tortoise and Red-ear turtle. They walk slowly, look around and tuck into their shells to sleep
- New Snake tank with a slithering snake, a flicking tongue and a heat lamp
- The Fish tank is livelier: a big fish, a little darting fish, bubbles, swaying weed and fish food. It now sits at the top of the Pets tab
- Cat tree and Dog bed show first in the Pets tab once you own a cat or dog
- Pets no longer walk over tables or decor

NEW STUFF
- New counter pieces in Stuff: retro radio, pinwheel, boom box, lucky cat, record player, snow globe, gumball machine, Newton's cradle and Pee-Dee (a mini Playdate that cranks all day!), plus a Juke box for the floor
- New Lighting tab: 7 floor lamps, 7 candles, incense, 5 string light styles, 6 neon signs and a disco ball
- 8 new vine styles for the shelf
- 8 new tablecloth patterns and oval table rugs
- You can now buy more than one of floor and table-top decor (no limit). Owned pieces show how many you have, and a "Buy another" sub-row under each owned piece lets you buy more. Tap A to put one out or pick one up, or hold A to edit (a "Hold A to edit item layout" bubble shows while you rest on an owned piece): a clean screen of the cafe that shows how many are in your hand, where A puts one down or picks one up, and B goes back. Pets, pet items, music, clothes, tablecloths, rugs, and all window and wall items stay one of each
- New Item stand at the top of Stuff: it turns a floor spot into a table spot, so table-top pieces can sit on it
- New Tiffany table lamp (same design as the floor one, smaller and cheaper)
- Updated lamp pixel arts
- Added wording to all items that says if it goes on a Table, Wall or Floor

SCREENS
- New machine pixel arts and updated machine UIs
- Settings added to the title screen instead of hidden behind the pause button
- Improved loading times of certain screens on the title screen
- Initials screen leads to the new High Scores screen, and plays click sounds instead of beeps
- Long orders no longer run under the patience meter
- In the cafe pause menu, Go to Shop is now the bottom option (Save & quit sits above it)

- Rugs flash where they go (Register rug, Table section rug or Cafe pickup rug) before their usual line
- Crank to pour is now on by default (you can still switch to Tilt in Settings)
- Removed the TAP / TILT word above the pour meter, and the A button DONE on the coffee pour screen

SALES
- Improved Sale tab with a new sale sticker, more items on sale and ?% off

Not tested on a real Playdate yet.
