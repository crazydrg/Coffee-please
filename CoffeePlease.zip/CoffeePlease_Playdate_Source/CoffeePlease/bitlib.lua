-- the bit helpers the shared game code uses (the PC version gets them from LuaJIT's bit library)
BITLIB = {
  band = function(a, b) return a & b end,
  bor = function(a, b) return a | b end,
  bxor = function(a, b) return a ~ b end,
  bnot = function(a) return ~a end,
  lshift = function(a, b) return a << b end,
  rshift = function(a, b) return a >> b end,
}
