-- Coffee Please!!!
-- by Christian G   (version 3.5)
--
-- A tiny coffee-shop game for the Playdate.
-- Ring them up, pour the coffee, mix in milk / sugar / espresso / ice, serve it,
-- ring the bell. Two ways to play:
--   RUSH HOUR    - open 7 AM to 2 PM, a fast time-limited shift
--   EVENING CHILL - open 4 PM to 12 AM, no timer: wash cups between customers

import "CoreLibs/graphics"
import "CoreLibs/ui"

local pd  = playdate
local gfx  = pd.graphics
local snd  = pd.sound

----------------------------------------------------------------------
-- Tuning knobs: change these numbers to adjust how the game feels
----------------------------------------------------------------------
local RUSH_SECONDS      = 90    -- Rush Hour is a 90 second countdown
local PATIENCE_SECONDS  = 75    -- how long a customer waits at the counter
local LINE_PATIENCE     = 2.0   -- people in line are this many times more patient
local LINE_MAX          = 3     -- people who can wait behind the one ordering
local TIP_MAX           = 250   -- best possible tip, in cents
local WALK_SPEED        = 110   -- barista speed (pixels per second)
local CUST_SPEED        = 140   -- customer speed (pixels per second)
local RECEIPT_CRANK     = 360   -- crank degrees to print the receipt
local MIX_CRANK         = 720   -- crank degrees to mix the drink
local BELL_CRANK        = 270   -- crank degrees to ring the bell
local POUR_RATE_MIN     = 0.25  -- coffee fill per second (gentle tilt)
local POUR_RATE_MAX     = 0.36  -- coffee fill per second (full tilt)
local DINE_IN_CHANCE    = 0.65  -- chance a customer wants to sit down
local STAY_MIN          = 40    -- seconds a customer stays seated (min)
local STAY_MAX          = 90    -- seconds a customer stays seated (max)
local MUSIC_VOLUME      = 0.85   -- the cafe music (0 to 1)
local BEEP_GAIN         = 0.45   -- how loud the little beeps are (0 to 1)

-- Evening Chill mode
local CHILL_ARRIVE_MIN    = 22    -- seconds between customers (min)
local CHILL_ARRIVE_SPAN   = 14    -- ...plus up to this much extra
local CHILL_PATIENCE      = 110   -- how long a customer waits at the counter
local CHILL_DINE_IN       = 0.85  -- chance a customer wants to sit down
local CHILL_STAY_MIN      = 45
local CHILL_STAY_MAX      = 100
local CUPS_TOTAL          = 5     -- ceramic cups in the whole shop
local DISH_CRANK          = 540   -- crank degrees to scrub one cup clean
local COFFEE_KINDS_IN_RUSH  = false   -- true = matcha/decaf in Rush Hour too
local KINDS         = { "coffee", "matcha", "decaf", "tea" }
local KIND_WEIGHTS  = { 46, 20, 17, 17 }
local KIND_PRICE    = { coffee = 0, matcha = 100, decaf = 0, tea = 50 }   -- cents extra
local WIN, UI, CAFE = {}, {}, {}      -- grouped to stay under the 200-locals limit
function UI.ink() end                 -- colour hook: does nothing on the 1-bit Playdate; the PC version paints the next shapes in the named colour
function UI.inkPush() end             -- (the same, but remembers the colour before it ...)
function UI.inkPop() end              -- (... and goes back to it)
function UI.inkKey() return "" end    -- (the PC version: which colour is on, so pictures made in one colour are kept apart from the others)
function UI.inkNum() return 0 end     -- (the same, as a number)
UI.color = false                      -- true on the PC (in colour): a few things are drawn a little differently there
UI.SIZE_NAME = { "Small", "Medium", "Large" }
UI.SIZE_FILL = { 0.55, 0.78, 1.0 }          -- where the "fill to here" line sits for each cup size
UI.KIND_NAME = { coffee = "Coffee", matcha = "Matcha", decaf = "Decaf", tea = "Tea" }
-- With the Halloween music on, the matcha slot becomes Pumpkin Spice; with the Christmas music on, Hot Cocoa. (Inside, the drink is still kind "matcha":
-- its button, price and cup are the same, only the name, the picture and what people put in it change.)
UI.SPECIAL = {
  fall   = { name = "Pumpkin Spice", word = "PUMPKIN", greet = "Pumpkin spice, please!", icon = "pumpkin" },
  winter = { name = "Hot Cocoa",     word = "COCOA",   greet = "Hot cocoa, please!",     icon = "cocoa" },
}


-- How likely each amount is in an order (index 1 = none, 2 = one, 3 = two, ...)
local MILK_WEIGHTS   = { 35, 35, 22, 8 }
local SUGAR_WEIGHTS  = { 35, 30, 25, 10 }
local SHOT_WEIGHTS   = { 60, 30, 10 }
local ICE_WEIGHTS    = { 45, 30, 17, 8 }

-- The starting high score table (scores are in cents)
local DEFAULT_SCORES  = {
  { n = "Grace",       s = 5500 },   -- six clean orders in a row: only for someone really good at it
  { n = "Christian",   s = 4600 },
  { n = "Kelly",       s = 3800 },
  { n = "Jay",         s = 3100 },
  { n = "Bellasmella", s = 2600 },
  { n = "Rosie",       s = 2200 },
  { n = "Otis",        s = 1700 },
  { n = "Juno",        s = 1350 },
  { n = "Mabel",       s = 1000 },
  { n = "Pip",         s = 700 },
}

-- Evening Chill has no timer, so its table is about how long you keep going
local DEFAULT_CHILL_SCORES  = {
  { n = "Grace",       s = 35000 },   -- roughly 25 minutes of near-perfect service
  { n = "Christian",   s = 27000 },
  { n = "Kelly",       s = 20500 },
  { n = "Jay",         s = 15500 },
  { n = "Bellasmella", s = 11500 },
  { n = "Rosie",       s = 8000 },
  { n = "Otis",        s = 5500 },
  { n = "Juno",        s = 3500 },
  { n = "Mabel",       s = 2000 },
  { n = "Pip",         s = 1000 },
}

----------------------------------------------------------------------
-- Basics
----------------------------------------------------------------------
local BLACK  = gfx.kColorBlack
local WHITE  = gfx.kColorWhite
local CHECK = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }

local fontNormal = gfx.getSystemFont()
local fontBold = gfx.getSystemFont(gfx.font.kVariantBold)

local function clamp(v, lo, hi)
  if v < lo then return lo elseif v > hi then return hi end
  return v
end

-- cents -> "$3.75"
local function money(c)
  c = math.floor(c + 0.5)
  return string.format("$%d.%02d", math.floor(c / (100)), c % 100)
end

local function drawT(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawText(str, x, y)
end
local function drawTC(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.center)
end
local function drawTR(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.right)
end

-- Playdate speed: drawing text is slow on the Playdate, stamping a picture is quick. So each piece of text is drawn
-- once into a little picture (per font) and stamped from then on; its size is remembered too. The PC draws text
-- directly (its colours are chosen as it draws). The pictures are let go when there are a lot of them.
;(function()                                                    -- the colour being drawn in, kept track of here (the Playdate can't be asked)
  local rawSet, rawPat, rawPush, rawPop = gfx.setColor, gfx.setPattern, gfx.pushContext, gfx.popContext
  local rawDither, rawMode = gfx.setDitherPattern, gfx.setImageDrawMode
  local cur, stack = BLACK, {}
  local mode, mstack = gfx.kDrawModeCopy, {}                    -- (and the way pictures are being drawn: asking the Playdate costs a call)
  gfx.setColor = function(c, ...) cur = c; return rawSet(c, ...) end
  gfx.setPattern = function(...) cur = -1; return rawPat(...) end
  if rawDither then gfx.setDitherPattern = function(...) cur = -1; return rawDither(...) end end
  gfx.setImageDrawMode = function(m, ...) mode = m; return rawMode(m, ...) end
  gfx.getImageDrawMode = function() return mode end
  gfx.pushContext = function(...) stack[#stack + 1] = cur; mstack[#mstack + 1] = mode; return rawPush(...) end
  gfx.popContext = function(...)
    local n = #stack
    if n > 0 then cur = stack[n]; stack[n] = nil end
    n = #mstack
    if n > 0 then mode = mstack[n]; mstack[n] = nil end
    return rawPop(...)
  end
  UI.getColor = function() return cur end
end)()
;(function()
  local rawText, rawAligned, rawSize = gfx.drawText, gfx.drawTextAligned, gfx.getTextSize
  local per, count = setmetatable({}, { __mode = "k" }), 0
  local old = setmetatable({}, { __mode = "k" })               -- (the last lot: still used ones move back, nothing is redrawn all at once)
  local NOFONT = {}
  local function entry(str)
    local f = (gfx.getFont and gfx.getFont()) or NOFONT
    local tn = UI.inkNum()                                       -- (PC: a picture keeps the colour it was made in, so one per colour)
    local pf = per[f]
    if not pf then pf = {}; per[f] = pf end
    local t = pf[tn]
    if not t then t = {}; pf[tn] = t end
    local e = t[str]
    if e then return e end
    if count >= 300 then old = per; per = setmetatable({}, { __mode = "k" }); count = 0; t = {}; per[f] = { [tn] = t } end
    local ot = old[f]; ot = ot and ot[tn]
    e = ot and ot[str]
    if e then t[str] = e; count = count + 1; return e end
    local w, h = rawSize(str)
    e = { w = w or 0, h = h or 0, ml = (string.find(str, "\n", 1, true) ~= nil) }
    if e.w > 0 and e.h > 0 and not e.ml then
      local ok, img = pcall(gfx.image.new, e.w, e.h, gfx.kColorClear)
      if ok and img then
        gfx.pushContext(img)
        gfx.setDrawOffset(0, 0); gfx.clearClipRect()
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        if f ~= NOFONT then gfx.setFont(f) end
        rawText(str, 0, 0)
        gfx.popContext()
        e.img = img
      end
    end
    t[str] = e
    count = count + 1
    return e
  end
  local function skip()                                          -- (PC: only in the draw modes where a stamp looks the same as drawn text)
    if UI.noCache then return true end
    if not UI.color then return false end
    local m = gfx.getImageDrawMode()
    return not (m == 0 or m == 3 or m == 4)
  end
  gfx.drawText = function(str, x, y, a4, ...)
    if skip() or a4 ~= nil or type(str) ~= "string" then return rawText(str, x, y, a4, ...) end
    local e = entry(str)
    if e.ml then return rawText(str, x, y) end
    if e.img then e.img:draw(x, y) end
    return e.w, e.h
  end
  gfx.drawTextAligned = function(str, x, y, align, a5, ...)
    if skip() or a5 ~= nil or type(str) ~= "string" then return rawAligned(str, x, y, align, a5, ...) end
    local e = entry(str)
    if e.ml then return rawAligned(str, x, y, align) end
    if e.img then
      local dx = 0
      if align == kTextAlignment.center then dx = math.floor(e.w / 2) elseif align == kTextAlignment.right then dx = e.w end
      e.img:draw(x - dx, y)
    end
  end
  gfx.getTextSize = function(str, a2, ...)
    if UI.noCache or a2 ~= nil or type(str) ~= "string" then return rawSize(str, a2, ...) end
    local e = entry(str)
    return e.w, e.h
  end
end)()

-- more fill patterns (the three drinks look different in the cup)
local DIAG   = { 0xEE, 0xDD, 0xBB, 0x77, 0xEE, 0xDD, 0xBB, 0x77 }
local STRIPE = { 0xCC, 0xCC, 0x33, 0x33, 0xCC, 0xCC, 0x33, 0x33 }
local TEA = { 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }
local DRINK_PATTERN = { coffee = CHECK, matcha = DIAG, decaf = STRIPE, tea = { 0x77, 0xAA, 0xDD, 0xAA, 0x77, 0xAA, 0xDD, 0xAA } }   -- (tea is an amber mesh: darker than matcha, lighter than coffee)

-- a little ceramic cup (x, y = top-left, s = size 1 small .. 3 big)
local function drawCup(x, y, s, dirty)
  local w, h = 8 * s, 8 * s
  UI.inkPush("mugc")
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(s >= 2 and 2 or 1)
  gfx.drawRect(x, y, w, h)
  gfx.drawCircleAtPoint(x + w + s, y + math.floor(h / (2)), s + 1)
  gfx.setLineWidth(1)
  if dirty then
    UI.ink("coffee")
    gfx.setPattern(CHECK)
    gfx.fillRect(x + 2, y + math.floor(h / (2)), w - 4, math.floor(h / (2)) - 2)
    gfx.setColor(BLACK)
  end
  UI.inkPop()
end

-- a coffee bean (x, y = centre)
local function drawBean(x, y, s)
  s = s or 1
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x - 5 * s, y - 3 * s, 10 * s, 6 * s)
  gfx.setColor(WHITE)
  gfx.drawLine(x - 4 * s, y + s, x + 4 * s, y - s)
  gfx.setColor(BLACK)
end

-- a dashed outline (the empty spot on a shelf)
local function dashedRect(x, y, w, h)
  gfx.setColor(BLACK)
  for dx = 0, w - 3, 6 do
    gfx.drawLine(x + dx, y, x + dx + 2, y)
    gfx.drawLine(x + dx, y + h, x + dx + 2, y + h)
  end
  for dy = 0, h - 3, 6 do
    gfx.drawLine(x, y + dy, x, y + dy + 2)
    gfx.drawLine(x + w, y + dy, x + w, y + dy + 2)
  end
end

----------------------------------------------------------------------
-- Sound: little synth blips, recorded-style effects, and the cafe music
----------------------------------------------------------------------
local function newSynth(wave)
  local ok, s = pcall(function() return snd.synth.new(wave) end)
  if ok then return s end
  return nil
end
local synthSq   = newSynth(snd.kWaveSquare)
local synthSine = newSynth(snd.kWaveSine)
UI.synthNoise = newSynth(snd.kWaveNoise)           -- (the scratch of a scratch-off ticket)

local function play(synth, hz, len, vol, when)
  if synth == nil then return end
  vol = (vol or 0.3) * BEEP_GAIN          -- beeps stay quiet; the music is the star
  pcall(function()
    if when then synth:playNote(hz, vol, len, when) else synth:playNote(hz, vol, len) end
  end)
end

local function sfxTick()  play(synthSq, 1800, 0.02, 0.10) end
local function sfxPop()   play(synthSine, 520, 0.08, 0.30) end
local function sfxWrong() play(synthSq, 110, 0.25, 0.30) end
local function sfxGood()
  play(synthSq, 660, 0.07, 0.25)
  play(synthSq, 990, 0.10, 0.25, 0.08)
end
local function sfxHello()
  play(synthSine, 880, 0.10, 0.30)
  play(synthSine, 1175, 0.20, 0.30, 0.10)
end

-- sound effect files live in the "sounds" folder
-- Each is loaded the first time it is played (not all at boot: that held up the start), and the rest are loaded one a
-- frame while the title screen sits idle (UI.sfxWarm), so none is usually loaded mid-game.
UI.SFX_NAMES = { "click1", "click2", "click3", "click4", "chime", "storedoor", "door", "bell", "receipt", "receipt2", "pour", "pour2", "mixer",
                 "icemixer", "plate", "slide", "tip", "cup1", "cup2", "dash1", "dash2", "ice1", "ice2", "ice3", "cleaning", "sink", "alarm",
                 "dish1", "dish2", "achieve" }
UI.SFX_OK, UI.sfxBad = {}, {}
for _, name in ipairs(UI.SFX_NAMES) do UI.SFX_OK[name] = true end
local sfx = setmetatable({}, { __index = function(t, name)
  if not UI.SFX_OK[name] or UI.sfxBad[name] then return nil end
  local ok, sp = pcall(function() return snd.sampleplayer.new("sounds/" .. (name == "receipt2" and "receipt" or name)) end)
  if ok and sp then rawset(t, name, sp); return sp end
  UI.sfxBad[name] = true
  return nil
end })
UI.sfxWarmI = 1
function UI.sfxWarm()                              -- load the next sound effect not in yet (true if it did)
  while UI.sfxWarmI <= #UI.SFX_NAMES do
    local name = UI.SFX_NAMES[UI.sfxWarmI]
    UI.sfxWarmI = UI.sfxWarmI + 1
    if rawget(sfx, name) == nil and not UI.sfxBad[name] then
      UI.loadN = UI.loadN + 1
      local _ = sfx[name]
      return true
    end
  end
  return false
end

local function sfxPlay(name, loop, vol, rate)
  local sp = sfx[name]
  if sp == nil then return end
  pcall(function()
    if vol then sp:setVolume(vol) end
    if rate then sp:setRate(rate) end
    if loop then
      if not sp:isPlaying() then sp:play(0) end
    else
      sp:play(1)
    end
  end)
end

-- the pretty register chime when a shift starts
local function sfxStart()
  if sfx.chime then
    sfxPlay("chime", false, 0.9)
  else
    play(synthSine, 1568, 0.25, 0.5)
    play(synthSine, 2093, 0.25, 0.5, 0.12)
    play(synthSine, 2637, 0.40, 0.5, 0.24)
  end
end

local function sfxStop(name)                     -- (only sounds that are in: stopping one never loads it)
  local sp = rawget(sfx, name)
  if name == "receipt" and UI.rcptPaused then UI.rcptPaused = false; if sp then pcall(function() sp:setPaused(false) end) end end
  if sp then pcall(function() sp:stop() end) end
  local p2, ic = rawget(sfx, "pour2"), rawget(sfx, "icemixer")
  if name == "pour" and p2 then pcall(function() p2:stop() end) end
  if name == "mixer" and ic then pcall(function() ic:stop() end) end     -- (the icy mixer sound goes quiet with it)
end

-- the coffee pour: one of the two pour recordings, left alone while it plays
local function sfxPour()
  local a, b = sfx.pour, sfx.pour2
  if (a and a:isPlaying()) or (b and b:isPlaying()) then return end
  local name = (b and math.random() < 0.5) and "pour2" or "pour"
  sfxPlay(name, false, 1.0, 1.0)
end

-- cups clinking and ice cubes: one of the recordings, picked at random
local function sfxRandom(names)                  -- (only the one picked is loaded, if it isn't in yet)
  local list = {}
  for _, n in ipairs(names) do if not UI.sfxBad[n] then list[#list + 1] = n end end
  while #list > 0 do
    local i = math.random(#list)
    if sfx[list[i]] then sfxPlay(list[i], false, 1.0); return true end
    table.remove(list, i)
  end
  return false
end
local function sfxCup() if not sfxRandom({ "cup1", "cup2" }) then sfxPlay("plate", false, 0.6) end end
function UI.sfxDish() if not sfxRandom({ "dish1", "dish2" }) then sfxPlay("plate", false, 0.5) end end      -- a used cup clinking into the dish bin / the sink
local function sfxClick()
  if not sfxRandom({ "click1", "click2", "click3", "click4" }) then play(synthSq, 1200, 0.03, 0.15) end
end
local function sfxDash() if not sfxRandom({ "dash1", "dash2" }) then sfxPop() end end   -- a second of pouring
local function sfxIce() if not sfxRandom({ "ice1", "ice2", "ice3" }) then sfxPop() end end

-- (the slurp now plays from the launcher, as the game's launch sound)

-- background music: the Menu button has a Music check box to switch it off.
-- Every tune is loaded whole into memory (a sampleplayer) rather than streamed from the disk, which hitched the frame rate every few seconds.
-- That is a lot of memory, so only the tune that is playing, the one that comes next and the shop's tune are kept (see UI.musicTick).
UI.tunes, UI.badTunes = {}, {}
UI.POOL = { "latte", "bossa", "piano", "swing", "closing" }       -- title screen, cafe and Evening Chill: one of these, picked at random
UI.musicOn, UI.musicNow = true, nil
UI.mus = { recent = {} }
function UI.tune(name)                                           -- the player for a tune (loaded the first time; nil if the file will not load)
  local p = UI.tunes[name]
  if p then return p end
  if UI.badTunes[name] then return nil end
  local ok, sp = pcall(function() return snd.fileplayer.new("music/" .. name) end)   -- (streamed from the file as it plays: no big load that would stall a frame)
  if not (ok and sp) then UI.badTunes[name] = true; return nil end
  pcall(function() sp:setVolume(MUSIC_VOLUME) end)
  UI.tunes[name] = sp
  return sp
end
UI.tune("shop")                                                  -- the coffee supply website's tune
do                                                               -- (and one for the title screen, ready to go)
  local first = UI.POOL[math.random(#UI.POOL)]
  if UI.tune(first) then UI.mus.pick = first end
end
pcall(function()
  local menu = pd.getSystemMenu()
  if menu and menu.addCheckmarkMenuItem then
    UI.musicItem = menu:addCheckmarkMenuItem("Music", true, function(on) UI.musicOn = on end)
  end
end)

----------------------------------------------------------------------
-- Layout
----------------------------------------------------------------------
local PLAYER_Y  = 58    -- the barista walks along behind the counter
local WALK_MIN  = 28
local WALK_MAX = 344
local JAR_X    = 368          -- the tip jar

local REG_X, REG_Y = 62, 136      -- where the customer being served stands
local PICK_X, PICK_Y = 308, 136   -- where they wait for their drink
local DOOR_X  = 28         -- customers walk in and out here (bottom left)
local LINE_SLOTS = { { 62, 166 }, { 62, 196 }, { 62, 226 } }
local DISH_X = 332                -- Evening Chill: where used cups get dropped off

local RUSH_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 62,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 144, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 226, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 308, stage = 4 },
}
-- Evening Chill squeezes in a dish bin, and the tip jar moves right
local CHILL_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 56,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 128, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 200, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 266, stage = 4 },
  { id = "dishes",   name = "Dishes",   label = "DISHES",   x = 329 },
}
local STATIONS = RUSH_STATIONS
local STAGE_ST = {}               -- STAGE_ST[1..4] = the station for each order step

local function stationById(id)
  for _, st in ipairs(STATIONS) do
    if st.id == id then return st end
  end
  return nil
end

local function setLayout(mode)
  do
    STATIONS = CHILL_STATIONS
    JAR_X, WALK_MAX = 386, 356
    REG_X, PICK_X, DISH_X = 56, 266, 329
    LINE_SLOTS = { { 56, 166 }, { 56, 196 }, { 56, 226 } }
  end
  STAGE_ST = {}
  for _, st in ipairs(STATIONS) do
    if st.stage then STAGE_ST[st.stage] = st end
  end
end
setLayout("rush")

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "ENT" }
local GREETS = { "Coffee please!", "One coffee, please!", "Morning! Coffee?", "Coffee time!" }

-- Round tables and where people sit (the last table is in the corner nook)
local TABLES = {
  { x = 132, y = 208, r = 13 }, { x = 186, y = 208, r = 13 },
  { x = 240, y = 208, r = 13 }, { x = 294, y = 208, r = 13 },
  { x = 350, y = 180, r = 13 },            -- the table inside the nook
}
local SEATS = {
  { x = 115, y = 208, t = 1 }, { x = 149, y = 208, t = 1 },
  { x = 169, y = 208, t = 2 }, { x = 203, y = 208, t = 2 },
  { x = 223, y = 208, t = 3 }, { x = 257, y = 208, t = 3 },
  { x = 277, y = 208, t = 4 }, { x = 311, y = 208, t = 4 },
  -- the L-shaped nook: three seats up the wall, two along the bottom
  { x = 386, y = 168, t = 5 }, { x = 386, y = 192, t = 5 }, { x = 386, y = 214, t = 5 },
  { x = 356, y = 218, t = 5 }, { x = 332, y = 218, t = 5 },
  -- and two chairs on the open sides of the nook table (left and top)
  { x = 327, y = 180, t = 5, back = "l" }, { x = 350, y = 157, t = 5, back = "u" },
}

----------------------------------------------------------------------
-- High scores (saved on the Playdate)
----------------------------------------------------------------------
local boards = { rush = {}, chill = {} }     -- sorted lists of { n = name, s = cents }
local lastInitials = "AAA"
UI.crankPour = true                       -- pour with the crank unless you picked Tilt in Settings

local function saveScores()
  pd.datastore.write({ v = 7, rush = boards.rush, chill = boards.chill, last = lastInitials, crank = UI.crankPour == true, pour = UI.crankPour and "crank" or "tilt" })
end

do
  local function take(dst, src)
    if type(src) ~= "table" then return end
    for _, e in ipairs(src) do
      if type(e) == "table" and type(e.n) == "string" and type(e.s) == "number" then
        dst[#dst + 1] = { n = e.n, s = e.s }
      end
    end
  end
  local saved = pd.datastore.read()
  if saved then
    if saved.v == 7 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
    elseif saved.v == 6 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
      -- the Rush Hour starting scores were lowered after the first 1.3 builds: swap the old starting entries for the new ones, keeping every score you really made
      local old = { Grace = 9000, Christian = 7800, Kelly = 6600, Jay = 5600, Bellasmella = 4700, Rosie = 3900, Otis = 3100, Juno = 2400, Mabel = 1700, Pip = 1100 }
      for i = #boards.rush, 1, -1 do
        local e = boards.rush[i]
        if old[e.n] == e.s then table.remove(boards.rush, i) end
      end
      for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
    elseif saved.v == 5 then
      take(boards.chill, saved.chill)     -- Rush Hour got combos in 1.3 (scores run much higher): fresh table
    elseif saved.v == 4 then
      take(boards.chill, saved.chill)     -- Rush Hour got harder in 2.3: fresh table
    elseif saved.v == 3 then
      take(boards.rush, saved.scores)       -- version 1.x saved only the Rush Hour table
    end
    if type(saved.last) == "string" and #saved.last == 3 then lastInitials = saved.last end
    if saved.pour == "tilt" then UI.crankPour = false end             -- (Crank to pour is the default; only a saved choice of Tilt changes it)
  end
  if #boards.rush == 0 then
    for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
  end
  if #boards.chill == 0 then
    for _, e in ipairs(DEFAULT_CHILL_SCORES) do boards.chill[#boards.chill + 1] = { n = e.n, s = e.s } end
  end
  table.sort(boards.rush, function(a, b) return a.s > b.s end)
  table.sort(boards.chill, function(a, b) return a.s > b.s end)
end

-- returns the rank (1 = best) the new score landed at
local function insertScore(mode, name, s)
  local list = boards[mode]
  local rank = #list + 1
  for i, e in ipairs(list) do
    if s > e.s then rank = i; break end
  end
  table.insert(list, rank, { n = name, s = s })
  while #list > 100 do table.remove(list) end
  lastInitials = name
  saveScores()
  return rank
end

----------------------------------------------------------------------
-- Game state
----------------------------------------------------------------------
local STATE_MENU   = 1
local STATE_PLAY   = 2
local STATE_ENTRY  = 3   -- closing time: type your initials
local STATE_BOARD  = 4   -- the high score table

local state = STATE_MENU
local frames = 0
local lastMs = pd.getCurrentTimeMilliseconds()
local G = nil                   -- the current day (nil on the title screen)
local board = { mode = "view", rank = nil, m = "rush", view = "rush", t = 0 }
local entry = { letters = { 0, 0, 0 }, cur = 1, crank = 0 }
local menuSel = 1                   -- title screen: 1 Cafe, 2 Rush Hour, 3 Evening Chill, 4 High scores / Achievements / Settings (UI.menuCol: 1, 2 or 3)
UI.menuCol = 1

-- screen fades: everything that changes screen goes through transitionTo()
local FADE_SECONDS  = 0.5
local trans = nil                   -- { phase = "out" or "in", t = seconds, fn = function }
function UI.season() return (G ~= nil and G.mode == "cafe" and G.win ~= nil) and G.win.season or nil end
function UI.kindName(kind)
  local sp = (kind == "matcha") and UI.SPECIAL[UI.season() or ""] or nil
  return sp and sp.name or UI.KIND_NAME[kind or "coffee"]
end
local endDay, setShiftMenu          -- (defined further down)

local function transitionTo(fn, dur)
  if trans == nil then trans = { phase = "out", t = 0, fn = fn, dur = dur or FADE_SECONDS } end
end
function UI.fast(fn) transitionTo(fn, 0.2) end       -- the title-screen pages: a quick dip to black instead of a long fade

-- mix the clock and frame count into the random seed so every day differs
local function reseed()
  local secs, ms = pd.getSecondsSinceEpoch()
  local mixed = (secs or 0) + (ms or 0) * 7 + pd.getCurrentTimeMilliseconds() * 13 + frames * 101
  math.randomseed(math.floor(mixed))
  math.random(); math.random(); math.random()
end

-- The window: the weather changes now and then, people stroll past
WIN.FX = { "rain", "wind", "leaves", "snow", "clouds" }      -- (snow never mixes with rain or leaves; wind goes with anything)

-- With the Halloween or the Christmas music on in the shop, the weather follows the season:
--   "fall":   it rains or clouds over now and then, and the leaves are always falling (no snow, no wind)
--   "winter": it only snows, all day (no rain, no clouds, no leaves, no wind)
WIN.SEASON_FX = { fall = { "rain", "clouds" }, winter = { "clouds" } }
function WIN.applySeason(fx, season)
  if season == "fall" then fx.leaves = true; fx.snow = false; fx.wind = false
  elseif season == "winter" then fx.snow = true; fx.leaves = false; fx.rain = false; fx.wind = false end        -- (clouds come and go)
end

function WIN.newWindow(season)
  local fx = { rain = false, wind = false, leaves = false, snow = false, clouds = false }
  local r, n = math.random(), 0
  if r < 0.22 then n = 0 elseif r < 0.67 then n = 1 elseif r < 0.90 then n = 2 else n = 3 end
  local pool = { 1, 2, 3, 4, 5 }
  for _ = 1, n do
    local k = table.remove(pool, math.random(#pool))
    fx[WIN.FX[k]] = true
  end
  if fx.snow then fx.rain = false; fx.leaves = false end
  WIN.applySeason(fx, season)
  local parts = {}
  if fx.clouds then                                  -- already cloudy when you arrive
    parts[1] = { k = "cloud", x = 22, y = 29, vx = 4 + math.random() * 3, vy = 0, s = 1 }
    parts[2] = { k = "cloud", x = 52, y = 31, vx = 4 + math.random() * 3, vy = 0, s = 0 }
  end
  local w = { fx = fx, nextChange = 70 + math.random() * 70, acc = { rain = 0, wind = 0, leaves = 0, snow = 0, clouds = 0 },
              parts = parts, walkers = {}, walkIn = 4 + math.random() * 8,
              skyIn = 12 + math.random() * 25, season = season }
  WIN.startSky(w)
  return w
end

-- day and night take turns all shift long: the sun crosses the window by day, the moon by night.
-- With the Halloween music on it is always night, and the moon stays up.
function WIN.startSky(w)
  if w.season == "fall" then
    w.sky = { kind = "moon", t = 36, dur = 60, still = true }
  else
    local dur = 50 + math.random() * 20
    w.sky = { kind = (math.random() < 0.5) and "moon" or "sun", t = math.random() * dur * 0.6, dur = dur }
  end
end
function WIN.isNight(w) return w ~= nil and w.sky ~= nil and w.sky.kind == "moon" end
function WIN.nightAmt(w)                      -- 0 = full day, 1 = full night; it eases across the turn from one to the other
  local s = w and w.sky
  if not s then return 0 end
  if s.still then return (s.kind == "moon") and 1 or 0 end
  local moon = (s.kind == "moon")
  local n = moon and 1 or 0
  local T = math.min(8, s.dur / 4)
  local dir = moon and -1 or 1
  if s.t > s.dur - T then n = n + dir * 0.5 * (s.t - (s.dur - T)) / T
  elseif s.t < T then n = n + dir * 0.5 * (1 - s.t / T) end
  return n
end
function UI.skyBlend() end                    -- (PC: blends the sky's colours; nothing to do on the 1-bit Playdate)

function WIN.updateWindow(dt)
  local w = G.win
  w.nextChange = w.nextChange - dt
  if w.nextChange <= 0 then                       -- slow: one effect flips every 70-140 s
    local list = (w.season and WIN.SEASON_FX[w.season]) or WIN.FX              -- (in a season only some kinds of weather happen)
    local k = (#list > 0) and list[math.random(#list)] or nil                    -- (winter: nothing changes, it just keeps snowing)
    if k then w.fx[k] = not w.fx[k] else k = "none" end
    if w.fx[k] then                                -- snow and rain/leaves never share a sky
      if k == "snow" then w.fx.rain = false; w.fx.leaves = false
      elseif k == "rain" or k == "leaves" then w.fx.snow = false end
    end
    WIN.applySeason(w.fx, w.season)
    w.nextChange = 70 + math.random() * 70
  end
  -- the sun crosses the window, then the moon, then the sun again: a day and night cycle (Halloween: the moon just stays up)
  if not w.sky then WIN.startSky(w) end
  if not w.sky.still then
    w.sky.t = w.sky.t + dt
    if w.sky.t >= w.sky.dur then
      w.sky = { kind = (w.sky.kind == "sun") and "moon" or "sun", t = 0, dur = 50 + math.random() * 20 }
    end
  end
  local rate = { rain = 16, wind = 1.5, leaves = 0.9, snow = 7, clouds = 0.16 }
  for _, k in ipairs(WIN.FX) do
    if w.fx[k] then w.acc[k] = w.acc[k] + rate[k] * dt end
    while w.acc[k] >= 1 do
      w.acc[k] = w.acc[k] - 1
      if k == "rain" then
        local sl = w.fx.wind and 14 or -3
        w.parts[#w.parts + 1] = { k = "rain", x = 12 + math.random() * 56, y = 21, vx = sl, vy = 70 + math.random() * 25 }
      elseif k == "clouds" then
        w.parts[#w.parts + 1] = { k = "cloud", x = 7, y = 27 + math.random() * 5, vx = 4 + math.random() * 3, vy = 0,
                                  s = math.random(0, 1) }
      elseif k == "snow" then
        w.parts[#w.parts + 1] = { k = "snow", x = 12 + math.random() * 56, y = 21, vx = 0,
                                  vy = 9 + math.random() * 8, ph = math.random() * 6 }
      elseif k == "wind" then
        w.parts[#w.parts + 1] = { k = "wind", x = 8, y = 26 + math.random() * 18, vx = 26 + math.random() * 14, vy = 0,
                                  ph = math.random() * 6 }
      else
        w.parts[#w.parts + 1] = { k = "leaf", x = 15 + math.random() * 50, y = 21, vx = 0,
                                  vy = 12 + math.random() * 8, ph = math.random() * 6 }
      end
    end
  end
  for i = #w.parts, 1, -1 do
    local q = w.parts[i]
    if q.k == "snow" then
      q.ph = q.ph + dt * 1.6
      q.x = q.x + math.sin(q.ph) * 6 * dt + (w.fx.wind and 14 * dt or 0)
    elseif q.k == "leaf" then
      q.ph = q.ph + dt * 2.2
      q.x = q.x + math.sin(q.ph) * 12 * dt + (w.fx.wind and 10 * dt or 0)
    elseif q.k == "wind" then
      q.ph = q.ph + dt * 4
      q.x = q.x + q.vx * dt
    else
      q.x = q.x + q.vx * dt
    end
    q.y = q.y + q.vy * dt
    if q.x > 76 or q.x < 6 or q.y > 49 then table.remove(w.parts, i) end
  end
  -- someone walks by now and then (never a crowd)
  w.walkIn = w.walkIn - dt
  if w.walkIn <= 0 and #w.walkers == 0 then
    local dir = (math.random() < 0.5) and 1 or -1
    w.walkers[1] = { x = dir == 1 and 6 or 76, dir = dir, speed = 15 + math.random() * 8, t = 0,
                     umbrella = w.fx.rain }
    w.walkIn = (w.gap or 14) + math.random() * (w.gapSpan or 18)
  end
  for i = #w.walkers, 1, -1 do
    local q = w.walkers[i]
    q.x = q.x + q.dir * q.speed * dt
    q.t = q.t + dt * 9
    if q.x < 2 or q.x > 80 then table.remove(w.walkers, i) end
  end
end

UI.COCOA_PAT = { 0x55, 0x22, 0x55, 0x88, 0x55, 0x22, 0x55, 0x88 }      -- (dark, so hot cocoa looks different from coffee in the cup)
UI.PUMPKIN_PAT = nil                     -- (the PC version gives pumpkin spice a pattern of its own, so it can be pumpkin coloured)
function UI.applyDrinkLook()
  local s = UI.season()
  DRINK_PATTERN.matcha = (s == "winter") and UI.COCOA_PAT or ((s == "fall" and UI.PUMPKIN_PAT) or DIAG)
end
function UI.drinkInk(kind)               -- PC: the colour of a drink (the coffee stream, ...)
  if kind == "matcha" then
    local s = UI.season()
    UI.ink((s == "fall") and "pspice" or ((s == "winter") and "cocoa" or "matcha"))
  else UI.ink(kind or "coffee") end
end

-- the season the cafe is in: "fall" with the Halloween music on, "winter" with the Christmas music on (one or the other each day if both are on).
-- (the window is made again whenever the music that is switched on changes, e.g. after a visit to the shop in the middle of a shift)
function CAFE.newWindowFor(d)
  local f, x = d and d.decor and d.decor.hmus == "on", d and d.decor and d.decor.xmus == "on"
  local season = nil
  if f and x then season = (math.random() < 0.5) and "fall" or "winter"
  elseif f then season = "fall"
  elseif x then season = "winter" end
  local w = WIN.newWindow(season)
  w.sk = (f and "H" or "") .. (x and "X" or "")
  return w
end

local function newGame(mode)
  mode = mode or "rush"
  reseed()
  local room = (mode ~= "cafe") and CAFE.randomRoom(mode) or nil      -- rush / chill: a new random room each time
  local dd = room or CAFE.cur
  CAFE.applyLayout(dd)
  setLayout(mode)
  G = {
    deco = room,
    mode = mode,
    t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
    px = STATIONS[1].x, moving = false, walk = 0,
    cupMax = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL,
    seatLimit = CAFE.seatsOf(dd.seatStep),
    seatOff = CAFE.seatOffOf(dd),
    seatCount = CAFE.seatCountOf(dd),
    cafe = (mode == "cafe") and CAFE.cur or nil,
    cups = { shelf = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL, dirty = 0, hand = 0 },   -- dishes
    sink = { state = "empty", progress = 0, angle = 0, t = 0 },
    lastCount = nil, ending = false,
    flow = { m = 0.5, target = 0.5, timer = 20 },
    pets = CAFE.makePets(dd),                        -- (the random rooms have pets now and then too)
    win = (mode == "cafe") and CAFE.newWindowFor(CAFE.cur) or WIN.newWindow(),
    sel = "down",       -- Evening Chill: "up" = the wall shelf, "down" = the counter
    st = nil,           -- which station panel is open ("register", ...)
    cust = nil,         -- the customer being served right now
    line = {},          -- people waiting in line (line[1] is next)
    others = {},        -- people walking to a seat, sitting, or leaving
    seats = {},         -- seats[i] = the customer sitting there
    arriveIn = 0.8,     -- seconds until the next customer shows up
    stepT = 0,          -- short pause before the next person steps up
    door = 0,           -- 0 = closed, 1 = open
    popups = {},        -- floating "+$2.00" texts
    msg = nil, msgT = 0,
    endT = 0,
  }
  setShiftMenu(mode ~= "rush", mode == "cafe")
end

local function say(str)
  G.msg = str
  G.msgT = 2.2
end

local function addPopup(str, x, y, life, small)
  G.popups[#G.popups + 1] = { s = str, x = x, y = y, t = 0, life = life or 1.8, small = small }
end

----------------------------------------------------------------------
-- Crank helper (shows the "use the crank" hint if the crank is docked)
----------------------------------------------------------------------
local function crankHelpStart()
  local ci = pd.ui and pd.ui.crankIndicator
  if ci and ci.start then ci:start() end
end

local function crankHelpDraw()
  if not pd.isCrankDocked() then return end
  local ci = pd.ui and pd.ui.crankIndicator
  if ci == nil then return end
  if ci.update then ci:update() elseif ci.draw then ci:draw() end
end

----------------------------------------------------------------------
-- Customers
----------------------------------------------------------------------
local function weighted(w)
  local total = 0
  for _, v in ipairs(w) do total = total + v end
  local r = math.random() * total
  for i, v in ipairs(w) do
    r = r - v
    if r < 0 then return i - 1 end
  end
  return #w - 1
end

-- lines of text for the speech bubble (after the greeting)
local function orderLines(o)
  local lines = UI.orderLines0(o)
  table.insert(lines, 1, UI.SIZE_NAME[o.size or 3] .. " size")
  return lines
end

function UI.orderLines0(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. " espresso" end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 then
    if o.kind and o.kind ~= "coffee" then return { "Just plain, thanks!" } end
    return { "Just black, thanks!" }
  end
  if #items == 1 then return { "With " .. items[1] } end
  if #items == 2 then return { "With " .. items[1] .. " & " .. items[2] } end
  if #items == 3 then return { "With " .. items[1] .. ", " .. items[2], "& " .. items[3] } end
  return { "With " .. items[1] .. ", " .. items[2] .. ",", items[3] .. " & " .. items[4] }
end

-- short version for the panel headers
local function orderShort(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. (o.shot == 1 and " shot" or " shots") end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 and o.kind == "coffee" then return "Black coffee" end
  table.insert(items, 1, string.sub(UI.SIZE_NAME[o.size or 3], 1, 1) .. ". " .. UI.kindName(o.kind))
  return table.concat(items, ", ")
end

function UI.specialMix(o, sp)                       -- what goes in the season's drink
  if sp.icon == "pumpkin" then                        --   pumpkin spice latte: espresso, milk and sugar welcome, almost always hot
    o.milk = math.max(o.milk, 1)
    if math.random() < 0.85 then o.ice = 0 end
  else                                                --   hot cocoa: milk and sugar, no espresso, no ice
    o.shot, o.ice = 0, 0
    o.milk = math.max(o.milk, 1)
  end
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1 elseif o.ice > 0 then o.ice = o.ice - 1 else o.shot = o.shot - 1 end
  end
end

function UI.reseason(c)                             -- the season changed while this matcha customer had not ordered yet: they ask for what is on the menu now
  local o = c.order
  if not o or o.kind ~= "matcha" then return end
  local sp = UI.SPECIAL[UI.season() or ""]
  if sp then UI.specialMix(o, sp) else o.shot = 0 end
  c.greet = sp and sp.greet or "One matcha, please!"
  c.price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind]
end

local function newCustomer()
  local o = { milk = weighted(MILK_WEIGHTS), sugar = weighted(SUGAR_WEIGHTS),
              shot = weighted(SHOT_WEIGHTS), ice = weighted(ICE_WEIGHTS), size = math.random(1, 3) }
  -- keep orders sensible: nobody wants more than 5 extras
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1
    elseif o.ice > 0 then o.ice = o.ice - 1
    elseif o.milk > 0 then o.milk = o.milk - 1
    else o.shot = o.shot - 1 end
  end
  local chill = (G ~= nil and G.mode ~= "rush")
  o.kind = KINDS[weighted(KIND_WEIGHTS) + 1]
  local special = (o.kind == "matcha") and UI.SPECIAL[UI.season() or ""] or nil
  if special then                                            -- the season's drink: what people put in it makes sense
    UI.specialMix(o, special)
  elseif o.kind == "matcha" or o.kind == "tea" or o.kind == "decaf" then o.shot = 0 end      -- no espresso in those
  local greet = GREETS[math.random(#GREETS)]
  if special then greet = special.greet
  elseif o.kind == "matcha" then greet = "One matcha, please!"
  elseif o.kind == "decaf" then greet = "Decaf, please!"
  elseif o.kind == "tea" then greet = "Tea, please!" end
  local look = UI.LOOKS[math.random(#UI.LOOKS)]
  local hat, glass = CAFE.pickWear(look)                  -- now and then a customer comes in wearing a hat and / or glasses
  return {
    x = DOOR_X, y = 258, path = {}, walk = 0,
    state = "line",       -- line, active, toSeat, seated, leaving
    stage = 0,            -- 0 stepping up, 1 register, 2 coffee, 3 mixer, 4 serve
    order = o,
    price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind],   -- cents
    greet = greet,
    look = look, hat = hat, glass = glass,
    patience = 1.0,       -- 1 = fresh, 0 = walks out
    q = 1.0,              -- order quality (mistakes lower it, it decides the tip)
    dine = math.random() < (chill and CHILL_DINE_IN or DINE_IN_CHANCE) and (G == nil or (G.seatCount or G.seatLimit) > 0),
    hasCup = false,       -- Evening Chill: carrying one of the shop's ceramic cups
    seat = nil, stay = 0,
    reg = { digits = "", state = "type", cur = 5, crank = 0, flash = 0, tick = 0 },
    cof = { fill = 0, tilt = 0, base = nil,
            phase = "pick", pick = nil },
    mix = { milk = 0, sugar = 0, shot = 0, ice = 0, phase = 1, progress = 0, angle = 0, tick = 0, hold = 0 },
    srv = { phase = 1, slide = 0, crank = 0, ding = 0, tick = 0, recent = 0 },
  }
end

-- Walking around things: tables (with their chairs) and floor decor are obstacles that people and pets go round.
-- An obstacle is a short line with a thickness; one that you start or finish inside is ignored (your own seat, a pet's bed).
function CAFE.obstacles()
  local obs = {}
  local lim = G.seatLimit or 0
  for ti, t in ipairs(TABLES) do
    local fs = 2 * ti - 1
    if fs <= lim and not (G.seatOff and G.seatOff[fs]) then
      obs[#obs + 1] = { x1 = t.x - 17, y1 = t.y, x2 = t.x + 17, y2 = t.y, r = 15 }
    end
  end
  if lim >= 15 then obs[#obs + 1] = { x1 = 350, y1 = 157, x2 = 350, y2 = 157, r = 9 } end      -- the nook table's top chair
  local d = G.cafe or G.deco
  if d then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] then
        local sl = CAFE.FSLOT[d.place[it.id]]
        obs[#obs + 1] = { x1 = sl[1], y1 = sl[2] + 6, x2 = sl[1], y2 = sl[2] + 6, r = 11 }
      end
    end
  end
  return obs
end

function CAFE.dist(o, px, py)                  -- how far a point is from an obstacle's line
  local dx, dy = o.x2 - o.x1, o.y2 - o.y1
  local len2 = dx * dx + dy * dy
  local t = 0
  if len2 > 0 then t = clamp(((px - o.x1) * dx + (py - o.y1) * dy) / len2, 0, 1) end
  local qx, qy = o.x1 + dx * t, o.y1 + dy * t
  return math.sqrt((px - qx) ^ 2 + (py - qy) ^ 2)
end

function CAFE.firstBlock(obs, skip, ax, ay, bx, by)     -- the first obstacle a straight walk would go through
  local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
  local n = math.max(1, math.floor(len / 3))
  for i = 1, n do
    local px, py = ax + (bx - ax) * i / n, ay + (by - ay) * i / n
    for _, o in ipairs(obs) do
      if not skip[o] and CAFE.dist(o, px, py) < o.r then return o end
    end
  end
  return nil
end

function CAFE.routeR(obs, skip, ax, ay, bx, by, depth)
  local hit = CAFE.firstBlock(obs, skip, ax, ay, bx, by)
  if not hit or depth >= 4 then return {} end
  local m = hit.r + 5
  local cx, cy = (hit.x1 + hit.x2) / 2, (hit.y1 + hit.y2) / 2
  local cand = {
    { hit.x1 - m, hit.y1 }, { hit.x2 + m, hit.y2 }, { cx, hit.y1 - m }, { cx, hit.y1 + m },
    { hit.x1 - m * 0.7, hit.y1 - m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 - m * 0.7 },
    { hit.x1 - m * 0.7, hit.y1 + m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 + m * 0.7 },
  }
  local best, bc
  for _, w in ipairs(cand) do
    local wx, wy = clamp(w[1], 14, 392), clamp(w[2], 124, 238)
    local inside = false
    for _, o in ipairs(obs) do if not skip[o] and CAFE.dist(o, wx, wy) < o.r then inside = true end end
    if not inside and (wx - ax) ^ 2 + (wy - ay) ^ 2 > 9 and not CAFE.firstBlock(obs, skip, ax, ay, wx, wy) then
      local cost = math.sqrt((wx - ax) ^ 2 + (wy - ay) ^ 2) + math.sqrt((bx - wx) ^ 2 + (by - wy) ^ 2)
      if bc == nil or cost < bc then best, bc = { wx, wy }, cost end
    end
  end
  if not best then return {} end
  local out = { best }
  for _, w in ipairs(CAFE.routeR(obs, skip, best[1], best[2], bx, by, depth + 1)) do out[#out + 1] = w end
  return out
end

function CAFE.route(ax, ay, bx, by)            -- waypoints (not counting the start or the goal) that go round things
  if not G then return {} end
  local obs = CAFE.obstacles()
  local skip = {}
  for _, o in ipairs(obs) do
    if CAFE.dist(o, ax, ay) < o.r + 1 or CAFE.dist(o, bx, by) < o.r + 1 then skip[o] = true end
  end
  return CAFE.routeR(obs, skip, ax, ay, bx, by, 0)
end

function CAFE.pointBlocked(x, y)
  if not G then return false end
  for _, o in ipairs(CAFE.obstacles()) do if CAFE.dist(o, x, y) < o.r then return true end end
  return false
end

function CAFE.avoidPath(sx, sy, pts)           -- a list of stops, with the detours put in
  local out = {}
  for _, pt in ipairs(pts) do
    for _, w in ipairs(CAFE.route(sx, sy, pt[1], pt[2])) do out[#out + 1] = { w[1], w[2] } end
    out[#out + 1] = pt
    sx, sy = pt[1], pt[2]
  end
  return out
end

-- walking: customers follow a list of waypoints
local function routeTo(c, x, y)
  if c.y > 236 then
    c.path = CAFE.avoidPath(c.x, c.y, { { DOOR_X, 228 }, { x, y } })     -- still outside: come in through the door first
  else
    c.path = CAFE.avoidPath(c.x, c.y, { { x, y } })
  end
end

local function moveAlong(c, dt)
  local p = c.path[1]
  if p == nil then return end
  local dx, dy = p[1] - c.x, p[2] - c.y
  local d = math.sqrt(dx * dx + dy * dy)
  local step = CUST_SPEED * dt
  if d <= step then
    c.x, c.y = p[1], p[2]
    table.remove(c.path, 1)
    if p[3] == "drop" and c.hasCup then          -- leave the used cup in the dish bin
      c.hasCup = false
      G.cups.dirty = G.cups.dirty + 1
      UI.sfxDish()
    end
  else
    c.x = c.x + dx / d * step
    c.y = c.y + dy / d * step
  end
  c.walk = c.walk + dt * 14
end

local function leaveRoute(c)
  c.state = "leaving"
  local p = {}
  local sx, sy = c.x, c.y
  if c.hasCup then
    p[#p + 1] = { DISH_X, 152, "drop" }        -- bring the cup back to the dish bin first
    sx, sy = DISH_X, 152
  end
  local lx = sx
  if lx < 96 then
    lx = 96                                    -- slip out sideways, not through the line
    p[#p + 1] = { lx, sy }
  end
  if sy < 232 then p[#p + 1] = { lx, 232 } end
  p[#p + 1] = { DOOR_X, 234 }
  p[#p + 1] = { DOOR_X, 270 }
  c.path = CAFE.avoidPath(c.x, c.y, p)
end

local function relineup()
  for i, c in ipairs(G.line) do routeTo(c, LINE_SLOTS[i][1], LINE_SLOTS[i][2]) end
end

local function freeSeat()
  local free = {}
  for i = 1, G.seatLimit do
    if G.seats[i] == nil and not (G.seatOff and G.seatOff[i]) then free[#free + 1] = i end
  end
  if #free == 0 then return nil end
  return free[math.random(#free)]
end

----------------------------------------------------------------------
-- Stations
----------------------------------------------------------------------
local function stopLoops(keepMixer)
  sfxStop("pour")
  if not keepMixer then sfxStop("mixer") end
  sfxStop("sink")
  sfxStop("cleaning")
end

local function closeStation(keepMixer)
  if G and G.st == "coffee" then pcall(pd.stopAccelerometer) end
  stopLoops(keepMixer)
  if G then G.st = nil end
end

local function nearStation()
  for _, st in ipairs(STATIONS) do
    if math.abs(G.px - st.x) <= 22 then return st end
  end
  return nil
end

-- Evening Chill: the cup shelf hangs on the wall above the barista
local SHELF_X1, SHELF_X2 = 104, 194
local function nearWall()
  return G.px >= SHELF_X1 and G.px <= SHELF_X2
end

-- true when the shelf (up) is what A would open, false when it's the counter (down)
local function shelfSelected()
  if not nearWall() then return false end
  return G.sel == "up" or nearStation() == nil
end

local function tryOpen(st)
  if st.id == "dishes" then                          -- no customer needed
    local sk = G.sink
    if sk.state == "empty" and G.cups.dirty == 0 then
      say("No dirty cups right now.")
      sfxWrong()
      return
    end
    G.st = st.id
    if sk.state == "empty" then                      -- just crank: the first dirty cup is already in the sink
      G.cups.dirty = G.cups.dirty - 1
      sk.state, sk.progress, sk.angle = "washing", 0, 0
      sfxCup()
    end
    if sk.state == "washing" then crankHelpStart() end
    return
  end
  local c = G.cust
  if c == nil or c.stage < 1 then
    say("Waiting for a customer...")
    return
  end
  if c.stage ~= st.stage then
    if c.stage > st.stage then
      say("This machine is already done.")
      if st.id == "mixer" then CAFE.mistake(0.03) end        -- clicked the mixer out of habit
    else
      say("Do the " .. STAGE_ST[c.stage].name .. " first!")
    end
    sfxWrong()
    return
  end
  if st.id == "serve" and #c.path > 0 then
    say("They're still walking over!")
    return
  end
  if st.id == "register" and G.cups.hand > 0 then
    say("Put the clean cups on the shelf first!")
    sfxWrong()
    return
  end
  if st.id == "coffee" and c.dine and not c.hasCup then
    if G.cups.shelf > 0 then                      -- grab a clean cup from the shelf
      G.cups.shelf = G.cups.shelf - 1
      c.hasCup = true
      sfxCup()
    else
      c.dine = false
    end
  end
  G.st = st.id
  if st.id == "serve" and c.srv.phase == 1 then
    c.srv.phase = 2                    -- A at the counter slides the plate right away
    sfxPlay("slide", false, 1.0)
  end
  if st.id == "coffee" then
    pd.startAccelerometer()
    c.cof.base = nil
  end
  if (st.id == "register" and c.reg.state == "crank")
      or (st.id == "mixer" and c.mix.phase == 2) then
    crankHelpStart()
  end
end

-- Rush Hour combo: 1 good order = x1, then +0.25 for each one in a row, up to x3
function UI.comboMult(streak) return 1 + 0.25 * math.min(math.max(streak - 1, 0), 8) end
function UI.comboTxt(streak) return string.format("%g", UI.comboMult(streak)) end

-- ---- the order is finished: pay, tip, send the customer off ----------
local function finishOrder(c)
  local q = clamp(c.q, 0, 1)
  c.final = q
  local tip = 0
  if q >= 0.5 then
    local f = 0.4 + 0.6 * c.patience
    local pm = (G.mode == "cafe") and (1 + 0.15 * CAFE.petCount()) * UI.tipMult(G.cafe) or 1      -- pets help the tips (and in the Cafe: the barista level, the decor after a prestige, the tip boost)
    if c.dine then pm = pm * 1.3 end                                           -- dining in tips better
    tip = math.floor(TIP_MAX * q * q * f * pm * (1 + 0.15 * (c.precise or 0)) / 25 + 0.5) * 25
  end
  local combo, lost = 0, false
  if G.mode == "rush" then                        -- Rush Hour: back-to-back good orders build a combo, and the combo multiplies what each order earns
    if q >= 0.9 then G.streak = (G.streak or 0) + 1 else lost = (G.streak or 0) >= 2; G.streak = 0 end
    G.bestStreak = math.max(G.bestStreak or 0, G.streak)
    local mult = UI.comboMult(G.streak)
    combo = math.floor((c.price + tip) * (mult - 1) / 25 + 0.5) * 25
  end
  G.cash = G.cash + c.price
  G.tips = G.tips + tip + combo
  G.served = G.served + 1
  if G.mode == "cafe" then UI.review(c, q) end              -- (the review: a grade sticker, and the star meter moves)
  if G.mode == "cafe" and q >= 0.5 then                     -- (counters for the Cafe achievements)
    if (c.order.ice or 0) > 0 then UI.statAdd("iced", 1) end
    if c.order.kind == "matcha" and UI.season() then UI.statAdd("season", 1) end
    if not UI.noWait() and (c.patience or 0) >= 0.9 then UI.statAdd("speedy", 1) end
    UI.statMax("bigtip", tip)
  end
  if G.mode == "rush" then UI.statMax("combo", G.streak or 0) end
  addPopup("+" .. money(c.price), stationById("register").x, 54, 1.8)
  if tip > 0 then
    addPopup("+" .. money(tip), JAR_X, 54, 2.2, true)
    sfxPlay("tip")
  else
    addPopup("no tip", JAR_X, 54, 1.8, true)
  end
  if combo > 0 then say("Combo x" .. UI.comboTxt(G.streak) .. "!  +" .. money(combo))
  elseif lost then say("Combo lost!")
  elseif G.mode == "cafe" then                     -- (the Cafe shows its grade as a sticker instead)
  elseif q >= 0.95 then say("Perfect order!")
  elseif q >= 0.75 then say("Nice work!")
  elseif q >= 0.5 then say("Good enough.")
  else say("Ouch... that was off.") end

  closeStation()
  G.cust = nil
  G.stepT = 0.7
  -- some people sit down with their drink, some take it to go
  if c.dine then
    local s = freeSeat()
    if s then
      G.seats[s] = c
      c.seat = s
      c.state = "toSeat"
      c.path = CAFE.avoidPath(c.x, c.y, { { SEATS[s].x, SEATS[s].y } })
    else
      leaveRoute(c)           -- no free seat: they head out
    end
  else
    leaveRoute(c)
  end
  G.others[#G.others + 1] = c
end

-- ---- 1. register -----------------------------------------------------
local function regPress(c, key)
  local r = c.reg
  if key == "DEL" then
    r.digits = string.sub(r.digits, 1, -2)
    sfxClick()
  elseif key == "ENT" then
    local val = tonumber(r.digits) or 0
    if val == c.price then
      G.lastSale = c.price                -- (the till's screen on the counter shows this sale from now on)
      r.state = "crank"
      crankHelpStart()
      sfxGood()
    else
      c.q = c.q - 0.2
      CAFE.mistake(0.05)
      r.digits = ""
      r.flash = 0.9
      sfxWrong()
    end
  else
    if #r.digits < 4 then r.digits = r.digits .. key end
    sfxClick()
  end
end

local function updateRegister(c, dt)
  local r = c.reg
  if r.flash > 0 then r.flash = r.flash - dt end
  if r.state == "type" then
    local col = (r.cur - 1) % 3
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if col == 0 then r.cur = r.cur + 2 else r.cur = r.cur - 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if col == 2 then r.cur = r.cur - 2 else r.cur = r.cur + 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      r.cur = r.cur - 3
      if r.cur < 1 then r.cur = r.cur + 12 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      r.cur = r.cur + 3
      if r.cur > 12 then r.cur = r.cur - 12 end
      sfxClick()
    end
    if pd.buttonJustPressed(pd.kButtonA) then regPress(c, KEYS[r.cur]) end
  else
    local ch = math.abs(pd.getCrankChange())
    r.crank = r.crank + ch
    r.tick = r.tick + ch
    if ch > 0.8 then
      r.hold = 0.15
      local sp = sfx.receipt
      if UI.rcptPaused and sp then                                      -- (cranking again after a pause: the printer sound carries on where it stopped)
        UI.rcptPaused = false
        if not pcall(function() sp:setPaused(false) end) then sfxPlay("receipt", false, 1.0, 1.0) end
      elseif not (sp and sp:isPlaying()) then sfxPlay("receipt", false, 1.0, 1.0) end   -- plays once, no loop
    else
      r.hold = (r.hold or 0) - dt
      if r.hold <= 0 and r.crank < RECEIPT_CRANK and not UI.rcptPaused and sfx.receipt and sfx.receipt:isPlaying() then
        UI.rcptPaused = pcall(function() sfx.receipt:setPaused(true) end)    -- (a pause in the cranking pauses it, rather than starting it over next time)
      end
    end
    if r.tick >= 30 then r.tick = r.tick - 30; sfxTick() end
    if r.crank >= RECEIPT_CRANK then
      c.stage = 2
      closeStation()
      routeTo(c, PICK_X, PICK_Y)      -- the customer drifts over to the pickup end
    end
  end
end

-- ---- 2. coffee ------------------------------------------------------
local PICK_BUTTONS = {
  { pd.kButtonUp, "coffee" }, { pd.kButtonRight, "matcha" },
  { pd.kButtonDown, "decaf" }, { pd.kButtonLeft, "tea" },
}

local function updateCoffee(c, dt)
  local f = c.cof
  if f.phase == "pick" then
    for _, pb in ipairs(PICK_BUTTONS) do
      if pd.buttonJustPressed(pb[1]) then f.pick = pb[2]; sfxClick() end
    end
    if pd.buttonJustPressed(pd.kButtonA) then
      if f.pick == nil then
        say("Pick a drink first!")
        sfxWrong()
      else
        f.phase = "pour"
        f.base = nil
        if UI.crankPour then crankHelpStart() end
        if f.pick ~= c.order.kind then c.q = c.q - 0.35; CAFE.mistake(0.12) end    -- wrong drink!
        sfxClick()
      end
    end
    return
  end
  local t = 0
  local autoDone = false
  if UI.crankPour then
    -- crank option: only turning it clockwise pours, and the faster you turn the faster it flows
    -- a real tap: turning the crank clockwise opens the valve, and the further you turn it the faster it flows;
    -- it keeps flowing by itself until you turn the crank back to close it
    local ch = pd.getCrankChange() or 0
    if ch == 0 and UI.color then ch = -90 end           -- (PC: letting go of the space bar shuts the tap at once, so it stops where you let go; on the Playdate the tap stays where you left it)
    f.valve = clamp((f.valve or 0) + ch / 180, 0, 1)         -- half a turn is wide open (and that's as fast as it gets)
    if not f.open and f.valve > 0.15 then f.open = true; f.hadOpen = true      -- a bit of cranking before it starts to flow
    elseif f.open and f.valve < 0.25 then f.open = false end                  -- and a roomy zone near the start where it shuts off
    t = f.open and math.max(0.02, (f.valve - 0.15) / 0.85) or 0
    if f.hadOpen and not f.open and f.fill >= UI.SIZE_FILL[c.order.size or 3] - 0.15 then autoDone = true end   -- tap closed and the cup is full (or a hair under): done
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  else
    local ax, ay = 0, 0
    if pd.accelerometerIsRunning() then
      local x, y = pd.readAccelerometer()
      ax, ay = x or 0, y or 0
    end
    -- the pose you were holding when you stepped up counts as "level"
    if f.base == nil then f.base = { ax, ay } end
    local d = math.sqrt((ax - f.base[1]) ^ 2 + (ay - f.base[2]) ^ 2)
    t = clamp((d - 0.2) / 0.5, 0, 1)
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  end
  if not UI.crankPour then                           -- tilt: back to resting with the cup full (or a hair under) counts as done
    if t > 0 then f.hadOpen = true
    elseif f.hadOpen and f.fill >= UI.SIZE_FILL[c.order.size or 3] - 0.15 then autoDone = true end
  end
  if t > 0 and f.fill < 1.25 then
    local rate = UI.crankPour and (0.6 * t ^ 1.3) or (POUR_RATE_MIN + (POUR_RATE_MAX - POUR_RATE_MIN) * t)
    f.fill = math.min(1.25, f.fill + rate * dt)
    sfxPour()
  else
    sfxStop("pour")
  end
  UI.pourSim(f, (t > 0 and f.fill < 1.25) and t or 0, dt)          -- the drink's surface, bubbles, crema and splashes
  if autoDone or pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB) then
    if f.fill < 0.2 then
      say("Pour some coffee first!")
      sfxWrong()
    else
      local err = math.abs(f.fill - UI.SIZE_FILL[c.order.size or 3])
      local pen = 0
      if err > 0.15 then pen = math.min(0.5, (err - 0.15) * 1.5) end      -- on the line or close to it is fine (about 7 pixels either side, so the last
      -- drips after you stop don't count against you); a bit further off still gets PERFECT, and only a clear miss costs more
      c.precise = clamp(1 - err / 0.15, 0, 1)                             -- a spot-on pour earns a bonus on the tip
      if f.fill > 1.2 then                                                -- it spilled over: much worse
        pen = pen + 0.2
        c.patience = math.max(0.05, c.patience - 0.25)                    -- they watch the mess get cleaned up
        CAFE.mistake(0.12)
        sfxWrong()
      end
      c.q = c.q - pen
      c.patience = math.max(0.05, c.patience - pen * 0.4)                 -- sloppy pours annoy people
      if pen > 0 then CAFE.mistake(0.04 + pen * 0.2) end                  -- missed the mark / overflowed
      sfxClick()
      local o = c.order
      if o.milk + o.sugar + o.shot + o.ice == 0 then
        c.stage = 4                      -- nothing to mix in: straight to pick up
      else
        c.stage = 3
      end
      closeStation()
    end
  end
end

-- ---- 3. mixer --------------------------------------------------------
local function updateMixer(c, dt)
  local m = c.mix
  if m.phase == 1 then
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if m.milk < 4 then m.milk = m.milk + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if m.sugar < 4 then m.sugar = m.sugar + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      if m.shot < 4 then m.shot = m.shot + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      if m.ice < 4 then m.ice = m.ice + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonA) then
      m.phase = 2
      crankHelpStart()
      sfxClick()
    end
  else
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    m.angle = m.angle + change
    m.progress = m.progress + ch / MIX_CRANK
    m.tick = m.tick + ch
    if m.tick >= 40 then m.tick = m.tick - 40; sfxTick() end
    -- electric mixer noise while you crank (faster crank = higher whirr)
    if ch > 0.8 then
      m.hold = 0.15
      local icy = (m.ice > 0 and sfx.icemixer) and "icemixer" or "mixer"            -- a drink with ice rattles while it mixes
      if not ((sfx.mixer and sfx.mixer:isPlaying()) or (sfx.icemixer and sfx.icemixer:isPlaying())) then sfxPlay(icy, false, 1.0, 1.0) end
    else
      m.hold = m.hold - dt
      if m.hold <= 0 and m.progress < 1 then sfxStop("mixer") end
    end
    if m.progress >= 1 then
      m.progress = 1
      local o = c.order
      local off = math.abs(m.milk - o.milk) + math.abs(m.sugar - o.sugar)
                + math.abs(m.shot - o.shot) + math.abs(m.ice - o.ice)
      c.q = c.q - 0.2 * off
      if off > 0 then CAFE.mistake(math.min(0.2, 0.04 * off)) end   -- wrong or missing ingredients
      c.stage = 4
      closeStation(true)               -- the mixer winds down by itself
    end
  end
end

-- ---- 4. serve + bell -------------------------------------------------
local function updateServe(c, dt)
  local s = c.srv
  if s.phase == 1 then
    s.phase = 2                       -- (safety: never wait for a second A)
  elseif s.phase == 2 then
    s.slide = math.min(1, s.slide + dt / 0.55)        -- (a smooth glide: see drawServe)
    s.recent = s.recent * 0.85
    -- the plate has to land before the bell can be rung
    if pd.buttonJustPressed(pd.kButtonA) and s.slide >= 1 then
      s.phase = 3
      s.ding = 0.9
      sfxPlay("bell", false, 1.0)                 -- ding!
    end
  else
    s.ding = s.ding - dt
    if s.ding <= 0 then finishOrder(c) end
  end
end

-- ---- Evening Chill: dish bin and cup shelf ------------------------------
local function updateDishes(dt)
  local s, cu = G.sink, G.cups
  sfxPlay("sink", true, 0.6)                    -- the tap is already dripping when you open it
  if s.state == "empty" then
    sfxStop("cleaning")
    if cu.dirty > 0 then                          -- (safety) a dirty cup hops straight in
      cu.dirty = cu.dirty - 1
      s.state, s.progress, s.angle = "washing", 0, 0
      UI.sfxDish()
    else                                          -- all clean: the screen closes by itself
      closeStation()
    end
  elseif s.state == "washing" then
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    s.angle = s.angle + change
    s.progress = s.progress + ch / DISH_CRANK
    s.tick = (s.tick or 0) + ch
    if s.tick >= 40 then s.tick = s.tick - 40; sfxTick() end
    if ch > 0.8 then sfxPlay("cleaning", true, 1.0) else sfxStop("cleaning") end
    if s.progress >= 1 then
      s.progress = 1
      s.state, s.t = "sparkle", 0
      cu.hand = cu.hand + 1                 -- the clean cup is in your hand right now
      UI.statAdd("washed", 1)
      sfxStop("cleaning")
      sfxCup()                              -- (just the clink of the clean cup: no beep)
    end
  else
    s.t = s.t + dt
    if s.t >= 0.8 then
      if cu.dirty > 0 then                  -- the next dirty cup hops into the sink
        cu.dirty = cu.dirty - 1
        s.state, s.progress, s.angle = "washing", 0, 0
        UI.sfxDish()
      else
        s.state = "empty"
      end
    end
  end
end

local function updateShelf(dt)
  local cu = G.cups
  if pd.buttonJustPressed(pd.kButtonA) then
    if cu.hand > 0 and cu.shelf < G.cupMax then
      cu.hand = cu.hand - 1
      cu.shelf = cu.shelf + 1
      sfxCup()
      if cu.hand == 0 then closeStation() end            -- that was the last one: step away on its own
    else
      say("You're not holding any cups.")
      sfxWrong()
    end
  end
end

local function updateStation(dt)
  if G.st == "dishes" or G.st == "shelf" then
    -- shelf with nothing left to place: A, B or the d-pad all step away from it
    local anyPad = pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
                or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight)
    if G.st == "shelf" and G.cups.hand == 0 and (anyPad or pd.buttonJustPressed(pd.kButtonA)) then
      closeStation()
      sfxClick()
      return
    end
    if pd.buttonJustPressed(pd.kButtonB) or (G.st == "dishes" and anyPad) then   -- walk away any time
      sfxStop("cleaning")
      closeStation()
      sfxClick()
      return
    end
    if G.st == "dishes" then updateDishes(dt) else updateShelf(dt) end
    return
  end
  local c = G.cust
  if c == nil then closeStation(); return end
  local locked = (G.st == "serve" and c.srv.phase == 3)
  local pouring = (G.st == "coffee" and c.cof.phase == "pour")   -- B = A while pouring
  if pd.buttonJustPressed(pd.kButtonB) and not locked and not pouring then
    sfxStop("receipt")
    closeStation()
    sfxClick()
    return
  end
  if G.st == "register" then updateRegister(c, dt)
  elseif G.st == "coffee" then updateCoffee(c, dt)
  elseif G.st == "mixer" then updateMixer(c, dt)
  elseif G.st == "serve" then updateServe(c, dt) end
end

----------------------------------------------------------------------
-- Updating the shop: arrivals, the line, seating, the door
----------------------------------------------------------------------
-- customers arrive faster during the morning and lunch rushes
local function patienceSecs()
  if G.mode == "cafe" then return (60 + 20 * G.cafe.stars) / (1 - UI.lvlSlowPct(UI.lvl(G.cafe)) / 100) end   -- a minute, plus 20 s per star (a higher barista level: it drains slower)
  if G.mode ~= "rush" then return CHILL_PATIENCE end
  return 20                                  -- Fast Cafe: twenty seconds per customer
end

local function arrivalGap()
  if G.mode == "cafe" then
    return CAFE.gap(24 - 2.6 * G.cafe.stars, 10 - G.cafe.stars)                                -- more stars, more customers
  end
  if G.mode == "chill" then return CAFE.gap(CHILL_ARRIVE_MIN, CHILL_ARRIVE_SPAN) end
  local hourF = G.t / RUSH_SECONDS * 7
  if (hourF >= 1 and hourF < 2.5) or (hourF >= 5 and hourF < 6.5) then
    return 5 + math.random() * 3
  end
  return 7 + math.random() * 4
end

local function updateOthers(dt)
  for i = #G.others, 1, -1 do
    local c = G.others[i]
    moveAlong(c, dt)
    if c.state == "toSeat" and #c.path == 0 then
      c.state = "seated"
      if G.mode ~= "rush" then
        c.stay = CHILL_STAY_MIN + math.random() * (CHILL_STAY_MAX - CHILL_STAY_MIN)
      else
        c.stay = STAY_MIN + math.random() * (STAY_MAX - STAY_MIN)
      end
    elseif c.state == "seated" then
      c.stay = c.stay - dt
      if c.stay <= 0 then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      end
    elseif c.state == "leaving" and #c.path == 0 then
      table.remove(G.others, i)
    end
  end
end

local function anyoneAtDoor()
  local function near(c)
    return #c.path > 0 and math.abs(c.x - DOOR_X) < 40 and c.y > 205
  end
  if G.cust and near(G.cust) then return true end
  for _, c in ipairs(G.line) do if near(c) then return true end end
  for _, c in ipairs(G.others) do if near(c) then return true end end
  return false
end

local function updateCustomers(dt)
  if G.mode ~= "rush" then CAFE.flowUpdate(dt) end
  -- someone new comes in (if the line has room)
  G.arriveIn = G.arriveIn - dt
  if G.arriveIn <= 0 then
    G.arriveIn = arrivalGap()
    local room = #G.line < LINE_MAX
    if room and G.mode == "cafe" and not CAFE.admit(#G.line + (G.cust and 1 or 0) + 1) then
      room = false
      G.arriveIn = 3 + math.random() * 4               -- (the street was quiet: try again in a few seconds)
    end
    if room then
      local c = newCustomer()
      G.busyN = (G.busyN or 0) + 1                          -- (how many have come in this busy spell: see CAFE.flowUpdate)
      G.line[#G.line + 1] = c
      routeTo(c, LINE_SLOTS[#G.line][1], LINE_SLOTS[#G.line][2])
    end
  end

  -- the next person in line steps up to the register
  if G.cust == nil then
    G.stepT = G.stepT - dt
    if G.stepT <= 0 and #G.line > 0 then
      local c = table.remove(G.line, 1)
      c.state = "active"
      G.cust = c
      routeTo(c, REG_X, REG_Y)
      relineup()
    end
  end

  -- people waiting in line slowly lose patience
  for i = #G.line, 1, -1 do
    local c = G.line[i]
    moveAlong(c, dt)
    if #c.path == 0 then
      if G.mode == "cafe" and not CAFE.rich() then c.patience = c.patience - dt / (patienceSecs() * LINE_PATIENCE) end   -- (only the Cafe has people losing patience in line; in Rush Hour and Evening Chill just the person at the counter does)
      if c.patience <= 0 then
        table.remove(G.line, i)
        G.missed = G.missed + 1
        leaveRoute(c)
        G.others[#G.others + 1] = c
        relineup()
        say("Someone gave up waiting!")
      end
    end
  end

  -- the person at the counter
  local c = G.cust
  if c then
    moveAlong(c, dt)
    if c.stage == 0 and #c.path == 0 then
      c.stage = 1
    end
    if c.stage >= 1 then
      if not UI.noWait() then c.patience = c.patience - dt / patienceSecs() end     -- (Evening Chill and the test cafe: nobody runs out of patience)
      if c.patience <= 0 then
        c.patience = 0
        G.missed = G.missed + 1
        G.streak = 0
        say("A customer walked out!")
        if G.mode == "cafe" then CAFE.mistake(0.4); G.cafe.pstreak = 0 end      -- (a walk-out ends a run of perfect orders too)
        sfxWrong()
        if c.hasCup then c.hasCup = false; G.cups.shelf = G.cups.shelf + 1 end   -- the cup goes back
        closeStation()
        G.cust = nil
        G.stepT = 0.6
        leaveRoute(c)
        G.others[#G.others + 1] = c
      end
    end
  end

  updateOthers(dt)

  -- the door swings open when someone is coming or going
  local want = anyoneAtDoor() and 1 or 0
  if want == 1 and G.door == 0 then sfxPlay("door", false, 1.0) end      -- the door chime, each time it opens
  if G.door < want then G.door = math.min(want, G.door + dt * 5)
  elseif G.door > want then G.door = math.max(want, G.door - dt * 5) end
end

local function updateWalking(dt)
  local dir = 0
  if pd.buttonIsPressed(pd.kButtonLeft) then dir = -1
  elseif pd.buttonIsPressed(pd.kButtonRight) then dir = 1 end
  G.moving = (dir ~= 0)
  if G.moving then
    G.px = clamp(G.px + dir * WALK_SPEED * dt, WALK_MIN, WALK_MAX)
    G.walk = G.walk + dt * 14
  end
  -- Up picks the wall shelf, Down picks the counter below (Evening Chill)
  if not nearWall() then
    G.sel = "down"
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    G.sel = "up"
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonDown) then
    G.sel = "down"
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonA) then
    if shelfSelected() then
      G.st = "shelf"
      sfxClick()
    else
      local st = nearStation()
      if st then tryOpen(st) end
    end
  end
end

endDay = function()
  closeStation()
  setShiftMenu(false)
  if G.mode == "cafe" then CAFE.finish(); return end
  G.total = G.cash + G.tips
  if G.mode == "rush" then UI.statAdd("rushes", 1); UI.statMax("rushbest", G.total); UI.achCheck(); UI.metaSave() end
  G.endT = 0
  entry.cur = 1
  entry.crank = 0
  for i = 1, 3 do
    entry.letters[i] = string.byte(lastInitials, i) - 65
    if entry.letters[i] < 0 or entry.letters[i] > 25 then entry.letters[i] = 0 end
  end
  state = STATE_ENTRY
end

-- Evening Chill and the Cafe have no clock: the Menu button has an "End shift" item
-- (and the Cafe adds "Save & quit" under it)
local shiftItem = nil
setShiftMenu = function(on, withSave)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if UI.setTitleItem then UI.setTitleItem(not withSave) end
  local title = withSave and "Go to Shop" or "End shift"      -- (in the Cafe it opens the shop)
  local wantMusic = UI.color or not withSave                 -- (the Playdate's menu holds three things: in the Cafe those are Save & quit, Achievements and Go to Shop)
  local key = tostring(on) .. tostring(withSave) .. tostring(wantMusic)
  if UI.menuKey == key then return end
  UI.menuKey = key
  local function drop(item) if item ~= nil then pcall(function() menu:removeMenuItem(item) end) end end
  local function add(t, fn) local ok, item = pcall(function() return menu:addMenuItem(t, fn) end); return ok and item or nil end
  drop(CAFE.saveItem); CAFE.saveItem = nil
  drop(UI.achItem); UI.achItem = nil
  drop(shiftItem); shiftItem = nil
  if not wantMusic and UI.musicItem then drop(UI.musicItem); UI.musicItem = nil end
  if wantMusic and UI.musicItem == nil and menu.addCheckmarkMenuItem then
    pcall(function() UI.musicItem = menu:addCheckmarkMenuItem("Music", UI.musicOn, function(v) UI.musicOn = v end) end)
  end
  if withSave then CAFE.saveItem = add("Save & quit", function() CAFE.saveQuit() end) end
  if withSave and on then UI.achItem = add("Achievements", function() UI.openAchInGame() end) end
  if on then
    UI.shiftTitle = title
    shiftItem = add(title, function()
      if state == STATE_PLAY and G and G.mode ~= "rush" and not G.ending then
        UI.ach = nil
        G.ending = true
        transitionTo(endDay)
      end
    end)
  end
end

local function updatePlay(dt)
  G.t = G.t + dt
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    if rem <= 1 and not G.alarmed then         -- the classic alarm clock starts a second before time is up, so it is already ringing as the clock hits 0:00
      G.alarmed = true
      sfxPlay("alarm", false, 1.0)
    end
    if rem <= 0 then
      G.t = limit
      if not G.ending then
        G.ending = true
        transitionTo(endDay)
      end
      return
    end
  end
  if G.msgT > 0 then
    G.msgT = G.msgT - dt
    if G.msgT <= 0 then G.msg = nil end
  end
  for i = #G.popups, 1, -1 do
    local p = G.popups[i]
    p.t = p.t + dt
    if p.t >= p.life then table.remove(G.popups, i) end
  end
  WIN.updateWindow(dt)
  if G.mode == "cafe" then UI.playTick(dt) end
  if G.pets then CAFE.updatePets(dt) end
  updateCustomers(dt)
  if G.st then updateStation(dt) else updateWalking(dt) end
end

----------------------------------------------------------------------
-- Drawing: people
----------------------------------------------------------------------
-- look 1..4 = customers, 5 = the barista
UI.LOOKS = { 1, 2, 3, 4, 6, 7, 8, 9, 10 }
UI.BARISTA = { 5, 11, 12 }                     -- the three starting barista models

local function drawPerson(x, y, look, angry, mood)
  if not (UI.color or UI.noCache or UI.noFast or UI.noMouth) and UI.personImg(x, y, look, angry, mood) then return end      -- (Playdate: stamped from a picture)
  UI.personRaw(x, y, look, angry, mood)
end
function UI.personRaw(x, y, look, angry, mood)
  x, y = math.floor(x), math.floor(y)
  -- body
  if look == 5 or look == 11 or look == 12 then              -- the three barista models share the apron
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(WHITE)
    gfx.fillRect(x - 6, y + 10, 12, 12)
    gfx.setColor(BLACK)
    gfx.drawRect(x - 6, y + 10, 12, 12)
  else
    gfx.setColor(BLACK)
    if look == 2 then gfx.setPattern(CHECK) end
    if look == 3 then gfx.setColor(WHITE) end
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 12, y + 7, 24, 15, 6)
    if look == 4 then
      gfx.setColor(WHITE)
      gfx.fillRect(x - 10, y + 13, 20, 2)
    end
  end
  -- head
  if look == 1 or look == 5 or look == 12 then
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y + 3, 7)
  else
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawCircleAtPoint(x, y, 9)
    gfx.setLineWidth(1)
  end
  if look == 6 then          -- long hair
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 10, y - 9, 20, 9, 4)
    gfx.fillRect(x - 10, y - 3, 4, 14)
    gfx.fillRect(x + 6, y - 3, 4, 14)
    gfx.setColor(WHITE); gfx.drawLine(x - 3, y - 5, x + 4, y - 3); gfx.setColor(BLACK)
  elseif look == 5 then      -- the barista with short, spiky hair
    gfx.setColor(BLACK)
    gfx.fillTriangle(x - 8, y - 6, x - 5, y - 11, x - 2, y - 7)
    gfx.fillTriangle(x - 3, y - 7, x, y - 12, x + 3, y - 7)
    gfx.fillTriangle(x + 2, y - 7, x + 5, y - 11, x + 8, y - 6)
    gfx.fillRect(x - 9, y - 4, 2, 7)
    gfx.fillRect(x + 7, y - 4, 2, 7)
  elseif look == 12 then     -- the barista with long hair and a little bow
    gfx.setColor(BLACK)
    gfx.fillRect(x - 11, y - 4, 4, 17)                    -- long hair down both sides, flicked out at the ends
    gfx.fillRect(x + 7, y - 4, 4, 17)
    gfx.fillCircleAtPoint(x - 11, y + 12, 3)
    gfx.fillCircleAtPoint(x + 11, y + 12, 3)
    gfx.fillRect(x - 8, y - 6, 16, 4)                      -- bangs
    gfx.fillTriangle(x - 8, y - 2, x - 2, y - 2, x - 8, y + 2)
    gfx.fillTriangle(x + 8, y - 2, x + 2, y - 2, x + 8, y + 2)
    if not UI.noBow then
      gfx.setColor(WHITE)                               -- a white bow with a black outline, tilted to sit on the hair
      gfx.fillTriangle(x + 6, y - 6, x + 2, y - 10, x + 1, y - 5)
      gfx.fillTriangle(x + 6, y - 6, x + 10, y - 6, x + 8, y - 1)
      gfx.setColor(BLACK)
      gfx.drawLine(x + 6, y - 6, x + 2, y - 10); gfx.drawLine(x + 2, y - 10, x + 1, y - 5); gfx.drawLine(x + 1, y - 5, x + 6, y - 6)
      gfx.drawLine(x + 6, y - 6, x + 10, y - 6); gfx.drawLine(x + 10, y - 6, x + 8, y - 1); gfx.drawLine(x + 8, y - 1, x + 6, y - 6)
      gfx.fillRect(x + 5, y - 7, 2, 2)
    end
  elseif look == 8 then      -- a cap with the brim to one side
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 8, y - 11, 16, 8, 4)
    gfx.fillRect(x - 9, y - 4, 22, 2)
    gfx.setColor(WHITE); gfx.drawPixel(x, y - 10); gfx.setColor(BLACK)
  elseif look == 9 then      -- big curly hair
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x - 6, y - 6, 4); gfx.fillCircleAtPoint(x, y - 9, 4); gfx.fillCircleAtPoint(x + 6, y - 6, 4)
    gfx.fillCircleAtPoint(x - 9, y - 1, 3); gfx.fillCircleAtPoint(x + 9, y - 1, 3)
    gfx.fillRect(x - 7, y - 6, 14, 3)
  elseif look == 10 then     -- ponytail
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 9, y - 10, 18, 8, 4)
    gfx.fillCircleAtPoint(x + 11, y - 3, 3)
    gfx.fillRect(x + 9, y - 6, 3, 4)
  elseif look == 2 then      -- hat
    gfx.setColor(BLACK)
    gfx.fillRect(x - 12, y - 4, 24, 4)
    gfx.fillRect(x - 7, y - 11, 14, 8)
  elseif look == 4 then      -- beanie
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x - 8, y - 11, 16, 9, 4)
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(x - 8, y - 11, 16, 9, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 8, y - 11, 16, 9, 4)            -- an outline, so the shading stays inside its rounded box
    gfx.fillRect(x - 9, y - 4, 18, 2)
  end
  -- face: everything is placed from "e", the top row of the eyes, so it always fits inside the round head
  gfx.setColor(BLACK)
  local gl = (look == 3) or (UI.glasses == true)             -- wearing glasses
  local e = UI.eyeRow(look, gl)
  if gl and look == 3 then CAFE.WEAR.g_round(x, y + e) end   -- (the customer with round glasses)
  gfx.fillRect(x - 4, y + e, 2, 2)                           -- two eyes the same size, the same distance either side of the middle
  gfx.fillRect(x + 3, y + e, 2, 2)
  if look == 12 then         -- lashes
    gfx.drawPixel(x - 5, y + e - 1); gfx.drawPixel(x + 5, y + e - 1)
  end
  mood = mood or (angry and 0 or 2)
  if gl and mood == 3 then mood = 2 end                      -- (no room for the big grin under glasses)
  if UI.noMouth then return end                              -- (a test switch: draw the face without its mouth)
  local m = y + e + 4 + (gl and 2 or 0)                      -- the row the bottom of a smile sits on
  if mood == 0 then                                -- a frown, with cross eyebrows
    if not gl then
      gfx.drawLine(x - 6, y + e - 4, x - 2, y + e - 2)
      gfx.drawLine(x + 6, y + e - 4, x + 2, y + e - 2)
    end
    gfx.drawLine(x - 3, m, x - 2, m - 1)
    gfx.drawLine(x - 2, m - 1, x + 2, m - 1)
    gfx.drawLine(x + 2, m - 1, x + 3, m)
  elseif mood == 1 then                            -- so-so: a small, slightly lopsided mouth
    gfx.drawLine(x - 2, m, x + 1, m)
    gfx.drawLine(x + 1, m, x + 3, m - 1)
  elseif mood == 3 then                            -- delighted: a wide, happy smile
    gfx.drawLine(x - 4, m - 1, x - 3, m)                   -- (the smile, with a little more underneath: an open grin)
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x + 3, m, x + 4, m - 1)
    gfx.drawLine(x - 1, m + 1, x + 1, m + 1)
  else
    gfx.drawLine(x - 4, m - 1, x - 3, m)                   -- a smile as wide as the eyes, the same either side of the middle
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x + 3, m, x + 4, m - 1)
  end
end

-- the row (from the middle of the head) where the top of the eyes sits: bald heads have the most face to spare,
-- dark-haired heads have their face a little lower, and glasses lift the eyes a row to leave room for the mouth
function UI.eyeRow(look, gl)
  local e
  if look == 7 or look == 11 then e = -1; if gl then e = e - 1 end
  elseif look == 1 or look == 5 or look == 12 then e = 2; if gl then e = e - 1 end
  else e = 1; if gl then e = e - 2 end end
  return e
end

-- 3 = delighted, 2 = smiling, 1 = flat, 0 = frowning (patience running out, a bungled order, a walk-out)
function UI.mood(c)
  if c.state == "line" or c.state == "active" then
    local m = (c.patience > 0.6) and 2 or ((c.patience > 0.3) and 1 or 0)
    if c.stage >= 2 then
      if c.q < 0.5 then m = 0
      elseif c.q < 0.8 then m = math.min(m, 1)
      elseif c.q >= 0.97 and c.stage >= 4 and m >= 1 then m = 3 end
    end
    return m
  end
  if c.final then return (c.final >= 0.9 and 3) or (c.final >= 0.7 and 2) or (c.final >= 0.5 and 1) or 0 end
  return (c.patience <= 0) and 0 or 2
end

-- A little bar that shrinks as the customer gets impatient.
-- onDark = true draws it in white so it shows up on a black band.
local function drawPatience(x, y, p, w, onDark)
  if onDark then
    gfx.setColor(WHITE)
    gfx.drawRect(x, y, w, 6)
    gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
    gfx.setColor(BLACK)
    return
  end
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, 6)
  gfx.setColor(BLACK)
  gfx.drawRect(x, y, w, 6)
  gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
end

function UI.heldCup(c, x, y)                       -- served people carry their drink, and the ones sitting down take a sip now and then
  if not c.final then return end
  if not (c.state == "toSeat" or c.state == "seated" or c.state == "leaving") then return end
  local p = 0
  if c.state == "seated" then
    local ph = (frames + c.look * 53 + (c.seat or 0) * 17) % 210
    if ph < 40 then p = math.sin(math.pi * ph / 40) end
  end
  local cx, cy = math.floor(x + 12 - p * 9), math.floor(y + 16 - p * 10)
  local o = c.order
  gfx.setColor(BLACK)
  gfx.drawLine(x + 9, y + 13, cx - 3, cy - 1)                        -- the arm
  if not (UI.color or UI.noCache or UI.noFast) and UI.cupImg(o, cx, cy, p < 0.3) then return end     -- (Playdate: the cup and its steam stamped from pictures)
  UI.cupRaw(o, cx, cy, p < 0.3)
  gfx.setColor(BLACK)
end
function UI.cupRaw(o, cx, cy, steam, ph, shell)        -- the cup in a hand (ph: the steam's step, 0-24, nil = now; shell: no drink in it)
  if o.ice > 0 then                                                  -- a little iced glass with a straw
    gfx.setColor(WHITE); gfx.fillPolygon(cx - 3, cy - 4, cx + 3, cy - 4, cx + 2, cy + 5, cx - 2, cy + 5)
    gfx.setColor(BLACK); gfx.drawPolygon(cx - 3, cy - 4, cx + 3, cy - 4, cx + 2, cy + 5, cx - 2, cy + 5)
    if not shell then gfx.setPattern(DRINK_PATTERN[o.kind or "coffee"]); gfx.fillRect(cx - 2, cy - 1, 5, 5); gfx.setColor(BLACK) end
    gfx.drawLine(cx + 1, cy + 4, cx + 1, cy - 4); gfx.drawLine(cx + 1, cy - 4, cx + 4, cy - 9)
  else                                                               -- a hot cup with a handle
    gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy - 3, 7, 8)
    gfx.setColor(BLACK); gfx.drawRect(cx - 3, cy - 3, 7, 8)
    if not shell then gfx.setPattern(DRINK_PATTERN[o.kind or "coffee"]); gfx.fillRect(cx - 2, cy - 2, 5, 3); gfx.setColor(BLACK) end
    gfx.drawLine(cx + 4, cy - 1, cx + 6, cy - 1); gfx.drawLine(cx + 6, cy - 1, cx + 6, cy + 2); gfx.drawLine(cx + 6, cy + 2, cx + 4, cy + 2)
    if steam then UI.steamRaw(cx, cy, ph) end                        -- squiggly steam
  end
  gfx.setColor(BLACK)
end
function UI.steamRaw(cx, cy, ph)
  local t = ph and (ph * 0.2513274 - cy * 0.8) or (frames * 0.25)     -- (ph: one of 25 steps round the loop, the same for every height)
  for i = 0, 1 do
    local px, py
    for yy = cy - 5, cy - 12, -2 do
      local xx = cx - 1 + i * 3 + math.floor(math.sin(t + yy * 0.8 + i * 2) * 1.4 + 0.5)
      if px then gfx.drawLine(px, py, xx, yy) end
      px, py = xx, yy
    end
  end
end

local function drawCustomer(c, withBar)
  local bob = 0
  if #c.path > 0 then bob = math.floor(math.sin(c.walk) * 1.5 + 0.5) end
  local angry = c.patience < 0.3 and (c.state == "line" or c.state == "active")
  UI.glasses = c.glass ~= nil
  drawPerson(c.x, c.y + bob, c.look, angry, UI.mood(c))
  UI.glasses = false
  if c.hat or c.glass then
    local wx, wy = math.floor(c.x), math.floor(c.y + bob)
    if c.hat then CAFE.drawHat(c.hat, wx, wy, c.look) end
    if c.glass then CAFE.drawGlass(c.glass, wx, wy + UI.eyeRow(c.look, true)) end
    gfx.setColor(BLACK)
  end
  UI.heldCup(c, math.floor(c.x), math.floor(c.y + bob))
  if withBar and c.stage >= 1 and c.stage <= 4 and not UI.noWait() then
    drawPatience(math.floor(c.x) - 16, math.floor(c.y) - 20, c.patience, 32)
  elseif c.state == "line" and G.mode == "cafe" and not CAFE.rich() and #c.path == 0 then      -- people waiting show a little bar beside them (Cafe only)
    drawPatience(math.floor(c.x) + 16, math.floor(c.y) + 2, c.patience, 24)
  end
  if angry and (math.floor(frames / (6))) % 2 == 0 then
    gfx.setColor(BLACK)
    drawT("!", math.floor(c.x) + 12, math.floor(c.y) - 22, true)
  end
end

local function drawBubble(c)
  if not (UI.color or UI.noCache or UI.noFast) then UI.bubbleImg(c); return end      -- (Playdate: drawn into a picture, stamped)
  UI.bubbleRaw(c)
end
function UI.bubbleImg(c)                              -- the order bubble, kept with the customer and drawn again now and then (in case the order changes)
  local b, cx = c.bub, math.floor(c.x)
  if b and b.cx == cx and b.greet == c.greet and frames >= b.at and frames - b.at < 15 then
    if b.img then UI.cacheDraw(b.img, b.x0, b.y0) else UI.bubbleRaw(c) end
    return
  end
  local x0, y0 = ((cx < 200) and (cx + 26) or (cx - 26 - 206)) - 14, 118     -- (room for the widest bubble and its tail)
  if not b or b.cx ~= cx then
    local ok, img = pcall(gfx.image.new, 206 + 28, 8 + 17 * 6 + 8, gfx.kColorClear)
    b = { img = ok and img or false }
    c.bub = b
  end
  b.cx, b.greet, b.at, b.x0, b.y0 = cx, c.greet, frames, x0, y0
  if not b.img then UI.bubbleRaw(c); return end
  b.img:clear(gfx.kColorClear)
  gfx.pushContext(b.img)
  gfx.setDrawOffset(-x0, -y0); gfx.clearClipRect(); gfx.setImageDrawMode(gfx.kDrawModeCopy)
  UI.bubbleRaw(c)
  gfx.popContext()
  UI.cacheDraw(b.img, x0, y0)
end
function UI.bubbleRaw(c)
  local lines = orderLines(c.order)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(c.greet)
  gfx.setFont(fontNormal)
  for _, line in ipairs(lines) do tw = math.max(tw, (gfx.getTextSize(line))) end
  local bw = math.min(206, tw + 28)                      -- hugs the words, with room at the sides
  local bh = 8 + 17 * (1 + #lines)
  local cx = math.floor(c.x)
  local right = cx < 200
  local bx = right and (cx + 26) or (cx - 26 - bw)
  local by = 122
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, by, bw, bh, 8)
  gfx.setLineWidth(1)
  -- little tail pointing at the customer
  local ex = right and bx or (bx + bw)
  local dir = right and -1 or 1
  gfx.setColor(WHITE)
  gfx.fillTriangle(ex, by + 8, ex, by + 22, ex + dir * 10, by + 15)
  gfx.fillRect(ex - 2, by + 9, 4, 12)
  gfx.setColor(BLACK)
  gfx.drawLine(ex, by + 8, ex + dir * 10, by + 15)
  gfx.drawLine(ex + dir * 10, by + 15, ex, by + 22)
  drawTC(c.greet, bx + math.floor(bw / (2)), by + 3, true)
  for i, line in ipairs(lines) do
    drawTC(line, bx + math.floor(bw / (2)), by + 3 + 17 * i)
  end
end

----------------------------------------------------------------------
-- Drawing: the shop
----------------------------------------------------------------------
-- the view out of a window: bx, by = the top-left of the glass on screen, k = how much bigger than the cafe's window
function WIN.sunAt(cx, cy, r, spin)                 -- a sun with little rays that turn
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy, r)
  for i = 0, 7 do
    local a = i * math.pi / 4 + spin
    gfx.drawLine(cx + math.cos(a) * (r + 2), cy + math.sin(a) * (r + 2), cx + math.cos(a) * (r + 4), cy + math.sin(a) * (r + 4))
  end
end

function WIN.moonAt(cx, cy, r)                      -- a crescent
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + math.max(1, math.floor(r / (2)) + 1), cy - 1, r - 1)
  gfx.setColor(BLACK)
end

function WIN.cloudAt(cx, cy, k, big)              -- a puffy cloud that covers whatever is behind it
  local b = big and 1 or 0
  local function blob(ex, fill)
    gfx.setColor(fill)
    gfx.fillCircleAtPoint(cx - 5 * k, cy + k, 3 * k + ex)
    gfx.fillCircleAtPoint(cx, cy - k, (4 + b) * k + ex)
    gfx.fillCircleAtPoint(cx + 5 * k, cy + k, 3 * k + ex)
    gfx.fillRect(cx - 8 * k - ex, cy + k - ex, 16 * k + 2 * ex, 3 * k + 2 * ex)
  end
  blob(1, BLACK); blob(0, WHITE)
  gfx.setColor(BLACK)
end

function WIN.drawView(w, bx, by, k, noPeople)
  local function X(x) return math.floor(bx + (x - 15) * k) end
  local function Y(y) return math.floor(by + (y - 23) * k) end
  local function L(x0, y0, x1, y1) gfx.drawLine(X(x0), Y(y0), X(x1), Y(y1)) end
  gfx.setClipRect(bx + 1, by + 1, 52 * k - 2, 24 * k - 2)
  local na = WIN.nightAmt(w)
  local night = na > 0.5
  if UI.color then                                  -- (PC: the colour of the sky, fading between day and night)
    UI.skyBlend(na, w.fx.rain or w.fx.clouds)
    UI.ink("dyn_sky")
    gfx.setColor(WHITE); gfx.fillRect(bx + 1, by + 1, 52 * k - 2, 24 * k - 2)
    if na > 0.05 then                               -- stars, twinkling (they fade in with the dark)
      UI.ink("dyn_star"); gfx.setColor(BLACK)
      for i, st in ipairs(WIN.STARS) do
        if (math.floor(frames / (14)) + i) % 5 ~= 0 then gfx.fillRect(X(st[1]), Y(st[2]), k, k) end
      end
    end
  end
  gfx.setColor(BLACK)
  gfx.setLineWidth(k)
  if w.sky then
    local p = w.sky.t / w.sky.dur
    local sx = X(8 + p * 66)
    local sy = Y(41 - math.sin(math.pi * p) * 15)
    if w.sky.kind == "sun" and (w.fx.rain or w.fx.snow) then
      -- no sun while it rains or snows (Christmas days are just snow and clouds)
    elseif w.sky.kind == "sun" then UI.ink("yellow"); WIN.sunAt(sx, sy, 3 * k, (w.sky.t * 0.4) % 6.28)
    else UI.ink("dyn_moon"); WIN.moonAt(sx, sy, 4 * k) end
    gfx.setColor(BLACK)
  end
  UI.ink("dyn_cloud")
  for _, q in ipairs(w.parts) do                    -- clouds drift in front of the sun and moon
    if q.k == "cloud" then WIN.cloudAt(X(math.floor(q.x)), Y(math.floor(q.y)), k, q.s == 1) end
  end
  gfx.setColor(BLACK)
  UI.ink("dyn_walk")
  for _, q in ipairs(noPeople and {} or w.walkers) do   -- a person walking by (not on the door screens)
    local x = math.floor(q.x)
    local step = math.floor(math.sin(q.t) * 2)
    gfx.fillCircleAtPoint(X(x), Y(34), 3 * k)
    gfx.fillRoundRect(X(x - 4), Y(37), 8 * k, 8 * k, 2 * k)
    L(x - 1, 45, x - 1 + step, 49)
    L(x + 1, 45, x + 1 - step, 49)
    if q.umbrella then
      UI.inkPush("inkred")
      gfx.fillTriangle(X(x - 8), Y(31), X(x + 8), Y(31), X(x), Y(24))
      UI.inkPop()
    end
  end
  for _, q in ipairs(w.parts) do
    local x, y = math.floor(q.x), math.floor(q.y)
    if q.k == "cloud" then
      -- (drawn above, behind the people)
    elseif q.k == "rain" then
      UI.ink("dyn_rain")
      L(x, y, x - (q.vx > 0 and -2 or 1), y + 3)
    elseif q.k == "snow" then                       -- a soft flake
      UI.ink("inkwhite")
      local fx, fy = X(x), Y(y)
      if fx >= bx + 3 and fx + 2 * k <= bx + 52 * k - 3 and fy >= by + 3 and fy + 2 * k <= by + 24 * k - 3 then
        gfx.fillRect(fx, fy, 2 * k, 2 * k)
        if (math.floor(q.ph * 2) % 2) == 0 then gfx.drawPixel(fx - 1, fy); gfx.drawPixel(fx + 2 * k, fy + 1) end
      end
    elseif q.k == "wind" then                       -- a lazy, squiggly gust
      UI.ink(night and "dyn_rain" or "inkwhite")
      local px, py = x, y + math.floor(math.sin(q.ph) * 2.5)
      for j = 1, 7 do
        local nx = x - j * 3
        local ny = y + math.floor(math.sin(q.ph - j * 0.9) * 2.5)
        L(px, py, nx, ny)
        px, py = nx, ny
      end
      L(px, py, px - 2, py - 2)                     -- the curl at the tail
    else
      UI.ink(((x + y) % 3 == 0) and "inkred" or "inkorange")
      gfx.fillEllipseInRect(X(x), Y(y), 5 * k, 3 * k)             -- a falling leaf
      L(x - 1, y + 3, x + 1, y + 1)
    end
  end
  gfx.setLineWidth(1)
  gfx.clearClipRect()
  gfx.setColor(BLACK)
end

function WIN.drawWindowView() WIN.drawView(G.win, 33, 23, 1) end
WIN.STARS = { { 12, 26 }, { 20, 31 }, { 31, 25 }, { 40, 29 }, { 49, 24 }, { 58, 30 }, { 66, 26 }, { 26, 36 }, { 53, 36 }, { 63, 34 } }

-- The still parts of the wall are drawn once into a picture (CAFE.sceneTop); this is only what moves.
function CAFE.wallStatic()
  CAFE.wallFill(CAFE.ownedOf("wallpaper"), 0, 18, 400, 53)   -- (the wall comes all the way down to its edge on the counter: no floor peeks through)
  UI.ink("wallpaper")
  gfx.setColor(BLACK)
  gfx.fillRect(0, 71, 400, 3)

  -- opening hours sign (in the Cafe it shows your cafe's name, and can be taken down)
  if G.mode ~= "cafe" or G.cafe.sign ~= false then      -- (the sign)
    gfx.setColor(WHITE)
    gfx.fillRect(272, 22, 90, 26)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(272, 22, 90, 26)
    gfx.setLineWidth(1)
    if G.mode == "cafe" then
      CAFE.fitText(CAFE.cafeName(), 317, 35, 80, 18, 84)          -- (a full 13-letter name fits, and so does a 14-letter one from an older save)
    else
      CAFE.fitText(G.mode == "chill" and "CHILL CAFE" or "FAST CAFE", 317, 35, 80, 18)
    end
  end
  if CAFE.dec() then CAFE.wallItemsRaw(false) end

  if G.mode ~= "cafe" or G.cafe.mugSign ~= false then CAFE.mugPic(366, 21) end    -- framed picture of the coffee mug from the title screen (in the Cafe it can be taken down)
end
function CAFE.mugPic(fx, fy)
  gfx.setColor(WHITE)
  gfx.fillRect(fx, fy, 30, 28)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(fx, fy, 30, 28)
  gfx.drawCircleAtPoint(fx + 22, fy + 16, 3)               -- handle
  gfx.setColor(WHITE)
  gfx.fillRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(fx + 8, fy + 12, 11, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(fx + 3, fy + 23, 22, 2)                      -- saucer
  gfx.drawLine(fx + 10, fy + 8, fx + 12, fy + 5)            -- steam
  gfx.drawLine(fx + 12, fy + 5, fx + 10, fy + 3)
  gfx.drawLine(fx + 16, fy + 8, fx + 18, fy + 5)
  gfx.drawLine(fx + 18, fy + 5, fx + 16, fy + 3)
  gfx.setColor(BLACK)
end

local function drawWall()
  -- window
  CAFE.drawWindowNow()

  -- shelf with cups (in Evening Chill these are the shop's real clean cups)
  do
    if shelfSelected() then
      local pad = ((math.floor(frames / (10))) % 2 == 0) and 0 or 3
      gfx.setColor(WHITE)
      gfx.fillRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setLineWidth(1)
    end
    gfx.setColor(BLACK)
    gfx.fillRect(102, 40, 92, 3)
    local two = G.cupMax > 5                      -- past 5 cups the shelf gets a second row behind the first
    local step = two and 17 or math.min(17, math.floor(88 / (math.max(1, G.cupMax))))
    for pass = 0, 1 do                            -- (the back row first, so the front row covers it)
      for i = 0, G.cupMax - 1 do
        local back = two and i >= 5
        if i < G.cups.shelf and ((pass == 0) == back) then
          local cx = 106 + (back and (i - 5) * step + 8 or i * step)
          local cy = back and 28 or 30
          UI.inkPush("mugc")
          gfx.setColor(WHITE)
          gfx.fillRect(cx, cy, 10, 10)
          gfx.setColor(BLACK)
          gfx.drawRect(cx, cy, 10, 10)
          gfx.fillRect(cx + 11, cy + 3, 2, 4)
          UI.inkPop()
        end
      end
    end
  end

  if UI.inPlay and not (UI.color or UI.noFast) then CAFE.drawLiveList(CAFE.liveLists().wall)        -- the clocks and signs that move
  elseif CAFE.dec() then CAFE.wallItemsRaw(true) end
  CAFE.drawVines()                                          -- hanging things go over everything below them
  CAFE.drawDangles()
  CAFE.drawLights()                                         -- the string of lights is over everything on the wall
end

function CAFE.counterStatic()
  gfx.setColor(WHITE)
  gfx.fillRect(0, 74, 400, 22)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 74, 400, 2)
  UI.ink("chrome")                                         -- (PC: the counter's front is black; its top keeps its colour)
  gfx.fillRect(0, 96, 400, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)             -- the station names (the one you stand at gets a bubble over its name; PC: white on the black front)
  gfx.setFont(fontNormal)
  for _, st in ipairs(STATIONS) do drawTC(st.label, st.x, 97) end
  drawTC("TIPS", JAR_X - 3, 97)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  UI.ink("counter")

  -- the machines stand a little way up from the front edge, each with a soft shadow on the counter
  local function stand(key, cx)
    CAFE.stamp(key, cx, 92)
    local w = CAFE.spr(key):getSize()
    gfx.setColor(BLACK)
    for px = cx - math.floor(w / (2)) + 2, cx - math.floor(w / (2)) + w - 3 do
      if (px + 93) % 2 == 0 then gfx.drawPixel(px, 93) end
    end
  end
  stand("m_register", stationById("register").x)        -- the till: customer screen, keys, drawer
  stand("m_coffee", stationById("coffee").x)            -- the espresso machine
  stand("m_mixer", stationById("mixer").x - 1)          -- the drinks blender (a pixel left, so the gaps either side are even)
  stand("m_pickup", stationById("serve").x + 1)         -- the pick-up mat and bell: empty until a cup slides on (a pixel right, so the gaps either side are even)
  local dishSt = stationById("dishes")
  if dishSt then stand("m_sink", dishSt.x) end          -- the sink, with a dotted spot for every cup it can show
  stand("m_jar", JAR_X + 1)                             -- the tip jar (the coins are added live)

  gfx.setColor(BLACK)
end

-- the till's customer screen on the counter: the most recent sale in 3x5 pixel digits, centred in the screen's 15 pixels
function UI.tillDigits(x0, y, cents)               -- (PD: the till's little figures, stamped from a cache)
  if UI.color then return UI.tillDigitsRaw(x0, y, cents) end
  local im = UI.cacheImg("till", cents, 0, 32, 6, function() UI.tillDigitsRaw(8, 0, cents) end)
  if im then UI.cacheDraw(im, x0 - 8, y) else UI.tillDigitsRaw(x0, y, cents) end
end
function UI.tillDigitsRaw(x0, y, cents)
  local str = string.format("%d.%02d", math.floor(cents / (100)), cents % 100)
  local function advance(k, gap)                                        -- how far to move on after glyph k
    local ch, nx = str:sub(k, k), str:sub(k + 1, k + 1)
    local w = (ch == ".") and 1 or 3
    if k < #str then w = w + ((ch == "." or nx == ".") and gap or 1) end
    return w
  end
  local function total(gap) local w = 0; for k = 1, #str do w = w + advance(k, gap) end return w end
  local gap = (total(1) > 15) and 0 or 1                                -- ($10 and up: no air round the dot, so it still fits)
  local x = x0 + math.floor((15 - total(gap)) / (2))
  gfx.setColor(BLACK)
  for k = 1, #str do
    local ch = str:sub(k, k)
    if ch == "." then
      gfx.drawPixel(x, y + 4)
    else
      local g = UI.DIG[ch]
      for gy = 1, 5 do
        local row = g[gy]
        for gx = 1, 3 do
          if row:sub(gx, gx) == "#" then gfx.drawPixel(x + gx - 1, y + gy - 1) end
        end
      end
    end
    x = x + advance(k, gap)
  end
end

CAFE.MUGS = { { 1, 7 }, { 11, 7 }, { 21, 7 }, { 1, 13 }, { 11, 13 }, { 21, 13 }, }     -- where the sink's mugs sit (back row first)

local function drawCounter()
  if UI.inPlay and not (UI.color or UI.noFast) then CAFE.drawLiveList(CAFE.liveLists().ctr, true)  -- the lamps glow and the plants sway, so these are drawn live
  elseif CAFE.dec() then CAFE.counterRaw() end

  -- the station you're standing at gets a white bubble that pulses
  local near = (not shelfSelected()) and nearStation() or nil
  if near then
    gfx.setFont(fontNormal)
    local tw = gfx.getTextSize(near.label)
    local pad = ((math.floor(frames / (10))) % 2 == 0) and 0 or 2
    local bw = tw + 12
    gfx.setColor(BLACK)
    gfx.fillRect(near.x - math.floor(bw / (2)) - 3, 96, bw + 6, 18)       -- (wipe the still name first)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(near.x - math.floor(bw / (2)) - pad, 98, bw + pad * 2, 14, 5)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawTC(near.label, near.x, 97)
    gfx.setColor(BLACK)
  end

  -- the sink: one mug for every dirty cup, up to six (the dotted spots are already in the picture)
  local dishSt = stationById("dishes")
  if dishSt then
    local mug = CAFE.spr("m_mug")
    local sx = dishSt.x - 15
    local sy = 93 - 21
    local mid = G.sink and (G.sink.state == "washing")                         -- a cup left half scrubbed stays in the sink (first spot), soapy
    local n = math.min(G.cups.dirty + (mid and 1 or 0), 6)
    for i = 1, n do
      local m = CAFE.MUGS[i]
      mug:draw(sx + m[1], sy + m[2])
      if mid and i == 1 then
        local bx, by = sx + m[1], sy + m[2]
        UI.ink("snow")
        local b = (math.floor(frames / (12))) % 2
        gfx.setColor(WHITE); gfx.fillCircleAtPoint(bx + 3, by - 1 - b, 2); gfx.fillCircleAtPoint(bx + 7, by - 2, 1); gfx.fillCircleAtPoint(bx + 5, by - 4 + b, 1)
        gfx.setColor(BLACK); gfx.drawCircleAtPoint(bx + 3, by - 1 - b, 2)
        UI.ink("none")
      end
    end
  end

  UI.tillDigits(stationById("register").x - 15 + 3, 72 + 2, G.lastSale or 0)       -- the till's screen: the most recent sale

  -- the tip jar: coins pile up as you earn tips
  local coins = math.min(12, math.floor(G.tips / (((G.mode == "cafe") and 1200 or 400))))       -- (fills up slowly)
  if coins > 0 then
    local coin = CAFE.spr("m_coin")
    local jx, jy = JAR_X + 1 - 10, 93 - 27
    for i = 0, coins - 1 do
      local row, col = math.floor(i / (3)), i % 3
      coin:draw(jx + 3 + col * 4 + ((row % 2 == 1) and 2 or 0), jy + 22 - row * 3)
    end
  end
  gfx.setColor(BLACK)
end

-- the seats' fabric in use (nil: the classic teal cushions on wooden chairs). CAFE.fabForce: the shop's picture of one
function CAFE.fabric()
  local id
  if CAFE.fabForce ~= nil then id = CAFE.fabForce or nil else id = CAFE.ownedOf("seating") end
  return id and CAFE.STDATA[id]
end
CAFE.SHADE = { l = { 0x55, 0xFF, 0x55, 0xFF, 0x55, 0xFF, 0x55, 0xFF }, d = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 },
               k = { 0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00 } }
-- one cushion in a fabric: its base, its pattern (round the cushion's middle, so it mirrors), then a seam in the frame's colour
function CAFE.cushionAt(fab, x, y, w, h, r)
  local pat = fab.pat
  local dark = (pat == "royal" or pat == "stars")
  UI.ink(fab.row)
  gfx.setColor(dark and BLACK or WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  local inner = function(px, py)                  -- (inside the seam, clear of the rounded corners)
    local ax, ay = math.min(px - x, x + w - 1 - px), math.min(py - y, y + h - 1 - py)
    if ax < 2 or ay < 2 then return false end
    if ax < r and ay < r then local dx, dy = r - ax, r - ay; return dx * dx + dy * dy <= (r - 1.5) * (r - 1.5) end
    return true
  end
  local cx, cy = x + math.floor((w - 1) / 2), y + math.floor((h - 1) / 2)
  if pat == "plain" then
    local sh = fab.shade or "w"
    local light = not (sh == "b" or sh == "k")
    if not UI.color and sh ~= "w" then                               -- (Playdate: the colour as a shade)
      if sh == "b" then gfx.setColor(BLACK) else gfx.setPattern(CAFE.SHADE[sh]) end
      gfx.fillRoundRect(x, y, w, h, r)
    end
    local det = fab.detail
    gfx.setColor((UI.color or light) and BLACK or WHITE)
    if det == "piping" then gfx.drawRoundRect(x + 2, y + 2, w - 4, h - 4, math.max(1, r - 2))
    elseif det == "tuft" then                                        -- buttons in a grid round the middle, with stitches between
      CAFE.symGrid(x + 2, y + 2, w - 4, h - 4, 5, 5, 1, 1, true, function(bx, by) gfx.drawPixel(bx, by) end)
    elseif det == "shine" then                                       -- a glint on the vinyl
      if UI.color then UI.ink("snow"); gfx.setColor(WHITE) else gfx.setColor(WHITE) end
      gfx.drawLine(x + 2, y + 4, x + 2, y + math.min(h - 4, 8)); gfx.drawPixel(x + 3, y + 3)
    else gfx.drawPixel(cx, cy) end
  elseif pat == "floral" or pat == "matcha" then
    CAFE.motifFill(pat, x + 1, y + 1, w - 2, h - 2, function(px, py) return inner(px, py) end, pat == "matcha" and w >= 15 and h >= 15)
  elseif pat == "royal" then                                         -- deep velvet, a gold cord round it, a gold diamond in the middle
    gfx.setColor(WHITE)
    gfx.drawRoundRect(x + 2, y + 2, w - 4, h - 4, math.max(1, r - 2))
    local q = math.max(2, math.floor(math.min(w, h) / 2) - 4)
    CAFE.diamondAt(cx, cy, q, q + 1, 1)
  else
    gfx.setColor(dark and WHITE or BLACK)
    CAFE.patArea(pat, x + 2, y + 2, w - 4, h - 4, pat == "stars" and w >= 15 and h >= 15, inner)
  end
  UI.ink(fab.frame)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(x, y, w, h, r)
end

-- a chair seen from above: a wooden back on the side away from the table, and a cushioned seat
-- back = "l" / "r" (the back is on that side) or "u" (the back is on top)
function CAFE.chairAt(x, y, back)
  local fab = CAFE.fabric()
  if fab then return CAFE.chairFab(fab, x, y, back) end
  UI.ink("chairwood")
  gfx.setColor(BLACK)
  if back == "u" then gfx.fillRoundRect(x - 9, y - 7, 18, 4, 2)
  elseif back == "l" then gfx.fillRoundRect(x - 7, y - 9, 4, 18, 2)
  else gfx.fillRoundRect(x + 3, y - 9, 4, 18, 2) end
  local sx, sy, sw, sh = x - 4, y - 7, 11, 14                   -- the seat
  if back == "r" then sx = x - 6 elseif back == "u" then sx, sy, sw, sh = x - 7, y - 4, 14, 11 end
  UI.ink("cushion")
  gfx.setColor(WHITE); gfx.fillRoundRect(sx, sy, sw, sh, 3)
  gfx.setColor(BLACK); gfx.drawRoundRect(sx, sy, sw, sh, 3)
  if not UI.color then                                       -- (1-bit: a stitched cushion in the middle of the seat)
    gfx.setPattern(CHECK); gfx.fillRoundRect(sx + 2, sy + 2, sw - 4, sh - 4, 2); gfx.setColor(BLACK)
  else
    gfx.drawPixel(sx + math.floor(sw / 2), sy + math.floor(sh / 2))     -- (a button in the cushion)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.chairFab(fab, x, y, back)           -- a chair in the chosen fabric: its back in the frame colour, the seat in the fabric
  UI.ink(fab.frame)
  gfx.setColor(BLACK)
  if back == "u" then gfx.fillRoundRect(x - 9, y - 7, 18, 4, 2)
  elseif back == "l" then gfx.fillRoundRect(x - 7, y - 9, 4, 18, 2)
  else gfx.fillRoundRect(x + 3, y - 9, 4, 18, 2) end
  local sx, sy, sw, sh = x - 4, y - 7, 11, 14
  if back == "r" then sx = x - 6 elseif back == "u" then sx, sy, sw, sh = x - 7, y - 4, 14, 11 end
  CAFE.cushionAt(fab, sx, sy, sw, sh, 3)
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- the corner couch: a back along both walls, an arm at each end, and a cushion for every seat
function CAFE.couch()
  local fab = CAFE.fabric()
  if fab then return CAFE.couchFab(fab) end
  UI.ink("couch")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(388, 149, 11, 86, 4)                      -- the back up the right wall...
  gfx.fillRoundRect(316, 224, 83, 11, 4)                      -- ...and along the bottom
  gfx.fillRoundRect(368, 149, 31, 8, 4)                       -- the arm at the top end
  gfx.fillRoundRect(314, 203, 7, 32, 3)                       -- the arm at the left end
  local function cushion(x, y, w, h)                          -- (odd sizes, so the tufted button sits exactly in the middle)
    gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 4)
    gfx.setColor(BLACK); gfx.drawRoundRect(x, y, w, h, 4)
    gfx.drawPixel(x + math.floor(w / 2), y + math.floor(h / 2))
  end
  gfx.setColor(BLACK); gfx.fillRect(368, 156, 21, 69); gfx.fillRect(320, 204, 49, 21)   -- (the seat under the cushions: no floor shows in the gaps between them)
  cushion(368, 156, 21, 25)                                   -- two cushions up the wall, all the same size...
  cushion(368, 180, 21, 25)
  cushion(368, 204, 21, 21)                                   -- ...a square one in the corner...
  cushion(344, 204, 25, 21)                                   -- ...and two along the bottom, the same size as the ones up the wall
  cushion(320, 204, 25, 21)
  UI.ink("none")
  gfx.setColor(BLACK)
end
function CAFE.couchFab(fab)                             -- the corner couch in the chosen fabric (the frame in its colour)
  UI.ink(fab.frame)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(388, 149, 11, 86, 4)
  gfx.fillRoundRect(316, 224, 83, 11, 4)
  gfx.fillRoundRect(368, 149, 31, 8, 4)
  gfx.fillRoundRect(314, 203, 7, 32, 3)
  gfx.fillRect(368, 156, 21, 69); gfx.fillRect(320, 204, 49, 21)
  CAFE.cushionAt(fab, 368, 156, 21, 25, 4)
  CAFE.cushionAt(fab, 368, 180, 21, 25, 4)
  CAFE.cushionAt(fab, 368, 204, 21, 21, 4)
  CAFE.cushionAt(fab, 344, 204, 25, 21, 4)
  CAFE.cushionAt(fab, 320, 204, 25, 21, 4)
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- tables, chairs, and the corner nook
local function drawFloorStatic()
  local lim = G.seatLimit
  CAFE.floorFill(CAFE.ownedOf("flooring"), 0, 114, 400, 126)
  CAFE.drawRunner()
  CAFE.drawRug()
  CAFE.drawOval()
  if lim >= 9 then CAFE.couch() end                     -- the corner nook: an L-shaped couch up the right wall and along the bottom

  -- chairs
  for i, s in ipairs(SEATS) do
    if i <= lim and not (G.seatOff and G.seatOff[i]) then
      if s.t <= 4 then CAFE.chairAt(s.x, s.y, (s.x < TABLES[s.t].x) and "l" or "r")
      elseif s.back then CAFE.chairAt(s.x, s.y, s.back) end
    end
  end

  -- round tables
  local firstSeat = { 1, 3, 5, 7, 9 }
  for ti, t in ipairs(TABLES) do
    if firstSeat[ti] <= lim and not (G.seatOff and G.seatOff[firstSeat[ti]]) then
      CAFE.tableAt(t.x, t.y, t.r, CAFE.ownedOf("cloth"))
    end
  end

  CAFE.drawFloorItems(false)
  gfx.setColor(BLACK)
end

-- the floor (rugs, chairs, tables, plants) never changes during a shift, so it is drawn once into a
-- picture and stamped on every frame: far fewer drawing calls
local function drawFloor()
  -- the things that move stay live: swaying plants, the blinking tree, candle flames
  if UI.inPlay and not (UI.color or UI.noFast) then CAFE.drawLiveList(CAFE.liveLists().floor) else CAFE.drawFloorItems(true) end
  CAFE.tableTopRaw()                                        -- lamps, candles and plants standing on the tables
  -- a coffee cup in front of everyone who is sitting down
  for i, s in ipairs(SEATS) do
    if G.seats[i] and G.seats[i].state == "seated" then
      local t = TABLES[s.t]
      UI.cupDot(math.floor(t.x + (s.x - t.x) * 0.45), math.floor(t.y + (s.y - t.y) * 0.45))
    end
  end
  gfx.setColor(BLACK)
end

-- Everything that never moves (the wall, the counter, the floor) is drawn once into two pictures and stamped on
-- every frame, so each frame has a few hundred fewer drawing calls. The barista is drawn between the two pictures.
function CAFE.scenePic(key, y0, h, drawfn, white)
  local st = G.scn
  if not st then st = {}; G.scn = st end
  local im = st[key]
  if im == nil then
    st[key] = false
    local ok, img = pcall(function() return gfx.image.new(400, h, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      if white then UI.ink((key == "bottom") and "floor" or "none"); gfx.setColor(WHITE); gfx.fillRect(0, white, 400, h - white); UI.ink("none") end    -- (PC: the floor is a soft beige)
      gfx.setDrawOffset(0, -y0)
      drawfn()
      gfx.setDrawOffset(0, 0)
      gfx.setColor(BLACK)
      gfx.popContext()
      im = img
    else
      im = false
    end
    st[key] = im
  end
  return im
end
function CAFE.wallPic() gfx.setColor(WHITE); gfx.fillRect(0, 0, 400, 74); CAFE.wallStatic() end
function CAFE.floorPic() CAFE.counterStatic(); drawFloorStatic() end
function CAFE.sceneTop()
  local im = CAFE.scenePic("top", 0, 74, CAFE.wallPic)
  if im then im:draw(0, 0) else CAFE.wallPic() end
  drawWall()
end
function CAFE.sceneBottom()
  local im = CAFE.scenePic("bottom", 72, 168, CAFE.floorPic, 2)
  if im then im:draw(0, 72) else CAFE.floorPic() end
  drawCounter()
  drawFloor()
end

-- the front door, bottom left: a line that swings open and shut (seen from above)
function UI.drawDoor()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 238, 12, 2)
  gfx.fillRect(46, 238, 354, 2)
  gfx.fillRect(10, 235, 4, 5)
  local a = math.rad(G.door * 90)
  local ex = 14 + math.floor(32 * math.cos(a) + 0.5)
  local ey = 238 - math.floor(32 * math.sin(a) + 0.5)
  gfx.setLineWidth(3)
  gfx.drawLine(14, 238, ex, ey)
  gfx.setLineWidth(1)
end

-- ---- clothes for the barista: hats and glasses (x, y = the middle of the head) --------------------------
CAFE.WEAR = {}
CAFE.WEARIDS = {}
CAFE.WEARCOL = { h_cap = "inkred", h_top = "pcat", h_beanie = "gingham", h_cowboy = "cowboy", h_chef = "white", h_crown = "inkgold",
                 h_party = "inkpink", h_beret = "inkpurple", h_santa = "inkred", h_wizard = "gingham", h_bow = "inkpink", h_flower = "inkgreen",
                 h_witch = "inkpurple", g_round = "brass", g_square = "inkblue", g_shades = "fur", g_heart = "inkpink", g_cat = "inkpurple",
                 g_nerd = "choc", g_monocle = "inkgold", g_3d = "inkred",
                 g_star = "inkgold", h_prop = "inkred", h_viking = "slate", h_halo = "inkgold", h_wreath = "inkpink", h_pirate = "pcat",
                 h_frog = "inkgreen", h_bunny = "white", h_bucket = "tan" }          -- (PC: the main colour of each piece; some paint their trims too)
function CAFE.defWear(id, fn)
  CAFE.WEAR[id] = function(x, y) UI.inkPush(CAFE.WEARCOL[id]); fn(x, y); UI.inkPop() end
  CAFE.WEARIDS[#CAFE.WEARIDS + 1] = id
end
CAFE.defWear("h_cap", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 8, y - 12, 16, 9, 4); gfx.fillRect(x - 9, y - 5, 22, 3)
  gfx.setColor(WHITE); gfx.drawPixel(x, y - 11); gfx.drawLine(x - 6, y - 7, x + 6, y - 7); gfx.setColor(BLACK)
end)
CAFE.defWear("h_top", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 6, y - 19, 12, 14); gfx.fillRect(x - 11, y - 7, 22, 3)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 11, 12, 2); gfx.setColor(BLACK)
end)
CAFE.defWear("h_beanie", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 9, y - 14, 18, 9, 5); gfx.fillCircleAtPoint(x, y - 16, 3)
  gfx.setColor(WHITE); gfx.fillRect(x - 10, y - 8, 20, 5); gfx.setColor(BLACK); gfx.drawRect(x - 10, y - 8, 20, 5)    -- a wide folded cuff that covers the top of the head
  for i = -8, 8, 3 do gfx.drawLine(x + i, y - 8, x + i, y - 4) end
end)
CAFE.defWear("h_cowboy", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 14, y - 8, 28, 4, 2); gfx.fillRoundRect(x - 6, y - 16, 12, 10, 3)
  gfx.fillTriangle(x - 14, y - 8, x - 10, y - 8, x - 14, y - 11); gfx.fillTriangle(x + 14, y - 8, x + 10, y - 8, x + 14, y - 11)
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 9, 12, 1); gfx.setColor(BLACK)
end)
CAFE.defWear("h_chef", function(x, y)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(x - 5, y - 13, 6); gfx.fillCircleAtPoint(x + 5, y - 13, 6); gfx.fillCircleAtPoint(x, y - 16, 6)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x - 5, y - 13, 5); gfx.fillCircleAtPoint(x + 5, y - 13, 5); gfx.fillCircleAtPoint(x, y - 16, 5)
  gfx.fillRect(x - 9, y - 10, 18, 7); gfx.setColor(BLACK); gfx.drawRect(x - 9, y - 10, 18, 7)
  gfx.setColor(WHITE); gfx.fillRect(x - 8, y - 11, 16, 2); gfx.setColor(BLACK)
end)
CAFE.defWear("h_crown", function(x, y)
  gfx.setColor(BLACK); gfx.fillPolygon(x - 9, y - 5, x - 9, y - 16, x - 4, y - 10, x, y - 17, x + 4, y - 10, x + 9, y - 16, x + 9, y - 5)
  gfx.setColor(WHITE); gfx.drawLine(x - 8, y - 6, x + 8, y - 6)
  UI.ink("redp"); gfx.drawPixel(x, y - 12); gfx.drawPixel(x - 6, y - 8); gfx.drawPixel(x + 6, y - 8); gfx.setColor(BLACK)        -- (PC: red jewels)
end)
CAFE.defWear("h_party", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 4, x + 8, y - 4, x, y - 21)
  gfx.setColor(WHITE); gfx.drawLine(x - 4, y - 9, x + 3, y - 12); gfx.drawLine(x - 3, y - 14, x + 2, y - 16)
  UI.ink("yellow")
  gfx.fillCircleAtPoint(x, y - 21, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, y - 21, 2)
end)
CAFE.defWear("h_beret", function(x, y)
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x - 11, y - 14, 22, 10); gfx.fillRect(x - 9, y - 7, 18, 3); gfx.fillRect(x - 1, y - 16, 3, 3)
  gfx.setColor(WHITE); gfx.drawLine(x - 7, y - 9, x - 3, y - 11); gfx.setColor(BLACK)
end)
CAFE.defWear("h_santa", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 9, y - 5, x + 9, y - 5, x + 6, y - 17)
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillRect(x - 10, y - 7, 20, 4); gfx.setColor(BLACK); gfx.drawRect(x - 10, y - 7, 20, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + 6, y - 17, 3); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + 6, y - 17, 3)
end)
CAFE.defWear("h_wizard", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 5, x + 8, y - 5, x + 2, y - 22); gfx.fillRect(x - 12, y - 6, 24, 3)
  UI.ink("yellow")
  gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - 11); gfx.drawPixel(x + 3, y - 15); gfx.drawPixel(x - 3, y - 7); gfx.setColor(BLACK)
end)
CAFE.defWear("h_bow", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 14, x - 8, y - 6, x, y - 10); gfx.fillTriangle(x + 8, y - 14, x + 8, y - 6, x, y - 10)
  gfx.fillCircleAtPoint(x, y - 10, 2)
end)
CAFE.defWear("h_flower", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 9, y - 6, 18, 2)
  UI.ink("inkpink")
  for i = 0, 4 do
    local a = i * 1.2566
    gfx.fillCircleAtPoint(x + 5 + math.floor(math.cos(a) * 3 + 0.5), y - 9 + math.floor(math.sin(a) * 3 + 0.5), 2)
  end
  UI.ink("yellow")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + 5, y - 9, 1); gfx.setColor(BLACK)
end)
CAFE.defWear("h_witch", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 12, y - 7, 24, 3)
  gfx.fillTriangle(x - 7, y - 6, x + 7, y - 6, x + 2, y - 19)
  gfx.fillTriangle(x + 2, y - 19, x + 8, y - 18, x + 1, y - 14)
  UI.ink("orangep")
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 10, 12, 3); gfx.setColor(BLACK); gfx.drawRect(x - 6, y - 10, 12, 3)
  UI.ink("inkgold")
  gfx.fillRect(x - 1, y - 10, 3, 3)
end)
-- glasses are drawn from the top row of the eyes (y here is that row, not the middle of the head), so they always sit over the eyes.
-- Each lens is 6 wide and 6 tall (rows y-2 .. y+3), so the 2 x 2 eye sits exactly in the middle of it.
CAFE.defWear("g_round", function(x, y)
  gfx.setColor(BLACK)
  gfx.drawEllipseInRect(x - 6, y - 2, 6, 6); gfx.drawEllipseInRect(x + 1, y - 2, 6, 6)
  gfx.drawPixel(x, y)
  gfx.drawLine(x - 7, y, x - 9, y - 1); gfx.drawLine(x + 7, y, x + 9, y - 1)
end)
CAFE.defWear("g_square", function(x, y)
  gfx.setColor(BLACK); gfx.drawRect(x - 6, y - 2, 6, 6); gfx.drawRect(x + 1, y - 2, 6, 6); gfx.drawPixel(x, y)
end)
CAFE.defWear("g_shades", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 7, y - 1, 7, 5); gfx.fillRect(x + 1, y - 1, 7, 5); gfx.drawLine(x, y - 1, x, y - 1)
  gfx.drawLine(x - 8, y - 1, x - 9, y - 1); gfx.drawLine(x + 8, y - 1, x + 9, y - 1)
  gfx.setColor(WHITE); gfx.drawPixel(x - 5, y); gfx.drawPixel(x + 3, y); gfx.setColor(BLACK)
end)
CAFE.defWear("g_heart", function(x, y)
  gfx.setColor(BLACK)
  for _, cx in ipairs({ x - 6, x + 1 }) do          -- a little heart, 6 wide and 5 tall, over each eye
    gfx.fillRect(cx, y - 1, 2, 1); gfx.fillRect(cx + 4, y - 1, 2, 1)
    gfx.fillRect(cx, y, 6, 2); gfx.fillRect(cx + 1, y + 2, 4, 1); gfx.fillRect(cx + 2, y + 3, 2, 1)
  end
  gfx.drawPixel(x, y)
end)
CAFE.defWear("g_cat", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 9, y - 3, x, y - 1, x - 3, y + 3); gfx.fillTriangle(x + 10, y - 3, x + 1, y - 1, x + 4, y + 3)
  gfx.drawLine(x, y - 1, x + 1, y - 1)
end)
CAFE.defWear("g_nerd", function(x, y)
  gfx.setColor(BLACK)
  gfx.drawEllipseInRect(x - 7, y - 2, 8, 6); gfx.drawEllipseInRect(x, y - 2, 8, 6)     -- big frames, joined in the middle
  gfx.fillRect(x - 6, y - 2, 12, 1)                                                      -- a thick top bar
  gfx.drawLine(x - 8, y - 1, x - 9, y - 1); gfx.drawLine(x + 8, y - 1, x + 9, y - 1)
end)
CAFE.defWear("g_monocle", function(x, y)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(x + 1, y - 2, 6, 6); gfx.drawLine(x + 6, y + 4, x + 8, y + 7); gfx.drawLine(x + 8, y + 7, x + 7, y + 12)
end)
CAFE.defWear("g_3d", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 6, y - 1, 6, 5)
  if UI.color then UI.ink("white"); gfx.drawRect(x - 6, y - 1, 6, 5); UI.ink("inkred") end       -- (PC: the red lens gets the same grey frame as the blue one)
  UI.ink("inkteal")
  if UI.color then gfx.fillRect(x + 1, y - 1, 6, 5) else gfx.setPattern(CHECK); gfx.fillRect(x + 1, y - 1, 6, 5); gfx.setColor(BLACK) end
  UI.ink("white")
  gfx.drawRect(x + 1, y - 1, 6, 5); gfx.drawPixel(x, y - 1)
end)
-- ---- more to wear: star glasses, a propeller cap, a viking helmet, a halo, a flower crown, a pirate hat, a frog hat, bunny ears, a bucket hat
CAFE.defWear("h_prop", function(x, y)              -- a panelled cap with a little propeller spinning on top
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 8, y - 13, 17, 9, 4); gfx.fillRect(x - 9, y - 6, 19, 2)
  UI.ink("yellow")
  gfx.setColor(WHITE)
  gfx.fillTriangle(x, y - 12, x - 6, y - 6, x - 3, y - 6); gfx.fillTriangle(x + 1, y - 12, x + 4, y - 6, x + 7, y - 6)   -- two light panels
  UI.ink("inkred")
  gfx.setColor(BLACK); gfx.drawLine(x, y - 13, x, y - 16)                                                -- the stalk
  UI.ink("inkblue")
  local sp = math.floor(math.abs(math.cos(frames * 0.45)) * 6 + 0.5)                                    -- the blades, turning (seen side on, they grow and shrink)
  gfx.fillRect(x - sp, y - 17, sp * 2 + 1, 2)
  gfx.setColor(WHITE); if sp >= 2 then gfx.drawPixel(x - sp + 1, y - 17) end
  gfx.setColor(BLACK); gfx.fillRect(x - 1, y - 18, 3, 1)
end)
CAFE.defWear("h_viking", function(x, y)            -- a round helmet with a riveted band and two curling horns
  UI.ink("cream")
  for side = -1, 1, 2 do
    gfx.setColor(WHITE)
    gfx.fillPolygon(x + side * 7, y - 12, x + side * 11, y - 11, x + side * 13, y - 14, x + side * 13, y - 19, x + side * 15, y - 15, x + side * 14, y - 10, x + side * 10, y - 7, x + side * 7, y - 8)
    gfx.setColor(BLACK)
    gfx.drawPolygon(x + side * 7, y - 12, x + side * 11, y - 11, x + side * 13, y - 14, x + side * 13, y - 19, x + side * 15, y - 15, x + side * 14, y - 10, x + side * 10, y - 7, x + side * 7, y - 8)
    gfx.drawPixel(x + side * 13, y - 13)                                                                  -- a ridge on the horn
  end
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 8, y - 15, 17, 11, 6)
  UI.ink("brass")
  gfx.setColor(WHITE); gfx.fillRect(x - 8, y - 9, 17, 3)
  gfx.setColor(BLACK); for i = -6, 6, 4 do gfx.drawPixel(x + i, y - 8) end                               -- rivets
  gfx.setColor(WHITE); gfx.drawPixel(x - 4, y - 13); gfx.drawPixel(x - 3, y - 14)                        -- a shine
  gfx.setColor(BLACK); gfx.fillRect(x, y - 9, 1, 5)                                                      -- the nose guard
end)
CAFE.defWear("h_halo", function(x, y)              -- a glowing ring floating over the head, bobbing gently
  local bob = math.floor(math.sin(frames * 0.12) * 1.2 + 0.5)
  local hy = y - 18 + bob
  UI.ink("inkgold")
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x - 8, hy - 2, 17, 6)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(x - 5, hy, 11, 2)
  gfx.setColor(WHITE); gfx.drawLine(x - 5, hy - 1, x - 2, hy - 1)                                         -- the shine along its top
  UI.ink("yellow")
  local k = (math.floor(frames / (4))) % 12                                                              -- a twinkle that hops round it
  gfx.setColor(BLACK)
  if k < 3 then gfx.drawPixel(x + 10, hy - 3); gfx.drawPixel(x + 9, hy - 3); gfx.drawPixel(x + 11, hy - 3); gfx.drawPixel(x + 10, hy - 4); gfx.drawPixel(x + 10, hy - 2)
  elseif k >= 6 and k < 9 then gfx.drawPixel(x - 10, hy - 1); gfx.drawPixel(x - 11, hy - 1); gfx.drawPixel(x - 9, hy - 1); gfx.drawPixel(x - 10, hy - 2); gfx.drawPixel(x - 10, hy) end
end)
CAFE.defWear("h_wreath", function(x, y)            -- a ring of flowers and little leaves across the top of the head
  UI.ink("leaf")
  gfx.setColor(BLACK)
  gfx.drawLine(x - 9, y - 6, x - 5, y - 9); gfx.drawLine(x - 5, y - 9, x + 5, y - 9); gfx.drawLine(x + 5, y - 9, x + 9, y - 6)   -- the vine
  gfx.fillTriangle(x - 7, y - 9, x - 9, y - 11, x - 5, y - 10); gfx.fillTriangle(x + 7, y - 9, x + 9, y - 11, x + 5, y - 10)
  gfx.fillTriangle(x - 2, y - 12, x - 3, y - 15, x, y - 13); gfx.fillTriangle(x + 2, y - 12, x + 3, y - 15, x, y - 13)
  local fl = { { -8, -7, 2 }, { -4, -10, 2 }, { 0, -11, 3 }, { 4, -10, 2 }, { 8, -7, 2 } }
  for i, f in ipairs(fl) do
    UI.ink((i % 2 == 1) and "inkpink" or "white")
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + f[1], y + f[2], f[3])
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + f[1], y + f[2], f[3])
    UI.ink("yellow")
    gfx.drawPixel(x + f[1], y + f[2])
  end
end)
CAFE.PIRATE = { body = { "........kkkkkkkkkkk........", "......kkkkkkkkkkkkkkk......", ".....kkkkkkkkkkkkkkkkk.....", "....kkkkkkkkkkkkkkkkkkk....", "...kkkkkkkkkkkkkkkkkkkkk...", "...kkkkkkkkkkkkkkkkkkkkk...", "..kkkkkkkkkkkkkkkkkkkkkkk..", ".kkkkkkkkkkkkkkkkkkkkkkkkk.", "kkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkkk.....kkkkk.....kkkkkk", "kk.......................kk" },
  skull = { "...........................", "...........................", ".........k..kkk..k.........", "..........kkkkkkk..........", "...........k.k.k...........", "..........kkkkkkk..........", ".........k..k.k..k.........", "...........................", "...........................", "...........................", "..........................." },
  trim = { "...........................", "...........................", "...........................", "...........................", "...........................", "...........................", "...........................", "...........................", "...kkkkkkkkkkkkkkkkkkkkk...", "...........................", "..........................." } }
CAFE.defWear("h_pirate", function(x, y)            -- a tricorn hat with a skull and crossbones and a gold band (a pixel picture: clear on the Playdate too)
  local x0, y0 = x - 13, y - 15
  gfx.setColor(BLACK); CAFE.runPic(CAFE.PIRATE.body, x0, y0, 1)
  UI.ink("white"); gfx.setColor(WHITE); CAFE.runPic(CAFE.PIRATE.skull, x0, y0, 1)
  UI.ink("gold2"); gfx.setColor(WHITE); CAFE.runPic(CAFE.PIRATE.trim, x0, y0, 1)
  gfx.setColor(BLACK)
end)
CAFE.defWear("h_frog", function(x, y)              -- a soft frog hat: a green dome, two goggly eyes and a big smile
  UI.ink("inkgreen")
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 9, y - 13, 19, 10, 5)
  gfx.setColor(WHITE); gfx.drawPixel(x - 7, y - 9); gfx.drawPixel(x + 8, y - 9)                          -- rosy cheeks
  gfx.setColor(WHITE); gfx.drawLine(x - 4, y - 7, x - 2, y - 5); gfx.drawLine(x - 2, y - 5, x + 3, y - 5); gfx.drawLine(x + 3, y - 5, x + 5, y - 7)   -- the smile
  for side = -1, 1, 2 do                                                                                  -- the eyes, blinking now and then
    local ex = x + side * 6 + ((side > 0) and 1 or 0)
    UI.ink("inkgreen")
    gfx.setColor(BLACK); gfx.fillCircleAtPoint(ex, y - 13, 4)
    UI.ink("white")
    gfx.setColor(WHITE)
    if (frames % 150) < 6 then gfx.drawLine(ex - 2, y - 13, ex + 2, y - 13)
    else gfx.fillCircleAtPoint(ex, y - 13, 2); gfx.setColor(BLACK); gfx.fillRect(ex - side, y - 13, 2, 2) end
  end
  gfx.setColor(BLACK)
end)
CAFE.defWear("h_bunny", function(x, y)             -- a headband with two tall bunny ears (the right one bent over at the tip, and it twitches)
  gfx.setColor(BLACK); gfx.fillRect(x - 9, y - 9, 19, 2)
  local tw = ((frames % 120) < 8) and 1 or 0
  UI.ink("white")
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x - 8, y - 24, 7, 17)                                       -- the left ear, standing tall
  gfx.setColor(WHITE); gfx.fillEllipseInRect(x - 7, y - 22, 5, 13)
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x + 2, y - 20 + tw, 7, 13)                                  -- the right ear, shorter...
  gfx.fillPolygon(x + 3, y - 18 + tw, x + 7, y - 21 + tw, x + 12, y - 17 + tw, x + 11, y - 14 + tw, x + 7, y - 16 + tw)     -- ...with its tip flopped over
  gfx.setColor(WHITE); gfx.fillEllipseInRect(x + 3, y - 17 + tw, 5, 9)
  if UI.color then                                                                                        -- (PC: pink inside the ears)
    UI.ink("inkpink")
    gfx.fillEllipseInRect(x - 6, y - 20, 3, 9); gfx.fillEllipseInRect(x + 4, y - 15 + tw, 3, 6)
  end
  gfx.setColor(BLACK)
end)
CAFE.defWear("h_bucket", function(x, y)            -- a soft bucket hat: a squat crown, a band and a sloping brim all round
  gfx.setColor(BLACK)
  gfx.fillPolygon(x - 6, y - 14, x + 6, y - 14, x + 8, y - 7, x - 8, y - 7)
  gfx.setColor(WHITE); gfx.fillRect(x - 7, y - 10, 15, 2)
  UI.ink("bark")
  gfx.setColor(BLACK); gfx.drawLine(x - 7, y - 10, x + 7, y - 10)
  UI.ink("tan")
  gfx.setColor(WHITE); gfx.fillPolygon(x - 9, y - 7, x + 9, y - 7, x + 13, y - 3, x - 13, y - 3)
  gfx.setColor(BLACK); gfx.drawPolygon(x - 9, y - 7, x + 9, y - 7, x + 13, y - 3, x - 13, y - 3)
  for i = -9, 9, 3 do gfx.drawPixel(x + i, y - 5) end                                                     -- stitching round the brim
  gfx.setColor(WHITE); gfx.drawPixel(x - 4, y - 13); gfx.drawPixel(x - 5, y - 12)
  gfx.setColor(BLACK)
end)
CAFE.defWear("g_star", function(x, y)              -- star-shaped shades, with a glint on each
  local STAR = { "...#...", "..###..", "#######", ".#####.", "..###..", ".##.##.", ".#...#." }
  if not UI.color then                                                                                    -- (1-bit: a thin white edge, so they show on dark hair)
    gfx.setColor(WHITE)
    for _, cx in ipairs({ x - 4, x + 4 }) do
      for r = 1, 7 do
        local row = STAR[r]
        for c = 1, 7 do if string.sub(row, c, c) == "#" then gfx.fillRect(cx + c - 5, y + r - 5, 3, 3) end end
      end
    end
  end
  gfx.setColor(BLACK)
  for _, cx in ipairs({ x - 4, x + 4 }) do
    for r = 1, 7 do
      local row = STAR[r]
      for c = 1, 7 do if string.sub(row, c, c) == "#" then gfx.drawPixel(cx + c - 4, y + r - 4) end end
    end
  end
  gfx.drawPixel(x, y - 1)
  gfx.drawLine(x - 8, y - 1, x - 9, y - 1); gfx.drawLine(x + 8, y - 1, x + 9, y - 1)
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawPixel(x - 5, y - 1); gfx.drawPixel(x + 3, y - 1)
  gfx.setColor(BLACK)
end)
-- how many rows a hat is raised for each hairstyle, so big or spiky hair sits under the hat and nothing pokes out of the top
CAFE.HATLIFT = {
  h_cap = { [5] = 1, [6] = 3, [9] = 5, [10] = 4, [12] = 2 },
  h_top = { [5] = 2, [6] = 2, [9] = 3, [10] = 3 },
  h_beanie = { [9] = 3, [10] = 3, [12] = 2 },
  h_cowboy = { [5] = 1, [6] = 1, [9] = 2, [10] = 2 },
  h_chef = { [6] = 3, [9] = 5, [10] = 3, [12] = 3 },
  h_crown = { [6] = 1, [9] = 3, [10] = 2, [12] = 1 },
  h_party = { [5] = 1, [6] = 4, [9] = 6, [10] = 4, [12] = 3 },
  h_beret = { [6] = 2, [9] = 4, [10] = 2, [12] = 2 },
  h_santa = { [5] = 3, [6] = 2, [9] = 3, [10] = 3, [12] = 2 },
  h_wizard = { [5] = 1, [6] = 2, [9] = 3, [10] = 3 },
  h_witch = { [5] = 1, [6] = 1, [9] = 3, [10] = 2 },
  h_prop = { [9] = 3, [10] = 3, [12] = 2 },
  h_viking = { [6] = 1, [9] = 3, [10] = 2, [12] = 1 },
  h_halo = { [5] = 1, [6] = 3, [9] = 5, [10] = 4, [12] = 3 },
  h_wreath = { [6] = 1, [9] = 3, [10] = 2, [12] = 1 },
  h_pirate = { [5] = 1, [6] = 1, [9] = 2, [10] = 2 },
  h_frog = { [9] = 3, [10] = 3, [12] = 2 },
  h_bucket = { [5] = 1, [6] = 2, [9] = 3, [10] = 3, [12] = 2 },
}
CAFE.WEARANIM = { h_prop = true, h_halo = true, h_frog = true, h_bunny = true }      -- (these move: always drawn live)
function CAFE.drawHat(id, x, y, look)
  local t = CAFE.HATLIFT[id]
  local hy = y - ((t and t[look]) or 0)
  if not (UI.color or UI.noCache or UI.noFast or CAFE.WEARANIM[id]) then       -- (Playdate: a hat that keeps still is stamped from a picture)
    local p = (x + hy + 1) % 2                                                -- (the picture's corner on the same square of the check as the screen)
    local im = UI.cacheGet("hat", id, p)
    if im == nil then im = UI.cacheImg("hat", id, p, 35, 26, function() CAFE.WEAR[id](17 + p, 26) end) end
    if im then UI.cacheDraw(im, x - 17 - p, hy - 26); return end
  end
  CAFE.WEAR[id](x, hy)
end
function CAFE.drawGlass(id, x, y)                     -- glasses, centred on x, their top row at y
  if not (UI.color or UI.noCache or UI.noFast or CAFE.WEARANIM[id]) then
    local p = (x + y + 1) % 2
    local im = UI.cacheGet("glass", id, p)
    if im == nil then im = UI.cacheImg("glass", id, p, 24, 20, function() CAFE.WEAR[id](11 + p, 6) end) end
    if im then UI.cacheDraw(im, x - 11 - p, y - 6); return end
  end
  CAFE.WEAR[id](x, y)
end

function CAFE.pickWear(look)
  if CAFE.hatIds == nil then
    CAFE.hatIds, CAFE.glassIds = {}, {}
    for _, id in ipairs(CAFE.WEARIDS) do
      if string.sub(id, 1, 2) == "g_" then CAFE.glassIds[#CAFE.glassIds + 1] = id else CAFE.hatIds[#CAFE.hatIds + 1] = id end
    end
  end
  local hat, glass
  if look ~= 2 and look ~= 4 and look ~= 8 and math.random() < 0.25 then hat = CAFE.hatIds[math.random(#CAFE.hatIds)] end    -- (not on top of a hat they already have)
  if look ~= 3 and math.random() < 0.22 then glass = CAFE.glassIds[math.random(#CAFE.glassIds)] end
  return hat, glass
end

function CAFE.drawWorn(x, y, look)                    -- whatever the barista has on (hat and glasses)
  local d = CAFE.dec()
  if d == nil then return end
  local glasses = false
  for i = 1, #CAFE.WEARIDS do
    local id = CAFE.WEARIDS[i]
    if d.decor[id] == "on" then
      if string.sub(id, 1, 2) == "g_" then CAFE.drawGlass(id, x, y + UI.eyeRow(look, true)); glasses = true      -- (glasses go right over the eyes)
      else CAFE.drawHat(id, x, y, look) end
    end
  end
  gfx.setColor(BLACK)
  return glasses
end

local function drawPlayer()
  local bob = 0
  if G.moving then bob = math.floor(math.sin(G.walk) * 1.5 + 0.5) end
  local px, py = math.floor(G.px), math.floor(PLAYER_Y + bob)
  local dec = CAFE.dec()
  if dec and G.mode == "cafe" then
    local gl = false                                   -- glasses sit over the eyes, so the mouth drops a pixel
    for i = 1, #CAFE.WEARIDS do
      local id = CAFE.WEARIDS[i]
      if dec.decor[id] == "on" and string.sub(id, 1, 2) == "g_" then gl = true end
    end
    UI.glasses = gl
    local hatOn = false
    for i = 1, #CAFE.WEARIDS do
      local id = CAFE.WEARIDS[i]
      if dec.decor[id] == "on" and string.sub(id, 1, 2) == "h_" then hatOn = true end
    end
    UI.noBow = hatOn or dec.nobow == true               -- the bow hides under a hat, or when you've turned it off
    local blook = UI.BARISTA[dec.char or 1] or 5
    drawPerson(px, py, blook, false)
    UI.glasses = false; UI.noBow = false
    CAFE.drawWorn(px, py, blook)
  else
    drawPerson(G.px, PLAYER_Y + bob, 5, false)
  end
  local n = G.cups and G.cups.hand or 0
  if n > 0 then                               -- clean cups held up in hand
    local x0 = math.floor(G.px) + 16               -- carried beside the barista
    for i = 1, n do drawCup(x0 + (i - 1) * 12, PLAYER_Y + 7 + bob, 1, false) end
  end
end

----------------------------------------------------------------------
-- Drawing: station panels (they pop up over the customer area)
----------------------------------------------------------------------
local function drawPanelFrame(c, title, text)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(6, 116, 388, 122, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(6, 116, 388, 122, 8)
  gfx.setLineWidth(1)
  UI.ink("chrome")                                              -- (PC: the station's title bar is black)
  gfx.fillRect(10, 120, 380, 18)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(title, 14, 121, true)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(title)
  if c then
    local x0 = 14 + tw + 12
    local room = (UI.noWait() and 384 or 340) - x0                 -- (the patience meter sits at the right end of the bar: the words stop before it)
    gfx.setFont(fontNormal)
    local pf = UI.pfCache or {}
    UI.pfCache = pf
    local str
    if pf.c == c and pf.text == text and pf.room == room and pf.kind == c.order.kind then str = pf.str     -- (worked out once per customer, not every frame)
    else
      str = text or orderShort(c.order)
      if gfx.getTextSize(str) > room then str = str:gsub(", ", ",") end                    -- a long order: squeeze the gaps...
      if gfx.getTextSize(str) > room then str = str:gsub("Pumpkin Spice", "Pumpkin") end   -- ...then the drink's name...
      if gfx.getTextSize(str) > room then str = str:gsub(" shots?", "sh"):gsub(" milk", "mk"):gsub(" sugar", "sg") end   -- ...then the other words
      if gfx.getTextSize(str) > room then str = CAFE.fitOne(str, room, false) end            -- (never under the meter)
      pf.c, pf.text, pf.room, pf.kind, pf.str = c, text, room, c.order.kind, str
    end
    drawT(str, x0, 121)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    if not UI.noWait() then drawPatience(346, 126, c.patience, 42, true) end
  else
    if G.st == "dishes" then
      drawTR("Dirty: " .. G.cups.dirty .. "     In hand: " .. G.cups.hand, 384, 121, true)
    else
      drawTR("In hand: " .. G.cups.hand, 384, 121, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
end

-- ---- the station screens (new look): little helpers first
function UI.textMid(word, cx, midY)               -- a bold word whose letters' own middle lands exactly on (cx, midY): the same measuring the placement bubbles use
  local m = CAFE.bubbleMeasure(word)
  gfx.setFont(fontBold)
  gfx.drawText(word, math.floor(cx - m.dx + 0.5), math.floor(midY - m.dy + 0.5))
end
UI.ARROWR = { "........k......", "........kk.....", "........kwk....", "........kwwk...", "kkkkkkkkkwwwk..", "kwwwwwwwwwwwwk.",
  "kwwwwwwwwwwwwwk", "kwwwwwwwwwwwwk.", "kkkkkkkkkwwwk..", "........kwwk...", "........kwk....", "........kk.....", "........k......" }   -- a clean pixel arrow pointing right
UI.RCPTHEART = { ".kk.kk.", "kkkkkkk", "kkkkkkk", ".kkkkk.", "..kkk..", "...k..." }   -- (pictures used every frame are kept here: the cache is keyed by the table)
UI.FLAMEPIC = { "..k..", ".kk..", ".kkk.", "kk.kk", "k...k", "kk.kk", ".kkk." }
function UI.pic(rows, x, y, k, inv)               -- draw a text picture (k = black, w = white); k = how many pixels each dot is
  k = k or 1
  do                                                  -- (drawn once, then stamped; PC: one per colour)
    local im = UI.cacheImg("pic", rows, k * 2 + (inv and 1 or 0) + 1000 * UI.inkNum(), #rows[1] * k, #rows * k, function() UI.picRaw(rows, 0, 0, k, inv) end)
    if im then UI.cacheDraw(im, x, y) else UI.picRaw(rows, x, y, k, inv) end
    gfx.setColor(BLACK)
    return
  end
  UI.picRaw(rows, x, y, k, inv)
end
function UI.picRaw(rows, x, y, k, inv)
  for j, r in ipairs(rows) do
    local i = 1
    while i <= #r do
      local ch = r:sub(i, i)
      if ch == "k" or ch == "w" then
        local n = 1
        while r:sub(i + n, i + n) == ch do n = n + 1 end
        local black = (ch == "k")
        if inv then black = not black end
        gfx.setColor(black and BLACK or WHITE)
        gfx.fillRect(x + (i - 1) * k, y + (j - 1) * k, n * k, k)
        i = i + n
      else i = i + 1 end
    end
  end
  gfx.setColor(BLACK)
end

function UI.icon(kind, x, y, inv)                                         -- little drawn icons, 12x12; inv = white on black
  local fg, bg = BLACK, WHITE
  if inv then fg, bg = WHITE, BLACK end
  gfx.setColor(fg)
  if kind == "bean" then
    gfx.fillEllipseInRect(x, y + 1, 12, 10)
    gfx.setColor(bg); gfx.setLineWidth(2); gfx.drawLine(x + 3, y + 9, x + 6, y + 6); gfx.drawLine(x + 6, y + 6, x + 9, y + 3); gfx.setLineWidth(1)
  elseif kind == "decaf" then
    gfx.setLineWidth(2); gfx.drawEllipseInRect(x + 1, y + 2, 10, 8); gfx.setLineWidth(1)
    gfx.drawLine(x + 3, y + 8, x + 6, y + 6); gfx.drawLine(x + 6, y + 6, x + 9, y + 4)
  elseif kind == "tea" then
    gfx.fillPolygon(x + 1, y + 11, x + 1, y + 5, x + 6, y + 1, x + 11, y + 1, x + 11, y + 6, x + 6, y + 11)
    gfx.setColor(bg); gfx.drawLine(x + 2, y + 10, x + 9, y + 3); gfx.setColor(fg)
  elseif kind == "matcha" then
    gfx.fillRoundRect(x, y + 5, 12, 7, 3)
    gfx.setColor(bg); gfx.drawLine(x + 2, y + 7, x + 9, y + 7); gfx.setColor(fg)
    gfx.drawLine(x + 7, y + 4, x + 10, y); gfx.drawLine(x + 8, y + 4, x + 11, y + 1); gfx.drawLine(x + 5, y + 4, x + 8, y)   -- the whisk
  elseif kind == "pumpkin" then                       -- a little pumpkin
    gfx.fillEllipseInRect(x, y + 3, 12, 9)
    gfx.fillRect(x + 5, y, 2, 4)
    gfx.setColor(bg); gfx.drawLine(x + 4, y + 5, x + 4, y + 10); gfx.drawLine(x + 8, y + 5, x + 8, y + 10); gfx.setColor(fg)
  elseif kind == "cocoa" then                         -- a mug with steam
    gfx.fillRoundRect(x, y + 4, 9, 8, 2)
    gfx.drawCircleAtPoint(x + 10, y + 8, 2)
    gfx.drawLine(x + 3, y, x + 4, y + 2); gfx.drawLine(x + 6, y, x + 7, y + 2)
  elseif kind == "shot" then
    gfx.fillPolygon(x + 2, y, x + 10, y, x + 9, y + 11, x + 3, y + 11)
    gfx.setColor(bg); gfx.fillRect(x + 4, y + 2, 4, 3); gfx.setColor(fg)
  elseif kind == "milk" then
    gfx.fillRect(x + 2, y + 4, 8, 8)
    gfx.fillTriangle(x + 2, y + 4, x + 10, y + 4, x + 6, y)
    gfx.setColor(bg); gfx.fillRect(x + 4, y + 7, 4, 3); gfx.drawLine(x + 5, y + 3, x + 7, y + 3); gfx.setColor(fg)
  elseif kind == "sugar" then
    gfx.fillRect(x + 1, y + 2, 10, 9)
    gfx.setColor(bg); gfx.fillRect(x + 3, y + 4, 2, 2); gfx.fillRect(x + 7, y + 4, 2, 2); gfx.fillRect(x + 5, y + 7, 2, 2); gfx.setColor(fg)
  elseif kind == "ice" then
    gfx.setLineWidth(2); gfx.drawRect(x + 1, y + 1, 10, 10); gfx.setLineWidth(1)
    gfx.drawLine(x + 3, y + 4, x + 5, y + 4); gfx.drawLine(x + 3, y + 4, x + 3, y + 7)
  end
  gfx.setColor(BLACK)
end
UI.DIG = { ["0"] = { "###", "#.#", "#.#", "#.#", "###" }, ["1"] = { ".#.", "##.", ".#.", ".#.", "###" }, ["2"] = { "###", "..#", "###", "#..", "###" },
  ["3"] = { "###", "..#", "###", "..#", "###" }, ["4"] = { "#.#", "#.#", "###", "..#", "..#" }, ["5"] = { "###", "#..", "###", "..#", "###" },
  ["6"] = { "###", "#..", "###", "#.#", "###" }, ["7"] = { "###", "..#", ".#.", ".#.", ".#." }, ["8"] = { "###", "#.#", "###", "#.#", "###" },
  ["9"] = { "###", "#.#", "###", "..#", "###" }, ["."] = { ".", ".", ".", ".", "#" } }
-- Playdate speed: little pictures drawn pixel by pixel (big digits, icons, the pixel fonts) are drawn once into a picture
-- and stamped after that. (The PC draws them directly: its colours are chosen as it draws.)
UI.cacheC, UI.cacheO, UI.cacheN = {}, {}, 0
function UI.cacheImg(ns, k1, k2, w, h, fn)
  local t0 = UI.cacheC[ns]
  if not t0 then t0 = {}; UI.cacheC[ns] = t0 end
  local t1 = t0[k1]
  if not t1 then t1 = {}; t0[k1] = t1 end
  if UI.noCache then return false end                -- (testing: everything drawn directly)
  local im = t1[k2]
  if im == nil then
    if UI.cacheN >= 400 then UI.cacheO, UI.cacheC, UI.cacheN = UI.cacheC, {}, 0; return UI.cacheImg(ns, k1, k2, w, h, fn) end
    local o0 = UI.cacheO[ns]; local o1 = o0 and o0[k1]                -- (the last lot: a picture still in use moves back, it isn't redrawn)
    if o1 and o1[k2] ~= nil then t1[k2] = o1[k2]; UI.cacheN = UI.cacheN + 1; return o1[k2] end
    im = false
    if w > 0 and h > 0 then
      local ok, img = pcall(gfx.image.new, w, h, gfx.kColorClear)
      if ok and img then
        gfx.pushContext(img)
        gfx.setDrawOffset(0, 0); gfx.clearClipRect(); gfx.setImageDrawMode(gfx.kDrawModeCopy)
        fn()
        gfx.popContext()
        im = img
      end
    end
    t1[k2] = im
    UI.cacheN = UI.cacheN + 1
  end
  return im
end
function UI.cacheGet(ns, k1, k2)                   -- the picture if it is made already (nil if not: then UI.cacheImg makes it)
  local t0 = UI.cacheC[ns]
  local t1 = t0 and t0[k1]
  if t1 then return t1[k2] end
  return nil
end
function UI.cacheDraw(im, x, y)                    -- stamped exactly as drawn (whatever draw mode is on)
  local m = gfx.getImageDrawMode()
  if m == gfx.kDrawModeCopy then im:draw(x, y); return end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  im:draw(x, y)
  gfx.setImageDrawMode(m)
end

-- Playdate speed in a busy cafe. People, hats, glasses and cups look the same wherever they are, so each is drawn
-- once into a picture and stamped. The pieces that move (lamps, plants, tanks, clocks, pets, the view out of the
-- window) each get a little picture of their own that is drawn again every other frame (half of them on one frame,
-- half on the next) and stamped in between. (The PC draws everything directly.)
function UI.personImg(x, y, look, angry, mood)
  x, y = math.floor(x), math.floor(y)
  local gl = (look == 3) or (UI.glasses == true)
  mood = mood or (angry and 0 or 2)
  if gl and mood == 3 then mood = 2 end
  local nb = (look == 12 and UI.noBow) and 1 or 0
  local p = (x + y + 1) % 2                                  -- (the picture's corner on the same square of the check as the screen)
  local k2 = mood * 8 + (gl and 4 or 0) + nb * 2 + p
  local im = UI.cacheGet("person", look, k2)
  if im == nil then im = UI.cacheImg("person", look, k2, 35, 40, function() UI.personRaw(17 + p, 14, look, false, mood) end) end
  if not im then return false end
  UI.cacheDraw(im, x - 17 - p, y - 14)
  return true
end
function UI.cupImg(o, cx, cy, steam)
  local kind, ice = o.kind or "coffee", o.ice > 0
  local im = UI.cacheGet("cup", ice and 1 or 0, 0)
  if im == nil then im = UI.cacheImg("cup", ice and 1 or 0, 0, 12, 16, function() UI.cupRaw(o, 4, 10, false, nil, true) end) end
  if not im then return false end
  UI.cacheDraw(im, cx - 4, cy - 10)
  gfx.setPattern(DRINK_PATTERN[kind])                       -- (the drink itself is drawn here, so its pattern lines up with the screen's)
  if ice then gfx.fillRect(cx - 2, cy - 1, 5, 5); gfx.setColor(BLACK); gfx.drawLine(cx + 1, cy + 3, cx + 1, cy - 1)
  else gfx.fillRect(cx - 2, cy - 2, 5, 3); gfx.setColor(BLACK) end
  if steam and not ice then
    local ph = (frames + cy * 3) % 25
    local sm = UI.cacheGet("steam", ph, 0)
    if sm == nil then sm = UI.cacheImg("steam", ph, 0, 10, 10, function() UI.steamRaw(4, 13, ph) end) end
    if sm then UI.cacheDraw(sm, cx - 4, cy - 13) else UI.steamRaw(cx, cy, ph) end
  end
  return true
end
function UI.cupDot(cx, cy)                          -- the coffee cup on the table in front of someone sitting down
  if not (UI.color or UI.noCache or UI.noFast) then
    local im = UI.cacheGet("cupdot", 0, 0) or UI.cacheImg("cupdot", 0, 0, 7, 7, function()
      gfx.setColor(BLACK); gfx.fillCircleAtPoint(3, 3, 3); gfx.setColor(WHITE); gfx.fillCircleAtPoint(3, 3, 1)
    end)
    if im then im:draw(cx - 3, cy - 3); return end
  end
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx, cy, 3)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 1)
end

UI.LIVE_K = 2                                       -- (a moving piece is drawn again every this many frames: 2, or more in a very busy cafe)
UI.liveAvg, UI.liveHold = 0, 0
function UI.livePace(ms)                            -- (Playdate: how long the frame's work took. If the cafe is so full that frames
  UI.liveAvg = UI.liveAvg * 0.9 + ms * 0.1          --  run long, the moving decor is redrawn less often; when there's time again, more)
  if UI.liveHold > 0 then UI.liveHold = UI.liveHold - 1; return end
  if UI.liveAvg > 26 and UI.LIVE_K < 3 then UI.LIVE_K, UI.liveHold = UI.LIVE_K + 1, 45
  elseif UI.liveAvg < 15 and UI.LIVE_K > 2 then UI.LIVE_K, UI.liveHold = UI.LIVE_K - 1, 45 end
end
function UI.liveDraw(key, x0, y0, w, h, fn, a, b, c, d, e_, f_)
  if not UI.inPlay or UI.color or UI.noCache or UI.noFast then fn(a, b, c, d, e_, f_); return end
  local C = G.liveC                                 -- (kept with the day, and let go when the decor changes)
  if not C then C = { n = 0 }; G.liveC = C end
  local e = C[key]
  if e == nil then
    local ok, img = pcall(gfx.image.new, w, h, gfx.kColorClear)
    if not (ok and img) then C[key] = false; fn(a, b, c, d, e_, f_); return end
    C.n = C.n + 1
    e = { img = img, ph = C.n }                     -- (its turn: spread out, so each frame redraws its share)
    C[key] = e
  elseif e == false then fn(a, b, c, d, e_, f_); return end
  local img, at = e.img, e.at
  if at == nil or (at ~= frames and ((frames + e.ph) % UI.LIVE_K == 0 or frames - at >= UI.LIVE_K or at > frames)) then
    img:clear(gfx.kColorClear)
    gfx.pushContext(img)
    gfx.setDrawOffset(-x0, -y0); gfx.clearClipRect()
    fn(a, b, c, d, e_, f_)
    gfx.popContext()
    e.at = frames
  end
  img:draw(x0, y0)
end
function CAFE.topBox(it, ax, ay)                   -- the box a counter / table-top piece's picture needs (a bird's has room for what it says)
  if it and it.bird then
    local x0, y0, w, h = UI.box8(ax, ay, -80, -52, 79, 15)
    if x0 < 0 then w, x0 = w + x0, 0 end
    if x0 + w > 400 then w = 400 - x0 end
    return x0, y0, w, h
  end
  return UI.box8(ax, ay, -21, -32, 20, 15)
end
function UI.box8(ax, ay, l, t, r, b)                -- a box round a piece at ax, ay (its corner on the 8-pixel grid, so patterns line up)
  local x0, y0 = ax + l, ay + t
  x0, y0 = x0 - x0 % 8, y0 - y0 % 8
  return x0, y0, ax + r - x0 + 1, ay + b - y0 + 1
end

-- Playdate: a piece whose still parts are drawn once into pictures (fn draws them, at their place on the screen) and
-- stamped from then on, one picture for each place it stands (its corner on the 8-pixel grid, so patterns line up)
function CAFE.fastArt() return not (UI.color or UI.noCache or UI.noFast) end
function CAFE.layer(ns, k1, x0, y0, w, h, fn, a, b, c, d, e)
  local ax, ay = x0 - x0 % 8, y0 - y0 % 8
  w, h = w + x0 - ax, h + y0 - ay
  local k2 = ax * 1000 + ay
  local im = UI.cacheGet(ns, k1, k2)
  if im == nil then
    im = UI.cacheImg(ns, k1, k2, w, h, function() gfx.setDrawOffset(-ax, -ay); fn(a, b, c, d, e) end)
  end
  if im then UI.cacheDraw(im, ax, ay) else fn(a, b, c, d, e) end
end
CAFE.LIVEDIRECT = { hamster = true, hamwhite = true, hamgray = true, axotank = true, axowild = true, axogold = true,
                    tiffany = true, tiffanytab = true }      -- (cheap to draw now, and quick-moving: drawn every frame)

-- the moving decor, found once a day (not by looking through every item in the game every frame)
function CAFE.liveLists()
  local L = G.liveL
  if L then return L end
  L = { ctr = {}, wall = {}, floor = {} }
  local d = CAFE.dec()
  if d then
    for _, it in ipairs(CAFE.ITEMS) do
      local id = it.id
      local pl = (d.decor[id] == "on") and d.place[id]
      if pl then
        if it.kind == "counter" and pl <= #CAFE.CSLOT then
          local sl = CAFE.CSLOT[pl]
          local dx = CAFE.slotFit(id, pl)
          local x0, y0, w, h = CAFE.topBox(it, sl[1] + dx, sl[2])
          L.ctr[#L.ctr + 1] = { "c" .. id, x0, y0, w, h, id, pl, sl[1], sl[2], CAFE.LIVEDIRECT[it.copyOf or id] }
        elseif (it.kind == "wall" or it.kind == "tiny") and CAFE.TILES[pl] and CAFE.LIVEWALL[id] then
          local cx, cy = CAFE.tileCenter(pl)
          local x0, y0, w, h = UI.box8(cx, cy, -17, -18, 16, 16)
          L.wall[#L.wall + 1] = { "w" .. id, x0, y0, w, h, (id == "cuckoo") and CAFE.cuckooBody or CAFE.art[id], cx, cy, nil, CAFE.LIVEDIRECT[it.copyOf or id] }
        elseif it.kind == "floor" and CAFE.ANIM[id] and CAFE.FSLOT[pl] then
          local sl = CAFE.FSLOT[pl]
          local x0, y0, w, h = UI.box8(sl[1], sl[2], -18, -31, 20, 20)
          L.floor[#L.floor + 1] = { "f" .. id, x0, y0, w, h, CAFE.art[id], sl[1], sl[2], nil, CAFE.LIVEDIRECT[it.copyOf or id] }
        end
      end
    end
  end
  G.liveL = L
  return L
end
function CAFE.drawLiveList(list, counter)
  for i = 1, #list do
    local e = list[i]
    if counter then
      if e[10] then CAFE.counterAt(e[6], e[7], e[8], e[9]) else UI.liveDraw(e[1], e[2], e[3], e[4], e[5], CAFE.counterAt, e[6], e[7], e[8], e[9]) end
    elseif e[10] then e[6](e[7], e[8])
    else UI.liveDraw(e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8]) end
  end
  gfx.setColor(BLACK)
end
function UI.dotRow(x0, x1, step, y, two)          -- a dotted line (PD: stamped from one cached strip, not dozens of single pixels)
  if UI.color or UI.noCache then
    for x = x0, x1, step do gfx.drawPixel(x, y); if two then gfx.drawPixel(x + 1, y) end end
    return
  end
  local col = UI.getColor()
  if col == -1 then for x = x0, x1, step do gfx.drawPixel(x, y); if two then gfx.drawPixel(x + 1, y) end end return end     -- (a pattern: drawn as it is)
  local w = x1 - x0 + 2
  local im = UI.cacheImg("dots", w * 100 + step, (two and 10 or 0) + (tonumber(col) or 0), w, 1, function()
    gfx.setColor(col)
    for x = 0, x1 - x0, step do gfx.drawPixel(x, 0); if two then gfx.drawPixel(x + 1, 0) end end
  end)
  if im then UI.cacheDraw(im, x0, y) else for x = x0, x1, step do gfx.drawPixel(x, y); if two then gfx.drawPixel(x + 1, y) end end end
end
function UI.bigWidth(s, k) local w = 0; for ch in s:gmatch(".") do w = w + (#UI.DIG[ch][1] + 1) * k end return w - k end
function UI.bigNum(s, rx, y, k, inv)                  -- chunky pixel digits, right edge at rx
  if not UI.color then
    local w = UI.bigWidth(s, k)
    local im = UI.cacheImg("big", k * 2 + (inv and 1 or 0), s, w, #UI.DIG["0"] * k, function() UI.bigNumRaw(s, w - 1, 0, k, inv) end)
    if im then UI.cacheDraw(im, rx - w + 1, y) else UI.bigNumRaw(s, rx, y, k, inv) end
    gfx.setColor(BLACK)
    return
  end
  UI.bigNumRaw(s, rx, y, k, inv)
end
function UI.bigNumRaw(s, rx, y, k, inv)
  local x = rx - UI.bigWidth(s, k) + 1
  gfx.setColor(inv and WHITE or BLACK)
  for ch in s:gmatch(".") do
    local g = UI.DIG[ch]
    for j, row in ipairs(g) do
      for i = 1, #row do
        if row:sub(i, i) == "#" then gfx.fillRect(x + (i - 1) * k, y + (j - 1) * k, k, k) end
      end
    end
    x = x + (#g[1] + 1) * k
  end
  gfx.setColor(BLACK)
end

function UI.textW(s, bold) gfx.setFont(bold and fontBold or fontNormal); return (gfx.getTextSize(s)) end
-- Round shapes for the little icons, built pixel by pixel round the centre pixel so they come out perfectly even:
-- every pixel whose distance from the centre is between rin and rout (and, for an arc, whose angle lies between a0 and a1,
-- measured clockwise on screen from "3 o'clock"). The pixel runs are worked out once and kept.
UI.atan2 = math.atan2 or math.atan                 -- (the angle of a point: the PC's Lua spells it atan2, the Playdate's atan)
UI.ringCache = {}
function UI.ringRuns(rin, rout, a0, a1)
  local key = rin .. "/" .. rout .. "/" .. (a0 or "") .. "/" .. (a1 or "")
  local runs = UI.ringCache[key]
  if runs then return runs end
  runs = {}
  local lim = math.ceil(rout)
  local i2, o2 = rin * rin, rout * rout
  for dy = -lim, lim do
    local x0
    for dx = -lim, lim + 1 do
      local on = false
      if dx <= lim then
        local d2 = dx * dx + dy * dy
        if d2 >= i2 and d2 <= o2 then
          on = true
          if a0 then
            local deg = math.deg(UI.atan2(dy, dx)) % 360
            on = deg >= a0 and deg <= a1
          end
        end
      end
      if on then
        if not x0 then x0 = dx end
      elseif x0 then
        runs[#runs + 1] = { x0, dy, dx - x0 }
        x0 = nil
      end
    end
  end
  UI.ringCache[key] = runs
  return runs
end

function UI.ringDraw(x, y, rin, rout, a0, a1)
  local runs = UI.ringRuns(rin, rout, a0, a1)
  for i = 1, #runs do
    local r = runs[i]
    gfx.fillRect(x + r[1], y + r[2], r[3], 1)
  end
end

function UI.disc(x, y, r) UI.ringDraw(x, y, 0, r) end

function UI.thickLine(x0, y0, x1, y1, r)                                   -- a line with round ends, `r` being the radius of its pen
  local n = math.max(1, math.floor(math.sqrt((x1 - x0) ^ 2 + (y1 - y0) ^ 2) + 0.5))
  for k = 0, n do
    UI.disc(math.floor(x0 + (x1 - x0) * k / n + 0.5), math.floor(y0 + (y1 - y0) * k / n + 0.5), r)
  end
end

-- the turn-arrow ring both icons sit in: a bold circle open on the right, an arrowhead at its end pointing clockwise
-- (ri and ro are the innermost and outermost pixel of the ring along the compass points)
function UI.turnRing(x, y, ri, ro, head)
  local a0, a1 = 40, 312
  UI.ringDraw(x, y, ri - 0.5, ro + 0.5, a0, a1)
  local R = (ri + ro) / 2
  local ea = math.rad(a1 - 3)                                               -- arrowhead: base across the ring, tip following the curve
  local ta = ea + (head * 1.35) / R
  local function P(ang, r) return math.floor(x + math.cos(ang) * r + 0.5), math.floor(y + math.sin(ang) * r + 0.5) end
  local bx0, by0 = P(ea, R + head * 0.62)
  local bx1, by1 = P(ea, R - head * 0.62)
  local tx, ty = P(ta, R)
  gfx.fillTriangle(bx0, by0, bx1, by1, tx, ty)
end

function UI.crankIcon(x, y, ang, s)                                     -- the crank: arm and handle turning inside a clockwise arrow
  s = s or 1
  gfx.setColor(BLACK)
  local small = s < 0.8
  if small then UI.turnRing(x, y, 10, 12, 4.5) else UI.turnRing(x, y, 22, 25, 8) end
  local a = math.rad(ang)
  local arm = small and 5 or 12
  local hx, hy = math.floor(x + math.cos(a) * arm + 0.5), math.floor(y + math.sin(a) * arm + 0.5)
  UI.thickLine(x, y, hx, hy, small and 1.0 or 2.0)                           -- the arm
  UI.disc(x, y, small and 1.5 or 3.6)                                        -- the hub
  UI.disc(hx, hy, small and 2.6 or 5.2)                                      -- the handle (with a hole in the big one)
  if not small then
    gfx.setColor(WHITE)
    UI.disc(hx, hy, 1.9)
    gfx.setColor(BLACK)
  end
end

-- a d-pad with a picture beside each word (the pad itself is the game's own)
UI.ICONINK = { bean = "coffee", decaf = "decaf", tea = "tea", matcha = "matcha", pumpkin = "pspice", cocoa = "cocoa",
               shot = "coffee", milk = "inkblue", sugar = "inkpink", ice = "inkteal" }      -- (PC: the colour of each choice)
function UI.padWords(pxx, pyy, words, icons, on)
  UI.ink("slate")
  UI.drawSmallPad(pxx, pyy, {}, on)
  UI.ink("none")
  local function group(side, txt, icon, cx, ty, lit)
    local tw = UI.textW(txt, true)
    local gw = 15 + tw
    local x0
    if side == "up" or side == "down" then x0 = cx - math.floor(gw / (2))
    elseif side == "left" then x0 = cx - gw
    else x0 = cx end
    UI.ink(UI.ICONINK[icon])
    if lit then
      gfx.setColor(BLACK); gfx.fillRoundRect(x0 - 4, ty - 2, gw + 8, 18, 4)
    end
    UI.icon(icon, x0, ty + 2, lit)
    gfx.setFont(fontBold)
    if lit then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) end
    drawT(txt, x0 + 15, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.ink("none")
    gfx.setColor(BLACK)
  end
  group("up", words.up, icons.up, pxx, pyy - 47, on == "up")
  group("down", words.down, icons.down, pxx, pyy + 29, on == "down")
  group("left", words.left, icons.left, pxx - 44, pyy - 9, on == "left")
  group("right", words.right, icons.right, pxx + 44, pyy - 9, on == "right")
end

function UI.steam(x, y, n, len, phase)
  UI.inkPush("gray")
  gfx.setColor(BLACK)
  for i = 1, n do
    local sx = x + (i - (n + 1) / 2) * 9
    local px, py
    for yy = y, y - len, -3 do
      local xx = sx + math.floor(math.sin(frames * 0.18 + yy * 0.45 + i * 1.7 + (phase or 0)) * 2.2 + 0.5)
      if px then gfx.drawLine(px, py, xx, yy) end
      px, py = xx, yy
    end
  end
  UI.inkPop()
end
-- a chunky mug (flat top, handle on the right); `pat` fills the drink inside (nil = empty)
function UI.mug(cx, top, w, h, pat, handle, fillTo)
  local x = cx - math.floor(w / (2))
  UI.inkPush("mugc")
  if handle then
    gfx.setColor(BLACK); gfx.setLineWidth(4)
    gfx.drawCircleAtPoint(x + w + 2, top + math.floor(h / (2)) - 1, math.floor(h / (4)) + 2)
    gfx.setLineWidth(1)
  end
  gfx.setColor(BLACK); gfx.fillRoundRect(x, top, w, h, 8)
  gfx.setColor(WHITE); gfx.fillRoundRect(x + 3, top + 3, w - 6, h - 6, 6)
  gfx.setColor(BLACK); gfx.fillRect(x - 1, top, w + 2, 4)                       -- the rim
  if pat then
    UI.ink("none")
    local dTop = fillTo or (top + 8)
    gfx.setPattern(pat); gfx.fillRoundRect(x + 5, dTop, w - 10, top + h - 5 - dTop, 4); gfx.setColor(BLACK)
    gfx.setColor(WHITE); gfx.fillRect(x + 8, dTop + 4, 2, top + h - dTop - 14); gfx.setColor(BLACK)      -- a shine on the glass
  end
  UI.inkPop()
end
function UI.saucer(cx, y, w)
  UI.inkPush("mugc")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - math.floor(w / (2)), y, w, 6, 3)
  gfx.setColor(WHITE); gfx.drawLine(cx - math.floor(w / (2)) + 5, y + 2, cx + math.floor(w / (2)) - 6, y + 2); gfx.setColor(BLACK)
  UI.inkPop()
end
function UI.plaque(cx, y, w, txt)                                        -- a little name plate
  w = math.max(w, UI.textW(txt, true) + 22)
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - math.floor(w / (2)), y, w, 17, 5)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid(txt, cx, y + 8.5, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end
function UI.tiltIcon(x, y, ang)                                         -- a plain "rotate" symbol: a turn-arrow round a tilting bar
  gfx.setColor(BLACK)
  UI.turnRing(x, y, 22, 25, 8)
  local a = math.rad(ang)                                                   -- the bar tips over as you tilt
  local bx, by = math.cos(a) * 11, math.sin(a) * 11
  UI.thickLine(math.floor(x - bx + 0.5), math.floor(y - by + 0.5), math.floor(x + bx + 0.5), math.floor(y + by + 0.5), 3.4)
  gfx.setColor(WHITE)
  UI.disc(x, y, 1.9)                                                        -- a pivot dot in the middle of the bar
  gfx.setColor(BLACK)
end

function UI.patCircle(cx, cy, r, pat)                                    -- a filled circle in a pattern (row by row)
  gfx.setPattern(pat)
  for dy = -r, r do
    local dx = math.floor(math.sqrt(r * r - dy * dy) + 0.5)
    gfx.fillRect(cx - dx, cy + dy, 2 * dx + 1, 1)
  end
  gfx.setColor(BLACK)
end

UI.TICK = { "...........kk", "..........kkk", ".........kkk.", "kk......kkk..", "kkk....kkk...", ".kkk..kkk....", "..kkkkkk.....", "...kkkk......", "....kk......." }      -- the register's tick: a crisp little check mark
local function drawRegister(c)
  local r = c.reg
  drawPanelFrame(c, "REGISTER")
  local x0, y0, kw, kh = 248, 144, 46, 23
  for i = 1, 12 do
    local col, row = (i - 1) % 3, math.floor((i - 1) / (3))
    local kx, ky = x0 + col * kw, y0 + row * kh
    local sel = (r.state == "type" and r.cur == i)
    local label = KEYS[i]
    UI.ink((label == "DEL") and "rred" or ((label == "ENT") and "rsage" or "cushion"))     -- (PC: coloured keys)
    if sel then
      gfx.setColor(BLACK); gfx.fillRoundRect(kx + 2, ky + 3, kw - 5, kh - 5, 5)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      if label == "ENT" then
        UI.pic(UI.TICK, kx + math.floor(kw / (2)) - 6, ky + 8, 1, true)             -- (white on the black key)
        gfx.setColor(BLACK)
      else
        UI.textMid(label, kx + kw / 2 - 0.5, ky + 12, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(WHITE); gfx.drawRoundRect(kx + 4, ky + 5, kw - 9, kh - 9, 3)
      gfx.setColor(BLACK)
    else
      gfx.setColor(BLACK); gfx.fillRoundRect(kx + 2, ky + 3, kw - 5, kh - 5, 5)
      gfx.setColor(WHITE); gfx.fillRoundRect(kx + 2, ky + 1, kw - 5, kh - 6, 5)
      gfx.setColor(BLACK); gfx.drawRoundRect(kx + 2, ky + 1, kw - 5, kh - 6, 5)
      if label == "ENT" then
        UI.ink("inkgreen")
        UI.pic(UI.TICK, kx + math.floor(kw / (2)) - 6, ky + 5, 1)
        UI.ink("rsage")
      else
        UI.textMid(label, kx + kw / 2 - 0.5, ky + 9.5, true)
      end
    end
  end
  -- the till's glass
  UI.ink("lcd")
  gfx.setColor(BLACK); gfx.fillRoundRect(14, 142, 224, 49, 9)
  gfx.setColor(WHITE); gfx.fillRoundRect(19, 147, 214, 39, 6)
  local paid = (r.state ~= "type")
  if not paid then
    drawT("CHARGE", 26, 150, true)
    drawT("$", 104, 150, true)
    UI.bigNum((money(c.price):gsub("%$", "")), 224, 148, 3)
    gfx.setColor(BLACK); UI.dotRow(24, 226, 4, 167)
    drawT("TYPE", 26, 171, true)
    drawT("$", 104, 171, true)
    if r.flash > 0 then
      if (math.floor(frames / (4))) % 2 == 0 then
        gfx.setColor(BLACK); gfx.fillRoundRect(98, 169, 130, 16, 4)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid("WRONG! Try again", 163, 177, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
      end
    else
      UI.bigNum((money(tonumber(r.digits) or 0):gsub("%$", "")), 224, 169, 3)
      if (math.floor(frames / (8))) % 2 == 0 then gfx.setColor(BLACK); gfx.fillRect(227, 169, 2, 15) end
    end
  else
    UI.fancyText(UI.color and "Hold SPACE!" or "Crank to print!", 126, 152, UI.crankAmp("prt", r.crank or 0), 206, true)   -- the big wavy prompt (it wiggles harder as you crank)
  end
  -- the receipt mouth
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.fillRoundRect(14, 194, 224, 11, 4)
  gfx.setColor(WHITE); gfx.fillRect(26, 198, 200, 2)
  UI.ink("white")
  local px0, px1 = 66, 186
  local maxH = 35
  local h = paid and math.floor(clamp(r.crank / 360, 0, 1) * maxH) or 4          -- a corner of paper peeks out while you type
  if h > 0 then
    gfx.setColor(WHITE); gfx.fillRect(px0, 199, px1 - px0, h)
    gfx.setColor(BLACK); gfx.drawLine(px0, 198, px0, 198 + h); gfx.drawLine(px1, 198, px1, 198 + h)
    if paid then
      for i = 0, 14 do                                                                  -- the torn end
        local zx = px0 + i * 8
        gfx.drawLine(zx, 198 + h, zx + 4, 198 + h - 3); gfx.drawLine(zx + 4, 198 + h - 3, zx + 8, 198 + h)
      end
      local ly, widths = 205, { 78, 50, 64 }
      for i = 1, 3 do
        if ly + 5 < 198 + h then gfx.drawLine(px0 + 10, ly, px0 + 10 + widths[i], ly); gfx.drawLine(px0 + 10, ly + 1, px0 + 10 + widths[i], ly + 1) end
        ly = ly + 5
      end
      if h >= maxH - 2 then UI.ink("inkred"); UI.pic(UI.RCPTHEART, 123, 220, 1); UI.ink("white") end
    else
      gfx.drawLine(px0, 198 + h, px1, 198 + h)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  if paid and not UI.color then UI.crankIcon(37, 220, frames * 18, 0.55) end   -- (PC: "Hold SPACE!" says it, no crank picture)
end


-- ---- the pour: a liquid that moves like liquid -----------------------------------------------------------------
-- The surface is a row of 24 little springs (one every 2 pixels across the mug): the stream pushes down where it lands,
-- the push runs out to both sides and bounces off the walls, and it all settles smoothly. Bubbles rise from where the
-- stream goes in and pop at the top, crema builds up while pouring and slowly thins after, drops leap out and fall
-- back. All of it is a few dozen numbers a frame, so the Playdate keeps its 30 frames a second.
UI.POUR_N = 24
UI.FOAMINK = { coffee = "foam", decaf = "foam", tea = "foamt", matcha = "foamm" }      -- (PC: crema on coffee, a paler froth on tea and matcha)
function UI.pourSim(f, flow, dt)
  local N = UI.POUR_N
  local h, v = f.wh, f.wv
  if not h then
    h, v = {}, {}
    for i = 1, N do h[i], v[i] = 0, 0 end
    f.wh, f.wv, f.bub, f.drops, f.foam, f.sw, f.lastFlow = h, v, {}, {}, 0, 0, 0
  end
  local surfY = 221 - math.floor(f.fill * 48)
  if surfY < 173 then surfY = 173 end
  f.lvl = f.lvl and (f.lvl + (surfY - f.lvl) * math.min(1, dt * 10)) or surfY            -- (the level glides up, never jumps)
  -- the stream: its width eases in and out; when the tap shuts, the last of it falls away as a tail
  local want = (flow > 0.66) and 5 or ((flow > 0.33) and 3 or ((flow > 0) and 1 or 0))
  f.sw = f.sw + (want - f.sw) * math.min(1, dt * 9)
  if flow <= 0 and (f.lastFlow or 0) > 0 then f.tail = { top = 163, v = 30, w = math.max(1, math.floor(f.sw + 0.5)) } end
  if f.tail then
    f.tail.v = f.tail.v + 520 * dt
    f.tail.top = f.tail.top + f.tail.v * dt
    if f.tail.top >= f.lvl then                                   -- the last splash as it lands
      local j = math.floor(N / 2)
      v[j] = v[j] + 18; v[j + 1] = v[j + 1] + 18
      f.tail = nil
    end
  end
  -- where the stream lands pushes the surface down (a little unevenly, so it never looks mechanical)
  local j = 12                                                     -- (the stream falls at x 270: between springs 12 and 13)
  if flow > 0 and f.fill > 0.02 then
    local push = (90 + 200 * flow) * dt * (0.7 + math.random() * 0.6)
    v[j] = v[j] + push; v[j + 1] = v[j + 1] + push
    v[j - 1] = v[j - 1] + push * 0.4; v[j + 2] = v[j + 2] + push * 0.4
  end
  local started, stopped = flow > 0 and (f.lastFlow or 0) <= 0, flow <= 0 and (f.lastFlow or 0) > 0
  if started or stopped or math.abs(flow - (f.lastFlow or 0)) > 0.2 then   -- the stream starting or stopping rocks the whole cup: one side up, the other down
    f.rock = -(f.rock or 1)
    local a = f.rock * (stopped and 24 or 12)
    for i = 1, N do v[i] = v[i] + a * math.cos(math.pi * (i - 1) / (N - 1)) + (math.random() - 0.5) * 3 end
  end
  f.lastFlow = flow
  -- the springs: each pulls back to level, gently damped; then the waves spread to the neighbours (twice, so they travel)
  local K, D, S = 70, 1.7, 0.26
  for i = 1, N do
    v[i] = v[i] + (-K * h[i] - D * v[i]) * dt
    h[i] = h[i] + v[i] * dt
  end
  for _ = 1, 2 do
    for i = 1, N - 1 do
      local d = S * (h[i] - h[i + 1])
      v[i] = v[i] - d; v[i + 1] = v[i + 1] + d
      h[i] = h[i] - d * dt; h[i + 1] = h[i + 1] + d * dt
    end
  end
  for i = 1, N do                                                  -- (kept inside the mug)
    if h[i] > 4 then h[i], v[i] = 4, 0 elseif h[i] < -4 then h[i], v[i] = -4, 0 end
  end
  -- crema: builds while pouring, thins slowly after (a thin layer stays)
  if flow > 0 then f.foam = math.min(1, f.foam + dt * 0.9) else f.foam = math.max(0.3, f.foam - dt * 0.12) end
  -- bubbles: born under the stream, they wobble up and pop at the top
  local bub = f.bub
  if flow > 0 and f.fill > 0.12 and #bub < 9 and math.random() < 0.12 + flow * 0.3 then
    bub[#bub + 1] = { x = 270 + math.random(-9, 9), y = math.min(219, f.lvl + 6 + math.random() * 14), vy = 9 + math.random() * 12, r = (math.random() < 0.08) and 2 or 1,
                      ph = math.random() * 6, dx = (math.random() - 0.5) * 8 }
  elseif flow <= 0 and f.fill > 0.15 and #bub < 4 and math.random() < 0.03 then              -- (now and then a lazy one, after)
    bub[#bub + 1] = { x = 250 + math.random() * 40, y = 219, vy = 8 + math.random() * 6, r = 1, ph = math.random() * 6 }
  end
  for i = #bub, 1, -1 do
    local b = bub[i]
    b.y = b.y - b.vy * dt
    b.x = b.x + (b.dx or 0) * dt
    b.ph = b.ph + dt * 5
    if b.pop then
      b.pop = b.pop - dt
      if b.pop <= 0 then table.remove(bub, i) end
    elseif b.y <= UI.pourSurf(f, b.x) + 2 then b.pop = 0.12; b.y = UI.pourSurf(f, b.x) end
  end
  -- drops that leap from where the stream lands, and fall back in
  local drops = f.drops
  if flow > 0.3 and f.fill > 0.05 and #drops < 8 and math.random() < flow * 0.35 then
    drops[#drops + 1] = { x = 270 + math.random(-2, 2), y = f.lvl - 1, vx = (math.random() - 0.5) * 50, vy = -(30 + math.random() * 45 * flow) }
  end
  for i = #drops, 1, -1 do
    local q = drops[i]
    q.vy = q.vy + 260 * dt
    q.px, q.py = q.x, q.y
    q.x, q.y = q.x + q.vx * dt, q.y + q.vy * dt
    if q.x < 248 then q.x, q.vx = 248, -q.vx * 0.5 elseif q.x > 291 then q.x, q.vx = 291, -q.vx * 0.5 end
    if q.vy > 0 and q.y >= UI.pourSurf(f, q.x) then                -- back in: a tiny ripple where it lands
      local k = math.max(1, math.min(N, math.floor((q.x - 247) / 2) + 1))
      v[k] = v[k] + 6
      table.remove(drops, i)
    end
  end
end
function UI.pourRuns(tops, a, b, fn)              -- call fn(x, width, y) once for every run of columns a..b at the same height
  local x0, y0 = a, tops[a]
  for x = a + 1, b + 1 do
    local y = (x <= b) and tops[x] or nil
    if y ~= y0 then fn(x0, x - x0, y0); x0, y0 = x, y end
  end
end
function UI.pourSurf(f, x)                                       -- the surface's height at screen column x
  local h = f.wh
  local l = f.lvl or math.max(173, 221 - math.floor((f.fill or 0) * 48))
  if not h then return l end
  local p = (x - 247) / 2
  local i = math.floor(p)
  local fr = p - i
  local a, b = h[math.max(1, math.min(UI.POUR_N, i + 1))], h[math.max(1, math.min(UI.POUR_N, i + 2))]
  return l + a + (b - a) * fr
end
function UI.pourDraw(f, x, mcx, inTop, inBot, pick)             -- the drink in the mug, the stream, the bubbles and drops
  local lvl = f.lvl or (inBot - math.floor(f.fill * (inBot - inTop)))
  local tops = UI.pourTops or {}
  UI.pourTops = tops
  -- the body: one column per pixel, each up to the wavy surface
  gfx.setColor(BLACK)
  gfx.setPattern(DRINK_PATTERN[pick] or DRINK_PATTERN.coffee)
  if f.fill > 0.005 then
    for dx = x + 5, x + 50 do
      local y = math.floor(UI.pourSurf(f, dx) + 0.5)
      if dx == x + 5 or dx == x + 50 then y = y - 1 end            -- (the drink climbs the wall a hair: a meniscus)
      if y < inTop then y = inTop end
      tops[dx] = y
    end
    UI.pourRuns(tops, x + 5, x + 50, function(x0, w, y) if y <= inBot then gfx.fillRect(x0, y, w, inBot - y + 1) end end)   -- (columns at the same height are one rectangle)
  else
    for dx = x + 5, x + 50 do tops[dx] = inBot + 1 end
  end
  gfx.setColor(BLACK)
  if f.fill > 0.04 then
    -- a darker line along the top of the drink, then the crema: a light, bubbly layer riding the waves
    UI.drinkInk(pick)
    UI.pourRuns(tops, x + 5, x + 50, function(x0, w, y) if y <= inBot then gfx.fillRect(x0, y, w, 1) end end)
    UI.ink(UI.color and (UI.FOAMINK[pick] or "foam") or "none")
    local th = 1 + math.floor(f.foam * 2.2 + 0.5)                -- 1 to 3 pixels thick
    gfx.setColor(WHITE)
    UI.pourRuns(tops, x + 6, x + 49, function(x0, w, y) if y + th <= inBot then gfx.fillRect(x0, y + 1, w, th) end end)
    local drift = math.floor(frames / (5))
    for dx = x + 6, x + 49 do                                      -- (little gaps in it, so it looks bubbly, not painted on; a few bubbles hanging under)
      local hsh = (dx * 37 + drift * ((dx % 3 == 0) and 1 or 0)) % 9
      if hsh == 0 or (th >= 2 and hsh == 4) then
        local y = tops[dx] + 1
        if y + th <= inBot then
          if hsh == 0 then UI.drinkInk(pick); gfx.setColor(BLACK); gfx.drawPixel(dx, y + th - 1); UI.ink(UI.color and (UI.FOAMINK[pick] or "foam") or "none"); gfx.setColor(WHITE)
          else gfx.drawPixel(dx, y + th) end
        end
      end
    end
    -- glints of light sliding along the surface
    gfx.setColor(WHITE)
    local g = math.floor(frames / (3))
    for dx = x + 7, x + 48 do
      if (dx * 5 + g) % 23 < 2 then
        local y = tops[dx] + th + 2
        if y < inBot - 1 then gfx.drawPixel(dx, y) end
      end
    end
    UI.ink("none")
    -- the glass shine down the left side, under the surface
    local sy = math.max(tops[x + 8] or lvl, inTop) + 4
    if inBot - sy > 6 then gfx.setColor(WHITE); gfx.fillRect(x + 8, sy, 2, inBot - sy - 5); gfx.drawPixel(x + 11, sy + 2) end
  end
  -- bubbles rising, and popping at the top
  for _, b in ipairs(f.bub or {}) do
    local bx = math.floor(b.x + math.sin(b.ph) * 1.2 + 0.5) + (mcx - 270)
    local by = math.floor(b.y + 0.5)
    if b.pop then
      gfx.setColor(WHITE); gfx.drawPixel(bx - 1, by - 1); gfx.drawPixel(bx + 1, by - 1); gfx.drawPixel(bx, by - 2)
    elseif by <= inBot - 1 then
      gfx.setColor(WHITE)
      if b.r >= 2 then gfx.drawCircleAtPoint(bx, by, 2) else gfx.drawPixel(bx, by) end
    end
  end
  -- the stream: eases in and out, ripples as it falls, a glint runs down it; a splash crown where it lands
  local sw = f.sw or 0
  local w = math.floor(sw + 0.5)
  local land = math.floor(UI.pourSurf(f, mcx) + 0.5)
  UI.drinkInk(pick)
  gfx.setColor(BLACK)
  if w >= 2 then
    for yy = 163, land, 2 do
      local wob = math.floor(math.sin(yy * 0.09 - frames * 0.32) * 0.55 + 0.5)       -- (a slow, gentle sway down the stream)
      local ww = w + ((yy < 168) and 1 or 0)                       -- (a touch wider right at the spout)
      if yy > land - 6 and w >= 3 then ww = ww + 1 end             -- (and it spreads a little as it hits)
      gfx.fillRect(mcx - math.floor(ww / (2)) + wob, yy, ww, math.min(2, land - yy + 1))
    end
  elseif w >= 1 then                                               -- a thin trickle: drips running down, not a wire
    local o = (frames * 3) % 6
    for yy = 163 + o, land, 6 do gfx.fillRect(mcx, yy, 1, math.min(3, land - yy + 1)) end
    gfx.fillRect(mcx, 163, 1, 2)
    if w >= 3 then
      gfx.setColor(WHITE)
      for yy = 164 + (frames * 3) % 7, land - 3, 7 do gfx.fillRect(mcx - 1 + ((w >= 5) and 1 or 0), yy, 1, 3) end
      gfx.setColor(BLACK)
      local k = (math.floor(frames / (2))) % 3                    -- the crown: drink thrown up either side of the stream
      gfx.drawPixel(mcx - w - 1 - k, land - 1 - k); gfx.drawPixel(mcx + w + k, land - 1 - k)
      if w >= 5 then gfx.drawPixel(mcx - w - 2, land - 3 + k); gfx.drawPixel(mcx + w + 1, land - 3 + k) end
    end
  end
  if f.tail then                                                    -- the last of the stream, falling away
    local t0 = math.floor(f.tail.top)
    local t1 = math.min(land, t0 + 10 + math.floor(f.tail.v / 40))
    if t1 > t0 then gfx.fillRect(mcx - math.floor(f.tail.w / (2)), t0, f.tail.w, t1 - t0) end
  end
  -- drops in flight (a pixel of trail behind each)
  for _, q in ipairs(f.drops or {}) do
    local qx, qy = math.floor(q.x + 0.5) + (mcx - 270), math.floor(q.y + 0.5)
    gfx.fillRect(qx, qy, 2, 2)
    if q.py then gfx.drawPixel(math.floor(q.px + 0.5) + (mcx - 270), math.floor(q.py + 0.5)) end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function UI.sunA(x, y)                          -- the A button: a ring round the A with little rays, like a sun
  UI.inkPush("flame")
  local pulse = (math.floor(frames / (6))) % 2
  if UI.color then                              -- (PC: the space bar does it, so a little space bar key sits in the middle)
    local down = (math.floor(frames / (12))) % 4 == 0                              -- the key bobs down now and then, as if pressed
    local ky = y - 6 + (down and 1 or 0)
    UI.ink("slate")
    gfx.setColor(BLACK); gfx.fillRoundRect(x - 15, y - 6 + 2, 30, 14, 4)          -- the key's side
    UI.ink("white")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 14, ky, 28, 11, 3)                  -- its top
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 15, ky - 1, 30, 13, 4)
    UI.ink("slate")
    gfx.drawLine(x - 7, ky + 4, x - 7, ky + 6); gfx.drawLine(x - 7, ky + 6, x + 7, ky + 6); gfx.drawLine(x + 7, ky + 6, x + 7, ky + 4)   -- the space sign
    UI.ink("flame")
    for i = 0, 11 do                                                                -- (the rays start clear of the key, so none of them touch its edge)
      local ang = math.rad(i * 30 + (pulse == 0 and 0 or 7))
      local r0, r1 = 21, (i % 2 == 0) and 26 or 24
      if pulse == 1 then r1 = r1 - 1 end
      gfx.drawLine(math.floor(x + math.cos(ang) * r0 + 0.5), math.floor(y + 1 + math.sin(ang) * r0 * 0.8 + 0.5),
                   math.floor(x + math.cos(ang) * r1 + 0.5), math.floor(y + 1 + math.sin(ang) * r1 * 0.8 + 0.5))
    end
    UI.inkPop()
    return
  end
  local down = (math.floor(frames / (10))) % 5 == 0                                  -- it presses itself now and then, as a hint
  local fy = y - 1 + (down and 2 or 0)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(x, y + 2, 13)                            -- the button's side (its shadow)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, fy, 11)                               -- its face
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(x, fy, 12); gfx.setLineWidth(1)
  drawTC("A", x, fy - 8, true)
  local spin = frames * 0.06                                                           -- a ring of dashes turning round it
  for i = 0, 9 do
    local ang = spin + i * math.pi / 5
    local r0, r1 = 17, 21 - pulse
    gfx.setLineWidth(2)
    gfx.drawLine(math.floor(x + math.cos(ang) * r0 + 0.5), math.floor(y + 1 + math.sin(ang) * r0 + 0.5),
                 math.floor(x + math.cos(ang) * r1 + 0.5), math.floor(y + 1 + math.sin(ang) * r1 + 0.5))
    gfx.setLineWidth(1)
  end
  UI.inkPop()
end

-- A small d-pad with the words around it (up above, down below, left and right
-- beside it). `on` = "up" / "down" / "left" / "right" boxes that word.
function UI.drawSmallPad(px, py, words, on)
  -- a rounded cross with a drop shadow, a bevel along its top edges, a dimple in the middle and crisp arrows
  local function cross(ox, oy, r)
    gfx.fillRoundRect(px - 13 + ox, py - 27 + oy, 26, 54, r)
    gfx.fillRoundRect(px - 39 + ox, py - 13 + oy, 78, 26, r)
  end
  gfx.setColor(BLACK); gfx.setPattern(CHECK); cross(2, 3, 5)                -- its shadow
  gfx.setColor(BLACK); cross(0, 0, 5)                                         -- the pad
  gfx.setColor(WHITE)                                                         -- the bevel: a fine light line along the top of each arm
  gfx.drawLine(px - 10, py - 25, px + 10, py - 25)
  gfx.drawLine(px - 37, py - 11, px - 15, py - 11); gfx.drawLine(px + 15, py - 11, px + 37, py - 11)
  gfx.drawLine(px - 37, py - 10, px - 37, py + 9); gfx.drawLine(px - 11, py - 25, px - 11, py - 14)
  for _, arm in ipairs({ { "up", px - 13, py - 27, 26, 15 }, { "down", px - 13, py + 12, 26, 15 }, { "left", px - 39, py - 13, 15, 26 }, { "right", px + 24, py - 13, 15, 26 } }) do
    if on == arm[1] then                                                     -- the pressed arm lights up
      gfx.setColor(WHITE); gfx.fillRoundRect(arm[2] + 2, arm[3] + 2, arm[4] - 4, arm[5] - 4, 3)
    end
  end
  gfx.setColor(WHITE); gfx.drawCircleAtPoint(px, py, 5)                      -- the dimple
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(px, py, 3)
  gfx.setColor(WHITE); gfx.drawPixel(px - 1, py - 1)
  local function arrow(x1, y1, x2, y2, x3, y3, lit)
    gfx.setColor(lit and BLACK or WHITE)
    gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  end
  arrow(px, py - 23, px - 5, py - 17, px + 5, py - 17, on == "up")
  arrow(px, py + 23, px - 5, py + 17, px + 5, py + 17, on == "down")
  arrow(px - 35, py, px - 29, py - 5, px - 29, py + 5, on == "left")
  arrow(px + 35, py, px + 29, py - 5, px + 29, py + 5, on == "right")
  gfx.setColor(BLACK)
  -- the words
  local function word(txt, x, ty, align, lit)
    gfx.setFont(fontBold)
    local tw = gfx.getTextSize(txt)
    local left = x - math.floor(tw / (2))                      -- centred
    if align == "left" then left = x elseif align == "right" then left = x - tw end
    if lit then
      gfx.setColor(BLACK)
      gfx.fillRoundRect(left - 4, ty - 1, tw + 8, 17, 4)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawT(txt, left, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end
  if words.up then word(words.up, px + (words.upDx or 0), py - 46, "center", on == "up") end
  if words.down then word(words.down, px, py + 30, "center", on == "down") end
  if words.left then word(words.left, px - 45, py - 8, "right", on == "left") end
  if words.right then word(words.right, px + 45, py - 8, "left", on == "right") end
end

UI.PICK_KEY_SIDE = { coffee = "up", decaf = "down", tea = "left", matcha = "right" }

local function drawCoffee(c)
  local f = c.cof
  drawPanelFrame(c, "COFFEE")
  if f.phase == "pick" then
    local sp = UI.SPECIAL[UI.season() or ""]                                          -- (the matcha button is the season's drink while its music is on)
    UI.padWords(112, 189, { up = "COFFEE", down = "DECAF", left = "TEA", right = sp and sp.word or "MATCHA" },
      { up = "bean", down = "decaf", left = "tea", right = sp and sp.icon or "matcha" }, f.pick and UI.PICK_KEY_SIDE[f.pick] or nil)
    UI.sunA(272, 178)
    drawTC("POUR", 272, 206, true)
    local mx = 345                                                                    -- the cup that shows what you picked
    if f.pick then UI.steam(mx, 164, 3, 14) end
    UI.mug(mx, 168, 46, 40, f.pick and DRINK_PATTERN[f.pick] or nil, true)
    UI.saucer(mx - 2, 208, 66)
    UI.plaque(mx - 2, 218, 84, f.pick and ((f.pick == "matcha" and sp) and sp.word or string.upper(f.pick)) or "PICK ONE")
    return
  end
  -- ---- pouring (the same picture for tilt and for crank; only the control on the left and the gauge differ) ----
  local crank = (UI.crankPour == true)
  local mcx = 270
  local top, bot = 168, 225
  local inTop, inBot = 173, 221
  local surface = inBot - math.floor(f.fill * (inBot - inTop))
  if surface < inTop then surface = inTop end
  local flow = f.tilt or 0
  -- left: what to do
  if crank then
    local amp = UI.crankAmp("pour", (f.valve or 0) * 180)
    UI.fancyText(UI.color and "Hold" or "Crank", 80, UI.color and 152 or 150, amp, 140, true)
    UI.fancyText(UI.color and "SPACE!" or "to pour!", 80, UI.color and 176 or 174, amp, 140, true)
    if not UI.color then UI.crankIcon(150, 216, (f.valve or 0) * 180 + 25, 0.55) end
  else
    drawT("Tilt Playdate", 16, 144, true)
    drawT("down to pour.", 16, 160, true)
    UI.tiltIcon(40, 206, 8 + 40 * flow)
  end
  -- the coffee machine head with its dial, buttons and spout
  local na = math.rad(200 + 140 * flow)
  if UI.color then                                                                   -- PC: a brushed silver head, a white dial with a black arm
    UI.ink("silver")
    gfx.setColor(WHITE); gfx.fillRoundRect(mcx - 30, 140, 60, 15, 4)
    gfx.setColor(BLACK); gfx.drawRoundRect(mcx - 30, 140, 60, 15, 4)
    gfx.fillRect(mcx + 0, 144, 16, 2); gfx.fillRect(mcx + 0, 148, 10, 2); gfx.fillCircleAtPoint(mcx + 22, 148, 2)
    UI.ink("none")
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(mcx - 19, 148, 5)
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(mcx - 19, 148, 5); gfx.setLineWidth(2)
    gfx.drawLine(mcx - 19, 148, math.floor(mcx - 19 + math.cos(na) * 4 + 0.5), math.floor(148 + math.sin(na) * 4 + 0.5)); gfx.setLineWidth(1)
  else
    gfx.setColor(BLACK); gfx.fillRoundRect(mcx - 30, 140, 60, 15, 4)
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(mcx - 19, 148, 5)
    gfx.setColor(BLACK); gfx.setLineWidth(2)
    gfx.drawLine(mcx - 19, 148, math.floor(mcx - 19 + math.cos(na) * 4 + 0.5), math.floor(148 + math.sin(na) * 4 + 0.5)); gfx.setLineWidth(1)
    gfx.setColor(WHITE); gfx.fillRect(mcx + 0, 144, 16, 2); gfx.fillRect(mcx + 0, 148, 10, 2); gfx.fillCircleAtPoint(mcx + 22, 148, 2)
  end
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.fillRect(mcx - 8, 155, 16, 5); gfx.fillRect(mcx - 3, 160, 6, 3)
  if flow <= 0 and f.fill > 0.05 and (math.floor(frames / (10))) % 2 == 0 then gfx.fillRect(mcx - 1, 165 + math.floor((frames % 10) / (3)), 2, 3) end   -- a last drip
  -- the drip tray and the mug
  UI.ink("gray")
  gfx.setColor(BLACK); gfx.fillRoundRect(mcx - 46, 226, 92, 8, 3)
  gfx.setColor(WHITE); for dx = -38, 34, 8 do gfx.fillRect(mcx + dx, 229, 4, 2) end
  local x = mcx - 28
  UI.ink("mugc")
  gfx.setColor(BLACK); gfx.setLineWidth(4); gfx.drawCircleAtPoint(x + 60, 197, 13); gfx.setLineWidth(1)
  gfx.fillRoundRect(x, top, 56, bot - top, 9)
  gfx.setColor(WHITE); gfx.fillRoundRect(x + 3, top + 3, 50, bot - top - 6, 7)
  gfx.setColor(BLACK); gfx.fillRect(x - 1, top, 58, 4)
  UI.ink("none")
  -- the drink: a sloshing surface, crema, bubbles, the stream and its splashes (see UI.pourSim)
  UI.pourDraw(f, x, mcx, inTop, inBot, f.pick)
  -- the size marks: the one the order wants is a flag pointing at the mug
  local sz = c.order.size or 3
  UI.ink("inkred")
  for i = 1, 3 do
    local ly = inBot - math.floor(UI.SIZE_FILL[i] * (inBot - inTop))
    gfx.setColor(BLACK)
    if i == sz then
      for dx = x + 5, x + 49, 6 do gfx.drawLine(dx, ly, dx + 3, ly) end
      local label = string.upper(UI.SIZE_NAME[i])
      local fw = UI.textW(label, true) + 12
      gfx.fillRoundRect(x - 11 - fw, ly - 8, fw, 16, 4)
      gfx.fillTriangle(x - 12, ly - 8, x - 12, ly + 8, x - 3, ly)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid(label, x - 11 - fw / 2, ly, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
    else
      gfx.drawLine(x - 8, ly, x - 2, ly)
    end
  end
  UI.drinkInk(f.pick)                                                                -- (PC: a spill is the drink's colour)
  if f.fill > 1.2 then gfx.fillRect(x - 3, 200, 3, 24); gfx.fillRect(x + 57, 214, 3, 14) end
  UI.ink("none")
  if f.fill > 0.3 then UI.steam(mcx - 21, top - 4, 1, 10); UI.steam(mcx + 21, top - 4, 1, 10, 2) end
  -- the gauge on the right: how far you are tilting, or how far the tap is open
  local gx = 350
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(gx, 160, 24, 68, 5); gfx.setLineWidth(1)
  local lvl = crank and (f.valve or 0) or flow
  local h = math.floor(56 * lvl)
  UI.drinkInk(f.pick)
  gfx.fillRoundRect(gx + 4, 224 - h, 16, h, 2)
  UI.ink("none")
  gfx.setColor(WHITE); for i = 1, 4 do gfx.drawLine(gx + 4, 224 - i * 14, gx + 9, 224 - i * 14) end
  gfx.setColor(BLACK); for i = 1, 4 do gfx.drawLine(gx - 5, 224 - i * 14, gx - 1, 224 - i * 14) end
  if crank then                                                                      -- the tap handle riding on the gauge
    gfx.fillCircleAtPoint(gx + 12, 224 - h, 9)
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(gx + 12, 224 - h, 6); gfx.setColor(BLACK); gfx.fillCircleAtPoint(gx + 12, 224 - h, 3)
  end
end


-- big sticker letters: white with a thick black edge and a drop shadow, each one bobbing on its own wave.
-- (each letter is drawn once into a little picture, then just stamped.) amp = 0 .. 1: how lively the wiggle is
UI.fancyCache = {}
UI.FX_RAINBOW = { "fx_red", "fx_orange", "fx_yellow", "fx_green", "fx_blue", "fx_purple", "fx_pink" }
UI.FX_GIFT = { tips = { "fx_yellow", "fx_orange", "fx_yellow", "fx_green" }, stars = { "fx_pink", "fx_purple", "fx_blue", "fx_pink" },
               flash = { "fx_red", "fx_orange", "fx_yellow", "fx_red" } }
function UI.fancyLetter(ch)
  local key = ch .. UI.inkKey()                -- (PC: one copy of each letter per colour, so a letter never keeps the colour it was first drawn in)
  local e = UI.fancyCache[key]
  if e ~= nil then return e end
  gfx.setFont(fontBold)
  local w, h = gfx.getTextSize(ch)
  e = { w = w, h = h }
  if ch ~= " " then
    local ok = pcall(function()
      local base = gfx.image.new(w, h, gfx.kColorClear)
      gfx.pushContext(base)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setFont(fontBold)
      gfx.drawText(ch, 0, 0)
      gfx.popContext()
      local img = gfx.image.new(w * 2 + 8, h * 2 + 8, gfx.kColorClear)
      gfx.pushContext(img)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      for dy = -2, 4 do
        for dx = -2, 4 do
          local edge = math.abs(dx) + math.abs(dy) <= 2
          local shadow = dx >= 1 and dy >= 2 and dx <= 3 and dy <= 4
          if edge or shadow then base:drawScaled(3 + dx, 3 + dy, 2) end
        end
      end
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      base:drawScaled(3, 3, 2)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.popContext()
      e.img = img
    end)
    if not ok then e.img = nil end
  end
  UI.fancyCache[key] = e
  return e
end
function UI.crankAmp(key, v)                    -- how hard the crank is going right now (0..1, smoothed), from a running total of degrees
  local last = UI["ampL" .. key] or v
  UI["ampL" .. key] = v
  local a = (UI["ampA" .. key] or 0) * 0.85 + math.min(math.abs(v - last) / 25, 1) * 0.15
  UI["ampA" .. key] = a
  return a
end
UI.fancyWarmI = 33
function UI.fancyWarm()                             -- (PD: the big wavy letters are made ahead, one a frame, so none is first built mid-game:
  if UI.color or UI.fancyWarmI > 126 then return end   --  once the title's pictures are in, while nobody is pressing buttons and the frame has time)
  if trans ~= nil or (UI.idle or 0) < 8 or not UI.titleReady() or not UI.loadRoom() then return end
  UI.loadN = UI.loadN + 1
  local f = gfx.getFont()
  UI.fancyLetter(string.char(UI.fancyWarmI))
  UI.fancyWarmI = UI.fancyWarmI + 1
  if f then gfx.setFont(f) end
end
function UI.fancyText(str, cx, y, amp, maxW, noSpark, cols)   -- cols (PC): colours that ripple along the letters, changing as it goes
  amp = amp or 0
  if not UI.color then cols = nil end
  local total = 0
  for i = 1, #str do total = total + UI.fancyLetter(string.sub(str, i, i)).w * 2 + 1 end
  local k = math.min(1, (maxW or 190) / math.max(total, 1))                    -- (squeezed a little if the font runs wide)
  total = math.floor(total * k + 0.5)
  local x = cx - math.floor(total / (2))
  local a = 1.4 + 1.6 * amp                                                    -- wave height (a little more while cranking)
  for i = 1, #str do
    if cols then UI.inkPush(cols[(i + math.floor(frames / (5))) % #cols + 1]) end
    local e = UI.fancyLetter(string.sub(str, i, i))
    if cols then UI.inkPop() end
    local dy = math.floor(math.sin(frames * (0.22 + 0.18 * amp) - i * 0.65) * a + 0.5)
    local dx = (amp > 0.25 and (math.floor(frames / (3)) + i) % 2 == 0) and 1 or 0     -- (a jiggle side to side as it mixes)
    if e.img then
      if k < 1 then                                                            -- (squeezed: the shrunk letter is made once and kept, scaling every frame is slow)
        local kq = math.floor(k * 100 + 0.5)
        e.sc = e.sc or {}
        local si = e.sc[kq]
        if si == nil then si = (e.img.scaledImage and e.img:scaledImage(kq / 100)) or false; e.sc[kq] = si end
        if si then si:draw(math.floor(x - 3 * k + dx + 0.5), y - 3 + dy) else e.img:drawScaled(math.floor(x - 3 * k + dx + 0.5), y - 3 + dy, k) end
      else e.img:draw(x - 3 + dx, y - 3 + dy) end
    elseif e.w > 0 then drawT(string.sub(str, i, i), x + dx, y + dy, true) end
    x = x + (e.w * 2 + 1) * k
  end
  -- two little sparkles that twinkle at the ends
  gfx.setColor(BLACK)
  if noSpark then return end
  for side = -1, 1, 2 do
    local k = (math.floor(frames / (4)) + ((side > 0) and 3 or 0)) % 6
    local sx, sy = cx + side * (math.floor(total / (2)) + 8), y + 12 + ((side > 0) and -6 or 4)
    local r = (k < 3) and k + 1 or 6 - k
    gfx.drawLine(sx - r, sy, sx + r, sy); gfx.drawLine(sx, sy - r, sx, sy + r)
    if r >= 3 then gfx.drawPixel(sx - 1, sy - 1); gfx.drawPixel(sx + 1, sy - 1); gfx.drawPixel(sx - 1, sy + 1); gfx.drawPixel(sx + 1, sy + 1) end
  end
end

-- what's still missing from the order (they vanish from the black bar as you add them)
function UI.mixHeader(o, m)
  local items = {}
  local function need(n, one, many)
    if n > 0 then items[#items + 1] = n .. " " .. (n == 1 and one or many) end
  end
  need(o.shot - m.shot, "shot", "shots")
  need(o.milk - m.milk, "milk", "milk")
  need(o.sugar - m.sugar, "sugar", "sugar")
  need(o.ice - m.ice, "ice", "ice")
  if m.phase == 2 then return "Mixing it up!" end
  if #items == 0 then return "Ready to mix!" end
  return table.concat(items, ", ")
end

local function drawMixer(c)
  local m, o = c.mix, c.order
  drawPanelFrame(c, "MIXER", UI.mixHeader(c.order, m))
  local cx, cy = 333, 191
  local a = math.rad(m.angle or 0)
  local mixing = (m.phase == 2)
  local mixed = mixing and m.progress >= 0.6
  -- the saucer, the handle and the cup seen from above
  UI.ink("mugc")
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 44)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 41)
  gfx.setColor(BLACK); gfx.fillRoundRect(cx + 30, cy - 10, 24, 20, 8)
  gfx.setColor(WHITE); gfx.fillRoundRect(cx + 36, cy - 4, 12, 8, 3)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 39)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 36)
  UI.drinkInk(o.kind)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 34)                             -- the drink
  if mixed and m.milk > 0 then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 34); gfx.setColor(BLACK); UI.patCircle(cx, cy, 34, CHECK) end
  gfx.setColor(WHITE)
  -- ingredients ride round the cup; dotted rings show what the order still wants
  local function slot(i, n, R, off, spin)
    local t = a * spin + (i - 1) * (2 * math.pi / math.max(n, 1)) + off
    return math.floor(cx + R * math.cos(t) + 0.5), math.floor(cy + R * math.sin(t) + 0.5)
  end
  local function row(kind, have, want, R, off, spin, draw)
    local n = math.max(have, want)                                  -- (spots stay put as the order's own amount is added)
    for i = 1, math.min(have, n) do
      local px, py = slot(i, n, R, off, spin)
      if not (mixed and kind ~= "ice") then draw(px, py) end
    end
  end
  row("shot", m.shot, o.shot, 11, 2.0, 1.3,
    function(x, y) UI.ink("coffee"); gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 6); gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawLine(x - 3, y + 3, x + 3, y - 3); gfx.setLineWidth(1); gfx.setColor(WHITE) end)
  row("milk", m.milk, o.milk, 22, 0.0, 1.0,
    function(x, y) UI.ink("snow"); gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 7); gfx.setColor(BLACK); gfx.drawLine(x - 4, y - 1, x - 2, y - 4); gfx.drawLine(x - 4, y, x - 3, y - 3); gfx.setColor(WHITE) end)
  row("sugar", m.sugar, o.sugar, 27, 0.5, -0.7,
    function(x, y) UI.ink("white"); gfx.setColor(WHITE); gfx.fillRect(x - 4, y - 4, 9, 9); gfx.setColor(BLACK); gfx.drawPixel(x - 1, y - 1); gfx.drawPixel(x + 1, y + 1); gfx.drawPixel(x - 1, y + 2); gfx.setColor(WHITE) end)
  row("ice", m.ice, o.ice, 17, 1.0, 0.4,
    function(x, y) UI.ink("water"); gfx.setColor(BLACK); gfx.fillRect(x - 5, y - 5, 11, 11); gfx.setColor(WHITE); gfx.setLineWidth(2); gfx.drawRect(x - 5, y - 5, 11, 11); gfx.setLineWidth(1); gfx.drawLine(x - 2, y - 2, x - 2, y + 1); gfx.drawLine(x - 2, y - 2, x + 1, y - 2) end)
  UI.drinkInk(o.kind)
  if mixing and not mixed then                                                       -- a swirl chasing the spoon
    gfx.setColor(WHITE)
    for i = 0, 22 do
      local t = a - i * 0.14
      local rr = 5 + (22 - i) * 1.3
      gfx.drawPixel(math.floor(cx + rr * math.cos(t) + 0.5), math.floor(cy + rr * math.sin(t) + 0.5))
    end
  end
  -- the spoon that turns with the crank
  local ex, ey = math.floor(cx + 29 * math.cos(a) + 0.5), math.floor(cy + 29 * math.sin(a) + 0.5)
  local fx, fy = math.floor(cx - 9 * math.cos(a) + 0.5), math.floor(cy - 9 * math.sin(a) + 0.5)
  UI.ink("gray")
  gfx.setColor(BLACK); gfx.setLineWidth(6); gfx.drawLine(fx, fy, ex, ey); gfx.setLineWidth(1)
  gfx.setColor(WHITE); gfx.setLineWidth(3); gfx.drawLine(fx, fy, ex, ey); gfx.setLineWidth(1)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(ex, ey, 8)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(ex, ey, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(ex, ey, 2)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 5); gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 2)
  UI.ink("none")
  -- left side
  if m.phase == 1 then
    if UI.mixHeader(o, m) == "Ready to mix!" then                                   -- everything's in: a big wavy "Ready to mix!" and an arrow to the button
      UI.ink("fx_green")                                                            -- (PC: all in green)
      UI.fancyText("Ready", 112, 154, 0.15, 180, true)
      UI.fancyText("to mix!", 112, 180, 0.15, 180)
      UI.ink("none")
      local ax = 204 + (math.floor(frames / (5))) % 4                              -- the arrow nudges toward the button
      UI.pic(UI.ARROWR, ax, 172)
      gfx.setColor(BLACK)
    else
      UI.padWords(112, 189, { up = "SHOT", down = "ICE", left = "MILK", right = "SUGAR" },
        { up = "shot", down = "ice", left = "milk", right = "sugar" }, nil)
    end
    UI.sunA(254, 178)
    drawTC("MIX", 254, 206, true)
  else
    -- how hard the crank is going: the letters wiggle more the faster it turns
    local spd = math.abs((m.angle or 0) - (UI.mixLastA or (m.angle or 0)))
    UI.mixLastA = m.angle or 0
    UI.mixAmp = (UI.mixAmp or 0) * 0.85 + math.min(spd / 25, 1) * 0.15
    UI.fancyText(UI.color and "Hold SPACE!" or "Crank to mix!", 112, UI.color and 160 or 150, UI.mixAmp, 184)
    local pw = 168
    local bx0, by0 = 114 - math.floor(pw / (2)), 196
    UI.ink("leaf")
    gfx.setColor(BLACK); gfx.fillRoundRect(bx0, by0, pw, 20, 7)
    gfx.setColor(WHITE); gfx.fillRoundRect(bx0 + 3, by0 + 3, pw - 6, 14, 5)
    UI.ink("inkgreen")
    local prog = clamp(m.progress, 0, 1)
    local segs = 14
    local sw = math.floor((pw - 12) / (segs))
    local lit = math.floor(prog * segs + 0.001)
    local shine = (math.floor(frames / (2))) % (segs + 8)                     -- a glint that runs along the filled part
    for i = 1, segs do
      local sx = bx0 + 6 + (i - 1) * sw
      if i <= lit then
        gfx.setColor(BLACK); gfx.fillRoundRect(sx, by0 + 6, sw - 2, 8, 2)
        if i == shine then gfx.setColor(WHITE); gfx.drawLine(sx + 1, by0 + 7, sx + sw - 5, by0 + 7) end
      end
    end
    UI.ink("none")
    gfx.setColor(BLACK)
    if not UI.color then UI.crankIcon(244, 192, frames * 18) end
  end
end


UI.ICECUBES = { { -7, 202 }, { 1, 206 }, { -5, 214 }, { 2, 218 } }
local function drawServe(c)
  local s = c.srv
  drawPanelFrame(c, "PICK UP")
  -- the striped awning
  UI.ink("inkred")
  local function awning(ox, oy)
    gfx.setClipRect(10 - ox, 140 - oy, 380, 24)
    for i = 0, 18 do
      local x = 10 + i * 20 - ox
      gfx.setColor((i % 2 == 0) and BLACK or WHITE)
      gfx.fillRect(x, 140 - oy, 20, 6)
      gfx.fillCircleAtPoint(x + 10, 146 - oy, 10)
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + 10, 146 - oy, 10)
    end
    gfx.clearClipRect()
    gfx.setColor(BLACK); gfx.fillRect(10 - ox, 138 - oy, 380, 3)
  end
  local aw = (not UI.color) and UI.cacheImg("awning", 0, 0, 380, 26, function() awning(10, 138) end)   -- (PD: drawn once, then stamped)
  if aw then UI.cacheDraw(aw, 10, 138) else awning(0, 0) end
  UI.ink("none")
  -- words
  if s.phase <= 2 then
    if s.slide < 1 then drawT("Here it comes...", 16, 166, true)
    else                                                                          -- big wavy words, like the other stations (clear of the cup on the ledge)
      UI.ink("fx_yellow")
      UI.fancyText(UI.color and "SPACE" or "Press A", 86, 160, 0.3, 148, true)
      UI.fancyText("to ring!", 86, 184, 0.3, 148)
      UI.ink("none")
    end
  else
    UI.fancyText("Order up!", 112, 172, 0.7, 190, nil, UI.FX_RAINBOW)
  end
  -- the ledge
  UI.ink("woodl")
  gfx.setColor(BLACK); gfx.fillRect(10, 226, 380, 8)
  gfx.setColor(WHITE)
  UI.dotRow(12, 386, 6, 229, true)
  UI.ink("none")
  gfx.setColor(BLACK)
  -- the drink slides in along the ledge
  local p = s.slide or 1                                                             -- the cup glides in: quick, then easing to a stop
  local e = (p >= 1) and 1 or (1 + 2.6 * (p - 1) ^ 3 + 1.6 * (p - 1) ^ 2)              -- (a hair past the mark, then settling back)
  local cx = 52 + math.floor(e * 130 + 0.5)
  if s.phase <= 2 and p > 0.04 and p < 0.75 then                                     -- streaks of motion behind it
    gfx.setColor(BLACK)
    local fade = 1 - p / 0.75
    for k = 0, 2 do
      local len = math.floor((10 + k * 4) * fade + 0.5)
      if len > 1 then gfx.drawLine(cx - 18 - len, 204 + k * 7, cx - 18, 204 + k * 7) end
    end
  end
  if s.phase > 2 then
    -- picked up: the ledge is bare
  elseif c.order.ice > 0 then
    UI.ink("glass")
    gfx.setColor(WHITE); gfx.fillPolygon(cx - 12, 192, cx + 12, 192, cx + 9, 226, cx - 9, 226)
    UI.ink("none")
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"]); gfx.fillPolygon(cx - 11, 200, cx + 11, 200, cx + 9, 225, cx - 9, 225)
    UI.ink("snow")
    gfx.setColor(WHITE)
    for _, q in ipairs(UI.ICECUBES) do gfx.fillRect(cx + q[1], q[2], 7, 7) end
    gfx.setColor(BLACK)
    for _, q in ipairs(UI.ICECUBES) do gfx.drawRect(cx + q[1], q[2], 7, 7) end
    UI.ink("slate")
    gfx.setLineWidth(2); gfx.drawPolygon(cx - 12, 192, cx + 12, 192, cx + 9, 226, cx - 9, 226)
    gfx.fillRect(cx - 14, 190, 28, 3)                                              -- the lid
    UI.ink("inkred")
    gfx.setLineWidth(3); gfx.drawLine(cx + 2, 223, cx + 8, 180); gfx.drawLine(cx + 8, 180, cx + 14, 177); gfx.setLineWidth(1)
    UI.ink("none")
  else
    UI.ink("mugc")
    gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawCircleAtPoint(cx + 16, 211, 6); gfx.setLineWidth(1)
    gfx.fillRoundRect(cx - 13, 197, 26, 29, 4)
    gfx.setColor(WHITE); gfx.fillRoundRect(cx - 11, 199, 22, 25, 3)
    UI.ink("none")
    gfx.setColor(BLACK); gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"]); gfx.fillRect(cx - 9, 204, 18, 18); gfx.setColor(BLACK)
    UI.ink("mugc")
    gfx.fillRect(cx - 14, 197, 28, 4)
    UI.ink("gray")
    UI.steam(cx, 192, 3, 18)
    UI.ink("none")
  end
  gfx.setColor(BLACK)
  -- the A button and the bell
  local bx = 336
  if s.phase == 3 then bx = bx + ((math.floor(frames / (2))) % 2 == 0 and 2 or -2) end
  if s.phase == 2 and s.slide >= 1 then
    UI.sunA(262, 180)
    drawTC("RING", 262, 203, true)
  end
  gfx.setColor(BLACK)
  UI.ink("slate")
  gfx.fillRoundRect(bx - 36, 219, 72, 7, 3)                                         -- the tray
  UI.ink("gold2")
  gfx.setClipRect(0, 0, 400, 219)
  gfx.fillCircleAtPoint(bx, 219, 28)                                                -- the dome
  gfx.clearClipRect()
  gfx.fillRect(bx - 3, 187, 6, 4)                                                    -- the stem
  gfx.fillCircleAtPoint(bx, 185, 5)                                                  -- the button
  gfx.setColor(WHITE)
  gfx.drawLine(bx - 22, 212, bx + 22, 212)                                           -- a band round the dome
  UI.ink("inkwhite")
  if UI.color then gfx.setColor(BLACK) end
  gfx.fillCircleAtPoint(bx - 12, 201, 4); gfx.drawLine(bx - 17, 194, bx - 9, 190)    -- the shine
  UI.ink("none")
  gfx.setColor(BLACK)
  if s.phase == 3 then
    drawTC("DING!", 262, 180, true)
    for i = -2, 2 do
      local ang = math.rad(i * 25 - 90)
      UI.ink("inkorange")
      gfx.drawLine(math.floor(bx + math.cos(ang) * 34), math.floor(219 + math.sin(ang) * 34), math.floor(bx + math.cos(ang) * 46), math.floor(219 + math.sin(ang) * 46))
    end
  end
  UI.ink("none")
end

-- Evening Chill: the dish bin (left) and sink (right)
local function drawDishes()
  local G = G
  local s, cu = G.sink, G.cups
  drawPanelFrame(nil, "DISHES")
  -- the rack: two shelves, up to 6 dirty mugs on show
  UI.ink("woodl")
  gfx.setColor(BLACK)
  for r = 0, 1 do
    local y0 = 163 + r * 24
    gfx.fillRect(14, y0 + 17, 116, 3)
    gfx.fillRect(16, y0 + 20, 3, 4); gfx.fillRect(125, y0 + 20, 3, 4)
  end
  UI.ink("none")
  local E_drawCup = drawCup
  for i = 1, math.min(cu.dirty, 6) do
    local col, row = (i - 1) % 3, math.floor((i - 1) / (3))
    E_drawCup(24 + col * 36, 163 + row * 24, 2, true)
  end
  -- the sink
  local wx = 276
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(158, 178, 222, 36, 9)                                           -- the basin
  UI.ink("snow")
  gfx.setColor(WHITE); gfx.fillRoundRect(163, 182, 212, 28, 6)
  UI.ink("water")
  gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(165, 197, 208, 11); gfx.setColor(BLACK)
  local wave = math.floor(math.sin(frames * 0.3) * 1.5)
  gfx.drawLine(165, 197 + wave, 373, 197 - wave)
  UI.ink("gray")
  gfx.fillRoundRect(152, 171, 234, 7, 3)                                            -- the rim
  UI.ink("slate")
  gfx.fillRect(238, 151, 12, 21)                                                    -- faucet pipe
  gfx.fillRoundRect(238, 142, 48, 12, 6)                                            -- the curve over the sink
  gfx.fillRect(wx - 5, 142, 10, 17)                                                 -- spout
  gfx.fillRect(wx - 7, 156, 14, 5)
  UI.ink("redp")
  gfx.fillCircleAtPoint(180, 164, 5); gfx.fillRect(178, 164, 4, 8)                  -- the two taps (hot and cold)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(180, 164, 2); gfx.setColor(BLACK)
  UI.ink("skyp")
  gfx.fillCircleAtPoint(358, 164, 5); gfx.fillRect(356, 164, 4, 8)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(358, 164, 2); gfx.setColor(BLACK)
  UI.ink("inkblue")
  local flow = (frames * 2) % 8
  for y = 161 + flow - 8, 180, 8 do if y >= 161 then gfx.drawLine(wx, y, wx, math.min(180, y + 4)) end end
  UI.ink("none")
  -- the cup in the sink
  if s.state ~= "empty" then
    local cxx, cyy = wx, 190
    E_drawCup(cxx - 12, cyy - 14, 3, false)
    if s.state == "washing" then
      local h = math.floor(10 * (1 - s.progress))
      UI.ink("coffee")
      if h > 0 then gfx.setPattern(CHECK); gfx.fillRect(cxx - 10, cyy + 8 - h, 20, h); gfx.setColor(BLACK) end
      local a = math.rad(s.angle)
      local sx, sy = math.floor(cxx + 30 * math.cos(a)), math.floor(cyy + 6 + 8 * math.sin(a))
      UI.ink("yellow")
      if UI.color then gfx.setColor(WHITE); gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3); gfx.setColor(BLACK); gfx.drawRoundRect(sx - 8, sy - 5, 16, 10, 3); UI.ink("leaf"); gfx.fillRect(sx - 8, sy + 2, 16, 3)
      else gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3) end                         -- (PC: a yellow sponge with a green scrubber)
      UI.ink("yellow")
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx - 3, sy - 1, 1); gfx.fillCircleAtPoint(sx + 3, sy + 2, 1); gfx.setColor(BLACK)
      UI.ink("inkblue")
      for i = 0, 2 do
        local bxx = cxx - 26 + ((frames * 0.7 + i * 23) % 56)
        gfx.drawCircleAtPoint(math.floor(bxx), cyy - 8 - ((math.floor(frames / (3)) + i * 5) % 12), 2 + i % 2)
      end
    else
      local big = ((math.floor(frames / (3))) % 2 == 0)
      UI.ink("inkyellow")
      for _, o in ipairs({ { -22, -10 }, { 24, -6 }, { -18, 12 }, { 22, 12 } }) do
        local r = big and 5 or 3
        gfx.drawLine(cxx + o[1] - r, cyy + o[2], cxx + o[1] + r, cyy + o[2]); gfx.drawLine(cxx + o[1], cyy + o[2] - r, cxx + o[1], cyy + o[2] + r)
      end
    end
  end
  -- progress as a row of soap bubbles
  local prog = (s.state == "washing") and clamp(s.progress, 0, 1) or ((s.state == "sparkle") and 1 or 0)
  UI.ink("water")
  for i = 1, 6 do
    local bx = 296 + i * 14
    gfx.setColor(BLACK)
    if i <= math.floor(prog * 6 + 0.001) then gfx.fillCircleAtPoint(bx, 148, 5)
    else gfx.drawCircleAtPoint(bx, 148, 5) end
  end
  gfx.setColor(WHITE); gfx.setColor(BLACK)
  UI.ink("none")
  -- the hint strip
  gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(12, 216, 376, 1); gfx.setColor(BLACK)
  if s.state == "empty" then drawTC("All clean!", 200, 219, true)
  elseif s.state == "washing" then drawTC("Hold SPACE to scrub!", 200, 219, true)
  else drawTC("Squeaky clean!", 200, 219, true) end
end


-- Evening Chill: the cup shelf on the wall
-- a clean cup for the shelf: round-cornered body, a rim, a shine and a ring handle (x, y = top-left, 26 wide, 24 tall)
function UI.shelfCup(x, y)
  UI.inkPush("mugc")
  gfx.setColor(BLACK)
  UI.ringDraw(x + 27, y + 12, 3.6, 6.2)                                        -- the handle (the body covers its left half)
  gfx.fillRect(x, y, 27, 12)                                                   -- flat top: square corners up here, round ones only at the bottom
  gfx.fillRoundRect(x, y + 4, 27, 20, 7)
  gfx.setColor(WHITE)
  gfx.fillRect(x + 3, y + 3, 21, 9)                                            -- the inside, square at the top as well
  gfx.fillRoundRect(x + 3, y + 8, 21, 13, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 1, y, 29, 3)                                                -- the lip of the rim, a little wider than the cup
  gfx.fillRect(x + 6, y + 8, 3, 8); gfx.setColor(WHITE); gfx.fillRect(x + 7, y + 9, 1, 6); gfx.setColor(BLACK)   -- a little shine
  UI.inkPop()
end

function UI.shelfSlot(x, y)                                                    -- an empty spot on the plank: a dotted cup shape
  UI.inkPush("gray")
  gfx.setColor(BLACK)
  for dx = 3, 23, 4 do gfx.fillRect(x + dx, y, 2, 1); gfx.fillRect(x + dx, y + 23, 2, 1) end
  for dy = 3, 19, 4 do gfx.fillRect(x, y + dy, 1, 2); gfx.fillRect(x + 26, y + dy, 1, 2) end
  UI.inkPop()
end

function UI.plank(x0, x1, y, bare)                                            -- one wooden plank with its two brackets (none when there's a row right below)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x0, y, x1 - x0, 7, 3)
  gfx.setColor(WHITE); gfx.fillRect(x0 + 5, y + 2, x1 - x0 - 10, 1); gfx.setColor(BLACK)
  if bare then UI.ink("none"); return end
  for _, bx in ipairs({ x0 + 14, x1 - 24 }) do
    gfx.fillTriangle(bx, y + 7, bx, y + 18, bx + 10, y + 7)
    gfx.setColor(WHITE); gfx.drawLine(bx + 2, y + 10, bx + 2, y + 14); gfx.setColor(BLACK)
  end
  UI.ink("none")
end

local function drawShelf()
  local cu = G.cups
  drawPanelFrame(nil, "SHELF")
  local two = G.cupMax > 5
  local perRow = two and 5 or math.max(1, G.cupMax)
  local gap = 48
  local x0 = 16 + (two and 0 or math.floor((5 - perRow) * gap / 2))           -- (a short shelf sits in the middle of the wall)
  local lowY = two and 206 or 192                                             -- where the lower plank is
  local plankX0, plankX1 = 12, 262
  if two then UI.plank(plankX0, plankX1, lowY - 38, true) end
  UI.plank(plankX0, plankX1, lowY)
  for i = 0, G.cupMax - 1 do
    local back = two and i >= 5
    local col = back and (i - 5) or i
    local x = 18 + col * gap + (two and 0 or math.floor((5 - perRow) * gap / 2))
    local y = (back and (lowY - 38) or lowY) - 24
    if i < cu.shelf then UI.shelfCup(x, y) else UI.shelfSlot(x, y) end
  end
  -- on the right: how many are up, the cups in hand, and what A does
  local cx = 330
  UI.plaque(cx, 144, 110, string.format("%d of %d cups", cu.shelf, G.cupMax))
  if cu.hand > 0 then
    local n = math.min(cu.hand, 3)                                            -- (the title bar says how many in all)
    local span = n * 36
    for i = 1, n do UI.shelfCup(cx - math.floor(span / (2)) + (i - 1) * 36 + 2, 172) end
    UI.sunA(298, 214)
    drawT("PUT UP", 322, 206, true)
  else
    drawTC("Hold a clean cup", cx, 176, false)
    drawTC("to place it.", cx, 194, false)
  end
  UI.ink("none")
end

local function drawStationPanel()
  if G.st == "dishes" then drawDishes(); UI.ink("none"); return end
  if G.st == "shelf" then drawShelf(); UI.ink("none"); return end
  local c = G.cust
  if c == nil then return end
  if G.st == "register" then drawRegister(c)
  elseif G.st == "coffee" then drawCoffee(c)
  elseif G.st == "mixer" then drawMixer(c)
  elseif G.st == "serve" then drawServe(c) end
  UI.ink("none")                                       -- (PC: nothing a panel painted in carries on to the rest of the screen)
end

----------------------------------------------------------------------
-- Drawing: HUD, popups, messages
----------------------------------------------------------------------
function UI.stopwatch(t)
  local secs = math.floor(t)
  if secs >= 3600 then
    return string.format("%d:%02d:%02d", math.floor(secs / (3600)), math.floor((secs % 3600) / (60)), secs % 60)
  end
  return string.format("%d:%02d", math.floor(secs / (60)), secs % 60)
end

local function drawHUD()
  UI.ink("chrome")                                              -- (PC: the top bar is black, not brown)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 0, 400, 18)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if G.mode == "cafe" and G.cafe and G.cafe.money then          -- in the Cafe the corner shows everything you have, not just this session
    drawTR(money(G.cafe.money + G.cash + G.tips - (G.banked or 0)), 394, 1, true)
  else
    drawTR(money(G.cash + G.tips), 394, 1, true)
  end
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    drawT(UI.stopwatch(math.max(0, math.ceil(rem))), 6, 1, true)           -- counting down from 1:30
    if rem <= 10 and rem > 0 then               -- closing countdown: 10, 9, 8...
      drawTC("Closing in " .. math.ceil(rem), 200, 1, true)
    end
    if (G.streak or 0) >= 2 then drawT("COMBO x" .. UI.comboTxt(G.streak), 76, 1, true) end         -- what the good orders in a row are worth now
  else
    local tx = (G.mode == "cafe") and UI.hudTimeX or 6
    local ts = UI.stopwatch(G.t)
    drawT(ts, tx, 1, true)           -- how long you've been playing
    gfx.setFont(fontBold)
    UI.hudLeft = tx + gfx.getTextSize(ts)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if G.mode == "cafe" then UI.drawStarBar() end         -- the barista level, the stars, and the meter to the next star
  if UI.hudExtra then UI.hudExtra() end
  if G.mode == "rush" then
    local prog = clamp(G.t / RUSH_SECONDS, 0, 1)
    gfx.setColor(WHITE)
    gfx.fillRect(0, 16, math.floor(400 * prog), 2)
  end
  gfx.setColor(BLACK)
end

function UI.drawPopups()
  for _, p in ipairs(G.popups) do
    local k = p.t / p.life
    local y = math.floor(p.y - 22 * k)
    -- small popups (tips over the jar) use the thin font and tight padding
    local pad = p.small and 3 or 5
    gfx.setFont(p.small and fontNormal or fontBold)
    local w = gfx.getTextSize(p.s)
    local bw = w + pad * 2
    local bx = clamp(p.x - math.floor(bw / (2)), 2, 398 - bw)
    local bh = p.small and 20 or 20
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, y - 2, bw, bh, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(bx, y - 2, bw, bh, 4)
    drawT(p.s, bx + pad, p.small and y + 1 or y, not p.small)
  end
end

function UI.drawMessage()
  if G.msg == nil then return end
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(G.msg)
  local bw = w + 20
  local bx = 200 - math.floor(bw / (2))
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, 188, bw, 22, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, 188, bw, 22, 6)
  gfx.setLineWidth(1)
  drawTC(G.msg, 200, 191, true)
end

local function needsCrank()
  if G.st == "dishes" then return G.sink.state == "washing" end
  local c = G.cust
  if c == nil or G.st == nil then return false end
  if G.st == "register" then return c.reg.state == "crank" end
  if G.st == "coffee" then return UI.crankPour == true and c.cof.phase == "pour" end
  if G.st == "mixer" then return c.mix.phase == 2 end
  return false
end

local function drawPlay()
  UI.inPlay = true                             -- (Playdate: the moving decor is drawn every other frame, see UI.liveDraw)
  CAFE.sceneTop()
  drawPlayer()                                 -- the barista stands behind the counter and the machines
  CAFE.sceneBottom()
  UI.drawDoor()
  if G.pets then CAFE.drawPets() end
  -- people, back of the line first so the front of the line is on top
  for i = #G.line, 1, -1 do drawCustomer(G.line[i], false) end
  for _, c in ipairs(G.others) do drawCustomer(c, false) end
  local c = G.cust
  if c then drawCustomer(c, true) end
  if G.birds then CAFE.drawBirds() end                    -- a parrot or an owl out flying, or sitting somewhere
  if c and c.stage == 1 and G.st == nil then drawBubble(c) end           -- (gone once the order has been rung in)
  if G.st then drawStationPanel() end
  UI.drawPopups()
  drawHUD()
  UI.drawStamp()
  UI.drawMessage()
  if needsCrank() then crankHelpDraw() end
  UI.inPlay = false
end

----------------------------------------------------------------------
-- Title screen
----------------------------------------------------------------------
-- Big headline text: drawn once into an image of exactly the text's size, then
-- scaled up to fill the box (boxH tall, as wide as the screen allows) and centred.
local bigTextCache = {}
local function bigText(str, boxY, boxH, maxScale)
  local e = bigTextCache[str]
  if e == nil then
    gfx.setFont(fontBold)
    local w, h = gfx.getTextSize(str)
    local img = nil
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setFont(fontBold)
      gfx.drawText(str, 0, 0)
      gfx.popContext()
    end)
    e = { img = ok and img or nil, w = w, h = h }
    bigTextCache[str] = e
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if e.img then
    local scale = math.min(maxScale, 376 / e.w, boxH / e.h)
    local x = math.floor((400 - e.w * scale) / 2 + 0.5)
    local y = math.floor(boxY + (boxH - e.h * scale) / 2 + 0.5)
    e.img:drawScaled(x, y, scale)
  else
    drawTC(str, 200, boxY + math.floor(boxH / (2)) - 8, true)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

-- the big steaming mug (ox, oy move it around the screen)
function UI.drawBigMug(ox, oy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawCircleAtPoint(224 + ox, 164 + oy, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(182 + ox, 150 + oy, 38, 10)
  gfx.setColor(BLACK)
  gfx.fillRect(166 + ox, 186 + oy, 70, 4)
  for k = -1, 1 do
    local px, py = 0, 0
    for i = 0, 8 do
      local yy = 140 + oy - i * 2.5
      local xx = 200 + ox + k * 10 + math.sin(frames * 0.15 + i * 0.7 + k) * 3
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

UI.TITLE_N = 40                                  -- one picture per game frame, so the sunburst and lettering move smoothly
UI.NEW_SHOP = true                               -- the dark-backdrop shop page; set false to get the plain white page back
function UI.shopBgImg()
  if not UI.NEW_SHOP then return false end
  local im = UI.shopBg
  if im == nil then
    local ok, got = pcall(function() return gfx.image.new("images/shopbg") end)
    im = (ok and got) or false
    UI.shopBg = im
  end
  return im
end

UI.SHOPBEANS = { { 303, 48, 0.045, 0 }, { 330, 46, 0.060, 2.1 }, { 359, 49, 0.050, 4.2 } }   -- x, y, speed, start
function UI.drawShopBeans()
  local imgs = UI.shopBeanImgs
  if imgs == nil then
    imgs = {}
    for i = 1, 3 do
      local ok, im = pcall(function() return gfx.image.new("images/shopbean" .. i) end)
      if ok and im then imgs[i] = im else imgs = false; break end
    end
    UI.shopBeanImgs = imgs
  end
  if not imgs then return end
  for i, b in ipairs(UI.SHOPBEANS) do
    imgs[i]:draw(b[1], b[2] + math.floor(math.sin(frames * b[3] + b[4]) * 2.4 + 0.5))
  end
end

function UI.titleArt()                          -- the title screen's sunburst (40 pictures): the first at once, the rest a few a frame
  return UI.bgSet("title")
end

-- one title-screen box: a white sticker edge when chosen, a drop shadow when not (leaves the draw mode white-on-black when chosen)
function UI.menuBox(x, y, w, sel, art)
  if art and not UI.color then UI.stickerBox(x, y, w, 31, sel); return end      -- (Playdate: a picture of the box is stamped, see UI.boxImg)
  if art then
    if sel then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x - 2, y - 2, w + 4, 35, 10)
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x + 3, y + 3, w, 31, 8)
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(x, y, w, 31, 8)
      gfx.setLineWidth(1)
    end
  else
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(x, y, w, 31, 8)
      gfx.setLineWidth(1)
    end
  end
end

-- a little gear (eight teeth, a hole in the middle), ink on bg, turned by `ang`
function UI.gear(cx, cy, ink, bg, ang)
  gfx.setColor(ink)
  for k = 0, 7 do
    local a = ang + k * math.pi / 4
    local function P(r, da)
      return cx + math.cos(a + da) * r, cy + math.sin(a + da) * r
    end
    local x1, y1 = P(6, -0.34); local x2, y2 = P(11, -0.20)
    local x3, y3 = P(11, 0.20); local x4, y4 = P(6, 0.34)
    gfx.fillPolygon(x1, y1, x2, y2, x3, y3, x4, y4)
  end
  gfx.fillCircleAtPoint(cx, cy, 8)
  gfx.setColor(bg)
  gfx.fillCircleAtPoint(cx, cy, 3)
end

-- the mascot on the title screen: the smiling mug in a coral sunburst badge, coffee leaping out of it in a curl.
-- 60 pictures, one per frame (the badge's rays turn, the coffee sways, drops fly, it blinks); each is loaded the
-- first time it's needed, so nothing waits on all of them at once.
UI.MASCOT_N = 60
-- the "Coffee Please!!!" lettering: its own pictures, one per title frame (the letters bob in a wave), drawn over the
-- title art (which still has the old lettering under it: these cover it, so both always show the same frame number).
function UI.titleWordsDraw(k)
  local set = UI.bgSet("titlewords")
  local im = set and set[k]
  if im then im:draw(30, 3) end
end
function UI.mascotDraw(x, y)
  local set = UI.bgSet("mascot")
  if not set then return end
  local k = math.min(frames % UI.MASCOT_N + 1, math.max(1, UI.setCount("mascot")))   -- (still coming in: the newest one so far)
  local im = set[k]
  if im then im:draw(x, y) end
end
local function drawMenu()
  local art = UI.titleArt()
  if art then
    local k = math.min(frames % UI.TITLE_N + 1, math.max(1, math.min(UI.setCount("title"), UI.setCount("titlewords"))))
    art[k]:draw(0, 0)                                                -- the turning sunburst and the "by Christian G" plate
    UI.titleWordsDraw(k)                                             -- "Coffee Please!!!", bobbing in a wave
    UI.mascotDraw(15, 72)                                            -- the mascot: the mug in its badge, coffee leaping out
  else
    gfx.setColor(BLACK)                                              -- (fallback if the pictures are missing)
    gfx.fillRect(0, 10, 400, 84)
    bigText("Coffee Please!!!", 14, 56, 5)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC("by Christian G", 200, 72, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.drawBigMug(-100, 6)
  end

  -- boxes: three game modes, then a row with the high scores (half length) and Settings (a gear) side by side
  local opts = { { "CAFE", "build your own cafe" },
                 { "RUSH HOUR", "90 sec score chase" },
                 { "EVENING CHILL", "time free mode, relax" } }
  local mx, my = 196, 100                                          -- (art: sits a little up and left so nothing touches the white border)
  if art then mx, my = 188, 89 end
  for i, o in ipairs(opts) do
    local y = my + (i - 1) * 35
    UI.ink(({ "m_cafe", "m_rush", "m_chill" })[i])                  -- (PC: each box its own soft colour)
    UI.menuBox(mx, y, 196, menuSel == i, art)
    drawT(o[1], mx + 10, y + 1, true)
    drawT(o[2], mx + 10, y + 15)
    UI.ink("none")
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if menuSel == i then CAFE.pointer(mx + 162, y + 11) end           -- the same mouse arrow the shop uses, resting on the box
  end
  local y4 = my + 3 * 35
  local hs, ac, st = menuSel == 4 and UI.menuCol == 1, menuSel == 4 and UI.menuCol == 2, menuSel == 4 and UI.menuCol == 3
  UI.ink("m_high")
  UI.menuBox(mx, y4, 98, hs, art)                                  -- HIGH SCORES: half the length it was
  drawT("HIGH", mx + 10, y4 + 1, true)
  drawT("SCORES", mx + 10, y4 + 15, true)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if hs then CAFE.pointer(mx + 74, y4 + 11) end
  UI.ink("m_ach")
  UI.menuBox(mx + 106, y4, 41, ac, art)                            -- ACHIEVEMENTS: a trophy
  UI.trophy(mx + 106 + 20, y4 + 15, ac and WHITE or BLACK, ac and BLACK or WHITE, ac)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if ac then CAFE.pointer(mx + 106 + 27, y4 + 15) end
  UI.ink("m_gear")
  UI.menuBox(mx + 155, y4, 41, st, art)                            -- SETTINGS: a turning gear in a box of its own
  UI.gear(mx + 155 + 20, y4 + 15, st and WHITE or BLACK, st and BLACK or WHITE, st and frames * 0.06 or 0)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if st then CAFE.pointer(mx + 155 + 27, y4 + 15) end
  gfx.setColor(BLACK)
  if art then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(7, 211, 42, 19, 6)                          -- the version sits on a little white label
    gfx.setColor(BLACK)
    gfx.drawRoundRect(7, 211, 42, 19, 6)
  end
  drawT("V.1.4", art and 12 or 6, art and 213 or 220)               -- the version, lower left
end

-- ---- settings (the gear box on the title screen) ------------------
function UI.decoCup(x, y)
  gfx.setColor(WHITE); gfx.fillRect(x, y + 3, 8, 7)
  gfx.setColor(BLACK); gfx.drawRect(x, y + 3, 8, 7)
  gfx.drawCircleAtPoint(x + 9, y + 6, 2)
  gfx.fillRect(x + 1, y + 4, 6, 2)
  gfx.drawPixel(x + 3, y); gfx.drawPixel(x + 2, y + 1); gfx.drawPixel(x + 4, y + 1)
end

function UI.decoBean(x, y)
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x, y + 1, 8, 7)
  gfx.setColor(WHITE)
  gfx.drawLine(x + 2, y + 7, x + 5, y + 2)
  gfx.setColor(BLACK)
end

-- the pictures behind the Settings, High Scores, save and new-cafe screens: each set is 40 frames. They are loaded a few
-- pictures at a time while you sit on the title screen (see UI.bgPreload), the one under the cursor first, so pressing a
-- button finds them ready. A screen whose set is not all in yet never waits for it: it shows the pictures it has (the
-- sunburst holds still a moment) while the rest come in a few a frame. A set is let go once its screens are out of reach.
UI.bgSets = {}
UI.bgPart = {}                                     -- sets that are part-way loaded
UI.SETN = { mascot = 60 }                          -- (pictures in a set: 40 unless it says here)
-- Loading costs a Playdate frame a few milliseconds a picture, so it is shared out: each frame may spend LOAD_MS on it
-- (counted from the start of the frame) and load at most LOAD_MAX things, so the screen keeps its 30 frames a second
-- and a button press is always answered at once.
UI.LOAD_MS, UI.LOAD_MAX = 10, 3
UI.loadN, UI.frameT0 = 0, 0
function UI.loadRoom() return UI.loadN < UI.LOAD_MAX and (pd.getCurrentTimeMilliseconds() - UI.frameT0) < UI.LOAD_MS end
function UI.setCount(name)                         -- how many pictures of a set are in so far
  local set = UI.bgSets[name]
  if set then return #set end
  local part = UI.bgPart[name]
  return part and #part or 0
end
UI.TITLESETS = { "title", "titlewords", "mascot" } -- the title screen's own: always kept, loaded before anything else
function UI.titleReady()
  for _, name in ipairs(UI.TITLESETS) do if UI.bgSets[name] == nil then return false end end
  return true
end
function UI.bgLoadOne(name)                        -- load the next picture of a set; true once the set is complete
  if UI.bgSets[name] ~= nil then return true end
  UI.loadN = UI.loadN + 1
  local part = UI.bgPart[name]
  if not part then part = {}; UI.bgPart[name] = part end
  local i = #part + 1
  local ok, im = pcall(function() return gfx.image.new("images/" .. name .. "/" .. i) end)
  if not (ok and im) then
    collectgarbage("collect")                      -- (memory may be tight: let go of anything unused and try once more)
    ok, im = pcall(function() return gfx.image.new("images/" .. name .. "/" .. i) end)
  end
  if not (ok and im) then UI.bgSets[name] = false; UI.bgPart[name] = nil; UI.bgFailT = frames; return true end
  part[i] = im
  if i >= (UI.SETN[name] or UI.TITLE_N) then UI.bgSets[name] = part; UI.bgPart[name] = nil; return true end
  return false
end
UI.bgView = {}                                     -- a stand-in for a set that is part-way in: frame i, or the last one loaded so far
UI.bgViewMeta = { __index = function(v, i)
  local part = rawget(v, "part")
  return part[i] or part[#part]
end }
function UI.bgSet(name)
  local set = UI.bgSets[name]
  if set ~= nil then return set end
  if name == "scores" and (UI.bgSets.closing ~= nil or UI.bgPart.closing ~= nil or UI.bgSets.shift ~= nil or UI.bgPart.shift ~= nil) then
    UI.bgSets.closing, UI.bgPart.closing, UI.bgSets.shift, UI.bgPart.shift = nil, nil, nil, nil   -- (the high score pictures come in right after a
    collectgarbage("collect")                                                                    --  shift's closing pictures: put those away first)
  end
  local part = UI.bgPart[name]
  if part == nil or #part == 0 then                -- (nothing of it yet: the first picture now, the rest a few a frame)
    if UI.bgLoadOne(name) then return UI.bgSets[name] end
    part = UI.bgPart[name]
  end
  local v = UI.bgView[name]
  if v == nil or rawget(v, "part") ~= part then
    v = setmetatable({ part = part }, UI.bgViewMeta)
    UI.bgView[name] = v
  end
  return v
end

function UI.bgMenus()                              -- the title screen, the high scores, or the save / new-cafe screens
  if state == STATE_MENU or state == STATE_BOARD then return true end
  if state ~= CAFE.STATE then return false end
  local m = CAFE.mode
  return m == "slots" or m == "name" or m == "char"
end
function UI.bgWanted(name)                         -- is a screen that uses this set on show, or a button or two away?
  if name == "achieve" and UI.ach ~= nil then return true end
  if name == "settings" or name == "scores" or name == "achieve" then return UI.bgMenus() end
  if name == "closing" or name == "shift" then                     -- the initials screen of this shift (kept from the start of the shift)
    return G ~= nil and (state == STATE_PLAY or state == STATE_ENTRY) and G.mode == (name == "closing" and "rush" or "chill")
  end
  local m = (state == CAFE.STATE) and CAFE.mode or nil
  if name == "slots" then return UI.bgMenus() end
  if name == "name" then return m == "slots" or m == "name" or m == "char" end
  if name == "char" then return m == "name" or m == "char" end
  return false
end

function UI.bgSweep()                              -- every frame: drop a set once its screens are gone
  for _, name in ipairs({ "settings", "scores", "slots", "name", "char", "closing", "shift", "achieve" }) do
    if (UI.bgSets[name] ~= nil or UI.bgPart[name] ~= nil) and not UI.bgWanted(name) then
      UI.bgSets[name] = nil
      UI.bgPart[name] = nil
    end
  end
end

-- a little work each frame: the rest of the pictures for the screen on show, then (on the title and save screens) your saves
-- and the pictures you are likely to ask for next, the one under the cursor first. A few pictures a frame, as long as the
-- frame has time for them, so neither the screen nor a fade ever waits.
UI.idle = 0
function UI.bgShown()                              -- the set the screen on show uses (nil if none)
  if state == STATE_MENU or state == STATE_PLAY then return (UI.settings ~= nil and "settings") or (UI.ach ~= nil and "achieve") or nil end
  if state == STATE_BOARD then return "scores" end
  if state == CAFE.STATE then
    local m = CAFE.mode
    if m == "slots" or m == "name" or m == "char" then return m end
  end
  return nil
end
function UI.bgLoadSome(name, force)                -- pictures of a set while the frame has room (force: at least one, even if it hasn't)
  if not force and not UI.loadRoom() then return UI.bgSets[name] ~= nil end
  repeat
    if UI.bgLoadOne(name) then return true end
  until not UI.loadRoom()
  return false
end
function UI.guessNext()                            -- the page the button just pressed is about to show (so its pictures can start coming in)
  if state == STATE_MENU then
    if UI.settings ~= nil or UI.ach ~= nil then return nil end
    if menuSel == 1 then return "slots" end
    if menuSel == 4 then return ({ "scores", "achieve", "settings" })[UI.menuCol] or "scores" end
  elseif state == STATE_BOARD then return nil
  elseif state == CAFE.STATE then
    local m = CAFE.mode
    if m == "slots" then return (CAFE.slots[CAFE.sel] == nil) and "name" or nil end
    if m == "name" then return CAFE.onDone and "char" or nil end
  end
  return nil
end
function UI.fadeLoad()                             -- while the screen goes dark: pictures of the next page, a handful a frame
  local name = UI.guessNext()
  if name == nil or UI.bgSets[name] ~= nil then return end
  local t0 = pd.getCurrentTimeMilliseconds()
  repeat
    if UI.bgLoadOne(name) then return end
  until UI.loadN >= 6 or pd.getCurrentTimeMilliseconds() - t0 >= 14
end

-- Playdate: before the title shows, everything it needs is made ready behind a progress bar: the title's pictures, the sound effects, the big wavy
-- letters and the boxes' pictures. Loading dribbled in a few things a frame while the sunburst was turning is what made it stutter.
UI.BOOT_MS = 22
function UI.bootDraw(b)                           -- the picture the launch animation ends on (the title screen), its bottom edge filling in as things load
  if UI.bootImg == nil then
    UI.bootImg = false
    local ok, im = pcall(gfx.image.new, "launcher/launchImages/56")
    if ok and im then UI.bootImg = im end
  end
  gfx.setBackgroundColor(WHITE)
  gfx.clear()
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if UI.bootImg then
    UI.bootImg:draw(0, 0)
    local w = math.floor(380 * math.min(b.done, b.total) / b.total)
    if w > 0 then gfx.setColor(BLACK); gfx.fillRect(10, 235, w, 2) end
  else
    UI.cupScene(frames / 30, math.min(b.done, b.total) / b.total, "Loading")
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

function UI.bootStep()                             -- true while the loading screen is up
  local b = UI.boot
  if b == nil then
    b = { stage = 1, done = 0, total = 140 + #UI.SFX_NAMES + 94 + 8 }
    UI.boot = b
    UI.bootDraw(b)                                 -- (the very first frame is just the picture: it is up before any work starts)
    return true
  end
  local t0 = pd.getCurrentTimeMilliseconds()
  repeat
    if b.stage == 1 then                           -- the title screen's pictures
      local more = false
      for _, name in ipairs(UI.TITLESETS) do
        if UI.bgSets[name] == nil then
          local before = #(UI.bgPart[name] or {})
          UI.bgLoadOne(name)
          b.done = b.done + 1
          more = true
          break
        end
      end
      if not more then b.stage = 2 end
    elseif b.stage == 2 then                       -- the sound effects
      if UI.sfxWarm() then b.done = b.done + 1 else b.stage = 3 end
    elseif b.stage == 3 then                       -- the big wavy letters
      if UI.fancyWarmI <= 126 then
        local f = gfx.getFont()
        UI.fancyLetter(string.char(UI.fancyWarmI))
        UI.fancyWarmI = UI.fancyWarmI + 1
        if f then gfx.setFont(f) end
        b.done = b.done + 1
      else b.stage = 4 end
    elseif b.stage == 4 then                       -- the pictures of the boxes (the title's, the save slots', the settings')
      for _, bx in ipairs({ { 196, 31 }, { 98, 31 }, { 41, 31 }, { 280, 44 }, { 196, 22 } }) do
        UI.boxImg(bx[1], bx[2], false); UI.boxImg(bx[1], bx[2], true)
      end
      b.done = b.done + 8
      b.stage = 5
    else
      UI.bootDone = true
      UI.boot = nil
      return false
    end
  until pd.getCurrentTimeMilliseconds() - t0 >= UI.BOOT_MS
  UI.bootDraw(b)
  return true
end

function UI.bgPreload()
  if state == STATE_PLAY and G ~= nil and (G.mode == "rush" or G.mode == "chill") then   -- during a shift: one picture for the closing screen every few frames
    local name = (G.mode == "rush") and "closing" or "shift"
    if UI.bgSets[name] == nil and frames % 5 == 0 and (G.t or 0) > 2 then UI.bgLoadOne(name) end
    return
  end
  local shown = UI.bgShown()
  if shown and UI.bgPart[shown] then UI.bgLoadSome(shown, true); return end   -- (the screen on show is still missing some: those first)
  local onTitle = state == STATE_MENU
  if onTitle and trans == nil and not UI.titleReady() then           -- the title's own pictures: a few every frame till they're all in
    for _, name in ipairs(UI.TITLESETS) do
      if UI.bgSets[name] == nil and not UI.bgLoadSome(name, true) then return end
    end
    return
  end
  if not UI.color then                              -- (Playdate: the title screen does no loading at all while you look at it: the sounds, letters and
    UI.idle = 0                                     --  title pictures are all in before it shows (UI.bootStep), and the next page's pictures start
    if trans ~= nil and trans.phase == "out" then UI.fadeLoad() end   --  coming in as the screen dips to black, so nothing ever hitches the sunburst)
    return
  end
  if not (onTitle or (state == CAFE.STATE and (CAFE.mode == "slots" or CAFE.mode == "name"))) then UI.idle = 0; return end
  if trans ~= nil then return end                  -- (nothing else during a fade: it stays smooth)
  if UI.anyButton() then
    UI.idle = 0                                    -- (somebody is pressing buttons: wait till they stop for a moment, so scrolling the menu never hitches)
    return
  end
  UI.idle = UI.idle + 1
  if UI.idle < 8 or not UI.loadRoom() then return end
  if onTitle then
    local next = nil                               -- what the cursor is on
    if UI.settings == nil then
      if menuSel == 1 then next = "slots"
      elseif menuSel == 4 then next = ({ "scores", "achieve", "settings" })[UI.menuCol] or "scores" end
    end
    if next ~= nil and next ~= "slots" and UI.bgSets[next] == nil then UI.bgLoadSome(next); return end
    if not CAFE.preRead() then return end          -- (your saves, one a frame, for the save screen)
    if next ~= nil and UI.bgSets[next] == nil then UI.bgLoadSome(next); return end
    if UI.sfxWarm() then return end                -- (then the sound effects, one a frame, before the other screens' pictures)
    for _, name in ipairs({ "slots", "settings", "scores", "achieve" }) do
      if UI.bgSets[name] == nil then UI.bgLoadSome(name); return end
    end
  elseif CAFE.mode == "slots" then
    if UI.bgSets.name == nil then UI.bgLoadSome("name") end
  else
    if UI.bgSets.char == nil then UI.bgLoadSome("char") end
  end
end

-- one sticker box, the same look as the title screen's (white edge when chosen, drop shadow when not)
-- A sticker box (a white edge when chosen, a drop shadow when not) is a few rounded rectangles: slow to draw thirty times a second on
-- the Playdate, so each shape is drawn once into a little picture and stamped after that (the same pixels, a fraction of the time).
UI.boxCache, UI.boxN = {}, 0
function UI.boxImg(w, h, sel)
  local key = (sel and "s" or "u") .. w .. "x" .. h
  local im = UI.boxCache[key]
  if im ~= nil then return im end
  if UI.boxN >= 48 then return false end
  local ok, made = pcall(function()
    local img = gfx.image.new(w + 7, h + 7, gfx.kColorClear)
    gfx.pushContext(img)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    local x, y = 2, 2
    if sel then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x - 2, y - 2, w + 4, h + 4, 10)
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x, y, w, h, 8)
    else
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x + 3, y + 3, w, h, 8)
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, h, 8)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(x, y, w, h, 8)
      gfx.setLineWidth(1)
    end
    gfx.popContext()
    return img
  end)
  im = (ok and made) or false
  UI.boxCache[key] = im
  UI.boxN = UI.boxN + 1
  return im
end
function UI.stickerBox(x, y, w, h, sel)
  if not UI.color then
    local im = UI.boxImg(w, h, sel)
    if im then
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      im:draw(x - 2, y - 2)
      gfx.setColor(BLACK)
      if sel then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) end     -- (what the text on a chosen box is drawn in)
      return
    end
  end
  if sel then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x - 2, y - 2, w + 4, h + 4, 10)
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x, y, w, h, 8)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  else
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x + 3, y + 3, w, h, 8)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x, y, w, h, 8)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(x, y, w, h, 8)
    gfx.setLineWidth(1)
  end
end

function UI.drawSettings()
  local art = UI.bgSet("settings")
  if not art then UI.drawSettingsPlain(); return end
  art[frames % UI.TITLE_N + 1]:draw(0, 0)                          -- the turning sunburst, the "Settings" lettering, the smiling mug
  local mx = 188
  local rows = { { "Pour with", "SPACE" },
                 { "Music", UI.musicOn and "ON" or "OFF" },
                 { "Back" } }
  for i, r in ipairs(rows) do
    local y = 76 + (i - 1) * 40
    local sel = UI.settings.sel == i
    UI.ink(sel and "chrome" or ({ "m_cafe", "m_chill", "m_rush" })[i])   -- (PC: each row its own soft colour; the chosen one is black)
    UI.stickerBox(mx, y, 196, 31, sel)
    drawT(r[1], mx + 10, y + 8, true)
    if r[2] then drawTR(r[2], mx + 150, y + 8, true) end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.ink("none")
    gfx.setColor(BLACK)
    if sel then CAFE.pointer(mx + 164, y + 11) end
  end
  if UI.settings.sel == 1 then                                      -- a little hint plate, only while "Pour with" is chosen
    UI.ink("m_high")
    UI.stickerBox(mx, 198, 196, 22, false)
    drawTC("Hold the space bar", mx + 98, 201, false)
    UI.ink("none")
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

function UI.drawSettingsPlain()                    -- (the old look, if the pictures are missing)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 16, 400, 34)
  bigText("Settings", 19, 28, 3)
  -- cups and beans all round the border
  local n = 0
  for x = 6, 386, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoCup(x, 2); UI.decoCup(x, 226) else UI.decoBean(x, 3); UI.decoBean(x, 227) end
  end
  n = 0
  for y = 58, 206, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoBean(4, y); UI.decoBean(388, y) else UI.decoCup(3, y); UI.decoCup(386, y) end
  end
  local rows = { { "Pour with", "SPACE" },
                 { "Music", UI.musicOn and "ON" or "OFF" },
                 { "Back" } }
  for i, r in ipairs(rows) do
    local y = 72 + (i - 1) * 40
    local sel = UI.settings.sel == i
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(100, y, 200, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(100, y, 200, 31, 8)
      gfx.setLineWidth(1)
    end
    if r[2] then
      drawT(r[1], 112, y + 8, true)
      drawTR(r[2], 262, y + 8, true)
    else
      drawTC(r[1], 200, y + 8, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if sel then CAFE.pointer(272, y + 12) end
  end
  drawTC(UI.settings.sel == 1 and "Hold the space bar to pour" or " ", 200, 196, false)
end

function UI.updateSettings()
  local st = UI.settings
  local function toggle()
    if st.sel == 1 then
      UI.crankPour = not UI.crankPour
      saveScores()
    elseif st.sel == 2 then
      UI.musicOn = not UI.musicOn
      pcall(function() if UI.musicItem then UI.musicItem:setValue(UI.musicOn) end end)
    end
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonDown) then st.sel = st.sel % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then st.sel = (st.sel + 1) % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    if st.sel < 3 then toggle() end
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if st.sel == 3 then sfxClick(); UI.fast(function() UI.settings = nil end) else toggle() end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick(); UI.fast(function() UI.settings = nil end)
  end
end

----------------------------------------------------------------------
-- Closing time: initials entry, then the high score board
----------------------------------------------------------------------
-- a white arrow with a black edge, pointing up (d = -1) or down (d = 1)
function UI.vertArrow(x, y, d)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x, y + d * 8, x - 8, y - d * 2, x + 8, y - d * 2)
  gfx.setColor(WHITE)
  gfx.fillTriangle(x, y + d * 6, x - 5, y, x + 5, y)
  gfx.setColor(BLACK)
end

function UI.drawEntryNew(art)                       -- the results on a white receipt, then the three initials, on the sunburst
  art[frames % UI.TITLE_N + 1]:draw(0, 0)
  local rows
  if G.mode == "rush" then                          -- (served and walked-out share a line; tips include the combo bonuses)
    rows = {
      { "Served / walked out", G.served .. " / " .. G.missed },
      { "Sales", money(G.cash) },
      { "Tips & combos", money(G.tips) },
      { "Best combo", (G.bestStreak or 0) .. " in a row" },
    }
  else
    rows = {
      { "Customers served", tostring(G.served) },
      { "Sales", money(G.cash) },
      { "Tips", money(G.tips) },
      { "Walked out", tostring(G.missed) },
    }
  end
  UI.stickerBox(76, 48, 248, 84, false)
  for i, row in ipairs(rows) do
    local y = 52 + (i - 1) * 14
    drawT(row[1], 92, y)
    drawTR(row[2], 308, y)
  end
  gfx.setColor(BLACK)
  for x = 86, 312, 6 do gfx.drawLine(x, 111, x + 2, 111) end
  drawT("TOTAL MADE", 92, 114, true)
  drawTR(money(G.total), 308, 114, true)

  UI.stickerBox(96, 141, 208, 20, false)
  drawTC("ENTER YOUR INITIALS", 200, 143, true)
  for i = 1, 3 do
    local bx, by = 140 + (i - 1) * 44, 181
    local on = (i == entry.cur)
    UI.stickerBox(bx, by, 32, 32, on)
    drawTC(string.char(65 + entry.letters[i]), bx + 16, by + 9, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if on then
      local nudge = (math.floor(frames / (6))) % 2                -- the arrows tick in and out
      UI.vertArrow(bx + 16, by - 5 - nudge, -1)
      UI.vertArrow(bx + 16, by + 37 + nudge, 1)
    end
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

local function drawEntry()
  local art = UI.bgSet(G.mode == "rush" and "closing" or "shift")
  if art then UI.drawEntryNew(art); return end
  gfx.setColor(BLACK)
  gfx.fillRect(0, 6, 400, 40)
  bigText(G.mode == "chill" and "Shift Over!" or "Closing Time!", 9, 34, 3)

  local rows = {
    { "Customers served", tostring(G.served) },
    { "Sales", money(G.cash) },
    { "Tips", money(G.tips) },
    { "Walked out", tostring(G.missed) },
  }
  if G.mode == "rush" then                                     -- (still four rows: served and walked-out share one, tips include the combo bonuses)
    rows = {
      { "Served / walked out", G.served .. " / " .. G.missed },
      { "Sales", money(G.cash) },
      { "Tips & combos", money(G.tips) },
      { "Best combo", (G.bestStreak or 0) .. " in a row" },
    }
  end
  local pitch = 15
  for i, row in ipairs(rows) do
    local y = 50 + (i - 1) * pitch
    drawT(row[1], 90, y)
    drawTR(row[2], 310, y)
  end
  gfx.setColor(BLACK)
  gfx.fillRect(80, 112, 240, 2)
  drawT("TOTAL MADE", 90, 116, true)
  drawTR(money(G.total), 310, 116, true)

  drawTC("ENTER YOUR INITIALS", 200, 138, true)
  for i = 1, 3 do
    local bx = 200 - 54 + (i - 1) * 40
    gfx.setColor(BLACK)
    if i == entry.cur then
      gfx.fillRect(bx, 174, 32, 32)
      gfx.fillTriangle(bx + 10, 170, bx + 22, 170, bx + 16, 163)
      gfx.fillTriangle(bx + 10, 210, bx + 22, 210, bx + 16, 217)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRect(bx, 174, 32, 32)
      gfx.setLineWidth(1)
    end
    drawTC(string.char(65 + entry.letters[i]), bx + 16, 180, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setColor(BLACK)
end

-- a small steaming mug for the corners of the board
function UI.drawSmallMug(x, y)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y + 10, 26, 20, 4)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(x, y + 10, 26, 20, 4)
  gfx.drawCircleAtPoint(x + 30, y + 20, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(x + 3, y + 13, 20, 5)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 4, y + 31, 38, 3)
  for k = 0, 1 do
    local px, py = 0, 0
    for i = 0, 5 do
      local yy = y + 6 - i * 2
      local xx = x + 8 + k * 9 + math.sin(frames * 0.15 + i * 0.8 + k * 2) * 2
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

-- the high-score look: double border, bobbing beans, steam rising from two cups
function UI.beanFrame()
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(2, 2, 396, 236, 10)
  gfx.setLineWidth(1)
  gfx.drawRoundRect(7, 7, 386, 226, 7)
  for i = 0, 5 do
    local bob = math.floor(math.sin(frames * 0.12 + i * 1.1) * 3 + 0.5)
    drawBean(22 + (i % 2) * 16, 50 + i * 24 + bob, 1)
    drawBean(378 - (i % 2) * 16, 50 + i * 24 - bob, 1)
  end
  for _, bx in ipairs({ 26, 35, 358, 367 }) do
    local px, py
    for yy = 204, 40, -3 do
      local xx = bx + math.sin(frames * 0.12 + yy * 0.09 + bx) * 3
      if px and (math.floor(yy / (3)) + (math.floor(frames / (6)))) % 6 ~= 0 then
        gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), yy)
      end
      px, py = xx, yy
    end
  end
  UI.drawSmallMug(18, 198)
  UI.drawSmallMug(350, 198)
  gfx.setColor(BLACK)
end

-- the new look: sunburst, lettering, a white sheet with dotted rows (all in the picture) and the words written on top
UI.BOARD_ROW0, UI.BOARD_ROWH = 77, 13               -- must match the picture: first row's top, row pitch
function UI.drawBoardArt(art)
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"
  art[frames % UI.TITLE_N + 1]:draw(0, 0)
  gfx.setColor(BLACK)
  drawTC(name, 200, 51, true)                        -- on the little plate between the arrows

  local function row(i, top)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (math.floor(frames / (8))) % 2 == 0 then          -- your own score blinks
      gfx.setColor(BLACK)
      if i <= 3 then gfx.fillRect(110, top, 208, 12) else gfx.fillRect(82, top, 236, 12) end
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    if i > 3 then drawTC(tostring(i), 98, top - 2, true) end   -- ranks 1-3 are already in their medals
    drawT(e.n, 114, top - 2, true)
    drawTR(money(e.s), 314, top - 2, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, UI.BOARD_ROW0 + (i - 1) * UI.BOARD_ROWH) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    local top = UI.BOARD_ROW0 + 10 * UI.BOARD_ROWH + 4
    for x = 86, 314, 6 do gfx.drawLine(x, top - 3, x + 2, top - 3) end
    row(board.rank, top)
  end

  local back = "B: back"                              -- on the little label, bottom left (a shorter form if this font runs wide)
  if gfx.getTextSize(back) > 60 then back = "B:back" end
  if gfx.getTextSize(back) > 60 then back = "B" end
  drawTC(back, 39, 209, false)
end

local function drawBoard()
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"

  local art = UI.bgSet("scores")
  if art then UI.drawBoardArt(art); return end
  if art == false and frames - (UI.bgFailT or 0) > 45 then UI.bgSets.scores = nil end       -- (the new look did not load: try again in a moment)

  UI.beanFrame()

  -- title band with arrows to switch boards
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(name .. " HIGH SCORES", 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(WHITE)
  gfx.fillTriangle(24, 23, 32, 17, 32, 29)
  gfx.fillTriangle(376, 23, 368, 17, 368, 29)
  gfx.setColor(BLACK)

  local function row(i, y, label)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (math.floor(frames / (8))) % 2 == 0 then
      gfx.setColor(BLACK)
      gfx.fillRect(58, y - 2, 286, 17)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTR(label or tostring(i), 92, y - 1, true)
    drawT(e.n, 104, y - 1, true)
    drawTR(money(e.s), 336, y - 1, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, 39 + (i - 1) * 16) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    for x = 60, 340, 6 do gfx.drawLine(x, 198, x + 2, 198) end
    row(board.rank, 199, "#" .. board.rank)
  end

  drawTC("B: back", 200, 216, true)
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------
local function goTitle()
  sfxClick()
  UI.fast(function()
    local hadShift = G ~= nil
    if G then closeStation() end
    setShiftMenu(false, false)
    state = STATE_MENU
    if hadShift and not UI.color then collectgarbage("collect") end     -- (Playdate: the shift's leftovers go now, while the screen is black, not mid-sunburst later)
  end)
end

CAFE.goTitle = function() goTitle() end

local function startGame(mode)
  sfxClick()
  sfxStart()
  transitionTo(function()
    newGame(mode)
    state = STATE_PLAY
    if not UI.color then UI.loadOn = true end  -- (Playdate: the loading scene while the room is drawn for the first time)
  end)
end

function UI.openBoard(m)
  UI.fast(function()
    board = { mode = "view", rank = nil, m = m, view = m, t = 0 }
    state = STATE_BOARD
    UI.bgSet("scores")
  end)
end

local function updateMenu()
  if pd.buttonJustPressed(pd.kButtonDown) then
    menuSel = menuSel % 4 + 1
    UI.menuCol = 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    menuSel = (menuSel + 2) % 4 + 1
    UI.menuCol = 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonLeft) then
    if menuSel == 4 and UI.menuCol > 1 then UI.menuCol = UI.menuCol - 1; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonRight) then
    if menuSel == 4 and UI.menuCol < 3 then UI.menuCol = UI.menuCol + 1; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if menuSel == 4 and UI.menuCol == 2 then
      UI.openAch()
    elseif menuSel == 4 and UI.menuCol == 3 then
      sfxClick()
      UI.fast(function() UI.settings = { sel = 1 }; UI.bgSet("settings") end)
    elseif menuSel == 4 then
      sfxClick()
      UI.openBoard("rush")
    elseif menuSel == 1 then
      sfxClick()
      CAFE.open()
    else
      startGame(menuSel == 3 and "chill" or "rush")
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick()
    UI.openBoard("rush")
  end
end

local function updateEntry(dt)
  G.endT = G.endT + dt
  if G.endT < 1.5 then return end   -- ignore button mashing as the shift ends
  local e = entry
  local function bump(d)
    e.letters[e.cur] = (e.letters[e.cur] + d) % 26
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonUp) then bump(1)
  elseif pd.buttonJustPressed(pd.kButtonDown) then bump(-1)
  elseif pd.buttonJustPressed(pd.kButtonLeft) then e.cur = math.max(1, e.cur - 1); sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonRight) then e.cur = math.min(3, e.cur + 1); sfxClick() end

  -- the crank spins through the alphabet too
  e.crank = e.crank + pd.getCrankChange()
  while e.crank >= 30 do e.crank = e.crank - 30; bump(1) end
  while e.crank <= -30 do e.crank = e.crank + 30; bump(-1) end

  if pd.buttonJustPressed(pd.kButtonA) then
    if e.cur < 3 then
      e.cur = e.cur + 1
      sfxClick()
    else
      local name = string.char(65 + e.letters[1], 65 + e.letters[2], 65 + e.letters[3])
      local rank = insertScore(G.mode, name, G.total)
      sfxClick()
      local m = G.mode
      transitionTo(function()
        board = { mode = "after", rank = rank, m = m, view = m, t = 0 }
        state = STATE_BOARD
        UI.bgSet("scores")
      end)
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    if e.cur > 1 then e.cur = e.cur - 1; sfxClick() end
  end
end

local function updateBoard(dt)
  board.t = board.t + dt
  -- (after a game the buttons stay locked a moment so a mashed A can't restart it)
  if board.t < (board.mode == "after" and 1.2 or 0.2) then return end
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    board.view = (board.view == "rush") and "chill" or "rush"
    sfxClick()
    return
  end
  if board.mode == "after" then
    if pd.buttonJustPressed(pd.kButtonA) then
      startGame(board.m)
    elseif pd.buttonJustPressed(pd.kButtonB) then
      sfxClick()
      goTitle()
    end
  else
    if pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
      sfxClick()
      goTitle()
    end
  end
end

----------------------------------------------------------------------
-- CAFE mode: three save files, a shop between shifts, stars, decorations, pets
----------------------------------------------------------------------
CAFE.STATE = 5
CAFE.PRICE = 3          -- every shop price is multiplied by this
CAFE.CUP_COST  = { 10, 20, 35, 50, 70, 90, 110, 130 }   -- dollars (x PRICE): cup 3, 4 ... 10
CAFE.SEAT_N    = { 2, 4, 6, 8, 15 }           -- seats after each seating upgrade (the last one is the corner booth: 5 on the couch, 2 chairs)
CAFE.SEAT_COST = { 60 / CAFE.PRICE, 40, 60, 85, 120 }     -- (the first table, in the starting kit, is $60 in the shop)
-- everything you can buy for the looks. kind: wall / floor (placed on a grid spot),
-- rug (one at a time), ceiling, pet.
CAFE.ITEMS = {
  { id = "clock",    name = "Wall clock",     kind = "wall",    cost = 25 },
  { id = "cuckoo",   name = "Cuckoo clock",   kind = "wall",    cost = 55 },
  { id = "calendar", name = "Calendar",       kind = "wall",    cost = 20 },
  { id = "plant",    name = "Spiky plant",    kind = "floor",   cost = 30 },
  { id = "cactus",   name = "Cactus",         kind = "floor",   cost = 25 },
  { id = "fern",     name = "Leafy fern",     kind = "floor",   cost = 30 },
  { id = "flowers",  name = "Flower pot",     kind = "floor",   cost = 35 },
  { id = "tree",     name = "Christmas tree", kind = "floor",   cost = 80 },
  { id = "pumpkin",  name = "Pumpkin",        kind = "floor",   cost = 20 },
  { id = "palm",     name = "Palm tree",      kind = "floor",   cost = 45 },
  { id = "snake",    name = "Snake plant",    kind = "floor",   cost = 30 },
  { id = "sunflower", name = "Sunflowers",    kind = "floor",   cost = 35 },
  { id = "bonsai",   name = "Bonsai",         kind = "floor",   cost = 40 },
  { id = "monstera", name = "Monstera",       kind = "floor",   cost = 40 },
  { id = "saltlamp", name = "Salt lamp",      kind = "counter", cost = 16, lit = true },
  { id = "lavalamp", name = "Lava lamp",      kind = "counter", cost = 18, lit = true },
  { id = "floorlamp", name = "Floor lamp",    kind = "floor",   cost = 35, lit = true },
  { id = "arclamp",  name = "Arc lamp",       kind = "floor",   cost = 45, lit = true },
  { id = "torchiere", name = "Torchiere lamp", kind = "floor",  cost = 40, lit = true },
  { id = "tripodlamp", name = "Tripod lamp",  kind = "floor",   cost = 38, lit = true },
  { id = "globelamp", name = "Globe lamp",    kind = "floor",   cost = 42, lit = true },
  { id = "tiffany",  name = "Tiffany lamp",   kind = "floor",   cost = 55, lit = true },
  { id = "tiffanytab", name = "Tiffany table lamp", kind = "counter", cost = 26, lit = true },
  { id = "streetlamp", name = "Street lamp",  kind = "floor",   cost = 60, lit = true },
  { id = "paperlamp", name = "Paper lantern lamp", kind = "floor", cost = 36, lit = true },
  { id = "neoncup",  name = "Neon cup sign",  kind = "wall",    cost = 40 },
  { id = "neonheart", name = "Neon heart sign", kind = "wall",   cost = 38 },
  { id = "neonbolt", name = "Neon bolt sign", kind = "wall",     cost = 36 },
  { id = "neonstar", name = "Neon star sign", kind = "wall",     cost = 40 },
  { id = "neonmoon", name = "Neon moon sign", kind = "wall",     cost = 42 },
  { id = "neonarrow", name = "Neon arrow sign", kind = "wall",   cost = 34 },
  { id = "discoball", name = "Disco ball",    kind = "wall",     cost = 50 },
  { id = "itemstand", name = "Item stand",    kind = "floor",    cost = 25, stuff = true },
  { id = "pinwheel", name = "Pinwheel",       kind = "counter",  cost = 28, stuff = true },
  { id = "radio",    name = "Retro radio",    kind = "counter",  cost = 45, stuff = true },
  { id = "boombox",  name = "Boom box",       kind = "counter",  cost = 50, stuff = true },
  { id = "luckycat", name = "Lucky cat",      kind = "counter",  cost = 48, stuff = true },
  { id = "record",   name = "Record player",  kind = "counter",  cost = 55, stuff = true },
  { id = "snowglobe", name = "Snow globe",    kind = "counter",  cost = 36, stuff = true },
  { id = "gumball",  name = "Gumball machine", kind = "counter", cost = 40, stuff = true },
  { id = "cradle",   name = "Newton's cradle", kind = "counter", cost = 34, stuff = true },
  { id = "miniplaydate", name = "Pee-Dee",    kind = "counter",  cost = 60, stuff = true },
  { id = "jukebox",  name = "Juke box",       kind = "floor",    cost = 85, stuff = true },
  { id = "wf1", name = "Single pane", kind = "frame", cost = 25 },
  { id = "wf2", name = "Six panes", kind = "frame", cost = 30 },
  { id = "wf3", name = "Diamond panes", kind = "frame", cost = 35 },
  { id = "wf4", name = "Windowsill", kind = "frame", cost = 35 },
  { id = "wf5", name = "Arched window", kind = "frame", cost = 40 },
  { id = "wf6", name = "Shutters", kind = "frame", cost = 45 },
  { id = "wc1", name = "Plain curtains", kind = "curtain", cost = 15 },
  { id = "wc2", name = "Checker curtains", kind = "curtain", cost = 18 },
  { id = "wc3", name = "Striped curtains", kind = "curtain", cost = 18 },
  { id = "wc4", name = "Scalloped valance", kind = "curtain", cost = 20 },
  { id = "wc5", name = "Lace curtains", kind = "curtain", cost = 22 },
  { id = "wc6", name = "Polka dot curtains", kind = "curtain", cost = 20 },
  { id = "wc7", name = "Coffee bean curtains", kind = "curtain", cost = 25 },
  { id = "wc8", name = "Window blinds", kind = "curtain", cost = 20 },
  { id = "wc9", name = "Heart curtains", kind = "curtain", cost = 22 },
  { id = "wc10", name = "Starry night curtains", kind = "curtain", cost = 28 },
  { id = "wc11", name = "Pastel floral curtains", kind = "curtain", cost = 26 },
  { id = "wc12", name = "Gingham cafe curtains", kind = "curtain", cost = 24 },
  { id = "wc13", name = "Royal velvet drapes", kind = "curtain", cost = 32 },
  { id = "wc14", name = "Matcha sprig curtains", kind = "curtain", cost = 26 },
  { id = "wc15", name = "Tartan curtains", kind = "curtain", cost = 24 },
  { id = "wc16", name = "Daisy curtains", kind = "curtain", cost = 26 },
  { id = "tulips",   name = "Tulip pot",      kind = "counter", cost = 15 },
  { id = "succ",     name = "Succulent",      kind = "counter", cost = 12 },
  { id = "daisies",  name = "Daisy vase",     kind = "counter", cost = 18 },
  { id = "minicac",  name = "Mini cactus",    kind = "counter", cost = 12 },
  { id = "herbs",    name = "Herb pot",       kind = "counter", cost = 15 },
  { id = "ivy",      name = "Ivy vines",      kind = "shelf",   cost = 25 },
  { id = "bloomvine", name = "Flowering vines", kind = "shelf", cost = 35 },
  { id = "fernvine", name = "Fern fronds",    kind = "shelf",   cost = 28 },
  { id = "heartvine", name = "Heart vines",   kind = "shelf",   cost = 32 },
  { id = "berryvine", name = "Berry vines",   kind = "shelf",   cost = 30 },
  { id = "starvine", name = "Twinkle vines",  kind = "shelf",   cost = 38 },
  { id = "moss",     name = "Hanging moss",   kind = "shelf",   cost = 22 },
  { id = "beadvine", name = "Bead strands",   kind = "shelf",   cost = 26 },
  { id = "wisteria", name = "Wisteria",       kind = "shelf",   cost = 40 },
  { id = "lanternvine", name = "Lantern strings", kind = "shelf", cost = 42 },
  { id = "lights",   name = "String lights",  kind = "ceiling", cost = 45, lit = true },
  { id = "fairylights", name = "Fairy lights", kind = "ceiling", cost = 40, lit = true },
  { id = "globelights", name = "Globe lights", kind = "ceiling", cost = 50, lit = true },
  { id = "lanternlights", name = "Lantern lights", kind = "ceiling", cost = 48, lit = true },
  { id = "heartlights", name = "Heart lights", kind = "ceiling", cost = 52, lit = true },
  { id = "starlights", name = "Star lights",  kind = "ceiling", cost = 55, lit = true },
  { id = "candle1",  name = "Pillar candle",  kind = "counter", cost = 12, lit = true },
  { id = "candle2",  name = "Taper candle",   kind = "counter", cost = 14, lit = true },
  { id = "candle3",  name = "Tealight trio",  kind = "counter", cost = 14, lit = true },
  { id = "candle4",  name = "Jar candle",     kind = "counter", cost = 16, lit = true },
  { id = "candle5",  name = "Candelabra",     kind = "counter", cost = 28, lit = true },
  { id = "candle6",  name = "Candle lantern", kind = "counter", cost = 24, lit = true },
  { id = "candle7",  name = "Floating candles", kind = "counter", cost = 22, lit = true },
  { id = "incense",  name = "Incense stick", kind = "counter", cost = 10, lit = true },
  { id = "rug",      name = "Welcome rug",    kind = "rug",     cost = 35 },
  { id = "rug2",     name = "Striped rug",    kind = "rug",     cost = 40 },
  { id = "rug3",     name = "Checker rug",    kind = "rug",     cost = 45 },
  { id = "rug4",     name = "Polka dot rug",  kind = "rug",     cost = 45 },
  { id = "rug5",     name = "Lattice rug",    kind = "rug",     cost = 50 },
  { id = "rug6",     name = "Plaid rug",      kind = "rug",     cost = 50 },
  { id = "rug7",     name = "Coffee bean rug", kind = "rug",    cost = 55 },
  { id = "rug8",     name = "Ripple rug",     kind = "rug",     cost = 50 },
  { id = "rug9",     name = "Sunburst rug",   kind = "rug",     cost = 55 },
  { id = "rug10",    name = "Diamond rug",    kind = "rug",     cost = 48 },
  { id = "rug11",    name = "Zigzag rug",     kind = "rug",     cost = 48 },
  { id = "rug12",    name = "Royal rug",      kind = "rug",     cost = 60 },
  { id = "rug13",    name = "Pastel floral rug", kind = "rug",  cost = 58 },
  { id = "rug14",    name = "Matcha rug",     kind = "rug",     cost = 58 },
  { id = "orug1",    name = "Cozy oval rug",  kind = "orug",    cost = 60 },
  { id = "orug2",    name = "Ripple oval rug", kind = "orug",   cost = 65 },
  { id = "orug3",    name = "Checker oval rug", kind = "orug",  cost = 65 },
  { id = "orug4",    name = "Polka dot oval rug", kind = "orug", cost = 70 },
  { id = "orug5",    name = "Sunburst oval rug", kind = "orug", cost = 75 },
  { id = "orug6",    name = "Coffee bean oval rug", kind = "orug", cost = 80 },
  { id = "orug7",    name = "Striped oval rug", kind = "orug",  cost = 62 },
  { id = "orug8",    name = "Lattice oval rug", kind = "orug",  cost = 70 },
  { id = "orug9",    name = "Plaid oval rug", kind = "orug",    cost = 70 },
  { id = "orug10",   name = "Diamond oval rug", kind = "orug",  cost = 68 },
  { id = "orug11",   name = "Zigzag oval rug", kind = "orug",   cost = 68 },
  { id = "orug12",   name = "Royal oval rug", kind = "orug",    cost = 85 },
  { id = "orug13",   name = "Pastel floral oval rug", kind = "orug", cost = 78 },
  { id = "orug14",   name = "Matcha oval rug", kind = "orug",   cost = 78 },
  { id = "rug15", name = "Argyle rug", kind = "rug", cost = 56 },
  { id = "rug16", name = "Fish-scale rug", kind = "rug", cost = 58 },
  { id = "rug17", name = "Sweetheart rug", kind = "rug", cost = 60 },
  { id = "rug18", name = "Ocean wave rug", kind = "rug", cost = 56 },
  { id = "rug19", name = "Moroccan tile rug", kind = "rug", cost = 58 },
  { id = "rug20", name = "Daisy rug", kind = "rug", cost = 60 },
  { id = "orug15", name = "Argyle oval rug", kind = "orug", cost = 78 },
  { id = "orug16", name = "Fish-scale oval rug", kind = "orug", cost = 80 },
  { id = "orug17", name = "Sweetheart oval rug", kind = "orug", cost = 82 },
  { id = "orug18", name = "Ocean wave oval rug", kind = "orug", cost = 78 },
  { id = "orug19", name = "Moroccan tile oval rug", kind = "orug", cost = 80 },
  { id = "orug20", name = "Daisy oval rug", kind = "orug", cost = 82 },
  { id = "run6",     name = "Polka dot runner", kind = "runner", cost = 38 },
  { id = "run7",     name = "Zigzag runner",  kind = "runner", cost = 40 },
  { id = "run8",     name = "Plaid runner",   kind = "runner", cost = 42 },
  { id = "run1",     name = "Red carpet runner", kind = "runner", cost = 40 },
  { id = "run2",     name = "Striped runner", kind = "runner", cost = 35 },
  { id = "run3",     name = "Checker runner", kind = "runner", cost = 35 },
  { id = "run4",     name = "Diamond runner", kind = "runner", cost = 40 },
  { id = "run5",     name = "Coffee bean runner", kind = "runner", cost = 45 },
  { id = "run9",     name = "Cozy runner",    kind = "runner", cost = 35 },
  { id = "run10",    name = "Lattice runner", kind = "runner", cost = 40 },
  { id = "run11",    name = "Ripple runner",  kind = "runner", cost = 40 },
  { id = "run12",    name = "Sunburst runner", kind = "runner", cost = 45 },
  { id = "run13",    name = "Pastel floral runner", kind = "runner", cost = 44 },
  { id = "run14",    name = "Matcha runner",  kind = "runner", cost = 44 },
  { id = "run15", name = "Argyle runner", kind = "runner", cost = 44 },
  { id = "run16", name = "Fish-scale runner", kind = "runner", cost = 46 },
  { id = "run17", name = "Sweetheart runner", kind = "runner", cost = 48 },
  { id = "run18", name = "Ocean wave runner", kind = "runner", cost = 44 },
  { id = "run19", name = "Moroccan tile runner", kind = "runner", cost = 46 },
  { id = "run20", name = "Daisy runner", kind = "runner", cost = 48 },
  { id = "t1",       name = "Tiny landscape",  kind = "tiny", cost = 8 },
  { id = "t2",       name = "Tiny heart",      kind = "tiny", cost = 8 },
  { id = "t3",       name = "Tiny sunburst",   kind = "tiny", cost = 10 },
  { id = "t4",       name = "Tiny mug print",  kind = "tiny", cost = 10 },
  { id = "t5",       name = "Cat portrait",    kind = "tiny", cost = 12 },
  { id = "t6",       name = "Tiny mirror",     kind = "tiny", cost = 12 },
  { id = "t7",       name = "Party bunting",   kind = "tiny", cost = 14 },
  { id = "t8",       name = "Little stars",    kind = "tiny", cost = 8 },
  { id = "t9",       name = "Music notes",     kind = "tiny", cost = 10 },
  { id = "t10",      name = "Moon and stars",  kind = "tiny", cost = 12 },
  { id = "t12",      name = "Sailboat",        kind = "tiny", cost = 10 },
  { id = "t13",      name = "Pastel bouquet",  kind = "tiny", cost = 14 },
  { id = "t14",      name = "Matcha painting", kind = "tiny", cost = 14 },
  { id = "t15", name = "Latte art", kind = "tiny", cost = 16 },
  { id = "t16", name = "Cherry blossoms", kind = "tiny", cost = 18 },
  { id = "t17", name = "City at night", kind = "tiny", cost = 18 },
  { id = "t18", name = "Coffee cherries", kind = "tiny", cost = 16 },
  { id = "t19", name = "Hot air balloon", kind = "tiny", cost = 18 },
  { id = "cloth1",   name = "Checker tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth2",   name = "Striped tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth3",   name = "Lace tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth4",   name = "Polka dot tablecloth", kind = "cloth", cost = 32 },
  { id = "cloth5",   name = "Plaid tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth6",   name = "Diamond tablecloth", kind = "cloth", cost = 36 },
  { id = "cloth7",   name = "Coffee bean tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth8",   name = "Heart tablecloth", kind = "cloth", cost = 36 },
  { id = "cloth9",   name = "Bordered tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth10",  name = "Starry tablecloth", kind = "cloth", cost = 42 },
  { id = "cloth11",  name = "Zigzag tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth12",  name = "Floral tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth13",  name = "Wavy tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth14",  name = "Paw print tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth15",  name = "Leafy vine tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth16",  name = "Snowflake tablecloth", kind = "cloth", cost = 42 },
  { id = "cloth17",  name = "Stitched tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth18",  name = "Harlequin tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth19",  name = "Ringed tablecloth", kind = "cloth", cost = 32 },
  { id = "cloth20",  name = "Pastel floral tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth21",  name = "Matcha tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth22", name = "Argyle tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth23", name = "Fish-scale tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth24", name = "Moroccan tile tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth25", name = "Daisy tablecloth", kind = "cloth", cost = 40 },
  { id = "cattree",  name = "Cat tree",       kind = "floor",   cost = 60, needs = "cat" },
  { id = "dogbed",   name = "Dog bed",        kind = "floor",   cost = 45, needs = "dog" },
  { id = "aquarium", name = "Fish tank",      kind = "counter", cost = 55, pettab = true },
  { id = "snaketank", name = "Snake tank",    kind = "counter", cost = 70, pettab = true },
  { id = "axotank",  name = "Pink axolotl",   kind = "counter", cost = 75, pettab = true },
  { id = "axowild",  name = "Wild axolotl",   kind = "counter", cost = 75, pettab = true },
  { id = "axogold",  name = "Golden axolotl", kind = "counter", cost = 80, pettab = true },
  { id = "hamster",  name = "Golden hamster", kind = "counter", cost = 55, pettab = true, ham = true },
  { id = "hamwhite", name = "White hamster",  kind = "counter", cost = 55, pettab = true, ham = true },
  { id = "hamgray",  name = "Gray hamster",   kind = "counter", cost = 55, pettab = true, ham = true },
  { id = "parrot",   name = "Green parrot",   kind = "counter", cost = 90, pettab = true, bird = "parrot" },
  { id = "macaw",    name = "Scarlet macaw",  kind = "counter", cost = 110, pettab = true, bird = "parrot" },
  { id = "bluemacaw", name = "Blue macaw",    kind = "counter", cost = 110, pettab = true, bird = "parrot" },
  { id = "cockatiel", name = "Cockatiel",     kind = "counter", cost = 85, pettab = true, bird = "parrot" },
  { id = "barnowl",  name = "Barn owl",       kind = "counter", cost = 100, pettab = true, bird = "owl" },
  { id = "snowyowl", name = "Snowy owl",      kind = "counter", cost = 110, pettab = true, bird = "owl" },
  { id = "hornowl",  name = "Horned owl",     kind = "counter", cost = 105, pettab = true, bird = "owl" },
  { id = "cat",      name = "Black cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "tuxcat",   name = "Tuxedo cat",     kind = "pet",     cost = 150, species = "cat" },
  { id = "tabbycat", name = "Tabby cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "calicocat", name = "Calico cat",    kind = "pet",     cost = 160, species = "cat" },
  { id = "graycat",  name = "Gray cat",       kind = "pet",     cost = 150, species = "cat" },
  { id = "dog",      name = "Black dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "dalmatian", name = "Dalmatian",     kind = "pet",     cost = 160, species = "dog" },
  { id = "husky",    name = "Husky",          kind = "pet",     cost = 170, species = "dog" },
  { id = "patchdog", name = "Patch dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "goldendog", name = "Golden dog",    kind = "pet",     cost = 160, species = "dog" },
  { id = "corgi",    name = "Corgi",          kind = "pet",     cost = 165, species = "dog" },
  { id = "tricorgi", name = "Tricolor corgi", kind = "pet",     cost = 170, species = "dog" },
  { id = "turtle",   name = "Green turtle",   kind = "pet",     cost = 120, species = "turtle" },
  { id = "boxturtle", name = "Box turtle",    kind = "pet",     cost = 130, species = "turtle" },
  { id = "tortoise", name = "Tortoise",       kind = "pet",     cost = 140, species = "turtle" },
  { id = "slider",   name = "Red-ear turtle", kind = "pet",     cost = 130, species = "turtle" },
  { id = "bunny",    name = "White bunny",    kind = "pet",     cost = 130, species = "bunny" },
  { id = "brownbun", name = "Brown bunny",    kind = "pet",     cost = 130, species = "bunny" },
  { id = "graybun",  name = "Gray bunny",     kind = "pet",     cost = 130, species = "bunny" },
  { id = "dutchbun", name = "Dutch bunny",    kind = "pet",     cost = 140, species = "bunny" },
  { id = "lopbun",   name = "Lop-eared bunny", kind = "pet",    cost = 145, species = "bunny" },
  { id = "h_cap",     name = "Baseball cap",   kind = "hat",     cost = 12 },
  { id = "h_top",     name = "Top hat",        kind = "hat",     cost = 25 },
  { id = "h_beanie",  name = "Pom beanie",     kind = "hat",     cost = 14 },
  { id = "h_cowboy",  name = "Cowboy hat",     kind = "hat",     cost = 22 },
  { id = "h_chef",    name = "Chef hat",       kind = "hat",     cost = 18 },
  { id = "h_crown",   name = "Golden crown",   kind = "hat",     cost = 60 },
  { id = "h_party",   name = "Party hat",      kind = "hat",     cost = 10 },
  { id = "h_beret",   name = "Beret",          kind = "hat",     cost = 16 },
  { id = "h_santa",   name = "Santa hat",      kind = "hat",     cost = 20 },
  { id = "h_wizard",  name = "Wizard hat",     kind = "hat",     cost = 40 },
  { id = "h_witch",   name = "Witch hat",      kind = "hat",     cost = 35 },
  { id = "h_bow",     name = "Big bow",        kind = "hat",     cost = 12 },
  { id = "h_flower",  name = "Flower band",    kind = "hat",     cost = 14 },
  { id = "h_prop",    name = "Propeller cap",  kind = "hat",     cost = 18 },
  { id = "h_viking",  name = "Viking helmet",  kind = "hat",     cost = 38 },
  { id = "h_halo",    name = "Halo",           kind = "hat",     cost = 45 },
  { id = "h_wreath",  name = "Flower crown",   kind = "hat",     cost = 24 },
  { id = "h_pirate",  name = "Pirate hat",     kind = "hat",     cost = 32 },
  { id = "h_frog",    name = "Frog hat",       kind = "hat",     cost = 20 },
  { id = "h_bunny",   name = "Bunny ears",     kind = "hat",     cost = 16 },
  { id = "h_bucket",  name = "Bucket hat",     kind = "hat",     cost = 15 },
  { id = "g_round",   name = "Round glasses",  kind = "glasses", cost = 10 },
  { id = "g_square",  name = "Square glasses", kind = "glasses", cost = 12 },
  { id = "g_shades",  name = "Sunglasses",     kind = "glasses", cost = 18 },
  { id = "g_heart",   name = "Heart glasses",  kind = "glasses", cost = 20 },
  { id = "g_cat",     name = "Cat-eye glasses", kind = "glasses", cost = 22 },
  { id = "g_nerd",    name = "Thick frames",   kind = "glasses", cost = 14 },
  { id = "g_monocle", name = "Fancy monocle",  kind = "glasses", cost = 30 },
  { id = "g_3d",      name = "3D glasses",     kind = "glasses", cost = 16 },
  { id = "g_star",    name = "Star glasses",   kind = "glasses", cost = 24 },
}
-- ---- wallpaper and flooring: one of each at a time, from their own shop tabs --------------------------------
-- Playdate: each is a light 1-bit pattern (the wall stays calm behind the decor); PC: each has its own colours.
CAFE.WALLPAPERS = {
  { "wp1", "Plaster wallpaper", "plaster", 30, "Soft and plain" },
  { "wp2", "Pinstripe wallpaper", "stripe", 34, "Thin and tidy stripes" },
  { "wp3", "Checker wallpaper", "check", 36, "Big bold checks" },
  { "wp4", "Polka dot wallpaper", "polka", 34, "Dots all over" },
  { "wp5", "Lattice wallpaper", "lattice", 38, "A garden trellis" },
  { "wp6", "Plaid wallpaper", "plaid", 40, "Cozy as a flannel" },
  { "wp7", "Coffee bean wallpaper", "bean", 40, "Beans, beans, beans" },
  { "wp8", "Ripple wallpaper", "ripple", 36, "Gentle waves" },
  { "wp9", "Sunburst wallpaper", "sun", 44, "Rays from up top" },
  { "wp10", "Diamond wallpaper", "diamond", 40, "Rows of little gems" },
  { "wp11", "Zigzag wallpaper", "zigzag", 38, "Zig, then zag" },
  { "wp12", "Royal wallpaper", "royal", 60, "Gold on deep purple" },
  { "wp13", "Pastel floral wallpaper", "floral", 50, "Spring on the walls" },
  { "wp14", "Matcha wallpaper", "matcha", 50, "Calm green sprigs" },
  { "wp15", "Brick wallpaper", "brick", 46, "A cozy brick wall" },
  { "wp16", "Wood panel wallpaper", "wood", 48, "Warm wooden boards" },
  { "wp17", "Wainscot wallpaper", "wainscot", 52, "Panels below, stripes above" },
  { "wp18", "Starry night wallpaper", "stars", 56, "A night sky indoors" },
  { "wp19", "Espresso wallpaper", "espresso", 44, "Dark and rich" },
  { "wp20", "Argyle wallpaper", "argyle", 46, "Preppy and cozy" },
  { "wp21", "Fish-scale wallpaper", "scallop", 44, "Little seaside scallops" },
  { "wp22", "Sweetheart wallpaper", "hearts", 44, "Hearts all over" },
  { "wp23", "Ocean wave wallpaper", "waves", 42, "Calm rolling waves" },
  { "wp24", "Moroccan tile wallpaper", "quatre", 52, "Four-leaf tiles" },
  { "wp25", "Daisy wallpaper", "daisy", 46, "A field of daisies" },
}
CAFE.FLOORINGS = {
  { "flr1", "Wood plank floor", "planks", 50, "Classic wooden boards" },
  { "flr2", "Square tile floor", "tiles", 46, "Clean square tiles" },
  { "flr3", "Diner checker floor", "checker", 56, "A retro diner look" },
  { "flr4", "Terrazzo floor", "terrazzo", 52, "Speckled and smooth" },
  { "flr5", "Hex tile floor", "hex", 58, "Little honeycomb tiles" },
  { "flr6", "Parquet floor", "parquet", 60, "Blocks of wood, this way and that" },
  { "flr7", "Herringbone floor", "herring", 64, "A fancy zigzag of boards" },
  { "flr8", "Slate floor", "slate", 54, "Cool grey stone" },
  { "flr9", "Fish-scale tile floor", "scallop", 60, "Shiny little scales" },
  { "flr10", "Moroccan tile floor", "quatre", 66, "Four-leaf tiles underfoot" },
  { "flr11", "Harlequin floor", "argyle", 62, "Diamonds, edge to edge" },
}
CAFE.WPDATA, CAFE.FLDATA = {}, {}
for _, w in ipairs(CAFE.WALLPAPERS) do
  CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = w[1], name = w[2], kind = "wallpaper", cost = w[4] }
  CAFE.WPDATA[w[1]] = { pat = w[3], desc = w[5] }
end
for _, w in ipairs(CAFE.FLOORINGS) do
  CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = w[1], name = w[2], kind = "flooring", cost = w[4] }
  CAFE.FLDATA[w[1]] = { pat = w[3], desc = w[5] }
end

-- ---- seating: the fabric on every chair and on the corner couch (one at a time, from its own shop tab) -------------
-- id, name, look (a pattern, or "plain" for a solid colour), cost, words under the price,
-- and for a solid colour, how the Playdate shows it: a shade (w white, l light, d mid, k dark, b black) and a detail
-- (piping round the edge, tufted buttons, a vinyl shine, or one button in the middle). PC: rows sf_<id> / sk_<id>.
CAFE.SEATINGS = {
  { "st_cozy", "Cozy knit seats", "cozy", 40, "Snug as a sweater" },
  { "st_stripe", "Cabana stripe seats", "stripe", 42, "Seaside stripes" },
  { "st_check", "Gingham seats", "check", 42, "Picnic checks" },
  { "st_polka", "Polka dot seats", "polka", 44, "Dots, dots, dots" },
  { "st_lattice", "Trellis seats", "lattice", 46, "A garden lattice" },
  { "st_plaid", "Tartan seats", "plaid", 48, "Cozy cabin plaid" },
  { "st_bean", "Coffee bean seats", "bean", 50, "Sit on the good stuff" },
  { "st_ripple", "Channel-tufted seats", "ripple", 52, "Plush stitched rows" },
  { "st_sun", "Sunburst seats", "sun", 50, "A little sun on every seat" },
  { "st_diamond", "Quilted diamond seats", "diamond", 54, "Soft quilted diamonds" },
  { "st_zigzag", "Chevron seats", "zigzag", 46, "Zig, then zag" },
  { "st_royal", "Royal velvet seats", "royal", 70, "Gold on deep purple" },
  { "st_floral", "Pastel floral seats", "floral", 56, "A garden to sit in" },
  { "st_matcha", "Matcha sprig seats", "matcha", 56, "Calm green sprigs" },
  { "st_stars", "Starry night seats", "stars", 60, "Sit under the stars" },
  { "st_argyle", "Argyle seats", "argyle", 52, "Preppy diamonds" },
  { "st_scallop", "Fish-scale seats", "scallop", 50, "Little scallops" },
  { "st_hearts", "Sweetheart seats", "hearts", 52, "Lots of love" },
  { "st_waves", "Ocean wave seats", "waves", 48, "Gentle waves" },
  { "st_quatre", "Moroccan tile seats", "quatre", 56, "Four-leaf tiles" },
  { "st_daisy", "Daisy seats", "daisy", 54, "Fresh as spring" },
  { "st_cherry", "Cherry red vinyl", "plain", 46, "Classic diner red", "k", "shine" },
  { "st_navy", "Navy velvet", "plain", 54, "Deep and dreamy", "b", "piping" },
  { "st_mint", "Mint green seats", "plain", 40, "Cool and fresh", "l", "button" },
  { "st_mustard", "Mustard seats", "plain", 42, "Warm and retro", "d", "button" },
  { "st_blush", "Blush pink seats", "plain", 40, "Soft and sweet", "w", "piping" },
  { "st_forest", "Forest velvet", "plain", 54, "Deep woodland green", "k", "piping" },
  { "st_lav", "Lavender seats", "plain", 42, "Calm and dreamy", "l", "piping" },
  { "st_caramel", "Caramel leather", "plain", 60, "Buttery soft, tufted", "l", "tuft" },
  { "st_charcoal", "Charcoal leather", "plain", 60, "Sleek and tufted", "b", "tuft" },
  { "st_sky", "Sky blue seats", "plain", 40, "Clear blue skies", "w", "button" },
}
CAFE.STDATA = {}
function CAFE.addSeatings()                        -- (in a function: the main chunk is out of room for loop variables)
  for _, w in ipairs(CAFE.SEATINGS) do
    CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = w[1], name = w[2], kind = "seating", cost = w[4] }
    local k = string.sub(w[1], 4)
    CAFE.STDATA[w[1]] = { pat = w[3], desc = w[5], shade = w[6], detail = w[7], row = "sf_" .. k, frame = "sk_" .. k }
  end
end
CAFE.addSeatings()

CAFE.byId = {}
CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = "hmus", name = "Halloween music", kind = "music", cost = 60 }       -- the Music tab: two records, either or both
CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = "xmus", name = "Christmas music", kind = "music", cost = 60 }
for _, it in ipairs(CAFE.ITEMS) do CAFE.byId[it.id] = it end
-- a few words under the price in the shop
CAFE.DESC = {
  clock = "Tick-tock!", cuckoo = "Cuckoo! Cuckoo!", calendar = "Every day counts",
  tree = "Ho ho ho!", pumpkin = "Spooky season!", palm = "Vacation vibes",
  cactus = "Ouch! Cute, though", flowers = "Smells lovely", plant = "Low maintenance",
  fern = "Lush little jungle", snake = "Tough as nails", sunflower = "Soak up the sun", bonsai = "Zen in a pot",
  monstera = "Big leafy energy", tulips = "Spring in a pot", succ = "Hardly needs water", daisies = "Fresh and cheerful",
  minicac = "Small but prickly", herbs = "Fresh and fragrant",
  lights = "Cozy glow", fairylights = "Tiny twinkling lights", globelights = "An old-time glow", lanternlights = "Paper lanterns on a string",
  heartlights = "Hearts all around", starlights = "A sky of little stars", ivy = "Hanging around", bloomvine = "In full bloom",
  fernvine = "Feathery and fresh", heartvine = "Love is in the air", berryvine = "Ripe for the picking",
  starvine = "Twinkle, twinkle", moss = "Soft and wispy", beadvine = "Strings of beads",
  wisteria = "Dreamy purple vibes", lanternvine = "Little glowing lanterns",
  rug = "Wipe your feet", rug2 = "Wipe your feet", rug3 = "Wipe your feet",
  run1 = "Roll out the red carpet", run2 = "Rolls out at the register", run3 = "Rolls out at the register",
  run4 = "Rolls out at the register", run5 = "Rolls out at the register",
  t1 = "Hang it up high", t2 = "Made with love", t3 = "Rise and shine", t4 = "Mug shot", t5 = "Meow",
  t6 = "Mirror, mirror", t7 = "Party time!", t8 = "Wish upon a star", t9 = "La la la", t10 = "Sweet dreams",
  t12 = "Smooth sailing", t13 = "Flowers that never wilt", t14 = "A calm cup of green",
  t15 = "A heart in the foam", t16 = "Spring on a branch", t17 = "Lights in every window", t18 = "Where coffee comes from", t19 = "Up, up and away",
  rug13 = "Pastel flowers underfoot", rug14 = "Fresh as green tea", orug13 = "A garden under the tables", orug14 = "Leafy and calm",
  run13 = "A flower path to the register", run14 = "Green leaves to the register",
  rug15 = "Preppy diamonds", orug15 = "Preppy diamonds", run15 = "Preppy diamonds",
  rug16 = "Seaside scallops", orug16 = "Seaside scallops", run16 = "Seaside scallops",
  rug17 = "Hearts underfoot", orug17 = "Hearts underfoot", run17 = "Hearts underfoot",
  rug18 = "Gentle waves", orug18 = "Gentle waves", run18 = "Gentle waves",
  rug19 = "Four-leaf tiles", orug19 = "Four-leaf tiles", run19 = "Four-leaf tiles",
  rug20 = "A field of daisies", orug20 = "A field of daisies", run20 = "A field of daisies",
  cloth22 = "Preppy diamonds round the rim", cloth23 = "Scallops round every table", cloth24 = "Moroccan tiles on every table", cloth25 = "Daisies round every table", cloth20 = "Pastel flowers on every table", cloth21 = "Matcha green on every table",
  cloth1 = "Dress up every table", cloth2 = "Dress up every table", cloth3 = "Dress up every table",
  cloth4 = "Dress up every table", cloth5 = "Dress up every table", cloth6 = "Dress up every table", cloth7 = "Dress up every table",
  cloth8 = "Dress up every table", cloth9 = "Dress up every table", cloth10 = "Dress up every table", cloth11 = "Dress up every table",
  cloth12 = "Flowers on every table", cloth13 = "Makes waves", cloth14 = "Pitter patter", cloth15 = "A garden on every table",
  cloth16 = "Let it snow", cloth17 = "Handmade charm", cloth18 = "Bold and jolly", cloth19 = "Rings around the table",
  candle1 = "Sits on a counter or table", candle2 = "Sits on a counter or table", candle3 = "Sits on a counter or table",
  candle4 = "Sits on a counter or table", candle5 = "Sits on a counter or table", candle6 = "Sits on a counter or table", candle7 = "Sits on a counter or table", incense = "Calm, smoky and fragrant",
  neonheart = "Be still my heart", neonbolt = "Shocking!", neonstar = "You're a star", neonmoon = "Open past midnight",
  arclamp = "Reach for the light", torchiere = "Light up the ceiling", tripodlamp = "Standing tall",
  globelamp = "A glowing moon", tiffany = "Stained glass glow", streetlamp = "Gaslight vibes", paperlamp = "Soft paper glow",
  neonarrow = "This way for coffee!", discoball = "Let's dance!", aquarium = "Swimming along", snaketank = "Slithers all day", turtle = "Slow and steady", boxturtle = "Snug in its shell", tortoise = "Old and wise", slider = "Sunbathing champ", pinwheel = "Spin, spin, spin", radio = "Tunes all day",
  boombox = "Pump up the volume", luckycat = "Waves in good luck", record = "Spin that record", snowglobe = "Shake, shake, shake",
  gumball = "A penny for a gumball", cradle = "Click, clack, click", miniplaydate = "Cranking it all day", jukebox = "Drop a coin, pick a tune",
  cp1 = "A centrepiece for every table", cp2 = "Dinner by candlelight", cp3 = "A little green", cp4 = "Tiny and spiky",
  rug4 = "Wipe your feet", rug5 = "Wipe your feet", rug6 = "Wipe your feet", rug7 = "Wipe your feet",
  orug1 = "Sits under the tables", orug2 = "Ripples under the tables", orug3 = "Sits under the tables", orug4 = "Spots under the tables", orug5 = "Sunshine for your tables", orug6 = "Beans under the tables",
  run6 = "Rolls out at the register", run7 = "Rolls out at the register", run8 = "Rolls out at the register",
  run9 = "Rolls out at the register", run10 = "Rolls out at the register", run11 = "Rolls out at the register", run12 = "Rolls out at the register",
  rug8 = "Wipe your feet", rug9 = "Wipe your feet", rug10 = "Wipe your feet", rug11 = "Wipe your feet", rug12 = "Wipe your feet in style",
  orug7 = "Stripes under the tables", orug8 = "Sits under the tables", orug9 = "Sits under the tables", orug10 = "Sparkles under the tables",
  orug11 = "Zigs under the tables", orug12 = "Fit for royalty",
  cp5 = "Spooky season, every table", cp6 = "Merry little tables",
  cat = "Boosts stars and tips", dog = "Boosts stars and tips",
  cattree = "The cat will love it", dogbed = "A nap spot for the dog",
  wf1 = "One big pane", wf2 = "Six little panes", wf3 = "Fancy diamonds", wf4 = "A ledge for plants", wf5 = "A rounded top", wf6 = "Open the shutters",
  wc1 = "Soft and simple", wc2 = "Checked and cozy", wc3 = "Stripes all the way", wc4 = "A frilly top", wc5 = "Light and lacy",
  wc6 = "Spot on", wc7 = "Smells like coffee", wc8 = "Half way down", wc9 = "Made with love", wc10 = "Twinkle twinkle",
  wc11 = "Pastel petals", wc12 = "Half curtains, very French", wc13 = "Deep velvet, gold sashes", wc14 = "Calm green sprigs",
  wc15 = "Cozy tartan", wc16 = "Daisies on blue",
  tuxcat = "Dressed for dinner", tabbycat = "Stripes and sass", calicocat = "Patches of everything", graycat = "Soft and silvery",
  dalmatian = "Spots on spots", husky = "Fluffy and loud", patchdog = "One patchy eye", goldendog = "A very good boy",
  corgi = "Short legs, big heart", tricorgi = "Three colours of cute",
  bunny = "Hop, hop, hop!", brownbun = "Soft as cocoa", graybun = "A little gray cloud", dutchbun = "Two-tone and fancy", lopbun = "Ears all the way down",
  axotank = "Smiles all day", axowild = "Wild and wiggly", axogold = "A golden grin",
  hamster = "Runs on its wheel", hamwhite = "A tiny snowball", hamgray = "Small and speedy",
  parrot = "It talks back!", macaw = "Loud and proud", bluemacaw = "Big, blue and chatty", cockatiel = "Whistles a tune",
  barnowl = "Hoo goes there?", snowyowl = "Snowy and wise", hornowl = "A night watchman",
  h_cap = "Brim to the back", h_top = "Very fancy", h_beanie = "Warm and fuzzy", h_cowboy = "Howdy, partner", h_chef = "Order up!",
  h_crown = "Royal barista", h_party = "Every day's a party", h_beret = "Oui oui", h_santa = "Ho ho ho!", h_wizard = "Brews magic coffee",
  h_witch = "Brews spooky coffee", h_bow = "So cute", h_flower = "Fresh as a daisy",
  h_prop = "Ready for take-off", h_viking = "Brews like a warrior", h_halo = "An angel of a barista", h_wreath = "Spring on your head",
  h_pirate = "Arr, coffee, matey!", h_frog = "Ribbit!", h_bunny = "Hop to it!", h_bucket = "Laid-back vibes", g_star = "A real superstar",
  g_round = "Classic look", g_square = "Sharp and smart", g_shades = "Too cool", g_heart = "Love at first sip", g_cat = "Purr-fect",
  g_nerd = "Very studious", g_monocle = "Quite posh", g_3d = "Coffee in 3D",
  saltlamp = "A warm, glowing rock", lavalamp = "Groovy, baby", floorlamp = "Soft, cozy light", neoncup = "Always open",
  hmus = "Spooky fall vibes", xmus = "Cozy winter vibes",
  itemstand = "A table spot on the floor", tiffanytab = "Stained glass for tables",
}
-- grid spots. The wall has three free spots (the name sign uses the last two).
CAFE.WSLOT = { { 3, 21, 24, 28 }, { 272, 21, 43, 28 }, { 319, 21, 43, 28 }, { 224, 21, 24, 28 }, { 200, 21, 24, 28 }, { 248, 21, 24, 28 } }   -- (the 4th is where the fridge used to be)   -- x, y, w, h
CAFE.XSLOT = { { 140, 61 }, { 180, 61 }, { 220, 61 }, { 260, 61 }, { 300, 61 }, { 340, 61 }, { 380, 61 } }   -- the lower row of the wall
CAFE.XSLOT2 = { { 20, 61 }, { 60, 61 }, { 100, 61 } }        -- (more of the lower row: under the clock and the window; kept after the first lot so old saves keep their spots)
CAFE.MUGSLOT = 17                                         -- the coffee picture's spot, up in the corner: wall decor can go there once the picture is taken down
-- All wall decor (clocks, pictures, signs) share one set of tiles: the six up by the ceiling, then the seven below them.
CAFE.TILES = {}
for i, sl in ipairs(CAFE.WSLOT) do CAFE.TILES[i] = { sl[1], sl[2], sl[3], sl[4] } end
for j, sl in ipairs(CAFE.XSLOT) do CAFE.TILES[#CAFE.WSLOT + j] = { sl[1] - 19, 51, 38, 20 } end
for _, sl in ipairs(CAFE.XSLOT2) do CAFE.TILES[#CAFE.TILES + 1] = { sl[1] - 19, 51, 38, 20 } end
CAFE.TILES[CAFE.MUGSLOT] = { 364, 21, 34, 28 }
function CAFE.gk(kind) return (kind == "tiny") and "wall" or kind end         -- tiny pictures live on the same grid as wall decor
function CAFE.tileCenter(i) local t = CAFE.TILES[i]; return t[1] + math.floor(t[3] / (2)), t[2] + math.floor(t[4] / (2)) end
CAFE.CSLOT = { { 91, 81 }, { 165, 81 }, { 232, 81 }, { 297, 81 }, { 361, 81 }, { 20, 81 } }   -- blank spots on the counter: each one is exactly halfway across the gap between the two machines beside it (6: the end of the counter, left of the register)
-- how far (in pixels, either side of the middle of a spot) something can reach before it would come within 2 pixels of a machine
CAFE.SCAP = { { -17, 17 }, { -17, 18 }, { -17, 18 }, { -13, 14 }, { -14, 14 }, { -18, 17 } }
-- how far each wide counter thing really reaches (measured over 150 frames of its animation, drawn alone); anything not listed is 21 wide or less
CAFE.AEXT = { saltlamp = { -17, 17 }, tiffanytab = { -13, 12 }, radio = { -11, 11 }, boombox = { -12, 13 }, luckycat = { -9, 13 },
              record = { -12, 11 }, cradle = { -15, 14 }, miniplaydate = { -14, 13 }, incense = { -11, 11 }, aquarium = { -11, 10 },
              snaketank = { -13, 13 }, axotank = { -15, 14 }, axowild = { -15, 14 }, axogold = { -15, 14 },
              hamster = { -17, 16 }, hamwhite = { -17, 16 }, hamgray = { -17, 16 } }
CAFE.ADX = { aquarium = 1, luckycat = -2 }          -- a nudge so the whole thing sits in the middle of its spot
function CAFE.fitsSlot(id, i) return true end       -- every counter piece fits every counter spot (a wide one slides over, or is drawn a little narrower: see slotFit)
function CAFE.slotFit(id, i)                        -- how a piece sits in counter spot i: its nudge, and (if it's wider than the gap) how far it may reach each side
  local dx = CAFE.ADX[id] or 0
  local cap, e = CAFE.SCAP[i], id and CAFE.AEXT[id]
  if not cap or not e then return dx, nil end
  if e[1] + dx >= cap[1] and e[2] + dx <= cap[2] then return dx, nil end
  if e[2] - e[1] <= cap[2] - cap[1] then              -- it fits the gap: slide it to the middle of it
    return math.floor((cap[1] + cap[2] - e[1] - e[2]) / 2), nil
  end
  local mid = math.floor((cap[1] + cap[2]) / 2)        -- too wide: in the middle, drawn narrower (tanks, cages and the like know how)
  return mid, { cap[1] - mid, cap[2] - mid }
end
function CAFE.counterAt(id, i, x, y)               -- draw a piece standing at counter spot i (x = the spot's middle)
  local dx, nar = CAFE.slotFit(id, i)
  CAFE.narrow = nar
  CAFE.art[id](x + dx, y)
  CAFE.narrow = nil
end
-- floor spots hug the walls: down the left, in the right-hand corner, and along the counter
CAFE.FSLOT = { { 20, 134 }, { 20, 170 }, { 20, 204 }, { 382, 128 }, { 100, 130 }, { 200, 130 }, { 300, 130 }, { 298, 206 } }   -- (the last one is by the left end of the corner bench)
-- where the tables can go (the first four match the original row along the bottom)
-- the six table spots: 1-3 along the bottom, 5-7 evenly spaced above them (spot 4's old square is a floor decor spot now)
CAFE.TSLOT = { { 132, 208 }, { 186, 208 }, { 240, 208 }, { 294, 208 }, { 132, 170 }, { 186, 170 }, { 240, 170 } }
CAFE.TFREE = { 1, 2, 3, 5, 6, 7 }
function CAFE.tableSpots(k) return CAFE.TFREE end
function CAFE.applyLayout(d)
  if not CAFE.defT then
    CAFE.defT, CAFE.defS = {}, {}
    for i, t in ipairs(TABLES) do CAFE.defT[i] = { t.x, t.y } end
    for i, q in ipairs(SEATS) do CAFE.defS[i] = { q.x, q.y } end
  end
  for i, t in ipairs(CAFE.defT) do TABLES[i].x, TABLES[i].y = t[1], t[2] end
  for i, q in ipairs(CAFE.defS) do SEATS[i].x, SEATS[i].y = q[1], q[2] end
  if d then
    for k = 1, 4 do
      local sl = d.tables[k] and CAFE.TSLOT[d.tables[k]]
      if sl then
        TABLES[k].x, TABLES[k].y = sl[1], sl[2]
        SEATS[2 * k - 1].x, SEATS[2 * k - 1].y = sl[1] - 17, sl[2]
        SEATS[2 * k].x, SEATS[2 * k].y = sl[1] + 17, sl[2]
      end
    end
  end
end
CAFE.slots = {}
CAFE.sel, CAFE.mode, CAFE.erase = 1, "slots", nil
CAFE.name, CAFE.letter, CAFE.crank, CAFE.onDone = "", 0, 0, false
CAFE.shopSel, CAFE.scroll, CAFE.report, CAFE.msg, CAFE.msgT = 1, 0, nil, nil, 0
CAFE.tab, CAFE.focus, CAFE.crankAcc, CAFE.tabPos = 1, "tabs", 0, 1       -- shop: which tab, list or bottom buttons, crank scrolling
CAFE.cur, CAFE.slot = nil, 1
CAFE.pend, CAFE.spots, CAFE.spotSel = nil, {}, 1

function CAFE.seatsOf(step) if step <= 0 then return 0 end return CAFE.SEAT_N[step] end
function CAFE.seatOffOf(d)                     -- seats that belong to tables you've switched off
  local off = {}
  for k = 1, 4 do
    if d.off and d.off[k] then off[2 * k - 1] = true; off[2 * k] = true end
  end
  return off
end
function CAFE.seatCountOf(d)
  local n, off = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d)
  for i in pairs(off) do if i <= CAFE.seatsOf(d.seatStep) then n = n - 1 end end
  return n
end

function CAFE.fresh(name)
  local rich = (string.upper(name or "") == "RICH")      -- test cheat: $99999 to start, and nobody gets impatient
  return { v = 2, tv = 2, name = name, money = rich and 9999900 or 0, cups = 0, seatStep = 0, stars = 0, decor = {}, place = {}, tables = {}, off = {}, shifts = 0 }
end

-- ---- grid bookkeeping ----------------------------------------------------------------
function CAFE.slotTaken(d, kind, slot)
  kind = CAFE.gk(kind)
  if kind == "wall" and d.sign ~= false and (slot == 2 or slot == 3) then return true end
  if kind == "wall" and d.mugSign ~= false and slot == CAFE.MUGSLOT then return true end
  for _, it in ipairs(CAFE.ITEMS) do
    if kind == "floor" and it.bird and d.decor[it.id] == "on" and d.place[it.id] == 40 + slot then return true end     -- (a bird's perch standing on the floor)
    if CAFE.gk(it.kind) == kind and d.decor[it.id] == "on" and d.place[it.id] == slot then return true end
  end
  return false
end

function CAFE.isGrid(it) return it.kind == "wall" or it.kind == "floor" or it.kind == "counter" or it.kind == "tiny" end

function CAFE.tableOn(d, k)                    -- is table k standing in the cafe (so something can sit in the middle of it)?
  if k == 5 then return (d.seatStep or 0) >= 5 end
  return k >= 1 and k <= 4 and k <= (d.seatStep or 0) and not (d.off and d.off[k]) and (d.tables[k] or 0) > 0
end

function CAFE.standSpots(d)                    -- the floor spots that have an Item stand standing on them (you can own several)
  local out = {}
  for k = 1, CAFE.copyCount(d, "itemstand") do
    local cid = CAFE.copyId("itemstand", k)
    if d.decor[cid] == "on" and d.place[cid] then out[#out + 1] = d.place[cid] end
  end
  return out
end
function CAFE.topOn(d, pl)                     -- is there something to stand on at this counter-style spot? (1-5 counter, 11-15 a table, 21-28 an Item stand, 41-48 the floor: birds' perches)
  if pl <= 10 or pl > 40 then return true end
  if pl <= 15 then return CAFE.tableOn(d, pl - 10) end
  if pl <= 20 then return false end
  for _, f in ipairs(CAFE.standSpots(d)) do if f == pl - 20 then return true end end
  return false
end
function CAFE.topXY(pl)                        -- where the things on a table / stand are drawn
  if pl > 40 then local sl = CAFE.FSLOT[pl - 40]; return sl[1], sl[2] + 4 end       -- (a perch standing on the floor)
  if pl > 20 then local sl = CAFE.FSLOT[pl - 20]; return sl[1], sl[2] - 10 end
  local t = TABLES[pl - 10]; return t.x, t.y - 7
end

-- (what is standing where, looked up instead of searched: reading a save used to scan every item for every spot of every item,
--  about a million steps for a well-furnished cafe, which is what made the Playdate's title screen hitch)
function CAFE.occBuild(d)
  local occ = { wall = {}, floor = {}, counter = {}, bird = {} }
  for _, it in ipairs(CAFE.ITEMS) do
    local pl = d.place[it.id]
    if pl ~= nil and d.decor[it.id] == "on" then
      local o = occ[CAFE.gk(it.kind)]
      if o then o[pl] = true end
      if it.bird then occ.bird[pl] = true end
    end
  end
  return occ
end
function CAFE.occAdd(occ, it, pl)
  local o = occ[CAFE.gk(it.kind)]
  if o then o[pl] = true end
  if it.bird then occ.bird[pl] = true end
end
function CAFE.slotTakenOcc(d, occ, kind, slot)     -- (the same answer as slotTaken)
  kind = CAFE.gk(kind)
  if kind == "wall" and d.sign ~= false and (slot == 2 or slot == 3) then return true end
  if kind == "wall" and d.mugSign ~= false and slot == CAFE.MUGSLOT then return true end
  if kind == "floor" and occ.bird[40 + slot] then return true end
  local o = occ[kind]
  return o ~= nil and o[slot] == true
end
function CAFE.freeSlots(d, kind, id, occ)
  kind = CAFE.gk(kind)
  local taken = occ and function(k, sl) return CAFE.slotTakenOcc(d, occ, k, sl) end or function(k, sl) return CAFE.slotTaken(d, k, sl) end
  local n = (kind == "wall") and #CAFE.TILES or ((kind == "counter") and #CAFE.CSLOT or #CAFE.FSLOT)
  local list = {}
  for i = 1, n do
    if not taken(kind, i) and (kind ~= "counter" or CAFE.fitsSlot(id, i)) then list[#list + 1] = i end
  end
  if kind == "counter" then                         -- the middle of each table is a counter-style spot too (11 = table 1 ... 15 = the nook table)
    for k = 1, 5 do
      if CAFE.tableOn(d, k) and not taken(kind, 10 + k) then list[#list + 1] = 10 + k end
    end
    for _, sf in ipairs(CAFE.standSpots(d)) do          -- an Item stand turns its floor spot into a table spot too
      if not taken(kind, 20 + sf) then list[#list + 1] = 20 + sf end
    end
    if id and CAFE.byId[id] and CAFE.byId[id].bird then  -- a bird's perch can also stand right on the floor
      for i = 1, #CAFE.FSLOT do
        if not taken("floor", i) and not taken(kind, 40 + i) then list[#list + 1] = 40 + i end
      end
    end
  end
  if kind == "wall" then
    table.sort(list, function(a, b)
      local ta, tb = CAFE.TILES[a], CAFE.TILES[b]
      if ta[2] ~= tb[2] then return ta[2] < tb[2] end
      return ta[1] < tb[1]
    end)
  end
  return list
end

function CAFE.fixPlacement(d)               -- old saves / odd data: give everything a legal spot
  local old = {}
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.isGrid(it) and d.decor[it.id] == "on" then
      old[it.id] = d.place[it.id]
      d.place[it.id] = nil
    end
  end
  local order = {}                                   -- (the Item stands first, so what stands on them can find their spots)
  for _, it in ipairs(CAFE.ITEMS) do if it.id == "itemstand" or it.copyOf == "itemstand" then order[#order + 1] = it end end
  for _, it in ipairs(CAFE.ITEMS) do if not (it.id == "itemstand" or it.copyOf == "itemstand") then order[#order + 1] = it end end
  local occ = CAFE.occBuild(d)                       -- (everything that is still standing where it was; filled in as each piece finds its spot)
  for _, it in ipairs(order) do
    if old[it.id] ~= nil or (CAFE.isGrid(it) and d.decor[it.id] == "on") then
      local want = old[it.id]
      local free = CAFE.freeSlots(d, it.kind, it.id, occ)
      local ok = false
      for _, f in ipairs(free) do if f == want then ok = true end end
      if ok then d.place[it.id] = want; CAFE.occAdd(occ, it, want)
      elseif #free > 0 then d.place[it.id] = free[1]; CAFE.occAdd(occ, it, free[1])
      else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.fixTops(d)                      -- a table went away or was switched off: what stood on it moves to the counter
  for _, it in ipairs(CAFE.ITEMS) do
    local pl = d.place[it.id]
    if it.kind == "counter" and d.decor[it.id] == "on" and pl and pl > 10 and not CAFE.topOn(d, pl) then
      d.place[it.id] = nil
      local free = CAFE.freeSlots(d, "counter", it.id)
      if #free > 0 then d.place[it.id] = free[1] else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.fixTables(d)                    -- old saves: every table gets one of the six spots, none doubled up
  local taken = {}
  for k = 1, math.min(d.seatStep, 4) do
    if d.off[k] then d.tables[k] = 0
    else
      local t = d.tables[k]
      local ok = false
      for _, f in ipairs(CAFE.TFREE) do if f == t then ok = true end end
      if not ok or taken[t] then
        t = nil
        for _, f in ipairs(CAFE.TFREE) do if not taken[f] then t = f; break end end
      end
      d.tables[k] = t
      taken[t] = true
    end
  end
end

function CAFE.read(i)
  local ok, d = pcall(pd.datastore.read, "cafe" .. i)
  if not ok or type(d) ~= "table" or type(d.name) ~= "string" then return nil end
  d.money = tonumber(d.money) or 0
  d.cups = clamp(math.floor(tonumber(d.cups) or 2), 0, 10)
  d.seatStep = clamp(math.floor(tonumber(d.seatStep) or 0), 0, 5)
  d.stars = clamp(tonumber(d.stars) or 0, 0, 5)
  d.lvl = clamp(math.floor(tonumber(d.lvl) or 1), 1, 999)
  d.pstreak = math.max(0, math.floor(tonumber(d.pstreak) or 0))
  d.boostT = (tonumber(d.boostT) or 0) > 0 and tonumber(d.boostT) or nil
  d.boostS = (tonumber(d.boostS) or 0) > 0 and tonumber(d.boostS) or nil
  d.char = clamp(math.floor(tonumber(d.char) or 1), 1, 3)
  d.shifts = tonumber(d.shifts) or 0
  if type(d.decor) ~= "table" then d.decor = {} end
  if type(d.place) ~= "table" then d.place = {} end
  if type(d.tables) ~= "table" then d.tables = {} end
  if type(d.off) ~= "table" then d.off = {} end
  if type(d.hball) ~= "table" then d.hball = nil end
  CAFE.fixTables(d)
  CAFE.ensureCopies(d)                           -- (copies you bought of floor and table-top decor)
  CAFE.fixVines(d)
  if d.decor.hmus == "on" and d.decor.xmus == "on" then d.decor.xmus = "off" end      -- (one season's music at a time)
  if d.tv ~= 2 then                              -- older saves: the little pictures were numbered on their own row
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "tiny" and d.place[it.id] then d.place[it.id] = d.place[it.id] + #CAFE.WSLOT end
    end
    d.tv = 2
  end
  CAFE.fixPlacement(d)
  return d
end

CAFE.NAME_MAX = 13                              -- the longest cafe name: the most letters that sit properly inside the wall sign and the shop preview
function CAFE.cafeName()                       -- the name of the cafe you're in, found wherever it's kept (never blank)
  local function ok(n) return type(n) == "string" and n:gsub("%s", "") ~= "" end
  local c = CAFE.cur
  if c and ok(c.name) then return c.name end
  local sl = CAFE.slot and CAFE.slots and CAFE.slots[CAFE.slot]
  if sl and ok(sl.name) then return sl.name end
  if G and G.cafe and ok(G.cafe.name) then return G.cafe.name end
  if CAFE.slot then                              -- straight from the save file
    local okr, d = pcall(pd.datastore.read, "cafe" .. CAFE.slot)
    if okr and type(d) == "table" and ok(d.name) then return d.name end
  end
  if ok(CAFE.name) then return CAFE.name end
  return "COFFEE"
end

function CAFE.rich()                                         -- (the test cafe; the name is checked once, not every frame)
  if G == nil or G.mode ~= "cafe" or G.cafe == nil then return false end
  local nm = G.cafe.name or ""
  if nm ~= CAFE.richName then CAFE.richName, CAFE.richIs = nm, (string.upper(nm) == "RICH") end
  return CAFE.richIs
end

function CAFE.preRead()                          -- (idle on the title screen) read your saves one a frame; true once all three are in
  local pre = CAFE.pre
  if pre == nil then pre = { n = 0 }; CAFE.pre = pre end
  if pre.n < 3 then
    pre.n = pre.n + 1
    pre[pre.n] = CAFE.read(pre.n) or false
  end
  return pre.n >= 3
end

function CAFE.write()
  CAFE.rc = nil
  CAFE.rsF = nil
  CAFE.pre = nil
  if CAFE.cur then pcall(pd.datastore.write, CAFE.cur, "cafe" .. CAFE.slot) end
  if CAFE.cur then UI.achCheck() end
  UI.metaSave()
end

function CAFE.addStars(d)
  if G and G.cafe then G.cafe.stars = clamp(math.floor((G.cafe.stars + d) * 100 + 0.5) / 100, 0, 5) end
end

-- a slip-up costs a little of a star; the more you've decorated, the less customers mind
function CAFE.mistake(amt)
  if not (G and G.mode == "cafe" and G.cafe) then return end
  local n = G.cafe.seatStep or 0
  for _, v in pairs(G.cafe.decor) do if v == "on" then n = n + 1 end end
  local mult = clamp(1 - 0.025 * n, 0.25, 1)
  CAFE.addStars(-amt * mult)
end

function CAFE.petOn(d, species)                 -- which cat / dog (if any) is out in the cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.species == species and d.decor[it.id] == "on" then return it.id end
  end
  return nil
end

function CAFE.hasNeed(d, need)                  -- cat tree wants a cat of any coat, dog bed any dog
  if need == "cat" or need == "dog" then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.species == need and d.decor[it.id] ~= nil then return true end
    end
    return false
  end
  return d.decor[need] ~= nil
end

function CAFE.petCount()
  local d = G and G.cafe
  if not d then return 0 end
  return (CAFE.petOn(d, "cat") and 1 or 0) + (CAFE.petOn(d, "dog") and 1 or 0) + (CAFE.petOn(d, "turtle") and 1 or 0) + (CAFE.petOn(d, "bunny") and 1 or 0)
end

-- ---- customer flow: it ebbs and flows, but never goes dead ---------------------------------------
function CAFE.flowUpdate(dt)
  local f = G.flow
  f.timer = f.timer - dt
  if f.timer <= 0 then
    f.target = math.random()
    f.timer = 25 + math.random() * 40
  end
  f.m = f.m + (f.target - f.m) * math.min(1, dt * 0.15)
  -- Busy and quiet spells (every Cafe, whatever its stars): a rush of a handful of customers (more for a well-liked cafe), then nobody
  -- new comes in until the line has been served, and then a breather of 18 to 28 seconds with nobody at the register at all: time for
  -- the dishes, the phone, the achievements. Then it gets busy again.
  if G.mode == "cafe" then
    local dirty = G.cups and G.cups.dirty or 0
    local stars = G.cafe.stars or 0
    local function busy()
      G.phase, G.phaseT, G.phaseLen = "busy", 0, 26 + math.random() * 18 + ((stars < 2) and 20 or 0)    -- (a new cafe is slow anyway: its spells run longer)
      G.busyN, G.busyCap = 0, 4 + math.floor(stars / 2) + math.random(0, 2)       -- (4 to 8 customers, then it calms down)
    end
    if not G.phase then busy() end
    G.phaseT = G.phaseT + dt
    if G.phase == "busy" then
      if G.phaseT >= G.phaseLen or (G.busyN or 0) >= (G.busyCap or 6) or (#G.line >= LINE_MAX and G.phaseT >= 15) or (dirty >= 4 and G.phaseT >= 15) then
        G.phase, G.phaseT = "drain", 0                                             -- (a full line, or four dirty cups piling up, cuts it short)
      end
    else
      if G.arriveIn < 1 then G.arriveIn = 1 end
      if G.phase == "drain" then
        if (#G.line == 0 and G.cust == nil) or G.phaseT > 120 then
          G.phase, G.phaseT = "quiet", 0
          G.phaseLen = (stars < 2) and (8 + math.random() * 4) or ((dirty >= 3) and (24 + math.random() * 4) or (18 + math.random() * 8))
        end
      elseif G.phaseT >= G.phaseLen then
        busy()
        G.arriveIn = 1 + math.random() * 2                       -- the first of the next busy spell is already at the door
      end
    end
  end
  -- nobody here at all? don't leave the shop empty for long
  if #G.line == 0 and G.cust == nil and G.arriveIn > 16 and (G.phase == nil or G.phase == "busy") then G.arriveIn = 16 end
end

-- how likely a new customer is to join, given how many people the line would hold with them in it:
-- a new cafe keeps short lines, and only a well-liked one gets a long queue
function CAFE.admit(n)
  local st = G.cafe.stars or 0
  local t
  if st < 2 then t = { 1, 0.5, 0.1, 0 }
  elseif st < 3 then t = { 1, 0.9, 0.3, 0 }
  elseif st < 4 then t = { 1, 1, 0.7, 0.2 }
  else t = { 1, 1, 1, 0.6 } end
  return math.random() < (t[n] or 0)
end

function CAFE.gap(lo, span)
  local f = G.flow
  local factor = 1.55 - 1.0 * f.m                      -- quiet spell 1.55x, rush 0.55x
  if math.random() < 0.14 then return 2.5 + math.random() * 3 end   -- a friend tags along
  return (lo + math.random() * span) * factor
end

-- ---- stars ---------------------------------------------------------------------------------------
CAFE.starImgs = {}
function CAFE.starImg(r, kind)                       -- a ready-made pixel star (made once per size): "f" full, "h" half, "e" empty
  local key = r * 10 + (kind == "f" and 1 or kind == "h" and 2 or 3)
  local im = CAFE.starImgs[key]
  if im ~= nil then return im end
  local S, c = 2 * r + 3, r + 1
  local vx, vy = {}, {}
  for i = 0, 9 do
    local a = -math.pi / 2 + i * math.pi / 5
    local rr = (i % 2 == 0) and (r + 1.0) or (r + 1.0) * 0.45
    vx[i + 1] = c + 0.5 + math.cos(a) * rr
    vy[i + 1] = c + 0.8 + math.sin(a) * rr
  end
  local function inside(x, y)                        -- even-odd test against the ten corners
    local ins = false
    local j = 10
    for i = 1, 10 do
      if (vy[i] > y) ~= (vy[j] > y) and x < (vx[j] - vx[i]) * (y - vy[i]) / (vy[j] - vy[i]) + vx[i] then ins = not ins end
      j = i
    end
    return ins
  end
  local mask = {}
  for py = 0, S - 1 do
    for px = 0, S - 1 do mask[py * S + px] = inside(px + 0.5, py + 0.5) end
  end
  im = gfx.image.new(S, S, gfx.kColorClear)
  gfx.pushContext(im)
  gfx.setColor(BLACK)
  for py = 0, S - 1 do
    for px = 0, S - 1 do
      if mask[py * S + px] then
        local edge = px == 0 or py == 0 or px == S - 1 or py == S - 1
          or not (mask[py * S + px - 1] and mask[py * S + px + 1] and mask[(py - 1) * S + px] and mask[(py + 1) * S + px])
        local left = px + 0.5 < c + 0.5
        if kind == "f" or edge or (kind == "h" and left) then gfx.drawPixel(px, py) end
      end
    end
  end
  gfx.popContext()
  CAFE.starImgs[key] = im
  return im
end

function CAFE.star(cx, cy, r, fill, color)
  local kind = (fill >= 0.999) and "f" or (fill >= 0.5) and "h" or "e"     -- (a star is only full once its meter is)
  local im = CAFE.starImg(r, kind)
  gfx.setImageDrawMode(color == WHITE and gfx.kDrawModeFillWhite or gfx.kDrawModeFillBlack)
  im:draw(cx - r - 1, cy - r - 1)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

function CAFE.drawStars(x0, cy, r, gap, value, color, lvl)
  for i = 1, 5 do
    if lvl and UI.starHook then UI.starHook(lvl, i) end      -- (PC: every barista level has its own colour of star, with a shine running over them)
    CAFE.star(x0 + (i - 1) * gap, cy, r, clamp(value - (i - 1), 0, 1), color)
  end
  UI.starTint = nil
  gfx.setColor(BLACK)
end

-- text squeezed to fit a box (scaled down if it's too wide)
CAFE.fitCache = {}
function CAFE.fitText(str, cx, cy, maxW, maxH, thinMax)
  gfx.setFont(fontBold)
  local w, h = gfx.getTextSize(str)
  if w <= maxW then
    drawTC(str, cx, cy - math.floor(h / (2)), true)
    return
  end
  local up = string.upper(str)
  if thinMax and UI.thinWidth(up) <= thinMax then            -- too wide for the bold font: small clear capitals instead
    gfx.setColor(BLACK)
    UI.thinText(up, cx - math.floor(UI.thinWidth(up) / (2)), cy - 3)
    return
  end
  local img = CAFE.fitCache[str]
  if img == nil then
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      drawT(str, 0, 0, true)
      gfx.popContext()
    end)
    if not ok then img = false end
    CAFE.fitCache[str] = img
  end
  if img then
    local k = maxW / w
    img:drawScaled(cx - math.floor(w * k / 2), cy - math.floor(h * k / 2), k)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    return
  end
  drawTC(string.sub(str, 1, 7) .. "..", cx, cy - math.floor(h / (2)), true)
end

-- ---- decoration art: every piece is drawn around a centre point ----------------------------------
CAFE.art = {}
local function A() return CAFE.art end

function CAFE.art.clock(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 11)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 11)
  gfx.setLineWidth(1)
  for h = 0, 11 do
    local a = h * math.pi / 6
    gfx.drawLine(math.floor(cx + math.sin(a) * 8), math.floor(cy - math.cos(a) * 8),
                 math.floor(cx + math.sin(a) * 9.5), math.floor(cy - math.cos(a) * 9.5))
  end
  local t = (G and G.t) or 0
  local am = t * 0.105
  local ah = am / 12 + 1
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 8), math.floor(cy - math.cos(am) * 8))
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 5), math.floor(cy - math.cos(ah) * 5))
  gfx.setLineWidth(1)
end

-- ---- candles: a flickering flame and a little curl of smoke ---------------------------------------------
function CAFE.flame(x, y, seed, big)             -- x, y = the bottom of the flame; it leans and bobs
  local ph = (math.floor(frames / (4)) + (seed or 0)) % 4
  local lean = (ph == 1) and -1 or ((ph == 3) and 1 or 0)
  local h = big and 6 or 4
  if ph == 2 then h = h - 1 end
  UI.inkPush("flame")
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(x, y - 1, big and 2 or 1)
  gfx.fillTriangle(x - (big and 2 or 1), y - 1, x + (big and 2 or 1), y - 1, x + lean, y - 1 - h)
  gfx.setColor(WHITE)
  gfx.drawPixel(x, y - 1)
  if big then gfx.drawPixel(x, y - 2) end
  UI.inkPop()
  gfx.setColor(BLACK)
end

function CAFE.smoke(x, y, seed)                  -- y = just above the flame; three pixels drift up and fade away
  UI.ink("gray")
  gfx.setColor(BLACK)
  for j = 0, 2 do
    local tt = (math.floor(frames / (3)) + (seed or 0) * 5 + j * 4) % 12
    if tt >= 1 and tt <= 10 then
      gfx.drawPixel(x + math.floor(math.sin(tt * 0.8 + (seed or 0) + j) * (1 + tt / 5) + 0.5), y - 1 - tt)
    end
  end
end

function CAFE.art.candle1(cx, cy)                -- a fat pillar candle on a dish, wax pooling at the top, with drips
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 8, cy + 8, 17, 3, 1)                       -- the dish (an odd width, so it sits dead centre)
  gfx.fillRect(cx - 3, cy + 7, 7, 1)
  UI.ink("rose")
  gfx.setColor(WHITE); gfx.fillRect(cx - 4, cy - 1, 9, 9)
  gfx.setColor(BLACK); gfx.drawRect(cx - 4, cy - 1, 9, 9)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 4, cy - 3, 9, 5)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 4, cy - 3, 9, 5)  -- the melted top
  gfx.drawLine(cx - 2, cy + 1, cx - 2, cy + 4); gfx.drawLine(cx + 2, cy + 1, cx + 2, cy + 3)   -- drips
  gfx.drawPixel(cx - 2, cy + 5); UI.ink("none"); gfx.drawLine(cx, cy - 1, cx, cy - 2)
  CAFE.flame(cx, cy - 3, 0, true)
  CAFE.smoke(cx, cy - 10, 0)
end

function CAFE.art.candle2(cx, cy)                -- a tall taper in a brass-style holder
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 6, cy + 9, 13, 2, 1)                       -- saucer
  gfx.fillRect(cx - 1, cy + 4, 3, 6)                                 -- stem
  gfx.fillCircleAtPoint(cx, cy + 7, 2)                               -- a bead on the stem
  gfx.fillPolygon(cx - 4, cy + 3, cx + 4, cy + 3, cx + 2, cy + 6, cx - 2, cy + 6)      -- the cup
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillRect(cx - 1, cy - 9, 3, 12)
  gfx.setColor(BLACK); gfx.drawRect(cx - 1, cy - 9, 3, 12)
  UI.ink("none")
  gfx.drawLine(cx, cy - 9, cx, cy - 10)
  CAFE.flame(cx, cy - 10, 1, false)
  CAFE.smoke(cx, cy - 16, 1)
end

function CAFE.art.candle3(cx, cy)                -- three tealights in a little dish
  UI.ink("skyp")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 10, cy + 6, 21, 4, 2)                      -- (odd width: centred under the middle light)
  for i = -1, 1 do
    local x = cx + i * 7
    local y = cy + 2 + ((i == 0) and -2 or 0)
    UI.ink("gray")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y + 1, 5, 4, 1)
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 2, y + 1, 5, 4, 1)
    CAFE.flame(x, y + 1, i + 2, false)
  end
  CAFE.smoke(cx, cy - 6, 2)
end

function CAFE.art.candle4(cx, cy)                -- a candle in a glass jar with a label
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRoundRect(cx - 6, cy - 1, 13, 12, 2)
  gfx.setColor(BLACK); gfx.drawRoundRect(cx - 6, cy - 1, 13, 12, 2)
  UI.ink("lav")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 5, cy + 4, 11, 6); gfx.setColor(BLACK)
  UI.ink("cream")
  gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy + 5, 7, 3)
  gfx.setColor(BLACK); gfx.drawRect(cx - 3, cy + 5, 7, 3)
  UI.ink("none")
  gfx.drawLine(cx, cy + 1, cx, cy + 3)
  CAFE.flame(cx, cy + 2, 3, true)
  UI.ink("slate")
  gfx.fillRect(cx - 7, cy - 2, 15, 2)                      -- the jar's rim
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy + 2); gfx.drawPixel(cx - 5, cy + 3); gfx.setColor(BLACK)   -- a shine on the glass
  CAFE.smoke(cx, cy - 6, 3)
end

function CAFE.art.candle5(cx, cy)                -- a three-armed candelabra
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 6, cy + 9, 13, 2, 1)
  gfx.fillRect(cx - 1, cy + 1, 3, 9)
  gfx.fillCircleAtPoint(cx, cy + 6, 2)
  gfx.drawLine(cx, cy + 3, cx - 8, cy - 1); gfx.drawLine(cx, cy + 3, cx + 8, cy - 1)
  gfx.drawLine(cx - 8, cy - 1, cx - 8, cy + 1); gfx.drawLine(cx + 8, cy - 1, cx + 8, cy + 1)
  for i = -1, 1 do
    local x = cx + i * 8
    local top = (i == 0) and cy - 7 or cy - 5
    UI.ink("cream")
    gfx.setColor(WHITE); gfx.fillRect(x - 1, top, 3, 7)
    gfx.setColor(BLACK); gfx.drawRect(x - 1, top, 3, (i == 0) and 9 or 6)
    CAFE.flame(x, top - 1, i + 1, false)
  end
  CAFE.smoke(cx, cy - 14, 4)
end

function CAFE.art.candle6(cx, cy)                -- a little lantern with a candle inside
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(cx, cy - 6, 3)                    -- the carrying ring
  gfx.fillRect(cx - 5, cy - 3, 11, 2)
  gfx.fillRect(cx - 6, cy + 9, 13, 2)
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillRect(cx - 5, cy - 1, 11, 10)
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 1, 11, 10)
  gfx.drawLine(cx - 2, cy - 1, cx - 2, cy + 9); gfx.drawLine(cx + 2, cy - 1, cx + 2, cy + 9)
  UI.ink("redp")
  gfx.fillRect(cx - 1, cy + 5, 3, 4)                      -- the candle
  CAFE.flame(cx, cy + 4, 1, false)
  UI.ink("inkorange")
  local g = (math.floor(frames / (6))) % 2                              -- the glow flickers round the glass
  gfx.drawPixel(cx - 8 - g, cy + 3); gfx.drawPixel(cx + 8 + g, cy + 3); gfx.drawPixel(cx - 8, cy + 6 + g); gfx.drawPixel(cx + 8, cy + 6 + g)
  CAFE.smoke(cx, cy - 9, 5)
end

function CAFE.art.candle7(cx, cy)                -- candles floating in a bowl of water
  UI.ink("skyp")
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(cx - 10, cy + 3, 21, 8)           -- (an odd width: the bowl is centred on the same column as everything else)
  UI.ink("water")
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 8, cy + 4, 17, 4)
  gfx.setColor(BLACK)
  local rp = (math.floor(frames / (6))) % 3                              -- ripples
  gfx.drawEllipseInRect(cx - 4 - rp, cy + 5 - math.floor(rp / (2)), 9 + rp * 2, 2 + rp)
  for _, o in ipairs({ { -5, 0 }, { 5, 1 } }) do
    local x, y = cx + o[1], cy + 3 + o[2]
    UI.ink(o[1] < 0 and "rose" or "cream")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y - 1, 5, 4, 1)
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 2, y - 1, 5, 4, 1)
    CAFE.flame(x, y - 1, o[1] + 4, false)
  end
  CAFE.smoke(cx, cy - 4, 6)
end

function CAFE.art.incense(cx, cy)                -- a stick of incense burning in a wooden holder, smoke curling up
  local t = frames
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 11, cy + 8, 23, 3, 1)                          -- the long thin holder
  gfx.fillRect(cx - 9, cy + 11, 3, 1); gfx.fillRect(cx + 7, cy + 11, 3, 1)             -- its little feet
  gfx.fillRect(cx - 8, cy + 6, 3, 2)                                    -- the stick goes into this bump
  local tx, ty = cx + 3, cy - 8                                          -- the glowing tip
  UI.ink("berry")
  gfx.drawLine(cx - 7, cy + 7, tx - 2, ty + 5)                           -- the unburnt stick
  UI.ink("gray")
  for i = 0, 2 do gfx.drawPixel(tx - 2 + i, ty + 5 - math.floor(i * 5 / (2))) end     -- the burnt part: a dotted ash line
  UI.ink("flame")
  if (math.floor(t / (5))) % 2 == 0 then                                              -- the ember glows and dims
    gfx.fillCircleAtPoint(tx, ty + 1, 1); gfx.drawPixel(tx + 2, ty + 1); gfx.drawPixel(tx - 2, ty + 1); gfx.drawPixel(tx, ty - 1)
  else
    gfx.drawPixel(tx, ty + 1); gfx.drawPixel(tx - 1, ty + 1); gfx.drawPixel(tx, ty)
  end
  UI.ink("gray")
  local f = t % 90                                                       -- a flake of ash drops now and then
  if f < 16 then gfx.drawPixel(tx - 2, ty + 6 + f - math.floor(f / (6))) end
  for j = 1, 18 do                                                       -- the main curl of smoke, thick at the bottom and fading to dots
    if j < 11 or j % 2 == 0 then
      local x = tx + math.floor(math.sin(j * 0.4 - t * 0.14) * (0.8 + j * 0.16) + 0.5)
      gfx.drawPixel(x, ty - 2 - j)
      if j < 7 then gfx.drawPixel(x + 1, ty - 2 - j) end
    end
  end
  for j = 3, 11 do                                                        -- and a faint second wisp that drifts the other way
    if j % 2 == 1 then gfx.drawPixel(tx + 3 + math.floor(math.sin(j * 0.6 - t * 0.2 + 2) * (0.8 + j * 0.1) + 0.5), ty - 2 - j) end
  end
end

-- ---- animated signs: they sit on the wall tiles (about 22 x 16 each) ----------------------------------
function CAFE.neonPlate(cx, cy)                  -- the dark board the neon tubes are fixed to
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 11, cy - 9, 23, 18, 4)                 -- (an odd width: the signs sit exactly in the middle)
  gfx.setColor(WHITE)
end

function CAFE.mapPic(rows, x0, y0, pc, pd)     -- a little text picture with several colours: pc[ch] = { palette row, 0 ink / 1 paper }, pd[ch] = "k" / "w" / "g"
  for y = 1, #rows do
    local r = rows[y]
    for x = 1, #r do
      local ch = string.sub(r, x, x)
      if ch ~= "." then
        if UI.color then
          local m = pc[ch] or { "none", (ch == "w") and 1 or 0 }
          UI.ink(m[1]); gfx.setColor(m[2] == 1 and WHITE or BLACK)
        else
          local m = pd[ch] or ((ch == "w") and "w" or "k")
          if m == "g" then gfx.setColor(((x + y) % 2 == 0) and BLACK or WHITE) else gfx.setColor(m == "w" and WHITE or BLACK) end
        end
        gfx.fillRect(x0 + x - 1, y0 + y - 1, 1, 1)
      end
    end
  end
  UI.ink("none"); gfx.setColor(BLACK)
end

function CAFE.pix(rows, x0, y0, ch)              -- the ch ("X") pixels of a little text picture, in the current colour
  ch = ch or "X"
  if not (UI.color or UI.noCache or UI.noFast) then      -- (Playdate: stamped from a picture of it, made the first time)
    local col = UI.getColor()
    if col == BLACK or col == WHITE then
      local key = (col == BLACK) and ch or (ch .. "w")
      local im = UI.cacheGet("pix", rows, key)
      if im == nil then
        local w = 0
        for y = 1, #rows do if #rows[y] > w then w = #rows[y] end end
        im = UI.cacheImg("pix", rows, key, w, #rows, function() gfx.setColor(col); CAFE.pixRaw(rows, 0, 0, ch) end)
      end
      if im then UI.cacheDraw(im, x0, y0); return end
    end
  end
  CAFE.pixRaw(rows, x0, y0, ch)
end
function CAFE.pixRaw(rows, x0, y0, ch)
  for y = 1, #rows do
    local r = rows[y]
    for x = 1, #r do if string.sub(r, x, x) == ch then gfx.drawPixel(x0 + x - 1, y0 + y - 1) end end
  end
end

-- neon tubes, drawn as clean pixel pictures (a thin tube, and the same tube glowing brighter)
CAFE.NHEART = { "..XXX...XXX..", ".X...X.X...X.", "X.....X.....X", "X...........X", "X...........X", ".X.........X.",
                "..X.......X..", "...X.....X...", "....X...X....", ".....X.X.....", "......X......" }
CAFE.NHEART2 = { "..XXX...XXX..", ".XXXXX.XXXXX.", "XXX..XXX..XXX", "XX.........XX", "XX.........XX", ".XX.......XX.",
                 "..XX.....XX..", "...XX...XX...", "....XX.XX....", ".....XXX.....", "......X......" }
CAFE.NSTAR = { "......X......", ".....XoX.....", ".....XoX.....", "....XoooX....", "XXXXXoooXXXXX", "XoooooooooooX",
               ".XoooooooooX.", "..XoooooooX..", "...XoooooX...", "..XoooooooX..", "..XoooXoooX..", ".XooXX.XXooX.", ".XXX.....XXX." }

function CAFE.art.neonheart(cx, cy)
  CAFE.neonPlate(cx, cy)
  local beat = ({ 0, 1, 0, 0, 1, 0, 0, 0 })[(math.floor(frames / (4))) % 8 + 1]      -- a double heartbeat: the tube glows thick, then settles
  CAFE.pix(beat == 1 and CAFE.NHEART2 or CAFE.NHEART, cx - 6, cy - 6)
  if beat == 1 then gfx.drawPixel(cx - 9, cy - 7); gfx.drawPixel(cx + 9, cy - 7); gfx.drawPixel(cx - 9, cy + 5); gfx.drawPixel(cx + 9, cy + 5) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonbolt(cx, cy)
  CAFE.neonPlate(cx, cy)
  local f = (math.floor(frames / (3))) % 14
  if f ~= 4 and f ~= 5 and f ~= 9 then                                   -- it flickers off now and then
    gfx.fillPolygon(cx + 2, cy - 8, cx - 5, cy + 1, cx - 1, cy + 1, cx - 3, cy + 8, cx + 5, cy - 2, cx + 1, cy - 2)
  else
    gfx.drawLine(cx + 2, cy - 7, cx - 4, cy + 1)
  end
  if f == 0 or f == 6 then gfx.drawPixel(cx - 9, cy - 5); gfx.drawPixel(cx + 8, cy + 5) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonstar(cx, cy)
  CAFE.neonPlate(cx, cy)
  local f = frames % 60                                                                -- the tube stays lit; now and then the whole star flashes full
  if f < 4 or (f >= 8 and f < 11) then CAFE.pix(CAFE.NSTAR, cx - 6, cy - 7, "o") end
  CAFE.pix(CAFE.NSTAR, cx - 6, cy - 7)
  local t = (math.floor(frames / (7))) % 4                                             -- a twinkle hops round the corners
  local c = ({ { -9, -6 }, { 8, -6 }, { 8, 5 }, { -9, 5 } })[t + 1]
  gfx.drawPixel(cx + c[1], cy + c[2]); gfx.drawPixel(cx + c[1] + 1, cy + c[2]); gfx.drawPixel(cx + c[1], cy + c[2] + 1)
  gfx.setColor(BLACK)
end

function CAFE.art.neonmoon(cx, cy)
  CAFE.neonPlate(cx, cy)
  gfx.fillCircleAtPoint(cx - 2, cy, 7)
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx + 1, cy - 2, 6)
  gfx.setColor(WHITE)
  local t = (math.floor(frames / (9))) % 3
  if t ~= 1 then gfx.drawLine(cx + 5, cy - 5, cx + 5, cy - 1); gfx.drawLine(cx + 3, cy - 3, cx + 7, cy - 3) end
  if t ~= 0 then gfx.drawPixel(cx + 6, cy + 4); gfx.drawPixel(cx + 7, cy + 4) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonarrow(cx, cy)
  CAFE.neonPlate(cx, cy)
  local on = (math.floor(frames / (6))) % 4                                           -- three chevrons light up one after another
  for i = 0, 2 do
    if on == i or on == 3 then
      local y = cy - 8 + i * 5                                                      -- (all three sit inside the board: the last tip is a pixel above its bottom edge)
      gfx.drawLine(cx - 5, y, cx, y + 4); gfx.drawLine(cx, y + 4, cx + 5, y)
      gfx.drawLine(cx - 5, y + 1, cx, y + 5); gfx.drawLine(cx, y + 5, cx + 5, y + 1)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.art.discoball(cx, cy)
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy - 14, cx, cy - 6)
  gfx.fillRect(cx - 2, cy - 7, 5, 2)                                         -- the hook
  UI.ink("snow")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy + 1, 8)
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(cx, cy + 1, 8)
  gfx.setClipRect(cx - 8, cy - 7, 17, 17)
  for k = -1, 1 do gfx.drawLine(cx - 8, cy + 1 + k * 4, cx + 8, cy + 1 + k * 4) end      -- the mirror tiles
  local sh = (math.floor(frames / (4))) % 4
  for k = -2, 2 do
    local x = cx + ((k * 4 + sh * 2) % 16) - 8
    gfx.drawLine(x, cy - 7, x, cy + 9)
  end
  gfx.clearClipRect()
  local sh2 = (math.floor(frames / (5))) % 3                                              -- a few tiles flash dark as it turns
  for j = -1, 1 do
    for i = -1, 1 do
      if (i * 2 + j + sh2) % 4 == 0 then UI.ink(({ "lav", "skyp", "rose" })[(i + j + 3) % 3 + 1]); gfx.fillRect(cx + i * 4 - 1, cy + 1 + j * 4 - 1, 3, 3) end
    end
  end
  local a = frames * 0.12                                                    -- sparkles circle it
  for k = 0, 2 do
    local ang = a + k * 2.1
    local sx, sy = cx + math.floor(math.cos(ang) * 12), cy + 1 + math.floor(math.sin(ang) * 10)
    UI.ink(({ "inkpink", "inkblue", "inkyellow" })[k + 1])
    gfx.drawLine(sx - 1, sy, sx + 1, sy); gfx.drawLine(sx, sy - 1, sx, sy + 1)
  end
end

function CAFE.smooth(a, b, x)                    -- eases 0 -> 1 as x goes from a to b
  local k = (x - a) / (b - a)
  if k < 0 then k = 0 elseif k > 1 then k = 1 end
  return k * k * (3 - 2 * k)
end

function CAFE.art.aquarium(cx, cy)               -- two fish at different depths, bubbles rising, a swaying weed, and now and then a pinch of food
  local fl, sin = math.floor, math.sin
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(cx - 11, cy - 8, 22, 16)
  gfx.setColor(BLACK)
  UI.ink("water")
  gfx.setPattern(TEA); gfx.fillRect(cx - 10, cy - 4, 20, 11); gfx.setColor(BLACK)                    -- the water (light, so the fish stand out)
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 10, cy - 4, 20, 11); gfx.setColor(BLACK) end     -- (in colour: clear water, the fish show through)
  UI.ink("tan")
  if UI.color then gfx.setPattern(CHECK); gfx.fillRect(cx - 10, cy + 5, 20, 2); gfx.setColor(BLACK) end     -- gravel
  UI.ink("slate")
  gfx.setLineWidth(2); gfx.drawRect(cx - 11, cy - 8, 22, 16); gfx.setLineWidth(1)
  UI.ink("leaf")
  for j = 1, 3 do                                                                                       -- a strand of weed, swaying
    local x1 = cx + 7 + fl(sin(frames * 0.1 + j * 0.8) * j * 0.5 + 0.5)
    local x0 = cx + 7 + fl(sin(frames * 0.1 + (j - 1) * 0.8) * (j - 1) * 0.5 + 0.5)
    gfx.drawLine(x0, cy + 5 - (j - 1) * 2, x1, cy + 5 - j * 2)
  end
  local cyc = frames % 300                                                                              -- feeding time: flakes sink, the big fish comes up for them
  local feed = CAFE.smooth(205, 220, cyc) - CAFE.smooth(262, 280, cyc)
  local t2 = frames * 0.11 + 2                                                                          -- the little fish: fast, low down, black
  local c2 = cx - 1 + sin(t2) * 4
  local d2 = (math.cos(t2) >= 0) and 1 or -1
  local y2 = fl(cy + 3.5 + sin(t2 * 0.7) * 0.6)
  local b2 = fl(c2 + d2 * 1)
  UI.ink("inkorange")
  gfx.fillEllipseInRect(b2 - 2, y2 - 1, 5, 3)
  gfx.fillTriangle(b2 - d2 * 2, y2, b2 - d2 * 4, y2 - 1 + (math.floor(frames / (2))) % 2, b2 - d2 * 4, y2 + 1)
  local t1 = frames * 0.045                                                                             -- the big fish: slow, easing round at each end
  local c1 = cx - 0.5 + sin(t1) * 3.5 * (1 - feed * 0.5) - feed
  local d1 = (math.cos(t1) >= 0) and 1 or -1
  local y1 = fl(cy - 0.5 + sin(t1 * 1.7 + 1) * 1.2 - feed * 1)
  local bc = fl(c1 + d1 * 1.5)
  local wag = (math.floor(frames / ((feed > 0.4 and 2 or 4)))) % 2                                                   -- (a busier tail while it's feeding)
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(bc - 3, y1 - 2, 7, 5)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(bc - 3, y1 - 2, 7, 5)
  gfx.fillTriangle(bc - d1 * 3, y1, bc - d1 * 6, y1 - 2 + wag, bc - d1 * 6, y1 + 3 - wag)               -- the tail
  gfx.drawPixel(bc + d1 * 2, y1 - 1)                                                                    -- the eye
  gfx.drawPixel(bc - d1, y1 - 3)                                                                        -- the dorsal fin
  if feed > 0.5 and (math.floor(frames / (3))) % 2 == 0 then gfx.drawPixel(bc + d1 * 4, y1) end                      -- a nibble
  UI.ink("bark")
  if cyc > 200 and cyc < 280 then
    for k = 0, 2 do
      local age = cyc - 205 - k * 11
      if age >= 0 then
        local fy = cy - 4 + fl(age * 0.12)
        if fy <= cy + 4 then gfx.drawPixel(cx - 5 + k * 4 + fl(sin(age * 0.3 + k) + 0.5), fy) end
      end
    end
  end
  UI.ink("inkblue")
  for k = 0, 1 do                                                                                       -- bubbles rising from the gravel
    local p = ((frames + k * 20) % 40) / 40
    local by = cy + 4 - fl(p * 9)
    if by > cy - 4 then gfx.drawPixel(cx - 8 + fl(sin(p * 9 + k) * 1.2 + 0.5), by) end
  end
end

function CAFE.art.pinwheel(cx, cy)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy + 2, cx, cy + 13)
  local a = frames * 0.25
  for i = 0, 3 do
    local ang = a + i * math.pi / 2
    local x1, y1 = cx + math.floor(math.cos(ang) * 9), cy - 2 + math.floor(math.sin(ang) * 9)
    local x2, y2 = cx + math.floor(math.cos(ang + 0.9) * 6), cy - 2 + math.floor(math.sin(ang + 0.9) * 6)
    UI.ink(({ "redp", "yellow", "skyp", "leaf" })[i + 1])
    gfx.setColor((i % 2 == 0 and not UI.color) and BLACK or WHITE)
    gfx.fillTriangle(cx, cy - 2, x1, y1, x2, y2)
    gfx.setColor(BLACK)
    gfx.drawLine(cx, cy - 2, x1, y1); gfx.drawLine(x1, y1, x2, y2)
  end
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy - 2, 1)
  gfx.setColor(BLACK)
end

do                                              -- (the tank and the pinwheel were drawn for the wall: stand them on the counter / table line instead)
  local tank, wheel = CAFE.art.aquarium, CAFE.art.pinwheel
  CAFE.art.aquarium = function(cx, cy) tank(cx, cy + 2) end
  CAFE.art.pinwheel = function(cx, cy) wheel(cx, cy - 3) end
end

-- where a snake that loops round the tank is, a distance s along its track: along the front, round the end, back along the rear, round the other end
function CAFE.snakeAt(s)
  local a, r = 5, 3.4                               -- half the length of the straight bits, and how tight the ends turn
  local straight, turn = 2 * a, math.pi * r
  local per = 2 * straight + 2 * turn
  s = s % per
  if s < straight then return -a + s, r end
  s = s - straight
  if s < turn then local f = s / r; return a + r * math.sin(f), r * math.cos(f) end
  s = s - turn
  if s < straight then return a - s, -r end
  s = s - straight
  local f = s / r
  return -a - r * math.sin(f), -r * math.cos(f)
end

function CAFE.art.snaketank(cx, cy)             -- a terrarium: the snake slithers round and round, slowing now and then to flick its tongue
  local fl, sin, cos = math.floor, math.sin, math.cos
  local top, bot = cy - 8, cy + 11
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(cx - 12, top, 25, bot - top)
  gfx.setColor(BLACK)
  UI.ink("tan")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 11, bot - 4, 23, 3) end
  gfx.setPattern(CHECK); gfx.fillRect(cx - 11, bot - 3, 23, 2); gfx.setColor(BLACK)         -- sandy floor
  UI.ink("slate")
  gfx.drawRect(cx - 12, top, 25, bot - top)
  gfx.fillRect(cx - 13, top - 2, 27, 2)                                                       -- the lid
  gfx.fillTriangle(cx + 4, top - 2, cx + 10, top - 2, cx + 7, top - 6)                       -- the heat lamp's hood
  UI.ink("leaf")
  -- one trip round its track takes 14 seconds; it slows right down twice a trip (that's when the tongue comes out)
  local Tc = 420
  local T = frames % Tc
  local w = 4 * math.pi / Tc
  local slow = 0.5 - 0.5 * cos(w * T)                                                          -- 0 = at its slowest
  local V = 41.4 / (0.625 * Tc)
  local sH = V * (0.625 * T - 0.375 * sin(w * T) / w) + 41.4 * ((math.floor(frames / (Tc))) % 2)
  local yc = cy + 2
  local function at(s)                                                                         -- a point on the track, with the slither wave across it
    local x, y = CAFE.snakeAt(s)
    local x2, y2 = CAFE.snakeAt(s + 0.4)
    local tx, ty = x2 - x, y2 - y
    local tl = math.sqrt(tx * tx + ty * ty); if tl < 0.001 then tl = 1 end
    tx, ty = tx / tl, ty / tl
    local wob = 0.7 * sin(s * 0.95 + frames * 0.05)
    return cx + x - ty * wob, yc + y + tx * wob, tx, ty
  end
  local pts = {}
  for i = 0, 9 do pts[i] = { at(sH - (9 - i) * 1.6) } end
  for i = 1, 9 do                                                                              -- thin at the tail and round the ends, fatter in the middle of the front lane
    local front = (pts[i][2] + pts[i - 1][2]) / 2 > yc - 0.5
    gfx.setLineWidth((i > 3 and front and math.abs(pts[i][4]) < 0.5) and 3 or 2)
    gfx.drawLine(fl(pts[i - 1][1] + 0.5), fl(pts[i - 1][2] + 0.5), fl(pts[i][1] + 0.5), fl(pts[i][2] + 0.5))
  end
  gfx.setLineWidth(1)
  local ex, ey, tx, ty = pts[9][1], pts[9][2], pts[9][3], pts[9][4]
  local hcx, hcy = fl(ex + tx * 1.5 + 0.5), fl(ey + ty * 1.5 + 0.5)
  local near = ey > yc - 0.5
  if math.abs(ty) > math.abs(tx) then gfx.fillEllipseInRect(hcx - 2, hcy - 3, 5, 7)           -- its head (upright while it turns)
  elseif near then gfx.fillEllipseInRect(hcx - 3, hcy - 2, 7, 5)
  else gfx.fillEllipseInRect(hcx - 2, hcy - 2, 5, 4) end                                       -- (smaller along the rear)
  gfx.setColor(WHITE)
  gfx.drawPixel(hcx + (tx >= 0 and 1 or -1), hcy - 1)                                          -- the eye
  gfx.drawPixel(fl(pts[4][1] + 0.5), fl(pts[4][2] + 0.5)); gfx.drawPixel(fl(pts[6][1] + 0.5), fl(pts[6][2] + 0.5))   -- the pattern on its back
  gfx.setColor(BLACK)
  local period = (slow < 0.35) and 34 or 120
  local fk = frames % period
  if fk < 7 then                                                                                -- the tongue flicks out and back
    local len = (fk < 4) and 4 or 3
    local ax, ay = (tx >= 0 and 1 or -1) * math.max(math.abs(tx), 0.6), math.max(-0.3, math.min(0.3, ty))
    local bx, by = fl(hcx + ax * 3.5 + 0.5), fl(hcy + ay * 3.5 + 0.5)
    local fx, fy = fl(hcx + ax * (3.5 + len) + 0.5), fl(hcy + ay * (3.5 + len) + 0.5)
    fx = math.max(cx - 9, math.min(cx + 9, fx))                                                -- (never through the glass)
    bx = math.max(cx - 9, math.min(cx + 9, bx))
    UI.ink("inkred")
    gfx.drawLine(bx, by, fx, fy)
    if fx > cx - 9 and fx < cx + 9 then gfx.drawPixel(fx + (tx >= 0 and 1 or -1), fy - 1); gfx.drawPixel(fx + (tx >= 0 and 1 or -1), fy + 1) end
  end
  UI.ink("inkorange")
  local lt = (math.floor(frames / (4))) % 6                                                                  -- warm light drifts down from the lamp
  gfx.drawPixel(cx + 5 + math.floor(lt / (3)), top + 2 + lt); gfx.drawPixel(cx + 9 - math.floor(lt / (3)), top + 2 + (lt + 3) % 6)
end

function CAFE.art.radio(cx, cy)
  UI.ink("mint")
  gfx.setColor(WHITE); gfx.fillRoundRect(cx - 11, cy - 3, 22, 13, 3)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(cx - 11, cy - 3, 22, 13, 3); gfx.setLineWidth(1)
  UI.ink("tan")
  if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 4, cy + 3, 4); gfx.setColor(BLACK) end
  UI.ink("bark")
  gfx.drawCircleAtPoint(cx - 4, cy + 3, 4)                                 -- the speaker
  gfx.drawPixel(cx - 4, cy + 3); gfx.drawPixel(cx - 6, cy + 2); gfx.drawPixel(cx - 2, cy + 4)
  UI.ink("brass")
  gfx.fillRect(cx + 3, cy, 6, 2)                                           -- the dial
  UI.ink("inkred")
  gfx.drawLine(cx + 4 + (math.floor(frames / (20))) % 4, cy, cx + 4 + (math.floor(frames / (20))) % 4, cy + 5)
  UI.ink("gray")
  gfx.drawLine(cx + 7, cy - 3, cx + 11, cy - 10)                           -- the aerial
  UI.ink("inkpurple")
  for k = 0, 1 do                                                          -- music notes float up from it
    local tt = (math.floor(frames / (3)) + k * 8) % 16
    local x, y = cx - 7 + k * 5 + math.floor(math.sin(tt * 0.6) * 2), cy - 4 - tt
    if tt < 14 then gfx.fillCircleAtPoint(x, y, 1); gfx.drawLine(x + 1, y, x + 1, y - 3) end
  end
end

-- ---- the rest of the Stuff tab: little things for the counter, and a juke box for the floor --------------
function CAFE.outRR(x, y, w, h, r, fill)          -- a rounded box with a 2px outline
  gfx.setColor(fill or WHITE); gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(x, y, w, h, r); gfx.setLineWidth(1)
end
function CAFE.noteAt(x, y)                        -- a little music note
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(x, y, 1); gfx.drawLine(x + 1, y, x + 1, y - 3)
end

function CAFE.art.boombox(cx, cy)                 -- two thumping speakers, a tape deck, and notes floating up
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.setLineWidth(2)
  gfx.drawLine(cx - 8, cy - 2, cx - 8, cy - 6); gfx.drawLine(cx - 8, cy - 6, cx + 8, cy - 6); gfx.drawLine(cx + 8, cy - 6, cx + 8, cy - 2)
  gfx.setLineWidth(1)
  UI.ink("redp")
  CAFE.outRR(cx - 12, cy - 3, 24, 14, 3)
  local beat = ((math.floor(frames / (3))) % 3 == 0)
  for sx = -7, 7, 14 do
    UI.ink("fur")
    if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + sx, cy + 4, 4) end
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx + sx, cy + 4, 4)
    gfx.fillCircleAtPoint(cx + sx, cy + 4, beat and 3 or 2)
    gfx.setColor(WHITE); gfx.drawPixel(cx + sx, cy + 4)
  end
  UI.ink("skyp")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy - 1, 7, 5) end
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 3, cy - 1, 7, 5)                                       -- the tape window with its two reels
  gfx.drawPixel(cx - 1, cy + 1); gfx.drawPixel(cx + 2, cy + 1)
  UI.ink("navyy")
  gfx.fillRect(cx - 3, cy + 6, 7, 2)                                       -- the tuning strip
  gfx.setColor(WHITE); gfx.drawPixel(cx - 2 + (math.floor(frames / (6))) % 5, cy + 6); gfx.setColor(BLACK)
  UI.ink("gray")
  gfx.drawLine(cx + 10, cy - 3, cx + 13, cy - 12)                          -- the aerial
  for k = 0, 1 do
    UI.ink(k == 0 and "inkpink" or "inkblue")
    local tt = (math.floor(frames / (2)) + k * 8) % 16
    if tt < 13 then CAFE.noteAt(cx - 5 + k * 9 + math.floor(math.sin(tt * 0.6) * 2), cy - 9 - math.floor(tt / (2))) end
  end
end

function CAFE.art.luckycat(cx, cy)                -- a maneki-neko: big dark eyes with a glint, a little mouth, one paw swinging slowly
  local ph = 0.5 + 0.5 * math.sin(frames * 0.2)                               -- 0 = paw up, 1 = paw swung right down
  local sw = math.rad(-62 + 68 * ph * ph * (3 - 2 * ph))                      -- (eased, so it lingers at the top and bottom of each beckon)
  local sx, sy = cx + 6, cy + 4                                                -- (the paw stays close to the body, so the cat sits in the middle of its spot)
  local ex, ey = sx + math.floor(math.cos(sw) * 5 + 0.5), sy + math.floor(math.sin(sw) * 5 + 0.5)
  local ox, oy = math.floor(-math.sin(sw) * 2 + 0.5), math.floor(math.cos(sw) * 2 + 0.5)    -- the arm is a little padded bar, not a hairline
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillPolygon(sx + ox, sy + oy, ex + ox, ey + oy, ex - ox, ey - oy, sx - ox, sy - oy)
  gfx.setColor(BLACK)
  gfx.drawLine(sx + ox, sy + oy, ex + ox, ey + oy); gfx.drawLine(sx - ox, sy - oy, ex - ox, ey - oy)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(ex, ey, 3)                      -- the paw
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(ex, ey, 3); gfx.drawPixel(ex, ey + 1); gfx.drawPixel(ex - 1, ey); gfx.drawPixel(ex + 1, ey)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 9, cy - 1, 19, 12)         -- the body
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 9, cy - 1, 19, 12); gfx.setLineWidth(1)
  gfx.setColor(WHITE); gfx.fillTriangle(cx - 8, cy - 9, cx - 6, cy - 16, cx - 2, cy - 11)      -- the ears
  gfx.fillTriangle(cx + 8, cy - 9, cx + 6, cy - 16, cx + 2, cy - 11)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 8, cy - 9, cx - 6, cy - 16); gfx.drawLine(cx - 6, cy - 16, cx - 2, cy - 11)
  gfx.drawLine(cx + 8, cy - 9, cx + 6, cy - 16); gfx.drawLine(cx + 6, cy - 16, cx + 2, cy - 11)
  UI.ink("inkpink")
  gfx.drawPixel(cx - 6, cy - 13); gfx.drawPixel(cx + 6, cy - 13)
  if UI.color then gfx.drawPixel(cx - 6, cy - 12); gfx.drawPixel(cx + 6, cy - 12) end
  UI.ink("white")
  CAFE.outRR(cx - 9, cy - 12, 19, 13, 4)                                      -- the head
  UI.ink("none")
  gfx.setColor(BLACK)
  if (math.floor(frames / (6))) % 9 == 8 then                                              -- a blink
    gfx.drawLine(cx - 6, cy - 8, cx - 3, cy - 8); gfx.drawLine(cx + 3, cy - 8, cx + 6, cy - 8)
  else                                                                        -- big dark eyes, each with a glint
    gfx.fillRect(cx - 6, cy - 9, 4, 3); gfx.fillRect(cx + 3, cy - 9, 4, 3)
    gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy - 9); gfx.drawPixel(cx + 4, cy - 9); gfx.setColor(BLACK)
  end
  UI.ink("inkpink")
  gfx.fillRect(cx - 1, cy - 6, 3, 1); gfx.drawPixel(cx, cy - 5)               -- the nose
  UI.ink("none")
  gfx.drawPixel(cx - 2, cy - 4); gfx.drawPixel(cx - 1, cy - 3); gfx.drawPixel(cx + 1, cy - 3); gfx.drawPixel(cx + 2, cy - 4)   -- and a little w of a mouth
  UI.ink("inkred")
  gfx.fillRect(cx - 6, cy + 1, 13, 2)                                         -- the collar and its bell
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy + 5, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy + 5, 2); gfx.drawPixel(cx, cy + 5)
  UI.ink("none")
end

-- the Music tab's pictures: a vinyl record sliding out of its sleeve, turning a little (which = "hmus" the pumpkin one, "xmus" the Christmas tree one)
CAFE.VPAT = { hmus = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }, xmus = { 0x88, 0x22, 0x88, 0x22, 0x88, 0x22, 0x88, 0x22 } }
function CAFE.vinyl(cx, cy, which)
  local floor, cos, sin, rad = math.floor, math.cos, math.sin, math.rad
  cx = cx + 3                                                   -- (sleeve and record together sit in the middle of the picture box)
  local dx, r = cx + 11, 24
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(dx, cy, r)
  gfx.setColor(WHITE)                                           -- the grooves
  gfx.drawCircleAtPoint(dx, cy, r - 3)
  gfx.drawCircleAtPoint(dx, cy, r - 6)
  gfx.drawCircleAtPoint(dx, cy, r - 9)
  gfx.setLineWidth(2)                                           -- a bright streak on each side, turning with the record
  local a0 = (frames * 5) % 360
  for k = 0, 1 do
    local px, py
    for da = 0, 36, 6 do
      local a = rad(a0 + k * 180 + da)
      local x, y = floor(dx + cos(a) * (r - 1.5) + 0.5), floor(cy + sin(a) * (r - 1.5) + 0.5)
      if px then gfx.drawLine(px, py, x, y) end
      px, py = x, y
    end
  end
  gfx.setLineWidth(1)
  UI.ink(which == "hmus" and "pumpk" or "redp")
  gfx.setColor(WHITE)                                           -- the paper label in the middle
  gfx.fillCircleAtPoint(dx, cy, 10)
  gfx.setPattern(CAFE.VPAT[which])
  gfx.fillCircleAtPoint(dx, cy, 8)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(dx, cy, 10)
  gfx.fillCircleAtPoint(dx, cy, 2)
  -- the sleeve, covering the left of the record
  local x0, y0, w, h = cx - 42, cy - 27, 42, 54
  UI.ink(which == "hmus" and "lav" or "skyp")
  gfx.setColor(WHITE)
  gfx.fillRect(x0, y0, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(x0, y0, w, h)
  gfx.setLineWidth(1)
  gfx.drawRect(x0 + 4, y0 + 4, w - 8, h - 8)
  local sx, sy = x0 + math.floor(w / (2)), y0 + 31
  if which == "hmus" then                                       -- a jack-o'-lantern under a few stars
    UI.ink("leafdk")
    gfx.fillRect(sx - 2, sy - 17, 4, 7)
    UI.ink("jack")
    gfx.fillEllipseInRect(sx - 14, sy - 11, 28, 24)
    gfx.setColor(WHITE)
    gfx.fillTriangle(sx - 9, sy - 1, sx - 3, sy - 1, sx - 6, sy - 6)          -- eyes
    gfx.fillTriangle(sx + 3, sy - 1, sx + 9, sy - 1, sx + 6, sy - 6)
    gfx.fillTriangle(sx - 2, sy + 3, sx + 2, sy + 3, sx, sy)                  -- nose
    gfx.drawLine(sx - 8, sy + 5, sx - 5, sy + 9); gfx.drawLine(sx - 5, sy + 9, sx - 2, sy + 5)      -- the grin
    gfx.drawLine(sx - 2, sy + 5, sx + 1, sy + 9); gfx.drawLine(sx + 1, sy + 9, sx + 4, sy + 5)
    gfx.drawLine(sx + 4, sy + 5, sx + 8, sy + 9)
    gfx.setColor(BLACK)
    UI.ink("inkyellow")
    for _, st in ipairs({ { -13, -22 }, { 11, -24 }, { 13, -14 }, { -14, -13 } }) do gfx.fillRect(sx + st[1], sy + st[2], 2, 2) end
  else                                                          -- a Christmas tree in the snow
    UI.ink("inkgreen")
    gfx.fillTriangle(sx, sy - 23, sx - 8, sy - 9, sx + 8, sy - 9)
    gfx.fillTriangle(sx, sy - 15, sx - 11, sy + 2, sx + 11, sy + 2)
    gfx.fillTriangle(sx, sy - 6, sx - 14, sy + 13, sx + 14, sy + 13)
    UI.ink("bark")
    gfx.fillRect(sx - 2, sy + 13, 4, 5)
    UI.ink(which == "hmus" and "lav" or "skyp")
    gfx.setColor(WHITE)
    gfx.setClipRect(x0 + 2, y0 + 2, w - 4, h - 4)
    CAFE.starAt(sx, sy - 25, 6)                                  -- a halo the colour of the sleeve, so the star stands apart from the tree...
    gfx.clearClipRect()
    gfx.setColor(BLACK)
    UI.ink("goldbk")
    CAFE.starAt(sx, sy - 25, 4)                                  -- ...and the star on top (a real five-pointed star)
    gfx.setColor(WHITE)
    local orn = { "redp", "yellow", "lav", "redp", "skyp", "yellow" }
    for i, o in ipairs({ { -3, -10 }, { 4, -4 }, { -8, 3 }, { 1, 7 }, { 9, 8 }, { -10, 10 } }) do UI.ink(orn[i]); gfx.fillCircleAtPoint(sx + o[1], sy + o[2], 1) end
    gfx.setColor(BLACK)
    UI.ink("inkwhite")
    for _, sn in ipairs({ { -14, -20 }, { 12, -21 }, { 15, -8 }, { -16, -6 }, { 15, 6 }, { -16, 18 } }) do gfx.fillRect(sx + sn[1], sy + sn[2], 2, 2) end
  end
  gfx.setColor(BLACK)
end
function CAFE.art.hmus(cx, cy) CAFE.vinyl(cx, cy, "hmus") end
function CAFE.art.xmus(cx, cy) CAFE.vinyl(cx, cy, "xmus") end

function CAFE.art.record(cx, cy)                  -- a turntable: the record spins and the notes float away
  UI.ink("woodl")
  CAFE.outRR(cx - 12, cy + 2, 24, 9, 2)
  UI.ink("none")
  gfx.setColor(BLACK); gfx.fillEllipseInRect(cx - 10, cy - 4, 20, 9)
  local a = frames * 0.5
  gfx.setColor(WHITE)
  gfx.drawLine(cx + math.floor(math.cos(a) * 7), cy + math.floor(math.sin(a) * 3), cx + math.floor(math.cos(a) * 3), cy + math.floor(math.sin(a) * 1.4))
  UI.ink("redp")
  gfx.fillCircleAtPoint(cx, cy, 2); gfx.setColor(BLACK); gfx.drawPixel(cx, cy)
  UI.ink("gray")
  gfx.drawLine(cx + 10, cy - 1, cx + 10, cy - 7)                             -- the arm
  gfx.setLineWidth(2); gfx.drawLine(cx + 10, cy - 7, cx + 4, cy - 1); gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(cx + 10, cy - 7, 1)
  UI.ink("brass")
  gfx.fillCircleAtPoint(cx - 9, cy + 6, 1)
  for k = 0, 1 do
    UI.ink(k == 0 and "inkblue" or "inkorange")
    local tt = (math.floor(frames / (2)) + k * 8) % 16
    if tt < 13 then CAFE.noteAt(cx - 4 + k * 8 + math.floor(math.sin(tt * 0.6) * 2), cy - 8 - math.floor(tt / (2))) end
  end
end

function CAFE.art.snowglobe(cx, cy)               -- a little pine tree in a globe, snow drifting down
  UI.ink("redbk")
  gfx.setColor(BLACK); gfx.fillRect(cx - 7, cy + 5, 14, 6)
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillRect(cx - 4, cy + 7, 8, 1)
  UI.ink("glass")
  gfx.fillCircleAtPoint(cx, cy - 3, 9)
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy - 3, 9); gfx.setLineWidth(1)
  UI.ink("inkgreen")
  gfx.fillTriangle(cx - 5, cy + 2, cx + 5, cy + 2, cx, cy - 3)           -- a pine tree in two tiers
  gfx.fillTriangle(cx - 4, cy - 1, cx + 4, cy - 1, cx, cy - 7)
  UI.ink("bark")
  gfx.fillRect(cx - 1, cy + 2, 2, 2)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.drawPixel(cx, cy - 4); gfx.drawPixel(cx - 2, cy + 1); gfx.drawPixel(cx + 2, cy + 1)
  UI.ink("snow")
  gfx.drawLine(cx - 7, cy + 3, cx + 7, cy + 3)                            -- snow on the ground
  gfx.setColor(BLACK)
  UI.ink("skyp")
  for k = 0, 7 do
    local x = cx - 6 + (k * 5) % 12 + math.floor(math.sin(frames * 0.2 + k) * 1)
    local y = cy - 10 + ((math.floor(frames / (2))) + k * 3) % 14
    if (x - cx) ^ 2 + (y - cy + 3) ^ 2 < 64 then gfx.drawPixel(x, y) end
  end
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy - 8); gfx.drawPixel(cx - 5, cy - 7); gfx.setColor(BLACK)
end

CAFE.GUMCOL = { "redp", "yellow", "skyp", "leaf", "rose", "orangep", "lav", "mint" }     -- (the PC version: every gumball its own colour)
function CAFE.art.gumball(cx, cy)                 -- a glass bowl of gumballs on a little stand
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy - 4, 9)
  UI.ink("redp")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy - 4, 9); gfx.setLineWidth(1)
  local balls = { { -4, -7, 0 }, { 1, -9, 1 }, { 5, -5, 2 }, { -6, -3, 1 }, { -1, -4, 2 }, { 4, -1, 0 }, { -4, 0, 2 }, { 0, 1, 0 } }
  for i = 1, #balls do
    local b = balls[i]
    local x, y = cx + b[1], cy + b[2] + 1
    UI.ink(CAFE.GUMCOL[i])
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, y, 2)
    if UI.color then UI.ink("white"); gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - 1); gfx.setColor(BLACK)      -- (a shine on every ball)
    elseif b[3] == 1 then gfx.fillCircleAtPoint(x, y, 1) elseif b[3] == 2 then gfx.drawPixel(x - 1, y - 1) end
  end
  UI.ink("redbk")
  if UI.color then gfx.setColor(WHITE) end
  gfx.fillRect(cx - 6, cy + 4, 12, 7)
  if UI.color then gfx.setColor(BLACK); UI.ink("redp"); gfx.drawRect(cx - 6, cy + 4, 12, 7) end
  UI.ink("brass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy + 7, 2); gfx.setColor(BLACK); gfx.drawPixel(cx, cy + 7)
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawLine(cx - 4, cy + 5, cx + 4, cy + 5); gfx.setColor(BLACK)
  UI.ink("inkblue")
  if (math.floor(frames / (3))) % 4 < 2 then gfx.drawPixel(cx - 7, cy - 9); gfx.drawPixel(cx - 7, cy - 8) end      -- a sparkle on the glass
end

function CAFE.art.cradle(cx, cy)                  -- Newton's cradle: four balls, the end ones swing out, click, and swing back
  local nar = CAFE.narrow
  local a, b = nar and math.max(-15, nar[1]) or -15, nar and math.min(14, nar[2]) or 14     -- (the base's ends: a little shorter in a tight spot)
  UI.ink("woodl")
  gfx.setColor(BLACK); gfx.fillRect(cx + a, cy + 9, b - a + 1, 2)
  UI.ink("slate")
  gfx.fillRect(cx + a + 1, cy - 10, 2, 19); gfx.fillRect(cx + b - 2, cy - 10, 2, 19)
  gfx.fillRect(cx + a + 1, cy - 10, b - a - 2, 2)
  local ph = (frames % 28) / 28
  local L, R = 0, 0
  if ph < 0.5 then L = math.sin(ph * 2 * math.pi) else R = math.sin((ph - 0.5) * 2 * math.pi) end
  for i = 0, 3 do
    local ang = (i == 0) and -L * 0.34 or ((i == 3) and R * 0.34 or 0)
    local px = cx - 8 + i * 5
    local bx, by = px + math.floor(math.sin(ang) * 14 + 0.5), cy - 8 + math.floor(math.cos(ang) * 14 + 0.5)
    UI.ink("gray")
    gfx.setColor(BLACK); gfx.drawLine(px, cy - 8, bx, by - 2)
    UI.ink("snow")
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(bx, by, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(bx, by, 2)
    UI.ink("slate")
  end
end

function CAFE.art.miniplaydate(cx, cy)            -- a tiny handheld (the Pee-Dee): a cup steaming on its screen, the crank turning now and then
  local bx, by = cx - 14, cy - 10
  UI.ink("yellow")
  CAFE.outRR(bx, by, 22, 21, 4)                                              -- the body
  UI.ink("glass")
  gfx.setColor(BLACK); gfx.fillRect(bx + 4, by + 4, 14, 9)                   -- the screen
  gfx.setColor(WHITE)
  gfx.drawPixel(bx + 5, by + 5)                                              -- a glint on the glass
  gfx.fillRect(bx + 7, by + 7, 6, 4)                                         -- a cup with a handle, on a saucer...
  gfx.drawPixel(bx + 13, by + 8); gfx.drawPixel(bx + 13, by + 9)
  gfx.drawLine(bx + 6, by + 11, bx + 13, by + 11)
  gfx.setColor(BLACK); gfx.drawLine(bx + 8, by + 8, bx + 11, by + 8)         -- (the coffee)
  gfx.setColor(WHITE)
  local f = (math.floor(frames / (5))) % 3                                                -- ...and its steam
  gfx.drawPixel(bx + 8, by + 5 + (f == 1 and 1 or 0)); gfx.drawPixel(bx + 11, by + 5 + (f == 2 and 1 or 0))
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.fillRect(bx + 4, by + 15, 4, 2); gfx.fillRect(bx + 5, by + 14, 2, 4)   -- the d-pad
  gfx.fillRect(bx + 17, by + 14, 2, 2); gfx.fillRect(bx + 13, by + 16, 2, 2)   -- the A and B buttons
  local c = CAFE.pdc                                                         -- the crank: it sits still, then every 8 to 10 seconds gets a good turning
  if not c or frames < c.last then c = { last = frames, nxt = frames + math.random(60, 150), left = 0, ang = 0 }; CAFE.pdc = c end
  if c.last ~= frames then
    c.last = frames
    if c.left > 0 then c.left = c.left - 1; c.ang = c.ang + 0.5
    elseif frames >= c.nxt then c.left = 36; c.nxt = frames + math.random(240, 300) end
  end
  local a = c.ang
  UI.ink("brass")
  local kx, ky = bx + 22 + math.floor(math.cos(a) * 4), by + 9 + math.floor(math.sin(a) * 4)
  gfx.setLineWidth(2); gfx.drawLine(bx + 22, by + 9, kx, ky); gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(kx, ky, 1)
  gfx.fillCircleAtPoint(bx + 22, by + 9, 1)
end

CAFE.JB = {}
function CAFE.jukeShape(cx, cy, grow)             -- the juke box's arched outline (cached: one polygon call instead of a dozen lines)
  local key = cx * 1000 + cy + (grow or 0) * 1000000
  local c = CAFE.JB[key]
  if c then return c end
  local pts, g = {}, grow or 0
  local rx, ry, top = 12 - g, 11 - g, cy - 5
  for k = 0, 12 do
    local a = math.pi + k * math.pi / 12
    pts[#pts + 1] = cx + math.floor(math.cos(a) * rx + 0.5)
    pts[#pts + 1] = top + math.floor(math.sin(a) * ry + 0.5)
  end
  pts[#pts + 1] = cx + rx; pts[#pts + 1] = cy + 14 - g
  pts[#pts + 1] = cx - rx; pts[#pts + 1] = cy + 14 - g
  CAFE.JB[key] = pts
  return pts
end
function CAFE.jukeDome(cx, cy)                    -- the dark half-moon of glass at the top, where the lights run round
  local key = "d" .. cx * 1000 + cy
  local c = CAFE.JB[key]
  if c then return c end
  local pts = {}
  for k = 0, 10 do
    local a = math.pi + k * math.pi / 10
    pts[#pts + 1] = cx + math.floor(math.cos(a) * 8 + 0.5)
    pts[#pts + 1] = cy - 6 + math.floor(math.sin(a) * 7 + 0.5)
  end
  CAFE.JB[key] = pts
  return pts
end

function CAFE.art.jukebox(cx, cy)                 -- a glowing juke box: chasing lights, a spinning record, notes drifting up
  UI.ink("wine")
  gfx.setColor(BLACK); gfx.fillPolygon(table.unpack(CAFE.jukeShape(cx, cy, 0)))
  UI.ink("peach")
  gfx.setColor(WHITE); gfx.fillPolygon(table.unpack(CAFE.jukeShape(cx, cy, 2)))
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillPolygon(table.unpack(CAFE.jukeDome(cx, cy)))              -- the glass dome...
  local tick = math.floor(frames / (4))
  gfx.setColor(WHITE)
  for k = 0, 4 do                                                           -- ...with its bulbs chasing round
    local a = math.pi + (k + 0.5) * math.pi / 5
    local x, y = cx + math.floor(math.cos(a) * 5.5 + 0.5), cy - 6 + math.floor(math.sin(a) * 4.5 + 0.5)
    if (k + tick) % 3 == 0 then gfx.fillRect(x - 1, y - 1, 2, 2) else gfx.drawPixel(x, y) end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 3, 11, 9)                                        -- the window with the record in it
  gfx.fillCircleAtPoint(cx, cy + 1, 3)
  local a = frames * 0.6
  gfx.setColor(WHITE)
  gfx.drawPixel(cx + math.floor(math.cos(a) * 2 + 0.5), cy + 1 + math.floor(math.sin(a) * 2 + 0.5))
  gfx.drawPixel(cx, cy + 1)
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 5, cy - 2, cx + 2, cy + 1)                               -- the arm
  UI.ink("redp")
  local sel = (math.floor(frames / (12))) % 3                                             -- the song buttons
  for k = 0, 2 do
    if k == sel then gfx.drawRect(cx - 6 + k * 5, cy + 7, 3, 2) else gfx.fillRect(cx - 6 + k * 5, cy + 7, 3, 2) end
  end
  UI.ink("gray")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 8, cy + 10, 16, 2); gfx.setColor(BLACK)      -- the speaker grille
  for j = 0, 4 do                                                           -- a column of lights down each side
    UI.ink(({ "inkpink", "inkyellow", "inkblue", "inkmint", "inkorange" })[j + 1])
    if (j + tick) % 3 == 0 then gfx.fillRect(cx - 9, cy - 3 + j * 3, 2, 2); gfx.fillRect(cx + 8, cy - 3 + j * 3, 2, 2) end
  end
  UI.ink("inkpink")
  for k = 0, 1 do                                                           -- notes float up out of the top
    local tt = (math.floor(frames / (2)) + k * 9) % 18
    if tt < 14 then CAFE.noteAt(cx - 4 + k * 8 + math.floor(math.sin(tt * 0.6) * 2), cy - 18 - math.floor(tt / (2))) end
  end
end

function CAFE.art.cuckoo(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 11, cy - 3, cx, cy - 14, cx + 11, cy - 3)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 9, cy - 3, 18, 14)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 9, cy - 3, 18, 14)
  local t = (G and G.t) or 0
  if t % 30 < 2 then                                  -- the little bird pops out
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy + 2, 2)
    gfx.fillTriangle(cx + 2, cy + 1, cx + 6, cy + 2, cx + 2, cy + 3)
  else
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
  end
  local sw = math.floor(math.sin(frames * 0.08) * 4)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)
  gfx.fillCircleAtPoint(cx + sw, cy + 17, 2)
end

function CAFE.art.calendar(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 10, cy - 12, 20, 24)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 10, cy - 12, 20, 24)
  gfx.fillRect(cx - 10, cy - 12, 20, 6)
  gfx.fillRect(cx - 6, cy - 14, 2, 4)
  gfx.fillRect(cx + 4, cy - 14, 2, 4)
  for r = 0, 2 do
    for c = 0, 3 do
      gfx.fillRect(cx - 8 + c * 4, cy - 3 + r * 5, 2, 2)
    end
  end
  gfx.drawRect(cx + 2, cy + 6, 5, 4)
end

local function pot(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 9, cy + 5, cx + 9, cy + 5, cx + 6, cy + 14, cx - 6, cy + 14)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 7, cy + 7, 14, 2)
  gfx.setColor(BLACK)
end

function CAFE.art.plant(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx, cy + 5, cx - 9 + sw, cy - 9, cx - 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + 9 + sw, cy - 10, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + sw, cy - 15, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx - 13 + sw, cy - 2, cx - 4, cy + 6)
  gfx.fillTriangle(cx, cy + 5, cx + 13 + sw, cy - 3, cx + 4, cy + 6)
  pot(cx, cy)
end

function CAFE.art.cactus(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 4, cy - 14, 8, 22, 3)
  gfx.fillRoundRect(cx - 11, cy - 7, 6, 3, 1)
  gfx.fillRoundRect(cx - 11, cy - 11, 3, 7, 1)
  gfx.fillRoundRect(cx + 5, cy - 3, 6, 3, 1)
  gfx.fillRoundRect(cx + 8, cy - 8, 3, 8, 1)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 1, cy - 10)
  gfx.drawPixel(cx + 1, cy - 4)
  gfx.drawPixel(cx - 1, cy + 1)
  pot(cx, cy)
end

function CAFE.art.fern(cx, cy)
  local sw = math.floor(math.sin(frames * 0.06) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  for k = -2, 2 do
    gfx.drawLine(cx, cy + 5, cx + k * 5, cy - 5)
    gfx.drawLine(cx + k * 5, cy - 5, cx + k * 8 + sw, cy - 11)
  end
  gfx.setLineWidth(1)
  pot(cx, cy)
end

function CAFE.art.flowers(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 2, cy + 5, cx + k * 7, cy - 7)
  end
  for k = -1, 1 do
    local fx, fy = cx + k * 7, cy - 9 - (k == 0 and 3 or 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(fx, fy, 4)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(fx, fy, 4)
    gfx.fillCircleAtPoint(fx, fy, 1)
  end
  pot(cx, cy)
end

function CAFE.art.tree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 9, 4, 6)
  gfx.fillTriangle(cx, cy - 15, cx - 8, cy - 3, cx + 8, cy - 3)
  gfx.fillTriangle(cx, cy - 8, cx - 11, cy + 4, cx + 11, cy + 4)
  gfx.fillTriangle(cx, cy - 2, cx - 13, cy + 10, cx + 13, cy + 10)
  local spots = { { -3, -8 }, { 3, -1 }, { -7, 2 }, { 6, 6 }, { -3, 7 } }
  for i, sp in ipairs(spots) do
    if (i + math.floor(frames / (20))) % 2 == 0 then
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx + sp[1], cy + sp[2], 2)
    end
  end
  gfx.setColor(WHITE)
  gfx.fillTriangle(cx, cy - 19, cx - 2, cy - 15, cx + 2, cy - 15)
  gfx.setColor(BLACK)
end

function CAFE.art.pumpkin(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setLineWidth(1)
  gfx.drawLine(cx, cy - 3, cx, cy + 13)
  gfx.fillRect(cx - 1, cy - 7, 3, 5)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 2, cy + 5, cx - 4, cy + 1)
  gfx.fillTriangle(cx + 2, cy + 5, cx + 6, cy + 5, cx + 4, cy + 1)
  gfx.fillRect(cx - 4, cy + 8, 8, 2)
end

-- ---- tiny wall art (about 20 x 16, hung on the open wall above the counter) -------------------------
local function tinyFrame(cx, cy, w, h, bg)        -- bg = the colour behind the picture (PC version)
  UI.ink(bg or "white")
  gfx.setColor(WHITE)
  gfx.fillRect(cx - math.floor(w / (2)), cy - math.floor(h / (2)), w, h)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(cx - math.floor(w / (2)), cy - math.floor(h / (2)), w, h)
  gfx.setLineWidth(1)
end
function CAFE.art.t1(cx, cy)                      -- landscape: mountains and a sun
  tinyFrame(cx, cy, 22, 16, "skyp")
  UI.ink("leaf")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 9, cy + 4, 18, 3); gfx.setColor(BLACK) end      -- a green meadow
  UI.ink("slate")
  gfx.fillTriangle(cx - 8, cy + 5, cx - 3, cy - 3, cx + 2, cy + 5)
  UI.ink("plum")
  gfx.fillTriangle(cx - 1, cy + 5, cx + 4, cy - 1, cx + 8, cy + 5)            -- (stops inside the frame's edge)
  UI.ink("yellow")
  if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + 5, cy - 4, 2); gfx.setColor(BLACK) end
  gfx.drawCircleAtPoint(cx + 5, cy - 4, 2)
end
function CAFE.art.t2(cx, cy)                      -- heart
  tinyFrame(cx, cy, 18, 18, "blush")
  UI.ink("inkred")
  UI.pic(CAFE.HEART10, cx - 5, cy - 4)                                         -- an even-sized heart, so it sits exactly in the middle of the frame
  gfx.setColor(BLACK)
  UI.ink("none")
end
CAFE.HEART10 = { ".kkk..kkk.", "kwkkkkkkkk", "kkkkkkkkkk", "kkkkkkkkkk", ".kkkkkkkk.", "..kkkkkk..", "...kkkk...", "....kk...." }
function CAFE.art.t3(cx, cy)                      -- sunburst
  tinyFrame(cx, cy, 21, 17, "skyp")                -- (an odd-sized frame, so the sun sits exactly in its middle, every ray inside it)
  gfx.setColor(BLACK)
  UI.ink("inkorange")
  CAFE.pix(CAFE.SUN11, cx - 5, cy - 5, "R")
  UI.ink("inkgold")
  CAFE.pix(CAFE.SUN11, cx - 5, cy - 5, "S")
  UI.ink("none")
end
CAFE.SUN11 = { ".....R.....", ".R...R...R.", "..R.....R..", "....SSS....", "...SSSSS...", "RR.SSSSS.RR", "...SSSSS...", "....SSS....",
               "..R.....R..", ".R...R...R.", ".....R....." }
function CAFE.art.t4(cx, cy)                      -- a mug print
  tinyFrame(cx, cy, 20, 17, "mint")
  CAFE.mapPic(CAFE.MUGPRINT, cx - 6, cy - 5, { a = { "snow", 1 }, h = { "inkred", 0 }, s = { "gray", 0 } }, { a = "w", h = "k", s = "k" })
end
CAFE.MUGPRINT = { "...s..s.....", "....s..s....", "...s..s.....", "kkkkkkkkkk..", "kwaaaaaaakkk", "kwahhahhak.k", "kwhhhhhhhk.k",
                  "kwahhhhhakkk", "kwaahhhaak..", "kwaaahaaak..", ".kkkkkkkk..." }   -- a white mug with a red heart on it, steaming
CAFE.CATFACE = { ".k.......k.", ".kk.....kk.", ".kpkkkkkpk.", "kwwwwkwwwwk", "kwkkwwwkkwk",
                 "kwwwwwwwwwk", "kwwwwpwwwwk", ".kwwkwkwwk.", "..kkkkkkk.." }
CAFE.CATDOTS = { 0xFF, 0xDD, 0xFF, 0xFF, 0xFF, 0x77, 0xFF, 0xFF }          -- a light sprinkle of dots behind the face
function CAFE.art.t5(cx, cy)                      -- round cat portrait: a little tabby face in a gold frame
  UI.ink("brass")                                                              -- (odd-sized circles round cx, cy: the face sits exactly in the middle)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 9, cy - 9, 19, 19)
  UI.ink("skyp")
  if UI.color then gfx.setColor(WHITE) else gfx.setPattern(CAFE.CATDOTS) end
  gfx.fillEllipseInRect(cx - 7, cy - 7, 15, 15)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 9, cy - 9, 19, 19); gfx.setLineWidth(1)
  local x0, y0 = cx - 5, cy - 4
  UI.ink("ginger")
  gfx.setColor(WHITE); CAFE.pix(CAFE.CATFACE, x0, y0, "w")
  gfx.setColor(BLACK); CAFE.pix(CAFE.CATFACE, x0, y0, "k")
  UI.ink("inkpink")
  CAFE.pix(CAFE.CATFACE, x0, y0, "p")
  gfx.setColor(BLACK)
end
function CAFE.art.t6(cx, cy)                      -- oval mirror with a shine
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 7, cy - 9, 14, 18)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 7, cy - 9, 14, 18); gfx.setLineWidth(1)
  UI.ink("inkblue")
  gfx.drawLine(cx - 3, cy - 4, cx - 1, cy - 6)
  gfx.drawLine(cx - 4, cy, cx + 1, cy - 7)
end
function CAFE.art.t7(cx, cy)                      -- bunting: a string of little flags
  tinyFrame(cx, cy, 34, 16, "cream")
  gfx.setColor(BLACK)
  UI.ink("bark")
  gfx.drawLine(cx - 14, cy - 5, cx, cy - 2); gfx.drawLine(cx, cy - 2, cx + 14, cy - 5)
  for i = -2, 2 do
    local x = cx + i * 6
    local y = cy - 5 + (2 - math.abs(i)) * 1 + math.floor(math.abs(2 - math.abs(i)) * 0.5)
    y = cy - 5 + math.floor((2 - math.abs(i)) * 1.5 + 0.5)
    UI.ink(({ "redp", "yellow", "skyp", "leaf", "rose" })[i + 3])
    if UI.color then
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    elseif i % 2 == 0 then gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
    else
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    end
  end
end
function CAFE.art.t8(cx, cy)                      -- three little stars on a night-blue board
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 11, cy - 8, 23, 17, 3)
  UI.ink("yellow")
  gfx.setColor(WHITE)
  CAFE.pix(CAFE.STAR9, cx - 4, cy - 5, "s")
  CAFE.pix(CAFE.STAR5, cx + 5, cy - 7, "s")
  CAFE.pix(CAFE.STAR5, cx - 10, cy + 2, "s")
  local tw = (math.floor(frames / (14))) % 2                                   -- two specks that twinkle
  gfx.drawPixel(cx + 8 - tw, cy + 5); gfx.drawPixel(cx - 8 + tw, cy - 5)
  gfx.setColor(BLACK)
end
CAFE.STAR9 = { "....s....", "....s....", "...sss...", "sssssssss", ".sssssss.", "..sssss..", "..sssss..", ".sss.sss.", ".s.....s." }
CAFE.STAR5 = { "..s..", ".sss.", "sssss", ".sss.", ".s.s." }
function CAFE.art.t9(cx, cy)                      -- music notes
  tinyFrame(cx, cy, 18, 18, "lilac")
  gfx.setColor(BLACK)
  UI.ink("inkpurple")
  UI.pic(CAFE.NOTES2, cx - 5, cy - 4)                                          -- two beamed notes, right in the middle of the frame
  gfx.setColor(BLACK)
  UI.ink("none")
end
CAFE.NOTES2 = { "...kkkkkkk", "...kkkkkkk", "...k.....k", "...k.....k", "...k.....k", ".kkk...kkk", "kkkk..kkkk", "kkkk..kkkk", ".kk....kk." }
function CAFE.art.t13(cx, cy)                     -- a pastel bouquet in a little vase
  tinyFrame(cx, cy, 19, 17, "rfloral")
  CAFE.mapPic(CAFE.BOUQUET, cx - 6, cy - 5, { p = { "fl_pink", 0 }, v = { "fl_lilac", 0 }, y = { "fl_yellow", 0 }, b = { "fl_blue", 0 },
    l = { "fl_leaf", 0 }, a = { "fl_blue", 1 } }, { a = "w" })
end
CAFE.BOUQUET = { "......v......", "...p.vwv.y...", "..pwp.v.ywy..", "...p..l..y...", "..b.l.l.l.p..", ".bwb.lll.pwp.", "..blllllllp..", "....kkkkk....", "...kawaaak...", "...kaaaaak...", "....kkkkk...." }
function CAFE.art.t14(cx, cy)                     -- matcha: a bowl of green tea, a leaf in the foam, two tea leaves
  tinyFrame(cx, cy, 19, 17, "rmatcha")
  CAFE.mapPic(CAFE.MATCHAPIC, cx - 6, cy - 5, { l = { "fl_leafdk", 0 }, m = { "fl_matcha", 1 }, a = { "fl_bowl", 1 } }, { m = "g", a = "w" })
end
CAFE.MATCHAPIC = { "...ll........", "..llll..ll...", "...lll.llll..", ".....l.lll...", ".............", ".kkkkkkkkkkk.", ".kmmmwwwmmmk.", ".kaaaaaaaaak.", "..kaaaaaaak..", "...kkkkkkk...", ".....kkk....." }
-- the newer paintings: 17 x 15 pictures in a 21 x 19 frame (tools/paintings/paint.py draws them)
CAFE.PAINT_LATTE = { "ttttttoooootttttt", "ttttoosssssootttt", "tttosssrrrsssottt", "TTossrrcccrrssoTT", "ttosrrccCccrrsott", "tossrchhchhcrsoot", "tosrchhhhhhhcrrrt", "Tosrcchhhhhccrrro", "tosrccchhhcccrrrt", "tossrccchcccrsoot", "ttosrrccCccrrsott", "TTossrrcccrrssoTT", "tttosssrrrsssottt", "ttttoosssssootttt", "ttttttoooootttttt" }
function CAFE.art.t15(cx, cy)                     -- latte art
  tinyFrame(cx, cy, 21, 19, "pa_latte_bg")
  CAFE.mapPic(CAFE.PAINT_LATTE, cx - 8, cy - 7, { t = { "pa_latte_t", 0 }, T = { "pa_latte_TT", 0 }, s = { "pa_latte_s", 0 }, o = { "pa_latte_o", 0 }, r = { "pa_latte_r", 0 }, c = { "pa_latte_c", 0 }, h = { "pa_latte_h", 0 }, C = { "pa_latte_CC", 0 } }, { t = "w", T = "g", s = "w", o = "k", r = "w", c = "k", h = "w", C = "g" })
end
CAFE.PAINT_BLOSSOM = { "aaaaaaaaaaaaaaaaa", "aaaaaaaqaaaaaaaap", "aqaaaaaaaaaaaaapw", "aaaaaaaaaaaapaaap", "aaaapaaaaaapwpaba", "aaapwpaaaaaapbbaa", "aaaapbaapaaabaaaa", "aaaaabapwpbbaaaaa", "aaaaaabapbbaaapaa", "aapaaabbbpabapwpa", "apwpabbapwpabbpaa", "aapbbaaaapaaaaaaa", "abbaaaaaaaaaaaaaa", "baaaaaaaaaqaaaaqa", "aaaqaaaaaaaaaaaaa" }
function CAFE.art.t16(cx, cy)                     -- cherry blossoms
  tinyFrame(cx, cy, 21, 19, "pa_blossom_bg")
  CAFE.mapPic(CAFE.PAINT_BLOSSOM, cx - 8, cy - 7, { a = { "pa_blossom_a", 0 }, b = { "pa_blossom_b", 0 }, p = { "pa_blossom_p", 0 }, w = { "pa_blossom_w", 0 }, q = { "pa_blossom_q", 0 } }, { a = "w", b = "k", p = "k", w = "w", q = "k" })
end
CAFE.PAINT_CITY = { "nnnnnnnnnnnnnnnnn", "nnnnnnsnnnnnmmnnn", "nnsnnnnnnBnMmmmnn", "nnnnnnnnnBmmmmmmn", "nnnnnnnnBBBmmMmmn", "nnnnsnnnByBmmmmnn", "nnnBBBnnBBBnmBBBB", "nsnByBnnByBnnByBy", "nnnBBBnnBBBBBBBBB", "BBBBBBnnBBByBBBBy", "ByBBBBBBBBBBBBBBB", "BBBByBBBByBBBByBB", "ByBBBBBBBBBBBBBBB", "BBBByByBByByBByBy", "BBBBBBBBBBBBBBBBB" }
function CAFE.art.t17(cx, cy)                     -- city at night
  tinyFrame(cx, cy, 21, 19, "pa_city_bg")
  CAFE.mapPic(CAFE.PAINT_CITY, cx - 8, cy - 7, { n = { "pa_city_n", 0 }, m = { "pa_city_m", 0 }, M = { "pa_city_MM", 0 }, s = { "pa_city_s", 0 }, B = { "pa_city_BB", 0 }, y = { "pa_city_y", 0 } }, { n = "k", m = "w", M = "g", s = "w", B = "g", y = "w" })
end
CAFE.PAINT_CHERRY = { "aaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaalLaa", "aaaaaaaaaaaalLlaa", "aaaaaaaaaaallLlla", "aaaaaaaaLlaalLlbb", "lLlaaaalLllaLllaa", "lLllaaallLlblbaaa", "llLllaaalLbahrraa", "llLLlaabblaarrhra", "allLlabaaaahrrrra", "aaablbhraaarrrrra", "aabahrrrraaaaaaaa", "bbaarrrraaaaaaaaa", "aaaaahrraaaaaaaaa", "aaaaarrraaaaaaaaa" }
function CAFE.art.t18(cx, cy)                     -- coffee cherries
  tinyFrame(cx, cy, 21, 19, "pa_cherry_bg")
  CAFE.mapPic(CAFE.PAINT_CHERRY, cx - 8, cy - 7, { a = { "pa_cherry_a", 0 }, b = { "pa_cherry_b", 0 }, l = { "pa_cherry_l", 0 }, L = { "pa_cherry_LL", 0 }, r = { "pa_cherry_r", 0 }, h = { "pa_cherry_h", 0 } }, { a = "w", b = "k", l = "g", L = "k", r = "k", h = "w" })
end
CAFE.PAINT_BALLOON = { "aaaaaaakkkaaaaaaa", "aaaaakkRRRkkaccca", "aaaakYYRRRYYccccc", "aaaakYYRRRYYkaaaa", "aaakBYYRRRYYBkaaa", "aaakBYYRRRYYBkaaa", "aaakBYYRRRYYBkaaa", "aaakBYYRRRYYBkaaa", "aaaakYYRRRYYkaaaa", "aaaakYYRRRYYkaaaa", "aaaaakkRRRkkaaaaa", "acccaaakkkaaaaaaa", "cccccakaaakaaaaaa", "aaaaaaakwkaaaaaaa", "aaaaaaawwwaaaaaaa" }
function CAFE.art.t19(cx, cy)                     -- hot air balloon
  tinyFrame(cx, cy, 21, 19, "pa_balloon_bg")
  CAFE.mapPic(CAFE.PAINT_BALLOON, cx - 8, cy - 7, { a = { "pa_balloon_a", 0 }, R = { "pa_balloon_RR", 0 }, Y = { "pa_balloon_YY", 0 }, B = { "pa_balloon_BB", 0 }, k = { "pa_balloon_k", 0 }, w = { "pa_balloon_w", 0 }, c = { "pa_balloon_c", 0 } }, { a = "w", R = "k", Y = "w", B = "g", k = "k", w = "g", c = "w" })
end
function CAFE.art.t10(cx, cy)                     -- moon and stars
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 12, cy - 9, 24, 18, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 3, cy, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx - 1, cy - 1, 5)
  gfx.setColor(WHITE)
  CAFE.pix(CAFE.STAR5, cx + 4, cy - 6, "s")                                   -- a little star beside the moon
  gfx.drawPixel(cx + 8, cy + 3); gfx.drawPixel(cx + 4, cy + 5)
  gfx.setColor(BLACK)
end
function CAFE.art.t12(cx, cy)                     -- sailboat
  tinyFrame(cx, cy, 22, 18, "skyp")
  gfx.setColor(BLACK)
  UI.ink("water")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 9, cy + 5, 18, 3); gfx.setColor(BLACK) end      -- the sea
  UI.ink("inkred")
  gfx.fillTriangle(cx - 1, cy - 6, cx - 1, cy + 2, cx - 6, cy + 2)
  UI.ink("white")
  if UI.color then gfx.setColor(WHITE); gfx.fillTriangle(cx + 1, cy - 4, cx + 1, cy + 2, cx + 6, cy + 2); gfx.setColor(BLACK) end
  gfx.drawLine(cx + 1, cy - 4, cx + 1, cy + 2); gfx.drawLine(cx + 1, cy - 4, cx + 6, cy + 2); gfx.drawLine(cx + 1, cy + 2, cx + 6, cy + 2)
  UI.ink("woodl")
  gfx.fillPolygon(cx - 7, cy + 4, cx + 7, cy + 4, cx + 5, cy + 7, cx - 5, cy + 7)
end

function CAFE.art.table(cx, cy)                    -- a table with its two chairs (the shop picture, and the place-a-table screen)
  CAFE.chairAt(cx - 17, cy, "l")
  CAFE.chairAt(cx + 17, cy, "r")
  CAFE.tableAt(cx, cy, 13, nil)
  gfx.setColor(BLACK)
end

function CAFE.art.booth(cx, cy)                    -- the corner booth, small: the L couch, the table and its two chairs
  local fab = CAFE.fabric()
  UI.ink(fab and fab.frame or "couch")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx + 16, cy - 25, 7, 48, 3)                -- the back up the side...
  gfx.fillRoundRect(cx - 31, cy + 16, 54, 7, 3)                -- ...and along the bottom
  gfx.fillRoundRect(cx + 3, cy - 26, 20, 6, 3)                 -- the arms
  gfx.fillRoundRect(cx - 32, cy + 3, 6, 20, 3)
  local function cushion(x, y, w, h)
    if fab then CAFE.cushionAt(fab, x, y, w, h, 3); return end
    gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 3)
    gfx.setColor(BLACK); gfx.drawRoundRect(x, y, w, h, 3)
    gfx.drawPixel(x + math.floor(w / 2), y + math.floor(h / 2))
  end
  cushion(cx + 4, cy - 20, 13, 13); cushion(cx + 4, cy - 7, 13, 12); cushion(cx + 4, cy + 4, 13, 13)
  cushion(cx - 26, cy + 4, 15, 13); cushion(cx - 11, cy + 4, 15, 13)
  CAFE.chairAt(cx - 26, cy - 7, "l")
  CAFE.chairAt(cx - 8, cy - 25, "u")
  CAFE.tableAt(cx - 8, cy - 7, 9, nil)
  UI.ink("none")
  gfx.setColor(BLACK)
end

local function smallPot(cx, cy)                -- a little pot for the counter
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 6, cy + 4, cx + 6, cy + 4, cx + 4, cy + 10, cx - 4, cy + 10)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 5, cy + 5, 10, 1)
  gfx.setColor(BLACK)
end

local function bloom(x, y, r)                  -- a flower head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.fillCircleAtPoint(x, y, math.max(1, r - 2))
end

function CAFE.art.tulips(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 3, cy + 4, cx + k * 4, cy - 4)
    gfx.fillTriangle(cx + k * 4 - 3, cy - 2, cx + k * 4 + 3, cy - 2, cx + k * 4, cy - 9)
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx, cy - 4)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.succ(cx, cy)
  gfx.setColor(BLACK)
  for k = -2, 2 do
    gfx.fillTriangle(cx, cy + 4, cx + k * 3 - 2, cy - 5 + math.abs(k), cx + k * 3 + 2, cy - 5 + math.abs(k))
  end
  gfx.setColor(WHITE)
  gfx.drawLine(cx, cy + 2, cx, cy - 3)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.daisies(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(cx - 4, cy + 1, 8, 9, 2)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(cx - 4, cy + 1, 8, 9, 2)
  for k = -1, 1 do
    gfx.drawLine(cx + k, cy + 1, cx + k * 5, cy - 6)
    bloom(cx + k * 5, cy - 7 - (k == 0 and 2 or 0), 3)
  end
end

function CAFE.art.minicac(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 2, cy - 7, 5, 12, 2)
  gfx.fillRoundRect(cx - 6, cy - 3, 3, 2, 1)
  gfx.fillRoundRect(cx - 6, cy - 6, 2, 5, 1)
  gfx.fillRoundRect(cx + 3, cy - 1, 3, 2, 1)
  gfx.fillRoundRect(cx + 5, cy - 4, 2, 5, 1)
  smallPot(cx, cy)
end

function CAFE.art.herbs(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do gfx.fillCircleAtPoint(cx + k * 4, cy - 1 - (k == 0 and 3 or 0), 3) end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 4, cy - 1)
  gfx.drawPixel(cx, cy - 4)
  gfx.drawPixel(cx + 4, cy - 1)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.palm(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 5, cx + 1, cy - 8)
  gfx.setLineWidth(1)
  for k = -3, 3 do
    gfx.drawLine(cx + 1, cy - 8, cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2)
    gfx.drawLine(cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2, cx + 1 + k * 5 + sw, cy - 11 + math.abs(k) * 3)
  end
  pot(cx, cy)
end

function CAFE.art.snake(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 3, cy + 5, cx - 5, cy - 12)
  gfx.fillTriangle(cx - 3, cy + 5, cx + 1, cy + 5, cx - 1, cy - 15)
  gfx.fillTriangle(cx + 1, cy + 5, cx + 4, cy + 5, cx + 3, cy - 10)
  gfx.fillTriangle(cx + 3, cy + 5, cx + 7, cy + 5, cx + 7, cy - 6)
  gfx.setColor(WHITE)
  gfx.drawLine(cx - 1, cy + 3, cx - 1, cy - 10)
  gfx.setColor(BLACK)
  pot(cx, cy)
end

function CAFE.art.sunflower(cx, cy)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 5, cx - 5, cy - 6)
  gfx.drawLine(cx + 3, cy + 5, cx + 6, cy - 3)
  gfx.fillTriangle(cx - 3, cy + 1, cx - 9, cy - 2, cx - 3, cy - 2)
  for _, f in ipairs({ { -5, -9, 5 }, { 6, -6, 4 } }) do
    for a = 0, 7 do
      local an = a * math.pi / 4
      gfx.fillCircleAtPoint(cx + f[1] + math.floor(math.cos(an) * (f[3] + 1)), cy + f[2] + math.floor(math.sin(an) * (f[3] + 1)), 1)
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 1)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 2)
  end
  pot(cx, cy)
end

function CAFE.art.bonsai(cx, cy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 6, cx - 2, cy + 1)
  gfx.drawLine(cx - 2, cy + 1, cx + 2, cy - 5)
  gfx.drawLine(cx + 2, cy - 5, cx - 1, cy - 9)
  gfx.setLineWidth(1)
  for _, c in ipairs({ { -7, -6, 5 }, { 0, -12, 6 }, { 8, -7, 5 }, { -2, -7, 4 } }) do
    gfx.fillCircleAtPoint(cx + c[1], cy + c[2], c[3])
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 7, cy - 6); gfx.drawPixel(cx + 1, cy - 12); gfx.drawPixel(cx + 8, cy - 7)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 9, cy + 6, 18, 2)
  gfx.fillRect(cx - 8, cy + 8, 3, 6)
  gfx.fillRect(cx + 5, cy + 8, 3, 6)
  gfx.fillRect(cx - 10, cy + 6, 20, 1)
end

function CAFE.art.monstera(cx, cy)
  gfx.setColor(BLACK)
  local leaves = { { -8, -4, 7, 5 }, { 1, -12, 8, 6 }, { 8, -3, 7, 5 }, { -2, -3, 6, 5 } }
  for _, l in ipairs(leaves) do
    gfx.fillEllipseInRect(cx + l[1] - l[3], cy + l[2] - l[4], l[3] * 2, l[4] * 2)
    gfx.setColor(WHITE)
    gfx.drawLine(cx + l[1] - 2, cy + l[2], cx + l[1] + 2, cy + l[2])         -- the leaf's splits
    gfx.drawPixel(cx + l[1], cy + l[2] - 2)
    gfx.setColor(BLACK)
  end
  gfx.drawLine(cx, cy + 5, cx - 6, cy - 2)
  gfx.drawLine(cx, cy + 5, cx + 7, cy - 2)
  pot(cx, cy)
end

-- ---- more floor lamps (they stand on y = cy + 14; every piece is centred on the pair of columns cx-1 / cx) -------
function CAFE.lampBase(cx, B, wide)               -- a flat weighted foot, 2 * wide pixels across
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - wide, B - 2, wide * 2, 3, 1)
end

CAFE.ARC = {}
do                                                -- the sweep of the arc lamp's pole, worked out once
  for i = 0, 8 do
    local a = math.pi - i * (math.pi - 0.55) / 8
    CAFE.ARC[#CAFE.ARC + 1] = { math.floor(2 + 9 * math.cos(a) + 0.5), math.floor(-6 - 9 * math.sin(a) + 0.5) }
  end
end

function CAFE.art.arclamp(cx, cy)               -- a heavy base, a pole that sweeps over, and a dome shade hanging from the tip
  local B = cy + 14
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 13, B - 3, 13, 4, 1)                         -- the marble block it stands on
  gfx.setColor(WHITE); gfx.drawLine(cx - 11, B - 2, cx - 4, B - 2); gfx.setColor(BLACK)
  UI.ink("slate")
  gfx.setLineWidth(2)
  gfx.drawLine(cx - 7, B - 3, cx - 7, cy - 6)                         -- up the pole...
  local A = CAFE.ARC
  for i = 1, #A - 1 do gfx.drawLine(cx + A[i][1], cy + A[i][2], cx + A[i + 1][1], cy + A[i + 1][2]) end   -- ...and over
  gfx.setLineWidth(1)
  local sx, yb = cx + A[#A][1], cy - 4                                 -- the shade hangs right under the tip of the arc
  local rows = CAFE.domeRows(5, 6)
  UI.ink("inkteal")
  for r = 0, 5 do gfx.drawLine(sx - rows[r], yb - r, sx + rows[r], yb - r) end
  UI.ink("brass")
  gfx.fillRect(sx - 6, yb, 13, 2)                                      -- its rim
  gfx.fillRect(sx - 1, A[#A][2] + cy, 3, 2)                             -- the little collar where it joins the arc
  if (math.floor(frames / (24))) % 11 ~= 10 then                                    -- the bulb, and light falling in a fan (with a rare flicker)
    UI.ink("glow")
    gfx.setColor(WHITE); gfx.fillEllipseInRect(sx - 2, yb + 2, 5, 4)
    gfx.setColor(BLACK); gfx.drawEllipseInRect(sx - 2, yb + 2, 5, 4)
    UI.ink("inkyellow")
    for k = -1, 1 do
      for j = 0, 1 do
        local s = (math.floor(frames / (3)) + j * 6) % 12
        gfx.drawPixel(sx + math.floor(k * (1 + s * 0.4) + 0.5), cy + 2 + s)
      end
    end
  end
end

function CAFE.art.torchiere(cx, cy)             -- a glass bowl on a tall slim pole that throws its light up at the ceiling
  local B = cy + 14
  CAFE.lampBase(cx, B, 7)
  gfx.setColor(BLACK)
  UI.ink("brass")
  gfx.fillRect(cx - 1, cy - 7, 2, B - cy + 5)                           -- the pole
  gfx.fillRect(cx - 3, cy - 8, 6, 2)                                    -- where the bowl sits
  gfx.fillRect(cx - 2, cy + 4, 4, 2)                                    -- a collar half way up
  UI.ink("peach")
  gfx.setColor(WHITE)
  gfx.fillPolygon(cx - 8, cy - 13, cx + 7, cy - 13, cx + 5, cy - 10, cx + 2, cy - 7, cx - 3, cy - 7, cx - 6, cy - 10)
  gfx.fillEllipseInRect(cx - 8, cy - 15, 16, 5)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 8, cy - 13, cx - 6, cy - 10); gfx.drawLine(cx - 6, cy - 10, cx - 3, cy - 7); gfx.drawLine(cx - 3, cy - 7, cx + 2, cy - 7)
  gfx.drawLine(cx + 2, cy - 7, cx + 5, cy - 10); gfx.drawLine(cx + 5, cy - 10, cx + 7, cy - 13)
  gfx.drawEllipseInRect(cx - 8, cy - 15, 16, 5)                          -- the rim of the bowl, seen from above
  UI.ink("flame")
  gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 5, cy - 14, 10, 3); gfx.setColor(BLACK)    -- the lit inside
  UI.ink("inkyellow")
  if (math.floor(frames / (20))) % 13 ~= 12 then                                      -- light climbs up the wall (with a rare flicker)
    for j = 0, 1 do
      local s = (math.floor(frames / (3)) + j * 3) % 6
      gfx.drawPixel(cx - 1 - (1 + math.floor(s / (2))), cy - 17 - s)
      gfx.drawPixel(cx + (1 + math.floor(s / (2))), cy - 17 - s)
      if s < 5 then gfx.drawPixel(cx - 1 + (j % 2), cy - 17 - s) end
    end
  end
end

function CAFE.art.tripodlamp(cx, cy)            -- three wooden legs holding up a tapered, pleated shade
  local B = cy + 14
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx - 1, cy + 3, cx - 11, B - 1); gfx.drawLine(cx, cy + 3, cx + 10, B - 1)       -- the two legs you can see splayed out...
  gfx.setLineWidth(1)
  gfx.fillRect(cx - 1, cy + 3, 2, B - cy - 5)                                                   -- ...and the third, coming towards you
  gfx.drawLine(cx - 7, cy + 9, cx + 6, cy + 9)                                                   -- a crossbar tying the legs
  gfx.fillRect(cx - 3, cy + 1, 6, 3)                                                             -- the hub
  gfx.fillRect(cx - 1, cy - 3, 2, 4)
  UI.ink("glow")
  gfx.setColor(WHITE)
  gfx.fillPolygon(cx - 6, cy - 14, cx + 5, cy - 14, cx + 8, cy - 4, cx - 9, cy - 4)
  gfx.setColor(BLACK)
  UI.ink("flame")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 7, cy - 8, 14, 3); gfx.setColor(BLACK)                -- the glow is brightest at the bottom
  UI.ink("tan")
  gfx.drawLine(cx - 6, cy - 14, cx - 9, cy - 4); gfx.drawLine(cx + 5, cy - 14, cx + 8, cy - 4)
  gfx.drawLine(cx - 3, cy - 14, cx - 4, cy - 8); gfx.drawLine(cx + 2, cy - 14, cx + 3, cy - 8)     -- the pleats
  gfx.drawLine(cx - 6, cy - 14, cx + 5, cy - 14); gfx.drawLine(cx - 9, cy - 4, cx + 8, cy - 4)
  gfx.drawLine(cx - 7, cy - 15, cx + 6, cy - 15)
  CAFE.motes(cx - 1, cy - 3, 8, 1, 0.1 * math.pi, 0.9 * math.pi, 6, 5, "inkyellow", 4)        -- the glow spills out of the bottom
end

function CAFE.art.globelamp(cx, cy)             -- a big frosted globe on a slim stem, a bulb glowing inside
  local B = cy + 14
  CAFE.lampBase(cx, B, 6)
  gfx.setColor(BLACK)
  UI.ink("brass")
  gfx.fillRect(cx - 1, cy + 6, 2, B - cy - 8)
  gfx.fillRect(cx - 3, cy + 4, 6, 3)                                    -- the socket it sits in
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 9, cy - 14, 18, 18)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 9, cy - 14, 18, 18)
  local big = (math.floor(frames / (8))) % 2 == 0                                    -- the bulb pulses
  UI.ink("flame")
  if big then gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 3, cy - 10, 6, 6); gfx.setColor(BLACK) end
  gfx.drawEllipseInRect(cx - 3, cy - 10, 6, 6)
  UI.ink("gray")
  gfx.fillRect(cx - 2, cy - 4, 4, 2); gfx.fillRect(cx - 1, cy - 2, 2, 3)   -- the bulb's neck and base
  UI.ink("inkorange")
  gfx.drawLine(cx - 1, cy - 8, cx - 1, cy - 6); gfx.drawLine(cx, cy - 8, cx, cy - 6)     -- the filament
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawLine(cx - 6, cy - 9, cx - 5, cy - 11); gfx.setColor(BLACK)    -- a shine on the glass
  UI.ink("inkyellow")
  local p = (math.floor(frames / (6))) % 4                                           -- a ring of light sparkles round it
  for i = 0, 7 do
    if (i + p) % 4 < 2 then
      local a = i * math.pi / 4
      gfx.drawPixel(cx + math.floor(math.cos(a) * 12 + 0.5), cy - 5 + math.floor(math.sin(a) * 12 + 0.5))
    end
  end
end

function CAFE.art.tiffany(cx, cy, drop)          -- a stained-glass dome on a round vase base: leaded panes and a jewelled rim (drop = a shorter stem, for the table lamp)
  local yb = cy - 2 + (drop or 0)                                                      -- the dome's lower edge
  if CAFE.fastArt() then CAFE.layer("tif", drop or 0, cx - 13, yb - 12, 26, cy + 14 - yb + 13, CAFE.tiffanyA, cx, cy, drop) else CAFE.tiffanyA(cx, cy, drop) end
  UI.ink("white")
  local t = (math.floor(frames / (3))) % 14                                           -- a glint runs across the glass
  gfx.setColor(WHITE); gfx.drawPixel(cx - 7 + t, yb - 6 - math.floor(math.abs(t - 7) / (3))); gfx.setColor(BLACK)
  CAFE.motes(cx - 1, yb + 3, 10, 1, 0.1 * math.pi, 0.9 * math.pi, 5, 4, "inkorange", 2)     -- coloured light falls on the table
end

function CAFE.tiffanyA(cx, cy, drop)                 -- the lamp itself (everything but the glint and the light it throws)
  local B = cy + 14
  local yb = cy - 2 + (drop or 0)                                                      -- the dome's lower edge
  UI.ink("bark")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 7, B - 2, 14, 3, 1)                             -- foot
  gfx.fillEllipseInRect(cx - 6, B - 11, 12, 10)                          -- the round base
  gfx.fillRect(cx - 1, yb + 1, 2, B - 11 - yb)                           -- stem
  gfx.fillRect(cx - 3, yb + 1, 6, 2)
  local out = CAFE.domeRows(12, 11)
  for r = 0, 10 do gfx.drawLine(cx - out[r], yb - r, cx + out[r] - 1, yb - r) end              -- the dome (a black frame)
  local ins = CAFE.domeRows(11, 8)
  gfx.setColor(WHITE)
  for r = 0, 7 do UI.ink((r < 2) and "redp" or ((r < 5) and "jack" or "leaf")); gfx.drawLine(cx - ins[r], yb - 2 - r, cx + ins[r] - 1, yb - 2 - r) end        -- the panes of glass
  gfx.setColor(BLACK)
  local f1, f2 = 0.34, 0.68
  UI.ink("lav")
  for r = 3, 5 do                                                        -- the outer panes are a darker colour
    local y, k1, k2 = yb - 2 - r, math.floor(f1 * ins[r]), math.floor(f2 * ins[r])
    gfx.setPattern(CHECK)
    gfx.fillRect(cx + k1 + 1, y, k2 - k1 - 1, 1); gfx.fillRect(cx - k2, y, k2 - k1 - 1, 1)
  end
  UI.ink("bark")
  gfx.setColor(BLACK)
  for _, f in ipairs({ f1, f2 }) do                                      -- the leading that runs up the dome, curving with it
    local px, py, qx
    for r = 0, 7 do
      local k = math.floor(f * ins[r])
      local x, y = cx + k, yb - 2 - r
      if px then gfx.drawLine(px, py, x, y); gfx.drawLine(qx, py, cx - 1 - k, y) end
      px, py, qx = x, y, cx - 1 - k
    end
  end
  gfx.drawLine(cx - ins[5], yb - 7, cx + ins[5] - 1, yb - 7); gfx.drawLine(cx - ins[2], yb - 4, cx + ins[2] - 1, yb - 4)
  gfx.fillRect(cx - 12, yb - 1, 24, 3)                                   -- the rim, with a row of jewels
  gfx.setColor(WHITE)
  UI.ink("skyp")
  for x = cx - 10, cx + 9, 4 do gfx.drawPixel(x, yb) end
end

function CAFE.art.streetlamp(cx, cy)            -- an old iron lamp post: a glass lantern with a roof, curved brackets and a moth
  local B = cy + 14
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 5, B - 3, 10, 4); gfx.fillRect(cx - 3, B - 7, 6, 4)       -- stepped base
  gfx.fillRect(cx - 1, cy - 8, 2, B - 7 - cy + 8)                             -- the post
  gfx.fillRect(cx - 2, cy + 3, 4, 2); gfx.fillRect(cx - 2, cy - 4, 4, 2)       -- collars
  gfx.drawLine(cx - 2, cy - 3, cx - 6, cy - 8); gfx.drawLine(cx + 1, cy - 3, cx + 5, cy - 8)   -- brackets that hold the lantern up
  gfx.drawLine(cx - 2, cy - 2, cx - 6, cy - 6); gfx.drawLine(cx + 1, cy - 2, cx + 5, cy - 6)
  gfx.fillRect(cx - 6, cy - 9, 12, 2)                                          -- the lantern's floor
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillRect(cx - 5, cy - 17, 10, 8)
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 17, 10, 8)
  gfx.fillRect(cx - 5, cy - 17, 1, 8); gfx.fillRect(cx + 4, cy - 17, 1, 8)
  gfx.fillPolygon(cx - 7, cy - 17, cx + 6, cy - 17, cx, cy - 20, cx - 1, cy - 20)             -- the roof
  gfx.fillRect(cx - 1, cy - 22, 2, 3)
  if (math.floor(frames / (5))) % 7 ~= 3 then                                               -- the light (it flickers now and then)
    UI.ink("flame")
    gfx.fillEllipseInRect(cx - 2, cy - 15, 4, 5)
    gfx.setColor(WHITE); gfx.drawPixel(cx - 1, cy - 14); gfx.setColor(BLACK)
    CAFE.motes(cx - 1, cy - 13, 8, 5, 0, 2 * math.pi, 7, 4, "inkyellow", 3)                    -- the light glimmering round the lantern
  end
  UI.ink("gray")
  local a = frames * 0.2                                                       -- the moth
  local mx, my = cx + math.floor(math.cos(a) * 11), cy - 13 + math.floor(math.sin(a * 1.3) * 5)
  gfx.drawPixel(mx, my); gfx.drawPixel(mx - 1, my - 1 + (math.floor(frames / (2))) % 2); gfx.drawPixel(mx + 1, my - 1 + (math.floor(frames / (2))) % 2)
end

function CAFE.art.paperlamp(cx, cy)             -- a ribbed paper lantern on a little wooden tripod
  local B = cy + 14
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 8, cx - 8, B); gfx.drawLine(cx + 2, cy + 8, cx + 7, B)             -- the legs
  gfx.fillRect(cx - 1, cy + 8, 2, B - cy - 9)
  gfx.fillRect(cx - 9, B - 1, 3, 2); gfx.fillRect(cx + 6, B - 1, 3, 2)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 8, cy - 13, 16, 22)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 8, cy - 13, 16, 22)
  for k = 1, 5 do                                                                              -- paper ribs, curved round the belly
    local y = cy - 13 + math.floor(k * 22 / (6))
    local fy = (y - (cy - 2)) / 11
    local hw = math.floor(8 * math.sqrt(math.max(0, 1 - fy * fy)) + 0.5)
    gfx.drawLine(cx - hw, y, cx - 1, y + 1); gfx.drawLine(cx, y + 1, cx + hw - 1, y)
  end
  UI.ink("bark")
  gfx.fillRect(cx - 3, cy - 14, 6, 3); gfx.fillRect(cx - 3, cy + 7, 6, 3)                      -- the top and bottom rings
  gfx.fillRect(cx - 1, cy - 16, 2, 2)
  if (math.floor(frames / (12))) % 2 == 0 then                                                              -- the lantern breathes with light
    UI.ink("flame")
    gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 4, cy - 6, 8, 10); gfx.setColor(BLACK)
  end
  UI.ink("inkyellow")
  local g = (math.floor(frames / (10))) % 2
  gfx.drawPixel(cx - 11 - g, cy - 4); gfx.drawPixel(cx + 10 + g, cy - 4); gfx.drawPixel(cx - 11, cy + 2 + g); gfx.drawPixel(cx + 10, cy + 2 + g)
end

function CAFE.art.cattree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy - 13, 4, 26)
  gfx.fillRect(cx - 10, cy + 12, 20, 3)
  gfx.fillRect(cx - 10, cy - 14, 20, 3)
  gfx.fillRect(cx - 9, cy - 1, 18, 3)
  gfx.setColor(WHITE)
  for k = -8, 6, 4 do gfx.drawPixel(cx + k, cy - 13) end
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy - 1, cx + 7, cy + 5)            -- a hanging toy
  gfx.fillCircleAtPoint(cx + 7, cy + 6, 2)
end

function CAFE.art.dogbed(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillEllipseInRect(cx - 9, cy + 3, 18, 8)
  gfx.setColor(BLACK)
end

CAFE.SPR = {
  plant = { "...........kk...........", "...........kk...........", "..........kwkk..........", "....k.....kwwk....kk....", "...kwk....kwkk...kwk....", "...kwkk..kwwwkk.kwwk....", "...kwwkk.kwwkwk.kwkk....", "...kwwwk.kwwwkkkwwwk....", "...kwwkwkkwwkwkkwwkk....", "kk..kwwkkkwwwkkwwkwk.kk.", "kwkkkwwwkkwwkwkwwwkkkwk.", "kwwkkwwkwkwwwkkwwkkwwkk.", ".kwwkkwwkkwwkwkwkwkwkk..", ".kwwwkwwwkkwwkkwwkwkwk..", "..kwwwkwkkkwkkkwkkkwk...", "...kwwkwwkkwwkkkkkwk....", "....kkwkwk.kk.kwkkk.....", "......kkkk.kk.kkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  fern = { "........................", "........................", "...........kk...........", "...........kk...........", "...........kk...........", "..........kwwk..........", "..........kwkk..........", "..........kwwk..........", "...kkk....kwkk....kkk...", "....kkkk..kwwk..kkwk....", "....kwkwk.kwkk.kkwkk....", ".....kwkwkkwwkkwwkk.....", ".....kwwkkkwkkkwkwk.....", "......kwwkkwwkwkwk......", "..kkkkkkkwkwkkwwkkkkkk..", ".kwwwwwkkkkkkwkkwwwkwkk.", "kkkkwkkwkkkkkkkkkwkkkkkk", "....kkkkkkkkkkwwkkkk....", "....kkkkkkkkkkkkkkkk....", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  flowers = { "...........kkk..........", "........kkkwwwk.........", "......k.kwwkkkkk........", ".....kwkkwkkkkwwk.k.....", "..kkkwwwkkkkwkwk.kwk....", "..kwwkkkkwwkkwkkkwwwk...", "..kwkkkkkwwkwwkwwkkkkk..", "..kkkkwkwkkkkkkwkkkkwwk.", "..kwwkkwkk..k.kkkkwkwk..", "..kwwkwwk...k.kwwkkwkk..", "...kkkkkk...k.kwwkwwk...", ".......k....k..kkkkkk...", ".....kkkkk..k.kkkkk.....", ".....kwwwwk.kkwwwwk.....", ".....kwwwwk.kkwwwwk.....", "......kwwwwkkwwwwk......", "......kwwwwkkwwwwk......", ".......kkkkkkkkkk.......", ".........k..k..k........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  pumpkin = { "................kk......", "...........kkk.k........", "...........kkk..........", "..........kkkk..........", "......kkkkwwwwkkkk......", ".....kwwkwwwwwwkwkk.....", "...kkwwkwwwwwwwwkwkkk...", "..kwwwkwkwwwwwwkwkwkwk..", "..kwwwkkkkwwwwkkkkkwkk..", ".kwwwwkkkkkwwkkkkkwkwkk.", ".kwwwwkwwwwwwwwwkkkwkwk.", ".kwwwwkwwwwkkwwwwkwkwkk.", ".kwwwwkkkwwwwwwkkkkwkwk.", "..kwwwkkkkkkkkkkkkwkwk..", "..kwwwkwwkkwwkkwkkkwkk..", "...kkwwkwwwwwwwwkkwkk...", ".....kwwkwwwwwwkkwk.....", "......kkkkwwwwkkkk......", "..........kkkk.........." },
  snake = { "...........kk...........", ".......kk..kk...........", ".......kkkkwkk..........", ".......kwkkwwk.kk.......", "..kk..kwkkkwkwkwk.......", "..kkk.kwwkkwwkkwk...kk..", "..kwk.kwwkwwkwkwkk.kwk..", "..kwwkkwwkwwwkkkwk.kwk..", "..kwkkkwwkwwkwkwkkkwkk..", "..kwwkkwwkwwwkkkwkkwwk..", "...kwwkwwkwwkwkwkkwwkk..", "...kwkkkwkwwwkkkwkwkk...", "...kwwkkwwkwkwkwkkwwk...", "...kwwwkwkkwwkkkkwwkk...", "....kwkkwwkwkwkwkwkk....", "....kwwkkwkwwkkkkwwk....", ".....kkkkwkkkkkkkwk.....", ".....kwkkwkkwkwkkkk.....", "......kk.kk.kkk.kk......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  tree0 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kkkwkk.........", "........kwkkkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwwwkwk.......", "......kkwkwkwwkkwk......", ".....kkkkwwwkwkkkkk.....", ".......kwwwkwkwkk.......", ".......kkwkwkwkwk.......", "......kkkkkkwkwkwk......", ".....kkkkkkwkwwwkwk.....", "....kkwkkkwkwwwkkkwk....", "...kkkkkkwkwwwkkkkkkk...", "......kkwkwwwkwkkk......", "......kwkwkkkwkwwwk.....", "....kkwkwkwkwkwkwwwk....", "...kkkkwkwkkkwkwkwkkk...", "..kkwkkkwwwkkkwwwkkkwk..", ".kkkkkkkwkkkkkwwkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  tree1 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kwwwkk.........", "........kwwwkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwkkkwk.......", "......kkwkwkkkwwwk......", ".....kkkkkkwkwwwkkk.....", ".......kwkkkwkwkk.......", ".......kkwkwkwkwk.......", "......kwwkkkwkwkwk......", ".....kkwwkkwkkkwkwk.....", "....kkwkkkwkwkkwwkwk....", "...kkkkkkwkkkwkwwkkkk...", "......kkwkwkkkwkkk......", "......kwkwkkkwkwkkk.....", "....kkwkwkwkwkwkkkwk....", "...kkwwwkwkwwwkwkwwwk...", "..kkwwwkkkwwwkkkwkwwwk..", ".kkkkkkkkkkkkkkkkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  monstera = { "..........kkkk..........", "........kkwwwwkk........", ".......kwwwwwwwwkk......", ".......kwwwkwwwwwk......", "...kkkk.kwwkwwwwkk.kkkk.", ".kkwwwwkkwwkwwwkwkkwwwkk", "kwwwwkwwkwwkwwwwkwwkwwwk", "kwwwkwwwwkwkwwwkkwwwkwwk", ".kwwwwwwwwkkkwkwkwwwwwkk", "..kkwwwwwkkkkkwkkwwwwkk.", "....kkkkkwkkkkkwkkkkkk..", ".......kkkkkkkkkkk......", ".........kk.kk.kk.......", "..........kk.k.kk.......", "...........kkkk.........", "............kk..........", "............kk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  palm = { ".......kkkk......kkkk...", ".....kkwwwwkk..kkwwwwkk.", "...kkwwwwwwwkkkkwwwwwwkk", "..kwwwwkwwwwwkkwwwwkwwwk", ".kwwkkkkkkwwwkwwwkkkkkwk", "kwwk......kkwwkkk.....kk", "kk..........kkk.........", "......kkkk..kwk..kkkk...", "....kkwwwwkkkwkkkwwwwkk.", "...kwwwkwkwwkwkwwkwkwwwk", "..kwkkk.kwwwkkwwwk.kkkwk", ".kk......kkwkkwkk.....kk", "...........kkk..........", "..........kwkkk.........", "..........kwkwk.........", "...........kwk..........", "..........kwkwk.........", "..........kkkwk.........", "...........kkk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  sunflower = { ".........kkkkkk.........", "......kk.kwwwwk.kk......", ".....kwwkkwwwwkkwwk.....", "..kk..kwwkkkwkkwwk..kk..", ".kwwk.kkkkkwkwkkkk.kwwk.", ".kwwwkkkwkkkwkwkkkkwwwk.", "..kwwwkkkkkkkwkwkkwwwk..", "...kkwwkkkwkwkkkwkwwkk..", ".....kkwkkkwkwkkkkwkk...", ".......kkwwkkkkwwkk.....", ".........kkkkkkkk.......", "...........kk...........", "...........kkk..........", "....kkk....kwk....kkk...", "..kkwwwkk..kkk..kkwwwkk.", ".kwwwkwwwkkkwkkkwwwkwwwk", "..kkkkkwwwkkkkkwwwkkkkk.", ".......kkkkkwkkkk.......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  cactus = { "..........kkkk..........", ".........kwwwwk.........", "........kwwwwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", "........kwwkwwwk...kkk..", "..kkk...kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwk..kwwkk.", ".kwwkk..kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwkkkkwwkk.", ".kwwkk..kwwkwwkkwwwwwwk.", ".kwwwkkkkwwkwwwkkkkkkkk.", ".kwwwwwwkwwkwwkk..kkkk..", "..kkkkkwkwwkwwwk........", ".......kkwwkwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", ".........kwwwkk.........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  bonsai = { "........................", ".........kkkkkkkk.......", ".......kkwwwwwwwwkk.....", "......kwwwwkwwwkwwwk....", "..kkkkwwwwkwwwkwwwwwkkk.", ".kwwwwkwwwwwwwwwwwwwwwwk", "kwwwkwwkkkkkkkkkwwwwwwwk", "kwwwwwwwkkwwkkwwwwwwwkwk", ".kkkwwwkkkwwwkkwwwwkkkk.", "....kkkk..kwwk..kkkk....", "..........kwwk..........", "..........kkwk..........", ".........kwwk...........", "........kkwkk...........", "........kwwwkk..........", ".......kkwwkkkk.........", "......kkkkkkkkkkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  daisies = { ".....kkkkk......", ".....kwkkkk.....", "....kkkkkkwk....", ".kkkkwkkkkk.k...", ".kwkkkkkkkkkwk..", ".kkkkkkwkkwkkkk.", "kwkkkkkkkkkkkkwk", ".kkkkwk.kwkkkkk.", "..kwkkk.kkkkkwk.", "...kk...k.kwkkk.", ".....k..k..kk...", ".....k..k..k....", "....kkkkkkkk....", "....kwkwkkkk....", "....kwwwwwkk....", "....kwwwwkwk....", "....kwwwwwkk....", "....kwwwwkwk....", ".....kwwwwk.....", ".....kwwwkk.....", ".....kwwwwk.....", ".....kkkkkk....." },
  tulips = { "......kk.k......", ".....kwwkkk.....", ".....kwwkwk.....", "..kk.kwwwkk.....", ".kwwkwkwkkkk.k..", ".kwwwkkkkkwwkkk.", ".kwwkwk.kkwwkwk.", "..kwwk..kkwwwkk.", "..kkkk..k.kwkk..", "..kwwkk.kkkkkk..", "...kwwk.kkwwk...", "...kkwwkkwwkk...", ".....kkkkkk.....", "......k.k.k.....", ".......kk.......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  succ = { ".......kk.......", ".......kk.......", "......kwkk......", "...kk.kwwk.kk...", "..kwkkkwkkkwkk..", "..kwwkwwwkkwwk..", ".kkwwkwwkwkwkkk.", ".kwkwkwwwkkkkwk.", ".kwkwwkwkkkwkwk.", "..kkwwkwwkwkkk..", "..kwkwkwkkkkkk..", "...kkkwkkkkkk...", ".....kkkkkk.....", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  minicac = { "................", "......kkkk......", "......kwkk......", ".....kwwkkk.....", "...kkkwwkwk.....", "...kkkwwwkk.kk..", "...kkkwwkwk.kk..", "...kwkwwkkk.kk..", "...kkkwwkwkkwk..", ".....kwwwkkkkk..", ".....kwwkwk.....", "......kwkk......", "......kkkk......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  herbs = { "................", "................", "......kkkk......", ".....kwwwkk.....", "....kwwwkwkk....", "....kwwkwkwk....", "....kwwwkwkk....", "..kkkwkkkkwkkk..", ".kwwkkwwkwkwkwk.", ".kwwwkwwwkkkwkk.", ".kwwkkwwkkkwkwk.", ".kwwwkwwwkkwwkk.", "..kkkkkkkkkkkk..", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  clock = { "........................", ".......kkkkkkkkkk.......", "......kwwwwwwwwwwk......", "....kkwwkkkkkkkkwwkk....", "...kwwwkwwwwwwwwkwwwk...", "...kwkkwwwwwkwwwwkkwk...", "..kwwkwwkwwwwwwwkwkwwk..", ".kwwkwwwwwwwwwwwwwwkwwk.", ".kwkwwkwwwwwwwwwwwkwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwkwwwwwwwwwwwwwkkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwwkwkwwwwwwwwwwwkkwwk.", "..kwwkwwwwwwwwwwwwkwwk..", "...kwkkwkwwwwwwwkkkwk...", "...kwwwkwwwwkwwwkwwwk...", "....kkwwkkkkkkkkwwkk....", "......kwwwwwwwwwwk......", ".......kkkkkkkkkk.......", "........................" },
  cuckoo = { "............k...........", "...........kwk..........", "...........kwk..........", "..........kwwwk.........", ".........kwwwwwk........", "........kkwkkkwkk.......", "......kwwwkkkkkwwwk.....", ".....kkwwkkkkkkkwwkk....", "....kwwwwwkkkkkwwwwwk...", "...kwwkwwkwwwwwkwwkwwk..", ".kkkkkkkkkkkkkkkkkkkkkkk", "....kwwwwwkkkkkwwwwwk...", "....kwwwwkwwkwwkwwwwk...", "....kwwwkwwwwwwwkwwwk...", "....kwwkwwwwwwwwwkwwk...", "....kwwkwwwwwwwwwkwwk...", "....kwwkkwwwwwwwkkwwk...", "....kwwkwwwwwwwwwkwwk...", "....kwwkwwwwwwwwwkwwk...", "....kwwwkwwwwwwwkwwwk...", "....kwwwwkwwkwwkwwwwk...", "....kwkwkwkkkkkwkwkwk...", "....kkkkkkkkkkkkkkkkk...", "........................" },
  calendar = { ".....kk........kk.....", ".....kk........kk.....", "kkkkkkkkkkkkkkkkkkkkkk", "kkkkkkkkkkkkkkkkkkkkkk", "kkkkkkwkwkwwkwkwkkkkkk", "kkkkkkkkkkkkkkkkkkkkkk", "kwwwwwwwwwwwwwwwwwwwwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwkkwwkkwwkkwwkkwwkkwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwkkwwkkwwkkwwkkwwkkwk", "kwwwwwwwwwwwwwkkwwwwwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwkkwwkkwwkkwwkkwwkkwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwwwwwwwwwwwwwwwwwwwwk", "kwkkwwkkwwkkwwkkwwkkwk", "kwwwwwwwwwwwwwwwwwwwwk", "kkkkkkkkkkkkkkkkkkkkkk" },
  cattree = { "........................", ".kkkkkkkkkkkkkkkkkkkkk..", ".kwkwkwkwkwkwkwkwkwkwk..", ".kkkkkkkkkkkkkkkkkkkkk..", "..........kkk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "...kkkkkkkkkkkkkkkkk....", "...kwwwwwwwwwwwwwwwk....", "...kkkkkkkkkkkkkkkkk....", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..kkkkkkkkkkkkkkkkkkk...", "..kwwwwwwwwwwwwwwwwwk...", "..kkkkkkkkkkkkkkkkkkk...", "........................" },
  dogbed = { "..............................", "..............................", "..............................", ".......kkkkkkkkkkkkkkkk.......", ".....kkwwwwwwwwwwwwwwwwkk.....", "...kkwwwwkkkkkkkkkkkkwwwwkk...", "..kwwwkkkwkwkwkwkwkwkkkkwwwk..", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kwwwkkwkwkwkwkwkwkwkwkwkwwwk.", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kkwkwkkkwkwkwkwkwkwkkkkkwkwk.", "..kkwkwkwkkkkkkkkkkkkkwkwkwk..", "...kkwkwkwkwkwkwkwkwkwkwkkk...", ".....kkkwkwkwkwkwkwkwkwkk.....", ".......kkkkkkkkkkkkkkkk.......", ".............................." },
}
CAFE.SPRPOT = { plant = 18, fern = 19, flowers = 20, snake = 20, palm = 20, monstera = 18, sunflower = 19, bonsai = 17, cactus = 18, tulips = 15, succ = 13, minicac = 13, herbs = 13, daisies = 12 }

-- ---- pixel-art sprites: drawn once from the text pictures above into images, then just stamped ------
CAFE.SPRIMG = {}

-- ---- the counter machines (drawn once into the counter picture; the mugs and coins are stamped live)
CAFE.SPR.m_register = {
  "...kkkkkkkkkkkkkkk....kkkk.....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkkk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkwk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkkk....",
  "...kkkkkkkkkkkkkkk....kwwwk....",
  "........kkkkk.........kwwwk....",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk.",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkkkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkwkkwwk",
  "kwwwwwwwwwwwwwwwwwwwkkwwwwkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkwkkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkkkkwwk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkkkkkkwwwwwwwwwkkkkkkkkkkk",
  "kkkkkkkkkkkwwkkkkkwwkkkkkkkkkkk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"
}
CAFE.SPR.m_coffee = {
  "..........kkkkkkkkkkkkkkk..........",
  ".......kkkkkkkkkwwwkkkkkkkkk.......",
  ".....kkkwwkkkkkwwwkwkkkkkkwkkk.....",
  "..kkkkkwkkkkkkwwwkkwwkkkkkkwkkkkk..",
  ".kkkkkkkkkkkkkwwwkwwwkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkwwwwwwwkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkkwwwwwkkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkkkwwwkkkkkkkkkkkkkkk.",
  ".kkkkkkkkkwwwwwwwwwwwwwwwkkkkkkkkk.",
  ".kkkwwwkkwkkkkwwkkkwwkkkkwkwwwwwwk.",
  ".kkwwkwwkwkkkkwwkkkwwkkkkwkwkwkkwk.",
  ".kkwwkwwkwkkkkwkkkkkwkkkkwkwwwwwwk.",
  ".kkwwwwwkwkkkwwwwwwwwwkkkwkkkkkkkk.",
  ".kkkwwwkkwkkkwkkkkkkkwwwkwkkkkkkkk.",
  ".kkkkkkkkwkkkwwwwwwwwwkwkwkwwkkwwk.",
  ".kkwkwkwkwkkkkwwwwwwwkwwkwkwwkkwwk.",
  ".kkkkkkkkwkwwwwwwwwwwwwwkwkkkkkkkk.",
  "..kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk..",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkwkwkwkwkwkwkwkwkwkwkwkwkwkwkwkwkk",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk."
}
CAFE.SPR.m_mixer = {
  ".............kkk.............",
  "............kkkkk............",
  ".......kkkkkkkkkkkkkk........",
  ".......kkwwwwwwwwwwwk........",
  "........kkkwwwwwwwwwkkkk.....",
  "........kkwwwwwwwwwwk..k.....",
  "........kwkwkwkwkwkwk..k.....",
  ".........kkwkwkwkwkk...k.....",
  ".........kwwwwwwwwwk...k.....",
  ".........kkwwwkwkwkk...k.....",
  "..........kwkwkwkwk.kkkk.....",
  "..........kkwkwkwkk..........",
  "..........kwkwkwkwk..........",
  "...........kkkkkkk...........",
  "..kkkkkkkkkkkkkkkkkkkkkkkkk..",
  ".kkkkkwwwkkkkkkkkkkkkkkkkkkk.",
  ".kkkkwwkwwkkkwwkkwwkkwwkkkkk.",
  ".kkkkwwkwwkkkwwkkwwkkwwkkkkk.",
  ".kkkkwwwwwkkkkkkkkkkkkkkkkkk.",
  ".kkkkkwwwkkkkkkkkkkkkkkkkkkk.",
  "..k.kkkkkkkkkkkkkkkkkkkkkkk.."
}
CAFE.SPR.m_pickup = {
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  "..................k.....k....",
  ".....................kkk.....",
  ".................k...kkk.k...",
  "..................wkkkkkkkw..",
  "..................kkkkkkkkk..",
  "..................kkwkkkkkk..",
  ".....kkkkkkkkk....kkwkkkkkk..",
  ".kk.kkwwwwwwwkk..kkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkkwwwwwwwwwwwwwwwwwwwwwwwkkk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkk"
}
CAFE.SPR.m_sink = {
  ".........................kkkkk.",
  "..................kkkkkkkkkkk..",
  "..................kkk.....kkk..",
  ".................kkkkk....kkk..",
  "...................k.....kkkkk.",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwkwkwkwwwwwkwkwkwwwwwkwkwkwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwkwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwkwkkwwk",
  "kwkwkwkwwwwwkwkwkwwwwwkwkkkwkwk",
  "kwkwkwkwkwkwkwkwkwkwkwkwkwkkkwk",
  "kkwwwwwwwwwwwwwwwwwwwwwwwwwwwkk",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk."
}
CAFE.SPR.m_jar = {
  ".......kkkkkkk.......",
  ".......kwwwwwk.......",
  ".......kwwkwwk.......",
  "kkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkwwwwwwwwwkkkkkk",
  "kkwkkwkkwkkwkkwkkwkkk",
  "kkwkkwkkwkkwkkwkkwkkk",
  "kkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkkkkkkkkkkkkkkkk",
  "..kkkkkkkkkkkkkkkkk..",
  "..kwwwwwwwwwwwwwwwk..",
  ".kkwwwwwwwkwwwwwwwkk.",
  ".kkwwwwwwkkkkwwkwkkk.",
  ".kkwwwwwkwkwwwwwkwkk.",
  ".kkwwwwwwkkkwwwkwkkk.",
  ".kkwwwwwwwkwkwwwkwkk.",
  ".kkwwwwwkkkkwwwkwkkk.",
  ".kkwwwwwwwkwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkkwwwwwwwwwwwwwkkk.",
  ".kkkkkkkkkkkkkkkkkkk.",
  "..kkkkkkkkkkkkkkkkk.."
}
CAFE.SPR.m_mug = {                                 -- a dirty mug in the sink: solid dark, so you can count them at a glance
  "kkkkkkww",
  "kwkkkkkk",
  "kkkkkkwk",
  "kkkkkkkk",
  "kkkkkkww"
}
CAFE.SPR.m_coin = {
  "wkkkw",
  "kkwkk",
  "wkkkw"
}
CAFE.SPR.saltlamp = {
  "......kkkk......",
  ".....kwwwwk.....",
  "....kwwwwwwk....",
  "...kwwwkwwwwk...",
  "..kwwwwkwwwwwk..",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkkwwwk.",
  ".kwwwkwwwkwkwwk.",
  ".kwwwkwwwkkwkwk.",
  ".kwwwwkwwwkwkwk.",
  ".kwwwwkwwwkkwwk.",
  "..kwwwwkwwwkwk..",
  "..kwwwwwkwwwwk..",
  "...kkwwwwwwkk...",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk.",
  "..kkkkkkkkkkkk.."
}
CAFE.SPR.lavalamp = {
  ".....kk.....",
  "....kwwk....",
  "...kwwwwk...",
  "..kkkkkkkk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  "..kkkkkkkk..",
  "...kkkkkk...",
  "..kkkkkkkk..",
  ".kkkkkkkkkk.",
  "kkkkkkkkkkkk",
  "kkkkkkkkkkkk"
}
CAFE.SPR.neoncup = {
  ".kkkkkkkkkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkwwwwwwwwwwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkkwwwwwwwwkkkwkk",
  "kkwkwwwwwwwwwwwwkwkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkkkkkkkkkkkkkkkkkkk",
  ".kkkkkkkkkkkkkkkkkk."
}

CAFE.SPR.floorlamp = {
  ".....kkkkkk.....",
  "....kwwwwwwk....",
  "...kwwkwwkwwk...",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkwwwwk.",
  ".kwwwwkwwkwwwwk.",
  "kkkkkkkkkkkkkkkk",
  "..kkkkkkkkkkkk..",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  "......kkkk......",
  "....kkkkkkkk....",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk."
}

CAFE.SPR.cp5 = {
  "......kk......",
  "......kk......",
  "...kkkkkkkk...",
  ".kkwwwkkwwwkk.",
  "kwwwwwkkwwwwwk",
  "kwwkkwwwwkkwwk",
  "kwwkkwwwwkkwwk",
  "kwwwwwwwwwwwwk",
  "kwwwkwkwkwkwwk",
  "kwwwwkwkwkwwwk",
  ".kwwwwkkwwwwk.",
  "..kkkkkkkkkk.."
}
CAFE.SPR.cp6 = {
  "......k......",
  ".....kkk.....",
  "...kkkkkkk...",
  "....kkkkk....",
  "....kk.kk....",
  "......k......",
  ".....kkk.....",
  "....kkwkk....",
  ".....kkk.....",
  "....kwkkk....",
  "...kkkkkwk...",
  "....kkkkk....",
  "...kwkkkkk...",
  "..kkkkkwkkk..",
  "...kkkkkkk...",
  "..kkkkwkkwk..",
  ".kkwkkkkkkkk.",
  ".....kkk.....",
  ".....kkk....."
}

function CAFE.spr(key, part)
  local ck = part and (key .. part) or key
  local im = CAFE.SPRIMG[ck]
  if im == nil then
    local rows = CAFE.SPR[key]
    local w, h = #rows[1], #rows
    local y0, y1 = 1, h
    if part and CAFE.SPRPOT[key] then
      if part == "top" then y1 = CAFE.SPRPOT[key] else y0 = CAFE.SPRPOT[key] + 1 end
    end
    im = gfx.image.new(w, y1 - y0 + 1, gfx.kColorClear)
    gfx.pushContext(im)
    for y = y0, y1 do
      local r = rows[y]
      for x = 1, w do
        local c = string.sub(r, x, x)
        if c == "k" then gfx.setColor(BLACK); gfx.drawPixel(x - 1, y - y0)
        elseif c == "w" then gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - y0) end
      end
    end
    gfx.popContext()
    CAFE.SPRIMG[ck] = im
  end
  return im
end

function CAFE.stamp(key, cx, bottom, dx)         -- centred on cx, standing on y = bottom
  local im = CAFE.spr(key)
  local w, h = im:getSize()
  im:draw(cx - math.floor(w / (2)) + (dx or 0), bottom - h + 1)
end

CAFE.SWK = {}
function CAFE.stampSway(key, cx, bottom, sw)     -- the leaves sway, the pot stays put
  local ks = CAFE.SWK[key]
  if not ks then ks = { key .. "top", key .. "bot" }; CAFE.SWK[key] = ks end
  local top = CAFE.SPRIMG[ks[1]] or CAFE.spr(key, "top")
  local bot = CAFE.SPRIMG[ks[2]] or CAFE.spr(key, "bot")
  local w, h = top:getSize()
  local _, h2 = bot:getSize()
  top:draw(cx - math.floor(w / (2)) + sw, bottom - h2 - h + 1)
  bot:draw(cx - math.floor(w / (2)), bottom - h2 + 1)
end

function CAFE.swayOf(speed, cx) return math.floor(math.sin(frames * speed + cx * 0.13) * 1.5 + 0.5) end
CAFE.FL = { plant = true, cactus = true, fern = true, flowers = true, palm = true, snake = true,
            sunflower = true, bonsai = true, monstera = true }
function CAFE.defFloor()
  for id in pairs(CAFE.FL) do
    CAFE.art[id] = function(cx, cy)
      CAFE.stampSway(id, cx, cy + 14, CAFE.swayOf(id == "fern" and 0.06 or 0.05, cx))
    end
  end
end
CAFE.defFloor()
function CAFE.art.tree(cx, cy)
  CAFE.stamp(((math.floor(frames / (20))) % 2 == 0) and "tree0" or "tree1", cx, cy + 15)
  UI.ink("inkgold")
  gfx.setColor(BLACK)                                   -- the star twinkles
  if (math.floor(frames / (10))) % 2 == 0 then
    gfx.drawPixel(cx - 5, cy - 12); gfx.drawPixel(cx + 5, cy - 12); gfx.drawPixel(cx, cy - 17)
  else
    gfx.drawPixel(cx - 6, cy - 13); gfx.drawPixel(cx + 6, cy - 13); gfx.drawPixel(cx - 5, cy - 10); gfx.drawPixel(cx + 5, cy - 10)
  end
end
function CAFE.art.pumpkin(cx, cy)
  CAFE.stamp("pumpkin", cx, cy + 13)
  if (frames + cx) % 90 < 6 then                        -- it blinks
    UI.ink("pumpk")
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 6, cy + 2, 5, 3); gfx.fillRect(cx + 1, cy + 2, 5, 3)
    gfx.setColor(BLACK)
    gfx.drawLine(cx - 6, cy + 3, cx - 2, cy + 3); gfx.drawLine(cx + 1, cy + 3, cx + 5, cy + 3)
  end
end
function CAFE.art.cattree(cx, cy)
  CAFE.stamp("cattree", cx, cy + 15)
  local sw = math.floor(math.sin(frames * 0.1) * 2 + 0.5)       -- the toy swings
  UI.ink("inkred")
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy + 3, cx + 7 + sw, cy + 9)
  gfx.fillCircleAtPoint(cx + 7 + sw, cy + 10, 2)
end
function CAFE.art.dogbed(cx, cy)
  CAFE.stamp("dogbed", cx, cy + 15)
  UI.ink("inkblue")
  gfx.setColor(BLACK)                                    -- little sleepy z's drift up
  for k = 0, 1 do
    local ph = (math.floor(frames / (6)) + k * 4) % 8
    local x, y = cx + 6 + k * 4, cy - 1 - ph
    if ph < 7 then
      gfx.drawLine(x, y, x + 2, y); gfx.drawPixel(x + 1, y + 1); gfx.drawLine(x, y + 2, x + 2, y + 2)
    end
  end
end
function CAFE.defCounter()
  for _, id in ipairs({ "tulips", "succ", "daisies", "minicac", "herbs" }) do
    CAFE.art[id] = function(cx, cy) CAFE.stampSway(id, cx, cy + 10, CAFE.swayOf(0.07, cx)) end
  end
end
CAFE.defCounter()
function CAFE.art.calendar(cx, cy)                -- a month on the wall, today marked (it keeps still)
  CAFE.stamp("calendar", cx, cy + 10)
end

function CAFE.art.clock(cx, cy)
  CAFE.stamp("clock", cx, cy + 12)
  UI.ink("none")
  gfx.setColor(BLACK)
  local t = frames / 30                                  -- (always alive, here and in the shop preview)
  local am = t * 0.3                                     -- the minute hand sweeps round
  local ah = am / 12 + 1
  local sa = math.floor(t * 2) * (math.pi / 6)           -- the second hand ticks: a jump every half second
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 6), math.floor(cy - math.cos(am) * 6))
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 4), math.floor(cy - math.cos(ah) * 4))
  gfx.setLineWidth(1)
  UI.ink("inkred")
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(sa) * 8), math.floor(cy - math.cos(sa) * 8))
  UI.ink("brass")
  gfx.fillCircleAtPoint(cx, cy, 2)
  if math.floor(t * 2) % 2 == 0 then gfx.fillRect(cx - 1, cy + 5, 2, 2) end   -- a tick-tock dot under the middle
end

function CAFE.art.saltlamp(cx, cy)             -- a glowing crystal on a dark base, warm light drifting off it
  CAFE.stamp("saltlamp", cx, cy + 10)
  CAFE.motes(cx, cy - 3, CAFE.narrow and 8 or 12, 14, math.pi, 2 * math.pi, 9, 4, "inkorange", 5)                 -- warm specks of light drifting off the crystal
  UI.ink("inkwhite")
  if (math.floor(frames / (10))) % 2 == 0 then gfx.drawPixel(cx - 4, cy - 8); gfx.drawPixel(cx + 3, cy - 5) else gfx.drawPixel(cx + 4, cy - 9); gfx.drawPixel(cx - 3, cy - 4) end   -- the crystal twinkles
end

function CAFE.art.tiffanytab(cx, cy)             -- the same lamp, a little squatter so it sits on a table
  CAFE.art.tiffany(cx, cy - 3, 4)
end

function CAFE.art.itemstand(cx, cy)               -- a little round-topped stand: a floor spot that holds a table-top piece
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 13, cy + 1, 26, 5, 2)                           -- the top
  gfx.setColor(WHITE); gfx.drawLine(cx - 10, cy + 2, cx + 8, cy + 2); gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 6, 4, 8)                                     -- the stem
  gfx.fillRect(cx - 5, cy + 9, 10, 2)
  gfx.fillRoundRect(cx - 9, cy + 13, 18, 4, 2)                           -- the foot
end

function CAFE.art.lavalamp(cx, cy)             -- blobs of wax drift up and down inside the glass
  CAFE.stamp("lavalamp", cx, cy + 11)
  UI.ink("inkpink")
  gfx.setColor(BLACK)
  gfx.setClipRect(cx - 4, cy - 7, 8, 13)
  local a = frames * 0.045
  gfx.fillCircleAtPoint(cx - 1 + math.floor(math.sin(a * 1.3) * 1.5), cy + 3 - math.floor((math.sin(a) + 1) * 4.5), 3)
  gfx.fillCircleAtPoint(cx + 1, cy + 3 - math.floor((math.sin(a * 0.7 + 2.2) + 1) * 4.5), 2)
  gfx.fillRect(cx - 4, cy + 4, 8, 2)                                    -- the pool at the bottom
  gfx.clearClipRect()
end

function CAFE.motes(x, y, rx, ry, a0, a1, n, len, ink, seed)   -- soft light: specks that leave an oval round (x, y) between angles a0 and a1 (0 = right, pi/2 = down) and drift out len pixels, twinkling as they go
  UI.ink(ink); gfx.setColor(BLACK)
  for i = 0, n - 1 do
    local per = 34 + (i * 7 + seed) % 15
    local p = ((frames + i * 11 + seed * 5) % per) / per
    if p < 0.8 and not (p > 0.5 and (frames + i) % 3 == 0) then
      local a = a0 + (a1 - a0) * ((i + 0.5) / n) + math.sin(i * 2.3 + seed) * 0.12
      local d = p * len
      gfx.drawPixel(x + math.floor(math.cos(a) * (rx + d) + 0.5), y + math.floor(math.sin(a) * (ry + d) + 0.5))
    end
  end
end

function CAFE.art.floorlamp(cx, cy)            -- a pleated shade on a slim pole: its light flickers on and off
  CAFE.stamp("floorlamp", cx, cy + 14)
  local lit = (math.floor(frames / (24))) % 9 ~= 8                                   -- (an occasional flicker)
  if lit then
    CAFE.motes(cx, cy - 5, 9, 1, 0.12 * math.pi, 0.88 * math.pi, 6, 6, "inkyellow", 1)      -- soft light falling from under the shade
  end
  gfx.setColor(BLACK)
end

function CAFE.art.neoncup(cx, cy)              -- a glowing cup sign on a dark plate, with blinking steam
  CAFE.stamp("neoncup", cx, cy + 12)
  UI.ink("nblue")
  gfx.setColor(WHITE)
  for i = 0, 2 do                                                              -- three swirls of steam, each swaying on its own beat
    local x = cx - 4 + i * 3
    local up = ((math.floor(frames / (10)) + i) % 2 == 0)
    local a, b = up and 1 or 0, up and 0 or 1
    gfx.drawPixel(x + a, cy - 1); gfx.drawPixel(x + b, cy - 2); gfx.drawPixel(x + b, cy - 3); gfx.drawPixel(x + a, cy - 4)
    gfx.drawPixel(x + a, cy - 5); gfx.drawPixel(x + b, cy - 6); gfx.drawPixel(x + b, cy - 7)
  end
  gfx.setColor(BLACK)
end

function CAFE.art.cuckoo(cx, cy)
  CAFE.cuckooBody(cx, cy)
  CAFE.cuckooDangle(cx, cy)
end

function CAFE.drawDangles()                    -- the cuckoo's pendulum and weights, drawn last so they hang in front
  local d = CAFE.dec()
  if not d or d.decor.cuckoo ~= "on" or not d.place.cuckoo then return end
  local cx, cy = CAFE.tileCenter(d.place.cuckoo)
  CAFE.cuckooDangle(cx, cy)
  gfx.setColor(BLACK)
end

function CAFE.cuckooBody(cx, cy)
  CAFE.stamp("cuckoo", cx, cy + ((cy > 50) and 9 or 10))     -- (on the lower row it sits a pixel higher, clear of the wall's edge)
  UI.ink("none")
  gfx.setColor(BLACK)
  local t = (G and G.t) or 0
  local am = t * 0.105
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am) * 4), math.floor(cy + 3 - math.cos(am) * 4))
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am / 12 + 1) * 2), math.floor(cy + 3 - math.cos(am / 12 + 1) * 2))
  if t % 30 < 2 then                                  -- the little bird pops out of the door
    UI.ink("yellow")
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 2, cy - 8, 5, 4)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy - 7, 2)
    gfx.fillTriangle(cx + 2, cy - 8, cx + 5, cy - 7, cx + 2, cy - 6)
  end
end

function CAFE.cuckooDangle(cx, cy)
  if cy > 50 then                                                  -- on the lower row there's no room to hang: just a short pendulum swinging under it
    UI.ink("brass"); gfx.setColor(BLACK)
    local sw = math.floor(math.sin(frames * 0.08) * 1.5 + 0.5)
    gfx.drawLine(cx, cy + 4, cx + sw, cy + 6); gfx.drawPixel(cx + sw, cy + 7)
    UI.ink("none"); gfx.setColor(BLACK)
    return
  end
  UI.ink("brass")
  gfx.setColor(BLACK)
  local sw = math.floor(math.sin(frames * 0.08) * 3)
  local s2 = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)                      -- pendulum
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + sw, cy + 19, 3)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx + sw, cy + 19, 3)
  UI.ink("bark")
  gfx.drawLine(cx - 8, cy + 11, cx - 8 + s2, cy + 18)             -- chains with pine-cone weights
  gfx.drawLine(cx + 8, cy + 11, cx + 8 - s2, cy + 16)
  gfx.fillTriangle(cx - 11 + s2, cy + 18, cx - 5 + s2, cy + 18, cx - 8 + s2, cy + 25)
  gfx.fillTriangle(cx + 5 - s2, cy + 16, cx + 11 - s2, cy + 16, cx + 8 - s2, cy + 23)
end

-- draw something that stays the same for the whole shift into a picture once, then just stamp it
-- (only the strip of the screen that holds the thing, y0 .. y0+h, is kept, so stamping it is cheap)
-- draw something once into a picture of just the area it covers (x0, y0, w, h); false if there's no memory for it
function CAFE.snap(drawfn, y0, h, x0, w)
  x0 = x0 or 0
  local ok, img = pcall(function() return gfx.image.new(w or 400, h, gfx.kColorClear) end)
  if ok and img then
    gfx.pushContext(img)
    gfx.setDrawOffset(-x0, -y0)
    drawfn()
    gfx.setDrawOffset(0, 0)
    gfx.popContext()
    return img
  end
  return false
end

function CAFE.cached(key, drawfn, y0, h, x0, w)
  local c = G[key]
  if c == nil then
    G[key] = false
    G[key] = CAFE.snap(drawfn, y0, h, x0, w)
    c = G[key]
  end
  if c then c:draw(x0 or 0, y0) else drawfn() end
end

CAFE.LIVEWALL = { clock = true, cuckoo = true, neoncup = true, neonheart = true, neonbolt = true, neonstar = true, neonmoon = true,
                  neonarrow = true, discoball = true }      -- (these move, so they are drawn every frame)
function CAFE.wallItemsRaw(live)               -- live = the moving ones (clocks), otherwise the still ones
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if (it.kind == "wall" or it.kind == "tiny") and d.decor[it.id] == "on" and d.place[it.id] and CAFE.TILES[d.place[it.id]]
       and ((CAFE.LIVEWALL[it.id] == true) == live) then
      local cx, cy = CAFE.tileCenter(d.place[it.id])
      local fn = (it.id == "cuckoo") and CAFE.cuckooBody or CAFE.art[it.id]     -- (the cuckoo's dangly bits come later)
      if fn then fn(cx, cy) end
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.tinyRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "tiny" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.XSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.counterRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "counter" and d.decor[it.id] == "on" and d.place[it.id] and d.place[it.id] <= #CAFE.CSLOT then
      local sl = CAFE.CSLOT[d.place[it.id]]
      CAFE.counterAt(it.id, d.place[it.id], sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.tableTopRaw()                    -- whatever stands in the middle of a table (drawn live, after the tables)
  local d = CAFE.dec()
  if not d then return end
  local tops = G.tops
  if not tops then
    tops = {}
    for _, it in ipairs(CAFE.ITEMS) do
      local pl = d.place[it.id]
      if it.kind == "counter" and d.decor[it.id] == "on" and pl and pl > 10 and CAFE.topOn(d, pl) then
        tops[#tops + 1] = { CAFE.art[it.id], pl, "t" .. it.id, CAFE.LIVEDIRECT[it.copyOf or it.id], it }
      end
    end
    G.tops = tops
  end
  for i = 1, #tops do
    local tx, ty = CAFE.topXY(tops[i][2])
    if tops[i][4] then tops[i][1](tx, ty)
    else
      local x0, y0, w, h = CAFE.topBox(tops[i][5], tx, ty)
      UI.liveDraw(tops[i][3], x0, y0, w, h, tops[i][1], tx, ty)
    end
  end
  gfx.setColor(BLACK)
end

-- vines hanging off the cup shelf's ends: ten styles, each hung from the left or the right end
CAFE.VINEIDS = { "ivy", "bloomvine", "fernvine", "heartvine", "berryvine", "starvine", "moss", "beadvine", "wisteria", "lanternvine" }
CAFE.VINES = {                                  -- strand lengths (kept short so they stop above the counter)
  ivy        = { 13, 22, 17 },
  bloomvine  = { 19, 13, 22 },
  fernvine   = { 22, 16, 21 },
  heartvine  = { 16, 22, 12 },
  berryvine  = { 20, 14, 22 },
  starvine   = { 14, 22, 18 },
  moss       = { 20, 22, 16, 21 },
  beadvine   = { 18, 22, 14 },
  wisteria   = { 18, 22, 15 },
  lanternvine = { 16, 22, 19 },
}

function CAFE.vineSide(d, id)                  -- 1 = hangs from the left end of the shelf, 2 = the right end
  local s = d.place and d.place[id]
  if s == 1 or s == 2 then return s end
  return (id == "bloomvine") and 2 or 1        -- (saves from before you could choose)
end

function CAFE.vineX(id, side)                  -- x of the first strand
  local n = #CAFE.VINES[id]
  if side == 2 then return 188 - (n - 1) * 4 end
  return 100
end

-- one vine of the given style, first strand at x0, hanging from y0
CAFE.VINESTEM = { beadvine = "bark", lanternvine = "bark", moss = "olive", wisteria = "bark" }      -- (PC colours)
CAFE.VINEPOP = { "rose", "lav", "yellow", "skyp", "orangep" }
function CAFE.vineDraw(id, x0, y0, ph)
  local lens, style = CAFE.VINES[id], id
  if not lens then return end
  local stem = CAFE.VINESTEM[id] or "leafdk"
  for i, len in ipairs(lens) do
    local x = x0 + (i - 1) * 4
    local px, py = x, y0
    local dirn = (i % 2 == 0) and 1 or -1
    gfx.setLineWidth(1)
    for yy = y0 + 2, y0 + len, 3 do
      local xx = x + math.floor(math.sin(ph * 0.3927 + yy * 0.3 + i) * 1.5 + 0.5)
      UI.ink(stem)
      gfx.setColor(BLACK)
      gfx.drawLine(px, py, xx, yy)
      px, py = xx, yy
      local even = (math.floor((yy - y0) / (3))) % 2 == 0
      local nth = math.floor((yy - y0) / (3)) + i
      if style == "ivy" then
        UI.ink("leaf")
        if even then
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx + dirn * 2, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx + dirn * 2, yy, 2)
        end
      elseif style == "bloomvine" then
        if even then
          UI.ink("leaf")
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx + dirn * 2, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx + dirn * 2, yy, 2)
        else
          UI.ink(CAFE.VINEPOP[nth % 3 + 1])
          local fx = xx - dirn * 3
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(fx, yy, 3)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(fx, yy, 3); gfx.fillCircleAtPoint(fx, yy, 1)
          gfx.drawPixel(fx, yy - 4); gfx.drawPixel(fx, yy + 4); gfx.drawPixel(fx - 4, yy); gfx.drawPixel(fx + 4, yy)
        end
      elseif style == "fernvine" then          -- feathery fronds branching off both sides
        UI.ink("inkgreen")
        if even then
          gfx.drawLine(xx, yy, xx - 4, yy + 3); gfx.drawLine(xx, yy, xx + 4, yy + 3)
          gfx.drawLine(xx - 4, yy + 3, xx - 4, yy + 5); gfx.drawLine(xx + 4, yy + 3, xx + 4, yy + 5)
        end
      elseif style == "heartvine" then
        if even then
          UI.ink((nth % 2 == 0) and "redp" or "rose")
          local fx = xx + dirn * 3
          gfx.setColor(WHITE)
          gfx.fillCircleAtPoint(fx - 2, yy - 1, 2); gfx.fillCircleAtPoint(fx + 2, yy - 1, 2)
          gfx.fillPolygon(fx - 4, yy, fx + 4, yy, fx, yy + 5)
          gfx.setColor(BLACK)
          gfx.drawCircleAtPoint(fx - 2, yy - 1, 2); gfx.drawCircleAtPoint(fx + 2, yy - 1, 2)
          gfx.drawLine(fx - 4, yy, fx, yy + 5); gfx.drawLine(fx + 4, yy, fx, yy + 5)
        end
      elseif style == "berryvine" then
        if even then
          UI.ink((nth % 3 == 0) and "inkpurple" or "inkred")
          local fx = xx + dirn * 3
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(fx, yy, 3)
          gfx.setColor(BLACK); gfx.fillCircleAtPoint(fx, yy, 2)
          gfx.setColor(WHITE); gfx.drawPixel(fx - 1, yy - 1)
        else
          UI.ink("inkgreen")
          gfx.setColor(BLACK); gfx.drawLine(xx, yy, xx - dirn * 3, yy - 2)
        end
      elseif style == "starvine" then          -- little sparkles that twinkle
        UI.ink("yellow")
        if even then
          local fx = xx + dirn * 3
          local big = (math.floor(ph / (2)) + i * 3 + math.floor(yy / (3))) % 5 < 3
          local r = big and 3 or 2
          gfx.setColor(BLACK); gfx.setLineWidth(3)
          gfx.drawLine(fx - r, yy, fx + r, yy); gfx.drawLine(fx, yy - r, fx, yy + r)
          gfx.setColor(WHITE); gfx.setLineWidth(1)
          gfx.drawLine(fx - r, yy, fx + r, yy); gfx.drawLine(fx, yy - r, fx, yy + r)
        end
      elseif style == "moss" then              -- wispy strands, a little tuft at every step
        UI.ink(even and "leaf" or "sage")
        gfx.drawLine(xx, yy, xx + 2, yy + 2); gfx.drawLine(xx, yy, xx - 2, yy + 2)
        if even then gfx.drawLine(xx, yy, xx + dirn * 4, yy - 1) end
      elseif style == "beadvine" then
        UI.ink(CAFE.VINEPOP[nth % 5 + 1])
        if even then
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx, yy, 2)
        else
          gfx.setColor(BLACK); gfx.fillCircleAtPoint(xx, yy, 1)
        end
      elseif style == "wisteria" then          -- drooping clusters of blossoms
        UI.ink((nth % 2 == 0) and "lav" or "lilac")
        if even and yy > y0 + 3 then
          gfx.setPattern(CHECK)
          gfx.fillPolygon(xx - 3, yy - 2, xx + 3, yy - 2, xx, yy + 5)
          gfx.setColor(BLACK)
          gfx.drawLine(xx - 3, yy - 2, xx, yy + 5); gfx.drawLine(xx + 3, yy - 2, xx, yy + 5)
          gfx.drawLine(xx - 3, yy - 2, xx + 3, yy - 2)
        end
      elseif style == "lanternvine" then       -- tiny paper lanterns that flicker
        if (math.floor((yy - y0) / (3))) % 3 == 1 then
          UI.ink(({ "redp", "jack", "rose" })[i % 3 + 1])
          gfx.setColor(WHITE); gfx.fillRoundRect(xx - 2, yy - 1, 5, 7, 2)
          gfx.setColor(BLACK); gfx.drawRoundRect(xx - 2, yy - 1, 5, 7, 2)
          UI.ink("flame")
          if (math.floor(ph / (3)) + i) % 3 ~= 0 then gfx.fillRect(xx, yy + 1, 1, 3) else gfx.drawPixel(xx, yy + 2) end
        end
      end
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.setLineWidth(1)
end

function CAFE.drawVines()
  local d = CAFE.dec()
  if not d then return end
  local any = false
  for _, id in ipairs(CAFE.VINEIDS) do if d.decor[id] == "on" then any = true; break end end
  if not any then return end
  local ph = (math.floor(frames / (4))) % 16                -- sixteen sway poses, each drawn once into a picture
  local st = G.vineImgs
  if not st then st = {}; G.vineImgs = st end
  local im = st[ph]
  if im == nil then
    st[ph] = false
    im = CAFE.snap(function() CAFE.vinesRaw(ph) end, 40, 44, 90, 112)
    st[ph] = im
  end
  if im then im:draw(90, 40) else CAFE.vinesRaw(ph) end
end

function CAFE.vinesRaw(ph)
  local d = CAFE.dec()
  for _, id in ipairs(CAFE.VINEIDS) do
    if d.decor[id] == "on" then CAFE.vineDraw(id, CAFE.vineX(id, CAFE.vineSide(d, id)), 43, ph) end
  end
end

function CAFE.vineSidesFree(d, id)             -- the shelf ends nobody else is hanging from
  local free = {}
  for side = 1, 2 do
    local taken = false
    for _, o in ipairs(CAFE.VINEIDS) do
      if o ~= id and d.decor[o] == "on" and CAFE.vineSide(d, o) == side then taken = true end
    end
    if not taken then free[#free + 1] = side end
  end
  return free
end

function CAFE.fixVines(d)                      -- old/odd saves: every vine that's out has its own end of the shelf
  local used = {}
  for _, id in ipairs(CAFE.VINEIDS) do
    if d.decor[id] == "on" then
      local side = CAFE.vineSide(d, id)
      if used[side] then side = (side == 1) and 2 or 1 end
      if used[side] then d.decor[id] = "off"; d.place[id] = nil
      else used[side] = true; d.place[id] = side end
    end
  end
end

for _, id in ipairs(CAFE.VINEIDS) do           -- the picture used on the "where should it go" screen
  CAFE.art[id] = function(cx, cy) CAFE.vineDraw(id, cx - math.floor(4 * (#CAFE.VINES[id] - 1) / (2)), cy - 16, 0) end
end

CAFE.ANIM = { arclamp = true, torchiere = true, tripodlamp = true, globelamp = true, tiffany = true, streetlamp = true, paperlamp = true, plant = true, fern = true, tree = true, palm = true, cactus = true, flowers = true, snake = true,
              sunflower = true, bonsai = true, monstera = true, pumpkin = true, cattree = true, dogbed = true, floorlamp = true, jukebox = true }      -- floor pieces that sway / blink
function CAFE.drawFloorItems(live)             -- live = just the moving ones (the rest are in the floor picture)
  local d = CAFE.dec()
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] and ((CAFE.ANIM[it.id] == true) == (live == true)) then
      local sl = CAFE.FSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.shuffle(t)
  for i = #t, 2, -1 do local j = math.random(i); t[i], t[j] = t[j], t[i] end
  return t
end

-- the rest of a random room: one of each kind now and then (every kind of decor but the music: rugs of all three
-- kinds, tablecloths, the window, wallpaper, flooring, seating, the barista's hat and glasses), and pets
CAFE.ROOMKINDS = { rug = 0.5, runner = 0.5, orug = 0.5, cloth = 0.5, frame = 0.5, curtain = 0.6, wallpaper = 0.65, flooring = 0.65,
                   seating = 0.6, hat = 0.4, glasses = 0.3 }
function CAFE.roomExtras(d)
  for kind, chance in pairs(CAFE.ROOMKINDS) do
    if math.random() < chance then
      local ids = {}
      for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind then ids[#ids + 1] = it.id end end
      if #ids > 0 then d.decor[ids[math.random(#ids)]] = "on" end
    end
  end
  local free = {}                                 -- floor spots nothing stands on yet (for a pet's bed or tree)
  for k = 1, 8 do free[k] = true end
  for id, sl in pairs(d.place) do local it = CAFE.byId[id]; if it and it.kind == "floor" then free[sl] = nil end end
  local species = CAFE.shuffle({ "cat", "dog", "turtle", "bunny" })
  for i = 1, math.random(0, 2) do                 -- no pet, one, or two of different kinds
    local sp, ids = species[i], {}
    for _, it in ipairs(CAFE.ITEMS) do if it.species == sp then ids[#ids + 1] = it.id end end
    if #ids > 0 then
      d.decor[ids[math.random(#ids)]] = "on"
      local home = (sp == "cat") and "cattree" or ((sp == "dog") and "dogbed" or nil)
      if home and math.random() < 0.5 then
        for k = 1, 8 do if free[k] then d.decor[home] = "on"; d.place[home] = k; free[k] = nil; break end end
      end
    end
  end
end

-- Rush Hour and Evening Chill: a different little cafe every time (3 or more tables, some decor)
function CAFE.randomRoom(mode)
  local d = { decor = {}, place = {}, tables = {}, off = {}, sign = true, cups = 5, stars = 0, name = "" }
  local n = (mode == "chill") and 3 or (3 + math.random(0, 1))
  local pool = {}
  for i, f in ipairs(CAFE.TFREE) do pool[i] = f end
  CAFE.shuffle(pool)
  for k = 1, n do d.tables[k] = pool[k] end
  d.seatStep = n
  local function fill(kind, slots, lo, hi)
    local ids = {}
    for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind and not it.needs and not it.copyOf then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    for i = 1, math.min(math.random(lo, hi), #ids, #slots) do
      d.decor[ids[i]] = "on"; d.place[ids[i]] = slots[i]
    end
  end
  do                                            -- wall decor: clocks and pictures on any of the free tiles
    local ids, slots = {}, { 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 }
    for _, it in ipairs(CAFE.ITEMS) do if (it.kind == "wall" or it.kind == "tiny") and not it.needs then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    local put = 0
    for _, id in ipairs(ids) do
      if put >= math.random(3, 6) then break end
      for si, sl in ipairs(slots) do
        if sl ~= false then
          d.decor[id] = "on"; d.place[id] = sl; slots[si] = false; put = put + 1
          break
        end
      end
    end
  end
  do
    local cs = { 1, 2, 3, 4, 5 }
    for k = 1, 5 do if CAFE.tableOn(d, k) then cs[#cs + 1] = 10 + k end end
    fill("counter", cs, 2, 5)
  end
  fill("floor", { 1, 2, 3, 4, 5, 6, 7, 8 }, 2, 4)
  CAFE.roomExtras(d)
  for side = 1, 2 do                            -- a vine from each end of the shelf now and then (any style)
    if math.random() < 0.4 then
      local id
      repeat id = CAFE.VINEIDS[math.random(#CAFE.VINEIDS)] until d.decor[id] ~= "on"
      d.decor[id] = "on"
      d.place[id] = side
    end
  end
  if math.random() < 0.5 then d.decor[CAFE.LIGHTIDS[math.random(#CAFE.LIGHTIDS)]] = "on" end
  return d
end

function CAFE.decorOn(id)
  local d = CAFE.dec()
  return d ~= nil and d.decor[id] == "on"
end

function CAFE.dec() return G ~= nil and (G.cafe or G.deco) or nil end      -- the decor being shown (a cafe save, or a random room)

-- ---- string lights: six styles, one on the wall at a time -------------------------------------------------
CAFE.LIGHTIDS = { "lights", "fairylights", "globelights", "lanternlights", "heartlights", "starlights" }
CAFE.LSTY = { lights = { 2, 24, 20 }, fairylights = { 3, 12, 10 }, globelights = { 2, 30, 20 },     -- { blink phases, frames per phase, pixels between bulbs }
              lanternlights = { 2, 36, 20 }, heartlights = { 2, 22, 20 }, starlights = { 2, 18, 20 } }

function CAFE.lightLit(id, i, phase)             -- is bulb number i glowing in this phase?
  if id == "fairylights" then return (i + phase) % 3 == 0 end
  return (i + phase) % 2 == 0
end

function CAFE.lightPaint(lit, card)              -- the colour a bulb is filled with: white when glowing on the dark wall (black on the white shop card); dim ones are the opposite
  if UI.color then gfx.setColor(lit and WHITE or BLACK); return end     -- (in colour: lit bulbs are the bright shade of their colour, dim ones the dark shade)
  if lit then gfx.setColor(card and BLACK or WHITE)
  elseif card then gfx.setColor(WHITE)
  else gfx.setColor(BLACK) end
end
function CAFE.lightRim(lit, card)               -- the outline round a bulb: a dim one on the dark wall is edged in white so it never disappears
  gfx.setColor((not lit and not card) and WHITE or BLACK)
end

CAFE.STARP = {}
function CAFE.starAt(x, y, r, outline)           -- a five-pointed star (outer radius r), as a filled polygon (or just its edge)
  local u = CAFE.STARP[r]
  if not u then
    u = {}
    for k = 0, 9 do
      local a = -math.pi / 2 + k * math.pi / 5
      local rr = (k % 2 == 0) and r or r * 0.45
      u[#u + 1] = math.floor(math.cos(a) * rr + 0.5 + 100) - 100
      u[#u + 1] = math.floor(math.sin(a) * rr + 0.5 + 100) - 100
    end
    CAFE.STARP[r] = u
  end
  if outline then
    for k = 1, 20, 2 do
      local n = (k + 2 > 20) and 1 or (k + 2)
      gfx.drawLine(x + u[k], y + u[k + 1], x + u[n], y + u[n + 1])
    end
    return
  end
  local pts = {}
  for k = 1, 20, 2 do pts[k] = x + u[k]; pts[k + 1] = y + u[k + 1] end
  gfx.fillPolygon(table.unpack(pts))
end

-- the colours the bulbs take in turn along the string (PC version)
CAFE.BULBCOL = { lights = { "redp", "yellow", "skyp", "leaf", "orangep", "rose" }, fairylights = { "gold2", "glow", "gold2", "snow" },
                 globelights = { "gold2", "glow" }, lanternlights = { "redp", "jack", "rose", "skyp", "lav", "leaf" },
                 heartlights = { "rose", "redp", "lav" }, starlights = { "yellow", "snow", "gold2" } }
-- one bulb hanging from the wire at (x, wy). k = how big (1 on the wall, bigger on the shop card); card = drawn black-on-white
CAFE.HEARTFILL = { ".kk...kk.", "kkkk.kkkk", "kkkkkkkkk", "kkkkkkkkk", ".kkkkkkk.", "..kkkkk..", "...kkk...", "....k...." }
CAFE.HEARTRIM = { "..kk...kk..", ".kkkk.kkkk.", "kkkkkkkkkkk", "kkkkkkkkkkk", "kkkkkkkkkkk", ".kkkkkkkkk.", "..kkkkkkk..", "...kkkkk...", "....kkk....", ".....k....." }
function CAFE.runPic(rows, x, y, sc)             -- a text picture's "k" dots in the current colour (sc = how big each dot is)
  for j = 1, #rows do
    local r = rows[j]
    local i = 1
    while i <= #r do
      if string.sub(r, i, i) == "k" then
        local n = 1
        while string.sub(r, i + n, i + n) == "k" do n = n + 1 end
        gfx.fillRect(x + (i - 1) * sc, y + (j - 1) * sc, n * sc, sc)
        i = i + n
      else i = i + 1 end
    end
  end
end
function CAFE.lightBulb(id, x, wy, lit, k, card)
  local function K(v) return math.floor(v * k + 0.5) end
  local ink = card and BLACK or WHITE
  local cols = CAFE.BULBCOL[id] or CAFE.BULBCOL.lights
  UI.ink(cols[math.floor(x / (math.floor(CAFE.LSTY[id or "lights"][3] * k + 0.5))) % #cols + 1])
  if UI.color then ink = WHITE end
  if id == "fairylights" then                      -- tiny pinpricks that twinkle in turn
    local y = wy + K(2)
    gfx.setColor(card and BLACK or WHITE)
    if lit then
      local a = K(2)
      if card then
        gfx.fillCircleAtPoint(x, y, K(1)); gfx.drawLine(x - a - 1, y, x + a + 1, y); gfx.drawLine(x, y - a - 1, x, y + a + 1)
      else
        gfx.drawPixel(x, y); gfx.drawPixel(x - 1, y); gfx.drawPixel(x + 1, y); gfx.drawPixel(x, y - 1); gfx.drawPixel(x, y + 1)
        gfx.drawPixel(x - 2, y); gfx.drawPixel(x + 2, y); gfx.drawPixel(x, y - 2); gfx.drawPixel(x, y + 2)
      end
    else
      if card then gfx.fillCircleAtPoint(x, y, K(1)) else gfx.drawPixel(x, y) end
    end
  elseif id == "globelights" then                  -- big round bulbs screwed into little sockets: lit ones glow, dim ones show their filament
    local cy, r = wy + K(7), K(4)
    UI.inkPush("gray")
    gfx.setColor(ink); gfx.fillRect(x - K(1), wy + K(1), K(2) + 1, K(2))
    gfx.setColor(BLACK); gfx.drawRect(x - K(1), wy + K(1), K(2) + 1, K(2))
    UI.inkPop()
    CAFE.lightRim(lit, card); gfx.fillCircleAtPoint(x, cy, r + 1)
    CAFE.lightPaint(lit, card); gfx.fillCircleAtPoint(x, cy, r)
    if lit then                                    -- a glass shine and a halo
      gfx.setColor(card and WHITE or BLACK)
      gfx.drawLine(x - r + 2, cy - 1, x - r + 3, cy - 2)
      gfx.setColor(ink)
      gfx.drawPixel(x - r - 3, cy); gfx.drawPixel(x + r + 3, cy); gfx.drawPixel(x, cy - r - 3)
      if k >= 1.5 then gfx.drawPixel(x - r - 2, cy - r - 1); gfx.drawPixel(x + r + 2, cy - r - 1) end
    else                                           -- the cold filament: a little loop on two posts
      gfx.setColor(card and BLACK or WHITE)
      local h = K(2)
      gfx.drawLine(x - 1, cy + h, x - 1, cy - 1); gfx.drawLine(x + 1, cy + h, x + 1, cy - 1); gfx.drawLine(x - 1, cy - 1, x + 1, cy - 1)
    end
  elseif id == "lanternlights" then                -- little paper lanterns with ribs and a tassel
    local w, h, y0 = K(8), K(8), wy + K(2)
    gfx.setColor(ink); gfx.drawLine(x, wy, x, y0)
    CAFE.lightRim(lit, card); gfx.fillRoundRect(x - math.floor(w / (2)) - 1, y0 - 1, w + 2, h + 2, K(3))
    CAFE.lightPaint(lit, card)
    gfx.fillRoundRect(x - math.floor(w / (2)), y0, w, h, K(3))
    gfx.setColor((lit or card) and BLACK or WHITE)
    gfx.drawLine(x - math.floor(w / (2)) + 1, y0 + math.floor(h / (3)), x + math.floor(w / (2)) - 1, y0 + math.floor(h / (3)))         -- the ribs
    gfx.drawLine(x - math.floor(w / (2)) + 1, y0 + math.floor(2 * h / (3)), x + math.floor(w / (2)) - 1, y0 + math.floor(2 * h / (3)))
    gfx.setColor(ink); gfx.drawLine(x, y0 + h, x, y0 + h + K(2))                   -- the tassel
  elseif id == "heartlights" then                  -- hearts
    local sc = math.max(1, K(1))                   -- (drawn from a pixel picture: an even, clean heart at any size)
    local x0, y0 = x - math.floor(9 * sc / 2), wy + K(2)
    CAFE.lightRim(lit, card); CAFE.runPic(CAFE.HEARTRIM, x0 - sc, y0 - sc, sc)        -- (the outline: the same heart a pixel bigger all round)
    CAFE.lightPaint(lit, card); CAFE.runPic(CAFE.HEARTFILL, x0, y0, sc)
  elseif id == "starlights" then                   -- stars: bright ones and little dim ones
    local r = K(5)
    local cy = wy + K(6)
    if lit then
      CAFE.lightRim(lit, card); CAFE.starAt(x, cy, r + 1)
      CAFE.lightPaint(lit, card); CAFE.starAt(x, cy, r)
    elseif card then                               -- a dim star on the shop card: a white star with a plain thick black edge (a hollow star)
      gfx.setColor(WHITE); CAFE.starAt(x, cy, r + 1)
      gfx.setColor(BLACK); gfx.setLineWidth(2); CAFE.starAt(x, cy, r, true); gfx.setLineWidth(1)
    else                                           -- a dim star on the dark wall: just its white outline (never invisible)
      gfx.setColor(BLACK); CAFE.starAt(x, cy, r + 1)
      gfx.setColor(WHITE); CAFE.starAt(x, cy, r)
      gfx.setColor(BLACK); CAFE.starAt(x, cy, r - 2)             -- (a white star with a smaller dark star cut out of it: a clean hollow star)
    end
    if lit then                                    -- a glint
      gfx.setColor(card and BLACK or WHITE)
      gfx.drawLine(x, cy - r - 2, x, cy - r - 1 - K(1)); gfx.drawLine(x - r - 2, cy, x - r - 1 - K(1), cy); gfx.drawLine(x + r + 2, cy, x + r + 1 + K(1), cy)
    end
  else                                             -- plain round bulbs
    local r = K(lit and 3 or 2)
    if lit then gfx.setColor(card and BLACK or WHITE) else gfx.setColor(WHITE) end
    gfx.fillCircleAtPoint(x, wy + K(3), r)
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, wy + K(3), r)
  end
  gfx.setColor(BLACK)
end

-- the string is drawn once into a picture (one for each blink phase) and just stamped on
function CAFE.lightsRaw(id, phase)
  local gap = CAFE.LSTY[id][3]
  local prev
  UI.ink("leafdk")
  gfx.setColor(WHITE)
  for x = 0, 400, 4 do
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    if prev then gfx.drawLine(prev[1], prev[2], x, y) end
    prev = { x, y }
  end
  for i = 0, math.floor(400 / (gap)) do
    local x = i * gap + math.floor(gap / (2))
    local wy = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    CAFE.lightBulb(id, x, wy, CAFE.lightLit(id, i, phase), 1, false)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.lightsId()                         -- which string is up (if any)
  for i = 1, #CAFE.LIGHTIDS do
    if CAFE.decorOn(CAFE.LIGHTIDS[i]) then return CAFE.LIGHTIDS[i] end
  end
  return nil
end

function CAFE.drawLights()
  local id = CAFE.lightsId()
  if not id then return end
  local st = CAFE.LSTY[id]
  local phase = (math.floor(frames / (st[2]))) % st[1]
  CAFE.limg = CAFE.limg or {}
  local key = id .. phase
  if CAFE.limg[key] == nil then
    local ok, img = pcall(function() return gfx.image.new(400, 28, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      gfx.setDrawOffset(0, -14)
      CAFE.lightsRaw(id, phase)
      gfx.setDrawOffset(0, 0)
      gfx.popContext()
      CAFE.limg[key] = img
    else
      CAFE.limg[key] = false
    end
  end
  local im = CAFE.limg[key]
  if im then im:draw(0, 14) else CAFE.lightsRaw(id, phase) end
  gfx.setColor(BLACK)
end

CAFE.RUGCOL = { rug = "rrose", rug2 = "skyp", rug3 = "rred", rug4 = "rlav", rug5 = "rpeach", rug6 = "rsage", rug7 = "rsand",
                rug8 = "rteal", rug9 = "rsun", rug10 = "rapricot", rug11 = "rlav", rug12 = "rcarpet",
                run1 = "rcarpet", run2 = "rteal", run3 = "gingham", run4 = "rpeach", run5 = "rsand", run6 = "rrose", run7 = "rapricot", run8 = "rsage",
                run9 = "rrose", run10 = "rpeach", run11 = "skyp", run12 = "rsun",
                orug1 = "rsage", orug2 = "skyp", orug3 = "rlav", orug4 = "rteal", orug5 = "rsun", orug6 = "rsand",
                orug7 = "rrose", orug8 = "rpeach", orug9 = "rsage", orug10 = "rlav", orug11 = "rapricot", orug12 = "rcarpet",
                rug13 = "rfloral", rug14 = "rmatcha", orug13 = "rfloral", orug14 = "rmatcha", run13 = "rfloral", run14 = "rmatcha",
                rug15 = "r_argyle", orug15 = "r_argyle", run15 = "r_argyle", rug16 = "r_scallop", orug16 = "r_scallop", run16 = "r_scallop", rug17 = "r_hearts", orug17 = "r_hearts", run17 = "r_hearts", rug18 = "r_waves", orug18 = "r_waves", run18 = "r_waves", rug19 = "r_quatre", orug19 = "r_quatre", run19 = "r_quatre", rug20 = "r_daisy", orug20 = "r_daisy", run20 = "r_daisy" }     -- (PC colours: soft, so the big pieces never shout)
-- Every pattern comes on every kind of rug (the runner by the register, the oval under the tables and the big rug in the middle):
-- cozy, stripes, checker, polka dots, lattice, plaid, coffee beans, ripples, sunburst, diamonds, zigzag and royal.
CAFE.RUGPAT = { rug = "cozy", rug2 = "stripe", rug3 = "check", rug4 = "polka", rug5 = "lattice", rug6 = "plaid", rug7 = "bean",
                rug8 = "ripple", rug9 = "sun", rug10 = "diamond", rug11 = "zigzag", rug12 = "royal",
                orug1 = "cozy", orug2 = "ripple", orug3 = "check", orug4 = "polka", orug5 = "sun", orug6 = "bean",
                orug7 = "stripe", orug8 = "lattice", orug9 = "plaid", orug10 = "diamond", orug11 = "zigzag", orug12 = "royal",
                run1 = "royal", run2 = "stripe", run3 = "check", run4 = "diamond", run5 = "bean", run6 = "polka", run7 = "zigzag", run8 = "plaid",
                run9 = "cozy", run10 = "lattice", run11 = "ripple", run12 = "sun",
                rug13 = "floral", rug14 = "matcha", orug13 = "floral", orug14 = "matcha", run13 = "floral", run14 = "matcha",
                rug15 = "argyle", orug15 = "argyle", run15 = "argyle", rug16 = "scallop", orug16 = "scallop", run16 = "scallop", rug17 = "hearts", orug17 = "hearts", run17 = "hearts", rug18 = "waves", orug18 = "waves", run18 = "waves", rug19 = "quatre", orug19 = "quatre", run19 = "quatre", rug20 = "daisy", orug20 = "daisy", run20 = "daisy" }
-- the floral and matcha rugs: little pastel flowers, or green tea leaves, scattered in rows (big rugs get bigger ones)
CAFE.FLCOL = { "fl_pink", "fl_lilac", "fl_yellow", "fl_blue" }
-- where the motifs of a pattern go, laid out round the middle of an area so the pattern mirrors left to right:
-- every row is centred (a row half a step over has a motif either side of the middle instead of on it), and the rows
-- are centred top to bottom. fn(x, y, side, col, row): side -1 left of the middle, 0 on it, 1 right of it; col counts
-- out from the middle (0, 1, 2 ...), row from the top (0, 1, ...)
function CAFE.symGrid(x0, y0, w, h, sx, sy, px, py, stagger, fn)
  local cx, cy = x0 + math.floor((w - 1) / 2), y0 + math.floor((h - 1) / 2)
  local hx = math.floor((w - 1) / 2) - px                 -- how far either side of the middle a motif may sit
  local n = math.floor((h - 1 - 2 * py) / sy) + 1          -- how many rows fit
  if hx < 0 or n < 1 then return end
  for i = 0, n - 1 do
    local yy = cy + math.floor((i - (n - 1) / 2) * sy + 0.5)
    local half = stagger and (((n % 2 == 1) and ((i - (n - 1) / 2) % 2 ~= 0)) or ((n % 2 == 0) and (i % 2 == 1)))
    if half then
      local j, d = 0, math.floor(sx / 2)
      while d <= hx do fn(cx - d, yy, -1, j, i); fn(cx + d, yy, 1, j, i); j = j + 1; d = d + sx end
    else
      fn(cx, yy, 0, 0, i)
      local j, d = 1, sx
      while d <= hx do fn(cx - d, yy, -1, j, i); fn(cx + d, yy, 1, j, i); j = j + 1; d = d + sx end
    end
  end
end

-- the floral and matcha patterns: little flowers / tea sprigs, laid out round the middle so they mirror
-- (a sprig leans out from the middle on each side; the one on the middle stands straight up)
CAFE.UPLEAF = { { 0, -2 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { -1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 }, { 0, 2 } }
function CAFE.motifFill(pat, x0, y0, w, h, inside, big)
  UI.inkPush("none")
  local sx, sy = big and 14 or 7, big and 12 or 6
  local pad = big and 4 or 2
  CAFE.symGrid(x0, y0, w, h, sx, sy, pad, pad, true, function(xx, yy, side, col, row)
    if inside and not inside(xx, yy, big and 3 or 1) then return end
    local k = (col + row) % 4 + 1                          -- (colours step out from the middle, the same both sides)
    if pat == "floral" then
      if big then
        UI.ink("fl_leaf"); gfx.setColor(BLACK)                                -- two little leaves under each flower
        gfx.drawPixel(xx - 2, yy + 3); gfx.drawPixel(xx - 3, yy + 2); gfx.drawPixel(xx + 2, yy + 3); gfx.drawPixel(xx + 3, yy + 2)
        UI.ink(CAFE.FLCOL[k]); gfx.setColor(BLACK)
        gfx.fillRect(xx - 1, yy - 1, 3, 3); gfx.drawPixel(xx, yy - 2); gfx.drawPixel(xx, yy + 2); gfx.drawPixel(xx - 2, yy); gfx.drawPixel(xx + 2, yy)
        UI.ink("none"); gfx.setColor(WHITE); gfx.drawPixel(xx, yy)
      else
        UI.ink(CAFE.FLCOL[k]); gfx.setColor(BLACK)
        gfx.drawPixel(xx, yy - 1); gfx.drawPixel(xx - 1, yy); gfx.drawPixel(xx + 1, yy); gfx.drawPixel(xx, yy + 1)
      end
    else
      UI.ink((k % 2 == 0) and "fl_leaf" or "fl_leafdk"); gfx.setColor(BLACK)
      local fl = (side < 0) and -1 or 1                                       -- (each side leans away from the middle)
      if big then
        if side == 0 then for _, q in ipairs(CAFE.UPLEAF) do gfx.drawPixel(xx + q[1], yy + q[2]) end
        else for _, q in ipairs(CAFE.SPRIG) do gfx.drawPixel(xx + fl * q[1], yy + q[2]) end end
      else
        if side == 0 then gfx.drawPixel(xx, yy - 1); gfx.drawPixel(xx, yy); gfx.drawPixel(xx, yy + 1)
        else gfx.drawPixel(xx, yy); gfx.drawPixel(xx + fl, yy - 1); gfx.drawPixel(xx - fl, yy + 1) end
      end
    end
  end)
  UI.inkPop()
  gfx.setColor(BLACK)
end
CAFE.SPRIG = { { 0, -2 }, { 1, -2 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { 2, -1 }, { -2, 0 }, { -1, 0 }, { 0, 0 }, { 1, 0 }, { -2, 1 }, { -1, 1 }, { -2, 2 } }   -- a little leaf on its stem
function CAFE.wallFill(id, x0, y0, w, h)          -- the back wall in its wallpaper (id nil: the classic checker)
  local wd = id and CAFE.WPDATA[id]
  if not wd then
    gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(x0, y0, w, h); gfx.setColor(BLACK)
    return
  end
  local pat = wd.pat
  local x1, y1 = x0 + w - 1, y0 + h - 1
  UI.ink("wp_" .. pat)
  gfx.setClipRect(x0, y0, w, h)
  local dark = UI.color and (pat == "royal" or pat == "stars" or pat == "espresso")     -- (Playdate: these stay light, so the shelf and the wall's edge still show)
  local fg = dark and WHITE or BLACK
  gfx.setColor(dark and BLACK or WHITE); gfx.fillRect(x0, y0, w, h)
  gfx.setColor(BLACK)
  if CAFE.NEWPAT[pat] then                        -- (the pattern engine's: round the middle of the wall, so it mirrors)
    CAFE.patTiles(pat, x0, y0, w, h, w >= 100, not UI.color and pat == "argyle")
  elseif pat == "plaster" then                        -- a faint speckle
    for y = y0 + 2, y1, 6 do for x = x0 + ((y - y0) % 12 == 2 and 1 or 4), x1, 6 do gfx.drawPixel(x, y) end end
  elseif pat == "stripe" then
    for x = x0 + 2, x1, 5 do gfx.drawLine(x, y0, x, y1) end
  elseif pat == "check" then
    gfx.setPattern({ 0xF0, 0xF0, 0xF0, 0xF0, 0x0F, 0x0F, 0x0F, 0x0F }); gfx.fillRect(x0, y0, w, h); gfx.setColor(BLACK)
  elseif pat == "polka" then
    local row = 0
    for y = y0 + 3, y1, 7 do
      for x = x0 + 3 + (row % 2) * 4, x1, 8 do gfx.fillRect(x - 1, y, 3, 1); gfx.fillRect(x, y - 1, 1, 3) end
      row = row + 1
    end
  elseif pat == "lattice" then
    for x = x0 - h, x1, 10 do gfx.drawLine(x, y0, x + h, y1); gfx.drawLine(x + h, y0, x, y1) end
  elseif pat == "plaid" then
    if UI.color then                              -- (Playdate: just the lines, it's busy enough)
      gfx.setPattern(CHECK)
      for x = x0 + 4, x1, 14 do gfx.fillRect(x, y0, 3, h) end
      for y = y0 + 4, y1, 14 do gfx.fillRect(x0, y, w, 3) end
      gfx.setColor(BLACK)
    end
    for x = x0 + 5, x1, 14 do gfx.drawLine(x, y0, x, y1) end
    for y = y0 + 5, y1, 14 do gfx.drawLine(x0, y, x1, y) end
  elseif pat == "bean" then
    local row = 0
    for y = y0 + 4, y1, 9 do
      for x = x0 + 4 + (row % 2) * 6, x1, 12 do
        gfx.fillEllipseInRect(x - 2, y - 1, 5, 4); gfx.setColor(WHITE); gfx.drawLine(x - 1, y + 1, x + 1, y); gfx.setColor(BLACK)
      end
      row = row + 1
    end
  elseif pat == "ripple" then
    for y = y0 + 3, y1 + 2, 7 do
      local px, py
      for x = x0, x1 + 4, 2 do
        local yy = y + math.floor(math.sin(x * 0.35) * 1.5 + 0.5)
        if px then gfx.drawLine(px, py, x, yy) end
        px, py = x, yy
      end
    end
  elseif pat == "sun" then
    local cx = x0 + math.floor(w / 2)
    for k = -18, 18 do
      local a = k * 0.085
      gfx.drawLine(cx, y0 - 6, cx + math.floor(math.sin(a) * 600), y0 - 6 + math.floor(math.cos(a) * 600))
    end
  elseif pat == "diamond" then
    local row = 0
    for y = y0 + 5, y1, 10 do
      for x = x0 + 5 + (row % 2) * 7, x1, 14 do
        gfx.drawLine(x, y - 3, x + 3, y); gfx.drawLine(x + 3, y, x, y + 3); gfx.drawLine(x, y + 3, x - 3, y); gfx.drawLine(x - 3, y, x, y - 3)
      end
      row = row + 1
    end
  elseif pat == "zigzag" then
    for y = y0 + 3, y1 + 3, 8 do
      local i = 0
      for x = x0 - 4, x1, 4 do
        gfx.drawLine(x, y + ((i % 2 == 0) and 0 or 3), x + 4, y + ((i % 2 == 0) and 3 or 0))
        i = i + 1
      end
    end
  elseif pat == "royal" then                     -- deep colour, little pale crests in rows
    gfx.setColor(fg)
    local row = 0
    for y = y0 + 6, y1, 12 do
      for x = x0 + 6 + (row % 2) * 8, x1, 16 do
        gfx.drawPixel(x, y - 3); gfx.fillRect(x - 1, y - 2, 3, 1); gfx.fillRect(x - 2, y - 1, 5, 1); gfx.fillRect(x - 1, y, 3, 1); gfx.drawPixel(x, y + 1)
        gfx.drawPixel(x - 3, y + 2); gfx.drawPixel(x + 3, y + 2)
      end
      row = row + 1
    end
    gfx.setColor(BLACK)
  elseif pat == "floral" or pat == "matcha" then
    CAFE.motifFill(pat, x0 - 2, y0 - 2, w + 4, h + 4, nil, true)
  elseif pat == "brick" then
    local row = 0
    for y = y0 + 6, y1 + 6, 7 do
      gfx.drawLine(x0, y, x1, y)
      for x = x0 + ((row % 2 == 0) and 0 or 8), x1, 16 do gfx.drawLine(x, y - 6, x, y - 1) end
      row = row + 1
    end
  elseif pat == "wood" then
    for x = x0 + 11, x1, 12 do gfx.drawLine(x, y0, x, y1) end
    for k = 0, 40 do                                -- a few grain marks, the same every time
      local gx = x0 + (k * 37) % w
      local gy = y0 + (k * 23) % math.max(1, h - 6)
      if (gx - x0) % 12 ~= 11 then gfx.drawLine(gx, gy, gx, gy + 3 + k % 3) end
    end
  elseif pat == "wainscot" then
    local rail = y0 + math.floor(h * 0.58)
    for x = x0 + 3, x1, 6 do gfx.drawLine(x, y0, x, rail - 3) end
    gfx.fillRect(x0, rail - 2, w, 2)
    for x = x0 + 2, x1, 20 do gfx.drawRect(x, rail + 3, 16, y1 - rail - 4) end
  elseif pat == "stars" then
    gfx.setColor(fg)
    for k = 0, 70 do
      local sx, sy = x0 + (k * 53) % w, y0 + (k * 29) % h
      if k % 7 == 0 then gfx.drawPixel(sx, sy - 1); gfx.drawPixel(sx - 1, sy); gfx.drawPixel(sx + 1, sy); gfx.drawPixel(sx, sy + 1) end
      gfx.drawPixel(sx, sy)
    end
    gfx.setColor(BLACK)
  elseif pat == "espresso" then
    gfx.setColor(fg)
    if UI.color then for y = y0 + 1, y1, 4 do for x = x0 + ((y - y0) % 8 == 1 and 1 or 3), x1, 4 do gfx.drawPixel(x, y) end end
    else gfx.setPattern(DIAG); gfx.fillRect(x0, y0, w, h) end
    gfx.setColor(BLACK)
  end
  gfx.clearClipRect()
  gfx.setColor(BLACK)
end

function CAFE.floorFill(id, x0, y0, w, h)         -- the floor in its flooring (id nil: plain)
  local fd = id and CAFE.FLDATA[id]
  if not fd then return end
  local pat = fd.pat
  local x1, y1 = x0 + w - 1, y0 + h - 1
  UI.ink("fl2_" .. pat)
  gfx.setClipRect(x0, y0, w, h)
  gfx.setColor(WHITE); gfx.fillRect(x0, y0, w, h)
  local function pen()                            -- (Playdate: the lines are a soft grey, so the floor stays calm under everything)
    if UI.color then gfx.setColor(BLACK)
    elseif pat == "herring" then gfx.setPattern({ 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA })   -- (a checker would hide a slanted line completely)
    else gfx.setPattern(CHECK) end
  end
  pen()
  if CAFE.NEWPAT[pat] then                        -- (the pattern engine's tiles, lined up on the middle of the floor; Playdate: soft)
    CAFE.patTiles(pat, x0, y0, w, h, w >= 100, not UI.color)
  elseif pat == "planks" then
    local row = 0
    for y = y0 + 10, y1 + 10, 11 do
      gfx.drawLine(x0, y, x1, y)
      for x = x0 + ((row * 29) % 60), x1, 60 do gfx.drawLine(x, y - 10, x, y - 1) end
      row = row + 1
    end
  elseif pat == "tiles" then
    for y = y0 + 19, y1, 20 do gfx.drawLine(x0, y, x1, y) end
    for x = x0 + 19, x1, 20 do gfx.drawLine(x, y0, x, y1) end
  elseif pat == "checker" then
    if UI.color then gfx.setPattern({ 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }) else gfx.setPattern({ 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }) end
    local row = 0
    for y = y0, y1, 20 do
      for x = x0 + ((row % 2) * 20), x1, 40 do gfx.fillRect(x, y, 20, 20) end
      row = row + 1
    end
  elseif pat == "terrazzo" then
    gfx.setColor(BLACK)
    local seed = 12345
    for _ = 0, 220 do
      seed = (seed * 1103515245 + 12345) % 2147483648
      local sx = x0 + seed % w
      seed = (seed * 1103515245 + 12345) % 2147483648
      local sy = y0 + seed % h
      gfx.drawPixel(sx, sy)
      if seed % 4 == 0 then gfx.drawPixel(sx + 1, sy) end
    end
  elseif pat == "hex" then
    local row = 0
    for y = y0, y1 + 10, 10 do
      local off = (row % 2) * 10
      for x = x0 - 20 + off, x1, 20 do
        gfx.drawLine(x, y + 3, x + 4, y); gfx.drawLine(x + 4, y, x + 10, y); gfx.drawLine(x + 10, y, x + 14, y + 3)
        gfx.drawLine(x, y + 3, x, y + 6)
      end
      row = row + 1
    end
  elseif pat == "parquet" then
    for by = 0, math.ceil(h / 20) do
      for bx = 0, math.ceil(w / 20) do
        local x, y = x0 + bx * 20, y0 + by * 20
        gfx.drawRect(x, y, 21, 21)
        if (bx + by) % 2 == 0 then for k = 7, 14, 7 do gfx.drawLine(x + k, y + 1, x + k, y + 19) end
        else for k = 7, 14, 7 do gfx.drawLine(x + 1, y + k, x + 19, y + k) end end
      end
    end
  elseif pat == "herring" then
    for y = y0 - 12, y1, 12 do
      for x = x0 - 12, x1, 24 do
        gfx.drawLine(x, y + 12, x + 12, y); gfx.drawLine(x + 12, y, x + 24, y + 12)
      end
    end
  elseif pat == "slate" then
    local row = 0
    for y = y0 + 13, y1 + 13, 14 do
      gfx.drawLine(x0, y, x1, y)
      for x = x0 + ((row % 2 == 0) and 6 or 26), x1, 40 do gfx.drawLine(x, y - 13, x, y - 1) end
      row = row + 1
    end
  end
  gfx.clearClipRect()
  UI.ink("floor")
  gfx.setColor(BLACK)
end

for id, w in pairs(CAFE.WPDATA) do CAFE.DESC[id] = w.desc end
for id, w in pairs(CAFE.FLDATA) do CAFE.DESC[id] = w.desc end
for id, w in pairs(CAFE.STDATA) do CAFE.DESC[id] = w.desc end
for id in pairs(CAFE.WPDATA) do                     -- the shop's picture: a piece of wall with a little frame on it
  CAFE.art[id] = function(cx, cy)
    local im = UI.cacheImg("wpprev", id, UI.inkNum(), 64, 44, function()
      CAFE.wallFill(id, 0, 0, 64, 44)
      UI.ink("none")
    end)
    if im then UI.cacheDraw(im, cx - 32, cy - 22) end
    gfx.setColor(BLACK); gfx.drawRect(cx - 33, cy - 23, 66, 46)
  end
end
for id in pairs(CAFE.FLDATA) do                     -- the shop's picture: a patch of floor with a little table on it
  CAFE.art[id] = function(cx, cy)
    local im = UI.cacheImg("flprev", id, UI.inkNum(), 64, 44, function()
      UI.ink("floor"); gfx.setColor(WHITE); gfx.fillRect(0, 0, 64, 44)
      CAFE.floorFill(id, 0, 0, 64, 44)
      UI.ink("none")
    end)
    if im then UI.cacheDraw(im, cx - 32, cy - 22) end
    gfx.setColor(BLACK); gfx.drawRect(cx - 33, cy - 23, 66, 46)
  end
end
for id in pairs(CAFE.STDATA) do                     -- the shop's picture: a corner of the couch and a chair, in the fabric
  CAFE.art[id] = function(cx, cy)
    local im = UI.cacheImg("stprev", id, UI.inkNum(), 84, 62, function()
      CAFE.fabForce = id
      local fab = CAFE.STDATA[id]
      local x0, y0 = 38, 8                         -- the couch corner: a back along the right and along the bottom, three cushions
      UI.ink(fab.frame); gfx.setColor(BLACK)
      gfx.fillRoundRect(x0 + 35, y0, 9, 46, 3); gfx.fillRoundRect(x0, y0 + 37, 44, 9, 3)
      gfx.fillRoundRect(x0 + 18, y0, 26, 6, 3); gfx.fillRoundRect(x0 - 2, y0 + 19, 6, 27, 3)
      gfx.fillRect(x0 + 4, y0 + 5, 32, 33)
      CAFE.cushionAt(fab, x0 + 18, y0 + 5, 18, 16, 3)
      CAFE.cushionAt(fab, x0 + 18, y0 + 20, 18, 18, 3)
      CAFE.cushionAt(fab, x0 + 4, y0 + 20, 15, 18, 3)
      CAFE.chairAt(16, 31, "l")                     -- and a chair beside it
      CAFE.fabForce = nil
      UI.ink("none")
    end)
    if im then UI.cacheDraw(im, cx - 42, cy - 31) end
    gfx.setColor(BLACK)
  end
end
function CAFE.rugIds(kind)                       -- every rug of one kind, in the shop's order (worked out once)
  CAFE.rugIdC = CAFE.rugIdC or {}
  local t = CAFE.rugIdC[kind]
  if not t then
    t = {}
    for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind then t[#t + 1] = it.id end end
    CAFE.rugIdC[kind] = t
  end
  return t
end
function CAFE.diamondAt(x, y, hw, hh, dot)      -- a diamond outline (and a dot in the middle: 0 none, 1 a pixel, 2+ a little square)
  gfx.drawLine(x, y - hh, x + hw, y); gfx.drawLine(x + hw, y, x, y + hh)
  gfx.drawLine(x, y + hh, x - hw, y); gfx.drawLine(x - hw, y, x, y - hh)
  if dot == 1 then gfx.drawPixel(x, y) elseif dot and dot >= 2 then gfx.fillRect(x - 1, y - 1, 3, 3) end
end
function CAFE.sunRays(cx, cy, rx, ry, n, irx, iry)   -- rays from a little oval round the middle (irx, iry) out to a big one (rx, ry)
  irx, iry = irx or 0, iry or 0
  for i = 0, n - 1 do
    local a = i * math.pi * 2 / n
    local c, s = math.cos(a), math.sin(a)
    gfx.drawLine(math.floor(cx + c * irx + 0.5), math.floor(cy + s * iry + 0.5), math.floor(cx + c * rx + 0.5), math.floor(cy + s * ry + 0.5))
  end
end
function CAFE.sunDisc(cx, cy, w, h)              -- the little sun in the middle of a sunburst
  UI.ink("rpeach")
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(math.floor(cx - w / 2), math.floor(cy - h / 2), w, h)
  gfx.setColor(BLACK)
  gfx.drawEllipseInRect(math.floor(cx - w / 2), math.floor(cy - h / 2), w, h)
end

-- a long runner rolled out in front of the register, down the line (drawn at any size, so the
-- shop preview can shrink it to fit its box)
function CAFE.runnerAt(which, x, y, w, h)
  local big = w >= 30
  local r = big and 5 or 2
  local pat = CAFE.RUGPAT[which] or "bean"
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 4 or 2                      -- border width
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  local cx = x + math.floor(w / (2))
  if CAFE.NEWPAT[pat] then
    gfx.setColor(BLACK); CAFE.patArea(pat, ix + 1, iy + 1, iw - 2, ih - 2, big)
  elseif pat == "floral" or pat == "matcha" then
    CAFE.motifFill(pat, ix, iy, iw, ih, nil, big)
  elseif pat == "royal" then                    -- red carpet: a dark pile, a gold trim and a row of royal diamonds
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(WHITE)
    if big then gfx.drawRoundRect(x + 7, y + 7, w - 14, h - 14, 2) end
    local st = math.max(10, math.floor(h * 16 / (118)))
    local hw, hh = math.max(2, math.floor(w * 7 / (36))), math.max(3, math.floor(st * 5 / (8)))
    for yy = y + st, y + h - math.floor(st / (2)), st do CAFE.diamondAt(cx, yy, hw, hh, big and 2 or 1) end
    if big then                                 -- tassel dots along the two trims
      for yy = y + 10, y + h - 10, 6 do gfx.drawPixel(x + 10, yy); gfx.drawPixel(x + w - 11, yy) end
    end
  elseif pat == "stripe" then
    local step = math.max(3, math.floor(h / (15)))
    for yy = iy, iy + ih - 2, step do gfx.fillRect(ix, yy, iw, math.max(1, math.floor(step / (2)))) end
  elseif pat == "check" then
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(ix, iy, iw, ih, big and 3 or 1)
  elseif pat == "diamond" then
    local step = math.max(6, math.floor(h * 14 / (118)))
    local hw, hh = math.max(3, math.floor(w * 8 / (36))), math.max(3, math.floor(step * 6 / (14)))
    for yy = y + step, y + h - step + 1, step do
      CAFE.diamondAt(cx, yy, hw, hh)
      gfx.fillCircleAtPoint(cx, yy, big and 2 or 1)
    end
  elseif pat == "polka" then                    -- a pair of dots, then one in the middle, down the runner
    local st = math.max(5, math.floor(h / (12)))
    CAFE.symGrid(ix, iy, iw, ih, math.max(4, math.floor(iw * 2 / 5)), st, big and 4 or 2, big and 4 or 2, true, function(xx, yy)
      gfx.fillCircleAtPoint(xx, yy, big and 3 or 1)
    end)
  elseif pat == "zigzag" then                   -- one zigzag down the runner, starting and ending on the same side
    local hw = math.max(3, math.floor(iw / 2) - (big and 4 or 1))
    local n = math.max(2, math.floor(ih / math.max(6, math.floor(h / (10)))))
    if n % 2 == 1 then n = n + 1 end
    local mx = ix + math.floor((iw - 1) / 2)
    local y0, y1 = iy + (big and 3 or 1), iy + ih - 1 - (big and 3 or 1)
    for i = 0, n - 1 do
      local ax, bx = (i % 2 == 0) and (mx - hw) or (mx + hw), (i % 2 == 0) and (mx + hw) or (mx - hw)
      local ay, by = y0 + math.floor((y1 - y0) * i / n + 0.5), y0 + math.floor((y1 - y0) * (i + 1) / n + 0.5)
      gfx.drawLine(ax, ay, bx, by)
      if big then gfx.drawLine(ax, ay + 1, bx, by + 1) end
    end
  elseif pat == "plaid" then
    local st = math.max(6, math.floor(h / (9)))
    gfx.setPattern(CHECK)
    for yy = iy + 1, iy + ih - 3, st do gfx.fillRect(ix, yy, iw, big and 5 or 2) end
    gfx.setColor(BLACK)
    gfx.drawLine(cx, iy, cx, iy + ih)
    if big then gfx.drawLine(cx - 8, iy, cx - 8, iy + ih); gfx.drawLine(cx + 8, iy, cx + 8, iy + ih) end
  elseif pat == "cozy" then                     -- a soft woven tone with a plain band at each end
    gfx.setPattern(TEA)
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(BLACK)
    local b = big and 9 or 4
    gfx.drawLine(ix, iy + b, ix + iw - 1, iy + b); gfx.drawLine(ix, iy + ih - 1 - b, ix + iw - 1, iy + ih - 1 - b)
    if big then gfx.drawLine(ix, iy + b + 2, ix + iw - 1, iy + b + 2); gfx.drawLine(ix, iy + ih - 3 - b, ix + iw - 1, iy + ih - 3 - b) end
  elseif pat == "lattice" then                  -- a trellis of diagonals
    gfx.setClipRect(ix, iy, iw, ih)
    local st = big and 12 or 6
    for yy = iy - iw, iy + ih, st do
      gfx.drawLine(ix, yy, ix + iw, yy + iw)
      gfx.drawLine(ix + iw, yy, ix, yy + iw)
    end
    gfx.clearClipRect()
  elseif pat == "ripple" then                   -- rounded frames stepping in to the middle
    local k, st = 0, big and 4 or 2
    while 2 * k * st < iw - 3 and 2 * k * st < ih - 3 do
      gfx.drawRoundRect(ix + k * st, iy + k * st, iw - 2 * k * st, ih - 2 * k * st, big and 3 or 1)
      k = k + 1
    end
  elseif pat == "sun" then                      -- a little sun in the middle, its rays reaching to the ends
    gfx.setClipRect(ix, iy, iw, ih)
    local cy = y + math.floor(h / (2))
    local sd = math.max(5, math.floor(iw * 0.6))
    CAFE.sunRays(cx, cy, iw * 0.9, ih * 0.62, big and 20 or 12, sd * 0.7, sd * 0.7)
    gfx.clearClipRect()
    CAFE.sunDisc(cx, cy, sd, sd)
  else                                          -- coffee beans, a zigzag down the runner (left, right, ... left)
    UI.ink("choc")
    local n = big and 9 or 7
    local mx = ix + math.floor((iw - 1) / 2)
    local dx = math.floor(iw / 4)
    for i = 0, n - 1 do
      local by = iy + math.floor(ih * (i + 0.5) / n + 0.5)
      CAFE.beanAt((i % 2 == 0) and (mx - dx) or (mx + dx), by, big and "mid" or false, i % 2 == 1)
    end
  end
  UI.ink("tan")
  gfx.setColor(BLACK)
  if big then for xx = x + 3, x + w - 3, 5 do gfx.drawLine(xx, y + h, xx, y + h + 3) end end   -- fringe at the door end
end

function CAFE.drawRunner()
  for _, id in ipairs(CAFE.rugIds("runner")) do
    if CAFE.decorOn(id) then CAFE.runnerAt(id, 38, 116, 36, 118) end
  end
end

-- an oval rug that sits under the six table spots (it fits whole inside them: x 105-267, y 151-227)
function CAFE.ovalAt(which, x, y, w, h)
  local big = w >= 100
  local lw = big and 2 or 1
  local pat = CAFE.RUGPAT[which] or "bean"
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(lw)
  gfx.drawEllipseInRect(x, y, w, h)
  local m = big and 7 or 3
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  gfx.drawEllipseInRect(ix, iy, iw, ih)
  gfx.setLineWidth(1)
  local m2 = big and 3 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  local cx, cy = x + w / 2, y + h / 2
  local ra, rb = fw / 2 - 1, fh / 2 - 1                   -- the pattern stays inside this oval
  local function inside(px, py, pad)             -- is the point well inside the pattern area?
    local dx, dy = (px - cx) / (fw / 2 - pad), (py - cy) / (fh / 2 - pad)
    return dx * dx + dy * dy <= 1
  end
  local function half(yy)                        -- how far the pattern oval reaches either side of the middle on row yy
    local t = (yy + 0.5 - cy) / rb
    if t <= -1 or t >= 1 then return nil end
    return math.floor(ra * math.sqrt(1 - t * t))
  end
  local function seg(x0, y0, x1, y1)             -- a straight line, trimmed to the pattern oval
    local dx, dy = x1 - x0, y1 - y0
    local ux, uy = (x0 - cx) / ra, (y0 - cy) / rb
    local vx, vy = dx / ra, dy / rb
    local A, B, C = vx * vx + vy * vy, 2 * (ux * vx + uy * vy), ux * ux + uy * uy - 1
    if A == 0 then return end
    local D = B * B - 4 * A * C
    if D <= 0 then return end
    local sq = math.sqrt(D)
    local t0, t1 = math.max(0, (-B - sq) / (2 * A)), math.min(1, (-B + sq) / (2 * A))
    if t1 <= t0 then return end
    gfx.drawLine(math.floor(x0 + dx * t0 + 0.5), math.floor(y0 + dy * t0 + 0.5), math.floor(x0 + dx * t1 + 0.5), math.floor(y0 + dy * t1 + 0.5))
  end
  if CAFE.NEWPAT[pat] then
    gfx.setColor(BLACK); CAFE.patArea(pat, fx, fy, fw, fh, big, function(px, py) return inside(px, py, 1) end)
  elseif pat == "floral" or pat == "matcha" then
    CAFE.motifFill(pat, fx, fy, fw, fh, inside, big)
  elseif pat == "cozy" then
    gfx.setPattern(TEA)
    gfx.fillEllipseInRect(fx, fy, fw, fh)
  elseif pat == "ripple" then
    gfx.setLineWidth(lw)
    local st = big and 8 or 4
    for k = 1, 6 do
      local sx, sy = k * st, k * st * fh / fw
      if sy * 2 >= fh - 2 or sx * 2 >= fw - 2 then break end
      gfx.drawEllipseInRect(fx + sx, fy + sy, fw - 2 * sx, fh - 2 * sy)
    end
    gfx.setLineWidth(1)
  elseif pat == "check" then
    gfx.setPattern(CHECK)
    gfx.fillEllipseInRect(fx, fy, fw, fh)
    gfx.setColor(BLACK)
    local k = big and 8 or 3
    gfx.drawEllipseInRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k)
  elseif pat == "polka" then
    local st = big and 12 or 6
    local row = 0
    for yy = fy + math.floor(st / (2)) + 1, fy + fh - 2, st do
      for xx = fx + math.floor(st / (2)) + (row % 2) * (math.floor(st / (2))) + 1, fx + fw - 2, st do
        if inside(xx, yy, big and 4 or 2) then gfx.fillCircleAtPoint(xx, yy, big and 3 or 1) end
      end
      row = row + 1
    end
  elseif pat == "sun" then
    local dw, dh = math.max(3, math.floor(fw * 0.24)), math.max(3, math.floor(fh * 0.24))
    CAFE.sunRays(cx, cy, fw / 2 - 1, fh / 2 - 1, 16, dw * 0.4, dh * 0.4)
    CAFE.sunDisc(cx, cy, dw, dh)
  elseif pat == "stripe" then                    -- bands across, following the curve
    local step, bw = big and 6 or 3, big and 3 or 1
    for y0 = math.floor(cy) - math.floor(step / 2) - step * math.floor(fh / (2 * step) + 1), fy + fh, step do
      for yy = y0, y0 + bw - 1 do
        local hw = half(yy)
        if hw and hw > 0 then gfx.fillRect(math.floor(cx) - hw, yy, 2 * hw, 1) end
      end
    end
  elseif pat == "lattice" then                   -- a trellis of diagonals, trimmed to the oval
    local st = big and 14 or 6
    local mx, my = math.floor(cx), math.floor(cy)
    for k = -math.floor((fw + fh) / st) - 1, math.floor((fw + fh) / st) + 1 do
      local ox = mx + k * st
      seg(ox - fh, my - fh, ox + fh, my + fh)
      seg(ox + fh, my - fh, ox - fh, my + fh)
    end
  elseif pat == "plaid" then                     -- woven bands both ways, a thin line down each
    local st, bw = big and 18 or 8, big and 6 or 3
    local mx, my = math.floor(cx), math.floor(cy)
    gfx.setPattern(CHECK)
    for k = -6, 6 do
      local y0 = my + k * st - math.floor(bw / 2)
      for yy = y0, y0 + bw - 1 do
        local hw = half(yy)
        if hw and hw > 0 then gfx.fillRect(mx - hw, yy, 2 * hw, 1) end
      end
      local x0 = mx + k * st - math.floor(bw / 2)
      for xx = x0, x0 + bw - 1 do
        local t = (xx + 0.5 - cx) / ra
        if t > -1 and t < 1 then
          local hh = math.floor(rb * math.sqrt(1 - t * t))
          if hh > 0 then gfx.fillRect(xx, my - hh, 1, 2 * hh) end
        end
      end
    end
    gfx.setColor(BLACK)
    UI.ink("slate")
    for k = -6, 6 do seg(mx - fw, my + k * st, mx + fw, my + k * st); seg(mx + k * st, my - fh, mx + k * st, my + fh) end
  elseif pat == "diamond" then                   -- rows of diamonds, every other row half a step over
    local hw, hh = big and 7 or 3, big and 5 or 2
    local sx, sy = 2 * hw + (big and 4 or 2), 2 * hh + (big and 4 or 2)
    local mx, my = math.floor(cx), math.floor(cy)
    for k = -6, 6 do
      local yy = my + k * sy
      local off = (k % 2 ~= 0) and math.floor(sx / 2) or 0
      for j = -12, 12 do
        local xx = mx + off + j * sx
        if inside(xx - hw, yy, 1) and inside(xx + hw, yy, 1) and inside(xx, yy - hh, 1) and inside(xx, yy + hh, 1) then
          CAFE.diamondAt(xx, yy, hw, hh, (k % 2 == 0) and (big and 2 or 1) or 0)
        end
      end
    end
  elseif pat == "zigzag" then                    -- zigzag bands across
    local st, amp = big and 12 or 6, big and 4 or 2
    local mx, my = fx + math.floor((fw - 1) / 2), fy + math.floor((fh - 1) / 2)
    for k = -5, 5 do CAFE.zigRow(mx, my + k * st, fx, fx + fw, amp, big, seg) end
  elseif pat == "royal" then                     -- a dark pile, a gold trim, royal diamonds down the middle
    gfx.fillEllipseInRect(fx, fy, fw, fh)
    gfx.setColor(WHITE)
    local k = big and 4 or 2
    gfx.drawEllipseInRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k)
    local mx, my = math.floor(cx), math.floor(cy)
    local hw, hh = big and 8 or 3, big and 10 or 4
    for j = -3, 3 do
      local xx = mx + j * (2 * hw + (big and 6 or 2))
      if inside(xx - hw, my, k + 2) and inside(xx + hw, my, k + 2) then CAFE.diamondAt(xx, my, hw, hh, big and 2 or 1) end
    end
    if big then
      for a = 0, 345, 15 do
        local rad = math.rad(a)
        gfx.drawPixel(math.floor(cx + (fw / 2 - k - 4) * math.cos(rad) + 0.5), math.floor(cy + (fh / 2 - k - 4) * math.sin(rad) + 0.5))
      end
    end
    gfx.setColor(BLACK)
  else                                           -- coffee beans, laid out in a mirror-matched pattern round the middle
    UI.ink("choc")
    local sx, sy = big and 14 or 6, big and 10 or 5                   -- spacing across / down
    local mx, my = math.floor(cx), math.floor(cy)
    local rows = math.floor((fh / 2) / sy)
    for k = -rows, rows do
      local yy = my + k * sy
      local half2 = (k % 2 ~= 0) and math.floor(sx / 2) or 0          -- every other row sits half a step over, the same on both sides
      for j = 0, math.floor(fw / sx) do
        for side = -1, 1, 2 do
          local off = half2 + j * sx
          if not (side == 1 and off == 0) then                         -- (the bean right in the middle only once)
            local xx = mx + side * off
            if inside(xx, yy, big and 6 or 2) then
              if big then
                gfx.setColor(BLACK); gfx.fillEllipseInRect(xx - 4, yy - 2, 9, 5)          -- a bean, its crease turned to mirror the other side
                gfx.setColor(WHITE)
                if side < 0 or off == 0 then gfx.drawLine(xx - 2, yy + 1, xx + 2, yy - 1) else gfx.drawLine(xx - 2, yy - 1, xx + 2, yy + 1) end
                gfx.setColor(BLACK)
              else gfx.fillCircleAtPoint(xx, yy, 1) end
            end
          end
        end
      end
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawOval()
  for _, id in ipairs(CAFE.rugIds("orug")) do
    if CAFE.decorOn(id) then CAFE.ovalAt(id, 105, 151, 162, 76) end
  end
end

-- a coffee bean lying on its side, its crease running corner to corner (flip: the crease the other way, for the
-- right-hand half of a pattern, so it mirrors). big: 10 x 6; "mid": 8 x 5; small: 6 x 4
function CAFE.beanAt(x, y, big, flip)
  gfx.setColor(BLACK)
  if big == "mid" then
    gfx.fillEllipseInRect(x - 4, y - 2, 8, 5)
    gfx.setColor(WHITE)
    if flip then gfx.drawLine(x - 2, y - 1, x + 2, y + 1) else gfx.drawLine(x - 2, y + 1, x + 2, y - 1) end
  elseif big then
    gfx.fillEllipseInRect(x - 5, y - 3, 10, 6)
    gfx.setColor(WHITE)
    if flip then gfx.drawLine(x - 3, y - 1, x + 3, y + 1) else gfx.drawLine(x - 3, y + 1, x + 3, y - 1) end
  else
    gfx.fillRoundRect(x - 3, y - 2, 6, 4, 2)
    gfx.setColor(WHITE)
    if flip then gfx.drawLine(x - 1, y - 1, x, y) else gfx.drawLine(x - 1, y, x, y - 1) end
  end
  gfx.setColor(BLACK)
end

-- ---- the pattern engine: a pattern worked out pixel by pixel from the middle of whatever it fills (u, v: how far
-- right / down of the middle), so it always mirrors left to right. Used by the newer patterns on rugs, wallpaper,
-- floors and tablecloths, and by every pattern on the seats. big: the full-size version (small: the shop picture /
-- little things like a cushion). hw, hh: half the size of the area (for patterns that follow its shape)
CAFE.PSPR = {}
function CAFE.loadPSPR(list)                      -- (in a function: the main chunk is out of room for loop variables)
for name, rows in pairs(list) do
  local t = { w = #rows[1], h = #rows, r = {} }
  for y, row in ipairs(rows) do
    t.r[y] = {}
    for x = 1, #row do t.r[y][x] = (string.sub(row, x, x) == "X") end
  end
  CAFE.PSPR[name] = t
end
end
CAFE.loadPSPR({
  heart7 = { ".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..." },
  heart5 = { "XX.XX", "XXXXX", ".XXX.", "..X.." },
  quat9 = { "...XXX...", "..X...X..", "XXX...XXX", "X.......X", "X...X...X", "X.......X", "XXX...XXX", "..X...X..", "...XXX..." },
  quat7 = { "..XXX..", ".X...X.", "X.X.X.X", "X..X..X", "X.X.X.X", ".X...X.", "..XXX.." },
  daisy7 = { "..XXX..", "..X.X..", "XXXXXXX", "X.XXX.X", "XXXXXXX", "..X.X..", "..XXX.." },
  daisy5 = { "..X..", ".X.X.", "X.X.X", ".X.X.", "..X.." },
  bean5 = { ".XXX.", "XX.XX", "XX.XX", "XX.XX", ".XXX." },
  star5 = { "..X..", ".XXX.", "XXXXX", ".XXX.", ".X.X." },
  dot3 = { ".X.", "XXX", ".X." },
  dot1 = { "X" },
})
function CAFE.patLat(u, v, sx, sy, stag, name)   -- a little picture repeated on a grid round the middle (every other row half a step over)
  local spr = CAFE.PSPR[name]                      -- (also gives back where that copy's middle is, and half its size)
  local j = math.floor((v + math.floor(sy / 2)) / sy)
  local off = (stag and j % 2 ~= 0) and math.floor(sx / 2) or 0
  local i = math.floor((u - off + math.floor(sx / 2)) / sx)
  local hx, hy = math.floor(spr.w / 2), math.floor(spr.h / 2)
  local row = spr.r[v - j * sy + hy + 1]
  return (row and row[u - off - i * sx + hx + 1]) or false, off + i * sx, j * sy, hx, hy
end
-- the patterns made of little pictures on a grid: spacing across / down (big, small), every other row over?, picture (big, small)
CAFE.LATS = { hearts = { 12, 10, 8, 7, true, "heart7", "heart5" }, quatre = { 10, 10, 8, 8, false, "quat9", "quat7" },
              daisy = { 12, 10, 8, 6, true, "daisy7", "daisy5" }, polka = { 8, 7, 4, 3, true, "dot3", "dot1" },
              bean = { 10, 8, 8, 6, true, "bean5", "bean5" } }
CAFE.PTILE = {}
function CAFE.patHit(u, v, sx, sy, stag, name)       -- is this point inside one of the little pictures? (the answer repeats every sx across and every row pair down, so each is worked out once)
  local tn = CAFE.PTILE[name]
  if tn == nil then tn = {}; CAFE.PTILE[name] = tn end
  local key = sx * 100 + sy
  local T = tn[key]
  if T == nil then T = {}; tn[key] = T end
  local k = (u % sx) + sx * (v % (stag and 2 * sy or sy))
  local h = T[k]
  if h == nil then h = CAFE.patLat(u, v, sx, sy, stag, name) and 1 or 0; T[k] = h end
  return h == 1
end
function CAFE.latOf(pat, u, v, big)
  local L = CAFE.LATS[pat]
  local sx, sy, nm = L[3], L[4], L[7]
  if big then sx, sy, nm = L[1], L[2], L[6] end
  if not CAFE.patHit(u, v, sx, sy, L[5], nm) then return false end
  return CAFE.patLat(u, v, sx, sy, L[5], nm)           -- (only where there is a hit: the picture's middle and size)
end
CAFE.NEWPAT = { argyle = true, scallop = true, hearts = true, waves = true, quatre = true, daisy = true }
function CAFE.patPix(pat, u, v, big, hw, hh)
  local au = math.abs(u)
  if CAFE.LATS[pat] then return (CAFE.latOf(pat, u, v, big))
  elseif pat == "stars" then
    if big and CAFE.patHit(u, v, 14, 12, true, "star5") then return true end
    return ((au * 7 + v * 13) % 29 == 0)
  elseif pat == "waves" then                       -- rows of gentle waves (a crest in the middle)
    local P, A, Q = big and 16 or 8, big and 2 or 1, big and 7 or 4
    return (v - math.floor(A * math.cos(2 * math.pi * u / P) + 0.5)) % Q == 0
  elseif pat == "scallop" then                     -- fish scales: rows of arcs, every other row half a scale over
    local r = big and 5 or 3
    local j = math.floor(v / r)
    local off = (j % 2 ~= 0) and r or 0
    local i = math.floor((u - off + r) / (2 * r))
    local du, dv = u - off - i * 2 * r, v - (j + 1) * r + 0.5
    local d = math.sqrt(du * du + dv * dv)
    return d <= r and d > r - 1.1
  elseif pat == "argyle" or pat == "diamond" then  -- diamonds: argyle has every other one woven in, and a stitch through the rest
    local a, b = big and 9 or 4, big and 6 or 3
    if pat == "diamond" then a, b = big and 6 or 4, big and 5 or 3 end
    local i1, j1 = math.floor(u / (2 * a) + 0.5), math.floor(v / (2 * b) + 0.5)
    local du, dv = u - 2 * a * i1, v - 2 * b * j1
    local d1 = math.abs(du) / a + math.abs(dv) / b
    if d1 <= 1 then
      if d1 > 1 - 1.15 / math.min(a, b) then return true end
      if pat == "diamond" then return du == 0 and dv == 0 end
      return (u + v) % 2 == 0
    end
    if pat == "diamond" then return false end
    local i2, j2 = math.floor((u - a) / (2 * a) + 0.5), math.floor((v - b) / (2 * b) + 0.5)
    local eu, ev = u - a - 2 * a * i2, v - b - 2 * b * j2
    return (eu == 0 or ev == 0) and (eu + ev) % 2 == 0
  elseif pat == "stripe" then return u % 3 == 0
  elseif pat == "check" then
    if big then return (math.floor((u + 1) / 3) + math.floor((v + 1) / 3)) % 2 == 0 end
    return (u + v) % 2 == 0
  elseif pat == "lattice" then local k = big and 6 or 4; return (u + v) % k == 0 or (u - v) % k == 0
  elseif pat == "plaid" then
    local bu, bv = ((u + 1) % 7) < 3, ((v + 1) % 7) < 3
    return u % 7 == 0 or v % 7 == 0 or ((bu or bv) and (u + v) % 2 == 0)
  elseif pat == "zigzag" then
    local P, Q = 6, big and 6 or 5
    return (v + math.abs((au % P) - P / 2)) % Q == 0
  elseif pat == "cozy" then return (u % 4 == 0 and v % 2 == 0) or (u % 4 == 2 and v % 2 == 1)
  elseif pat == "ripple" then
    local d = math.min((hw or 8) - au, (hh or 8) - math.abs(v))
    return d >= 1 and d % 3 == 1
  elseif pat == "sun" then                         -- a little sun, thin rays round it
    local r = math.sqrt(u * u + v * v)
    if r <= 1.6 then return true end
    if r < 3.5 then return false end
    local k = (UI.atan2(v, au) + math.pi / 2) * 6 / math.pi
    return math.abs(k - math.floor(k + 0.5)) < 1.2 / (math.pi * r / 3)
  end
  return false
end
-- fill an area with a pattern, round its middle (inside(x, y): is the pixel in the shape? nil: the whole box).
-- A pattern of little pictures only puts down whole ones (none cut off at the edge), unless part is true
function CAFE.patArea(pat, x0, y0, w, h, big, inside, part)
  local cx, cy = x0 + math.floor((w - 1) / 2), y0 + math.floor((h - 1) / 2)
  local hw, hh = math.floor((w - 1) / 2), math.floor((h - 1) / 2)
  local lat = CAFE.LATS[pat] and not part
  local function fits(mx, my, ax, ay)
    if mx - ax < x0 or mx + ax > x0 + w - 1 or my - ay < y0 or my + ay > y0 + h - 1 then return false end
    return not inside or (inside(mx - ax, my - ay) and inside(mx + ax, my - ay) and inside(mx - ax, my + ay) and inside(mx + ax, my + ay))
  end
  for py = y0, y0 + h - 1 do
    for px = x0, x0 + w - 1 do
      if lat then
        local hit, mu, mv, ax, ay = CAFE.latOf(pat, px - cx, py - cy, big)
        if hit and fits(cx + mu, cy + mv, ax, ay) then gfx.drawPixel(px, py) end
      elseif (not inside or inside(px, py)) and CAFE.patPix(pat, px - cx, py - cy, big, hw, hh) then gfx.drawPixel(px, py) end
    end
  end
end
-- the same, for a big plain box (the wall, the floor): one repeat of the pattern is drawn once, then stamped across
-- (lined up on the middle). soft: Playdate, every other pixel only (a calm floor)
CAFE.PERIOD = { hearts = { 12, 20, 8, 14 }, quatre = { 10, 10, 8, 8 }, daisy = { 12, 20, 8, 12 }, waves = { 16, 7, 8, 4 },
                scallop = { 10, 10, 6, 6 }, argyle = { 18, 12, 8, 6 } }
function CAFE.patTiles(pat, x0, y0, w, h, big, soft)
  local per = CAFE.PERIOD[pat]
  local pw, ph = per[big and 1 or 3], per[big and 2 or 4]
  local cx, cy = x0 + math.floor((w - 1) / 2), y0 + math.floor((h - 1) / 2)
  if soft then cx, cy = cx - cx % 2, cy - cy % 2 end
  local im = UI.cacheImg("ptile", pat .. (big and "B" or "s") .. (soft and "f" or ""), UI.inkNum(), pw, ph, function()
    gfx.setColor(BLACK)
    for tv = 0, ph - 1 do for tu = 0, pw - 1 do
      if CAFE.patPix(pat, tu, tv, big) and not (soft and (tu + tv) % 2 == 1) then gfx.drawPixel(tu, tv) end
    end end
  end)
  if not im then CAFE.patArea(pat, x0, y0, w, h, big); return end
  local kx0, ky0 = math.floor((x0 - cx) / pw) - 1, math.floor((y0 - cy) / ph) - 1
  for ky = ky0, math.floor((y0 + h - cy) / ph) + 1 do
    for kx = kx0, math.floor((x0 + w - cx) / pw) + 1 do UI.cacheDraw(im, cx + kx * pw, cy + ky * ph) end
  end
end

-- a zigzag line across, mirrored round x = mx (its middle point peaks up), from x0 to x1; seg draws a line piece
function CAFE.zigRow(mx, yy, x0, x1, amp, thick, seg)
  seg = seg or gfx.drawLine
  local J = math.floor(math.max(mx - x0, x1 - mx) / (2 * amp)) + 1
  for j = -J, J - 1 do
    local ax, bx = mx + j * 2 * amp, mx + (j + 1) * 2 * amp
    local ay = yy + ((j % 2 == 0) and -amp or amp)
    local by = yy + (((j + 1) % 2 == 0) and -amp or amp)
    seg(ax, ay, bx, by)
    if thick then seg(ax, ay + 1, bx, by + 1) end
  end
end

-- the big centre rug
function CAFE.rugAt(which, x, y, w, h)
  local big = w >= 100
  local r = big and 8 or 3
  local pat = CAFE.RUGPAT[which] or "check"
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 6 or 3
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  gfx.drawRoundRect(ix, iy, iw, ih, big and 5 or 2)            -- (the inner border: the shop's little picture has it too)
  local m2 = big and 2 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  local cx, cy = fx + math.floor(fw / (2)), fy + math.floor(fh / (2))
  if CAFE.NEWPAT[pat] then
    gfx.setColor(BLACK); CAFE.patArea(pat, fx, fy, fw, fh, big)
  elseif pat == "floral" or pat == "matcha" then
    CAFE.motifFill(pat, fx, fy, fw, fh, nil, big)
  elseif pat == "cozy" then
    UI.ink("tan")
    gfx.setPattern(TEA)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
  elseif pat == "stripe" then
    gfx.setColor(BLACK)
    local step = big and 6 or 3
    for yy = fy + 1, fy + fh - 2, step do gfx.fillRect(fx, yy, fw, big and 3 or 1) end
  elseif pat == "polka" then                    -- dots, every row centred (a zigzag of two rows)
    gfx.setColor(BLACK)
    local st = big and 11 or 5
    CAFE.symGrid(fx, fy, fw, fh, st, math.floor(st * 0.9), big and 5 or 2, big and 4 or 2, true, function(xx, yy)
      gfx.fillCircleAtPoint(xx, yy, big and 3 or 1)
    end)
  elseif pat == "lattice" then                  -- a lattice of diamonds, crossing in the middle
    gfx.setColor(BLACK)
    gfx.setClipRect(fx, fy, fw, fh)
    local st = big and 14 or 6
    local mx, my = fx + math.floor((fw - 1) / 2), fy + math.floor((fh - 1) / 2)
    for k = -math.floor((fw + fh) / st) - 1, math.floor((fw + fh) / st) + 1 do
      local ox = mx + k * st
      gfx.drawLine(ox - fh, my - fh, ox + fh, my + fh)
      gfx.drawLine(ox + fh, my - fh, ox - fh, my + fh)
    end
    gfx.clearClipRect()
  elseif pat == "plaid" then                    -- woven bands both ways, centred, a thin line down each
    local st = big and 18 or 8
    local bw = big and 6 or 3
    local mx, my = fx + math.floor((fw - 1) / 2), fy + math.floor((fh - 1) / 2)
    gfx.setClipRect(fx, fy, fw, fh)
    gfx.setPattern(CHECK)
    for k = -12, 12 do gfx.fillRect(mx + k * st - math.floor(bw / 2), fy, bw, fh) end
    gfx.fillRect(fx, my - math.floor(bw / 2), fw, bw)
    gfx.setColor(BLACK)
    UI.ink("slate")
    for k = -12, 12 do gfx.drawLine(mx + k * st, fy, mx + k * st, fy + fh) end
    gfx.drawLine(fx, my, fx + fw, my)
    gfx.clearClipRect()
  elseif pat == "bean" then                     -- coffee beans in a zigzag, top row / bottom row, the same from both ends
    UI.ink("choc")                              -- (the shop's little picture is the same zigzag, in little beans)
    gfx.setColor(BLACK)
    local bw2 = big and 4 or 3                  -- half a bean's width
    local step = big and 10 or 7
    local n = math.floor((fw - 2 * bw2 - 2) / step) + 1
    if n % 2 == 0 then n = n - 1 end            -- (an odd count: both ends are on the top row)
    local x0 = fx + math.floor((fw - (n - 1) * step) / 2)
    local yt, yb = fy + (big and 6 or 3), fy + fh - (big and 7 or 4)
    for i = 0, n - 1 do
      CAFE.beanAt(x0 + i * step, (i % 2 == 0) and yt or yb, big and "mid" or false, i > (n - 1) / 2)
    end
  elseif pat == "ripple" then                   -- rounded frames stepping in to the middle
    gfx.setColor(BLACK)
    local k, st = 1, big and 4 or 2
    while 2 * k * st < fh - 2 do
      gfx.drawRoundRect(fx + k * st, fy + k * st, fw - 2 * k * st, fh - 2 * k * st, big and 3 or 1)
      k = k + 1
    end
    gfx.drawLine(fx + k * st, cy, fx + fw - k * st - 1, cy)
  elseif pat == "sun" then                      -- a sun in the middle, its rays fanning out to the corners
    gfx.setColor(BLACK)
    gfx.setClipRect(fx, fy, fw, fh)
    local dw, dh = math.max(5, math.floor(fh * 1.1)), math.max(3, math.floor(fh * 0.62))
    CAFE.sunRays(cx, cy, fw * 0.62, fh * 0.9, big and 28 or 14, dw * 0.75, dh * 0.75)
    gfx.clearClipRect()
    CAFE.sunDisc(cx, cy, dw, dh)
  elseif pat == "diamond" then                  -- a row of diamonds along the middle, little ones above and below
    gfx.setColor(BLACK)
    local hh = math.max(2, math.floor(fh / 2) - (big and 3 or 1))
    local hw = big and math.floor(hh * 1.3) or hh + 1
    local n = math.max(1, math.floor(fw / (2 * hw + (big and 4 or 1))))
    local gap = fw / n
    for i = 0, n - 1 do
      local xx = math.floor(fx + gap * (i + 0.5) + 0.5)
      CAFE.diamondAt(xx, cy, hw, hh, big and 2 or 1)
      if big and i < n - 1 then
        local x2 = math.floor(fx + gap * (i + 1) + 0.5)
        gfx.fillRect(x2 - 1, fy + 2, 3, 3); gfx.fillRect(x2 - 1, fy + fh - 5, 3, 3)
      end
    end
  elseif pat == "zigzag" then                   -- zigzag bands along the rug
    gfx.setColor(BLACK)
    gfx.setClipRect(fx, fy, fw, fh)
    local st, amp = big and 9 or 4, big and 3 or 1
    local mx, my = fx + math.floor((fw - 1) / 2), fy + math.floor((fh - 1) / 2)
    local n = math.max(1, math.floor((fh - 2 * amp - 2) / st) + 1)
    for i = 0, n - 1 do
      CAFE.zigRow(mx, my + math.floor((i - (n - 1) / 2) * st + 0.5), fx, fx + fw, amp, big)
    end
    gfx.clearClipRect()
  elseif pat == "royal" then                    -- a dark pile, a gold trim and a row of royal diamonds
    gfx.setColor(BLACK)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
    gfx.setColor(WHITE)
    if big then gfx.drawRoundRect(fx + 3, fy + 3, fw - 6, fh - 6, 3) end
    local hh = math.max(2, math.floor(fh / 2) - (big and 6 or 1))
    local hw = big and hh + 3 or hh + 1
    local n = math.max(1, math.floor(fw / (2 * hw + (big and 8 or 2))))
    local gap = fw / n
    for i = 0, n - 1 do CAFE.diamondAt(math.floor(fx + gap * (i + 0.5) + 0.5), cy, hw, hh, big and 2 or 1) end
    if big then for xx = fx + 6, fx + fw - 6, 6 do gfx.drawPixel(xx, fy + 5); gfx.drawPixel(xx, fy + fh - 6) end end
    gfx.setColor(BLACK)
  else
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
    gfx.setColor(BLACK)
    local k = big and 6 or 2
    gfx.drawRoundRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k, big and 3 or 1)
  end
  gfx.setColor(BLACK)                            -- (no fringe: a clean edge)
end

-- ---- table dressing: cloths and centrepieces ----------------------------------------------------------
function CAFE.ownedOf(kind)
  local own = G and (G.cafe or G.deco) and G.own
  if G and (G.cafe or G.deco) and not own then own = {}; G.own = own end
  if own then
    local v = own[kind]
    if v ~= nil then return v or nil end
  end
  local r
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == kind and CAFE.decorOn(it.id) then r = it.id; break end
  end
  if own then own[kind] = r or false end
  return r
end

CAFE.CLOTHCOL = { cloth1 = "inkred", cloth2 = "skyp", cloth3 = "white", cloth4 = "rose", cloth5 = "forest", cloth6 = "lav", cloth7 = "tan",
                  cloth8 = "inkred", cloth9 = "teal", cloth10 = "navyy", cloth11 = "orangep",
                  cloth12 = "rose", cloth13 = "skyp", cloth14 = "tan", cloth15 = "leaf", cloth16 = "inkblue", cloth17 = "gingham",
                  cloth18 = "inkpurple", cloth19 = "orangep", cloth20 = "rfloral", cloth21 = "rmatcha",
                  cloth22 = "r_argyle", cloth23 = "r_scallop", cloth24 = "r_quatre", cloth25 = "r_daisy" }
CAFE.CLOTHPAT = { cloth22 = "argyle", cloth23 = "scallop", cloth24 = "quatre", cloth25 = "daisy" }       -- (the engine's patterns, round the rim)      -- (PC colours)
function CAFE.clothAt(id, x, y, r)               -- the cloth under a table: drawn once (kept inside its round edge), then stamped
  local R = r + math.max(2, math.floor(r / (3)))
  local S = R + 4                                -- (room round it: the lace's scallops stand out past the edge)
  local im = UI.cacheImg("cloth", id, r, 2 * S + 1, 2 * S + 1, function()
    CAFE.clothRaw(id, S, S, r, true)
    if id ~= "cloth3" then                       -- (nothing pokes out past the hem: everything outside the circle is wiped)
      gfx.setColor(gfx.kColorClear)
      local lim = (R - 0.5) * (R - 0.5)
      for j = 0, 2 * S do
        local dy = j - S
        if dy * dy > lim then gfx.fillRect(0, j, 2 * S + 1, 1)
        else
          local hw = math.floor(math.sqrt(lim - dy * dy))
          gfx.fillRect(0, j, S - hw, 1); gfx.fillRect(S + hw + 1, j, S - hw, 1)
        end
      end
    end
    UI.ink(CAFE.CLOTHCOL[id] or "white")
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(S, S, R)
  end)
  if im then UI.cacheDraw(im, x - S, y - S) else CAFE.clothRaw(id, x, y, r) end
  gfx.setColor(BLACK)
end
function CAFE.clothRaw(id, x, y, r, noRim)      -- only the rim of the cloth shows round the table, so each pattern runs round the rim
  local R = r + math.max(2, math.floor(r / (3)))
  local mid = (r + R) / 2
  local function around(n, fn, off)               -- call fn(px, py, angle) at n evenly spaced points on the rim
    for i = 0, n - 1 do
      local a = math.rad((off or 0) + i * 360 / n)
      fn(x + math.floor(mid * math.cos(a) + 0.5), y + math.floor(mid * math.sin(a) + 0.5), a)
    end
  end
  UI.ink(CAFE.CLOTHCOL[id] or "white")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, R)
  gfx.setColor(BLACK)
  if CAFE.CLOTHPAT[id] then                      -- the pattern engine's, centred on the table, so it runs evenly round the rim
    local r2 = (R - 0.5) * (R - 0.5)
    CAFE.patArea(CAFE.CLOTHPAT[id], x - R, y - R, 2 * R + 1, 2 * R + 1, false, function(px, py)
      local dx, dy = px - x, py - y
      return dx * dx + dy * dy <= r2
    end, true)
  elseif id == "cloth1" then                     -- checker
    gfx.setPattern(CHECK)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
  elseif id == "cloth2" then                     -- stripes
    for dy = -R + 1, R - 1, 3 do
      local hw = math.floor(math.sqrt(R * R - dy * dy))
      gfx.fillRect(x - hw, y + dy, 2 * hw, 2)
    end
  elseif id == "cloth4" then                     -- polka dots
    around(16, function(px, py) gfx.fillCircleAtPoint(px, py, math.max(1, math.floor((R - r) / (3)))) end)
  elseif id == "cloth5" then                     -- plaid: a woven tone with a cross-hatch of lines
    gfx.setPattern(DIAG)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
    around(12, function(px, py, a)
      gfx.drawLine(x + math.floor(r * math.cos(a) + 0.5), y + math.floor(r * math.sin(a) + 0.5),
                   x + math.floor(R * math.cos(a) + 0.5), y + math.floor(R * math.sin(a) + 0.5))
    end, 7)
  elseif id == "cloth6" then                     -- diamonds
    local q = math.max(2, math.floor((R - r) / (2)))
    around(12, function(px, py)
      gfx.drawLine(px, py - q, px + q, py); gfx.drawLine(px + q, py, px, py + q)
      gfx.drawLine(px, py + q, px - q, py); gfx.drawLine(px - q, py, px, py - q)
      gfx.drawPixel(px, py)
    end)
  elseif id == "cloth7" then                     -- coffee beans
    local q = math.max(2, math.floor((R - r) / (2)))
    around(12, function(px, py)
      gfx.fillEllipseInRect(px - q, py - q + 1, q * 2, q * 2 - 1)
      gfx.setColor(WHITE); gfx.drawLine(px - q + 1, py, px + q - 1, py + 1); gfx.setColor(BLACK)
    end, 15)
  elseif id == "cloth8" then                     -- little hearts
    local q = math.max(1, math.floor((R - r) / (3)))
    around(9, function(px, py)
      gfx.fillCircleAtPoint(px - q, py - q, q); gfx.fillCircleAtPoint(px + q, py - q, q)
      gfx.fillTriangle(px - 2 * q, py - q, px + 2 * q, py - q, px, py + 2 * q)
    end, 20)
  elseif id == "cloth9" then                     -- a bold border with a thin line inside it
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 2)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(x, y, r + 2)
  elseif id == "cloth10" then                    -- night sky
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(WHITE)
    around(14, function(px, py, a)
      gfx.drawPixel(px, py)
      if math.floor(a * 10) % 3 == 0 then
        gfx.drawPixel(px - 1, py); gfx.drawPixel(px + 1, py); gfx.drawPixel(px, py - 1); gfx.drawPixel(px, py + 1)
      end
    end, 9)
    gfx.setColor(BLACK)
  elseif id == "cloth11" then                    -- a zigzag edge
    for i = 0, 15 do
      local a0, a1 = math.rad(i * 22.5), math.rad(i * 22.5 + 22.5)
      local am = (a0 + a1) / 2
      gfx.fillTriangle(x + math.floor((r + 1) * math.cos(a0) + 0.5), y + math.floor((r + 1) * math.sin(a0) + 0.5),
                       x + math.floor((r + 1) * math.cos(a1) + 0.5), y + math.floor((r + 1) * math.sin(a1) + 0.5),
                       x + math.floor(R * math.cos(am) + 0.5), y + math.floor(R * math.sin(am) + 0.5))
    end
  elseif id == "cloth20" then                    -- pastel flowers round the rim, each a different colour
    local q = math.max(1, math.floor((R - r) / (3)))
    local k = 0
    UI.inkPush("none")
    around(10, function(px, py)
      k = k + 1
      UI.ink(CAFE.FLCOL[(k - 1) % 4 + 1]); gfx.setColor(BLACK)
      gfx.drawPixel(px, py - q); gfx.drawPixel(px - q, py); gfx.drawPixel(px + q, py); gfx.drawPixel(px, py + q)
      if q >= 2 then gfx.fillRect(px - 1, py - 1, 3, 3) end
      UI.ink("none"); gfx.setColor(WHITE); gfx.drawPixel(px, py)
    end, 18)
    UI.inkPop(); gfx.setColor(BLACK)
  elseif id == "cloth21" then                    -- green tea leaves round the rim
    local k = 0
    UI.inkPush("none")
    around(12, function(px, py, a)
      k = k + 1
      UI.ink((k % 2 == 0) and "fl_leaf" or "fl_leafdk"); gfx.setColor(BLACK)
      local tx, ty = math.floor(math.cos(a + math.pi / 2) + 0.5), math.floor(math.sin(a + math.pi / 2) + 0.5)    -- (along the rim)
      gfx.drawPixel(px, py); gfx.drawPixel(px + tx, py + ty); gfx.drawPixel(px - tx, py - ty)
      if R - r >= 6 then gfx.drawPixel(px + tx * 2, py + ty * 2); gfx.drawPixel(px + 1, py); gfx.drawPixel(px, py + 1) end
    end, 15)
    UI.inkPop(); gfx.setColor(BLACK)
  elseif id == "cloth12" then                    -- little flowers: four petals round a pale middle
    local q = math.max(1, math.floor((R - r) / (3)))
    around(10, function(px, py)
      if q <= 1 then
        gfx.drawPixel(px - 1, py); gfx.drawPixel(px + 1, py); gfx.drawPixel(px, py - 1); gfx.drawPixel(px, py + 1)
      else
        gfx.fillCircleAtPoint(px - q, py, q - 1); gfx.fillCircleAtPoint(px + q, py, q - 1)
        gfx.fillCircleAtPoint(px, py - q, q - 1); gfx.fillCircleAtPoint(px, py + q, q - 1)
        gfx.setColor(WHITE); gfx.drawPixel(px, py); gfx.setColor(BLACK)
      end
    end, 18)
  elseif id == "cloth13" then                    -- a wave running round the rim
    local amp = math.max(1, (R - r) / 2 - 1)
    local n, px0, py0 = 160, nil, nil
    for i = 0, n do
      local a = i * math.pi * 2 / n
      local rr = mid + amp * math.sin(a * 7)
      local px, py = x + math.floor(rr * math.cos(a) + 0.5), y + math.floor(rr * math.sin(a) + 0.5)
      if px0 then gfx.drawLine(px0, py0, px, py); if R - r >= 6 then gfx.drawLine(px0, py0 + 1, px, py + 1) end end
      px0, py0 = px, py
    end
  elseif id == "cloth14" then                    -- paw prints walking round the rim: a pad and three toes, toes to the outside
    local q = math.max(1, math.floor((R - r) / (3)))
    around(8, function(px, py, a)
      local ca, sa = math.cos(a), math.sin(a)
      local bx, by = px - math.floor(ca * q + 0.5), py - math.floor(sa * q + 0.5)
      if q <= 1 then gfx.fillRect(bx, by, 2, 2) else gfx.fillCircleAtPoint(bx, by, q) end
      for k = -1, 1 do
        local ta = a + k * 0.32
        local tr = mid + q + 1
        local tx, ty = x + math.floor(tr * math.cos(ta) + 0.5), y + math.floor(tr * math.sin(ta) + 0.5)
        if q <= 1 then gfx.drawPixel(tx, ty) else gfx.fillCircleAtPoint(tx, ty, math.max(1, q - 1)) end
      end
    end, 10)
  elseif id == "cloth15" then                    -- a vine winding round, a leaf at every bend
    local amp = math.max(0.6, (R - r) / 2 - 1.5)
    local n, px0, py0 = 160, nil, nil
    for i = 0, n do
      local a = i * math.pi * 2 / n
      local rr = mid + amp * math.sin(a * 8)
      local px, py = x + math.floor(rr * math.cos(a) + 0.5), y + math.floor(rr * math.sin(a) + 0.5)
      if px0 then gfx.drawLine(px0, py0, px, py) end
      px0, py0 = px, py
    end
    local big = (R - r) >= 6
    for i = 0, 15 do
      local a = (i + 0.25) * math.pi * 2 / 16                   -- just past each bend, a leaf on the side the vine bends away from
      local out = (i % 2 == 0) and -1 or 1
      local rr = mid + out * (big and 1.5 or 1)
      local lx, ly = x + math.floor(rr * math.cos(a) + 0.5), y + math.floor(rr * math.sin(a) + 0.5)
      if big then gfx.fillEllipseInRect(lx - 1, ly - 1, 3, 3); gfx.drawPixel(lx + math.floor(math.cos(a + 1.57) * 2 + 0.5), ly + math.floor(math.sin(a + 1.57) * 2 + 0.5))
      else gfx.drawPixel(lx, ly); gfx.drawPixel(lx + math.floor(math.cos(a + 1.57) + 0.5), ly + math.floor(math.sin(a + 1.57) + 0.5)) end
    end
  elseif id == "cloth16" then                    -- white snowflakes on a dark winter cloth
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(WHITE)
    local q = math.max(1, math.floor((R - r) / (3)))
    around(10, function(px, py, a)
      gfx.drawLine(px - q, py, px + q, py); gfx.drawLine(px, py - q, px, py + q)
      if q >= 2 then gfx.drawLine(px - q + 1, py - q + 1, px + q - 1, py + q - 1); gfx.drawLine(px - q + 1, py + q - 1, px + q - 1, py - q + 1) end
    end, 0)
    around(10, function(px, py) gfx.drawPixel(px, py) end, 18)
    gfx.setColor(BLACK)
  elseif id == "cloth17" then                    -- a hand-stitched ring of dashes, sewn just inside the hem
    local n = math.floor(mid * 1.6)
    for i = 0, n - 1, 2 do
      local a0, a1 = i * math.pi * 2 / n, (i + 1) * math.pi * 2 / n
      gfx.drawLine(x + math.floor(mid * math.cos(a0) + 0.5), y + math.floor(mid * math.sin(a0) + 0.5),
                   x + math.floor(mid * math.cos(a1) + 0.5), y + math.floor(mid * math.sin(a1) + 0.5))
    end
    if R - r >= 6 then gfx.drawCircleAtPoint(x, y, R - 2) end
  elseif id == "cloth18" then                    -- harlequin: dark and light wedges all the way round
    for i = 0, 15, 2 do
      local a0, a1 = math.rad(i * 22.5), math.rad(i * 22.5 + 22.5)
      local am = (a0 + a1) / 2
      local function P(rr, aa) return x + math.floor(rr * math.cos(aa) + 0.5), y + math.floor(rr * math.sin(aa) + 0.5) end
      local x1, y1 = P(r, a0); local x2, y2 = P(R, a0); local x3, y3 = P(R, am); local x4, y4 = P(R, a1); local x5, y5 = P(r, a1)
      gfx.fillPolygon(x1, y1, x2, y2, x3, y3, x4, y4, x5, y5)
    end
  elseif id == "cloth19" then                    -- thin rings, like the grain of a tree
    for rr = r + 1, R - 1, 2 do gfx.drawCircleAtPoint(x, y, rr) end
  else                                           -- lace: scalloped edge and a dotted ring
    for a = 0, 330, 30 do
      local rad = math.rad(a)
      local sx, sy = x + math.floor(R * math.cos(rad) + 0.5), y + math.floor(R * math.sin(rad) + 0.5)
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx, sy, math.max(2, math.floor(r / (6))))
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(sx, sy, math.max(2, math.floor(r / (6))))
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 1)
    gfx.setColor(BLACK)
    for a = 0, 345, 15 do
      local rad = math.rad(a)
      gfx.drawPixel(x + math.floor((r + 1) * math.cos(rad) + 0.5), y + math.floor((r + 1) * math.sin(rad) + 0.5))
    end
  end
  gfx.setColor(BLACK)
  if not noRim then gfx.drawCircleAtPoint(x, y, R) end
end

function CAFE.tableAt(x, y, r, cloth)
  if cloth then CAFE.clothAt(cloth, x, y, r) end
  UI.ink("tan")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.setLineWidth(1)
  UI.ink("none")
end

function CAFE.drawRug()
  for _, id in ipairs(CAFE.rugIds("rug")) do
    if CAFE.decorOn(id) then CAFE.rugAt(id, 112, 115, 190, 38) end      -- (up by the counter, so an oval rug under the tables barely meets it)
  end
end

-- ---- the window: frames and curtains -------------------------------------------------------------------
CAFE.FRAMES = { "wf1", "wf2", "wf3", "wf4", "wf5", "wf6" }
CAFE.CURTAINS = { "wc1", "wc2", "wc3", "wc4", "wc5", "wc6", "wc7", "wc8", "wc9", "wc10", "wc11", "wc12", "wc13", "wc14", "wc15", "wc16" }

CAFE.CURTCOL = { wc1 = "redp", wc2 = "gingham", wc3 = "mint", wc4 = "yellow", wc5 = "white", wc6 = "rose", wc7 = "tan", wc8 = "woodl",
                 wc9 = "blush", wc10 = "navyy", wc11 = "c_floral", wc12 = "c_cafe", wc13 = "c_velvet", wc14 = "c_matcha",
                 wc15 = "c_tartan", wc16 = "c_daisy" }                                              -- (PC colours)
CAFE.FRAMECOL = { wf1 = "woodl", wf2 = "white", wf3 = "brass", wf4 = "woodl", wf5 = "bark", wf6 = "forest" }
-- each curtain's fabric (the pattern sewn into the drape; both drapes are mirror images of each other)
CAFE.CURTPAT = { wc1 = "plain", wc2 = "check", wc3 = "stripe", wc6 = "polka", wc7 = "bean", wc9 = "heart", wc10 = "stars",
                 wc11 = "floral", wc13 = "velvet", wc14 = "matcha", wc15 = "plaid", wc16 = "daisy" }
CAFE.HEART3 = { { -1, 0 }, { 1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 0, 2 } }
-- one side curtain: a gathered heading along the rod, folds that pinch in to a sash tie-back (with a tassel), then flare
-- out to a hem at the bottom. dir = 1 hangs from the left edge (x0 is the window's side, the drape reaches in from it)
function CAFE.drape(x0, y0, wd, h, dir, style, sway)
  local function X(dx) return dir == 1 and (x0 + dx) or (x0 - dx) end
  local pinch, ty = 3 + sway, 12                         -- how far it's drawn in at the tie-back, and how far down that is
  local pat = CAFE.CURTPAT[style] or "plain"
  local dark = (pat == "stars" or pat == "velvet")
  local E = {}
  for v = 0, h - 1 do                                    -- how far in from the side the drape reaches, row by row
    if v <= ty then E[v] = wd - math.floor(pinch * v / ty + 0.5)
    else local t = (v - ty) / (h - 1 - ty); E[v] = wd - pinch + math.floor((pinch + 1) * (1 - (1 - t) * (1 - t)) + 0.5) end
  end
  UI.ink(CAFE.CURTCOL[style] or "redp")
  for v = 0, h - 1 do                                    -- the cloth
    gfx.setColor(dark and BLACK or WHITE)
    local a, b = X(0), X(E[v] - 1)
    gfx.fillRect(math.min(a, b), y0 + v, math.abs(b - a) + 1, 1)
    if pat == "daisy" and not UI.color then gfx.setPattern({ 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }); gfx.fillRect(math.min(a, b), y0 + v, math.abs(b - a) + 1, 1) end
  end
  local function inside(dx, v) return v >= 2 and v < h - 2 and dx >= 1 and dx <= E[v] - 2 and (v < ty or v > ty + 1) end
  local function dot(dx, v) if inside(dx, v) then gfx.drawPixel(X(dx), y0 + v) end end
  gfx.setColor(dark and WHITE or BLACK)
  -- the pattern (in the drape's own coordinates, so the two drapes mirror)
  if pat == "check" then                                 -- gingham: 2-pixel checks
    for v = 2, h - 3 do for dx = 1, wd do if (math.floor(dx / 2) + math.floor(v / 2)) % 2 == 0 then dot(dx, v) end end end
  elseif pat == "stripe" then
    for v = 2, h - 3 do for dx = 2, wd, 3 do dot(dx, v) end end
  elseif pat == "polka" then                             -- little round dots
    for v = 3, h - 4, 5 do
      local off = (math.floor(v / 5) % 2 == 0) and 2 or 5
      for dx = off, wd - 1, 6 do dot(dx, v); dot(dx + 1, v); dot(dx, v + 1); dot(dx + 1, v + 1) end
    end
  elseif pat == "bean" then                              -- coffee beans
    UI.ink("choc")
    for v = 4, h - 4, 6 do
      local off = (math.floor(v / 6) % 2 == 0) and 3 or 6
      for dx = off, wd - 2, 6 do dot(dx - 1, v); dot(dx, v); dot(dx + 1, v); dot(dx - 1, v + 1); dot(dx + 1, v + 1); dot(dx, v + 1) end
    end
    gfx.setColor(WHITE)
    for v = 4, h - 4, 6 do
      local off = (math.floor(v / 6) % 2 == 0) and 3 or 6
      for dx = off, wd - 2, 6 do if inside(dx + 1, v) and inside(dx - 1, v + 1) then gfx.drawPixel(X(dx), y0 + v + ((dir == 1) and 1 or 0)) end end
    end
    gfx.setColor(BLACK)
  elseif pat == "heart" then                             -- little hearts
    UI.ink("inkred")
    for v = 3, h - 5, 6 do
      local off = (math.floor(v / 6) % 2 == 0) and 3 or 6
      for dx = off, wd - 2, 6 do
        local ok = true
        for _, q in ipairs(CAFE.HEART3) do if not inside(dx + q[1], v + q[2]) then ok = false end end
        if ok then for _, q in ipairs(CAFE.HEART3) do dot(dx + q[1], v + q[2]) end end
      end
    end
  elseif pat == "stars" then                             -- a night sky: twinkles and a few little crosses
    UI.ink("yellow")
    for _, q in ipairs({ { 3, 4 }, { 7, 8 }, { 4, 15 }, { 8, 19 }, { 3, 21 }, { 6, 3 } }) do dot(q[1], q[2]) end
    for _, q in ipairs({ { 5, 10 }, { 3, 17 } }) do dot(q[1], q[2] - 1); dot(q[1] - 1, q[2]); dot(q[1], q[2]); dot(q[1] + 1, q[2]); dot(q[1], q[2] + 1) end
  elseif pat == "floral" or pat == "daisy" then          -- little flowers (pastel ones / white daisies with a yellow heart)
    local k = 0
    for v = 4, h - 4, 6 do
      local off = (math.floor(v / 6) % 2 == 0) and 3 or 6
      for dx = off, wd - 2, 6 do
        if inside(dx - 1, v) and inside(dx + 1, v) and inside(dx, v - 1) and inside(dx, v + 1) then
          k = k + 1
          if pat == "floral" then UI.ink(CAFE.FLCOL[(k % 4) + 1]); gfx.setColor(BLACK) else UI.ink("snow"); gfx.setColor(WHITE) end
          gfx.drawPixel(X(dx), y0 + v - 1); gfx.drawPixel(X(dx - 1), y0 + v); gfx.drawPixel(X(dx + 1), y0 + v); gfx.drawPixel(X(dx), y0 + v + 1)
          if pat == "daisy" then UI.ink("yellow"); gfx.setColor(BLACK); gfx.drawPixel(X(dx), y0 + v) end
        end
      end
    end
    gfx.setColor(BLACK)
  elseif pat == "matcha" then                            -- tea sprigs leaning in
    UI.ink("fl_leaf")
    for v = 4, h - 4, 6 do
      local off = (math.floor(v / 6) % 2 == 0) and 3 or 6
      for dx = off, wd - 2, 6 do dot(dx, v); dot(dx + 1, v - 1); dot(dx - 1, v + 1); dot(dx + 1, v) end
    end
  elseif pat == "plaid" then                             -- tartan: woven bands each way, a dark line down each
    for v = 2, h - 3 do for dx = 1, wd do
      local bx, by = (dx % 6) < 2, (v % 6) < 2
      if (bx and by) or ((bx or by) and (dx + v) % 2 == 0) then dot(dx, v) end
    end end
  end
  -- the folds (gathered in at the tie-back, falling out below), the heading's pleats, the hem
  UI.ink(CAFE.CURTCOL[style] or "redp")
  gfx.setColor(dark and WHITE or BLACK)
  if pat == "plain" or pat == "velvet" then
    for _, f in ipairs({ 0.36, 0.7 }) do
      for v = 2, h - 3 do
        if v < ty - 1 or v > ty + 3 then
          if not (pat == "velvet" and v % 2 == 1) then local dx = math.floor(E[v] * f + 0.5); if dx >= 1 and dx <= E[v] - 2 then gfx.drawPixel(X(dx), y0 + v) end end
        end
      end
    end
  end
  for dx = 1, E[0] - 2, 3 do gfx.drawPixel(X(dx), y0 + 1) end                  -- pleats along the top
  gfx.setColor(BLACK)
  if dark then UI.ink(pat == "velvet" and "brass" or CAFE.CURTCOL[style] or "redp") end
  for dx = 0, E[h - 2] - 1 do gfx.drawPixel(X(dx), y0 + h - 2) end           -- the hem
  UI.ink(CAFE.CURTCOL[style] or "redp")
  gfx.setColor(BLACK)
  for v = 0, h - 1 do gfx.drawPixel(X(E[v] - 1), y0 + v) end                  -- the inside edge
  for dx = 0, E[0] - 1 do gfx.drawPixel(X(dx), y0) end                          -- the top
  UI.ink("brass")                                                               -- the sash round it, and its tassel
  for v = ty, ty + 1 do for dx = 0, E[v] do gfx.drawPixel(X(dx), y0 + v) end end
  local tx = E[ty]
  gfx.drawPixel(X(tx), y0 + ty + 2); gfx.drawPixel(X(tx), y0 + ty + 3); gfx.drawPixel(X(tx - 1), y0 + ty + 4); gfx.drawPixel(X(tx), y0 + ty + 4); gfx.drawPixel(X(tx + 1), y0 + ty + 4)
end

function CAFE.windowBase(x, y, frame, preview)
  local w, h = 54, 26
  UI.ink("sky")
  gfx.setColor(WHITE)
  if frame == "wf5" then gfx.fillRoundRect(x, y, w, h, 12) else gfx.fillRect(x, y, w, h) end   -- (arched corners show the wall, not white)
  if preview then                                         -- (a little sky for the shop picture)
    UI.ink("skyp")
    gfx.setColor(BLACK)
    gfx.drawLine(x + 6, y + 18, x + 20, y + 16); gfx.drawLine(x + 30, y + 8, x + 44, y + 9)
    UI.ink("yellow")
    WIN.sunAt(x + 40, y + 14, 3, 0.3)
  else
    WIN.drawView(G.win, x + 1, y + 1, 1)
  end
end

function CAFE.windowTop(x, y, frame, curtain, preview, swayIn)
  local w, h = 54, 26
  UI.ink(CAFE.FRAMECOL[frame or "wf1"] or "woodl")
  if frame == "wf2" then UI.ink("gray") end
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  if frame == "wf5" then gfx.drawRoundRect(x, y, w, h, 12) else gfx.drawRect(x, y, w, h) end
  gfx.setLineWidth(1)
  if frame == nil or frame == "wf4" or frame == "wf5" then   -- the usual four panes
    gfx.drawLine(x + 27, y, x + 27, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf2" then                              -- six panes
    gfx.drawLine(x + 18, y, x + 18, y + h); gfx.drawLine(x + 36, y, x + 36, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf3" then                              -- diamond panes
    gfx.setClipRect(x + 1, y + 1, w - 2, h - 2)
    for xx = x - h, x + w, 11 do
      gfx.drawLine(xx, y, xx + h, y + h); gfx.drawLine(xx + h, y, xx, y + h)
    end
    gfx.clearClipRect()
  elseif frame == "wf6" then                              -- shutters folded open at both sides
    for _, sx in ipairs({ x + 1, x + w - 10 }) do
      gfx.setColor(WHITE); gfx.fillRect(sx, y + 1, 9, h - 2)
      gfx.setColor(BLACK); gfx.drawRect(sx, y + 1, 9, h - 2)
      for yy = y + 4, y + h - 4, 3 do gfx.drawLine(sx + 1, yy, sx + 7, yy) end
    end
  end
  if frame == "wf4" then                                  -- a sill with two little brackets
    gfx.fillRect(x - 3, y + h, w + 6, 3)
    gfx.fillRect(x + 5, y + h + 3, 5, 2); gfx.fillRect(x + w - 10, y + h + 3, 5, 2)
  end
  if curtain then
    UI.ink(CAFE.CURTCOL[curtain] or "redp")
    local sway = swayIn or 0
    if swayIn == nil and not preview and G and G.win and G.win.fx and G.win.fx.wind then sway = (math.floor(frames / (14))) % 2 end   -- they stir in the wind
    if curtain == "wc4" then                              -- a scalloped valance across the top: seven scallops, centred
      local mx = x + math.floor(w / 2)
      gfx.setColor(WHITE); gfx.fillRect(x - 1, y - 1, w + 2, 6)
      for i = -3, 3 do gfx.setColor(WHITE); gfx.fillCircleAtPoint(mx + i * 8, y + 5, 4); gfx.setColor(BLACK); gfx.drawCircleAtPoint(mx + i * 8, y + 5, 4) end
      gfx.setColor(WHITE); gfx.fillRect(x - 1, y - 1, w + 2, 5); gfx.setColor(BLACK)
      gfx.drawLine(x - 1, y + 3, x + w + 1, y + 3)
      for xx = mx - 24, mx + 24, 4 do gfx.drawPixel(xx, y + 1) end                   -- the gathers along the top
      for i = -3, 3 do gfx.drawPixel(mx + i * 8, y + 6); gfx.drawPixel(mx + i * 8, y + 7) end   -- a stitch down each scallop
    elseif curtain == "wc5" then                          -- sheer lace: a fine net, little lace flowers, a scalloped hem
      local mx = x + math.floor(w / 2)
      gfx.setColor(BLACK)
      for yy = y + 3, y + h - 5, 2 do
        for xx = mx - 24 + ((math.floor((yy - y) / 2)) % 2) * 2, mx + 24, 4 do gfx.drawPixel(xx, yy) end
      end
      for _, q in ipairs({ { -18, 9 }, { -6, 9 }, { 6, 9 }, { 18, 9 }, { -12, 16 }, { 0, 16 }, { 12, 16 } }) do
        local fx, fy = mx + q[1], y + q[2]
        gfx.setColor(WHITE); gfx.fillRect(fx - 2, fy - 2, 5, 5)
        gfx.setColor(BLACK); gfx.drawPixel(fx, fy - 2); gfx.drawPixel(fx, fy + 2); gfx.drawPixel(fx - 2, fy); gfx.drawPixel(fx + 2, fy)
        gfx.drawPixel(fx - 1, fy - 1); gfx.drawPixel(fx + 1, fy - 1); gfx.drawPixel(fx - 1, fy + 1); gfx.drawPixel(fx + 1, fy + 1)
      end
      for i = -4, 4 do gfx.drawCircleAtPoint(mx + i * 6, y + h - 3, 2) end
      gfx.drawLine(x + 1, y + 2, x + w - 1, y + 2)
    elseif curtain == "wc12" then                         -- cafe curtains: gingham half curtains on a rod across the middle, a little valance on top
      local mx = x + math.floor(w / 2)
      local function gingham(x0, y0, ww, hh)
        gfx.setColor(WHITE); gfx.fillRect(x0, y0, ww, hh)
        gfx.setColor(BLACK)
        for yy = y0, y0 + hh - 1 do for xx = x0, x0 + ww - 1 do
          if (math.floor((xx - mx) / 2) + math.floor((yy - y0) / 2)) % 2 == 0 then gfx.drawPixel(xx, yy) end
        end end
      end
      gingham(x + 1, y + 1, w - 2, 4)                                         -- the valance...
      gfx.setColor(BLACK); gfx.drawLine(x + 1, y + 5, x + w - 2, y + 5)
      for i = -6, 6 do gfx.drawPixel(mx + i * 4, y + 6) end                    -- ...with a little frill
      local top = y + 13
      gingham(x + 1, top + 1, 24, h - 15); gingham(mx + 2, top + 1, 24, h - 15)   -- two half curtains, a gap between
      gfx.setColor(BLACK)
      gfx.drawLine(x + 25, top + 1, x + 25, y + h - 2); gfx.drawLine(mx + 2, top + 1, mx + 2, y + h - 2)
      for xx = x + 2, x + 24, 3 do gfx.drawPixel(xx, top + 2) end
      for xx = mx + 3, mx + 25, 3 do gfx.drawPixel(xx, top + 2) end
      UI.ink("brass"); gfx.fillRect(x - 1, top, w + 2, 1)                       -- the cafe rod
    elseif curtain == "wc8" then                          -- blinds, pulled down a little over half way
      gfx.setColor(WHITE); gfx.fillRect(x + 1, y + 1, w - 2, 15)
      gfx.setColor(BLACK)
      for yy = y + 2, y + 15, 3 do gfx.drawLine(x + 1, yy, x + w - 1, yy) end
      gfx.drawLine(x + 1, y + 16, x + w - 1, y + 16)
      UI.ink("cream")
      gfx.drawLine(x + w - 6, y + 16, x + w - 6, y + 21); gfx.fillCircleAtPoint(x + w - 6, y + 22, 2)   -- the pull cord
    else                                                  -- two drapes with tie-backs
      CAFE.drape(x + 1, y + 1, 12, h - 2, 1, curtain, sway)
      CAFE.drape(x + w - 1, y + 1, 12, h - 2, -1, curtain, sway)
      UI.ink("brass")
      gfx.setColor(BLACK)
      gfx.fillRect(x - 2, y - 2, w + 4, 2)                -- the curtain rod
      gfx.fillCircleAtPoint(x - 3, y - 1, 2); gfx.fillCircleAtPoint(x + w + 3, y - 1, 2)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.windowAt(x, y, frame, curtain, preview)
  CAFE.windowBase(x, y, frame, preview)
  CAFE.windowTop(x, y, frame, curtain, preview, nil)
end

function CAFE.drawWindowNow()
  local frame, curtain = CAFE.ownedOf("frame"), CAFE.ownedOf("curtain")
  UI.liveDraw("win", 32, 16, 54, 32, CAFE.windowBase, 32, 22, frame, false)    -- the glass and what's outside move...
  local sway = 0
  if curtain and G and G.win and G.win.fx and G.win.fx.wind then sway = (math.floor(frames / (14))) % 2 end
  local st = G.winOv
  if not st then st = {}; G.winOv = st end
  local im = st[sway]
  if im == nil then                              -- ...the frame and curtains on top are drawn once
    st[sway] = false
    im = CAFE.snap(function() CAFE.windowTop(6, 8, frame, curtain, false, sway) end, 0, 40, 0, 66)
    st[sway] = im
  end
  if im then im:draw(26, 14) else CAFE.windowTop(32, 22, frame, curtain, false, sway) end
end

function CAFE.windowPreview(id, cx, cy)                 -- the shop picture: the window at 1.6 times its size
  CAFE.WPREV = CAFE.WPREV or {}
  local im = CAFE.WPREV[id]
  if im == nil then
    im = gfx.image.new(66, 40, gfx.kColorClear)
    gfx.pushContext(im)
    local isFrame = CAFE.byId[id].kind == "frame"
    CAFE.windowAt(6, 8, isFrame and id or nil, (not isFrame) and id or nil, true)
    gfx.popContext()
    CAFE.WPREV[id] = im
  end
  im:drawScaled(cx - 52, cy - 32, 1.6, 1.6)
end

for _, id in ipairs(CAFE.FRAMES) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end
for _, id in ipairs(CAFE.CURTAINS) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end

-- ---- pets --------------------------------------------------------------------------------------------
function CAFE.homeOf(kind)               -- where the pet's own furniture is (if you've put it out)
  local d = CAFE.dec()                           -- (your cafe, or a Rush Hour / Evening Chill room)
  local id = (kind == "cat") and "cattree" or ((kind == "dog") and "dogbed" or nil)      -- (turtles don't have a bed)
  if d and id and d.decor[id] == "on" and d.place[id] then
    local sl = CAFE.FSLOT[d.place[id]]
    return sl[1], sl[2]
  end
  return nil
end

-- ---- keeping pets off the tables and the floor decor --------------------------------------------------
-- The floor is cut into 6-pixel squares. A square is "taken" when it lies within a table (with its chairs) or a piece of floor decor
-- (plus a little margin), so a pet that plans its walk over the free squares only can never cross a filled spot. Each taken
-- square remembers which things cover it (one bit each), so a pet's own bed or tree can be let through for that pet alone.
CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH = 6, 12, 124, 64, 20       -- square size, left, top, columns, rows

function CAFE.petGrid()                          -- the squares that are taken (made once, when the shift starts or comes back from the shop)
  local g = G.petGrid
  if g then return g, g.obs end
  local obs = CAFE.obstacles()
  local C, X0, Y0, W, Hh = CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  local mask = {}
  for k, o in ipairs(obs) do
    local bit, rr = (1 << (k - 1)), o.r + 4
    local i0 = math.max(0, math.floor((math.min(o.x1, o.x2) - rr - X0) / C))
    local i1 = math.min(W - 1, math.ceil((math.max(o.x1, o.x2) + rr - X0) / C))
    local j0 = math.max(0, math.floor((math.min(o.y1, o.y2) - rr - Y0) / C))
    local j1 = math.min(Hh - 1, math.ceil((math.max(o.y1, o.y2) + rr - Y0) / C))
    for j = j0, j1 do
      for i = i0, i1 do
        if CAFE.dist(o, X0 + i * C, Y0 + j * C) < rr then mask[j * W + i] = ((mask[j * W + i] or 0) | bit) end
      end
    end
  end
  g = { obs = obs, mask = mask }
  G.petGrid = g
  return g, obs
end

function CAFE.petTaken(mask, n, ex)               -- is square n taken by anything but the things in ex?
  local m = mask[n]
  return m ~= nil and (m & ~ex) ~= 0
end

function CAFE.petCell(x, y)                       -- the square a point is in
  local C, W, Hh = CAFE.PGC, CAFE.PGW, CAFE.PGH
  local i = math.max(0, math.min(W - 1, math.floor((x - CAFE.PGX) / C + 0.5)))
  local j = math.max(0, math.min(Hh - 1, math.floor((y - CAFE.PGY) / C + 0.5)))
  return j * W + i
end

function CAFE.petLOS(g, ax, ay, bx, by, ex)       -- can a pet walk straight from a to b without touching a taken square?
  local mask, C, X0, Y0, W, Hh = g.mask, CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  local n = math.max(1, math.floor(math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2) / 3))
  for k = 1, n do
    local x, y = ax + (bx - ax) * k / n, ay + (by - ay) * k / n
    local i, j = math.floor((x - X0) / C + 0.5), math.floor((y - Y0) / C + 0.5)
    if i < 0 or i >= W or j < 0 or j >= Hh then return false end
    if CAFE.petTaken(mask, j * W + i, ex) then return false end
  end
  return true
end

-- Working out a walk is done a little at a time (a few squares a frame), so a pet that is deciding where to go never stalls the game.
function CAFE.petSearch(g, si, gi, ex)            -- start looking for a way from square si to square gi over free squares
  return { g = g, si = si, gi = gi, nex = ~ex, best = { [si] = 0 }, from = { [si] = si }, done = {},
           hk = { 0 }, hv = { si }, hn = 1 }
end

function CAFE.petStep(st, budget)                 -- look at up to `budget` squares: the way (a list of squares) when found, false if there is none, nil if still looking
  local mask, W, Hh, nex = st.g.mask, CAFE.PGW, CAFE.PGH, st.nex
  local gx, gy, gi, si = st.gi % W, math.floor(st.gi / (W)), st.gi, st.si
  local best, from, done, hk, hv, hn = st.best, st.from, st.done, st.hk, st.hv, st.hn
  while hn > 0 and budget > 0 do
    local cur = hv[1]
    local lk, lv = hk[hn], hv[hn]
    hk[hn], hv[hn] = nil, nil
    hn = hn - 1
    if hn > 0 then
      local i = 1
      while true do
        local l = i * 2
        if l > hn then break end
        if l < hn and hk[l + 1] < hk[l] then l = l + 1 end
        if hk[l] < lk then hk[i], hv[i] = hk[l], hv[l]; i = l else break end
      end
      hk[i], hv[i] = lk, lv
    end
    if not done[cur] then
      done[cur] = true
      budget = budget - 1
      if cur == gi then
        local path, c = {}, cur
        while c ~= si do path[#path + 1] = c; c = from[c] end
        for a = 1, math.floor(#path / (2)) do path[a], path[#path + 1 - a] = path[#path + 1 - a], path[a] end
        return path
      end
      local ci, cj, cg = cur % W, math.floor(cur / (W)), best[cur]
      for dj = -1, 1 do
        for di = -1, 1 do
          local ni, nj = ci + di, cj + dj
          if (di ~= 0 or dj ~= 0) and ni >= 0 and ni < W and nj >= 0 and nj < Hh then
            local n = nj * W + ni
            local m = mask[n]
            if not done[n] and (m == nil or (m & nex) == 0) then
              local ok = true
              if di ~= 0 and dj ~= 0 then                                   -- (a diagonal step may not cut between two taken squares)
                local m1, m2 = mask[cj * W + ni], mask[nj * W + ci]
                ok = (m1 == nil or (m1 & nex) == 0) and (m2 == nil or (m2 & nex) == 0)
              end
              if ok then
                local ng = cg + ((di ~= 0 and dj ~= 0) and 1.4142 or 1)
                if best[n] == nil or ng < best[n] then
                  best[n], from[n] = ng, cur
                  local dx, dy = math.abs(ni - gx), math.abs(nj - gy)
                  local f = ng + dx + dy - 0.5858 * math.min(dx, dy)
                  hn = hn + 1
                  local i = hn
                  while i > 1 do
                    local pi = math.floor(i / (2))
                    if hk[pi] > f then hk[i], hv[i] = hk[pi], hv[pi]; i = pi else break end
                  end
                  hk[i], hv[i] = f, n
                end
              end
            end
          end
        end
      end
    end
  end
  st.hn = hn
  if hn == 0 then return false end
  return nil
end

function CAFE.petCorners(g, path, sx, sy, tx, ty, ex)    -- the corners to go round on the way from (sx, sy) to (tx, ty): the squares of the way, pulled straight where a pet can see ahead
  local W, C, X0, Y0 = CAFE.PGW, CAFE.PGC, CAFE.PGX, CAFE.PGY
  local cells = {}
  for k, n in ipairs(path) do cells[k] = { X0 + (n % W) * C, Y0 + (math.floor(n / (W))) * C } end
  local out, ax, ay, k = {}, sx, sy, 1
  while k <= #cells do
    if CAFE.petLOS(g, ax, ay, tx, ty, ex) then break end         -- the goal is in sight from here: no more corners
    local best, j = k, k
    while j <= #cells and CAFE.petLOS(g, ax, ay, cells[j][1], cells[j][2], ex) do best = j; j = j + 1 end
    out[#out + 1] = cells[best]
    ax, ay = cells[best][1], cells[best][2]
    k = best + 1
  end
  return out
end

function CAFE.petAim(kind, p)                     -- pick the next place for a pet to go and start looking for the way: false if it is boxed in
  local th = p.think
  local g, obs = CAFE.petGrid()
  local C, X0, Y0, W, Hh, mask = CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH, g.mask
  if th == nil then
    local hx, hy = CAFE.homeOf(kind)
    local ex = 0
    if hx then for k, o in ipairs(obs) do if o.x1 == hx and o.y1 == hy + 6 then ex = (1 << (k - 1)) end end end   -- (its own bed or tree is open to it)
    th = { ex = ex, sx = p.x, sy = p.y, tries = 0, hx = hx, hy = hy }
    local si = CAFE.petCell(p.x, p.y)
    if CAFE.petTaken(mask, si, ex) then            -- standing inside something: step out to the nearest free square first
      local ci, cj, bestN, bd = si % W, math.floor(si / (W)), nil, 1e9
      for dj = -6, 6 do
        for di = -6, 6 do
          local ni, nj = ci + di, cj + dj
          if ni >= 0 and ni < W and nj >= 0 and nj < Hh and not CAFE.petTaken(mask, nj * W + ni, ex) and di * di + dj * dj < bd then
            bestN, bd = nj * W + ni, di * di + dj * dj
          end
        end
      end
      if not bestN then return false end
      si = bestN
      th.first = { X0 + (si % W) * C, Y0 + (math.floor(si / (W))) * C }
      th.sx, th.sy = th.first[1], th.first[2]
    end
    th.si = si
    p.think = th
  end
  th.tries, th.picks = th.tries + 1, (th.picks or 0) + 1
  if th.tries > 4 or th.picks > 14 then p.think = nil; return false end
  if th.tries == 1 and th.hx and not p.home and math.random() < ((kind == "dog") and 0.65 or 0.45) then     -- off to its own bed or tree
    th.tx, th.ty, th.home = th.hx, th.hy + ((kind == "cat") and 14 or 10), true
  else
    local i = math.random(math.ceil((50 - X0) / C), math.floor((380 - X0) / C))
    local j = math.random(math.ceil((126 - Y0) / C), math.floor((226 - Y0) / C))
    local x, y = X0 + i * C, Y0 + j * C
    if mask[j * W + i] ~= nil or (x - p.x) ^ 2 + (y - p.y) ^ 2 <= 400 then th.st, th.tries = nil, th.tries - 1; return true end   -- (not a good spot: pick again next frame)
    th.tx, th.ty, th.home = x + math.random(-2, 2), y + math.random(-2, 2), false
  end
  th.st = CAFE.petSearch(g, th.si, CAFE.petCell(th.tx, th.ty), th.ex)
  return true
end

function CAFE.petThink(kind, p)                   -- a pet that is deciding: a few squares of looking each frame; sets it walking when the way is found
  local th = p.think
  if th == nil or th.st == nil then
    if not CAFE.petAim(kind, p) then p.think = nil; p.wait = 1 + math.random() * 2 end       -- boxed in: have another look in a moment
    return
  end
  local res = CAFE.petStep(th.st, 30)
  if res == nil then return end
  if res == false then th.st = nil; return end                                   -- no way there: try another place
  local g = CAFE.petGrid()
  local wp = CAFE.petCorners(g, res, th.sx, th.sy, th.tx, th.ty, th.ex)
  if th.first then table.insert(wp, 1, th.first) end
  p.tx, p.ty, p.home, p.wp = th.tx, th.ty, th.home, wp
  p.mode, p.think = "walk", nil
end

function CAFE.petPlace(p)                         -- a pet that has just arrived starts on a free bit of floor
  local g = CAFE.petGrid()
  local cand, C, X0, Y0, W, Hh = {}, CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  for j = 0, Hh - 1 do
    for i = 0, W - 1 do
      local x, y = X0 + i * C, Y0 + j * C
      if g.mask[j * W + i] == nil and x >= 60 and x <= 340 and y >= 130 and y <= 220 then cand[#cand + 1] = { x, y } end
    end
  end
  if #cand > 0 then
    local c = cand[math.random(#cand)]
    p.x, p.y = c[1] + math.random(-2, 2), c[2] + math.random(-2, 2)
  end
  p.fresh = nil
end

function CAFE.makePets(d)                       -- (d: the decor showing: your cafe, or a Rush Hour / Evening Chill room)
  local pets = {}
  d = d or CAFE.cur
  for _, kind in ipairs({ "cat", "dog", "turtle", "bunny" }) do
    local var = CAFE.petOn(d, kind)
    if var then
      pets[kind] = { var = var, x = 60 + math.random() * 280, y = 130 + math.random() * 90, tx = 0, ty = 0,
                     mode = "idle", wait = 1 + math.random() * 3, dir = 1, home = false, fresh = true,
                     pose = (kind == "cat") and "sit" or "sit" }
    end
  end
  if d.hball then                                         -- hamsters out of their cages, rolling round in a ball
    for _, it in ipairs(CAFE.ITEMS) do
      if it.ham and d.hball[it.id] == true and d.decor[it.id] == "on" and d.place[it.id] then
        pets["ham:" .. it.id] = { kind = "hamball", var = it.id, x = 60 + math.random() * 280, y = 130 + math.random() * 90, tx = 0, ty = 0,
                                  mode = "idle", wait = 1 + math.random() * 2, dir = 1, home = false, fresh = true, pose = "sit", roll = 0 }
      end
    end
  end
  return pets
end

function CAFE.updatePets(dt)
  CAFE.birdsUpdate(dt)
  for key, p in pairs(G.pets) do
    local kind = p.kind or key
    local speed = (kind == "cat") and 20 or ((kind == "turtle") and 9 or ((kind == "hamball") and 30 or ((kind == "bunny") and 24 or 26)))
    if p.fresh then CAFE.petPlace(p) end                  -- (first thing: stand on a free bit of floor, not on a table)
    if p.mode == "walk" then
      local gx, gy = p.tx, p.ty
      local via = p.wp and p.wp[1]
      if via then gx, gy = via[1], via[2] end
      local dx, dy = gx - p.x, gy - p.y
      local dist = math.sqrt(dx * dx + dy * dy)
      if via and dist <= speed * dt then          -- reached a corner of the detour: carry on to the next
        p.x, p.y = gx, gy
        table.remove(p.wp, 1)
      elseif dist <= speed * dt then
        p.x, p.y = p.tx, p.ty
        p.mode = p.home and "rest" or "idle"
        if kind == "cat" then
          p.pose = (math.random() < (p.home and 0.7 or 0.45)) and "sleep" or "sit"
        elseif kind == "turtle" then
          p.pose = (math.random() < 0.4) and "hide" or "sit"
        elseif kind == "bunny" then
          p.pose = (math.random() < 0.35) and "sleep" or "sit"
        elseif kind == "hamball" then
          p.pose = "sit"
        else
          p.pose = p.home and "lie" or ((math.random() < 0.55) and "sit" or "lie")
        end
        local sleepy = (p.pose == "sleep" or p.pose == "lie" or p.pose == "hide")
        p.wait = p.home and (12 + math.random() * 14) or (sleepy and (7 + math.random() * 9) or (2 + math.random() * 5))
      else
        p.x = p.x + dx / dist * speed * dt
        p.y = p.y + dy / dist * speed * dt
        if math.abs(dx) > 1 then p.dir = dx > 0 and 1 or -1 end
        if p.roll then p.roll = p.roll + p.dir * speed * dt / 7 end          -- (the hamster ball turns as it rolls)
      end
    else
      p.wait = p.wait - dt
      if p.wait <= 0 then
        CAFE.petThink(kind, p)                                -- (works out a way to a spot it can really get to, round the tables and the floor decor)
        if kind == "hamball" and p.mode ~= "walk" and p.think == nil then p.wait = 0.5 + math.random() * 1.5 end   -- (a hamster hardly ever stops)
      end
    end
  end
end

-- a floating "z" for sleepers
function CAFE.zzz(x, y)
  UI.inkPush("inkblue")
  local k = (math.floor(frames / (18))) % 3
  for i = 0, 1 do
    local zy = y - 5 - i * 6 - k
    local sz = 2 + i
    gfx.drawLine(x + i * 4, zy, x + i * 4 + sz, zy)
    gfx.drawLine(x + i * 4 + sz, zy, x + i * 4, zy + sz)
    gfx.drawLine(x + i * 4, zy + sz, x + i * 4 + sz, zy + sz)
  end
  UI.inkPop()
end

-- an ear: black, with a thin white edge so it shows up against the black head
function CAFE.ear(x1, y1, x2, y2, x3, y3)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  gfx.setColor(WHITE)
  gfx.drawLine(x1, y1, x3, y3)
  gfx.setColor(BLACK)
end

-- x, y = where the feet are. cat: walk / sit / sleep.  dog: walk / sit / lie
-- ---- turtles: slow little shells (they walk, look about, or tuck right in) -----------------------------
CAFE.TSPEC = {                                       -- w = half the shell's width, h = how tall the dome is, leg = leg length
  turtle    = { w = 8,  h = 8,  leg = 3, st = "hex" },
  boxturtle = { w = 7,  h = 9,  leg = 3, st = "dots" },
  tortoise  = { w = 10, h = 11, leg = 4, st = "grid", head = 3 },
  slider    = { w = 9,  h = 6,  leg = 3, st = "stripes" },
}
CAFE.TDOME = {}
function CAFE.domeRows(w, h)                         -- how wide the shell is on every row (bottom row first), worked out once
  local key = w * 100 + h
  local t = CAFE.TDOME[key]
  if not t then
    t = {}
    for r = 0, h - 1 do t[r] = math.floor(w * math.sqrt(1 - ((r + 0.5) / h) ^ 2) + 0.5) end
    CAFE.TDOME[key] = t
  end
  return t
end

function CAFE.turtle(x, y, d, pose, var)             -- x, y = where the feet are. poses: walk / sit / hide
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.TSPEC[var] or CAFE.TSPEC.turtle
  local w, h, leg = sp.w, sp.h, sp.leg
  local hid = (pose == "hide")
  local yb = hid and (y - 1) or (y - leg)             -- the row the shell sits on
  local rows = CAFE.domeRows(w, h)
  local col = CAFE.TCOL[var] or CAFE.TCOL.turtle
  UI.ink(col[1])
  gfx.setColor(BLACK)
  for r = 0, h - 1 do gfx.drawLine(x - rows[r], yb - r, x + rows[r], yb - r) end
  gfx.fillRect(x - w, yb, w * 2 + 1, 2)                -- the flat underside
  if not hid then
    UI.ink(col[2])
    local walk = (pose == "walk")
    local st = walk and ((math.floor(frames / (7))) % 2) or 0
    gfx.fillRect(x + d * (w - 3) - 1, yb + 2, 3, leg - 1 - st)           -- front foot
    gfx.fillRect(x - d * (w - 3) - 1, yb + 2, 3, leg - 2 + st)           -- back foot
    gfx.drawLine(x - d * w, yb + 1, x - d * (w + 3), yb + 2)             -- a stubby tail
    local hr = sp.head or 2
    local bob = walk and ((math.floor(frames / (9))) % 2) or 0
    local up = (pose == "sit") and 2 or 0                                -- looking about: the neck stretches up
    local hx, hy = x + d * (w + 3 + hr), yb - up - bob
    gfx.setLineWidth(hr + 1)
    gfx.drawLine(x + d * (w - 1), yb + 1, hx - d, hy)                    -- the neck
    gfx.setLineWidth(1)
    gfx.fillCircleAtPoint(hx, hy, hr)
    gfx.setColor(WHITE)
    gfx.drawPixel(hx + d, hy - 1)                                         -- an eye
    if var == "slider" then UI.ink("redp"); gfx.drawPixel(hx - d * 2, hy); gfx.drawPixel(hx - d * 2, hy + 1) end   -- the red ear patch
  else
    gfx.setColor(WHITE)
  end
  UI.ink(col[1])
  gfx.setColor(WHITE)                                   -- the pattern on the shell
  local m = yb - math.floor(h / (2))
  if sp.st == "hex" then
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x - 2, yb - h + 2, x - 3, m); gfx.drawLine(x + 2, yb - h + 2, x + 3, m)
    gfx.drawLine(x - 3, m, x - 5, yb - 1); gfx.drawLine(x + 3, m, x + 5, yb - 1)
  elseif sp.st == "dots" then
    gfx.drawPixel(x, yb - h + 3); gfx.drawPixel(x - 3, m + 1); gfx.drawPixel(x + 3, m + 1)
    gfx.drawPixel(x, m); gfx.drawPixel(x - 2, yb - 2); gfx.drawPixel(x + 2, yb - 2)
  elseif sp.st == "grid" then
    gfx.drawLine(x - 6, yb - 3, x + 6, yb - 3); gfx.drawLine(x - 4, yb - 7, x + 4, yb - 7)
    gfx.drawLine(x, yb - h + 2, x, yb - 3); gfx.drawLine(x - 4, yb - 7, x - 5, yb - 1); gfx.drawLine(x + 4, yb - 7, x + 5, yb - 1)
  else                                                  -- stripes
    gfx.drawLine(x - 6, yb - 2, x + 6, yb - 2); gfx.drawLine(x - 4, yb - 4, x + 4, yb - 4)
    gfx.drawPixel(x, yb - h + 2)
  end
  gfx.setColor(BLACK)
  if hid then CAFE.zzz(x + d * (w + 1), yb - h) end
end

-- the PC colours: each coat is a (body, markings) pair; turtles are { shell, skin }; cats get coloured eyes
CAFE.PETCOL = { cat = "pcat", tuxcat = "ptux", tabbycat = "ptabby", calicocat = "pcalico", graycat = "pgray",
                dog = "pchoc", dalmatian = "pdal", husky = "phusky", patchdog = "ppatch", goldendog = "pgold", corgi = "pgold", tricorgi = "ppatch" }
CAFE.PETEYE = { cat = "yellow", tuxcat = "leaf", tabbycat = "leaf", calicocat = "yellow", graycat = "yellow" }
CAFE.TCOL = { turtle = { "tsh1", "olive" }, boxturtle = { "tsh2", "bark" }, tortoise = { "tsh3", "tan" }, slider = { "tsh4", "forest" } }
function CAFE.pet(kind, x, y, dir, pose, var)
  if kind == "turtle" then CAFE.turtle(x, y, dir, pose, var); UI.ink("none"); return end
  if kind == "bunny" then CAFE.bunny(x, y, dir, pose, var); UI.ink("none"); return end
  UI.ink(CAFE.PETCOL[var or kind] or "pcat")
  CAFE.petBody(kind, x, y, dir, pose, var)
  if var and var ~= "cat" and var ~= "dog" then CAFE.petCoat(kind, var, math.floor(x), math.floor(y), dir, pose) end
  UI.ink("none")
end

-- coat markings drawn over the plain black pet (white marks, or a grey dither)
function CAFE.petCoat(kind, var, x, y, dir, pose)
  local bx, by, hw, hh, hx, hy                      -- body centre and half sizes, head centre
  if kind == "cat" then
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 5, 6, 3, x + dir * 7, y - 9
    elseif pose == "sleep" then bx, by, hw, hh, hx, hy = x, y - 4, 8, 3, x + dir * 6, y - 5
    else bx, by, hw, hh, hx, hy = x, y - 5, 4, 4, x + dir, y - 12 end
  else
    local sp = CAFE.PETSPEC[var] or CAFE.PETSPEC.dog
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 8 - sp.up, 9 + sp.bl, 4, x + dir * (10 + sp.bl), y - 14 - sp.up
    elseif pose == "lie" then bx, by, hw, hh, hx, hy = x, y - 4, 9 + sp.bl, 3, x + dir * (10 + sp.bl), y - 4
    else bx, by, hw, hh, hx, hy = x - 2, y - 6, 5, 4, x + dir * 3, y - 19 - math.floor(sp.up / (2)) end
  end
  local function grey(cx, cy, w, h)
    gfx.setColor(BLACK); gfx.setPattern(CHECK)
    gfx.fillEllipseInRect(cx - w, cy - h, w * 2, h * 2)
    gfx.setColor(BLACK)
  end
  gfx.setColor(WHITE)
  if var == "tuxcat" then                          -- white bib, belly and a pale nose
    gfx.fillEllipseInRect(bx - 2, by, 5, hh)
    gfx.drawPixel(hx + dir, hy + 1)
    gfx.drawLine(hx, hy + 2, hx + dir, hy + 2)
  elseif var == "tabbycat" then                    -- stripes across the back
    for i = -3, 3, 3 do                              -- wobbly stripes, not ruler-straight
      gfx.drawLine(bx + i, by - hh + 1, bx + i + 1, by)
      gfx.drawLine(bx + i + 1, by, bx + i, by + hh - 1)
    end
  elseif var == "calicocat" then                   -- patches
    gfx.fillEllipseInRect(bx - hw + 1, by - hh + 1, 4, 3)
    gfx.fillEllipseInRect(bx + 1, by, 4, 3)
    gfx.drawPixel(hx - dir, hy - 2)
  elseif var == "graycat" then
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1)                   -- (the head stays dark so the face shows)
  elseif var == "dalmatian" then                   -- spots all over
    gfx.fillCircleAtPoint(bx - hw + 2, by - 1, 1); gfx.fillCircleAtPoint(bx + 1, by + 1, 1)
    gfx.fillCircleAtPoint(bx + hw - 3, by - 1, 1); gfx.fillCircleAtPoint(bx - 2, by - 2, 1)
    gfx.fillCircleAtPoint(bx + 3, by - 2, 1); gfx.fillCircleAtPoint(bx - hw + 3, by + 2, 1)
    gfx.drawPixel(hx - dir * 2, hy - 2)
  elseif var == "husky" then                       -- grey coat, white face mask and belly
    gfx.setColor(BLACK); grey(bx, by, hw + 1, hh + 1); gfx.setColor(WHITE)
    gfx.drawLine(hx + (dir > 0 and 2 or -6), hy + 2, hx + (dir > 0 and 6 or -2), hy + 2)      -- pale muzzle
    gfx.drawLine(hx, hy - 3, hx, hy - 1)                                                       -- the blaze
  elseif var == "patchdog" then                    -- one white patch and a white chest
    gfx.fillEllipseInRect(bx + dir * 2 - 2, by - hh + 1, 5, 4)         -- a white patch on the back
    gfx.fillEllipseInRect(bx - dir * 4 - 1, by, 3, 3)                   -- and one on the haunch
    gfx.drawLine(hx, hy - 3, hx, hy - 1)                                -- a little blaze
  elseif var == "goldendog" then                   -- a pale golden coat (ears and nose stay dark)
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1); grey(hx, hy, 3, 3)
  elseif var == "corgi" or var == "tricorgi" then  -- corgis: a white chest and belly, a white blaze and muzzle (red ones are a pale tan all over)
    if var == "corgi" then gfx.setColor(BLACK); grey(bx, by, hw + 1, hh + 1); grey(hx, hy, 3, 3); gfx.setColor(WHITE) end
    if pose == "sit" then gfx.fillEllipseInRect(hx + (dir > 0 and -2 or -3), by - hh, 5, hh * 2)
    else gfx.fillEllipseInRect(bx - 3, by, 7, hh) end
    gfx.drawLine(hx, hy - 3, hx, hy)
    gfx.drawLine(hx + (dir > 0 and 2 or -5), hy + 2, hx + (dir > 0 and 5 or -2), hy + 2)
  end
  gfx.setColor(BLACK)
  CAFE.petEyes(kind, var, x, y, dir, pose)
end

function CAFE.petEyes(kind, var, x, y, d, pose)   -- the coats paint over the face, so the eyes go back on top
  local sp = CAFE.PETSPEC[var] or CAFE.PETSPEC[kind]
  gfx.setColor(WHITE)
  if kind == "cat" then
    if pose ~= "sleep" then UI.ink(CAFE.PETEYE[var] or "yellow") end
    local f = sp.fat
    if pose == "walk" then gfx.drawPixel(x + d * 8, y - 10); gfx.drawPixel(x + d * 6, y - 10)
    elseif pose == "sleep" then gfx.drawLine(x + d * 5, y - 5, x + d * 7, y - 5)
    else gfx.drawPixel(x + d - 1, y - 12 - math.floor(f / (2))); gfx.drawPixel(x + d + 2, y - 12 - math.floor(f / (2))) end
  else
    local bl, up = sp.bl, sp.up
    local hs = (sp.hr or 4) - 4
    local ex, ey
    if pose == "walk" then ex, ey = x + d * (11 + bl), y - 15 - up - hs
    elseif pose == "lie" then
      gfx.drawLine(x + d * (9 + bl), y - 5, x + d * (11 + bl), y - 5)
      gfx.setColor(BLACK); return
    else ex, ey = x + d * 4, y - 20 - math.floor(up / (2)) - hs end
    if var == "husky" or var == "goldendog" or var == "corgi" then   -- grey face: a small white patch with black eyes
      gfx.fillRect(math.min(ex, ex + d) - 1, ey - 1, 4, 3)
      gfx.setColor(BLACK); gfx.drawPixel(ex, ey); gfx.drawPixel(ex + d, ey)
      return
    end
    gfx.drawPixel(ex, ey); gfx.drawPixel(ex + d, ey)
  end
  gfx.setColor(BLACK)
end

CAFE.PETSPEC = {                                    -- every coat has its own ears, tail and shape
  cat      = { ears = "point", fat = 0, tail = { len = 1.0, g = 1 } },     -- tails differ only in length and thickness
  tuxcat   = { ears = "tall",  fat = 0, tail = { len = 1.35, g = 1 } },
  tabbycat = { ears = "tuft",  fat = 1, tail = { len = 0.45, g = 2 } },
  calicocat = { ears = "point", fat = 1, tail = { len = 1.1, g = 3 } },
  graycat  = { ears = "short", fat = 2, tail = { len = 0.8, g = 2 } },
  dog       = { ears = "floppy", up = 0,  sn = 5, tail = { len = 1.0, g = 1 }, bl = 0, thick = 0 },
  dalmatian = { ears = "fold",   up = 3,  sn = 6, tail = { len = 1.3, g = 1 }, bl = 0, thick = 0 },
  husky     = { ears = "point",  up = 0,  sn = 4, tail = { len = 0.9, g = 2 }, bl = 1, thick = 1 },
  patchdog  = { ears = "long",   up = -2, sn = 4, tail = { len = 0.5, g = 2 }, bl = 2, thick = 0 },
  goldendog = { ears = "floppy", up = 0,  sn = 6, tail = { len = 1.2, g = 3 }, bl = 2, thick = 2 },
  corgi     = { ears = "point",  up = -2, sn = 4, tail = { len = 0.3, g = 3 }, bl = 3, thick = 1 },
  tricorgi  = { ears = "point",  up = -2, sn = 4, tail = { len = 0.3, g = 3 }, bl = 3, thick = 1 },
}

function CAFE.catEars(hx, hy, d, kind, sit, tipH)
  local tall = (kind == "tall") and 3 or 0
  if sit then
    if kind == "short" then
      CAFE.ear(hx - 3, hy - 2, hx - 3, hy - 6, hx, hy - 3)
      CAFE.ear(hx + 3, hy - 2, hx + 3, hy - 6, hx, hy - 3)
    elseif kind == "round" then
      gfx.fillCircleAtPoint(hx - 3, hy - 4, 2); gfx.fillCircleAtPoint(hx + 3, hy - 4, 2)
    elseif kind == "fold" then
      gfx.fillRect(hx - 5, hy - 5, 4, 2); gfx.fillRect(hx + 2, hy - 5, 4, 2)
    else
      CAFE.ear(hx - 3, hy - 2, hx - 3, hy - 6 - tall, hx, hy - 3)
      CAFE.ear(hx + 3, hy - 2, hx + 3, hy - 6 - tall, hx, hy - 3)
      if kind == "tuft" then gfx.drawPixel(hx - 3, hy - 7); gfx.drawPixel(hx + 3, hy - 7) end
    end
    return
  end
  if kind == "round" then
    gfx.fillCircleAtPoint(hx - d, hy - 4, 2); gfx.fillCircleAtPoint(hx + d * 2, hy - 3, 2)
  elseif kind == "short" then
    CAFE.ear(hx - d * 2, hy - 2, hx - d, hy - 6, hx + d, hy - 2)
    CAFE.ear(hx + d, hy - 2, hx + d * 3, hy - 5, hx + d * 3, hy - 1)
  elseif kind == "fold" then
    gfx.fillRoundRect(hx - 2, hy - 5, 5, 3, 1)
  else
    CAFE.ear(hx - d * 2, hy - 2, hx - d, hy - 2 - tipH - tall, hx + d, hy - 2)
    CAFE.ear(hx + d, hy - 2, hx + d * 3, hy - 1 - tipH - tall, hx + d * 3, hy - 1)
    if kind == "tuft" then gfx.drawPixel(hx - d, hy - 3 - tipH); gfx.drawPixel(hx + d * 3, hy - 2 - tipH) end
  end
end

function CAFE.tailLine(t, bx, by, ex, ey)        -- a tail is a line: t.len says how long, t.g how thick
  ex = bx + (ex - bx) * t.len; ey = by + (ey - by) * t.len
  ex, ey = math.floor(ex + 0.5), math.floor(ey + 0.5)
  gfx.drawLine(bx, by, ex, ey)
  if t.g >= 2 then gfx.drawLine(bx, by + 1, ex, ey + 1) end
  if t.g >= 3 then gfx.drawLine(bx, by - 1, ex, ey - 1); gfx.drawLine(bx + 1, by, ex + 1, ey) end
end

function CAFE.catTail(t, d, bx, by, mx, my, ex, ey)
  mx = bx + (mx - bx) * 1.0
  -- two segments, stretched by the tail's length
  local sx, sy = bx + (mx - bx) * t.len, by + (my - by) * t.len
  local fx, fy = bx + (ex - bx) * t.len, by + (ey - by) * t.len
  sx, sy, fx, fy = math.floor(sx + 0.5), math.floor(sy + 0.5), math.floor(fx + 0.5), math.floor(fy + 0.5)
  for o = 0, t.g - 1 do
    local oy = (o == 0) and 0 or ((o % 2 == 1) and 1 or -1)
    gfx.drawLine(bx, by + oy, sx, sy + oy); gfx.drawLine(sx, sy + oy, fx, fy + oy)
  end
end

function CAFE.dogEars(hx, hy, d, kind)
  if kind == "point" then
    CAFE.ear(hx - 2 * d, hy - 3, hx - d, hy - 9, hx + d, hy - 3)
    CAFE.ear(hx + d, hy - 3, hx + 3 * d, hy - 8, hx + 3 * d, hy - 2)
  elseif kind == "long" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 3 * d, hy - 3, hx - d, hy + 8)
  elseif kind == "fold" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 4, hx + 2 * d, hy + 1)
  else
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 3, hx, hy + 5)
  end
end

function CAFE.dogTail(t, d, bx, by, ex, ey)
  CAFE.tailLine(t, bx, by, ex, ey)
end

function CAFE.petBody(kind, x, y, dir, pose, var)
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.PETSPEC[var or kind] or CAFE.PETSPEC[kind]
  gfx.setColor(BLACK)
  local step = math.floor(math.sin(frames * 0.5) * 1.5)
  local wag = math.floor(math.sin(frames * 0.35) * 3)
  local breathe = math.floor(math.sin(frames * 0.12) + 0.5)
  local d = dir
  if kind == "cat" then
    local f = sp.fat
    if pose == "walk" then
      gfx.fillEllipseInRect(x - 7 - f, y - 8 - f, 14 + 2 * f, 7 + f)
      gfx.fillCircleAtPoint(x + d * 7, y - 9, 3)
      CAFE.catEars(x + d * 7, y - 9, d, sp.ears, false, 5)
      CAFE.catTail(sp.tail, d, x - d * 7, y - 6, x - d * 9, y - 9, x - d * 11, y - 12 + step)
      gfx.drawLine(x - 4, y - 2, x - 4 + step, y)
      gfx.drawLine(x + 4, y - 2, x + 4 - step, y)
      UI.inkPush(CAFE.PETEYE[var or kind])
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 8, y - 10); gfx.setColor(BLACK)
      UI.inkPop()
    elseif pose == "sleep" then                     -- curled up in a ball
      gfx.fillEllipseInRect(x - 9 - f, y - 8 - f - breathe, 18 + 2 * f, 8 + f + breathe)
      gfx.fillCircleAtPoint(x + d * 6, y - 5, 3)
      CAFE.catEars(x + d * 6, y - 5, d, sp.ears, false, 4)
      gfx.setColor(WHITE)
      gfx.drawLine(x + d * 5, y - 5, x + d * 7, y - 5)         -- closed eyes
      if sp.tail.len >= 0.6 then gfx.drawLine(x - 6, y - 3, x + 3, y - 1) end   -- the tail wrapped round
      gfx.setColor(BLACK)
      CAFE.zzz(x + d * 9, y - 8)
    else                                            -- sitting, looking out
      gfx.fillEllipseInRect(x - 5 - f, y - 9 - f, 10 + 2 * f, 9 + f)
      gfx.fillCircleAtPoint(x + d, y - 12 - math.floor(f / (2)), 4)
      CAFE.catEars(x + d, y - 12 - math.floor(f / (2)), d, sp.ears, true, 4)
      CAFE.catTail(sp.tail, d, x - d * 5, y - 2, x - d * 10, y - 6, x - d * 9, y - 10 + math.floor(wag / (2)))
      UI.inkPush(CAFE.PETEYE[var or kind])
      gfx.setColor(WHITE); gfx.drawPixel(x + d - 1, y - 12 - math.floor(f / (2))); gfx.drawPixel(x + d + 2, y - 12 - math.floor(f / (2))); gfx.setColor(BLACK)
      UI.inkPop()
    end
  else
    local up, sn, bl, th = sp.up, sp.sn, sp.bl, sp.thick
    local function snout(hx, hy) gfx.fillRect(d > 0 and (hx + 2) or (hx - 2 - sn), hy, sn, 3) end
    if pose == "walk" then
      local hr = sp.hr or 4
      local hx, hy = x + d * (10 + bl), y - 14 - up - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - bl, y - 12 - up - th, 20 + 2 * bl, 9 + th)
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 10 - up, x - d * (15 + bl), y - 15 - up + wag)
      gfx.drawLine(x - 7 - bl, y - 4 - up, x - 7 - bl + step, y)
      gfx.drawLine(x - 3, y - 4 - up, x - 3 - step, y)
      gfx.drawLine(x + 4, y - 4 - up, x + 4 + step, y)
      gfx.drawLine(x + 8 + bl, y - 4 - up, x + 8 + bl - step, y)
      gfx.setColor(WHITE)
      gfx.drawPixel(x + d * (11 + bl), y - 15 - up)                                  -- eye
      if var == nil or var == "dog" then gfx.fillEllipseInRect(x - 3, y - 7 - up, 8, 3) end   -- pale belly
      gfx.setColor(BLACK)
    elseif pose == "sit" then
      local hr = sp.hr or 4
      local hx, hy = x + d * 3, y - 19 - math.floor(up / (2)) - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - math.floor(bl / (2)), y - 10 - th, 14 + math.floor(bl / (2)), 10 + th)     -- haunches
      gfx.fillRoundRect(x + (d > 0 and 0 or -6), y - 16 - math.floor(up / (2)), 6, 16 + math.floor(up / (2)), 2)   -- chest and front legs
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * 9, y - 2, x - d * 14, y - 3 + wag)
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 4, hy - 1); gfx.drawLine(x + d * 3, y - 10, x + d * 3, y - 3); gfx.setColor(BLACK)
    else                                                                          -- lying down, asleep
      local hr = sp.hr or 4
      local hx, hy = x + d * (10 + bl), y - 4 - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - bl, y - 7 - breathe - th, 20 + 2 * bl, 7 + breathe + th)
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 3, x - d * (14 + bl), y - 5)
      gfx.setColor(WHITE); gfx.drawLine(x + d * (9 + bl), y - 5, x + d * (11 + bl), y - 5); gfx.setColor(BLACK)
      CAFE.zzz(x + d * 4, y - 8)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawPets()
  for key, p in pairs(G.pets) do
    local kind = p.kind or key
    local lk = p.lkey
    if not lk then lk = "p" .. tostring(key); p.lkey = lk end
    if kind == "hamball" then
      local x, y = math.floor(p.x), math.floor(p.y)
      UI.liveDraw(lk, x - 23, y - 31, 46, 39, CAFE.hamBall, p.x, p.y, p.dir, p.mode == "walk", p.roll or 0, p.var)
    else
      local x, y, dir, pose = p.x, p.y, p.dir, p.pose
      if p.mode == "walk" then pose = "walk"
      elseif p.mode == "rest" and p.home then
        local hx, hy = CAFE.homeOf(kind)
        if hx and kind == "cat" then x, y = hx, hy - 14
        elseif hx then kind, x, y, dir, pose = "dog", hx, hy + 10, 1, "lie" end      -- curled up on the dog bed
      end
      local fx, fy = math.floor(x), math.floor(y)
      UI.liveDraw(lk, fx - 23, fy - 31, 46, 39, CAFE.pet, kind, x, y, dir, pose, p.var)
    end
  end
end

-- ---- more pets: bunnies on the floor; axolotls, hamsters, parrots and owls on the counter (or a table) ----------------
-- a little shape in one of three looks: "w" white with a black edge, "b" solid black, "g" grey (a dither inside a black edge)
function CAFE.blob(x, y, w, h, look)
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x, y, w, h)
  if look == "w" then gfx.setColor(WHITE); gfx.fillEllipseInRect(x + 1, y + 1, w - 2, h - 2)
  elseif look == "g" then gfx.setColor(WHITE); gfx.fillEllipseInRect(x + 1, y + 1, w - 2, h - 2); gfx.setPattern(CHECK); gfx.fillEllipseInRect(x + 1, y + 1, w - 2, h - 2) end
  gfx.setColor(BLACK)
end

-- ---- bunnies: they hop about, sit up with their ears tall, and flop down for a nap -----------------------------------
CAFE.BUNSPEC = {                                    -- body look, ears ("up" or "lop"), the face colour, markings
  bunny    = { look = "w", ears = "up" },
  brownbun = { look = "b", ears = "up" },
  graybun  = { look = "g", ears = "up" },
  dutchbun = { look = "w", ears = "up", dutch = true },
  lopbun   = { look = "w", ears = "lop" },
}
CAFE.BUNCOL = { bunny = "snow", brownbun = "pchoc", graybun = "pgray", dutchbun = "ptux", lopbun = "pgold" }
function CAFE.bunny(x, y, d, pose, var)               -- x, y = where the feet are. poses: walk (a hop) / sit / sleep
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.BUNSPEC[var] or CAFE.BUNSPEC.bunny
  local lk = sp.look
  UI.ink(CAFE.BUNCOL[var] or "snow")
  local hop = 0
  if pose == "walk" then hop = math.floor(math.abs(math.sin(frames * 0.28)) * 4 + 0.5) end
  local by = y - hop
  local function E(xo, yo, w, h, look)                -- an oval given as if facing right; flipped when it faces left
    local ex = (d > 0) and (x + xo) or (x - xo - w + 1)
    CAFE.blob(ex, by + yo, w, h, look)
  end
  local function P(xo, yo) gfx.drawPixel(x + d * xo, by + yo) end
  local earLook = sp.dutch and "b" or lk
  local ink = (lk == "b" or sp.dutch) and WHITE or BLACK
  if pose == "sleep" then                             -- a flat loaf, ears laid back along it
    E(-7, -6, 14, 6, lk)
    if sp.dutch then E(-7, -6, 7, 6, "b") end
    E(3, -7, 7, 5, lk)                                                             -- the head, tucked down
    if sp.ears == "lop" then E(2, -7, 4, 7, earLook) else E(-2, -8, 8, 3, earLook) end
    gfx.setColor(ink); P(7, -5); P(8, -5)                                          -- a closed eye
    gfx.setColor(BLACK)
    CAFE.zzz(x + d * 9, by - 8)
  else
    local walk = (pose == "walk")
    if walk then
      E(-7, -7, 13, 7, lk)                                                         -- the body, stretched out mid-hop
      if sp.dutch then E(-7, -7, 7, 7, "b") end
      E(-9, -6, 3, 3, "w")                                                         -- the cotton tail
      if sp.ears == "lop" then E(3, -11, 7, 6, lk); E(2, -12, 4, 10, earLook); gfx.setColor(BLACK); P(4, -10); P(4, -9)       -- the long ear hangs down the side of the head
      else
        E(2, -17, 3, 7, earLook); E(4, -16, 3, 6, earLook)
        if earLook == "b" then gfx.setColor(WHITE); gfx.drawLine(x + d * 3, by - 15, x + d * 3, by - 12); gfx.drawLine(x + d * 5, by - 14, x + d * 5, by - 12) end
        E(3, -11, 7, 6, lk)
      end
      if sp.dutch then gfx.setColor(BLACK); P(6, -10); P(7, -10); gfx.setColor(WHITE); P(6, -9); P(6, -8) end
      gfx.setColor(ink); P(7, -9)                                                  -- the eye
      gfx.setColor(BLACK); if lk ~= "b" then P(9, -8) end                          -- the nose
      gfx.drawLine(x - d * 5, by - 1, x - d * (7 + ((hop > 1) and 2 or 0)), by)     -- back feet kicking out
      gfx.drawLine(x + d * 3, by - 1, x + d * 4, by)
    else
      E(-6, -8, 11, 8, lk)                                                         -- the body, sitting up
      if sp.dutch then E(-6, -8, 6, 8, "b") end
      E(-8, -6, 3, 3, "w")                                                         -- the cotton tail
      local twitch = ((frames % 160) < 6) and 1 or 0
      if sp.ears == "lop" then E(1, -12, 7, 6, lk); E(0, -13, 4, 10 + ((frames % 200 < 8) and 1 or 0), earLook); gfx.setColor(BLACK); P(2, -11); P(2, -10)   -- floppy ears hanging down the side (one gives a little swing now and then)
      else
        E(1, -18 + twitch, 3, 8 - twitch, earLook); E(3, -17, 3, 7, earLook)
        if earLook == "b" then gfx.setColor(WHITE); gfx.drawLine(x + d * 2, by - 16 + twitch, x + d * 2, by - 13); gfx.drawLine(x + d * 4, by - 15, x + d * 4, by - 13) end
        E(1, -12, 7, 6, lk)
      end
      if sp.dutch then gfx.setColor(BLACK); P(4, -11); P(5, -11); gfx.setColor(WHITE); P(4, -10); P(4, -9) end
      gfx.setColor(ink); P(5, -10)                                                 -- the eye
      gfx.setColor(BLACK); if lk ~= "b" then P(7, -9) end                          -- the nose
      gfx.drawLine(x + d * 2, by - 1, x + d * 3, by)                                -- a front paw
    end
  end
  gfx.setColor(BLACK)
end

-- ---- little hand-drawn sprites for the small pets: each letter is a colour (see CAFE.PIXMAP); drawn once into a picture -----
-- a map entry is { Playdate colour (BLACK, WHITE, or "d" for a fine dither), PC colour row, PC colour (if it differs) }
CAFE.PIXIMG = {}
function CAFE.pixImg(key, rows, map, flip)          -- (kept by the picture's rows and colours, so no name has to be put together every frame)
  local t = CAFE.PIXIMG[rows]
  if not t then t = {}; CAFE.PIXIMG[rows] = t end
  local t2 = t[map]
  if not t2 then t2 = {}; t[map] = t2 end
  local fk = flip and 2 or 1
  local im = t2[fk]
  if im then return im end
  local w, h = #rows[1], #rows
  im = gfx.image.new(w, h, gfx.kColorClear)
  gfx.pushContext(im)
  for y = 1, h do
    local r = rows[y]
    for x = 1, w do
      local ch = string.sub(r, flip and (w - x + 1) or x, flip and (w - x + 1) or x)
      local m = map[ch]
      if m then
        UI.ink(m[2] or "none")
        local c = m[1]
        if UI.color and m[3] ~= nil then c = m[3] end
        if c == "d" then c = ((x + y) % 2 == 0) and BLACK or WHITE end
        gfx.setColor(c)
        gfx.drawPixel(x - 1, y - 1)
      end
    end
  end
  UI.ink("none")
  gfx.popContext()
  t2[fk] = im
  return im
end

-- ---- the axolotl tank: it glides about on the gravel smiling, waves its gills, blinks, and now and then swims up for air ----
CAFE.AXO = {
  a = { "g.............g", ".gg.........gg.", "g..g#######g..g", ".g#ooooooooo#g.", "gg#ooooooooo#gg", "..#oeoooooeo#..",
        "gg#onoooooon#gg", ".#ooo#ooo#ooo#.", ".#oooo###oooo#.", "..##ooooooo##..", "....#ooooo#....", "...#o##o##o#..." },
  b = { ".g...........g.", "g.gg.......gg.g", "...g#######g...", "gg#ooooooooo#gg", "..#ooooooooo#..", "gg#oeoooooeo#gg",
        "..#onoooooon#..", ".#ooo#ooo#ooo#.", ".#oooo###oooo#.", "..##ooooooo##..", "....#ooooo#....", "...#o##o##o#..." },
}
CAFE.AXO.blink = { CAFE.AXO.a[1], CAFE.AXO.a[2], CAFE.AXO.a[3], CAFE.AXO.a[4], CAFE.AXO.a[5], "..#o##ooo##o#..",
                   CAFE.AXO.a[7], CAFE.AXO.a[8], CAFE.AXO.a[9], CAFE.AXO.a[10], CAFE.AXO.a[11], CAFE.AXO.a[12] }
CAFE.AXOMAP = {                                           -- pink (white on the Playdate), wild (dark, speckled), golden
  axotank = { ["#"] = { BLACK, "axop" }, o = { WHITE, "axop" }, g = { BLACK, "axog1" }, e = { BLACK, "none" }, n = { WHITE, "axon", BLACK } },
  axowild = { ["#"] = { BLACK, "axow" }, o = { "d", "axow", WHITE }, g = { BLACK, "axog2" }, e = { BLACK, "none", BLACK }, n = { "d", "axow", WHITE } },
  axogold = { ["#"] = { BLACK, "axoy" }, o = { WHITE, "axoy" }, g = { BLACK, "axog3" }, e = { BLACK, "none" }, n = { WHITE, "axon", BLACK } },
}
function CAFE.axolotl(x, y, frame, id)                     -- x, y = the middle of its feet
  local rows = CAFE.AXO[frame] or CAFE.AXO.a
  local im = CAFE.pixImg(nil, rows, CAFE.AXOMAP[id] or CAFE.AXOMAP.axotank, false)
  im:draw(x - 7, y - 11)
  if id == "axowild" and not UI.color then                  -- (the wild one's face stays clear on the Playdate)
    gfx.setColor(WHITE); gfx.fillRect(x - 3, y - 6, 7, 2); gfx.setColor(BLACK)
    gfx.drawPixel(x - 3, y - 6); gfx.drawPixel(x + 3, y - 6)
  end
end
function CAFE.axoTank(cx, cy, id)
  local fl, sin = math.floor, math.sin
  local nar = CAFE.narrow                                        -- (in a tight spot on the counter: a narrower tank)
  local L, R, T, B = cx - (nar and math.min(14, -nar[1] - 1) or 14), cx + (nar and math.min(13, nar[2] - 1) or 13), cy - 12, cy + 9           -- the glass
  local fast = CAFE.fastArt()                                    -- (Playdate: the parts that keep still are stamped from pictures)
  if fast then CAFE.layer("axoA", id, L - 2, T - 2, R - L + 5, B - T + 6, CAFE.axoTankA, L, R, T, B) else CAFE.axoTankA(L, R, T, B) end
  UI.ink("water")
  gfx.setColor(BLACK)
  if fast then                                                                                               -- the water line, rippling
    local w, rip = R - L - 1, (L + 1 + fl(frames / (6))) % 6
    local im = UI.cacheGet("axoW", w, rip)
    if im == nil then im = UI.cacheImg("axoW", w, rip, w, 1, function() gfx.setColor(BLACK); for xx = 0, w - 1 do if (xx + rip) % 6 ~= 0 then gfx.drawPixel(xx, 0) end end end) end
    if im then UI.cacheDraw(im, L + 1, T + 3) end
  else
    for xx = L + 1, R - 1 do if (xx + fl(frames / (6))) % 6 ~= 0 then gfx.drawPixel(xx, T + 3) end end
  end
  for k = 0, 2 do                                                                                            -- light glinting in the water
    local gx = L + 3 + ((fl(frames / (9)) + k * 9) % (R - L - 5))
    gfx.drawPixel(gx, T + 6 + k * 3)
  end
  UI.ink("leaf")                                                                                             -- a swaying water plant
  if fast then
    local q = fl(frames * 0.07 * 32 / (2 * math.pi)) % 32                                                  -- (one of 32 steps of its sway)
    local im = UI.cacheGet("axoP", q, 0)
    if im == nil then im = UI.cacheImg("axoP", q, 0, 12, 10, function() gfx.setColor(BLACK); CAFE.axoPlant(2, 9, q * 2 * math.pi / 32) end) end
    if im then UI.cacheDraw(im, L + 1, B - 12) end
  else
    CAFE.axoPlant(L + 3, B - 3, frames * 0.07)
  end
  local seed = 0
  for i = 1, #id do seed = seed + string.byte(id, i) end
  local cyc = (frames + seed * 37) % 900                                       -- mostly gliding about the bottom; now and then up for a gulp of air
  local up = CAFE.smooth(620, 680, cyc) - CAFE.smooth(740, 820, cyc)
  local t = (frames + seed * 11) * 0.010
  local ax = cx - 1 + sin(t) * 4.5 + sin(t * 2.3) * 1
  local ay = fl(B - 2 - up * 7 + 0.5)
  if up < 0.05 then ay = ay + ((fl(frames / (24)) % 2 == 0) and 0 or -1) end   -- (a little bob as it walks)
  local blink = ((frames + seed * 5) % 150) < 5
  local frame = blink and "blink" or ((fl((frames + seed) / (14)) % 2 == 0) and "a" or "b")
  CAFE.axolotl(fl(ax + 0.5), ay, frame, id)
  if up > 0.9 then                                                             -- bubbles as it gulps
    UI.ink("water")
    local bt = cyc % 24
    gfx.setColor(WHITE); gfx.drawCircleAtPoint(fl(ax + 0.5) + 2, ay - 12 - fl(bt / 6), 1)
  end
  if fast then CAFE.layer("axoB", id, L - 2, T - 2, R - L + 5, B - T + 6, CAFE.axoTankB, L, R, T, B) else CAFE.axoTankB(L, R, T, B) end
  UI.ink("none")
  gfx.setColor(BLACK)
end
function CAFE.axoTankA(L, R, T, B)                    -- the tank's still parts behind the axolotl: the glass, the gravel, the arch
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(L, T, R - L + 1, B - T + 1)
  UI.ink("tan")                                                                                              -- the gravel
  gfx.setColor(WHITE); gfx.fillRect(L + 1, B - 3, R - L - 1, 3)
  gfx.setColor(BLACK)
  for xx = L + 2, R - 2, 3 do gfx.drawPixel(xx, B - 3 + (xx % 2)) end
  UI.ink("gray")                                                                                             -- a little stone arch to hide in
  gfx.setColor(WHITE); gfx.fillRoundRect(R - 9, B - 8, 8, 6, 3)
  gfx.setColor(BLACK); gfx.drawRoundRect(R - 9, B - 8, 8, 6, 3); gfx.fillRoundRect(R - 7, B - 5, 4, 3, 1)
end
function CAFE.axoTankB(L, R, T, B)                    -- ...and in front of it: the tank's edge, its stand, a shine on the glass
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRect(L, T, R - L + 1, B - T + 1); gfx.setLineWidth(1)
  gfx.fillRect(L - 1, B + 1, R - L + 3, 2)                                     -- the stand
  UI.ink("white"); gfx.setColor(WHITE); gfx.drawLine(L + 2, T + 5, L + 2, T + 8)   -- a shine on the glass
end
function CAFE.axoPlant(x0, yb, ph)                     -- three stems, swaying (x0 = the first stem, yb = their foot, ph = the sway's angle)
  local fl, sin = math.floor, math.sin
  for j = 0, 2 do
    local px = x0 + j * 2
    local h = 9 - j * 2
    for k = 0, h do
      local sw = fl(sin(ph + k * 0.5 + j) * (k / 4) + 0.5)
      gfx.drawPixel(px + sw, yb - k)
    end
  end
end

-- ---- the hamster: a cage with a wheel, a bowl and a water bottle. It runs in the wheel, trots to its bowl and nibbles,
-- ---- has a drink, curls up in the bedding for a nap, then back to the wheel. Or it's out in its ball, rolling round the floor.
CAFE.HAM = {
  stand = { "....##.##...", "...#nn#n#...", "..#ooooooo#.", ".#ooooooeoo#", "#ooooooooocn", "#oooooooccc#", "#cccccccccc#", ".##########.", "..#.#..#.#.." },
  run1  = { "............", "....##.##...", "...#nn#n#...", "..#ooooooo#.", ".#ooooooeoo#", "#ooooooooocn", "#ccooooocc#.", ".#########..", ".#....#....." },
  run2  = { "............", "....##.##...", "...#nn#n#...", "..#ooooooo#.", ".#ooooooeoo#", "#ooooooooocn", "#ccooooocc#.", ".#########..", "...#....#..." },
  eat1  = { "....##.##...", "...#nn#n#...", "..#ooooooo#.", ".#ooooooeoo#", "#oooooooccc#", "#ooooooccccn", "#ccccccccyy#", ".#########y.", "..#.#..#.#.." },
  eat2  = { "....##.##...", "...#nn#n#...", "..#ooooooo#.", ".#ooooooeoo#", "#oooooooccc#", "#ooooooccccn", "#cccccccccy#", ".#########yy", "..#.#..#.#.." },
  drink = { "........##..", ".......#n#..", "....####o#..", "...#oooooe#.", "..#ooooooon#", ".#ooooooccc#", "#cccccccccc#", ".##########.", "..#.#..#.#.." },
  sleep = { "............", "........##..", "...#####nn#.", "..#ooooooo#.", ".#ooooooooo#", "#ooooooo##o#", "#oooooooooc#", "#ccccccccc#.", ".#########.." },
}
CAFE.HAMMAP = {
  hamster  = { ["#"] = { BLACK, "hamg" }, o = { WHITE, "hamg" }, c = { WHITE, "hambel" }, n = { WHITE, "hampink", BLACK }, e = { BLACK, "none" }, y = { BLACK, "yellow", WHITE } },
  hamwhite = { ["#"] = { BLACK, "hamw" }, o = { WHITE, "hamw" }, c = { WHITE, "hamw" }, n = { WHITE, "hampink", BLACK }, e = { BLACK, "none" }, y = { BLACK, "yellow", WHITE } },
  hamgray  = { ["#"] = { BLACK, "hamgr" }, o = { "d", "hamgr", WHITE }, c = { WHITE, "hambel" }, n = { WHITE, "hampink", BLACK }, e = { BLACK, "none" }, y = { BLACK, "yellow", WHITE } },
}
CAFE.HAMCOL = { hamster = "hamg", hamwhite = "hamw", hamgray = "hamgr" }
function CAFE.hamDraw(x, y, pose, d, id)                  -- x, y = the middle of its feet; d = 1 facing right, -1 left
  local rows = CAFE.HAM[pose] or CAFE.HAM.stand
  local im = CAFE.pixImg(nil, rows, CAFE.HAMMAP[id] or CAFE.HAMMAP.hamster, d < 0)
  im:draw(x - 6, y - 8)
end
function CAFE.hamBody(x, y, d, look, run, sleep, id)       -- (kept for anything that still asks for the old one)
  CAFE.hamDraw(x, y, sleep and "sleep" or (run and (((math.floor(frames / (3))) % 2 == 0) and "run1" or "run2") or "stand"), d, id or "hamster")
end
function CAFE.hamOut(d, id)                           -- is this hamster out of its cage, rolling round in its ball?
  return d ~= nil and d.hball ~= nil and d.hball[id] == true and G ~= nil and G.pets ~= nil and G.pets["ham:" .. id] ~= nil
end
function CAFE.hamCage(cx, cy, id)
  local fl = math.floor
  local d = CAFE.dec()
  local nar = CAFE.narrow                                      -- (in a tight spot on the counter: a narrower cage)
  local L, R, T, B = cx - (nar and math.min(15, -nar[1] - 2) or 15), cx + (nar and math.min(14, nar[2] - 2) or 14), cy - 10, cy + 8         -- inside the bars; B = the floor
  local bx = math.min(cx - 4, R - 22)                           -- the food bowl (clear of the wheel, even in a narrow cage)
  local fast = CAFE.fastArt()                                   -- (Playdate: the parts that keep still are stamped from pictures)
  if fast then CAFE.layer("hamA", id, L - 2, T - 6, R - L + 5, B - T + 10, CAFE.hamCageA, L, R, T, B, bx) else CAFE.hamCageA(L, R, T, B, bx) end
  local out = CAFE.hamOut(d, id)
  local seed = 0
  for i = 1, #id do seed = seed + string.byte(id, i) end
  local cyc = (frames + seed * 53) % 1200
  local wx, wy = math.min(cx + 7, R - 7), cy - 2               -- the wheel
  local floorY = B - 2
  -- where it is and what it's doing
  local pose, hx, hy, dir, spin = "stand", wx, floorY, 1, 0
  local function walk(a, b, t0, t1)
    local k = clamp((cyc - t0) / (t1 - t0), 0, 1)
    hx = fl(a + (b - a) * k + 0.5); dir = (b >= a) and 1 or -1
    pose = ((fl(frames / (4))) % 2 == 0) and "run1" or "run2"
  end
  if cyc < 300 then                                             -- running in the wheel
    pose = ((fl(frames / (2))) % 2 == 0) and "run1" or "run2"; hx, hy, spin = wx, wy + 7, 1
  elseif cyc < 350 then walk(wx, bx + 6, 300, 350)              -- off to the bowl
  elseif cyc < 540 then                                         -- nibbling
    hx, dir = bx + 6, -1; pose = ((fl(frames / (6))) % 2 == 0) and "eat1" or "eat2"
  elseif cyc < 580 then walk(bx + 6, L + 9, 540, 580)           -- to the bottle
  elseif cyc < 680 then hx, dir, pose = L + 9, -1, "drink"
  elseif cyc < 720 then walk(L + 9, cx, 680, 720)
  elseif cyc < 1080 then hx, pose = cx, "sleep"                 -- a nap in the bedding
  elseif cyc < 1150 then walk(cx, wx, 1080, 1150)
  else hx, pose = wx, "stand" end
  if out then pose = nil end
  UI.ink("redp")                                                -- the wheel (red), its spokes turning while it runs
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(wx, wy, 8)
  local ang = spin * frames * 0.45
  for k = 0, 2 do
    local a = ang + k * math.pi / 3
    gfx.drawLine(wx + fl(math.cos(a) * 7 + 0.5), wy + fl(math.sin(a) * 7 + 0.5), wx - fl(math.cos(a) * 7 + 0.5), wy - fl(math.sin(a) * 7 + 0.5))
  end
  gfx.fillCircleAtPoint(wx, wy, 1)
  UI.ink("slate")
  gfx.drawLine(wx + 1, wy + 2, wx + 4, B); gfx.drawLine(wx - 1, wy + 2, wx - 4, B)  -- the stand
  if fast then CAFE.layer("hamB", id, L - 2, T - 6, R - L + 5, B - T + 10, CAFE.hamCageB, L, R, T, B, cx) else CAFE.hamCageB(L, R, T, B, cx) end
  if pose and spin == 1 then UI.ink("none"); CAFE.hamDraw(hx, hy, pose, dir, id) end
  if pose and spin ~= 1 then
    CAFE.hamDraw(hx, floorY + ((pose == "sleep" and (fl(frames / (30))) % 2 == 0) and 0 or 0), pose, dir, id)
    if pose == "sleep" then CAFE.zzz(hx + 3, floorY - 12) end
    if pose == "drink" and (fl(frames / (10))) % 3 == 0 then UI.ink("water"); gfx.setColor(BLACK); gfx.drawPixel(L + 5, T + 12) end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end
function CAFE.hamCageA(L, R, T, B, bx)               -- the cage's still parts behind the wheel: the floor, the bedding, the bottle, the bowl
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(L, T, R - L + 1, B - T + 1)
  UI.ink("tan")                                                -- fluffy bedding
  gfx.setColor(WHITE); gfx.fillRect(L + 1, B - 2, R - L - 1, 3)
  gfx.setColor(BLACK); for xx = L + 1, R - 1, 3 do gfx.drawPixel(xx, B - 2 + (xx % 2)); gfx.drawPixel(xx + 1, B - 1) end
  UI.ink("water")                                               -- the water bottle on the left wall, with its spout
  gfx.setColor(WHITE); gfx.fillRect(L + 1, T + 2, 4, 7)
  gfx.setColor(BLACK); gfx.drawRect(L + 1, T + 2, 4, 7); gfx.drawLine(L + 3, T + 9, L + 5, T + 11)
  gfx.drawLine(L + 2, T + 6, L + 3, T + 6)
  UI.ink("skyp")                                                -- the food bowl, heaped with seeds
  gfx.setColor(WHITE); gfx.fillRoundRect(bx - 4, B - 4, 9, 4, 2)
  gfx.setColor(BLACK); gfx.drawRoundRect(bx - 4, B - 4, 9, 4, 2)
  UI.ink("yellow"); gfx.setColor(BLACK); gfx.drawPixel(bx - 2, B - 5); gfx.drawPixel(bx, B - 6); gfx.drawPixel(bx + 2, B - 5); gfx.drawPixel(bx - 1, B - 5)
end
function CAFE.hamCageB(L, R, T, B, cx)               -- ...and the bars, roof and handle over the wheel, and the tray it stands on
  UI.ink("gray")                                                -- the bars (fine and far apart, so you can see in), the roof and handle
  gfx.setColor(BLACK)
  for xx = L + 2, R - 1, 6 do for yy = T + 1, B - 4, 3 do gfx.drawPixel(xx, yy) end end
  gfx.drawRect(L - 1, T - 1, R - L + 3, B - T + 2)
  gfx.drawLine(L + 1, T - 3, R - 1, T - 3); gfx.drawLine(L - 1, T - 1, L + 1, T - 3); gfx.drawLine(R + 1, T - 1, R - 1, T - 3)
  gfx.drawLine(cx - 2, T - 5, cx + 2, T - 5); gfx.drawLine(cx - 2, T - 5, cx - 2, T - 3); gfx.drawLine(cx + 2, T - 5, cx + 2, T - 3)
  UI.ink("slate")
  gfx.fillRect(L - 2, B + 1, R - L + 5, 3)                       -- the tray
end
function CAFE.hamBall(x, y, d, moving, roll, id)      -- the clear ball rolling round the floor, the hamster running inside
  x, y = math.floor(x), math.floor(y)
  local bounce = (moving and (math.floor(frames / (4))) % 2 == 0) and 1 or 0
  local cx, cy = x, y - 9 - bounce
  UI.ink("none")
  gfx.setColor(BLACK); gfx.fillEllipseInRect(cx - 8, y - 1, 17, 3)              -- its shadow
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 9)
  CAFE.hamDraw(cx, cy + 8, moving and (((math.floor(frames / (2))) % 2 == 0) and "run1" or "run2") or "stand", d, id)
  UI.ink("water")
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy, 9)
  for k = 0, 3 do                                                                  -- the air slots, turning as it rolls
    local a = roll + k * math.pi / 2
    local px, py = cx + math.floor(math.cos(a) * 7 + 0.5), cy + math.floor(math.sin(a) * 7 + 0.5)
    gfx.drawPixel(px, py); gfx.drawPixel(px + math.floor(-math.sin(a) * 1.5 + 0.5), py + math.floor(math.cos(a) * 1.5 + 0.5))
  end
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawLine(cx - 5, cy - 4, cx - 3, cy - 6)                 -- a shine
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- birds: a parrot or an owl on its perch; now and then it flies off round the cafe, lands somewhere it can sit, and flies home ----
CAFE.BIRDSPEC = {
  parrot    = { kind = "parrot", look = "b", face = false, col = "leaf", trim = "yellow" },
  macaw     = { kind = "parrot", look = "b", face = true,  col = "redp", trim = "skyp", wing = true },
  bluemacaw = { kind = "parrot", look = "g", face = true,  col = "inkblue", trim = "yellow", gold = true },   -- (PC: a deep blue back, a golden front)
  cockatiel = { kind = "parrot", look = "w", crest = true, col = "cream", trim = "inkorange" },
  barnowl   = { kind = "owl", look = "g", heart = true,  col = "tan" },
  snowyowl  = { kind = "owl", look = "w", speck = true,  col = "snow", pixEyes = true },
  hornowl   = { kind = "owl", look = "b", tufts = true,  col = "bark" },
}
CAFE.SQUAWK = { "HELLO!", "COFFEE!", "SQUAWK!", "PRETTY BIRD!", "ORDER UP!", "LATTE!" }
function CAFE.parrotSit(x, y, sp, look)                -- x, y = its feet, facing right; look: "bob" / "stretch" / nil
  local fl = math.floor
  local bob = (look == "bob") and 1 or 0
  local lk = sp.look
  local gold = sp.gold and UI.color                                                -- (PC: the blue macaw in full colour)
  if gold then lk = "b" end
  gfx.setColor(BLACK)
  gfx.fillTriangle(x - 2, y - 3, x + 1, y - 3, x - 4, y + 8)                     -- the long tail, hanging down past the perch
  CAFE.blob(x - 4, y - 10, 8, 11, lk)                                              -- the body
  if gold then                                                                     -- a golden-yellow chest and belly
    UI.inkPush("gold2"); gfx.setColor(WHITE); gfx.fillEllipseInRect(x - 1, y - 9, 4, 8); gfx.setColor(BLACK); gfx.drawPixel(x + 1, y - 4); UI.inkPop()
    UI.inkPush("skyp"); gfx.setColor(WHITE); gfx.drawLine(x - 3, y + 2, x - 3, y + 5); UI.inkPop()      -- a light stripe down the tail
  end
  CAFE.blob(x - 2, y - 15 + bob, 7, 7, lk)                                         -- the head
  if sp.crest then                                                                 -- cockatiel: a crest and a round cheek spot
    gfx.setColor(BLACK); gfx.drawLine(x, y - 15 + bob, x - 1, y - 18 + bob); gfx.drawLine(x - 1, y - 18 + bob, x - 3, y - 19 + bob)
    UI.inkPush(sp.trim); gfx.fillRect(x + 2, y - 11 + bob, 2, 2); UI.inkPop()
  end
  if sp.face then                                                                  -- macaws: a bare white face round the eye
    gfx.setColor(WHITE); gfx.fillRect(x + 1, y - 13 + bob, 3, 3)
  end
  UI.inkPush("cream")
  gfx.setColor((lk == "b" and not sp.face) and WHITE or BLACK)
  gfx.fillRect(x + 4, y - 13 + bob, 2, 2); gfx.drawPixel(x + 5, y - 11 + bob)      -- the hooked beak
  UI.inkPop()
  gfx.setColor((lk == "b" and not sp.face) and WHITE or BLACK)
  gfx.drawPixel(x + 2, y - 12 + bob)                                               -- the eye
  if look == "stretch" then                                                        -- a wing stretched out
    gfx.setColor(BLACK); gfx.fillTriangle(x - 2, y - 8, x - 9, y - 12, x - 6, y - 4)
    if sp.wing or gold then UI.inkPush(gold and "skyp" or sp.trim); gfx.setColor(WHITE); gfx.drawLine(x - 3, y - 7, x - 7, y - 10); UI.inkPop() end
  else
    UI.inkPush(gold and "skyp" or (sp.wing and sp.trim or sp.col))
    gfx.setColor((lk == "w") and BLACK or WHITE)
    gfx.drawLine(x - 3, y - 7, x, y - 1)                                          -- the folded wing's edge
    if gold then gfx.drawLine(x - 4, y - 5, x - 2, y - 1) end
    if sp.wing then gfx.drawLine(x - 2, y - 8, x + 1, y - 3) end
    UI.inkPop()
  end
  gfx.setColor(BLACK)
  gfx.drawPixel(x - 1, y); gfx.drawPixel(x + 1, y)                                 -- toes round the perch
end
function CAFE.owlSit(x, y, sp, look)                   -- x, y = its feet, facing out; look: "left" / "right" / "blink" / nil
  local lk = sp.look
  CAFE.blob(x - 5, y - 13, 11, 14, lk)                                             -- the round body
  gfx.setColor(BLACK)
  if sp.tufts then gfx.fillTriangle(x - 5, y - 10, x - 4, y - 16, x - 1, y - 12); gfx.fillTriangle(x + 5, y - 10, x + 4, y - 16, x + 1, y - 12) end
  if sp.heart then                                                                 -- barn owl: a pale heart-shaped face
    gfx.setColor(WHITE); gfx.fillEllipseInRect(x - 4, y - 12, 4, 6); gfx.fillEllipseInRect(x, y - 12, 4, 6); gfx.fillTriangle(x - 3, y - 8, x + 3, y - 8, x, y - 5)
    gfx.setColor(BLACK); gfx.drawPixel(x, y - 12)
  end
  local ex = (look == "left") and -1 or ((look == "right") and 1 or 0)
  for side = -1, 1, 2 do                                                           -- the big eyes
    local cx = x + side * 2 + ((side > 0) and 0 or -1)
    if sp.pixEyes then                                                              -- snowy owl: dark round eyes set clear of the edge (PC: in a yellow ring)
      local l = x + ((side < 0) and -3 or 2)                                        -- (left column of this 2x2 pupil)
      if look == "blink" then
        gfx.setColor(BLACK); gfx.drawLine(l, y - 8, l + 1, y - 8)
      else
        if UI.color then                                                            -- (a ring of yellow round each pupil)
          UI.inkPush("yellow"); gfx.setColor(WHITE)
          gfx.fillRect(l, y - 10, 2, 4); gfx.fillRect(l - 1, y - 9, 4, 2)
          UI.inkPop()
        end
        gfx.setColor(BLACK); gfx.fillRect(l + (UI.color and ex or 0), y - 9, 2, 2)
      end
    elseif look == "blink" then
      gfx.setColor((lk == "b") and WHITE or BLACK); gfx.drawLine(cx - 1, y - 9, cx + 1, y - 9)
    elseif sp.heart then
      gfx.setColor(BLACK); gfx.fillRect(cx + ex - ((ex < 0) and 0 or 0), y - 10, 2, 2)    -- (dark eyes in the pale face)
    else
      UI.inkPush("yellow")
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, y - 9, 2)
      UI.inkPop()
      gfx.setColor(BLACK); gfx.drawPixel(cx + ex, y - 9); if lk ~= "b" then gfx.drawCircleAtPoint(cx, y - 9, 2) end
    end
  end
  UI.inkPush("inkorange")
  gfx.setColor((lk == "b") and WHITE or BLACK); gfx.drawPixel(x, y - 7); gfx.drawPixel(x, y - 6)    -- the beak
  UI.inkPop()
  if sp.speck or lk == "b" then                                                    -- speckles down the front
    gfx.setColor((lk == "b") and WHITE or BLACK)
    gfx.drawPixel(x - 2, y - 3); gfx.drawPixel(x + 2, y - 4); gfx.drawPixel(x, y - 2); gfx.drawPixel(x - 3, y - 5); gfx.drawPixel(x + 3, y - 2)
  end
  gfx.setColor(BLACK)
  gfx.drawPixel(x - 2, y); gfx.drawPixel(x + 2, y)                                 -- talons
end
function CAFE.birdFly(x, y, d, sp)                     -- in flight, side on: x, y = its middle
  x, y = math.floor(x), math.floor(y)
  local up = (math.floor(frames / (4))) % 2 == 0
  local lk = sp.look
  local owl = sp.kind == "owl"
  local span = owl and 9 or 8
  if not UI.color then                                                             -- (1-bit: a white edge all round, so it shows against the wall)
    gfx.setColor(WHITE)
    for k = 1, 4 do
      local ox, oy = ({ -1, 1, 0, 0 })[k], ({ 0, 0, -1, 1 })[k]
      gfx.fillTriangle(x - d * 3 + ox, y - 1 + oy, x - d * 3 + ox, y + 1 + oy, x - d * (owl and 7 or 10) + ox, y + (owl and 1 or 2) + oy)
      gfx.fillEllipseInRect(x - 5 + ox, y - 2 + oy, 10, 5)
      gfx.fillEllipseInRect(x + d * 4 - 3 + ox, y - 4 - (owl and 0 or 1) + oy, owl and 7 or 6, owl and 7 or 6)
      if up then gfx.fillTriangle(x - 2 + ox, y - 1 + oy, x + 3 + ox, y - 1 + oy, x - d * 2 + ox, y - span + oy)
      else gfx.fillTriangle(x - 2 + ox, y + oy, x + 3 + ox, y + oy, x - d * 2 + ox, y + span - 2 + oy) end
    end
  end
  gfx.setColor(BLACK)
  gfx.fillTriangle(x - d * 3, y - 1, x - d * 3, y + 1, x - d * (owl and 7 or 10), y + (owl and 1 or 2))   -- the tail
  CAFE.blob(x - 5, y - 2, 10, 5, lk)                                               -- the body
  CAFE.blob(x + d * 4 - 3, y - 4 - (owl and 0 or 1), owl and 7 or 6, owl and 7 or 6, lk)   -- the head
  gfx.setColor((lk == "b") and WHITE or BLACK)
  gfx.drawPixel(x + d * 5, y - 2 - (owl and 0 or 1))
  UI.inkPush(owl and "inkorange" or "cream")
  gfx.setColor((lk == "b") and WHITE or BLACK); gfx.drawPixel(x + d * 7, y - 1 - (owl and 0 or 1))
  UI.inkPop()
  gfx.setColor(BLACK)
  if up then gfx.fillTriangle(x - 2, y - 1, x + 3, y - 1, x - d * 2, y - span)    -- wings up...
  else gfx.fillTriangle(x - 2, y, x + 3, y, x - d * 2, y + span - 2) end           -- ...and down
  if sp.wing then UI.inkPush(sp.trim); gfx.setColor(WHITE); if up then gfx.drawLine(x, y - 2, x - d * 2, y - span + 2) else gfx.drawLine(x, y + 1, x - d * 2, y + span - 4) end; UI.inkPop() end
  gfx.setColor(BLACK)
end
function CAFE.birdHome(id)                             -- where its perch is: the perch bar (where the feet go)
  local d = CAFE.dec()
  if not d then return nil end
  local pl = d.place[id]
  if not pl then return nil end
  local x, y
  if pl <= 10 then local sl = CAFE.CSLOT[pl]; if not sl then return nil end; x, y = sl[1] + (CAFE.slotFit(id, pl)), sl[2]
  else x, y = CAFE.topXY(pl) end
  return x - 1, y - 4
end
function CAFE.birdSpots(id)                             -- places a bird can land: the tables, the tops of other things on the counter, plants and lamps
  local d = CAFE.dec()
  local out = {}
  if not d then return out end
  for k = 1, 5 do
    local t = TABLES[k]
    if t and CAFE.tableOn(d, k) and not (d.off and d.off[k]) then out[#out + 1] = { t.x + math.random(-4, 4), t.y - 2 } end
  end
  for _, it in ipairs(CAFE.ITEMS) do
    local pl = d.place[it.id]
    if it.id ~= id and d.decor[it.id] == "on" and pl then
      if it.kind == "counter" and pl <= 10 and CAFE.CSLOT[pl] then out[#out + 1] = { CAFE.CSLOT[pl][1], CAFE.CSLOT[pl][2] - 9 }
      elseif it.kind == "floor" and CAFE.FSLOT[pl] then out[#out + 1] = { CAFE.FSLOT[pl][1], CAFE.FSLOT[pl][2] - 22 } end
    end
  end
  for i, sl in ipairs(CAFE.CSLOT) do                    -- and the bare counter top
    local taken = false
    for _, it in ipairs(CAFE.ITEMS) do if it.kind == "counter" and d.decor[it.id] == "on" and d.place[it.id] == i then taken = true end end
    if not taken then out[#out + 1] = { sl[1], sl[2] + 6 } end
  end
  return out
end
function CAFE.birdsUpdate(dt)
  local d = G and G.cafe
  if not d then return end
  G.birds = G.birds or {}
  local list = CAFE.BIRDITEMS                     -- (the birds among all the items, found once)
  if not list then
    list = {}
    for _, it in ipairs(CAFE.ITEMS) do if it.bird then list[#list + 1] = it end end
    CAFE.BIRDITEMS = list
  end
  for _, it in ipairs(list) do
    do
      local b = G.birds[it.id]
      local hx, hy = CAFE.birdHome(it.id)
      if d.decor[it.id] ~= "on" or not hx then
        G.birds[it.id] = nil
      else
        if not b then b = { mode = "home", wait = 6 + math.random() * 14, x = hx, y = hy, dir = 1 }; G.birds[it.id] = b end
        local owl = it.bird == "owl"
        if b.mode == "home" or b.mode == "sit" then
          if b.mode == "home" then b.x, b.y = hx, hy end
          b.wait = b.wait - dt
          b.talk = b.talk and (b.talk - dt) or nil
          if b.talk and b.talk <= 0 then b.talk, b.say = nil, nil end
          if not owl and not b.talk and math.random() < dt / 14 then                  -- a parrot says something now and then
            b.say, b.talk = CAFE.SQUAWK[math.random(#CAFE.SQUAWK)], 2.2
          end
          if b.wait <= 0 then
            local tx, ty
            if b.mode == "sit" and math.random() < 0.7 then tx, ty = hx, hy           -- (usually back home after a little sit)
            else
              local sp = CAFE.birdSpots(it.id)
              if #sp > 0 then local s = sp[math.random(#sp)]; tx, ty = s[1], s[2] end
            end
            if tx then
              local dist = math.sqrt((tx - b.x) ^ 2 + (ty - b.y) ^ 2)
              b.mode, b.sx, b.sy, b.tx, b.ty, b.t = "fly", b.x, b.y, tx, ty, 0
              b.T = math.max(0.8, dist / (owl and 55 or 70))
              b.arc = math.min(34, 8 + dist * 0.25)
              b.home = (tx == hx and ty == hy)
              b.dir = (tx >= b.x) and 1 or -1
              b.say, b.talk = nil, nil
            else
              b.wait = 5 + math.random() * 10
            end
          end
        elseif b.mode == "fly" then
          b.t = b.t + dt
          local f = math.min(1, b.t / b.T)
          local e = f * f * (3 - 2 * f)
          b.x = b.sx + (b.tx - b.sx) * e
          b.y = b.sy + (b.ty - b.sy) * e - b.arc * math.sin(math.pi * f)
          if f >= 1 then
            b.x, b.y = b.tx, b.ty
            if b.home then b.mode, b.wait = "home", (owl and 18 or 10) + math.random() * (owl and 30 or 22)
            else b.mode, b.wait = "sit", 4 + math.random() * 7 end
          end
        end
      end
    end
  end
end
function CAFE.birdLook(id, owl)                        -- an idle fidget, worked out from the clock (so it costs nothing to keep)
  local seed = 0
  for i = 1, #id do seed = seed + string.byte(id, i) end
  local c = (frames + seed * 29) % 240
  if owl then
    if c < 6 or (c > 120 and c < 126) then return "blink" end
    if c > 40 and c < 90 then return "left" elseif c > 150 and c < 200 then return "right" end
    return nil
  end
  if c > 60 and c < 90 then return ((math.floor(c / (6))) % 2 == 0) and "bob" or nil end
  if c > 180 and c < 200 then return "stretch" end
  return nil
end
function CAFE.birdSay(x, y, str)                        -- a little speech bubble
  local w = UI.thinWidth(str) + 6
  local bx = math.max(2, math.min(398 - w, x - math.floor(w / 2)))
  local by = y - 12
  gfx.setColor(WHITE); gfx.fillRoundRect(bx, by, w, 11, 3)
  gfx.setColor(BLACK); gfx.drawRoundRect(bx, by, w, 11, 3)
  gfx.fillTriangle(x - 2, by + 10, x + 2, by + 10, x, by + 13)
  UI.thinText(str, bx + 3, by + 2)
end
function CAFE.drawBird(id, x, y, mode, dir)
  local it = CAFE.byId[id]
  local sp = CAFE.BIRDSPEC[id] or CAFE.BIRDSPEC.parrot
  UI.ink(sp.col)
  if mode == "fly" then CAFE.birdFly(x, y - 6, dir or 1, sp)
  elseif sp.kind == "owl" then CAFE.owlSit(math.floor(x), math.floor(y), sp, CAFE.birdLook(id, true))
  else CAFE.parrotSit(math.floor(x), math.floor(y), sp, CAFE.birdLook(id, false)) end
  UI.ink("none")
end
function CAFE.perch(cx, cy, id)                         -- the perch stand, with the bird on it when it's home
  local owl = (CAFE.byId[id] or {}).bird == "owl"
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 6, cy + 8, 12, 3, 1)                                     -- the base
  gfx.fillRect(cx - 1, cy - 3, 2, 11)                                              -- the post
  if owl then                                                                      -- an owl's perch is a little branch
    gfx.fillRoundRect(cx - 9, cy - 4, 18, 3, 1); gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy - 3); gfx.drawPixel(cx + 4, cy - 3); gfx.setColor(BLACK)
    gfx.drawLine(cx + 6, cy - 4, cx + 8, cy - 7); gfx.drawPixel(cx + 9, cy - 8)
  else
    gfx.fillRect(cx - 8, cy - 4, 16, 2)                                            -- the bar
    UI.ink("brass")
    gfx.drawLine(cx + 5, cy - 2, cx + 5, cy); gfx.fillRect(cx + 3, cy, 5, 3)       -- a seed cup hanging off it
    gfx.setColor(WHITE); gfx.drawLine(cx + 4, cy + 1, cx + 6, cy + 1); gfx.setColor(BLACK)
  end
  UI.ink("none")
  local b = G and G.birds and G.birds[id]
  if b == nil or b.mode == "home" then CAFE.drawBird(id, cx - 1, cy - 4, "home") end
  if b and b.mode == "home" and b.say then CAFE.birdSay(cx, cy - 22, b.say) end
end
function CAFE.drawBirds()                               -- birds away from their perch: flying, or sitting somewhere
  if not G or not G.birds then return end
  for id, b in pairs(G.birds) do
    if b.mode ~= "home" then
      CAFE.drawBird(id, b.x, b.y, b.mode, b.dir)
      if b.mode == "sit" and b.say then CAFE.birdSay(math.floor(b.x), math.floor(b.y) - 18, b.say) end
    end
  end
end

for _, id in ipairs({ "axotank", "axowild", "axogold" }) do CAFE.art[id] = function(cx, cy) CAFE.axoTank(cx, cy, id) end end
for _, id in ipairs({ "hamster", "hamwhite", "hamgray" }) do CAFE.art[id] = function(cx, cy) CAFE.hamCage(cx, cy, id) end end
for _, id in ipairs({ "parrot", "macaw", "bluemacaw", "cockatiel", "barnowl", "snowyowl", "hornowl" }) do CAFE.art[id] = function(cx, cy) CAFE.perch(cx, cy, id) end end

-- ---- going in and out --------------------------------------------------------------------------------
function CAFE.open()
  UI.fast(function()
    local pre = CAFE.pre
    local ready = pre ~= nil and pre.n >= 3                  -- (already read while you were looking at the title)
    for i = 1, 3 do
      if ready then CAFE.slots[i] = pre[i] or nil else CAFE.slots[i] = CAFE.read(i) end
    end
    CAFE.pre = nil
    CAFE.mode, CAFE.erase, CAFE.sel = "slots", nil, 1
    UI.setTitleItem(false)
    state = CAFE.STATE
    UI.bgSet("slots")
  end)
end

function CAFE.begin()                          -- off to the store
  if UI.color then CAFE.write() end            -- starting a shift saves the game (Playdate: in the dark, so the button press itself costs nothing)
  sfxStart()
  transitionTo(function()
    if not UI.color then CAFE.write() end
    if CAFE.keep then CAFE.resume() else newGame("cafe"); UI.shiftStartAch(CAFE.cur) end
    state = STATE_PLAY
    if not UI.color then UI.loadOn = true end  -- (Playdate: the loading scene while the cafe is drawn for the first time)
  end)
end

function CAFE.resume()                         -- back from the shop: same people, same clock, new purchases
  local g, d = CAFE.keep, CAFE.cur
  CAFE.keep = nil
  CAFE.applyLayout(d)
  setLayout("cafe")
  G = g
  G.ending, G.cafe, G.msg = false, d, nil
  G.cups.shelf = math.max(0, G.cups.shelf + d.cups - G.cupMax)
  G.cupMax = d.cups
  G.seatLimit, G.seatOff, G.seatCount = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d), CAFE.seatCountOf(d)
  G.petGrid = nil                                 -- (the tables and floor decor may have moved: the pets' map is made again)
  local sk = ((d.decor.hmus == "on") and "H" or "") .. ((d.decor.xmus == "on") and "X" or "")
  if (G.win and G.win.sk or "") ~= sk then G.win = CAFE.newWindowFor(d) end        -- (Halloween or Christmas music was switched on or off in the shop: new weather)
  for _, c in ipairs(G.line or {}) do UI.reseason(c) end                           -- (and a matcha order not taken yet becomes the new season's drink)
  if G.cust and (G.cust.stage or 0) < 2 then UI.reseason(G.cust) end
  G.scn, G.own, G.winOv, G.vineImgs, G.tops = nil, nil, nil, nil, nil; G.liveL, G.liveC = nil, nil     -- every cached picture (wall, counter, floor, window, vines...) is drawn again with the new decor
  for key in pairs(G) do
    if type(key) == "string" and (key:find("Img$") or key:find("^vine")) then G[key] = nil end
  end
  G.pets = CAFE.makePets()
  G.birds = nil                                   -- (perches may have moved: the birds start again from home)
  for i = #G.others, 1, -1 do                   -- tables may have moved or been switched off
    local c = G.others[i]
    if c.seat then
      if c.seat > G.seatLimit or G.seatOff[c.seat] then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      elseif c.state == "seated" then
        c.x, c.y = SEATS[c.seat].x, SEATS[c.seat].y
      elseif c.state == "toSeat" then
        c.path = { { SEATS[c.seat].x, SEATS[c.seat].y } }
      end
    end
  end
  setShiftMenu(true, true)
end

function CAFE.finish()                         -- the shift is over: bank it, open the shop
  G.total = G.cash + G.tips - (G.banked or 0)
  local d = CAFE.cur
  d.money = d.money + G.total
  d.shifts = d.shifts + 1
  CAFE.report = "Shift: " .. money(G.total) .. " from " .. (G.served - (G.servedBank or 0)) .. " customers"
  CAFE.keep = G                                -- the cafe waits as it is: the line, the diners, the clock, the tip jar
  G.banked = G.cash + G.tips                   -- (what has been paid into your money so far; the totals on screen carry on)
  G.servedBank = G.served
  CAFE.write()
  CAFE.mode, CAFE.shopSel, CAFE.scroll, CAFE.msg = "shop", 1, 0, nil
  CAFE.tab, CAFE.focus, CAFE.tabPos = 1, "tabs", 1
  state = CAFE.STATE
end

function CAFE.saveQuit()                       -- Menu button: bank what you've made so far
  if state ~= STATE_PLAY or not G or G.mode ~= "cafe" or G.ending then return end
  G.ending = true
  CAFE.cur.money = CAFE.cur.money + G.cash + G.tips - (G.banked or 0)
  G.banked = G.cash + G.tips
  CAFE.write()
  CAFE.closeDoor()
end

-- ---- the shop ----------------------------------------------------------------------------------------
CAFE.TABINK = { "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a13", "a14", "a15", "a12" }     -- (PC: each tab's colour)
-- the shop's pages, like browser tabs (Left / Right to switch)
CAFE.TABS = { "Cafe", "Plants", "Lighting", "Stuff", "Wall", "Window", "Rugs", "Tables", "Pets", "Clothes", "Music", "Wallpaper", "Flooring", "Seating", "Sale" }
CAFE.TABPATH = { "cafe", "plants", "lighting", "stuff", "wall", "window", "rugs", "tables", "pets", "clothes", "music", "wallpaper", "flooring", "seating", "sale" }
CAFE.TABKIND = { floor = 2, counter = 2, shelf = 2, wall = 5, tiny = 5, ceiling = 3, frame = 6, curtain = 6, rug = 7, runner = 7, orug = 7, cloth = 8, hat = 10, glasses = 10, music = 11, wallpaper = 12, flooring = 13, seating = 14 }
CAFE.SALE_TAB = 15                                -- (Sale stays the last tab)
function CAFE.tabOf(row)
  local k = row[3]
  if k == "bow" then return 10 end
  if k == "hball" then return 9 end
  if k == "scratch" or k == "scratchgo" or k == "scratchfree" then return 4 end
  if k == "seat" or k == "cup" or k == "sign" or k == "layout" then return 1 end
  local it = CAFE.byId[row[5] or ""]
  if not it then return 1 end
  if it.needs or it.kind == "pet" or it.pettab then return 9 end          -- pet furniture and tanks first, then the pets
  if it.stuff then return 4 end                    -- the radio, the fish tank, the pinwheel
  if it.lit then return 3 end                      -- lamps, candles and string lights
  return CAFE.TABKIND[it.kind] or 2
end

function CAFE.rowSig()                          -- a cheap number that changes whenever the rows would (no garbage made)
  local d = CAFE.cur
  if CAFE.rsF == frames and CAFE.rsD == d then return CAFE.rsV end      -- (worked out once a frame; a save starts it afresh)
  CAFE.rsV = CAFE.rowSigRaw(d); CAFE.rsF, CAFE.rsD = frames, d
  return CAFE.rsV
end
function CAFE.rowSigRaw(d)
  local sg = (d.seatStep or 0) * 7 + (d.cups or 0) * 13 + (d.sign == false and 1 or 0) * 3 + (d.mugSign == false and 59 or 0) + (d.nobow and 11 or 0) + (d.scratch and 41 or 0) + (tonumber(d.freeGold) or 0) * 43 + (tonumber(d.freeBean) or 0) * 47 + (tonumber(d.freeLatte) or 0) * 53
  if d.hball then for id, v in pairs(d.hball) do if v then sg = sg + 17 * #id end end end      -- (a hamster let out in its ball)
  local items = CAFE.ITEMS
  for i = 1, #items do
    local st = d.decor[items[i].id]
    if st == "on" then sg = sg + i * 3 elseif st == "off" then sg = sg + i * 5 end
  end
  if CAFE.sale then sg = sg + CAFE.sale.nextMs % 100003 + (CAFE.sale.flash and 29 or 0) end
  sg = sg + math.floor((d.stars or 0) * 100) * 31 + UI.lvl(d) * 37      -- (a prestige row comes and goes with the stars)
  return sg
end

function CAFE.rows()                           -- the rows on the tab you're looking at (kept between frames, rebuilt only when something changes)
  if CAFE.sale and pd.getCurrentTimeMilliseconds() >= CAFE.sale.nextMs then CAFE.rollSale() end
  local sg = CAFE.rowSig()
  local ac = CAFE.allC
  if not (ac and ac.sig == sg and ac.cur == CAFE.cur) then
    ac = { sig = sg, cur = CAFE.cur, rows = CAFE.allRows(), tabs = {} }
    CAFE.allC = ac
  end
  local out = ac.tabs[CAFE.tab]
  if out == nil then
    out = {}
    if CAFE.tab == CAFE.SALE_TAB then                       -- Sale: whatever is marked down right now (it's still on its own tab too)
      for _, r in ipairs(ac.rows) do
        if r[7] then out[#out + 1] = r end
      end
      local ord = {}
      for i, r in ipairs(out) do ord[r] = i end
      table.sort(out, function(a, b) if a[7] ~= b[7] then return a[7] > b[7] end return ord[a] < ord[b] end)     -- (the biggest deals first)
      if #out == 0 then out[1] = { "Nothing on sale", "", "none", 0, nil, "Back in a bit" } end
    else
      for _, r in ipairs(ac.rows) do
        if CAFE.tabOf(r) == CAFE.tab then out[#out + 1] = r end
      end
    end
    ac.tabs[CAFE.tab] = out
  end
  return out
end

CAFE.REVIEWS = {                                  -- what customers say about the things you've put out
  t15 = "The latte art painting is adorable.", t16 = "Those cherry blossoms are so pretty.", t17 = "I love the little city at night.", t18 = "Coffee cherries on the wall, so clever!", t19 = "The hot air balloon makes me want to travel.",
  rug15 = "The argyle rug is so preppy.", orug15 = "Argyle under the tables, how classy.", run15 = "Argyle to the register? Fancy.",
  rug16 = "The fish-scale rug looks like a mermaid tail!", orug16 = "Scallops under my table, so cute.", run16 = "A path of little scallops, love it.",
  rug17 = "That heart rug made my day.", orug17 = "Hearts under the tables, adorable.", run17 = "A runner full of hearts? Sweet.",
  rug18 = "The wave rug feels like the beach.", orug18 = "Waves under the table, so calming.", run18 = "Walking on waves to the register!",
  rug19 = "The Moroccan tile rug is gorgeous.", orug19 = "That tiled oval rug is stunning.", run19 = "The tile runner is so elegant.",
  rug20 = "The daisy rug is so cheerful.", orug20 = "Daisies under the tables!", run20 = "A daisy path to the register, cute.",
  cloth22 = "Argyle tablecloths, very cozy.", cloth23 = "The scalloped tablecloth is so pretty.", cloth24 = "These tiled tablecloths are lovely.", cloth25 = "Daisies on my table!",
  wc11 = "The flowery curtains are so sweet.", wc12 = "Cafe curtains! So French.", wc13 = "Velvet drapes? This place is fancy.", wc14 = "The leafy curtains are lovely.",
  wc15 = "Tartan curtains, so cozy.", wc16 = "The daisy curtains are adorable.",
  clock = "That wall clock keeps me on time for my coffee!", cuckoo = "The cuckoo clock made my whole day. Cuckoo!",
  calendar = "Handy calendar on the wall, I finally know the date.",
  plant = "That spiky plant gives the place real attitude.", cactus = "Love the cactus. Looks sharp!",
  fern = "The leafy fern makes it feel like a little jungle in here.", flowers = "The flower pot smells lovely.",
  tree = "A Christmas tree all year round? Yes please!", pumpkin = "That pumpkin is the best part of the cafe!",
  palm = "A palm tree inside a cafe, I feel like I'm on vacation.", snake = "The snake plant is stylish and low key.",
  sunflower = "Those sunflowers brighten up my morning.", bonsai = "The bonsai is so calm and peaceful.",
  monstera = "The monstera is huge and gorgeous.", saltlamp = "The salt lamp makes it so warm and cozy.",
  lavalamp = "I could watch that lava lamp for hours.", floorlamp = "The floor lamp makes it feel like home.",
  neoncup = "The neon cup sign is super cool at night.", tulips = "Fresh tulips on the counter, what a nice touch.",
  succ = "The little succulent on the counter is adorable.", daisies = "The daisy vase made me smile.",
  minicac = "That mini cactus is so cute!", herbs = "The herb pot makes the counter smell great.",
  candle1 = "That candle flickering on the table is so cozy.", candle2 = "The tall taper candle is so elegant.",
  candle3 = "Those little tealights make it feel like a spa.", candle4 = "The jar candle smells like heaven. Well, it looks like it does.",
  candle5 = "A candelabra! This place is fancy.", candle6 = "The little lantern candle is so charming.",
  candle7 = "Floating candles? Magical.",
  incense = "The incense makes this place smell calm and wonderful.",
  arclamp = "That arc lamp is so stylish.", torchiere = "The torchiere lamp lights the whole room beautifully.",
  tripodlamp = "The tripod lamp is such a cool piece.", globelamp = "The globe lamp glows like a little moon.",
  tiffany = "That Tiffany lamp is a work of art.", tiffanytab = "The little Tiffany lamp on my table is gorgeous.",
  itemstand = "The stand by the wall is the perfect place for a lamp.", streetlamp = "A street lamp inside a cafe? Love it.",
  paperlamp = "The paper lantern lamp is so soft and calming.", neonheart = "The neon heart sign gives me all the feels.",
  neonbolt = "The neon bolt sign is electric!", neonstar = "That neon star sign is a star itself.",
  neonmoon = "The neon moon sign is so dreamy at night.", neonarrow = "The neon arrow sign pointed me straight to the coffee.",
  discoball = "A disco ball in a cafe? Let's dance!", aquarium = "I watched the fish tank for twenty minutes.", snaketank = "The snake in the tank is so smooth. Kinda scary, kinda great.",
  parrot = "The parrot said COFFEE! at me. Best greeting ever.", macaw = "That macaw landed on my table and stole my heart.",
  bluemacaw = "A big blue macaw flew right over my latte!", cockatiel = "The cockatiel whistled along to the music.",
  barnowl = "The barn owl turned its head ALL the way round. Wow.", snowyowl = "A snowy owl in a cafe? Magical.", hornowl = "The horned owl watched me sip. Very wise.",
  axotank = "The axolotl smiled at me. I smiled back.", axowild = "The wild axolotl wiggled its little gills at me!", axogold = "That golden axolotl is pure sunshine.",
  hamster = "The hamster ran on its wheel the whole time I was here.", hamwhite = "The white hamster is the size of a marshmallow!", hamgray = "The little gray hamster rolled right past my feet!",
  corgi = "A corgi! Those little legs!", tricorgi = "The tricolor corgi did a happy wiggle.",
  bunny = "A bunny hopped by my table. I melted.", brownbun = "The brown bunny did a binky!", graybun = "The gray bunny is so fluffy.",
  dutchbun = "That Dutch bunny looks like it wears a tuxedo.", lopbun = "The lop-eared bunny's ears!! So floppy!",
  turtle = "The little turtle is the sweetest thing ever.", boxturtle = "The box turtle hid in its shell when I waved.", tortoise = "That tortoise is so slow and so wise.", slider = "The red-ear turtle has so much attitude.",
  pinwheel = "The pinwheel on the wall is so fun.", radio = "The retro radio playing on the counter is a great touch.",
  boombox = "That boom box is pumping out the best tunes.", luckycat = "The lucky cat waved at me. I feel luckier already.",
  record = "A record player! The music sounds so warm.", snowglobe = "I shook the snow globe. Twice.",
  gumball = "A gumball machine in a cafe? I love it.", cradle = "I could watch that Newton's cradle click all day.",
  miniplaydate = "That little Pee-Dee has been cranking all day.", jukebox = "The juke box is a showstopper. I picked a song.",
  ivy = "Those ivy vines hanging off the shelf are lovely.", bloomvine = "The flowering vines are gorgeous.",
  fernvine = "The fern fronds by the shelf look so fresh.", heartvine = "Those little hearts hanging from the shelf are adorable.",
  berryvine = "The berry vines look good enough to eat.", starvine = "The twinkling vines by the shelf are magical.",
  moss = "The hanging moss gives the place a cozy forest feel.", beadvine = "The bead strands catch the light so nicely.",
  wisteria = "The wisteria hanging off the shelf is dreamy.", lanternvine = "Those tiny lanterns on the shelf are so sweet.",
  lights = "The string lights are so cozy.", fairylights = "The fairy lights make this place feel like a dream.",
  globelights = "Those big round bulbs are so retro. Love them.", lanternlights = "The paper lantern lights glow so softly.",
  heartlights = "The heart lights above the counter made me smile.", starlights = "The star-shaped lights are pure magic.", rug = "The welcome rug really does feel welcoming.",
  t1 = "The tiny landscape on the wall is so charming.", t2 = "That tiny heart on the wall made me smile.",
  t3 = "The tiny sunburst brightens up the wall.", t4 = "I love the tiny mug print. Very on brand!",
  t5 = "The cat portrait is hilarious. I love it.", t6 = "Nice little mirror, I checked my hair.",
  t7 = "The party bunting makes every day feel like a party.", t8 = "Those little stars on the wall are so sweet.",
  t9 = "The music notes on the wall go with the vibe.", t10 = "The moon and stars on the wall are dreamy.",
  t12 = "That sailboat on the wall is calming.", t13 = "The pastel bouquet painting is so pretty.", t14 = "The matcha painting makes me want a matcha latte.",
  rug13 = "The pastel floral rug is like a spring garden.", rug14 = "The matcha rug is such a calm shade of green.",
  orug13 = "Flowers under my table, so cute!", orug14 = "The matcha oval rug is so soothing.", run13 = "A path of flowers to the register? Adorable.",
  run14 = "The leafy green runner is so fresh.", cloth20 = "The pastel flower tablecloth is darling.", cloth21 = "The matcha tablecloth matched my drink!", cp1 = "Flowers on my table, how sweet!",
  cp2 = "The candle on my table was so cozy.", cp3 = "The little sprig on my table is a nice touch.",
  cp4 = "A cactus on my table. Don't touch!", cp5 = "A pumpkin on my table! Love it.",
  cp6 = "A tiny Christmas tree on my table, so festive!", cattree = "The cat tree is the best seat in the house, says the cat.",
  dogbed = "The dog bed looks so comfy, I almost took a nap.", cat = "The cat napping by my table made my day.",
  dog = "The dog said hello when I walked in!",
  hmus = { "It's so spooky in here and I love it!", "That spooky swing music with the leaves falling outside is perfect.",
           "The fall vibes in here are unreal. Pumpkin spice and spooky tunes!", "Rain on the window and spooky music? Cozy and creepy, I'm in.",
           "Happy Halloween! This place has the best fall vibes in town.", "The haunted waltz had me grinning over my pumpkin spice." },
  xmus = { "I love the snow in the window, so peaceful.", "Jingly music and snow at the window. It feels like the holidays in here.",
           "The festive vibes are so nice, I never want to leave.", "Hot cocoa, snowfall and ice skating music. Pure magic!",
           "It feels like Christmas in here. I love it!", "The snow falling outside while that waltz plays is so cozy." },
}

function CAFE.reviewFor(it, name, skip)
  local who = CAFE.WHO
  local txt = CAFE.REVIEWS[it.id]
  if type(txt) == "table" then                    -- several lines to pick from (skip = one already used, so a second review differs)
    local n = math.random(#txt)
    if skip and #txt > 1 then while txt[n] == skip do n = math.random(#txt) end end
    txt = txt[n]
    CAFE.lastReview = txt
  end
  local low = string.lower(it.name)
  if txt == nil then
    local k = it.kind
    if k == "hat" then txt = "Love the " .. low .. " on the barista!"
    elseif k == "glasses" then txt = "Those " .. low .. " look great on the barista."
    elseif k == "pet" then txt = "The " .. low .. " is adorable. I came back just for them!"
    elseif k == "frame" then txt = "Love the " .. low .. " by the window."
    elseif k == "curtain" then txt = "Those " .. low .. " are so pretty."
    elseif k == "runner" then txt = "The " .. low .. " is a lovely touch on the floor."
    elseif k == "orug" then txt = "The " .. low .. " ties the tables together."
    elseif k == "cloth" then txt = "My table had a " .. low .. ". So fancy!"
    elseif k == "rug" then txt = "The " .. low .. " is so cozy underfoot."
    else txt = "I love the " .. low .. " at " .. name .. "." end
  end
  return CAFE.REVHEAD[math.random(#CAFE.REVHEAD)] .. "\"" .. txt .. "\" - " .. who[math.random(#who)]
end

CAFE.WHO = { "Dana", "Marcus", "Priya", "Leo", "Jo", "Sam", "Ines", "Theo", "Mia", "Ravi", "Zoe", "Omar", "Christian", "Grace", "Bella", "Jay", "Kelly",
             "Aiden", "Amara", "Beatrice", "Caleb", "Chloe", "Dmitri", "Elena", "Felix", "Fatima", "Gus", "Hana", "Hugo", "Imani", "Isaac", "Jasmine", "Kai",
             "Lena", "Lucas", "Maya", "Mateo", "Nadia", "Noah", "Olive", "Oscar", "Penny", "Quinn", "Rosa", "Rhys", "Sasha", "Sofia", "Tariq", "Uma",
             "Victor", "Wendy", "Xavier", "Yara", "Zane", "Abe", "Birdie", "Cleo", "Dev", "Edie", "Finn", "Greta", "Harper", "Ivy", "Jun", "Kofi",
             "Lola", "Milo", "Nora", "Otis", "Pia", "Remy", "Stella", "Tomas", "Una", "Vera", "Walt", "Yuki" }
function CAFE.who() return CAFE.WHO[math.random(#CAFE.WHO)] end
-- reviews that come with each barista level (every level keeps the ones before it): the higher you go, the more glowing they get
CAFE.LVREVIEWS = {
  [2] = { "The barista just leveled up and you can taste it.", "Level 2 barista? The latte art is getting serious.",
          "Service here keeps getting better and better.", "Came for the coffee, stayed for the barista's skills." },
  [3] = { "This barista pulls the smoothest shots in town.", "The foam on my latte was a perfect little heart.",
          "My order was ready before I finished asking. Wow.", "The crema on my coffee was picture perfect." },
  [4] = { "People line up just to watch the barista work.", "A Level 4 barista who still remembers my name. Love it.",
          "I've tried every cafe in town. This one wins.", "The pour was so smooth it was basically art." },
  [5] = { "Five star barista, five star coffee. Easy.", "This barista could run a coffee school.",
          "I drove across town for this latte and I'd do it again.", "Even my coffee snob uncle approved. That's huge." },
  [6] = { "A food blogger told me about this place. They were right.", "This barista is a local legend now.",
          "Best cup of my life. I'm not exaggerating.", "The matcha here is the best I've ever had. I said it." },
  [7] = { "I heard the barista here won a latte art contest.", "Tourists ask for this cafe by name now.",
          "Pure magic in a mug. Every single time.", "I proposed here. She said yes. The coffee helped." },
  [8] = { "There's a waitlist to sit by the window now.", "This barista could make decaf taste exciting.",
          "They should put this cafe on a postage stamp.", "Every sip is like a warm hug." },
  [9] = { "A coffee magazine called this the best cafe around.", "My grandkids will hear stories about this coffee.",
          "The barista's speed is unreal. And so friendly!", "Is there anything this barista can't brew?" },
  [10] = { "Coffee royalty works here. Bow to the barista.", "World-class coffee in our little town. Who knew?",
           "Legend status. Simply the best cafe there is.", "I'd give it six stars if I could." },
}
CAFE.REVHEAD = { "Review: ", "5-star review: ", "A regular says: ", "New review: ", "Overheard: " }
function CAFE.reviewLine(txt)                          -- one review, the way the scroller shows it
  return CAFE.REVHEAD[math.random(#CAFE.REVHEAD)] .. "\"" .. txt .. "\" - " .. CAFE.who()
end
function CAFE.levelReviews(lv, n)                      -- n reviews from those this level has unlocked (at least one from the newest level)
  local out, pool = {}, {}
  local top = math.min(lv, 10)
  for l = 2, top do for _, t in ipairs(CAFE.LVREVIEWS[l]) do pool[#pool + 1] = t end end
  if #pool == 0 then return out end
  local newest = CAFE.LVREVIEWS[top]
  if newest then out[1] = newest[math.random(#newest)] end
  while #out < n and #pool > 0 do
    local t = table.remove(pool, math.random(#pool))
    if t ~= out[1] then out[#out + 1] = t end
  end
  return out
end

function CAFE.shopMsgs()                         -- welcome lines, what's on sale, and customer reviews of what you own
  if CAFE.msgList and CAFE.msgChecked and frames - CAFE.msgChecked < 40 then return CAFE.msgList end   -- (checked twice a second, not every frame)
  CAFE.msgChecked = frames
  local d = CAFE.cur
  local name = (d.name and d.name ~= "") and d.name or "your cafe"
  local sg = CAFE.rowSig()
  if CAFE.msgKey == sg and CAFE.msgName == name and CAFE.msgList then return CAFE.msgList end
  local ownedIds = {}
  for _, it in ipairs(CAFE.ITEMS) do if d.decor[it.id] == "on" and not it.copyOf then ownedIds[#ownedIds + 1] = it.id end end
  local key = sg
  local sale, half, rest = {}, {}, {}
  if CAFE.sale then
    for id in pairs(CAFE.sale.ids) do
      local it = CAFE.byId[id]
      if it then
        local pct = CAFE.salePct(id)
        sale[#sale + 1] = it.name
        if pct >= 50 then half[#half + 1] = it.name else rest[#rest + 1] = { it.name, pct } end
      end
    end
    table.sort(sale); table.sort(half)
    table.sort(rest, function(a, b) if a[2] ~= b[2] then return a[2] > b[2] end return a[1] < b[1] end)
  end
  local function andList(t)
    if #t == 1 then return t[1] end
    return table.concat(t, ", ", 1, #t - 1) .. " & " .. t[#t]
  end
  local m = { "Welcome to Coffee Supply, " .. name .. "!" .. ((UI.lvl(d) >= 2) and ("  (Barista Lv " .. UI.lvl(d) .. ")") or "") }
  if #half >= 1 then m[#m + 1] = "HALF PRICE: " .. andList(half) .. (#half == 1 and " is" or " are") .. " 50% off!" end
  if #rest >= 1 then
    local top = {}
    for i = 1, math.min(3, #rest) do top[i] = rest[i][1] .. " " .. rest[i][2] .. "% off" end
    m[#m + 1] = "ALSO ON SALE: " .. andList(top) .. (#rest > 3 and " and more!" or "!")
  end
  if #sale >= 2 then m[#m + 1] = #sale .. " things are marked down, 10% to 50% off. Open the Sale tab!" end
  -- reviews: about things you really have out (up to 8), general ones, and the ones your barista level has unlocked,
  -- mixed together (they're most of what scrolls by; the picks change every time the scroller comes round)
  local revs = {}
  local pool = {}
  for _, id in ipairs(ownedIds) do pool[#pool + 1] = CAFE.byId[id] end
  local picked = 0
  while #pool > 0 and picked < 8 do
    local it = table.remove(pool, math.random(#pool))
    revs[#revs + 1] = CAFE.reviewFor(it, name)
    if it.kind == "music" then revs[#revs + 1] = CAFE.reviewFor(it, name, CAFE.lastReview) end        -- (the season's music gets two, it's what people notice)
    picked = picked + 1
  end
  local general = {
    "Best coffee in town at " .. name .. "!", name .. " is my happy place.", "Five stars, would crank again.",
    "I come to " .. name .. " every single day.", "Fast service at " .. name .. "!", "The baristas at " .. name .. " know my order.",
    "Smells amazing the second you walk in.", "My new favorite spot, thanks to " .. name .. ".", "I brought my whole family to " .. name .. ".",
    "Worth the trip across town.", "The music, the smell, the cozy vibe. Perfect.", "Cutest cafe I've ever been to.",
    "Grabbed a coffee to go and came right back for another.", "The barista smiled at everyone. Such a nice place.",
  }
  if (d.seatStep or 0) >= 1 then general[#general + 1] = "Lots of cozy places to sit at " .. name .. "." end
  for _ = 1, 2 do revs[#revs + 1] = CAFE.reviewLine(table.remove(general, math.random(#general))) end
  for _, t in ipairs(CAFE.levelReviews(UI.lvl(d), 3)) do revs[#revs + 1] = CAFE.reviewLine(t) end
  for i = #revs, 2, -1 do local j = math.random(i); revs[i], revs[j] = revs[j], revs[i] end
  for _, t in ipairs(revs) do m[#m + 1] = t end
  m[#m + 1] = ({ "Did you know? The more decor you put out, the faster your star meter fills!",
                 "Tip: decorations make every review count for more stars!",
                 "Decor tip: a cozier cafe earns stars faster!" })[math.random(3)]
  if #sale >= 2 and math.random() < 0.5 then m[#m + 1] = "Deals change every few minutes. Check back soon!"
  else m[#m + 1] = (math.random() < 0.5) and "New stuff in every tab. Take a look around!" or "Thanks for shopping at Coffee Supply!" end
  gfx.setFont(fontBold)
  local list, dur, total, wid = {}, {}, 0, {}
  for i, t in ipairs(m) do                      -- a long one stays up long enough to scroll all the way across
    local w = gfx.getTextSize(t)
    list[i] = t
    wid[i] = w
    dur[i] = (w <= 372) and 6000 or math.floor((w + 372) / 55 * 1000)
    total = total + dur[i]
  end
  CAFE.msgKey, CAFE.msgName, CAFE.msgList, CAFE.msgDur, CAFE.msgTotal, CAFE.msgW = key, name, list, dur, total, wid
  return list
end

function CAFE.fitOne(str, maxW, bold)           -- one line cut short with "..." if it can't fit the box
  CAFE.fitCache = CAFE.fitCache or {}
  local key = (bold and "b" or "n") .. maxW .. "|" .. str
  local c = CAFE.fitCache[key]
  if c then return c end
  gfx.setFont(bold and fontBold or fontNormal)
  local out = str
  if gfx.getTextSize(out) > maxW then
    while #out > 1 and gfx.getTextSize(out .. "...") > maxW do out = string.sub(out, 1, #out - 1) end
    out = out .. "..."
  end
  CAFE.fitCache[key] = out
  return out
end

function CAFE.fitLines(str, maxW, bold, maxLines)  -- words wrapped to whole lines no wider than the box (the last line ends in "..." if it still runs over)
  CAFE.fitCache = CAFE.fitCache or {}
  local key = (bold and "B" or "N") .. maxW .. ":" .. maxLines .. "|" .. str
  local c = CAFE.fitCache[key]
  if c then return c end
  gfx.setFont(bold and fontBold or fontNormal)
  local lines, line = {}, ""
  for word in string.gmatch(str, "%S+") do
    local try = (line == "") and word or (line .. " " .. word)
    if gfx.getTextSize(try) > maxW and line ~= "" then lines[#lines + 1] = line; line = word else line = try end
  end
  if line ~= "" then lines[#lines + 1] = line end
  if #lines == 0 then lines[1] = "" end
  if #lines > maxLines then
    local rest = table.concat(lines, " ", maxLines)
    lines = { table.unpack(lines, 1, maxLines) }
    lines[maxLines] = rest
  end
  for i = 1, #lines do lines[i] = CAFE.fitOne(lines[i], maxW, bold) end
  CAFE.fitCache[key] = lines
  return lines
end

-- little 5x7 letters and digits for the sale stickers, each one thickened by a pixel (so 6 wide, 7 with its gap)
UI.PIXG = {
  S = { ".####", "#...#", "#....", ".###.", "....#", "#...#", ".###." },
  A = { ".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
  L = { "#....", "#....", "#....", "#....", "#....", "#....", "#####" },
  E = { "#####", "#....", "#....", "####.", "#....", "#....", "#####" },
  O = { ".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
  F = { "#####", "#....", "#....", "####.", "#....", "#....", "#...." },
  ["0"] = { ".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###." },
  ["1"] = { "..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###." },
  ["2"] = { ".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####" },
  ["3"] = { ".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###." },
  ["4"] = { "...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#." },
  ["5"] = { "#####", "#....", "####.", "....#", "....#", "#...#", ".###." },
  ["6"] = { ".###.", "#....", "#....", "####.", "#...#", "#...#", ".###." },
  ["7"] = { "#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..." },
  ["8"] = { ".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###." },
  ["9"] = { ".###.", "#...#", "#...#", ".####", "....#", "....#", ".###." },
  ["%"] = { "##..#", "##..#", "...#.", "..#..", ".#...", "#..##", "#..##" },
  B = { "####.", "#...#", "#...#", "####.", "#...#", "#...#", "####." },
  C = { ".###.", "#...#", "#....", "#....", "#....", "#...#", ".###." },
  D = { "####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####." },
  G = { ".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".###." },
  H = { "#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
  I = { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "#####" },
  J = { "..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.." },
  K = { "#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#" },
  M = { "#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#" },
  N = { "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", "#...#" },
  P = { "####.", "#...#", "#...#", "####.", "#....", "#....", "#...." },
  Q = { ".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#" },
  R = { "####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#" },
  T = { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.." },
  U = { "#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
  V = { "#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.." },
  W = { "#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#" },
  X = { "#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#" },
  Y = { "#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.." },
  Z = { "#####", "....#", "...#.", "..#..", ".#...", "#....", "#####" },
  [":"] = { ".....", "..#..", "..#..", ".....", "..#..", "..#..", "....." },
  ["!"] = { "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.." },
  ["/"] = { "....#", "...#.", "...#.", "..#..", ".#...", ".#...", "#...." },
}
function UI.pixWidth(str)
  local w = 0
  for i = 1, #str do
    w = w + (string.sub(str, i, i) == " " and 4 or 7)
  end
  return w - 1
end
UI.FX_STREAK = { "inkorange", "inkred", "flame", "inkred" }
function UI.pixTextCycle(str, x, y, cols)              -- (PC: a colour wave runs along the letters; the Playdate just draws it)
  if not UI.color then return UI.pixText(str, x, y) end
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    UI.ink(cols[(i + math.floor(frames / (4))) % #cols + 1])
    UI.pixText(ch, gx, y)
    gx = gx + (ch == " " and 4 or 7)
  end
end
function UI.pixText(str, x, y)                       -- in the current colour; x, y = top-left
  do                                                    -- (drawn once, then stamped; in whichever colour is on, and on the PC its tint too)
    local col = UI.getColor()
    if col == -1 then return UI.pixTextRaw(str, x, y) end                -- (a pattern: drawn as it is)
    local im = UI.cacheImg("pixText", col + 4 * UI.inkNum(), str, UI.pixWidth(str) + 2, 9, function() gfx.setColor(col); UI.pixTextRaw(str, 0, 0) end)
    if im then UI.cacheDraw(im, x, y) else gfx.setColor(col); UI.pixTextRaw(str, x, y) end
    gfx.setColor(col)
    return
  end
  UI.pixTextRaw(str, x, y)
end
function UI.pixClock(str, x, y)                       -- text that changes every second (a countdown): stamped a letter at a time, so nothing new is ever drawn
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    if ch ~= " " then UI.pixText(ch, gx, y) end
    gx = gx + (ch == " " and 4 or 7)
  end
end
function UI.pixTextRaw(str, x, y)
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    local g = UI.PIXG[ch]
    if g then
      for ry = 1, 7 do
        local row = g[ry]
        local c = 1
        while c <= 5 do
          if string.sub(row, c, c) == "#" then
            local c2 = c
            while c2 < 5 and string.sub(row, c2 + 1, c2 + 1) == "#" do c2 = c2 + 1 end
            gfx.fillRect(gx + c - 1, y + ry - 1, c2 - c + 2, 1)      -- (one pixel wider than the run: the thickening)
            c = c2 + 1
          else
            c = c + 1
          end
        end
      end
    end
    gx = gx + (ch == " " and 4 or 7)
  end
end

-- the same letters with single-pixel strokes (6 across each, a space is 3): a long cafe name still fits its sign
function UI.thinWidth(str)
  local w = 0
  for i = 1, #str do w = w + (string.sub(str, i, i) == " " and 3 or 6) end
  return w - 1
end
function UI.thinText(str, x, y)                      -- in the current colour; x, y = top-left
  do                                                    -- (drawn once, then stamped; in whichever colour is on, and on the PC its tint too)
    local col = UI.getColor()
    if col == -1 then return UI.thinTextRaw(str, x, y) end                -- (a pattern: drawn as it is)
    local im = UI.cacheImg("thinText", col + 4 * UI.inkNum(), str, (UI.thinWidth and UI.thinWidth(str) or (#str * 6)) + 2, 9, function() gfx.setColor(col); UI.thinTextRaw(str, 0, 0) end)
    if im then UI.cacheDraw(im, x, y) else gfx.setColor(col); UI.thinTextRaw(str, x, y) end
    gfx.setColor(col)
    return
  end
  UI.thinTextRaw(str, x, y)
end
function UI.thinTextRaw(str, x, y)
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    local g = UI.PIXG[ch]
    if g then
      for ry = 1, 7 do
        local row = g[ry]
        local c = 1
        while c <= 5 do
          if string.sub(row, c, c) == "#" then
            local c2 = c
            while c2 < 5 and string.sub(row, c2 + 1, c2 + 1) == "#" do c2 = c2 + 1 end
            gfx.fillRect(gx + c - 1, y + ry - 1, c2 - c + 1, 1)
            c = c2 + 1
          else
            c = c + 1
          end
        end
      end
    end
    gx = gx + (ch == " " and 3 or 6)
  end
end

-- the sale sticker: how much is off. Half price ones are solid, the rest are outlined. x, y = top-left; 60 wide, 17 tall.
UI.SALE_W = 60
function UI.saleSticker(x, y, pct, ink, bg)
  local txt = pct .. "% OFF"
  gfx.setColor(bg); gfx.fillRoundRect(x, y, UI.SALE_W, 17, 6)
  gfx.setColor(ink)
  if pct >= 50 then
    gfx.fillRoundRect(x, y, UI.SALE_W, 17, 6)
    gfx.setColor(bg)
  else
    gfx.drawRoundRect(x, y, UI.SALE_W, 17, 6)
  end
  UI.pixText(txt, x + math.floor((UI.SALE_W - UI.pixWidth(txt)) / (2)), y + 5)
  gfx.setColor(BLACK)
end

function CAFE.salePct(id)                           -- how much off an item is right now (nil when it isn't on sale)
  local v = CAFE.sale and CAFE.sale.ids[id]
  if not v then return nil end
  if CAFE.sale.flash then return 50 end            -- (a Flash Sale from the daily gift: all of it half price)
  return (type(v) == "number") and v or 50
end

function CAFE.rowName(name, price, sale)          -- a list row's name, kept clear of its price and the SALE sticker
  CAFE.fitCache = CAFE.fitCache or {}
  local key = "R" .. name .. "|" .. price .. "|" .. (sale and 1 or 0)
  local c = CAFE.fitCache[key]
  if c then return c[1], c[2] end
  gfx.setFont(fontBold)
  local pw = (price ~= "") and gfx.getTextSize(price) or 0
  local tx = 275 - pw - 4 - UI.SALE_W              -- the sticker's left edge
  local right = sale and (tx - 5) or (275 - pw - 8)
  local txt = CAFE.fitOne(name, right - 20, false)
  CAFE.fitCache[key] = { txt, tx }
  return txt, tx
end

function CAFE.drawShopMsg()                      -- one line a little below the address bar; long ones scroll right to left
  local list = CAFE.shopMsgs()
  local durs = CAFE.msgDur
  local total = 0
  for i = 1, #list do total = total + math.floor(durs[i] * 3 / (100)) end      -- (milliseconds to frames at 30 per second)
  CAFE.msgFr = ((CAFE.msgFr or 0) + 1) % math.max(total, 1)       -- counted in frames, so the scroll moves the same whole pixels every frame
  if CAFE.msgFr == 0 then CAFE.msgKey = nil; CAFE.msgChecked = nil; CAFE.msgImgs = nil end   -- (round again: new reviews picked next time)
  local t = CAFE.msgFr
  local idx = 1
  while idx < #list and t >= math.floor(durs[idx] * 3 / (100)) do t = t - math.floor(durs[idx] * 3 / (100)); idx = idx + 1 end
  local str = list[idx]
  local w = CAFE.msgW[idx]
  gfx.setColor(BLACK)
  if w <= 372 then
    drawTC(str, 200, UI.shopBgImg() and 30 or 31, true)
  else
    local imgs = CAFE.msgImgs
    if not imgs or CAFE.msgImgsFor ~= list then imgs = {}; CAFE.msgImgs = imgs; CAFE.msgImgsFor = list end
    local im = imgs[idx]
    if im == nil then                                -- the long line is drawn once into a picture; scrolling it is then a single draw per frame
      im = CAFE.snap(function() gfx.setColor(BLACK); drawT(str, 2, 2, true) end, 0, 22, 0, w + 6) or false
      imgs[idx] = im
    end
    if im then
      if UI.shopBgImg() then gfx.setClipRect(10, 29, 380, 17); im:draw(400 - t * 2 - 2, 28); gfx.clearClipRect()
      else im:draw(400 - t * 2 - 2, 29) end
    else
      gfx.setClipRect(0, 29, 400, 22)
      drawT(str, 400 - t * 2, 31, true)
      gfx.clearClipRect()
    end
  end
end

function CAFE.rollSale()                       -- ten things go on sale: two or four of them half price, the rest 10 to 45 percent off
  local d, pool = CAFE.cur, {}
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    local tab = CAFE.tabOf({ nil, nil, "buy", 0, it.id })
    if tab >= 3 and not it.copyOf and d.decor[it.id] == nil and (it.needs == nil or CAFE.hasNeed(d, it.needs)) then
      pool[#pool + 1] = it.id
    end
  end
  local count = math.min(10, #pool)
  local old = CAFE.sale and CAFE.sale.ids or {}
  local fresh = {}
  for _, id in ipairs(pool) do if not old[id] then fresh[#fresh + 1] = id end end
  if #fresh < count then fresh = pool end          -- (nearly everything was on sale last time: nothing else to pick)
  local nHalf = math.min((math.random() < 0.5) and 2 or 4, count)
  local ids = {}
  for k = 1, count do
    if #fresh == 0 then break end
    local id = table.remove(fresh, math.random(#fresh))
    ids[id] = (k <= nHalf) and 50 or (5 * math.random(2, 9))        -- 10, 15 ... 45 percent off
  end
  CAFE.sale = { ids = ids, nextMs = pd.getCurrentTimeMilliseconds() + (240 + math.random() * 120) * 1000 }
end

function CAFE.allRows()
  if CAFE.sale and pd.getCurrentTimeMilliseconds() >= CAFE.sale.nextMs then CAFE.rollSale() end
  local d = CAFE.cur
  local rows = {}
  CAFE.scratchRows(rows)                           -- (scratch-off tickets: first on the Stuff tab)
  if d.seatStep < 5 then
    local cost = math.floor(CAFE.SEAT_COST[d.seatStep + 1] * 100 * CAFE.PRICE + 0.5)
    local nxt = CAFE.SEAT_N[d.seatStep + 1]
    local label = (d.seatStep == 4) and "Corner booth (L-table)" or ("Add a table  " .. CAFE.seatsOf(d.seatStep) .. " > " .. nxt .. " seats")
    if d.seatStep == 0 then
      rows[#rows + 1] = { "Dine-in starting kit", money(cost), "seat", cost, nil, "Comes with 1 table and 2 cups" }
    else
      rows[#rows + 1] = { label, money(cost), "seat", cost, nil, "More seats, bigger tips", layout = true }
    end
  else
    rows[#rows + 1] = { "Seats  " .. CAFE.seatsOf(5), "MAX", "none", 0, nil, "Your cafe is full of tables!", pv = "table", layout = true }
  end
  if d.seatStep == 0 then
    -- (no cups to buy until you have the dine-in starting kit)
  elseif d.cups < 10 then
    local cost = CAFE.CUP_COST[math.max(1, d.cups - 1)] * 100 * CAFE.PRICE
    rows[#rows + 1] = { "More cups  " .. d.cups .. " > " .. (d.cups + 1), money(cost), "cup", cost, nil, "Cups for dine-in drinks" }
  else
    rows[#rows + 1] = { "Cups  " .. d.cups, "MAX", "none", 0, nil, "You own every cup there is!", pv = "cup" }
  end
  if d.char == 3 then rows[#rows + 1] = { "Hair bow", d.nobow and "OFF" or "ON", "bow", 0, nil, "Hides under any hat" } end
  rows[#rows + 1] = { "Cafe sign", d.sign == false and "OFF" or "ON", "sign", 0, nil, "Off frees up wall space" }
  rows[#rows + 1] = { "Coffee picture", d.mugSign == false and "OFF" or "ON", "sign", 0, nil, "Off frees up a wall spot", mug = true }
  if (d.stars or 0) >= 4.999 then
    local nl = UI.lvl(d) + 1
    local subs = { "Stars start again from 0" }                -- (the words take turns, so each one fits the box)
    if UI.lvlTipPct(nl) > UI.lvlTipPct(nl - 1) then subs[#subs + 1] = "Tips +5% (to +" .. UI.lvlTipPct(nl) .. "% in all)" end
    if UI.lvlSlowPct(nl) > UI.lvlSlowPct(nl - 1) then subs[#subs + 1] = "Patience +5% (to " .. UI.lvlSlowPct(nl) .. "% slower)" end
    subs[#subs + 1] = "A free Golden Bean ticket!"
    table.insert(rows, 1, { "Prestige: Barista Lv " .. nl, "GO!", "prestige", 0, nil, subs[1], subs = subs })
  end
  for _, it in ipairs(CAFE.ITEMS) do
    if not it.copyOf and (it.needs == nil or CAFE.hasNeed(d, it.needs)) then
      local st = d.decor[it.id]
      local multi = CAFE.multiOK(it) and CAFE.countOf(d, it.id) or nil
      if multi and multi.tot > 0 then                      -- owned: how many, and a row to buy another
        local label = (multi.tot == 1) and (multi.placed == 1 and "ON" or "OFF") or (multi.placed == 0 and "OFF" or (multi.placed .. "/" .. multi.tot .. " ON"))
        rows[#rows + 1] = { it.name, label, "toggle", 0, it.id, CAFE.DESC[it.id], multi = multi }
        local cost = it.cost * 100 * CAFE.PRICE
        rows[#rows + 1] = { "Buy another", money(cost), "more", cost, it.id, CAFE.DESC[it.id], multi = multi, more = true }
      elseif st == nil then
        local cost = it.cost * 100 * CAFE.PRICE
        local pct = CAFE.salePct(it.id)
        if pct then
          cost = math.floor(cost * (100 - pct) / 100 + 0.5)
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id], pct }
        else
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id] }
        end
      else
        rows[#rows + 1] = { it.name, st == "on" and "ON" or "OFF", "toggle", 0, it.id, CAFE.DESC[it.id] }
        if it.ham then                                   -- a hamster you own: let it out to roll round the floor in a ball, or keep it in its cage
          rows[#rows + 1] = { "Hamster ball", (d.hball and d.hball[it.id]) and "ON" or "OFF", "hball", 0, it.id, "Rolls round the floor in a ball", pv = "hball" }
        end
      end
    end
  end
  return rows
end

function CAFE.say(str) CAFE.msg, CAFE.msgT = str, 2.4 end

-- the shop's address bar: round back / forward / reload buttons, then the address in its own field with a padlock,
-- the page's name in bold, a bookmark star, and a quick loading line whenever you change tabs
UI.NAVICON = {
  back = { "...k....", "..kk....", ".kkkkkkk", "kkkkkkkk", ".kkkkkkk", "..kk....", "...k...." },
  fwd  = { "....k...", "....kk..", "kkkkkkk.", "kkkkkkkk", "kkkkkkk.", "....kk..", "....k..." },
  ref  = { "...kkkk...", ".kk....k.k", ".k......kk", "k......kkk", "k.........", "k........k", "k........k", ".k......k.", ".kk....kk.", "...kkkk..." },
}
function UI.urlBar()
  UI.ink("s_url")
  gfx.setColor(BLACK); gfx.fillRoundRect(8, 6, 384, 24, 12)                   -- a soft shadow under the bar
  gfx.setColor(WHITE); gfx.fillRoundRect(8, 4, 384, 24, 12)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(8, 4, 384, 24, 12); gfx.setLineWidth(1)
  for i, k in ipairs({ "back", "fwd", "ref" }) do                              -- round buttons with crisp pixel icons
    local cx = 21 + (i - 1) * 18
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, 16, 7)
    local ic = UI.NAVICON[k]
    UI.pic(ic, cx - math.floor(#ic[1] / 2), 16 - math.floor(#ic / 2), 1)
  end
  gfx.setColor(WHITE); gfx.fillRoundRect(70, 7, 302, 18, 9)                    -- the address field, sunk in a little
  gfx.setColor(BLACK); gfx.drawRoundRect(70, 7, 302, 18, 9)
  gfx.drawLine(76, 8, 364, 8)
  UI.ink("inkgreen")                                                           -- the padlock
  gfx.setColor(BLACK); gfx.drawRoundRect(78, 10, 7, 7, 3); gfx.fillRoundRect(76, 13, 11, 8, 2)
  gfx.setColor(WHITE); gfx.fillRect(81, 15, 1, 3)
  gfx.setFont(fontNormal)
  local x = 92
  UI.ink("gray"); drawT("https://", x, 8); x = x + gfx.getTextSize("https://")
  UI.ink("gingham"); drawT("coffeesupply.com/", x, 8); x = x + gfx.getTextSize("coffeesupply.com/")
  drawT(CAFE.TABPATH[CAFE.tab], x, 8, true)
  UI.ink("yellow")                                                             -- the bookmark star
  CAFE.star(381, 16, 5, 1, BLACK)
  UI.ink(CAFE.TABINK[CAFE.tab])
  if CAFE.urlTab ~= CAFE.tab then CAFE.urlTab, CAFE.urlF = CAFE.tab, frames end
  local k = (frames - (CAFE.urlF or -99)) / 10                                  -- the page loading: a line runs along the field
  if k < 1 then gfx.setColor(BLACK); gfx.fillRect(74, 22, math.floor(294 * k), 2) end
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- the shop's two buttons (Back to cafe, Save & quit): raised keys with a little picture each; the chosen one is pressed in
function UI.shopButton(x, w, label, kind, on)
  gfx.setColor(BLACK); gfx.fillRoundRect(x, 216, w, 17, 8)                      -- its edge / shadow
  gfx.setColor(on and BLACK or WHITE); gfx.fillRoundRect(x, 214, w, 17, 8)      -- its face
  gfx.setColor(BLACK); gfx.drawRoundRect(x, 214, w, 17, 8)
  if on and UI.color then gfx.setColor(WHITE); gfx.drawRoundRect(x + 2, 216, w - 4, 13, 6) end -- (PC: the chosen one gets a fine inner ring; on the Playdate it would cut through the words, so it's just filled)
  if on then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) else UI.inkPush("chrome") end      -- (PC: black words unless chosen)
  drawTC(label, x + math.floor(w / (2)) + 1, 215)
  if not on then UI.inkPop() end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

-- put a wall/floor piece on the grid (picking the spot if there's a choice)
function CAFE.putOut(id)
  local d, it = CAFE.cur, CAFE.byId[id]
  -- (all three rugs can be out together: the oval one under the tables lies over the pickup rug)
  if it.kind == "shelf" then                          -- vines: choose the left or the right end of the cup shelf
    local free = CAFE.vineSidesFree(d, id)
    d.decor[id] = "off"
    if #free == 0 then
      CAFE.say("Shelf ends are full: turn a vine off first.")
    else
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
    end
    CAFE.write()
    return
  end
  if CAFE.isGrid(it) then
    local free = CAFE.freeSlots(d, it.kind, id)
    if #free == 0 then
      d.decor[id] = "off"
      local wide = false                           -- (a counter spot is free, but this one is too wide for it)
      if it.kind == "counter" then for i = 1, #CAFE.CSLOT do if not CAFE.slotTaken(d, "counter", i) then wide = true end end end
      CAFE.say((it.kind == "wall" or it.kind == "tiny") and "Wall's full: turn something off first." or (it.kind == "counter" and (wide and "No wide spot left: turn something off first." or "Counter and tables are full: turn something off first.") or "Floor's full: turn something off first."))
    else                                           -- even one free spot goes to the placing screen so you see where it lands
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      d.decor[id] = "off"
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
      return
    end
  elseif it.species then                           -- one cat and one dog at a time (the new one takes over)
    for _, o in ipairs(CAFE.ITEMS) do
      if o.species == it.species and d.decor[o.id] == "on" then d.decor[o.id] = "off" end
    end
    d.decor[id] = "on"
  elseif it.kind == "hat" or it.kind == "glasses" or it.kind == "rug" or it.kind == "runner" or it.kind == "orug" or it.kind == "cloth" or it.kind == "frame" or it.kind == "curtain" or it.kind == "ceiling" or it.kind == "music" or it.kind == "wallpaper" or it.kind == "flooring" or it.kind == "seating" then        -- one of each kind at a time
    for _, o in ipairs(CAFE.ITEMS) do
      if o.kind == it.kind and d.decor[o.id] == "on" then
        d.decor[o.id] = "off"
        if it.kind == "music" then CAFE.say(o.name .. " is off: one season at a time.") end        -- (each season has its own weather)
      end
    end
    d.decor[id] = "on"
  else
    d.decor[id] = "on"
  end
  CAFE.write()
end

-- The season's drink takes the matcha slot, so the music can't change while an order is being made: from the moment its receipt is printed
-- (the order is taken) until the bell at pick up. (People who have not ordered yet just ask for what is on the menu when the shift goes on.)
function CAFE.musicLocked(row)
  local it = CAFE.byId[row[5] or ""]
  if not (it and it.kind == "music") then return false end
  local g = CAFE.keep
  return g ~= nil and g.cust ~= nil and (g.cust.stage or 0) >= 2
end

function CAFE.buy(row)
  local d = CAFE.cur
  if CAFE.musicLocked(row) then sfxWrong(); CAFE.say("Finish the order in progress first: music can't change until it is served."); return end
  if row[3] == "more" then                         -- another copy of something you own
    local cid = (d.money >= row[4]) and CAFE.nextCopy(d, row[5]) or nil
    row = { row[1], row[2], "buy", row[4], cid or row[5], row[6] }
  end
  if d.money < row[4] then
    sfxWrong()
    CAFE.say("Not enough money yet.")
    return
  end
  if row[3] == "seat" and d.seatStep < 4 then       -- a table: choose where it goes, pay when it's down
    if trans ~= nil then return end                  -- (the screen is still changing: wait, so each table gets its own turn)
    local used, free = {}, {}
    for k = 1, 4 do if d.tables[k] then used[d.tables[k]] = true end end
    for _, i in ipairs(CAFE.tableSpots(d.seatStep + 1)) do if not used[i] then free[#free + 1] = i end end
    if #free == 0 then sfxWrong(); CAFE.say("No room for another table."); return end
    CAFE.pend, CAFE.spots, CAFE.spotSel, CAFE.pendCost = "table", free, 1, row[4]
    transitionTo(function()
      G = CAFE.stageG()
      CAFE.mode = "place"
    end)
    return
  end
  d.money = d.money - row[4]
  local it = CAFE.byId[row[5] or ""]
  if UI.lvl(d) <= 1 then d.stars = clamp(d.stars + (it and ((it.kind == "hat" or it.kind == "glasses") and 0 or (it.kind == "pet" and 0.2 or 0.08)) or 0.2), 0, 5) end    -- upgrades earn stars (until the first prestige: then only reviews do)
  UI.statAdd("spent", row[4])
  if CAFE.sale and CAFE.sale.flash and row[7] then UI.statAdd("flash", 1) end
  sfxPlay("tip", false, 1.0)
  if row[3] == "cup" then d.cups = d.cups + 1; CAFE.say("Bought!")
  elseif row[3] == "seat" then d.seatStep = d.seatStep + 1; CAFE.say("Bought!")
  else
    d.decor[row[5]] = "off"
    CAFE.say("Bought!")
    CAFE.putOut(row[5])
    return
  end
  CAFE.write()
end

-- ---- Scratch-off tickets (the first things on the Stuff tab) -------------------------------------------------
-- Buy one and it opens: nine silver spots to scratch off (Playdate: crank; PC: hold Space, or rub with the mouse).
-- Three of the same picture in a row (across, down or corner to corner) wins that picture's prize. The result is
-- decided when you buy it (like a real ticket); a ticket you leave half done waits on the Stuff tab.
CAFE.SCR = {
  { name = "Bean Scratch", cost = 1000, card = "scr1", desc = "3 in a row wins up to $250",
    syms = { { "bean", 1000, 25 }, { "mug", 2000, 12 }, { "croissant", 5000, 4 }, { "star", 25000, 0.6 } } },
  { name = "Latte Lotto", cost = 2500, card = "scr2", desc = "3 in a row wins up to $750",
    syms = { { "mug", 2500, 22 }, { "donut", 5000, 12 }, { "cake", 15000, 3 }, { "star", 75000, 0.6 } } },
  { name = "Golden Bean", cost = 5000, card = "scr3", desc = "3 in a row wins up to $2500!",
    syms = { { "croissant", 5000, 22 }, { "cake", 10000, 12 }, { "gmug", 50000, 2.5 }, { "gbean", 250000, 0.2 } } },
}
CAFE.SCR_LINES = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 }, { 1, 4, 7 }, { 2, 5, 8 }, { 3, 6, 9 }, { 1, 5, 9 }, { 3, 5, 7 } }
-- the pictures: o = outline, w = white, a = main colour, d = its darker shade, b / c / r = second colours
-- (pc = which palette row and which half each letter uses on the PC; pd = black, white or grey on the Playdate)
UI.SCRSYM = {
  bean = { px = { "....ooooo....", "..ooaaaaaoo..", ".oaaaaaaadao.", ".oaaaaaaddao.", "oaaaaaaddaaao", "oawaaaddaaaao", "oawaaddaaaaao",
                  "oaaaddaaaaaao", "oaaddaaaaaaao", ".oaddaaaaaao.", ".oadaaaaaaao.", "..ooaaaaaoo..", "....ooooo...." },
           pc = { a = { "sym_bean", 1 }, d = { "sym_bean", 0 } }, pd = { a = "g" } },
  mug = { px = { "...d...d.....", "....d...d....", "...d...d.....", "ooooooooo....", "occcccccoooo.", "oaaaaaaao..o.", "oawaaaaao..o.",
                 "oawaaaaaoooo.", "oaaaaaaao....", ".oaaaaao.....", "..ooooo......", "ooooooooooo..", ".ooooooooo..." },
          pc = { a = { "sym_mug", 1 }, c = { "sym_coffee", 1 }, d = { "sym_steam", 0 } }, pd = { c = "g" } },
  croissant = { px = { ".............", ".............", "....ooooo....", "..ooawaaaoo..", ".oaadaaadaao.", "oaaadaaadaaao", "oaaadaaadaaao",
                       "oaadaaaaadaao", ".oo.ooooo.oo.", ".............", ".............", ".............", "............." },
                pc = { a = { "sym_croi", 1 }, d = { "sym_croi", 0 } }, pd = {} },
  donut = { px = { "....ooooo....", "..oobbbbboo..", ".obbcbbbbcbo.", ".obbbbccbbbo.", "obcbbooobbcbo", "obbbo...obbbo", "obbbo...obcbo",
                   "obcbbooobbbbo", "oabbbbbbbcbao", ".oabbcbbbbao.", ".oaaaabbaaao.", "..ooaaaaaoo..", "....ooooo...." },
            pc = { a = { "sym_dough", 1 }, b = { "sym_donut", 1 }, c = { "sym_sprk", 0 } }, pd = { a = "g" } },
  cake = { px = { ".....orro....", ".....orro....", "...ooooooooo.", "..owwwwwwwwo.", ".owwwwwwwwwo.", "oaaaaaaaaaao.", "occcccccccco.",
                  "oaaaaaaaaaao.", "occcccccccco.", "oaaaaaaaaaao.", "oooooooooooo.", ".............", "............." },
           pc = { a = { "sym_dough", 1 }, c = { "sym_jam", 0 }, r = { "sym_jam", 1 } }, pd = { c = "g", r = "k" } },
  star = { px = { "......o......", ".....oao.....", ".....oao.....", "....oaaao....", "ooooaaaaaoooo", "oaaaaawaaaaao", ".oaaaaaaaaao.",
                  "..oaaaaaaao..", "...oaaaaao...", "..oaaaoaaao..", "..oaao.oaao..", ".oao.....oao.", ".oo.......oo." },
           pc = { a = { "sym_star", 1 } }, pd = {} },
  gmug = { px = { "...s...s.....", "....s...s....", "...s...s.....", "ooooooooo....", "odddddddoooo.", "oaaaaaaao..o.", "oawaaaaao..o.",
                  "oawaaaaaoooo.", "oaaaaaaao....", ".oaaaaao.....", "..ooooo......", "ooooooooooo..", ".ooooooooo..." },
           pc = { a = { "sym_gold", 1 }, d = { "sym_gold", 0 }, w = { "sym_spark", 1 }, s = { "sym_gold", 0 } }, pd = { d = "g", s = "k" } },
  gbean = { px = { "....ooooo....", "..ooaaaaaoo..", ".oaaaaaaadao.", ".oaaaaaaddao.", "oaaaaaaddaaao", "oawaaaddaaaao", "oawaaddaaaaao",
                   "oaaaddaaaaaao", "oaaddaaaaaaao", ".oaddaaaaaao.", ".oadaaaaaaao.", "..ooaaaaaoo..", "....ooooo...." },
            pc = { a = { "sym_gold", 1 }, d = { "sym_gold", 0 } }, pd = { d = "g" } },
}
UI.SCR_COIN = { "..ooooo..", ".oaaaaao.", "oaawwwaao", "oawaaaaao", "oaawwaaao", "oaaaawaao", "oawwwaaao", ".oaaaaao.", "..ooooo.." }
UI.scrImg = {}
function UI.scrSymImg(key, k)                     -- a picture made once (k = pixel size), then just stamped
  local id = key .. k
  local im = UI.scrImg[id]
  if im then return im end
  local S = UI.SCRSYM[key]
  im = gfx.image.new(13 * k, 13 * k, gfx.kColorClear)
  gfx.pushContext(im)
  for r, line in ipairs(S.px) do
    for c = 1, #line do
      local ch = string.sub(line, c, c)
      if ch ~= "." then
        if UI.color then
          local m = S.pc[ch] or ((ch == "w") and { "none", 1 }) or { "none", (ch == "a" or ch == "b") and 1 or 0 }
          UI.ink(m[1]); gfx.setColor(m[2] == 1 and WHITE or BLACK)
        else
          local m = S.pd[ch] or (((ch == "a" or ch == "b" or ch == "w")) and "w" or "k")
          if m == "g" then gfx.setColor(((r + c) % 2 == 0) and BLACK or WHITE) else gfx.setColor(m == "w" and WHITE or BLACK) end
        end
        gfx.fillRect((c - 1) * k, (r - 1) * k, k, k)
      end
    end
  end
  UI.ink("none")
  gfx.popContext()
  UI.scrImg[id] = im
  return im
end

function CAFE.scratchMake(tier)                   -- decide the ticket now: maybe a win, and nine pictures to match
  local T = CAFE.SCR[tier]
  local roll, acc, win = math.random() * 100, 0, nil
  for i = #T.syms, 1, -1 do                        -- (the rarest first)
    acc = acc + T.syms[i][3]
    if roll < acc then win = i; break end
  end
  local line = win and math.random(1, 8) or nil
  local grid
  for _ = 1, 400 do
    grid = {}
    if line then for _, c in ipairs(CAFE.SCR_LINES[line]) do grid[c] = win end end
    for c = 1, 9 do if not grid[c] then grid[c] = math.random(1, #T.syms) end end
    local full = 0
    for _, L in ipairs(CAFE.SCR_LINES) do if grid[L[1]] == grid[L[2]] and grid[L[2]] == grid[L[3]] then full = full + 1 end end
    if full == (line and 1 or 0) then break end
  end
  local g = ""
  for c = 1, 9 do g = g .. grid[c] end
  return { tier = tier, grid = g, line = line, done = "000000000" }
end

CAFE.FREEK = { "freeBean", "freeLatte", "freeGold" }           -- (how many free tickets of each kind are waiting, in the save)
function CAFE.scratchRows(rows)                   -- the tickets, first on the Stuff tab
  local d = CAFE.cur
  if d.scratch and CAFE.SCR[d.scratch.tier] then
    rows[#rows + 1] = { "Finish your " .. CAFE.SCR[d.scratch.tier].name, "GO!", "scratchgo", 0, nil, "Your ticket is waiting!", tier = d.scratch.tier }
  end
  for tier = 3, 1, -1 do                                         -- (free ones: rank-up rewards and daily gifts)
    local n = tonumber(d[CAFE.FREEK[tier]]) or 0
    if n > 0 then
      rows[#rows + 1] = { "Free " .. CAFE.SCR[tier].name .. ((n > 1) and ("  x" .. n) or ""), "FREE", "scratchfree", 0, nil, (tier == 3) and "A free reward ticket!" or "From your daily gift!", tier = tier }
    end
  end
  for i, T in ipairs(CAFE.SCR) do
    rows[#rows + 1] = { T.name, money(T.cost), "scratch", T.cost, nil, T.desc, tier = i }
  end
end

function CAFE.scratchBuy(row)
  local d = CAFE.cur
  if row[3] == "scratchfree" then
    if d.scratch then sfxWrong(); CAFE.say("Finish the ticket you have first!"); return end
    local fk = CAFE.FREEK[row.tier or 3]
    if (tonumber(d[fk]) or 0) <= 0 then return end
    d[fk] = tonumber(d[fk]) - 1
    d.scratch = CAFE.scratchMake(row.tier or 3)
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  if row[3] == "scratch" then
    if d.scratch then sfxWrong(); CAFE.say("Finish the ticket you have first!"); return end
    if d.money < row[4] then sfxWrong(); CAFE.say("Not enough money yet."); return end
    d.money = d.money - row[4]
    UI.statAdd("spent", row[4])
    d.scratch = CAFE.scratchMake(row.tier)
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  if not d.scratch then return end
  UI.fast(function() CAFE.scratchOpen() end)
end

function CAFE.scratchOpen()
  local d = CAFE.cur
  local t = d.scratch
  local s = { phase = "scratch", sel = 1, t = 0, acc = 0, coat = {}, left = {}, pop = {}, conf = {}, snd = 0 }
  for c = 1, 9 do
    local on = string.sub(t.done, c, c) ~= "1"
    local cells, order = {}, {}
    for k = 1, 36 do cells[k] = on; order[k] = k end
    for k = 36, 2, -1 do local j = math.random(1, k); order[k], order[j] = order[j], order[k] end   -- (it comes off in a random scatter of flakes)
    s.coat[c] = { cells = cells, order = order, n = on and 36 or 0 }
  end
  s.sel = CAFE.scratchNext(s, 0) or 1
  CAFE.scr = s
  CAFE.mode = "scratch"
end

function CAFE.scratchNext(s, from)                -- the next spot still covered (reading order, round from the top)
  for k = 1, 9 do
    local c = (from + k - 1) % 9 + 1
    if s.coat[c].n > 0 then return c end
  end
  return nil
end

function CAFE.scratchCell(c) return 34 + ((c - 1) % 3) * 42, 56 + math.floor((c - 1) / 3) * 42 end    -- a spot's top-left (each spot is 38 square)

function CAFE.scratchRub(c, n, mx, my)            -- take n flakes off spot c (or, with mx / my, the ones under the coin)
  local s, d = CAFE.scr, CAFE.cur
  local co = s.coat[c]
  if co.n <= 0 then return end
  local took = 0
  if mx then
    local x0, y0 = CAFE.scratchCell(c)
    for k = 1, 36 do
      if co.cells[k] then
        local fx, fy = x0 + 1 + ((k - 1) % 6) * 6 + 3, y0 + 1 + math.floor((k - 1) / 6) * 6 + 3
        if (fx - mx) ^ 2 + (fy - my) ^ 2 <= (UI.color and 169 or 64) then co.cells[k] = false; co.n = co.n - 1; took = took + 1 end   -- (PC: a big coin, so it comes off fast)
      end
    end
  else
    for _, k in ipairs(co.order) do
      if took >= n then break end
      if co.cells[k] then co.cells[k] = false; co.n = co.n - 1; took = took + 1 end
    end
  end
  if took > 0 then
    s.rubT = 0.12
    if frames - (s.snd or 0) >= 3 then s.snd = frames; play(UI.synthNoise, 1400 + math.random(0, 900), 0.035, 0.18) end
  end
  if co.n > 0 and co.n <= 8 then                     -- nearly clear: the rest flakes away by itself
    for k = 1, 36 do co.cells[k] = false end
    co.n = 0
  end
  if co.n == 0 then
    s.pop[c] = 0
    local t = d.scratch
    t.done = string.sub(t.done, 1, c - 1) .. "1" .. string.sub(t.done, c + 1)
    sfxPop()
    local nx = CAFE.scratchNext(s, c)
    if nx then if not mx then s.sel = nx end
    else CAFE.scratchFinish() end
  end
end

function CAFE.scratchFinish()                    -- every spot is off: pay out (or not), and the ticket is used up
  local s, d = CAFE.scr, CAFE.cur
  local t = d.scratch
  local T = CAFE.SCR[t.tier]
  s.phase, s.t = "result", 0
  s.tier, s.grid, s.line = t.tier, t.grid, t.line
  s.prize = t.line and T.syms[tonumber(string.sub(t.grid, CAFE.SCR_LINES[t.line][1], CAFE.SCR_LINES[t.line][1]))][2] or 0
  d.scratch = nil
  UI.statAdd("scratch", 1)
  if s.prize > 0 then
    d.money = d.money + s.prize
    UI.statAdd("scratchwon", s.prize)
    for i = 1, 40 do
      local a = -math.pi / 2 + (math.random() - 0.5) * 2.8
      local v = 100 + math.random() * 140
      s.conf[i] = { x = 274, y = 110, vx = math.cos(a) * v, vy = math.sin(a) * v, k = i % 5, w = (i % 3 == 0) and 3 or 2 }
    end
    sfxPlay("tip", false, 1.0)
    play(synthSine, 1047, 0.10, 0.30, 0.05); play(synthSine, 1319, 0.10, 0.30, 0.15); play(synthSine, 1568, 0.10, 0.30, 0.25); play(synthSine, 2093, 0.30, 0.30, 0.35)
  else
    play(synthSine, 523, 0.12, 0.25); play(synthSine, 392, 0.25, 0.25, 0.14)
  end
  CAFE.write()
end

function CAFE.scratchLeave()
  CAFE.write()
  local back = CAFE.scrBack or "shop"                             -- (a ticket from the daily gift goes back to the door)
  CAFE.scrBack = nil
  UI.fast(function() CAFE.mode = back; CAFE.scr = nil; CAFE.allC = nil end)
end

function CAFE.scratchUpdate(dt, L, R, U, D, A_, B_)
  local s = CAFE.scr
  if not s then CAFE.mode = "shop"; return end
  s.t = s.t + dt
  for c, p in pairs(s.pop) do s.pop[c] = p + dt end
  if s.rubT then s.rubT = s.rubT - dt; if s.rubT <= 0 then s.rubT = nil end end
  for _, q in ipairs(s.conf) do q.vy = q.vy + 260 * dt; q.vx = q.vx * (1 - dt * 1.5); q.x = q.x + q.vx * dt; q.y = q.y + q.vy * dt end
  if s.phase == "result" then
    local ch = math.abs(pd.getCrankChange())
    if ch == 0 then s.let = true end                                       -- (PC: Space has to be let go first, so holding it doesn't skip the result)
    if s.t > 0.8 and (A_ or B_ or (UI.color and s.let and ch > 0)) then sfxClick(); CAFE.scratchLeave() end
    return
  end
  if B_ then sfxClick(); CAFE.scratchLeave(); return end                  -- (the ticket waits on the Stuff tab)
  local c = s.sel
  local nc = c
  if L and (c - 1) % 3 > 0 then nc = c - 1 elseif R and (c - 1) % 3 < 2 then nc = c + 1
  elseif U and c > 3 then nc = c - 3 elseif D and c < 7 then nc = c + 3 end
  if nc ~= c then s.sel = nc; s.mouse = false; sfxClick() end
  if A_ then local nx = CAFE.scratchNext(s, s.sel); if nx and nx ~= s.sel then s.sel = nx; sfxClick() end end
  local ch = math.abs(pd.getCrankChange())
  if ch > 0 and s.coat[s.sel].n > 0 then
    s.acc = s.acc + ch
    local n = math.floor(s.acc / 9)                                        -- (about one full turn clears a spot)
    if n > 0 then s.acc = s.acc - n * 9; CAFE.scratchRub(s.sel, n) end
  end
end

function CAFE.scratchDraw()
  local s = CAFE.scr
  if not s then return end
  local d = CAFE.cur
  local t = d.scratch
  local tier = (s.phase == "result") and s.tier or (t and t.tier) or 1
  local grid = (s.phase == "result") and s.grid or (t and t.grid) or "111111111"
  local line = (s.phase == "result") and s.line or nil
  local T = CAFE.SCR[tier]
  -- the table it lies on
  UI.ink("scrbg")
  local function felt()
    gfx.setColor(BLACK); gfx.fillRect(0, 0, 400, 240)
    gfx.setColor(WHITE)
    for y = 0, 239, 8 do for x = ((y / 8) % 2) * 4, 399, 8 do gfx.drawPixel(x, y) end end
  end
  local felt0 = (not UI.color) and UI.cacheImg("felt", 0, 0, 400, 240, felt)       -- (PD: built once, then stamped)
  if felt0 then UI.cacheDraw(felt0, 0, 0) else felt() end
  -- the ticket: a shadow, a coloured card with a stitched edge, notches down the sides like a real one
  UI.ink(T.card)
  gfx.setColor(BLACK); gfx.fillRoundRect(19, 9, 368, 228, 10)
  gfx.setColor(WHITE); gfx.fillRoundRect(16, 6, 368, 226, 10)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(16, 6, 368, 226, 10); gfx.setLineWidth(1)
  UI.dotRow(26, 374, 4, 11); UI.dotRow(26, 374, 4, 226)
  UI.ink("scrbg")
  for y = 30, 210, 30 do gfx.setColor(BLACK); gfx.fillCircleAtPoint(16, y, 3); gfx.fillCircleAtPoint(384, y, 3) end
  UI.ink("none")
  -- the name, big and wiggly (PC: its colours ripple)
  UI.ink(T.card)
  UI.fancyText(T.name .. "!", 200, 15, 0.35, 300, nil, UI.FX_RAINBOW)
  UI.ink("none")
  -- the nine spots
  for c = 1, 9 do
    local x0, y0 = CAFE.scratchCell(c)
    local sym = T.syms[tonumber(string.sub(grid, c, c))][1]
    UI.ink("scrcell")
    gfx.setColor(WHITE); gfx.fillRoundRect(x0, y0, 38, 38, 4)
    gfx.setColor(BLACK); gfx.drawRoundRect(x0, y0, 38, 38, 4)
    local co = s.coat[c]
    if not co or co.n < 36 then                                          -- the picture underneath (it pops when the spot is clear)
      local p = s.pop[c]
      local big = p and p < 0.18
      local k = big and 3 or 2
      local im = UI.scrSymImg(sym, k)
      local sz = 13 * k
      im:draw(x0 + 19 - math.floor(sz / 2), y0 + 19 - math.floor(sz / 2))
    end
    if co and co.n > 0 then                                              -- the silver coating, flake by flake
      UI.ink("scrcoat")
      for k = 1, 36 do
        if co.cells[k] then
          local fx, fy = x0 + 1 + ((k - 1) % 6) * 6, y0 + 1 + math.floor((k - 1) / 6) * 6
          if UI.color then
            gfx.setColor(WHITE); gfx.fillRect(fx, fy, 6, 6)
            gfx.setColor(BLACK); if (k * 7) % 5 == 0 then gfx.drawPixel(fx + 2, fy + 3) end
          else
            gfx.setPattern(CHECK); gfx.fillRect(fx, fy, 6, 6); gfx.setColor(BLACK)
          end
        end
      end
      if co.n == 36 then                                                 -- an untouched spot shows a little bean
        UI.ink("scrcoatdk")
        gfx.setColor(UI.color and BLACK or WHITE)
        gfx.fillEllipseInRect(x0 + 14, y0 + 13, 10, 12)
        gfx.setColor(UI.color and WHITE or BLACK)
        gfx.drawLine(x0 + 19, y0 + 15, x0 + 18, y0 + 22)
      end
      UI.ink("none")
    end
  end
  gfx.setColor(BLACK)
  -- the chosen spot: a thick frame and the coin that does the scratching
  if s.phase == "scratch" then
    local x0, y0 = CAFE.scratchCell(s.sel)
    gfx.setLineWidth(3); gfx.drawRoundRect(x0 - 3, y0 - 3, 44, 44, 6); gfx.setLineWidth(1)
    if not s.mouse then
      local wob = s.rubT and ((math.floor(frames / 2) % 2 == 0) and 2 or -2) or 0
      UI.ink("sym_gold")
      UI.pic(UI.scrCoinRows(), x0 + 30 + wob, y0 + 28 - (s.rubT and 2 or 0))
      UI.ink("none")
    elseif UI.color and UI.pc and UI.pc.lx then                -- PC: a big coin under the mouse, as wide as the patch it rubs off
      local wob = s.rubT and ((math.floor(frames / 2) % 2 == 0) and 1 or -1) or 0
      UI.ink("sym_gold")
      UI.pic(UI.scrCoinRows(), UI.pc.lx - 13 + wob, UI.pc.ly - 13, 3)
      UI.ink("none")
    end
  end
  -- three in a row: a bright line through them
  if line and (math.floor(frames / 4) % 2 == 0 or s.t > 1.2) then
    local L = CAFE.SCR_LINES[line]
    local ax, ay = CAFE.scratchCell(L[1]); local bx, by = CAFE.scratchCell(L[3])
    UI.ink("inkred")
    gfx.setColor(BLACK); gfx.setLineWidth(5); gfx.drawLine(ax + 19, ay + 19, bx + 19, by + 19); gfx.setLineWidth(1)
    UI.ink("none")
  end
  -- the prizes
  UI.ink("scrcell")
  gfx.setColor(WHITE); gfx.fillRoundRect(178, 52, 192, 134, 6)
  gfx.setColor(BLACK); gfx.drawRoundRect(178, 52, 192, 134, 6)
  UI.ink("none")
  gfx.setFont(fontBold)
  drawTC("MATCH 3 IN A ROW!", 274, 55, true)
  for i = #T.syms, 1, -1 do
    local y = 74 + (#T.syms - i) * 27
    local im = UI.scrSymImg(T.syms[i][1], 1)
    for k = 0, 2 do im:draw(188 + k * 15, y + 2) end
    local hit = line and tonumber(string.sub(grid, CAFE.SCR_LINES[line][1], CAFE.SCR_LINES[line][1])) == i
    if hit then UI.ink("inkred") end
    drawTR("= " .. money(T.syms[i][2]), 360, y, true)
    UI.ink("none")
  end
  gfx.setColor(BLACK)
  -- what to do
  local hint
  if s.phase == "result" then hint = UI.color and "Press SPACE to go on" or "Press A to go on"
  else hint = UI.color and "Hold SPACE or rub with the mouse!  X: later" or "Crank to scratch!   B: later" end
  gfx.setFont(fontBold)
  local hw = gfx.getTextSize(hint) + 20
  gfx.setColor(BLACK); gfx.fillRoundRect(200 - math.floor(hw / 2), 198, hw, 19, 8)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite); drawTC(hint, 200, 199, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
  -- the result
  if s.phase == "result" and s.t > 0.35 then
    local pt = math.min(1, (s.t - 0.35) / 0.3)
    local pop = pt < 1 and (pt * (1 + 0.3 * math.sin(pt * math.pi))) or 1
    local bw, bh = math.floor(196 * pop), math.floor(92 * pop)
    if bw > 20 then                                                      -- (over the prize list, so the winning row stays in sight)
      local bx, by = 274 - math.floor(bw / 2), 119 - math.floor(bh / 2)
      UI.ink(s.prize > 0 and "scr3" or "scrcell")
      gfx.setColor(BLACK); gfx.fillRoundRect(bx + 3, by + 4, bw, bh, 10)
      gfx.setColor(WHITE); gfx.fillRoundRect(bx, by, bw, bh, 10)
      gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(bx, by, bw, bh, 10); gfx.setLineWidth(1)
      UI.ink("none")
      if pt >= 1 then
        if s.prize > 0 then
          UI.fancyText("WINNER!", 274, 86, 0.8, 176, nil, UI.FX_RAINBOW)
          UI.ink("fx_green")
          UI.fancyText("+" .. money(s.prize), 274, 116, 0.5, 176, true)
          UI.ink("none")
        else
          UI.fancyText("No luck!", 274, 90, 0.3, 176, true)
          gfx.setFont(fontNormal)
          drawTC("Better luck next time!", 274, 124)
        end
      end
    end
    for _, q in ipairs(s.conf) do
      if q.y < 240 then
        UI.ink(({ "redp", "yellow", "skyp", "leaf", "rose" })[q.k + 1])
        gfx.setColor(BLACK); gfx.fillRect(math.floor(q.x), math.floor(q.y), q.w, (q.w == 3) and 1 or 2)
      end
    end
    UI.ink("none")
  end
  gfx.setColor(BLACK)
end
function UI.scrCoinRows()                        -- the coin, as a text picture (a = its face, w = the $ on it)
  if not UI.scrCoinR then
    local out = {}
    for i, r in ipairs(UI.SCR_COIN) do out[i] = r:gsub("o", "k"):gsub("a", "W"):gsub("w", "k"):gsub("W", "w") end
    UI.scrCoinR = out
  end
  return UI.scrCoinR
end

function UI.scratchPreview(cx, cy, tier)          -- the shop card: a little ticket with three spots, one scratched
  local T = CAFE.SCR[tier]
  UI.ink(T.card)
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 35, cy - 19, 72, 42, 5)
  gfx.setColor(WHITE); gfx.fillRoundRect(cx - 37, cy - 22, 72, 42, 5)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(cx - 37, cy - 22, 72, 42, 5); gfx.setLineWidth(1)
  for x = cx - 32, cx + 29, 3 do gfx.drawPixel(x, cy - 18) end
  UI.ink("none")
  for k = 0, 2 do
    local x0, y0 = cx - 31 + k * 21, cy - 12
    UI.ink("scrcell"); gfx.setColor(WHITE); gfx.fillRect(x0, y0, 18, 18); gfx.setColor(BLACK); gfx.drawRect(x0, y0, 18, 18)
    if k == 0 then
      UI.ink("none")
      UI.scrSymImg(T.syms[#T.syms][1], 1):draw(x0 + 3, y0 + 3)
    else
      UI.ink("scrcoat")
      if UI.color then gfx.setColor(WHITE); gfx.fillRect(x0 + 1, y0 + 1, 16, 16) else gfx.setPattern(CHECK); gfx.fillRect(x0 + 1, y0 + 1, 16, 16) end
      gfx.setColor(BLACK)
    end
  end
  UI.ink("sym_gold")
  UI.pic(UI.scrCoinRows(), cx + 22, cy + 6)
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.toggle(row)
  local d = CAFE.cur
  if row[3] == "sign" and row.mug then                       -- the coffee picture up in the corner
    if d.mugSign == false then
      for _, it in ipairs(CAFE.ITEMS) do
        if CAFE.gk(it.kind) == "wall" and d.decor[it.id] == "on" and d.place[it.id] == CAFE.MUGSLOT then sfxWrong(); CAFE.say("Take down the wall decor in its spot first."); return end
      end
      d.mugSign = nil
    else
      d.mugSign = false
    end
    sfxClick()
    CAFE.write()
    return
  end
  if row[3] == "sign" then
    if d.sign == false then
      if CAFE.slotTaken(d, "wall", 2) or CAFE.slotTaken(d, "wall", 3) then
        -- (sign is off, so the slot test is just about the other decor)
      end
      local blocked = false
      for _, it in ipairs(CAFE.ITEMS) do
        if CAFE.gk(it.kind) == "wall" and d.decor[it.id] == "on" and (d.place[it.id] == 2 or d.place[it.id] == 3) then blocked = true end
      end
      if blocked then sfxWrong(); CAFE.say("Take down the wall decor in its spot first."); return end
      d.sign = true
    else
      d.sign = false
    end
    sfxClick()
    CAFE.write()
    return
  end
  local id = CAFE.toggleTarget(d, row[5])
  if CAFE.musicLocked(row) then sfxWrong(); CAFE.say("Finish the order in progress first: music can't change until it is served."); return end
  if d.decor[id] == "on" then
    d.decor[id] = "off"
    d.place[id] = nil
    if id == "itemstand" or CAFE.byId[id].copyOf == "itemstand" then CAFE.fixTops(d) end     -- (what stood on it moves to the counter)
    sfxClick()
    CAFE.write()
  else
    sfxClick()
    CAFE.putOut(id)
  end
end

-- a stand-in for the cafe with nobody in it (for choosing where things go)
function CAFE.stageG()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  return { mode = "cafe", cafe = d, t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
           px = -300, moving = false, walk = 0, sel = "down", st = nil, cust = nil,
           cupMax = d.cups, seatLimit = CAFE.seatsOf(d.seatStep), seatOff = CAFE.seatOffOf(d), seatCount = CAFE.seatCountOf(d),
           cups = { shelf = d.cups, dirty = 0, hand = 0 },
           sink = { state = "empty", progress = 0, angle = 0, t = 0 },
           win = CAFE.newWindowFor(d), line = {}, others = {}, seats = {}, door = 0, popups = {}, ending = true }
end

function CAFE.spotRect(kind, i)
  if kind == "shelf" then                       -- the two ends of the cup shelf
    return (i == 1) and 92 or 172, 42, 28, 36
  end
  if kind == "counter" then
    if i > 40 then                               -- a perch on the floor
      local sl = CAFE.FSLOT[i - 40]
      return sl[1] - 16, sl[2] - 18, 32, 36
    end
    if i > 20 then                               -- the top of an Item stand
      local sl = CAFE.FSLOT[i - 20]
      return sl[1] - 15, sl[2] - 27, 30, 34
    end
    if i > 10 then                               -- the middle of a table
      local t = TABLES[i - 10]
      return t.x - 15, t.y - 24, 30, 34
    end
    local sl, cap = CAFE.CSLOT[i], CAFE.SCAP[i]
    local hw = cap and math.min(14, math.max(-cap[1], cap[2]) + 1) or 14         -- (the narrow spots by the sink and the jar get a narrower box)
    return sl[1] - hw, 69, hw * 2, 24
  end
  if kind == "tiny" or kind == "wall" then
    local sl = CAFE.TILES[i]
    return sl[1], sl[2], sl[3], sl[4]
  end
  if kind == "table" then
    local sl = CAFE.TSLOT[i]
    return sl[1] - 27, sl[2] - 19, 54, 38
  end
  local sl = CAFE.FSLOT[i]
  return sl[1] - 16, sl[2] - 18, 32, 36
end

function CAFE.leavePlace(placed)
  if trans ~= nil then return end                  -- (one at a time: never twice while the screen is changing)
  local id = CAFE.pend
  if placed then
    local d = CAFE.cur
    if id == "table" then
      d.money = d.money - CAFE.pendCost
      if d.seatStep == 0 then d.cups = math.max(d.cups, 2) end        -- the starting kit comes with two cups
      d.seatStep = d.seatStep + 1
      d.tables[d.seatStep] = CAFE.spots[CAFE.spotSel]
      if UI.lvl(d) <= 1 then d.stars = clamp(d.stars + 0.2, 0, 5) end
      UI.statAdd("spent", CAFE.pendCost or 0)
    else
      d.place[id] = CAFE.spots[CAFE.spotSel]
      d.decor[id] = "on"
    end
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  transitionTo(function()
    G = nil
    CAFE.pend = nil
    CAFE.mode = "shop"
  end)
end

-- move a cursor between spots the way the screen looks: left goes to the spot on the left, up to the one above
function CAFE.spatial(pts, cur, dir)           -- pts = list of {x, y} centres; returns the new index (or the same one)
  local cx, cy = pts[cur][1], pts[cur][2]
  local best, bs
  for i, p in ipairs(pts) do
    if i ~= cur then
      local dx, dy = p[1] - cx, p[2] - cy
      local along, across
      if dir == "R" then along, across = dx, math.abs(dy)
      elseif dir == "L" then along, across = -dx, math.abs(dy)
      elseif dir == "D" then along, across = dy, math.abs(dx)
      else along, across = -dy, math.abs(dx) end
      if along > 2 then
        local sc = along + across * 2.5
        if bs == nil or sc < bs then best, bs = i, sc end
      end
    end
  end
  return best or cur
end

function CAFE.spotPts(kind, list)
  local pts = {}
  for i, sl in ipairs(list) do
    local x, y, w, h = CAFE.spotRect(kind, sl)
    pts[i] = { x + w / 2, y + h / 2 }
  end
  return pts
end

-- ---- the door: turn the sign from CLOSED to OPEN with the crank, then the cafe opens --------------------
CAFE.GREETS = { "Welcome back!", "Hope your day is good!", "Have a good day!", "Coffee heads welcome!",
                "Good to see you again!", "Rise and grind!", "Fresh beans, fresh start!", "Your cafe missed you!",
                "Another day, another cup!", "Let's brew something great!", "Smells like a good day!", "Glad you're here!" }

function CAFE.openDoor()
  CAFE.keep = nil
  CAFE.sale = CAFE.sale and { ids = {}, nextMs = 0 } or nil
  CAFE.rollSale()
  CAFE.door = { p = 0, done = 0, tick = 0 }
  crankHelpStart()
  CAFE.greet, CAFE.greetF, CAFE.report = CAFE.GREETS[math.random(#CAFE.GREETS)], nil, nil
  if CAFE.cur then UI.migrate(CAFE.cur) end
  CAFE.gift = UI.giftReady() and { phase = "box", t = 0, crank = 0 } or nil       -- (today's daily gift, if it hasn't been opened yet)
  transitionTo(function()
    G = { win = WIN.newWindow() }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.closeDoor()                      -- Save & quit: the door shows OPEN, flips to CLOSED, then the title
  transitionTo(function()
    if G and G.mode then closeStation() end
    CAFE.keep = nil
    setShiftMenu(false, false)
    G = { win = WIN.newWindow() }
    CAFE.door = { p = 1, done = 0, tick = 0, closing = true, hold = 0 }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.signFace(open)                   -- the hanging sign, drawn once for each side
  CAFE.signImgs = CAFE.signImgs or {}
  local k = open and "open" or "closed"
  if not CAFE.signImgs[k] then
    local W, H = 164, 56
    local word = open and "OPEN" or "CLOSED"
    local t = gfx.image.new(60, 20, gfx.kColorClear)       -- the word, drawn small then blown up 2x
    gfx.pushContext(t)
    gfx.setColor(BLACK)
    gfx.setFont(fontBold)
    gfx.drawTextAligned(word, 30, 1, kTextAlignment.center)
    gfx.popContext()
    local im = gfx.image.new(W, H, gfx.kColorClear)
    gfx.pushContext(im)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(0, 0, W, H, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(3)
    gfx.drawRoundRect(1, 1, W - 2, H - 2, 9)
    gfx.setLineWidth(1)
    gfx.drawRoundRect(6, 6, W - 12, H - 12, 5)
    local tw = (word == "OPEN") and 2.4 or 2
    local x0, y0 = math.floor(W / 2 - 30 * tw), math.floor(H / 2 - 10 * tw)
    t:drawScaled(x0, y0, tw, tw)
    t:drawScaled(x0 + 1, y0, tw, tw)                       -- drawn twice, a pixel apart: chunkier letters
    gfx.popContext()
    CAFE.signImgs[k] = im
  end
  return CAFE.signImgs[k]
end

function CAFE.doorUpdate(dt, B_)
  local dr = CAFE.door
  WIN.updateWindow(dt)
  if dr.closing then                                    -- it turns itself over, then back to the title
    if dr.done > 0 then
      dr.done = dr.done - dt
      if dr.done <= 0 then
        dr.done = -1
        transitionTo(function() G = nil; state = STATE_MENU end)
      end
    elseif dr.done == 0 then
      dr.hold = dr.hold + dt
      if dr.hold > 0.7 then
        dr.p = math.max(0, dr.p - dt * 0.7)
        if dr.p <= 0 then dr.done = 1.0 end                  -- (no sounds on this screen)
      end
    end
    return
  end
  if dr.done > 0 then
    dr.done = dr.done - dt
    if dr.done <= 0 then dr.done = -1; CAFE.begin() end
    return
  elseif dr.done < 0 then return end
  if B_ then
    sfxClick()
    transitionTo(function() G = nil; CAFE.mode = "slots"; UI.bgSet("slots") end)
    return
  end
  local before = dr.p
  dr.p = dr.p + pd.getCrankChange() / 200                -- about half a turn flips the sign
  if pd.buttonJustPressed(pd.kButtonA) then dr.auto = true end           -- a press of A turns the sign all the way over by itself
  if dr.auto or pd.buttonIsPressed(pd.kButtonRight) or pd.buttonIsPressed(pd.kButtonA) then dr.p = dr.p + dt * 0.9 end
  if pd.buttonIsPressed(pd.kButtonLeft) then dr.p = dr.p - dt * 0.6 end
  dr.p = clamp(dr.p, 0, 1)
  if dr.p > 0.02 and not dr.snd then dr.snd = true; if sfx.storedoor then sfxPlay("storedoor", false, 1.0) else sfxClick() end end   -- the door sliding open (once)
  if dr.p >= 1 then
    sfxPlay("bell", false, 1.0)
    dr.done = 1.0
  end
end

function CAFE.doorArt()                          -- the storefront pictures, loaded once (false if any are missing: the old plain door is drawn)
  local art = CAFE.doorImgs
  if art == nil then
    art = {}
    for k, f in pairs({ bg = "door_bg", win = "door_win", open = "door_open", closed = "door_closed" }) do
      local ok, im = pcall(function() return gfx.image.new("images/" .. f) end)
      if ok and im then art[k] = im else art = false; break end
    end
    CAFE.doorImgs = art
  end
  return art
end

function CAFE.doorDrawArt(art)
  local dr = CAFE.door
  art.bg:draw(0, 0)                                      -- brick walls, lantern, plants, the door, the board for the name, the mat
  WIN.drawView(G.win, 122, 48, 3, true)                  -- the live view through the glass (sky and weather, nobody walking by)
  art.win:draw(118, 42)                                  -- window bars and the little cafe curtain
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)           -- the cafe's name, in white on the board
  do
    local nm = CAFE.cafeName()
    gfx.setFont(fontBold)
    if gfx.getTextSize(nm) <= 176 then
      drawTC(nm, 200, 11, true)
    else                                                  -- a very wide name: chunky capitals, so all of it shows
      local up = string.upper(nm)
      gfx.setColor(WHITE)
      UI.pixText(up, 200 - math.floor(UI.pixWidth(up) / (2)), 15)
      gfx.setColor(BLACK)
    end
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  local fl = (math.floor(frames / (3))) % 3                           -- the lantern flame flickers
  UI.ink("flame")
  gfx.fillPolygon(43, 88, 49, 88, 46, 76 - (fl == 1 and 1 or 0))
  gfx.fillCircleAtPoint(46, 88, 3)
  UI.ink("none")
  local hr = dr.closing and 2 or 7                       -- the clock: seven when you open, two when you close
  local ha = math.rad(hr * 30)
  gfx.setLineWidth(2)
  gfx.drawLine(352, 82, math.floor(352 + math.sin(ha) * 8 + 0.5), math.floor(82 - math.cos(ha) * 8 + 0.5))
  gfx.drawLine(352, 82, 352, 70)
  gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(352, 82, 2)
  -- the sign hangs from a hook and flips over
  UI.ink("brass")
  gfx.fillCircleAtPoint(200, 134, 3)
  local ease = dr.p * dr.p * (3 - 2 * dr.p)
  local ang = ease * math.pi
  local sx = math.abs(math.cos(ang))
  if sx < 0.05 then
    gfx.fillRect(199, 134, 3, 63)
  else
    gfx.drawLine(200, 134, math.floor(200 - 70 * sx), 141)
    gfx.drawLine(200, 134, math.floor(200 + 70 * sx), 141)
    local im = (ang >= math.pi / 2) and art.open or art.closed
    im:drawScaled(math.floor(200 - 82 * sx), 141, sx, 1)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  if not dr.closing and dr.p < 0.5 and dr.done == 0 and not CAFE.gift then       -- the reminder: spin the crank (or press A)
    local label = UI.color and "Hold SPACE!" or "Press A or crank!"
    gfx.setFont(fontBold)
    local bw = gfx.getTextSize(label) + (UI.color and 28 or 58)          -- (PC: just the words, no crank picture)
    local bx, by = 200 - math.floor(bw / (2)), 200
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, 36, 10)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(bx, by, bw, 36, 10)
    gfx.setLineWidth(1)
    if UI.color then
      drawTC(label, 200, by + 9, true)
    else
      local ix, iy = bx + 22, by + 18                              -- a little crank, turning round
      local a = frames * 0.18
      gfx.drawCircleAtPoint(ix, iy, 7)
      gfx.setLineWidth(3)
      gfx.drawLine(ix, iy, math.floor(ix + math.cos(a) * 11), math.floor(iy + math.sin(a) * 11))
      gfx.setLineWidth(1)
      gfx.fillCircleAtPoint(math.floor(ix + math.cos(a) * 12), math.floor(iy + math.sin(a) * 12), 3)
      gfx.fillCircleAtPoint(ix, iy, 2)
      drawT(label, bx + 40, by + 9, true)
    end
    crankHelpDraw()                                              -- (and the system's own crank picture, if the crank is tucked in)
  end
end

function CAFE.doorDraw()
  local dr = CAFE.door
  local art = CAFE.doorArt()
  if art then CAFE.doorDrawArt(art); return end
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 0, 400, 240)                          -- the wall either side
  gfx.setColor(BLACK)
  gfx.fillRect(92, 0, 216, 240)                         -- the door frame
  gfx.setColor(WHITE)
  gfx.fillRect(98, 0, 204, 240)                         -- the door
  gfx.setColor(BLACK)
  gfx.fillRect(98, 0, 204, 6)
  -- the window in the door: the same view as the one in the cafe, bigger
  gfx.fillRect(118, 14, 164, 82)
  gfx.setColor(WHITE)
  gfx.fillRect(122, 20, 156, 72)
  WIN.drawView(G.win, 122, 20, 3, true)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawLine(200, 20, 200, 92)
  gfx.drawLine(122, 56, 278, 56)
  gfx.setLineWidth(1)
  -- door panels, and the handle
  gfx.setLineWidth(2)
  gfx.drawRoundRect(114, 172, 76, 58, 4)
  gfx.drawRoundRect(210, 172, 76, 58, 4)
  gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(286, 150, 6)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(286, 150, 2)
  -- the sign hangs on the glass and flips over
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(200, 100, 3)
  gfx.drawLine(200, 100, 200, 108)
  local ease = dr.p * dr.p * (3 - 2 * dr.p)
  local ang = ease * math.pi
  local sx = math.abs(math.cos(ang))
  if sx < 0.05 then
    gfx.fillRect(199, 108, 3, 56)
  else
    local im = CAFE.signFace(ang >= math.pi / 2)
    im:drawScaled(math.floor(200 - 82 * sx), 108, sx, 1)
  end
  gfx.setColor(BLACK)
  if not dr.closing and dr.p < 0.5 and dr.done == 0 and not CAFE.gift then       -- the reminder: spin the crank
    local label = UI.color and "Hold SPACE!" or "Press A or crank!"
    gfx.setFont(fontBold)
    local bw = gfx.getTextSize(label) + 58
    local bx, by = 200 - math.floor(bw / (2)), 188
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, 36, 10)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(bx, by, bw, 36, 10)
    gfx.setLineWidth(1)
    if UI.color then
      drawTC(label, 200, by + 9, true)
    else
      local ix, iy = bx + 22, by + 18                              -- a little crank, turning round
      local a = frames * 0.18
      gfx.drawCircleAtPoint(ix, iy, 7)
      gfx.setLineWidth(3)
      gfx.drawLine(ix, iy, math.floor(ix + math.cos(a) * 11), math.floor(iy + math.sin(a) * 11))
      gfx.setLineWidth(1)
      gfx.fillCircleAtPoint(math.floor(ix + math.cos(a) * 12), math.floor(iy + math.sin(a) * 12), 3)
      gfx.fillCircleAtPoint(ix, iy, 2)
      drawT(label, bx + 40, by + 9, true)
    end
    crankHelpDraw()                                              -- (and the system's own crank picture, if the crank is tucked in)
  end
end

-- ---- the table layout editor: pick a table up, then put it down on any empty square ------------------
function CAFE.tableAtSlot(d, i)                -- which of your tables stands on square i (or nil)
  for k = 1, math.min(d.seatStep, 4) do
    if d.tables[k] == i and not d.off[k] then return k end
  end
  return nil
end

function CAFE.layoutSpots(d)                    -- the squares shown while you move tables around
  local all = {}
  for i, f in ipairs(CAFE.TFREE) do all[i] = f end
  return all
end

function CAFE.tablesInHand(d)
  local n = 0
  for k = 1, math.min(d.seatStep, 4) do if d.off[k] then n = n + 1 end end
  return n
end

function CAFE.openLayout()
  local d = CAFE.cur
  for k = 1, math.min(d.seatStep, 4) do          -- (a table that was switched off is simply one in your hand)
    if d.off[k] then d.tables[k] = 0 end
  end
  CAFE.lay, CAFE.grab = d.tables[1] and d.tables[1] > 0 and d.tables[1] or 1, false
  transitionTo(function()
    G = CAFE.stageG()
    CAFE.mode = "layout"
  end)
end

function CAFE.layoutRefresh()                  -- the floor picture is drawn once, so redo it after a change
  local d = CAFE.cur
  CAFE.applyLayout(d)
  CAFE.fixTops(d)
  G.scn, G.tops, G.liveL, G.liveC = nil, nil, nil, nil
  G.seatOff, G.seatCount = CAFE.seatOffOf(d), CAFE.seatCountOf(d)
end

function CAFE.layoutUpdate(L, R, U, D, A_, B_)
  local d = CAFE.cur
  local n = math.min(d.seatStep, 4)
  if n < 1 then B_ = true end
  local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
  if dir then
    local all = CAFE.layoutSpots(d)
    local cur = 1
    for i, v in ipairs(all) do if v == CAFE.lay then cur = i end end
    local nat = CAFE.spatial(CAFE.spotPts("table", all), cur, dir)
    if all[nat] ~= CAFE.lay then CAFE.lay = all[nat]; sfxClick() end
  elseif A_ then
    local k = CAFE.tableAtSlot(d, CAFE.lay)
    if k then                                   -- a table: it goes into your hand
      d.tables[k] = 0; d.off[k] = true
      CAFE.layoutRefresh(); sfxClick()
    else                                        -- an empty square: put a table from your hand down
      local hk
      for j = 1, n do if d.off[j] then hk = j; break end end
      if hk then
        d.tables[hk] = CAFE.lay; d.off[hk] = nil
        CAFE.layoutRefresh(); sfxPlay("tip", false, 1.0)
      else
        sfxWrong(); CAFE.say("No tables in your hand. Pick one up first.")
      end
    end
  elseif B_ then
    CAFE.write()
    transitionTo(function()
      G = nil
      CAFE.mode = "shop"
      CAFE.rc = nil
    end)
  end
end

function CAFE.layoutDraw()
  local d = CAFE.cur
  CAFE.sceneTop()
  CAFE.sceneBottom()
  UI.drawDoor()
  for _, i in ipairs(CAFE.layoutSpots(d)) do
    local x, y, w, h = CAFE.spotRect("table", i)
    local sel = (i == CAFE.lay)
    if not CAFE.tableAtSlot(d, i) then            -- a clear box round every empty square
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, h, 5)
      gfx.setColor(BLACK)
      gfx.setLineWidth(sel and 3 or 2)
      gfx.drawRoundRect(x, y, w, h, 5)
      gfx.setLineWidth(1)
      if CAFE.tablesInHand(d) > 0 then drawTC("+", x + math.floor(w / (2)), y + math.floor(h / (2)) - 8, true) end
    elseif sel then
      gfx.setColor(BLACK)
      gfx.setLineWidth(3)
      gfx.drawRoundRect(x - 2, y - 2, w + 4, h + 4, 6)
      gfx.setLineWidth(1)
    end
  end
  local x, y, w, h = CAFE.spotRect("table", CAFE.lay)
  CAFE.pointer(x + math.floor(w / (2)) + 4, y + math.floor(h / (2)) - 2)         -- the mouse arrow rests on the chosen square
  gfx.setColor(WHITE)
  local label = "Tables in hand: " .. CAFE.tablesInHand(d)
  gfx.setFont(fontBold)
  local bw = gfx.getTextSize(label) + 28                       -- the bubble hugs the words
  gfx.fillRoundRect(200 - math.floor(bw / (2)), 100, bw, 24, 6)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(200 - math.floor(bw / (2)), 100, bw, 24, 6)
  drawTC(label, 200, 104, true)
  if CAFE.msg then
    local ml = CAFE.fitLines(CAFE.msg, 324, true, 3)
    local mh = 6 + 16 * #ml
    gfx.setColor(WHITE)
    gfx.fillRoundRect(30, 130, 340, mh, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(30, 130, 340, mh, 6)
    for li = 1, #ml do drawTC(ml[li], 200, 133 + (li - 1) * 16, true) end
  end
end

-- ---- owning more than one: floor and table-top decor can be bought again (as many as you like) ----------------------
-- A second copy is its own item called "<id>#2" (and so on): it has its own spot and its own on / off, and draws like the first.
function CAFE.copyCount(d, id)                 -- how many copies of this piece you own (they are numbered one after the other, so no limit)
  local n = 0
  while d.decor[CAFE.copyId(id, n + 1)] ~= nil do n = n + 1 end
  return n
end
function CAFE.copyId(id, k) return (k == 1) and id or (id .. "#" .. k) end
function CAFE.multiOK(it)                       -- floor and table-top pieces only (no pets or pet things, music, clothes, cloths, rugs, window or wall decor)
  return it ~= nil and not it.copyOf and (it.kind == "floor" or it.kind == "counter") and not it.needs and not it.pettab and not it.species
end
function CAFE.ensureCopy(id, k)                 -- make the item for copy k (it only exists once someone owns it)
  local cid = CAFE.copyId(id, k)
  if CAFE.byId[cid] then return cid end
  local base = CAFE.byId[id]
  local it = {}
  for key, v in pairs(base) do it[key] = v end
  it.id, it.copyOf = cid, id
  CAFE.ITEMS[#CAFE.ITEMS + 1] = it
  CAFE.byId[cid] = it
  CAFE.BIRDITEMS = nil                          -- (found again, with this one in)
  CAFE.art[cid] = function(...) return CAFE.art[id](...) end
  CAFE.ANIM[cid], CAFE.ADX[cid], CAFE.AEXT[cid] = CAFE.ANIM[id], CAFE.ADX[id], CAFE.AEXT[id]
  return cid
end
function CAFE.ensureCopies(d)                   -- a saved cafe: bring back the copies it owns
  for key in pairs(d.decor) do
    local base, k = string.match(key, "^(.-)#(%d+)$")
    if base and CAFE.byId[base] then CAFE.ensureCopy(base, tonumber(k)) end
  end
end
function CAFE.countOf(d, id)                    -- how many you own, how many are out in the cafe, how many are in your hand
  local tot, placed = 0, 0
  for k = 1, CAFE.copyCount(d, id) do
    local st = d.decor[CAFE.copyId(id, k)]
    if st ~= nil then tot = tot + 1; if st == "on" then placed = placed + 1 end end
  end
  return { tot = tot, placed = placed, hand = tot - placed }
end
function CAFE.nextCopy(d, id)                   -- the first copy number you don't own yet
  return CAFE.ensureCopy(id, CAFE.copyCount(d, id) + 1)
end
function CAFE.toggleTarget(d, id)               -- tapping A on an owned row: put one out of your hand, or when none are, pick the last one up
  if not CAFE.multiOK(CAFE.byId[id]) then return id end
  local lastOn
  for k = 1, CAFE.copyCount(d, id) do
    local cid = CAFE.copyId(id, k)
    local st = d.decor[cid]
    if st == "off" then return CAFE.ensureCopy(id, k) end
    if st == "on" then lastOn = cid end
  end
  return lastOn or id
end

-- The decor editor (hold A on an owned piece in the shop): the cafe with every spot this piece can use; put one down or pick one up.
function CAFE.openEdit(id)
  local d = CAFE.cur
  CAFE.edit = { id = id, slot = nil }
  CAFE.hold = nil
  transitionTo(function()
    G = CAFE.stageG()
    CAFE.mode = "edit"
  end)
end
function CAFE.editSpots()                       -- every spot this piece could stand on: where its copies are now, plus the free ones
  local d, id = CAFE.cur, CAFE.edit.id
  local it = CAFE.byId[id]
  local mine, list = {}, {}
  for k = 1, CAFE.copyCount(d, id) do
    local cid = CAFE.copyId(id, k)
    if d.decor[cid] == "on" and d.place[cid] then mine[d.place[cid]] = cid; list[#list + 1] = d.place[cid] end
  end
  for _, sl in ipairs(CAFE.freeSlots(d, it.kind, id)) do list[#list + 1] = sl end
  return list, mine
end
function CAFE.editRefresh()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  CAFE.fixTops(d)
  G.scn, G.own, G.winOv, G.vineImgs, G.tops = nil, nil, nil, nil, nil; G.liveL, G.liveC = nil, nil
  for key in pairs(G) do
    if type(key) == "string" and (key:find("Img$") or key:find("^vine")) then G[key] = nil end
  end
end
function CAFE.editUpdate(L, R, U, D, A_, B_)
  local d, e = CAFE.cur, CAFE.edit
  local it = CAFE.byId[e.id]
  local list, mine = CAFE.editSpots()
  local have = false
  for _, sl in ipairs(list) do if sl == e.slot then have = true end end
  if not have then e.slot = list[1] end
  local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
  if dir and #list > 0 then
    local cur = 1
    for i, v in ipairs(list) do if v == e.slot then cur = i end end
    local nat = CAFE.spatial(CAFE.spotPts(it.kind, list), cur, dir)
    if list[nat] ~= e.slot then e.slot = list[nat]; sfxClick() end
  elseif A_ and e.slot then
    local cid = mine[e.slot]
    if cid then                                              -- one of yours is here: it goes into your hand
      d.decor[cid] = "off"; d.place[cid] = nil
      CAFE.editRefresh(); sfxClick()
    else
      local c = CAFE.countOf(d, e.id)
      if c.hand > 0 then                                     -- a free spot: put one from your hand down
        for k = 1, CAFE.copyCount(d, e.id) do
          local hid = CAFE.copyId(e.id, k)
          if d.decor[hid] == "off" then d.decor[hid] = "on"; d.place[hid] = e.slot; break end
        end
        CAFE.editRefresh(); sfxPlay("tip", false, 1.0)
      else
        sfxWrong(); CAFE.say("None in your hand. Pick one up first.")
      end
    end
  elseif B_ then
    CAFE.write()
    transitionTo(function()
      G = nil
      CAFE.edit = nil
      CAFE.mode = "shop"
      CAFE.rc = nil
    end)
  end
end
function CAFE.editDraw()
  local d, e = CAFE.cur, CAFE.edit
  local it = CAFE.byId[e.id]
  CAFE.sceneTop()
  CAFE.sceneBottom()
  UI.drawDoor()
  local list, mine = CAFE.editSpots()
  local c = CAFE.countOf(d, e.id)
  for _, sl in ipairs(list) do
    local x, y, w, h = CAFE.spotRect(it.kind, sl)
    local sel = (sl == e.slot)
    if mine[sl] then                                         -- one of yours: a heavy outline on the selected one
      if sel then
        gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(x - 2, y - 2, w + 4, h + 4, 6); gfx.setLineWidth(1)
      end
    elseif sel then                                          -- a free spot: a preview of the piece standing there
      gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 4)
      gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(x, y, w, h, 4); gfx.setLineWidth(1)
      if c.hand > 0 then
        if it.kind == "counter" and sl <= 10 then CAFE.counterAt(e.id, sl, CAFE.CSLOT[sl][1], y + math.floor(h / (2)))
        else CAFE.art[e.id](x + math.floor(w / (2)), y + math.floor(h / (2))) end
      end
    else                                                     -- the rest: dotted boxes
      gfx.setColor(WHITE)
      for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
      for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
      gfx.setColor(BLACK)
      for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
      for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
    end
  end
  if e.slot then
    local x, y, w, h = CAFE.spotRect(it.kind, e.slot)
    CAFE.pointer(x + math.floor(w / (2)) + 4, y + math.floor(h / (2)) - 2)
  end
  -- one neat plate at the top: the name, how many are in your hand, and what the buttons do
  gfx.setFont(fontBold)
  local top = it.name .. "   In hand: " .. c.hand
  local mid = (e.slot and mine[e.slot]) and "A: pick it up" or (c.hand > 0 and "A: put one here" or "None in hand")
  local sub = mid .. "     B: back"
  local pw = math.max(gfx.getTextSize(top), gfx.getTextSize(sub)) + 30
  pw = math.min(pw, 360)
  gfx.setColor(WHITE); gfx.fillRoundRect(200 - math.floor(pw / (2)), 3, pw, 38, 7)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(200 - math.floor(pw / (2)), 3, pw, 38, 7); gfx.setLineWidth(1)
  drawTC(CAFE.fitOne(top, pw - 16, true), 200, 6, true)
  drawTC(CAFE.fitOne(sub, pw - 16, false), 200, 24)
  if CAFE.msg then
    local ml = CAFE.fitLines(CAFE.msg, 324, true, 2)
    local mh = 6 + 16 * #ml
    gfx.setColor(WHITE); gfx.fillRoundRect(30, 130, 340, mh, 6)
    gfx.setColor(BLACK); gfx.drawRoundRect(30, 130, 340, mh, 6)
    for li = 1, #ml do drawTC(ml[li], 200, 133 + (li - 1) * 16, true) end
  end
end

-- ---- screens -------------------------------------------------------------------------------------------
function CAFE.update(dt)
  do                                           -- the tab strip slides to the chosen tab (the short way round)
    local n = #CAFE.TABS
    local dl = (CAFE.tab - CAFE.tabPos + n / 2) % n - n / 2
    if math.abs(dl) < 0.02 then CAFE.tabPos = CAFE.tab else CAFE.tabPos = (CAFE.tabPos + dl * math.min(1, dt * 12) - 1) % n + 1 end
  end
  if CAFE.msgT > 0 then CAFE.msgT = CAFE.msgT - dt; if CAFE.msgT <= 0 then CAFE.msg = nil end end
  if CAFE.askPend and CAFE.mode == "shop" and trans == nil then              -- (PC: the star bar was clicked in a shift: the rank-up question is waiting)
    CAFE.askPend = nil
    if CAFE.cur and (CAFE.cur.stars or 0) >= 4.999 and not CAFE.rank then
      CAFE.tab, CAFE.tabPos, CAFE.shopSel, CAFE.scroll, CAFE.focus = 1, 1, 1, 0, "list"
      CAFE.ask = { sel = 2 }
    end
  end
  local A_, B_ = pd.buttonJustPressed(pd.kButtonA), pd.buttonJustPressed(pd.kButtonB)
  local U, D = pd.buttonJustPressed(pd.kButtonUp), pd.buttonJustPressed(pd.kButtonDown)
  local L, R = pd.buttonJustPressed(pd.kButtonLeft), pd.buttonJustPressed(pd.kButtonRight)
  if CAFE.mode == "slots" then
    if CAFE.erase then
      if L or R then CAFE.eraseSel = 3 - (CAFE.eraseSel or 2); sfxClick()           -- 1 = delete, 2 = cancel
      elseif A_ then
        if CAFE.eraseSel == 1 then
          CAFE.pre = nil
          pcall(pd.datastore.delete, "cafe" .. CAFE.erase)
          CAFE.slots[CAFE.erase] = nil
        end
        CAFE.erase = nil
        sfxClick()
      elseif B_ then CAFE.erase = nil; sfxClick() end
      return
    end
    if D then CAFE.sel = CAFE.sel % 3 + 1; sfxClick()
    elseif U then CAFE.sel = (CAFE.sel + 1) % 3 + 1; sfxClick()
    elseif R and CAFE.slots[CAFE.sel] then CAFE.erase = CAFE.sel; CAFE.eraseSel = 2; sfxClick()      -- (it starts on Cancel, to be safe)
    elseif B_ then CAFE.goTitle()
    elseif A_ then
      sfxClick()
      local i = CAFE.sel
      CAFE.slot = i
      if CAFE.slots[i] then
        CAFE.cur = CAFE.slots[i]
        CAFE.openDoor()
      else
        UI.fast(function() CAFE.mode, CAFE.name, CAFE.letter, CAFE.onDone = "name", "", 0, false; UI.bgSet("name") end)
      end
    end
  elseif CAFE.mode == "char" then
    if L then CAFE.charSel = (CAFE.charSel + 1) % 3 + 1; sfxClick()
    elseif R then CAFE.charSel = CAFE.charSel % 3 + 1; sfxClick()
    elseif B_ then
      sfxClick()
      UI.fast(function() CAFE.mode, CAFE.onDone = "name", false; UI.bgSet("name") end)
    elseif A_ then
      CAFE.cur = CAFE.fresh(CAFE.pendName)
      CAFE.cur.char = CAFE.charSel
      CAFE.write()
      CAFE.openDoor()
    end
  elseif CAFE.mode == "name" then
    if CAFE.onDone then
      if L or U or B_ then CAFE.onDone = false; sfxClick()
      elseif A_ then
        local nm = CAFE.name:gsub("%s+$", "")
        if #nm >= 1 then
          CAFE.pendName, CAFE.charSel = nm, 1               -- next: pick who's behind the counter
          UI.fast(function() CAFE.mode = "char"; UI.bgSet("char") end)
        else
          sfxWrong()
          CAFE.onDone = false
        end
      end
      return
    end
    CAFE.crank = CAFE.crank + pd.getCrankChange()
    local step = 0                                         -- only the crank turns the wheel: A-Z, then the word CAFE, then a space
    while CAFE.crank >= 24 do CAFE.crank = CAFE.crank - 24; step = step + 1 end
    while CAFE.crank <= -24 do CAFE.crank = CAFE.crank + 24; step = step - 1 end
    if L then step = step - 1 elseif R then step = step + 1 end         -- left / right turn the wheel too, if you'd rather not crank
    if step ~= 0 then CAFE.letter = (CAFE.letter + step) % 28; sfxClick() end
    if D then
      CAFE.onDone = true                                   -- down: on to the DONE button below
      sfxClick()
    elseif A_ then
      local nm = CAFE.name
      if CAFE.letter == 26 then                            -- the word
        local add = (#nm > 0 and string.sub(nm, -1) ~= " ") and " CAFE" or "CAFE"
        if #nm + #add <= CAFE.NAME_MAX then CAFE.name = nm .. add; sfxClick() else sfxWrong() end
      elseif #nm < CAFE.NAME_MAX then
        local ch = (CAFE.letter == 27) and " " or string.char(65 + CAFE.letter)
        if not (ch == " " and #nm == 0) then CAFE.name = nm .. ch; sfxClick() else sfxWrong() end
      else
        sfxWrong()
      end
    elseif B_ then
      if #CAFE.name > 0 then
        CAFE.name = CAFE.name:sub(1, -2)
        sfxClick()
      else
        sfxClick()
        UI.fast(function() CAFE.mode = "slots"; UI.bgSet("slots") end)
      end
    end
  elseif CAFE.mode == "door" then
    if CAFE.gift and not CAFE.door.closing then UI.giftUpdate(dt) else CAFE.doorUpdate(dt, B_) end
  elseif CAFE.mode == "layout" then
    CAFE.layoutUpdate(L, R, U, D, A_, B_)
  elseif CAFE.mode == "edit" then
    CAFE.editUpdate(L, R, U, D, A_, B_)
  elseif CAFE.mode == "scratch" then
    CAFE.scratchUpdate(dt, L, R, U, D, A_, B_)
  elseif CAFE.mode == "place" then
    if trans ~= nil then return end                             -- (still fading in: a quick second A would put the same table down twice)
    local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
    if dir then
      local kind = (CAFE.byId[CAFE.pend] or { kind = "table" }).kind
      local nsel = CAFE.spatial(CAFE.spotPts(kind, CAFE.spots), CAFE.spotSel, dir)
      if nsel ~= CAFE.spotSel then CAFE.spotSel = nsel; sfxClick() end
    elseif A_ then CAFE.leavePlace(true)
    elseif B_ then CAFE.leavePlace(false) end
  else   -- shop
    if CAFE.rank then UI.rankUpdate(dt); return end            -- (the prestige show plays over everything)
    if CAFE.note then                                 -- a little message box: A or B closes it
      if A_ or B_ then CAFE.note = nil; sfxClick() end
      return
    end
    if CAFE.ask then UI.askUpdate(); return end
    local rows = CAFE.rows()
    local n = #rows
    -- the crank scrolls too: every 70 degrees is one step
    CAFE.crankAcc = CAFE.crankAcc + pd.getCrankChange()
    local step = 0
    if CAFE.crankAcc >= 70 then CAFE.crankAcc = CAFE.crankAcc - 70; step = 1
    elseif CAFE.crankAcc <= -70 then CAFE.crankAcc = CAFE.crankAcc + 70; step = -1 end
    if D then step = 1 elseif U then step = -1 end
    local function click() if frames - (CAFE.lastClick or -9) >= 3 then CAFE.lastClick = frames; sfxClick() end end
    local function turn(t)                                              -- switch tabs; the pointer goes back up to them
      CAFE.tab = t; CAFE.shopSel, CAFE.scroll, CAFE.focus = 1, 0, "tabs"
      CAFE.rc = nil
      click()
    end
    if CAFE.hold then                                                   -- A is down on an owned piece: held a moment opens the editor, let go before that is a tap
      local hr = CAFE.hold.row
      if U or D or L or R or B_ or CAFE.focus ~= "list" or rows[CAFE.shopSel] ~= hr then CAFE.hold = nil
      elseif pd.buttonIsPressed(pd.kButtonA) then
        if frames - CAFE.hold.t >= 14 then
          CAFE.hold = nil; sfxClick()
          if hr.layout then CAFE.openLayout() else CAFE.openEdit(hr[5]) end      -- (the seats row: hold A to move or hide the tables)
          return
        end
      else
        CAFE.hold = nil
        if hr.layout then if hr[3] == "seat" then CAFE.buy(hr) else sfxWrong() end else CAFE.toggle(hr) end
      end
    end
    if B_ then                                                          -- B hops between the list and the Back to cafe button
      CAFE.focus = (CAFE.focus == "back" or CAFE.focus == "quit") and "list" or "back"
      if CAFE.focus == "list" then CAFE.shopSel = math.max(1, math.min(CAFE.shopSel, n)) end
      sfxClick()
    elseif CAFE.focus == "tabs" or CAFE.focus == "list" then
      if L then turn((CAFE.tab - 2) % #CAFE.TABS + 1)                   -- the tabs wrap around
      elseif R then turn(CAFE.tab % #CAFE.TABS + 1)
      elseif CAFE.focus == "tabs" then
        if step == 1 then CAFE.focus, CAFE.shopSel = "list", 1; click() end
      else
        if step == 1 then
          if CAFE.shopSel < n then CAFE.shopSel = CAFE.shopSel + 1; click() end     -- (only B takes you down to the buttons)
        elseif step == -1 then
          if CAFE.shopSel > 1 then CAFE.shopSel = CAFE.shopSel - 1; click()
          else CAFE.focus = "tabs"; click() end                         -- back up to the tabs
        elseif A_ then
          local row = rows[CAFE.shopSel]
          local k = row[3]
          if (k == "toggle" and row.multi) or row.layout then CAFE.hold = { t = frames, row = row }       -- (tap = put out / pick up / buy, hold = edit; decided on release)
          elseif k == "cup" or k == "seat" or k == "buy" or k == "more" then CAFE.buy(row)
          elseif k == "scratch" or k == "scratchgo" or k == "scratchfree" then CAFE.scratchBuy(row)
          elseif k == "bow" then CAFE.cur.nobow = (CAFE.cur.nobow ~= true) or nil; sfxClick(); CAFE.write()
          elseif k == "hball" then
            local hb = CAFE.cur.hball or {}
            CAFE.cur.hball = hb
            hb[row[5]] = (hb[row[5]] ~= true) or nil
            if CAFE.cur.decor[row[5]] ~= "on" and hb[row[5]] then CAFE.say("Put the hamster out first!") end
            sfxClick(); CAFE.write()
          elseif k == "toggle" or k == "sign" then CAFE.toggle(row)
          elseif k == "layout" then CAFE.openLayout()
          elseif k == "prestige" then CAFE.ask = { sel = 2 }; sfxClick()      -- (it asks first, on "Not yet")
          else sfxWrong() end
        end
      end
    else                                                                -- the two buttons in the bottom bar
      if step == -1 then CAFE.focus = "list"; CAFE.shopSel = math.max(1, n); click()
      elseif L and CAFE.focus == "quit" then CAFE.focus = "back"; sfxClick()
      elseif R and CAFE.focus == "back" then CAFE.focus = "quit"; sfxClick()
      elseif A_ then
        CAFE.write()
        if CAFE.focus == "back" then sfxClick(); CAFE.begin()
        else CAFE.closeDoor() end
      end
    end
    -- keep the highlighted row in view (7 rows fit)
    if CAFE.shopSel <= CAFE.scroll then CAFE.scroll = CAFE.shopSel - 1 end
    if CAFE.shopSel > CAFE.scroll + CAFE.visRows() then CAFE.scroll = CAFE.shopSel - CAFE.visRows() end
    if CAFE.scroll < 0 then CAFE.scroll = 0 end
  end
end

function CAFE.band(title)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(title, 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

-- a little box showing the highlighted item, inside a wobbly animated border
function CAFE.wobbleBox(bx, by, bw, bh)            -- a round-cornered box edge drawn as slowly moving squiggly lines
  local t = frames * 0.18
  local r = 12
  local sw, sh, al = bw - 2 * r, bh - 2 * r, math.pi * r / 2
  local per = 2 * sw + 2 * sh + 4 * al
  local n = 80
  local fx, fy, lx, ly
  gfx.setLineWidth(2)
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < sw then x, y, nx, ny = bx + r + d, by, 0, -1
    elseif d < sw + al then
      local a = -math.pi / 2 + (d - sw) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + bw - r + r * nx, by + r + r * ny
    elseif d < sw + al + sh then x, y, nx, ny = bx + bw, by + r + (d - sw - al), 1, 0
    elseif d < sw + 2 * al + sh then
      local a = (d - sw - al - sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + bw - r + r * nx, by + bh - r + r * ny
    elseif d < 2 * sw + 2 * al + sh then x, y, nx, ny = bx + bw - r - (d - sw - 2 * al - sh), by + bh, 0, 1
    elseif d < 2 * sw + 3 * al + sh then
      local a = math.pi / 2 + (d - 2 * sw - 2 * al - sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + r + r * nx, by + bh - r + r * ny
    elseif d < 2 * sw + 3 * al + 2 * sh then x, y, nx, ny = bx, by + bh - r - (d - 2 * sw - 3 * al - sh), -1, 0
    else
      local a = math.pi + (d - 2 * sw - 3 * al - 2 * sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + r + r * nx, by + r + r * ny
    end
    local o = math.sin(i * 1.1 + t) * 1.6
    local px, py = x + nx * o, y + ny * o
    if lx then gfx.drawLine(lx, ly, px, py) else fx, fy = px, py end
    lx, ly = px, py
  end
  gfx.drawLine(lx, ly, fx, fy)
  gfx.setLineWidth(1)
end

function CAFE.pointer(mx, my)
  if PC and PC.mouseOn then return end                  -- a little mouse arrow, bobbing
  mx = math.floor(mx) + math.floor(math.sin(frames * 0.15) * 2 + 0.5)
  my = math.floor(my) + math.floor(math.sin(frames * 0.15 + 1) * 1.5 + 0.5)
  UI.inkPush("chrome")                                          -- (PC: always a plain white arrow with a black edge)
  UI.pic(CAFE.ARROW, mx, my)
  UI.inkPop()
  gfx.setColor(BLACK)
end
CAFE.ARROW = { "k.........", "kk........", "kwk.......", "kwwk......", "kwwwk.....", "kwwwwk....", "kwwwwwk...", "kwwwwwwk..",
               "kwwwwwwwk.", "kwwwwkkkkk", "kwwkwwk...", "kwk.kwwk..", "kk..kwwk..", "k....kwwk.", ".....kwwk.", "......kk.." }   -- a clean pixel arrow (like a mouse pointer)

-- where each kind of thing can go, as a word in a little bubble on the shop's picture
CAFE.RUGWHERE = { runner = "Register rug", orug = "Table section rug", rug = "Cafe pickup rug" }     -- (flashed under the rugs' previews)
CAFE.WHERE = { floor = "Floor", counter = "Table", cloth = "Table", wall = "Wall", tiny = "Wall", frame = "Window", curtain = "Window",
               shelf = "Shelf", ceiling = "Ceiling", rug = "Floor", orug = "Floor", runner = "Floor", wallpaper = "Wall", flooring = "Floor", seating = "Seats" }
CAFE.bubM = {}
function CAFE.bubbleMeasure(word)                  -- where the real letters sit inside the text box (measured from the drawn pixels, once per word)
  local m = CAFE.bubM[word]
  if m then return m end
  gfx.setFont(fontBold)
  local tw, th = gfx.getTextSize(word)
  m = { w = tw, dx = tw / 2, dy = th / 2 }       -- (what to use if the pixels can't be read: the middle of the text box)
  local function scan(str)                       -- the box the real letters fill, from the drawn pixels
    local sw, sh = gfx.getTextSize(str)
    local im = gfx.image.new(sw + 8, sh + 8, gfx.kColorClear)
    gfx.pushContext(im)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    gfx.setFont(fontBold)
    gfx.drawText(str, 4, 4)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.popContext()
    local x0, x1, y0, y1 = 9999, -1, 9999, -1
    for y = 0, sh + 7 do
      for x = 0, sw + 7 do
        if im:sample(x, y) ~= gfx.kColorClear then
          if x < x0 then x0 = x end
          if x > x1 then x1 = x end
          if y < y0 then y0 = y end
          if y > y1 then y1 = y end
        end
      end
    end
    return x0, x1, y0, y1
  end
  local ok = pcall(function()
    local x0, x1, y0, y1 = scan(word)
    if x1 >= x0 and y1 >= y0 then
      m.w = x1 - x0 + 1
      m.dx = (x0 + x1 + 1) / 2 - 4              -- the middle of the letters, measured from where the text was drawn
      m.dy = (y0 + y1 + 1) / 2 - 4
    end
    -- the tails of g, j, p, q and y hang below the line and would drag the middle down ("Ceiling" sat too high),
    -- so the up-and-down middle is taken from the same word with those letters swapped for round ones
    local flat = word:gsub("[gjpqy]", "o")
    if flat ~= word then
      local _, _, fy0, fy1 = scan(flat)
      if fy1 >= fy0 then m.dy = (fy0 + fy1 + 1) / 2 - 4 end
    end
  end)
  CAFE.bubM[word] = m
  return m
end

function CAFE.whereBubble(word, cx, mid)             -- a round black bubble with bold white words, centred on x = cx and on the line y = mid
  local m = CAFE.bubbleMeasure(word)
  local w, h = math.max(46, m.w + 18), 17
  local x, top = cx - math.floor(w / (2)), mid - 8
  gfx.setColor(WHITE)                                            -- a white rim so it stands out from dark pictures too
  gfx.fillRoundRect(x - 1, top - 1, w + 2, h + 2, 9)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x, top, w, h, 8)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  gfx.setFont(fontBold)
  gfx.drawText(word, math.floor(cx - m.dx + 0.5), math.floor(top + h / 2 - m.dy + 0.5))      -- (the letters' own middle lands on the bubble's middle)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

CAFE.MOREDESC = { hmus = { "Changes the weather", "Adds Pumpkin Spice" },          -- (more lines the card cycles through)
                  xmus = { "Changes the weather", "Adds Hot Cocoa" } }
function UI.squiggle(bx, by, bw, bh, t, plate)    -- the shop picture's wobbly card: a white card whose edge ripples
  local per = 2 * (bw + bh)
  local n = 40
  local qx, qy = UI.sqx or {}, UI.sqy or {}
  UI.sqx, UI.sqy = qx, qy
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < bw then x, y, nx, ny = bx + d, by, 0, -1
    elseif d < bw + bh then x, y, nx, ny = bx + bw, by + (d - bw), 1, 0
    elseif d < 2 * bw + bh then x, y, nx, ny = bx + bw - (d - bw - bh), by + bh, 0, 1
    else x, y, nx, ny = bx, by + bh - (d - 2 * bw - bh), -1, 0 end
    local o = math.sin(i * 1.3 + t) * 1.8
    qx[i], qy[i] = x + nx * o, y + ny * o
  end
  if plate then                                  -- on the dark page the white card IS the squiggle (no straight white box showing behind it)
    local pts = UI.sqpts or {}
    UI.sqpts = pts
    for i = 0, n - 1 do pts[2 * i + 1] = math.floor(qx[i] + 0.5); pts[2 * i + 2] = math.floor(qy[i] + 0.5) end
    gfx.setColor(WHITE)
    gfx.fillPolygon(table.unpack(pts, 1, 2 * n))
    gfx.setColor(BLACK)
  end
  gfx.setLineWidth(2)
  for i = 1, n do gfx.drawLine(qx[i - 1], qy[i - 1], qx[i], qy[i]) end
  gfx.drawLine(qx[n], qy[n], qx[0], qy[0])
  gfx.setLineWidth(1)
end

function CAFE.drawPreview(row)
  if row == nil or row[3] == "start" or row[3] == "quit" or (row[3] == "none" and not row.pv) then return end
  local id = row[5]
  if row[3] == "seat" or row.pv == "table" then id = (row[3] == "seat" and CAFE.cur and CAFE.cur.seatStep == 4) and "booth" or "table" end
  local art = id and CAFE.art[id]
  local bx, by, bw, bh = 298, 68, 92, 70
  local plate = UI.shopBgImg()
  if not plate then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, bh, 8)
  end
  gfx.setColor(BLACK)
  -- squiggly border: points on the rectangle edge pushed in/out by a moving sine (Playdate: its 25 frames are drawn once, then stamped)
  do                                                                  -- (both: 25 frames drawn once, then stamped; PC: one set per colour)
    local ph = frames % 25
    local im = UI.cacheImg("squig", bw * 1000 + bh, ph + 100 * UI.inkNum(), bw + 10, bh + 10, function() UI.squiggle(5, 5, bw, bh, ph * (2 * math.pi / 25), plate) end)
    if im then UI.cacheDraw(im, bx - 5, by - 5) else UI.squiggle(bx, by, bw, bh, ph * (2 * math.pi / 25), plate) end
  end
  gfx.setClipRect(bx + 4, by + 4, bw - 8, bh - 8)
  local cx, cy = bx + math.floor(bw / (2)), by + math.floor(bh / (2)) + 2
  local it = id and CAFE.byId[id]
  local function drawAs(fn, ox, oy)             -- run a "draw what's owned" routine as if only this id were on
    local save, saveG = CAFE.decorOn, G
    CAFE.decorOn = function(q) return q == id end
    G = { mode = "cafe", cafe = { decor = { [id] = "on" } } }
    gfx.setDrawOffset(ox, oy)
    pcall(fn)
    gfx.setDrawOffset(0, 0)
    G = saveG
    CAFE.decorOn = save
  end
  if it and it.kind == "runner" then
    local h = bh - 22                            -- shrunk to fit the box, whole
    local w = math.floor(h * 36 / 118 + 0.5)
    CAFE.runnerAt(id, cx - math.floor(w / (2)), by + 12, w, h)              -- (a little lower, clear of the top edge)
  elseif it and it.kind == "orug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 76 / 162 + 0.5)
    CAFE.ovalAt(id, cx - math.floor(w / (2)), by + 10 + math.floor((bh - 22 - h) / (2)), w, h)
  elseif it and it.kind == "rug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 44 / 190 + 0.5) + 4
    CAFE.rugAt(id, cx - math.floor(w / (2)), by + 10 + math.floor((bh - 22 - h) / (2)), w, h)
  elseif it and it.kind == "shelf" then
    local n = #CAFE.VINES[id]                    -- hanging from a bit of shelf, drawn small and blown up
    CAFE.vinePrev = CAFE.vinePrev or gfx.image.new(42, 30, gfx.kColorClear)
    CAFE.vinePrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.vinePrev)
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 42, 3)
    CAFE.vineDraw(id, 21 - (n - 1) * 2, 3, (math.floor(frames / (4))) % 16)
    gfx.popContext()
    gfx.setClipRect(bx + 1, by + 1, bw - 2, bh - 2)
    CAFE.vinePrev:drawScaled(cx - 42, by + 8, 2, 2)
  elseif it and it.kind == "ceiling" then
    gfx.setColor(BLACK)                          -- (the real lights are white on the dark wall: here it's black on the white card)
    local nb, gap, x0 = 4, 22, bx + 14
    if id == "fairylights" then nb, gap, x0 = 6, 15, bx + 9 end
    local wy0 = by + 24
    local px0, py0
    for x = bx + 4, bx + bw - 4, 3 do
      local y = wy0 + math.floor(4 * math.sin(math.pi * ((x - bx) % 30) / 30) + 0.5)
      if px0 then gfx.drawLine(px0, py0, x, y) end
      px0, py0 = x, y
    end
    local ph = (math.floor(frames / (CAFE.LSTY[id][2]))) % CAFE.LSTY[id][1]
    for i = 0, nb - 1 do
      local x = x0 + i * gap
      local wy = wy0 + math.floor(4 * math.sin(math.pi * ((x - bx) % 30) / 30) + 0.5)
      CAFE.lightBulb(id, x, wy, CAFE.lightLit(id, i, ph), 1.5, true)
    end
  elseif it and it.kind == "cloth" then
    CAFE.tableAt(cx, cy, 22, id)
  elseif it and it.species then                   -- pets: drawn small, then blown up so you can see the coat
    CAFE.petPrev = CAFE.petPrev or {}
    local im = CAFE.petPrev[id]
    if im == nil then im = gfx.image.new(50, 36, gfx.kColorClear); CAFE.petPrev[id] = im end
    im:clear(gfx.kColorClear)
    gfx.pushContext(im)
    CAFE.pet(it.species, 25, 32, 1, "sit", id)
    gfx.popContext()
    gfx.setClipRect(bx + 1, by + 1, bw - 2, bh - 2)
    im:drawScaled(cx - 50, cy - 38, 2, 2)
  elseif row[3] == "prestige" then
    UI.drawPrestigePreview(cx, cy)
  elseif row[3] == "scratch" or row[3] == "scratchgo" or row[3] == "scratchfree" then
    UI.scratchPreview(cx, cy, row.tier or 1)
  elseif row[3] == "layout" then                  -- a cardboard package with the mouse arrow resting on it
    local x0, y0 = cx - 26, cy - 8                 -- front face
    local fw, fh, dx, dy = 44, 28, 12, 9           -- (front width/height, and how far the top leans back)
    gfx.setColor(WHITE)
    gfx.fillPolygon(x0, y0, x0 + dx, y0 - dy, x0 + fw + dx, y0 - dy, x0 + fw, y0)           -- top
    gfx.fillPolygon(x0 + fw, y0, x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy, x0 + fw, y0 + fh)   -- side
    gfx.fillRect(x0, y0, fw, fh)
    gfx.setPattern(CHECK)                          -- the side is shaded
    gfx.fillPolygon(x0 + fw, y0, x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy, x0 + fw, y0 + fh)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(x0, y0, fw, fh)
    gfx.drawLine(x0, y0, x0 + dx, y0 - dy); gfx.drawLine(x0 + dx, y0 - dy, x0 + fw + dx, y0 - dy)
    gfx.drawLine(x0 + fw, y0, x0 + fw + dx, y0 - dy)
    gfx.drawLine(x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy); gfx.drawLine(x0 + fw, y0 + fh, x0 + fw + dx, y0 + fh - dy)
    gfx.setLineWidth(1)
    local mx = x0 + math.floor(fw / (2))                         -- packing tape down the middle of the lid and the front
    gfx.setPattern(CHECK)
    gfx.fillPolygon(mx - 4, y0, mx - 4 + dx, y0 - dy, mx + 4 + dx, y0 - dy, mx + 4, y0)
    gfx.fillRect(mx - 4, y0, 8, 11)
    gfx.setColor(BLACK)
    gfx.drawRect(mx - 4, y0, 8, 11)
    gfx.drawRect(x0 + 6, y0 + 16, 16, 8)            -- a little shipping label
    gfx.drawLine(x0 + 9, y0 + 19, x0 + 19, y0 + 19)
    gfx.drawLine(x0 + 9, y0 + 22, x0 + 15, y0 + 22)
    CAFE.pointer(x0 + fw - 12, y0 + 6)
  elseif row[3] == "hball" then                   -- the hamster in its ball (or tucked up in its cage), blown up
    CAFE.ballPrev = CAFE.ballPrev or gfx.image.new(44, 32, gfx.kColorClear)
    CAFE.ballPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.ballPrev)
    if CAFE.cur.hball and CAFE.cur.hball[row[5]] then CAFE.hamBall(22, 26, 1, true, frames * 0.15, row[5])
    else CAFE.hamCage(22, 16, row[5]) end
    gfx.popContext()
    CAFE.ballPrev:drawScaled(cx - 44, by + 6, 2, 2)
  elseif row[3] == "bow" then                     -- the barista, with or without the bow
    CAFE.wearPrev = CAFE.wearPrev or gfx.image.new(40, 40, gfx.kColorClear)
    CAFE.wearPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wearPrev)
    UI.noBow = CAFE.cur.nobow == true
    drawPerson(20, 24, 12, false, 2)
    UI.noBow = false
    gfx.popContext()
    CAFE.wearPrev:drawScaled(cx - 40, by + 5, 2, 2)
  elseif row[3] == "sign" and row.mug then        -- the coffee picture, twice the size
    CAFE.mugPrev = CAFE.mugPrev or gfx.image.new(34, 32, gfx.kColorClear)
    CAFE.mugPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.mugPrev); CAFE.mugPic(2, 2); gfx.popContext()
    CAFE.mugPrev:drawScaled(cx - 34, cy - 32, 2)
  elseif row[3] == "sign" then                    -- the sign you actually have, name and all
    gfx.setClipRect(cx - 43, by + 4, 86, bh - 8)            -- (a little wider than the card's usual picture area, so 13 letters sit inside the sign)
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 43, cy - 14, 86, 28)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(cx - 43, cy - 14, 86, 28)
    gfx.setLineWidth(1)
    CAFE.fitText(CAFE.cafeName(), cx, cy, 66, 18, 79)
  elseif row[3] == "cup" or row.pv == "cup" then    -- a big steaming mug (also on the "MAX" cups row)
    UI.ink("mugc")
    gfx.setColor(BLACK)
    gfx.setLineWidth(3)
    gfx.drawCircleAtPoint(cx + 24, cy + 2, 8)
    gfx.setLineWidth(1)
    gfx.setColor(WHITE); gfx.fillRoundRect(cx - 20, cy - 12, 40, 32, 5)
    gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(cx - 20, cy - 12, 40, 32, 5); gfx.setLineWidth(1)
    UI.ink("none")
    gfx.setPattern(DRINK_PATTERN.coffee); gfx.fillRect(cx - 17, cy - 8, 34, 11); gfx.setColor(BLACK)
    UI.ink("gray")
    for i = -1, 1 do
      local px, py
      for yy = cy - 16, cy - 30, -2 do
        local xx = cx + i * 9 + math.floor(math.sin(frames * 0.2 + yy * 0.5 + i * 2) * 3 + 0.5)
        if px then gfx.drawLine(px, py, xx, yy) end
        px, py = xx, yy
      end
    end
    UI.ink("mugc")
    gfx.fillRect(cx - 26, cy + 22, 52, 3)
    UI.ink("none")
  elseif it and (it.kind == "wall" or it.kind == "tiny") and art then      -- wall decor: blown up so you can see it
    CAFE.wallPrev = CAFE.wallPrev or gfx.image.new(70, 50, gfx.kColorClear)
    CAFE.wallPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wallPrev)
    art(35, 25)
    gfx.popContext()
    CAFE.wallPrev:drawScaled(cx - 70, cy - 50, 2, 2)
  elseif it and it.pettab and art then              -- tanks, cages and perches: blown up so you can see who lives there
    local bird = it.bird ~= nil                    -- (a bird is tall: it sits lower, so its head is in the picture, not under the top edge)
    local key = bird and "birdPrev" or "tankPrev"
    CAFE[key] = CAFE[key] or gfx.image.new(46, bird and 40 or 34, gfx.kColorClear)
    CAFE[key]:clear(gfx.kColorClear)
    gfx.pushContext(CAFE[key])
    art(23, bird and 25 or 20)
    gfx.popContext()
    CAFE[key]:drawScaled(cx - 46, bird and (by + 1) or (cy - 36), 2, 2)
  elseif it and (it.kind == "hat" or it.kind == "glasses") then          -- clothes: the barista wearing it, blown up
    CAFE.wearPrev = CAFE.wearPrev or gfx.image.new(40, 40, gfx.kColorClear)
    CAFE.wearPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wearPrev)
    local blook = UI.BARISTA[CAFE.cur.char or 1] or 5
    UI.glasses = (it.kind == "glasses")
    UI.noBow = (it.kind == "hat") or CAFE.cur.nobow == true
    drawPerson(20, 24, blook, false, 2)
    UI.glasses = false; UI.noBow = false
    if it.kind == "glasses" then CAFE.WEAR[id](20, 24 + UI.eyeRow(blook, true)) else CAFE.drawHat(id, 20, 24, blook) end
    gfx.popContext()
    CAFE.wearPrev:drawScaled(cx - 40, by + 5, 2, 2)
  elseif art then
    art(cx, cy)
  else
    local label = (row[3] == "cup") and "CUPS" or (row[3] == "sign") and "SIGN" or ""
    gfx.setColor(BLACK)
    if label ~= "" then drawTC(label, cx, cy - 8, true) end
  end
  gfx.clearClipRect()
  local where = it and CAFE.WHERE[it.kind]
  if it and it.bird and (math.floor(frames / (50))) % 2 == 1 then where = "Floor" end      -- (a bird's perch: on a table, or on the floor)
  if where then CAFE.whereBubble(where, cx, by) end     -- "Floor", "Wall", "Table"...: where this one can go (sits on the frame's top line)
  gfx.setColor(BLACK)
  if plate then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) end   -- (white words on the black plate)
  local PW = plate and 84 or (bw + 12)                           -- widest line that fits the plate
  if row[2] ~= "" then drawTC(CAFE.fitOne(row[2], PW, true), bx + math.floor(bw / (2)), by + bh + 6, true) end   -- the price, always in view
  local sub = row[6]
  local rw = it and CAFE.RUGWHERE[it.kind]
  if sub and rw and (math.floor(frames / (50))) % 2 == 0 then sub = rw end       -- rugs: the words flash between where it goes and the usual line
  if row.subs then sub = row.subs[(math.floor(frames / (60))) % #row.subs + 1] end
  local more = sub and id and CAFE.MOREDESC[id]
  if more then                                                                   -- the music records: the usual line, then what else they do
    local ph = (math.floor(frames / (50))) % (#more + 1)
    if ph > 0 then sub = more[ph] end
  end
  local mu = row.multi
  local mlines = nil
  if row.layout and (CAFE.cur.seatStep or 0) >= 1 and (math.floor(frames / (50))) % 2 == 1 then mlines = { "Hold A", "to move tables" } end
  if mu then                                      -- something you can own more than one of: how many you have, and how to edit them
    local ph = (math.floor(frames / (50))) % (row.more and 2 or 3)
    local owned = "Owned: " .. mu.tot
    if ph == 0 then mlines = (mu.tot == 1) and { owned, (mu.hand == 1) and "in your hand" or "in the cafe" } or { owned, mu.placed .. " out", mu.hand .. " in hand" }
    elseif ph == 1 and not row.more then mlines = { "Hold A", "to edit" } end
  end
  if sub or mlines then                           -- a few words under it, wrapped to the box
    local lines = mlines and {} or CAFE.fitLines(sub, PW, false, 4)
    if mlines then                                 -- (each of these lines kept inside the box too: wrapped if it runs wide)
      for _, ml in ipairs(mlines) do for _, l2 in ipairs(CAFE.fitLines(ml, PW, false, 2)) do if #lines < 4 then lines[#lines + 1] = l2 end end end
    end
    local pitch, y0 = 14, by + bh + 24
    if #lines > 3 then pitch, y0 = 12, by + bh + 20 end        -- a fourth line squeezes in by tightening the gaps
    for li = 1, #lines do drawTC(lines[li], bx + math.floor(bw / (2)), y0 + (li - 1) * pitch) end
  end
  if CAFE.hold and CAFE.hold.row == row and frames - CAFE.hold.t >= 3 then       -- A is held: a little bar fills up, and then the editor opens
    local f = math.min(1, (frames - CAFE.hold.t) / 14)
    local x0 = bx + math.floor(bw / (2)) - 36
    if not plate then gfx.setColor(BLACK) else gfx.setColor(WHITE) end
    gfx.fillRect(x0, 226, math.floor(72 * f), 4)
    gfx.drawRect(x0 - 1, 225, 74, 6)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)         -- (always back to normal, even when there was no description)
end

-- a little sticker plate with a few pieces of help in it, spaced evenly and centred as a group on the plate
function UI.hintPlate(parts, y)
  gfx.setFont(fontNormal)
  local widths, total = {}, 0
  for i, t in ipairs(parts) do widths[i] = gfx.getTextSize(t); total = total + widths[i] end
  local gap = 22
  local span = total + gap * (#parts - 1)
  local hw = math.min(span + 32, 372)
  UI.stickerBox(200 - math.floor(hw / (2)), y, hw, 22, false)
  local x = 200 - math.floor(span / (2))
  for i, t in ipairs(parts) do
    drawT(t, x, y + 3)
    x = x + widths[i] + gap
  end
  gfx.setColor(BLACK)
end

-- a white arrow with a black edge, pointing left (d = -1) or right (d = 1)
function UI.sideArrow(x, y, d, big)
  local w, h = big and 15 or 12, big and 15 or 12
  local tip, base = x + d * w, x
  gfx.setColor(BLACK)
  gfx.fillTriangle(tip + d * 2, y, base - d * 2, y - h - 2, base - d * 2, y + h + 2)
  gfx.setColor(WHITE)
  gfx.fillTriangle(tip, y, base, y - h, base, y + h)
  gfx.setColor(BLACK)
end

function UI.drawNameNew()                                  -- NAME YOUR CAFE, on the sunburst
  -- the name so far, on a white sticker
  UI.stickerBox(50, 54, 300, 38, false)
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(CAFE.name)
  local x0 = 200 - math.floor(w / (2))
  drawT(CAFE.name, x0, 62, true)
  if (math.floor(frames / (10))) % 2 == 0 and #CAFE.name < CAFE.NAME_MAX then gfx.setColor(BLACK); gfx.fillRect(x0 + w + 2, 77, 9, 3) end
  drawTR(#CAFE.name .. "/" .. CAFE.NAME_MAX, 340, 74)
  -- the letter wheel (A-Z, the word CAFE, a space), then DONE below it
  local lc = (CAFE.letter == 26) and "CAFE" or ((CAFE.letter == 27) and "space" or string.char(65 + CAFE.letter))
  local dialOn = not CAFE.onDone
  local nudge = dialOn and ((math.floor(frames / (6))) % 2) or 0         -- the arrows tick in and out while the wheel is chosen
  UI.stickerBox(150, 104, 100, 36, dialOn)
  drawTC(lc, 200, 114, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  UI.stickerBox(150, 152, 100, 30, CAFE.onDone)
  drawTC("DONE", 200, 159, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  CAFE.pointer(232, CAFE.onDone and 164 or 118)
  UI.hintPlate(CAFE.onDone and { "A: next", "B: back to the letters" } or { "Type or wheel: letter", "A: add", "B: delete" }, 202)
end

function UI.drawCharNew()                                  -- PICK YOUR BARISTA, on the sunburst
  CAFE.charImgs = CAFE.charImgs or {}
  for i = 1, 3 do
    local bx, by, bw, bh = 36 + (i - 1) * 116, 58, 100, 112
    local on = (CAFE.charSel == i)
    if on then                                             -- the chosen card: a white edge round a heavy black line
      gfx.setColor(WHITE); gfx.fillRoundRect(bx - 4, by - 4, bw + 8, bh + 8, 12)
      gfx.setColor(BLACK); gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 10)
      gfx.setColor(WHITE); gfx.fillRoundRect(bx + 2, by + 2, bw - 4, bh - 4, 7)
    else
      UI.stickerBox(bx, by, bw, bh, false)
    end
    local im = CAFE.charImgs[i]
    if im == nil then
      im = gfx.image.new(40, 40, gfx.kColorClear)
      gfx.pushContext(im)
      drawPerson(20, 14, UI.BARISTA[i], false, 2)
      gfx.popContext()
      CAFE.charImgs[i] = im
    end
    im:drawScaled(bx + 10, by + 12, 2.0)
    gfx.setColor(BLACK)
    if on then CAFE.pointer(bx + 70, by + 95) end
  end
  gfx.setColor(BLACK)
  UI.hintPlate({ "Left / Right: choose", "A: pick", "B: back" }, 202)
end

function CAFE.draw()
  if CAFE.mode == "door" then
    CAFE.doorDraw()
    if CAFE.gift and not CAFE.door.closing then UI.giftDraw() end
    return
  end
  if CAFE.mode == "layout" then CAFE.layoutDraw(); return end
  if CAFE.mode == "scratch" then CAFE.scratchDraw(); return end
  if CAFE.mode == "edit" then CAFE.editDraw(); return end
  if CAFE.mode == "place" then
    CAFE.sceneTop()
    CAFE.sceneBottom()
    UI.drawDoor()
    local it = CAFE.byId[CAFE.pend] or { kind = "table", name = "table" }
    for i, sp in ipairs(CAFE.spots) do
      local x, y, w, h = CAFE.spotRect(it.kind, i == CAFE.spotSel and sp or sp)
      x, y, w, h = CAFE.spotRect(it.kind, sp)
      if i == CAFE.spotSel then
        gfx.setColor(WHITE)
        gfx.fillRoundRect(x, y, w, h, 4)
        gfx.setColor(BLACK)
        gfx.setLineWidth(2)
        gfx.drawRoundRect(x, y, w, h, 4)
        gfx.setLineWidth(1)
        if it.kind == "counter" and sp <= 10 and CAFE.byId[CAFE.pend] then CAFE.counterAt(CAFE.pend, sp, CAFE.CSLOT[sp][1], y + math.floor(h / (2)))
        else CAFE.art[CAFE.byId[CAFE.pend] and CAFE.pend or "table"](x + math.floor(w / (2)), y + math.floor(h / (2))) end
      else
        gfx.setColor(WHITE)
        for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
        for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
        gfx.setColor(BLACK)
        for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
        for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w - 1, yy, x + w - 1, yy + 2) end
      end
    end
    gfx.setColor(WHITE)
    local by = (it.kind == "table" or it.kind == "counter") and 112 or 196        -- keep the box off the spots (tables sit low, the counter high)
    local pl = CAFE.fitLines((it.kind == "shelf") and ("Which end for the " .. it.name .. "?") or ("Where should the " .. it.name .. " go?"), 284, true, 2)
    local ph = 4 + 16 * (#pl + 1)
    if by + ph > 236 then by = 236 - ph end
    gfx.fillRoundRect(50, by, 300, ph, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(50, by, 300, ph, 6)
    for li = 1, #pl do drawTC(pl[li], 200, by + 2 + (li - 1) * 16, true) end
    drawTC(CAFE.fitOne("D-pad: choose   A: place   B: cancel", 284, false), 200, by + 2 + #pl * 16)
    return
  end
  if CAFE.mode == "slots" then
    local art = UI.bgSet("slots")
    if art then
      art[frames % UI.TITLE_N + 1]:draw(0, 0)                                -- the turning sunburst and the lettering
    else
      UI.beanFrame()
      CAFE.band("CAFE  -  CHOOSE A SAVE")
    end
    for i = 1, 3 do
      local y = (art and 54 or 42) + (i - 1) * 50
      local d = CAFE.slots[i]
      local sel = CAFE.sel == i
      if art then
        UI.stickerBox(60, y, 280, 44, sel)                                   -- the same sticker boxes as the title screen
      else
        gfx.setColor(BLACK)
        if sel then
          gfx.fillRoundRect(60, y, 280, 44, 8)
          gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
        else
          gfx.setLineWidth(2)
          gfx.drawRoundRect(60, y, 280, 44, 8)
          gfx.setLineWidth(1)
        end
      end
      local col = sel and WHITE or BLACK
      drawT(tostring(i), 70, y + 13, true)
      if d then
        drawT(d.name, 88, y + 4, true)
        drawT(string.format("%s  %d cups  %d seats", money(d.money), d.cups, CAFE.seatsOf(d.seatStep)), 88, y + 24)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        CAFE.drawStars(280, y + 12, 5, 11, d.stars, col, UI.lvl(d))
        if UI.lvl(d) >= 2 then UI.levelBadge(270, y + 12, UI.lvl(d), col == WHITE) end
        local stk = UI.giftStreakNow(d)                       -- the daily-gift streak: a little flame and the days, right after the name
        if stk >= 1 then
          gfx.setFont(fontBold)
          local fx = 88 + gfx.getTextSize(d.name) + 8
          UI.ink("inkorange")
          gfx.setColor(col)
          UI.pic(UI.FLAMEPIC, fx, y + 7, 1, col == WHITE)
          gfx.setColor(UI.color and BLACK or col)             -- (the picture leaves the colour at black; Playdate: the days in the box's own colour, PC: orange)
          UI.pixText(tostring(stk), fx + 7, y + 7)
          UI.ink("none")
          gfx.setColor(BLACK)
        end
      else
        drawT("NEW CAFE", 88, y + 13, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if sel and not CAFE.erase then CAFE.pointer(316, y + 24) end            -- the mouse arrow rests on the chosen save
    end
    if art then
      local hint = "B: back      Right: erase"                               -- on a little sticker plate at the bottom
      gfx.setFont(fontNormal)
      local hw = math.min(gfx.getTextSize(hint) + 28, 330)
      UI.stickerBox(200 - math.floor(hw / (2)), 206, hw, 22, false)
      drawTC(hint, 200, 209)
    else
      drawTC("B: back      Right: erase", 200, 208)
    end
    if CAFE.erase then
      local bx, by, bw, bh = 66, 58, 268, 124
      gfx.setColor(WHITE)
      gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14)
      gfx.setColor(BLACK)
      CAFE.wobbleBox(bx, by, bw, bh)                        -- squiggly edge
      drawTC("Are you sure you want to", 200, by + 22)
      if CAFE.delW == nil then                              -- the letters of "delete", measured once
        gfx.setFont(fontBold)
        CAFE.delW, CAFE.delTotal = {}, 0
        for i = 1, 6 do
          CAFE.delW[i] = (gfx.getTextSize(string.sub("delete", i, i)))
          CAFE.delTotal = CAFE.delTotal + CAFE.delW[i]
        end
        gfx.setFont(fontNormal)
        CAFE.delRest = (gfx.getTextSize(" this save file?"))
      end
      local x0 = 200 - math.floor((CAFE.delTotal + CAFE.delRest) / (2))
      local lx = x0
      for i = 1, 6 do                                       -- "delete" in bold, every letter wiggling
        drawT(string.sub("delete", i, i), lx, by + 42 + math.floor(math.sin(frames * 0.4 + i * 0.9) * 2 + 0.5), true)
        lx = lx + CAFE.delW[i]
      end
      drawT(" this save file?", lx, by + 42)
      for i = 1, 2 do                                       -- Delete and Cancel, each a button
        local x = (i == 1) and 86 or 206
        local on = (CAFE.eraseSel == i)
        gfx.setColor(BLACK)
        if on then
          gfx.fillRoundRect(x, by + 74, 108, 28, 8)
          gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
        else
          gfx.setLineWidth(2); gfx.drawRoundRect(x, by + 74, 108, 28, 8); gfx.setLineWidth(1)
        end
        drawTC(i == 1 and "Delete" or "Cancel", x + 54, by + 81, true)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        gfx.setColor(BLACK)
        if on then CAFE.pointer(x + 80, by + 94) end         -- the mouse arrow rests on the chosen button
      end
    end
  elseif CAFE.mode == "char" and UI.bgSet("char") then
    UI.bgSet("char")[frames % UI.TITLE_N + 1]:draw(0, 0)
    UI.drawCharNew()
  elseif CAFE.mode == "char" then
    UI.beanFrame()
    CAFE.band("PICK YOUR BARISTA")
    gfx.setColor(BLACK)
    CAFE.charImgs = CAFE.charImgs or {}
    for i = 1, 3 do
      local bx = 40 + (i - 1) * 112
      local on = (CAFE.charSel == i)
      gfx.setColor(WHITE); gfx.fillRoundRect(bx, 52, 96, 120, 10)
      gfx.setColor(BLACK)
      gfx.setLineWidth(on and 4 or 2)
      gfx.drawRoundRect(bx, 52, 96, 120, 10)
      gfx.setLineWidth(1)
      local im = CAFE.charImgs[i]
      if im == nil then
        im = gfx.image.new(40, 40, gfx.kColorClear)
        gfx.pushContext(im)
        drawPerson(20, 14, UI.BARISTA[i], false, 2)
        gfx.popContext()
        CAFE.charImgs[i] = im
      end
      im:drawScaled(bx + 8, 62, 2.0)
      if on then CAFE.pointer(bx + 62, 150) end
    end
    gfx.setColor(BLACK)
  elseif CAFE.mode == "name" and UI.bgSet("name") then
    UI.bgSet("name")[frames % UI.TITLE_N + 1]:draw(0, 0)
    UI.drawNameNew()
  elseif CAFE.mode == "name" then
    UI.beanFrame()
    CAFE.band("NAME YOUR CAFE")
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(64, 42, 272, 38, 8)
    gfx.setLineWidth(1)
    gfx.setFont(fontBold)
    local w = gfx.getTextSize(CAFE.name)
    local x0 = 200 - math.floor((w + 10) / (2))
    drawT(CAFE.name, x0, 52, true)
    if (math.floor(frames / (10))) % 2 == 0 and #CAFE.name < CAFE.NAME_MAX then gfx.fillRect(x0 + w + 2, 70, 9, 3) end
    -- the letter wheel (A-Z, the word CAFE, a space), then DONE below it
    local lc = (CAFE.letter == 26) and "CAFE" or ((CAFE.letter == 27) and "space" or string.char(65 + CAFE.letter))
    gfx.setColor(BLACK)
    gfx.fillTriangle(140, 102, 140, 126, 128, 114)           -- left and right turn the wheel
    gfx.fillTriangle(260, 102, 260, 126, 272, 114)
    local dialOn = not CAFE.onDone
    if not dialOn then gfx.setLineWidth(2); gfx.drawRoundRect(150, 96, 100, 36, 8); gfx.setLineWidth(1)
    else gfx.fillRoundRect(150, 96, 100, 36, 8) end
    gfx.setImageDrawMode(dialOn and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC(lc, 200, 106, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if CAFE.onDone then gfx.fillRoundRect(150, 152, 100, 28, 8) else gfx.setLineWidth(2); gfx.drawRoundRect(150, 152, 100, 28, 8); gfx.setLineWidth(1) end
    gfx.setImageDrawMode(CAFE.onDone and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC("DONE", 200, 158, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)

  else
    -- the shop is a web page: address bar on top, tabs, a list of links, a bar of buttons below
    local shopBg = UI.shopBgImg()
    if shopBg then
      shopBg:draw(0, 0)                                      -- the dark backdrop, the white sheet, address bar and bottom bar: one picture
      UI.drawShopBeans()                                     -- (three beans in the corner, drifting up and down)
    else
      gfx.setColor(WHITE)
      gfx.fillRoundRect(8, 4, 384, 24, 12)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(8, 4, 384, 24, 12)
      gfx.setLineWidth(1)
      -- back / forward arrows
      gfx.fillTriangle(14, 16, 22, 10, 22, 22)
      gfx.fillTriangle(38, 16, 30, 10, 30, 22)
      gfx.setLineWidth(2)                                    -- refresh: a circle of arrow
      for a = 40, 320, 20 do
        local r1, r2 = math.rad(a), math.rad(a + 20)
        gfx.drawLine(math.floor(56 + math.cos(r1) * 6 + 0.5), math.floor(16 + math.sin(r1) * 6 + 0.5),
                     math.floor(56 + math.cos(r2) * 6 + 0.5), math.floor(16 + math.sin(r2) * 6 + 0.5))
      end
      gfx.setLineWidth(1)
      gfx.fillTriangle(56 + 6, 16 - 7, 56 + 6, 16 + 1, 56 + 13, 16 - 2)
      gfx.drawCircleAtPoint(82, 16, 7)                       -- globe
      gfx.drawEllipseInRect(79, 9, 6, 14)
      gfx.drawLine(75, 16, 89, 16)

    end
    UI.urlBar()
    gfx.setColor(BLACK)
    UI.ink("chrome")                                        -- (PC: black words on the yellow strip)
    CAFE.drawShopMsg()                                      -- the line under the address bar: a new message every 6 seconds
    UI.ink("none")
    -- the tabs: a strip that slides round, kept to the left of the preview picture
    gfx.setClipRect(8, 45, 280, 21)
    do
      local n = #CAFE.TABS
      for ti, name in ipairs(CAFE.TABS) do
        local dd = (ti - CAFE.tabPos + n / 2) % n - n / 2         -- -3 .. 3 tabs away from the middle
        local tx = math.floor(148 + dd * 76 - 36)
        if tx > -80 and tx < 300 then
          UI.ink(CAFE.TABINK[ti])                         -- (PC: every tab its own colour)
          gfx.setColor(BLACK)
          local on = (ti == CAFE.tab)
          if on then
            if shopBg then gfx.setColor(WHITE); gfx.fillRoundRect(tx - 1, 46, 74, 19, 6); gfx.setColor(BLACK) end
            gfx.fillRoundRect(tx, 47, 72, 17, 5)
            gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
          else
            gfx.setColor(WHITE); gfx.fillRoundRect(tx, 47, 72, 17, 5); gfx.setColor(BLACK)
            gfx.drawRoundRect(tx, 47, 72, 17, 5)
          end
          local cx1, cx2 = math.max(tx, 8), math.min(tx + 72, 288)          -- the letters are cut off at the bottom edge of their tab (so the tail of a "g" doesn't poke out)
          if cx2 > cx1 then
            gfx.setClipRect(cx1, 47, cx2 - cx1, 17)
            if not on then UI.ink("chrome") end               -- (PC: black words on the other tabs)
            local bold = on
            if bold then gfx.setFont(fontBold); if gfx.getTextSize(name) > 68 then bold = false end end     -- (a long name like "Wallpaper" stays in plain letters so it fits)
            drawTC(name, tx + 36, 48, bold)
            UI.ink(CAFE.TABINK[ti])
            gfx.setClipRect(8, 45, 280, 21)
          end
          gfx.setImageDrawMode(gfx.kDrawModeCopy)
        end
      end
    end
    gfx.clearClipRect()
    UI.ink("none")
    gfx.setColor(BLACK)
    if CAFE.focus == "tabs" then CAFE.pointer(148 + 16, 51) end             -- the mouse rests on the chosen tab
    -- the bar along the bottom: stars on the left, two buttons, money on the right
    if not shopBg then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(8, 212, 384, 24, 12)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(8, 212, 384, 24, 12)
      gfx.setLineWidth(1)
    end
    CAFE.drawStars(26, 224, 5, 11, CAFE.cur.stars, BLACK, UI.lvl(CAFE.cur))
    CAFE.shopBtns = CAFE.shopBtns or { { "back", "Back to cafe", 82, 112 }, { "quit", "Save & quit", 198, 102 } }
    for bi = 1, 2 do
      local bn = CAFE.shopBtns[bi]
      UI.ink(CAFE.TABINK[CAFE.tab])
      gfx.setColor(BLACK)
      local on = (CAFE.focus == bn[1])
      UI.shopButton(bn[3], bn[4], bn[2], bn[1], on)
      if on then CAFE.pointer(bn[3] + bn[4] - 14, 221) end
    end
    gfx.setColor(BLACK)
    if CAFE.moneyShown ~= CAFE.cur.money then CAFE.moneyShown = CAFE.cur.money; CAFE.moneyStr = money(CAFE.cur.money) end
    UI.ink("inkgreen")
    drawTR(CAFE.moneyStr, 381, 217, true)
    local rows = CAFE.rows()
    if CAFE.tab == CAFE.SALE_TAB then UI.ink(CAFE.TABINK[CAFE.tab]); UI.saleTimerRow(69); UI.ink("none") end
    for vi = 1, CAFE.visRows() do
      local i = CAFE.scroll + vi
      local row = rows[i]
      if row == nil then break end
      UI.ink(CAFE.TABINK[CAFE.tab])                       -- (PC: the rows take the colour of their tab)
      local y = CAFE.rowY(vi)                              -- (the sheet's white part runs y 68 to 208: rows 19 tall keep a pixel clear at the top and the bottom)
      gfx.setColor(BLACK)
      local sel = (CAFE.focus == "list" and CAFE.shopSel == i)
      local ind = row.more and 22 or 0                     -- "Buy another" hangs under its item: pushed in, with an elbow joining it to the item above
      if row.more then
        gfx.setLineWidth(2)
        gfx.drawLine(18, y - 1, 18, y + 9); gfx.drawLine(18, y + 9, 10 + ind - 1, y + 9)
        gfx.setLineWidth(1)
      end
      if sel then
        gfx.fillRoundRect(10 + ind, y, 273 - ind, 19, 5)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(10 + ind, y, 273 - ind, 19, 5)   -- every choice is a button with a border
      end
      local nameTxt, stickerX = CAFE.rowName(row[1], row[2], row[7])
      if not sel then UI.ink("chrome") end                 -- (PC: the words are black; the chosen row keeps white words on its colour)
      drawT(nameTxt, 20 + ind, y + 1)
      UI.ink(CAFE.TABINK[CAFE.tab])
      if row[7] then                                       -- how much is off (solid for half price, outlined for the rest)
        UI.saleSticker(stickerX, y + 1, row[7], sel and WHITE or BLACK, sel and BLACK or WHITE)
        gfx.setColor(BLACK)
      end
      if not sel then UI.ink("chrome") end
      if row[2] ~= "" then drawTR(row[2], 275, y + 2, true) end
      UI.ink(CAFE.TABINK[CAFE.tab])
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if sel then                                          -- the mouse pointer, resting on the choice
        gfx.setFont(fontNormal)
        CAFE.pointer(20 + ind + math.min(gfx.getTextSize(row[1]) * 0.6, 150), y + 7)
      end
    end
    UI.ink("none")
    CAFE.drawPreview(rows[CAFE.shopSel])
    UI.ink(CAFE.TABINK[CAFE.tab])
    -- a scroll bar down the right of the list: the thumb slides as you move
    do
      UI.ink("chrome")                                          -- (PC: scroll bars are black)
      local tx, ty, th = 285, 68, 138
      gfx.setColor(BLACK)
      gfx.drawRoundRect(tx, ty, 7, th, 3)
      local n = #rows
      local thumb = (n <= CAFE.visRows()) and th or math.max(14, math.floor(th * CAFE.visRows() / n))
      local pos = (n <= 1) and 0 or (CAFE.shopSel - 1) / (n - 1)
      if CAFE.focus == "tabs" then pos = 0 elseif CAFE.focus ~= "list" then pos = 1 end
      gfx.fillRoundRect(tx, ty + math.floor((th - thumb) * pos + 0.5), 7, thumb, 3)
    end
    UI.ink("none")
    local bmsg = CAFE.msg
    local hrow = rows[CAFE.shopSel]
    local hint = false
    local onRow = CAFE.focus == "list" and hrow and CAFE.shopSel > CAFE.scroll and CAFE.shopSel <= CAFE.scroll + CAFE.visRows()
    if not bmsg and onRow and ((hrow.multi and not hrow.more) or (hrow.layout and (CAFE.cur.seatStep or 0) >= 1)) then
      local what = hrow.layout and "table layout" or "item layout"
      bmsg, hint = UI.color and ("Hold Enter or right-click to edit " .. what) or ("Hold A to edit " .. what), true    -- (an owned piece: the same bubble that says "Bought!", while you rest on it)
    end
    if bmsg then
      local bx0, bw0 = 20, 254                               -- (over the list, clear of the picture and its words)
      local ml = CAFE.fitLines(bmsg, bw0 - 16, true, 4)
      local mh = 4 + 16 * #ml
      local by0 = 204 - mh
      if onRow then                                          -- keep it off the row you are on (and the "Buy another" row under it)
        local sy = CAFE.rowY(CAFE.shopSel - CAFE.scroll)
        local ry = sy + ((hrow.multi and not hrow.more) and 40 or 20)
        if ry > by0 then by0 = 71 end
        if by0 == 71 and sy < 71 + mh then by0 = 204 - mh end
      end
      gfx.setColor(WHITE)
      gfx.fillRoundRect(bx0, by0, bw0, mh, 6)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(bx0, by0, bw0, mh, 6)
      for li = 1, #ml do drawTC(ml[li], bx0 + math.floor(bw0 / (2)), by0 + 2 + (li - 1) * 16, true) end
    end
    if CAFE.note then
      local bx, by, bw, bh = 70, 62, 260, 112
      gfx.setColor(WHITE)
      if shopBg then gfx.fillRoundRect(bx + 2, by + 2, bw - 4, bh - 4, 10) else gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14) end
      gfx.setColor(BLACK)
      CAFE.wobbleBox(bx, by, bw, bh)
      drawTC(CAFE.fitOne(CAFE.note[1], 236, true), 200, by + 14, true)
      drawTC(CAFE.fitOne(CAFE.note[2], 236, false), 200, by + 40)
      drawTC(CAFE.fitOne(CAFE.note[3], 236, false), 200, by + 58)
      gfx.setColor(BLACK)
      gfx.fillRoundRect(200 - 36, by + 80, 72, 24, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      drawTC("OK", 200, by + 85, true)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      CAFE.pointer(200 + 20, by + 98)
    end
    if CAFE.ask then UI.askDraw() end
    if CAFE.rank then UI.rankDraw() end
  end
  gfx.setColor(BLACK)
end


-- System menu (the Menu button): jump back to the title screen
-- (the Cafe hides this item: there you only get End shift / Save & quit)
function UI.setTitleItem(on)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if on and UI.titleItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Title screen", function()
        if state ~= STATE_MENU then goTitle() end
      end)
    end)
    if ok then UI.titleItem = item end
  elseif (not on) and UI.titleItem ~= nil then
    pcall(function() menu:removeMenuItem(UI.titleItem) end)
    UI.titleItem = nil
  end
end
UI.setTitleItem(false)

-- the fade to black and back that covers every change of screen
local fadeImg = nil
do
  local ok, img = pcall(function() return gfx.image.new(400, 240, BLACK) end)
  if ok then fadeImg = img end
end

function UI.drawFade()
  if trans == nil then return end
  local k = clamp(trans.t / trans.dur, 0, 1)
  local a = (trans.phase == "out") and k or (1 - k)
  if a <= 0.02 then return end
  if a >= 0.98 then
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 400, 240)
    return
  end
  if fadeImg then
    fadeImg:drawFaded(0, 0, a, gfx.image.kDitherTypeBayer8x8)
    return
  end
  gfx.setColor(BLACK)                       -- fallback: a coarse checker fade
  if a > 0.3 then gfx.setPattern(CHECK) end
  if a > 0.3 then gfx.fillRect(0, 0, 400, 240) end
  gfx.setColor(BLACK)
end

function UI.anyButton()                         -- is a button being pressed?
  return pd.buttonIsPressed(pd.kButtonUp) or pd.buttonIsPressed(pd.kButtonDown) or pd.buttonIsPressed(pd.kButtonLeft) or pd.buttonIsPressed(pd.kButtonRight)
      or pd.buttonIsPressed(pd.kButtonA) or pd.buttonIsPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
      or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) or pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB)
end

UI.SEASON_TUNES = { hmus = { "skeleton", "haunted" }, xmus = { "skating", "snowfall" } }       -- the two records in the shop's Music tab and their tracks

function UI.pickTune(exclude)                   -- a random tune from the playlist, not the one just played (nor the one before it)
  local pl = UI.mus.list or UI.POOL
  local list = {}
  for _, n in ipairs(pl) do
    local r = UI.mus.recent
    if not UI.badTunes[n] and n ~= exclude and n ~= r[1] and n ~= r[2] then list[#list + 1] = n end
  end
  if #list == 0 then
    for _, n in ipairs(pl) do if not UI.badTunes[n] and n ~= exclude then list[#list + 1] = n end end
  end
  if #list == 0 then
    for _, n in ipairs(pl) do if not UI.badTunes[n] then list[#list + 1] = n end end         -- (a playlist of one: it goes round again)
  end
  if #list == 0 then return nil end
  return list[math.random(#list)]
end

function UI.freeTune(name)                      -- let a tune go (its memory comes back once the garbage is collected, which waits for a quiet moment)
  local p = UI.tunes[name]
  if p then pcall(function() p:stop() end); UI.tunes[name] = nil; UI.mus.gc = true end
end

function UI.inList(name, list)
  for _, n in ipairs(list) do if n == name then return true end end
  return false
end

function UI.musicStart(name, ctx)               -- play a tune once, twice or three times round, and choose the one that will follow it
  for _ = 1, 3 do
    local p = name and UI.tune(name)
    if p then
      local plays = weighted({ 40, 40, 20 }) + 1
      pcall(function() p:stop(); p:play(plays) end)
      local m = UI.mus
      local again = (name == m.cur)
      m.cur, m.t0, m.ctx = name, frames, ctx or m.ctx
      if not again then m.recent = { name, m.recent[1] } end
      local old = m.pick
      if again and old and old ~= name and not UI.badTunes[old] and UI.inList(old, m.list or UI.POOL) then
        return                                  -- (the same tune again, back from the settings or the shop: the one lined up after it stays, loaded or not)
      end
      m.pick = UI.pickTune(name)
      if old and old ~= m.pick and old ~= name then UI.freeTune(old) end      -- (a tune that was lined up and is not any more)
      return
    end
    name = UI.pickTune(name)                    -- (that one would not load: try another)
  end
end

function UI.musicSwitch(want, ctx, list, lkey)  -- a different kind of music is wanted: stop what plays and start the right thing
  local m = UI.mus
  if m.cur and UI.tunes[m.cur] then pcall(function() UI.tunes[m.cur]:stop() end) end
  if UI.tunes.shop then pcall(function() UI.tunes.shop:stop() end) end
  if UI.tunes.rush then pcall(function() UI.tunes.rush:stop() end) end
  if want == "shop" then
    if UI.tunes.shop then pcall(function() UI.tunes.shop:play(0) end) end
  elseif want == "rush" then                    -- Rush Hour has a tune of its own (90 seconds, looped); the playlist's tunes make room for it
    if m.cur then UI.freeTune(m.cur) end
    if m.pick then UI.freeTune(m.pick) end
    m.cur, m.pick = nil, nil
    local p = UI.tune("rush")
    if p then pcall(function() p:play(0) end) end
  elseif want == "pool" then
    UI.freeTune("rush")
    list = list or UI.POOL
    local same = (m.ctx == ctx and m.lkey == lkey)
    m.list, m.lkey = list, lkey
    if m.cur and UI.tunes[m.cur] and same and UI.inList(m.cur, list) then      -- (back from the shop: the same tune again)
      UI.musicStart(m.cur, ctx)
    else                                                        -- (a new place, or other tunes switched on: a new random tune, the one lined up if it is loaded and still on the list)
      local nx = (m.pick and UI.tunes[m.pick] and UI.inList(m.pick, list)) and m.pick or nil
      if m.cur and m.cur ~= nx then UI.freeTune(m.cur) end
      if m.pick and m.pick ~= nx then UI.freeTune(m.pick) end
      m.cur, m.pick = nil, nil
      UI.musicStart(nx or UI.pickTune(nil), ctx)
      m.lkey = lkey
    end
  end
end

function UI.musicQuiet()                        -- a moment when loading a tune would not be noticed: nothing pressed for a second, and no screen fade going
  if trans ~= nil then return false end           -- (a fade that stalls while a tune loads is just the hitch you would notice)
  if state == STATE_PLAY and G ~= nil and G.st ~= nil then return false end
  return frames - (UI.lastBtn or 0) >= 30
end

UI.SLISTS = {}                                  -- the playlists for each mix of records, made once
function UI.musicList()                         -- which tunes the title screen, cafe and Evening Chill choose from, and what they are called
  local cafe = nil
  if state == STATE_PLAY and G ~= nil and G.mode == "cafe" then cafe = CAFE.cur
  elseif state == CAFE.STATE and G ~= nil and (CAFE.mode == "place" or CAFE.mode == "layout" or CAFE.mode == "edit") then cafe = CAFE.cur end
  local d = cafe and cafe.decor
  local h, x = d and d.hmus == "on", d and d.xmus == "on"
  if h or x then                                -- the cafe's own music: only the records that are bought and switched on
    local key = h and (x and "HX" or "H") or "X"
    local list = UI.SLISTS[key]
    if not list then
      list = {}
      if h then for _, n in ipairs(UI.SEASON_TUNES.hmus) do list[#list + 1] = n end end
      if x then for _, n in ipairs(UI.SEASON_TUNES.xmus) do list[#list + 1] = n end end
      UI.SLISTS[key] = list
    end
    return list, key
  end
  return UI.POOL, ""
end

function UI.musicTick()                         -- title screen, cafe, Evening Chill: random tunes. Rush Hour: its own. The website: its own
  if UI.anyButton() then UI.lastBtn = frames end
  local want, ctx, list, lkey = "none", nil, nil, ""
  if UI.musicOn then
    if (state == CAFE.STATE and CAFE.mode == "shop") or (state == STATE_MENU and UI.settings ~= nil) then want = "shop"
    elseif (state == STATE_PLAY or state == STATE_ENTRY) and G ~= nil and G.mode == "rush" then want = "rush"
    else
      want = "pool"
      ctx = ((state == STATE_PLAY or state == STATE_ENTRY) and G ~= nil) and "shift" or "menus"
      list, lkey = UI.musicList()
    end
  end
  local key = want .. (ctx or "") .. lkey
  if key ~= UI.musicNow then
    UI.musicNow = key
    UI.musicSwitch(want, ctx, list, lkey)
    return
  end
  if want == "shop" or want == "rush" then
    if frames % 90 == 0 then                    -- (safety net: a tune that somehow ended starts again)
      local p = UI.tunes[want]
      if p then pcall(function() if not p:isPlaying() then p:play(0) end end) end
    end
  elseif want == "pool" then
    local m = UI.mus
    if frames % 6 == 0 then
      local p = m.cur and UI.tunes[m.cur]
      if p and not p:isPlaying() then           -- the tune has run its course: on to the next, or round again if that is not loaded yet
        local nx = m.pick
        if nx and nx ~= m.cur and UI.tunes[nx] then UI.freeTune(m.cur); UI.musicStart(nx) else UI.musicStart(m.cur) end
      elseif not p and UI.musicNow ~= nil then  -- (nothing playing at all: start something)
        UI.musicStart(UI.pickTune(nil))
      end
    end
    if m.pick and not UI.tunes[m.pick] and frames - (m.t0 or 0) > 240 then   -- (load the next tune in a quiet moment, or anyway if it has not come by the time the tune is nearly through)
      if UI.musicQuiet() or frames - (m.t0 or 0) > 1500 then UI.tune(m.pick) end
    end
  end
  UI.mus.gc = false                                -- (streamed tunes hold almost no memory, so there's no big clean-up to do: that was a hitch)
end

----------------------------------------------------------------------
-- Barista levels, the star meter, order grades, the daily gift, achievements
----------------------------------------------------------------------
UI.hudTimeX = 6                                              -- (PC: moved over to make room for the phone)
function UI.noWait() return CAFE.rich() or (G ~= nil and G.mode == "chill") end      -- (Evening Chill: nobody runs out of patience, no meters)
function UI.lvl(d)                                           -- the barista level of a cafe (1 until its first prestige)
  d = d or (G and G.cafe) or CAFE.cur
  return math.max(1, math.floor(tonumber(d and d.lvl) or 1))
end
function UI.decorCount(d, owned)                             -- how much decor is out (or owned, out or not)
  local n = 0
  for _, v in pairs(d.decor or {}) do if v == "on" or (owned and v == "off") then n = n + 1 end end
  return n
end
function UI.decorReview(d) return 1 + math.min(0.5, 0.0125 * UI.decorCount(d)) end    -- a cosier cafe gets warmer reviews
function UI.lvlTipPct(lv)                                     -- how much bigger tips are at a barista level: +5% a level, up to +40%
  lv = math.max(1, math.floor(lv))
  return math.min(40, 5 * (lv - 1))
end
function UI.lvlSlowPct(lv)                                    -- how much slower customers lose patience at a barista level: 5% a level, up to 50%
  lv = math.max(1, math.floor(lv))
  return math.min(50, 5 * (lv - 1))
end
function UI.tipMult(d)                                       -- Cafe tips: higher barista levels tip better
  local lv = UI.lvl(d)
  local m = 1 + UI.lvlTipPct(lv) / 100                                                -- (decor doesn't change tips: it fills the star meter faster, see UI.decorReview)
  if (tonumber(d.boostT) or 0) > 0 then m = m * 2 end                                -- (the daily gift's tip boost)
  return m
end

-- ---- the little save shared by all three cafes: achievements, their counters, the daily gift ----
function UI.meta()
  local m = UI.metaT
  if m then return m end
  local ok, d = pcall(pd.datastore.read, "meta")
  if not ok or type(d) ~= "table" then d = {} end
  if type(d.got) ~= "table" then d.got = {} end
  if type(d.n) ~= "table" then d.n = {} end
  UI.metaT = d
  return d
end
function UI.metaSave() pcall(pd.datastore.write, UI.meta(), "meta") end
-- Each save file has its own Cafe achievements (kept in the save: d.ach); Rush Hour's are shared (kept in "meta").
UI.RUSHK = { rushes = true, rushbest = true, combo = true }
function UI.prof(d)                                          -- a cafe's own achievements and counters
  if type(d.ach) ~= "table" then d.ach = {} end
  if type(d.ach.got) ~= "table" then d.ach.got = {} end
  if type(d.ach.n) ~= "table" then d.ach.n = {} end
  return d.ach
end
function UI.inCafe() return CAFE.cur ~= nil and (state == CAFE.STATE or (G ~= nil and G.mode == "cafe")) end
function UI.storeFor(k)                                      -- where a counter lives (nil: it doesn't count here, e.g. dishes in Evening Chill)
  if UI.RUSHK[k] then return UI.meta() end
  if UI.inCafe() then return UI.prof(CAFE.cur) end
  return nil
end
function UI.stat(k, st) st = st or UI.storeFor(k); return st and tonumber(st.n[k]) or 0 end
function UI.statAdd(k, v) local st = UI.storeFor(k); if st then st.n[k] = (tonumber(st.n[k]) or 0) + v end end
function UI.statMax(k, v) local st = UI.storeFor(k); if st and v > (tonumber(st.n[k]) or 0) then st.n[k] = v end end
function UI.flag(k) local st = UI.storeFor(k); if st then st.n[k] = 1 end end
function UI.migrate(d)                                       -- (6.9 / 7.0 kept the Cafe achievements in one shared list: the first cafe opened after the update gets them)
  local m = UI.meta()
  if m.moved then return end
  local pr = UI.prof(d)
  for _, a in ipairs(UI.ACH) do if a[2] == 1 and m.got[a[1]] then pr.got[a[1]] = true end end
  for k, v in pairs(m.n) do
    if not UI.RUSHK[k] and (tonumber(v) or 0) > (tonumber(pr.n[k]) or 0) then pr.n[k] = v end
  end
  if m.day and not pr.day then pr.day, pr.streak = m.day, m.streak end
  m.moved = true
  UI.metaSave()
end

-- ---- achievements: { id, tab (1 Cafe, 2 Rush Hour), name, what to do, the counter, its goal } ----
UI.ACH = {
  { "first", 1, "First Pour", "Serve your first Cafe order", "served", 1 },
  { "serve100", 1, "Busy Morning", "Serve 100 Cafe orders", "served", 100 },
  { "serve500", 1, "Packed House", "Serve 500 Cafe orders", "served", 500 },
  { "serve1000", 1, "Coffee Machine", "Serve 1,000 Cafe orders", "served", 1000 },
  { "perfect10", 1, "Steady Hands", "10 perfect orders in a row", "pbest", 10 },
  { "perfect20", 1, "In the Zone", "20 perfect orders in a row", "pbest", 20 },
  { "perfect30", 1, "Barista Brain", "30 perfect orders in a row", "pbest", 30 },
  { "perfect40", 1, "Crema de la Crema", "40 perfect orders in a row", "pbest", 40 },
  { "perfect50", 1, "Flawless", "50 perfect orders in a row", "pbest", 50 },
  { "star1", 1, "Rising Star", "Earn your first full star", "starmax", 1 },
  { "star5", 1, "Five-Star Cafe", "Reach 5 out of 5 stars", "starmax", 5 },
  { "lv2", 1, "Fresh Start", "Prestige once (Barista Lv 2)", "lvl", 2 },
  { "lv4", 1, "Bean There", "Prestige 3 times (Barista Lv 4)", "lvl", 4 },
  { "lv6", 1, "Master Roaster", "Prestige 5 times (Barista Lv 6)", "lvl", 6 },
  { "lv11", 1, "Coffee Legend", "Prestige 10 times (Barista Lv 11)", "lvl", 11 },
  { "booth", 1, "Full House", "Get the corner booth (15 seats)", "seats", 5 },
  { "decor10", 1, "Decorator", "Own 10 decorations", "decor", 10 },
  { "decor40", 1, "Interior Designer", "Own 40 decorations", "decor", 40 },
  { "decor80", 1, "Showroom", "Own 80 decorations", "decor", 80 },
  { "pet", 1, "Best Friend", "Adopt your first pet", "pets", 1 },
  { "zoo", 1, "Petting Zoo", "A cat, a dog and a turtle out at once", "zoo", 1 },
  { "style", 1, "Dressed to Impress", "Wear a hat and glasses together", "style", 1 },
  { "spooky", 1, "Spooky Season", "Open with the Halloween music on", "spooky", 1 },
  { "jolly", 1, "Holly Jolly", "Open with the Christmas music on", "jolly", 1 },
  { "gift", 1, "Surprise!", "Open your first daily gift", "gifts", 1 },
  { "gift3", 1, "Coming Back", "Open daily gifts 3 days in a row", "gstreak", 3 },
  { "gift7", 1, "Loyal Barista", "Open daily gifts 7 days in a row", "gstreak", 7 },
  { "gift14", 1, "Two Week Regular", "Open daily gifts 14 days in a row", "gstreak", 14 },
  { "gift30", 1, "Coffee Every Day", "Open daily gifts 30 days in a row", "gstreak", 30 },
  { "flash", 1, "Bargain Hunter", "Buy something in a Flash Sale", "flash", 1 },
  { "spend", 1, "Big Spender", "Spend $1,000 in the shop", "spent", 100000 },
  { "tips", 1, "Tip Jar Hero", "Earn $50 in tips in one shift", "tipshift", 5000 },
  { "iced", 1, "Ice Ice Baby", "Serve 50 iced drinks", "iced", 50 },
  { "season", 1, "Seasonal Sipper", "Serve 25 Pumpkin Spice or Hot Cocoa", "season", 25 },
  { "speedy", 1, "Lightning Hands", "Serve 25 orders lightning fast", "speedy", 25 },
  { "suds", 1, "Squeaky Clean", "Wash 100 cups", "washed", 100 },
  { "bigtip", 1, "Big Tipper", "Get a $4 tip on one order", "bigtip", 400 },
  { "fashion", 1, "Fashion Icon", "Own 15 hats and glasses", "clothes", 15 },
  { "rugs", 1, "Rug Collector", "Own 10 rugs", "rugs", 10 },
  { "parade", 1, "Pet Parade", "A cat, a dog, a turtle and a bunny out at once", "parade", 1 },
  { "flock", 1, "Birds of a Feather", "Have a parrot and an owl out at once", "flock", 1 },
  { "rush1", 2, "Clocked In", "Finish a Rush Hour", "rushes", 1 },
  { "rush10", 2, "Rush Regular", "Finish 10 Rush Hours", "rushes", 10 },
  { "combo2", 2, "Combo Starter", "Reach a x2 combo", "combo", 5 },
  { "combo3", 2, "Combo King", "Reach the top x3 combo", "combo", 9 },
  { "rush40", 2, "Rush Pro", "Score $40 in one Rush Hour", "rushbest", 4000 },
  { "rush70", 2, "Rush Legend", "Score $70 in one Rush Hour", "rushbest", 7000 },
}
UI.ACH_TABS = { "CAFE", "RUSH HOUR" }
UI.achQ = {}                                                 -- unlocked, waiting to be shown
UI.achOwner = setmetatable({}, { __mode = "k" })           -- (which cafe a list of achievements belongs to)
function UI.achProgress(a, st)                               -- how far along (for counters that are worth showing as "7/10")
  local v = UI.stat(a[5], st)
  if a[5] == "pbest" then                                    -- perfect orders in a row: the run you're on now (a slip starts it again at 0)
    local d = UI.achOwner and UI.achOwner[st]
    if not d and CAFE.cur and CAFE.cur.ach == st then d = CAFE.cur end
    if d then v = math.max(0, math.floor(tonumber(d.pstreak) or 0)) end
  end
  if a[5] == "spent" or a[5] == "tipshift" or a[5] == "rushbest" or a[5] == "bigtip" then return nil end
  if a[6] <= 1 then return nil end
  return math.floor(math.min(v, a[6])), a[6]                -- (whole numbers: saved counters can come back as 7.0)
end
function UI.achCheck()                                       -- anything newly earned is unlocked (and shown)
  local d = UI.inCafe() and CAFE.cur or nil
  if d and d.decor then                                      -- (the counters that come straight from the cafe you're in)
    UI.statMax("seats", d.seatStep or 0)
    UI.statMax("decor", UI.decorCount(d, true))
    UI.statMax("lvl", UI.lvl(d))
    UI.statMax("starmax", math.floor((d.stars or 0) + 0.001))
    local pets, kinds = 0, {}
    for _, it in ipairs(CAFE.ITEMS) do
      if it.species and d.decor[it.id] ~= nil then pets = pets + 1 end
      if it.species and d.decor[it.id] == "on" then kinds[it.species] = true end
    end
    UI.statMax("pets", pets)
    if kinds.cat and kinds.dog and kinds.turtle then UI.flag("zoo") end
    if kinds.cat and kinds.dog and kinds.turtle and kinds.bunny then UI.flag("parade") end
    local clothes, rugs, parrot, owl = 0, 0, false, false
    for _, it in ipairs(CAFE.ITEMS) do
      local v = d.decor[it.id]
      if v ~= nil then
        if it.kind == "hat" or it.kind == "glasses" then clothes = clothes + 1 end
        if it.kind == "rug" or it.kind == "orug" or it.kind == "runner" then rugs = rugs + 1 end
        if v == "on" and it.bird == "parrot" then parrot = true elseif v == "on" and it.bird == "owl" then owl = true end
      end
    end
    UI.statMax("clothes", clothes)
    UI.statMax("rugs", rugs)
    if parrot and owl then UI.flag("flock") end
    local hat, glass = false, false
    for id, v in pairs(d.decor) do
      if v == "on" then
        local it = CAFE.byId[id]
        if it and it.kind == "hat" then hat = true elseif it and it.kind == "glasses" then glass = true end
      end
    end
    if hat and glass then UI.flag("style") end
  end
  local m, pr = UI.meta(), d and UI.prof(d) or nil
  local anyM, anyP = false, false
  for _, a in ipairs(UI.ACH) do
    local st = (a[2] == 2) and m or pr
    if st and not st.got[a[1]] and UI.stat(a[5], st) >= a[6] then
      st.got[a[1]] = true
      UI.achQ[#UI.achQ + 1] = { a = a, t = 0 }
      if st == m then anyM = true else anyP = true end
    end
  end
  if anyM then UI.metaSave() end
  if anyP and CAFE.slot then pcall(pd.datastore.write, d, "cafe" .. CAFE.slot) end      -- (kept safe in the save right away)
end
function UI.achCount(tab, st)
  local got, all = 0, 0
  for _, a in ipairs(UI.ACH) do
    if a[2] == tab then all = all + 1; if st and st.got[a[1]] then got = got + 1 end end
  end
  return got, all
end
function UI.shiftStartAch(d)                                 -- a Cafe shift is starting
  if d.decor.hmus == "on" then UI.flag("spooky") end
  if d.decor.xmus == "on" then UI.flag("jolly") end
  UI.achCheck()
end

-- the trophy: a cup with two handles on a little stand (cx, cy = middle), ink on bg
function UI.trophy(cx, cy, ink, bg, shine)
  gfx.setColor(ink)
  gfx.fillRoundRect(cx - 6, cy - 8, 13, 9, 3)                -- the cup
  gfx.fillRect(cx - 6, cy - 8, 13, 4)
  gfx.drawCircleAtPoint(cx - 7, cy - 4, 3)                   -- handles
  gfx.drawCircleAtPoint(cx + 7, cy - 4, 3)
  gfx.fillRect(cx - 1, cy + 1, 3, 3)                         -- stem
  gfx.fillRoundRect(cx - 5, cy + 4, 11, 4, 1)                -- base
  gfx.setColor(bg)
  gfx.fillRect(cx - 6, cy - 4, 13, 1)                        -- a band round the cup
  gfx.drawPixel(cx - 3, cy - 7); gfx.drawPixel(cx - 3, cy - 6)   -- a glint
  gfx.fillRect(cx - 3, cy + 5, 7, 1)
  if shine then                                              -- a sparkle that winks
    local k = (math.floor(frames / (3))) % 10
    if k < 4 then
      gfx.setColor(ink)
      local sx, sy = cx + 9, cy - 10
      gfx.drawLine(sx - k, sy, sx + k, sy); gfx.drawLine(sx, sy - k, sx, sy + k)
    end
  end
  gfx.setColor(BLACK)
end
function UI.lock(cx, cy, ink)                                -- a padlock
  gfx.setColor(ink)
  gfx.drawRoundRect(cx - 4, cy - 8, 9, 9, 4)
  gfx.drawRoundRect(cx - 3, cy - 7, 7, 8, 3)
  gfx.fillRoundRect(cx - 6, cy - 3, 13, 10, 2)
  gfx.setColor(ink == BLACK and WHITE or BLACK)
  gfx.fillRect(cx, cy, 1, 4)
  gfx.drawPixel(cx - 1, cy + 1); gfx.drawPixel(cx + 1, cy + 1)
  gfx.setColor(BLACK)
end

-- ---- the popup when one is earned: it drops in at the top, rests, and slides away ----
function UI.achHold() return CAFE.rank ~= nil or (state == CAFE.STATE and CAFE.mode == "scratch") end   -- (an achievement waits until the rank-up show and a scratch-off are over)
function UI.achTick(dt)
  if UI.achHold() then return end
  local q = UI.achQ[1]
  if not q then return end
  if q.t == 0 then                                           -- a little fanfare
    if sfx.achieve then sfxPlay("achieve", false, 1.0)
    else
      play(synthSine, 1047, 0.10, 0.30); play(synthSine, 1319, 0.10, 0.30, 0.09)
      play(synthSine, 1568, 0.10, 0.30, 0.18); play(synthSine, 2093, 0.25, 0.30, 0.27)
    end
  end
  q.t = q.t + dt
  if q.life == nil then q.life = (#UI.achQ > 1) and 2.0 or 3.2 end         -- (a few at once: each one is quicker)
  if q.t >= q.life then table.remove(UI.achQ, 1) end
end
function UI.achDraw()
  if UI.achHold() then return end
  local q = UI.achQ[1]
  if not q then return end
  local t = q.t
  local life = q.life or 3.2
  local k
  if t < 0.35 then k = 1 - (1 - t / 0.35) ^ 3                -- (eases in)
  elseif t > life - 0.4 then k = 1 - ((t - life + 0.4) / 0.4) ^ 2
  else k = 1 end
  local w, h = 268, 36
  local top = (state == STATE_PLAY) and 22 or 4             -- (in a shift it sits under the top bar, so the stars stay in view)
  local x, y = 200 - math.floor(w / (2)), math.floor(-h - 4 + (h + 4 + top) * k)
  UI.ink("achpop")
  gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y - 2, w + 4, h + 4, 11)
  gfx.setColor(BLACK); gfx.fillRoundRect(x, y, w, h, 9)
  gfx.setColor(WHITE); gfx.drawRoundRect(x + 3, y + 3, w - 6, h - 6, 7)
  UI.trophy(x + 22, y + 19, WHITE, BLACK, true)
  gfx.setColor(WHITE)
  UI.pixText("ACHIEVEMENT UNLOCKED", x + 40, y + 7)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(CAFE.fitOne(q.a[3], w - 52, true), x + 40, y + 16, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if t < 1.2 then                                            -- confetti specks off its corners
    gfx.setColor(WHITE)
    for i = 1, 6 do
      local a = i * 1.05 + 0.3
      local r = 6 + t * 40
      gfx.fillRect(math.floor(x + (i % 2 == 0 and w or 0) + math.cos(a) * r), math.floor(y + h / 2 + math.sin(a) * r * 0.6), 2, 2)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- the Achievements screen (the trophy box on the title screen) ----
function UI.achViews(inGame)                                -- whose achievements can be looked at: each save file's Cafe ones, then Rush Hour
  local v = {}
  if inGame then
    v[1] = { label = CAFE.cafeName(), tab = 1, st = UI.prof(CAFE.cur) }
  else
    local pre = CAFE.pre
    for i = 1, 3 do
      local d
      if pre and pre.n >= i then d = pre[i] or nil else d = CAFE.read(i) end
      if d then v[#v + 1] = { label = d.name or ("CAFE " .. i), tab = 1, st = UI.prof(d), slot = i }; UI.achOwner[v[#v].st] = d end
    end
    if #v == 0 then v[1] = { label = "NO CAFE YET", tab = 1, st = nil } end
  end
  v[#v + 1] = { label = "RUSH HOUR", tab = 2, st = UI.meta() }
  return v
end
function UI.openAch(inGame)
  sfxClick()
  UI.fast(function()
    UI.ach = { view = 1, sel = 1, scroll = 0, crank = 0, views = UI.achViews(inGame), inGame = inGame }
    if not inGame and CAFE.slot then                          -- (start on the save you played last)
      for k, vw in ipairs(UI.ach.views) do if vw.slot == CAFE.slot then UI.ach.view = k end end
    end
    UI.bgSet("achieve")
  end)
end
function UI.openAchInGame()                                   -- from the Menu button during a Cafe shift
  if state == STATE_PLAY and G ~= nil and G.mode == "cafe" and not G.ending and UI.ach == nil and trans == nil then
    closeStation()
    UI.openAch(true)
  end
end
function UI.achList(tab)
  local out = {}
  for _, a in ipairs(UI.ACH) do if a[2] == tab then out[#out + 1] = a end end
  return out
end
UI.ACH_ROWS = 4
UI.ACH_RH = 38                                               -- the height of one row in the list
function UI.updateAch()
  local s = UI.ach
  local vw = s.views[s.view]
  local list = UI.achList(vw.tab)
  local step = 0
  s.crank = s.crank + pd.getCrankChange()
  if s.crank >= 60 then s.crank = s.crank - 60; step = 1 elseif s.crank <= -60 then s.crank = s.crank + 60; step = -1 end
  if pd.buttonJustPressed(pd.kButtonDown) then step = 1 elseif pd.buttonJustPressed(pd.kButtonUp) then step = -1 end
  if step ~= 0 then
    local n = clamp(s.sel + step, 1, #list)
    if n ~= s.sel then s.sel = n; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    local n = #s.views
    s.view = (s.view - 1 + (pd.buttonJustPressed(pd.kButtonRight) and 1 or -1)) % n + 1
    s.sel, s.scroll = 1, 0; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
    sfxClick(); UI.fast(function() UI.ach = nil end)
  end
  if s.sel <= s.scroll then s.scroll = s.sel - 1 end
  if s.sel > s.scroll + UI.ACH_ROWS then s.scroll = s.sel - UI.ACH_ROWS end
end
function UI.drawAch()
  local s = UI.ach
  local art = UI.bgSet("achieve")
  if art then art[frames % UI.TITLE_N + 1]:draw(0, 0)
  else UI.beanFrame(); CAFE.band("ACHIEVEMENTS") end
  -- whose achievements: a plate with the cafe's name (or Rush Hour), arrows either side, a dot for each page
  local vw = s.views[s.view]
  local got0, all0 = UI.achCount(vw.tab, vw.st)
  local label = string.upper(vw.label) .. "   " .. got0 .. "/" .. all0
  local lw = math.max(UI.pixWidth(label) + 24, 150)
  local lx = 200 - math.floor(lw / (2))
  UI.ink("achtab")
  UI.stickerBox(lx, 44, lw, 18, true)
  gfx.setColor(WHITE)
  UI.pixText(label, 200 - math.floor(UI.pixWidth(label) / (2)), 50)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if #s.views > 1 then
    local nud = (math.floor(frames / (8))) % 2
    for side = -1, 1, 2 do                                       -- the arrows: left / right for the next one
      local ax = 200 + side * (math.floor(lw / (2)) + 10 + nud)
      gfx.setColor(BLACK); gfx.fillTriangle(ax + side * 7, 53, ax - side * 2, 45, ax - side * 2, 61)
      gfx.setColor(WHITE); gfx.fillTriangle(ax + side * 5, 53, ax - side * 1, 48, ax - side * 1, 58)
    end
    for k = 1, #s.views do                                       -- the page dots, under the plate
      local dx = 200 - (#s.views - 1) * 4 + (k - 1) * 8
      gfx.setColor(BLACK); gfx.fillCircleAtPoint(dx, 67, 2)
      gfx.setColor(WHITE); if k == s.view then gfx.fillCircleAtPoint(dx, 67, 2) else gfx.drawPixel(dx, 67) end
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  do                                                             -- how to go back: a little plate in the corner
    gfx.setFont(fontNormal)
    local hint = "B: back"
    local hw = gfx.getTextSize(hint) + 14
    UI.ink("m_high")
    UI.stickerBox(24, 45, hw, 17, false)
    drawT(hint, 31, 45)
    UI.ink("none")
    gfx.setColor(BLACK)
  end
  -- the list: a white card, one row per achievement
  local px, py, pw, ph = 22, 71, 356, 160
  gfx.setColor(BLACK); gfx.fillRoundRect(px + 3, py + 3, pw, ph, 8)
  UI.ink("achcard")
  gfx.setColor(WHITE); gfx.fillRoundRect(px, py, pw, ph, 8)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(px, py, pw, ph, 8); gfx.setLineWidth(1)
  UI.ink("none")
  local list = UI.achList(vw.tab)
  local got = vw.st and vw.st.got or {}
  gfx.setFont(fontBold); local _, hB = gfx.getTextSize("Ag")
  gfx.setFont(fontNormal); local _, hN = gfx.getTextSize("Ag")
  local RH = UI.ACH_RH
  local textH = hB + hN - 3                                                    -- the name and the line under it, as one block...
  local ty0 = math.floor((RH - 2 - textH) / 2)                                 -- ...centred in the row
  for vi = 1, UI.ACH_ROWS do
    local i = s.scroll + vi
    local a = list[i]
    if a == nil then break end
    local y = py + 4 + (vi - 1) * RH
    local sel = s.sel == i
    local done = got[a[1]] == true
    UI.ink(sel and "achtab" or (done and "achgot" or "achlock"))
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(px + 4, y, pw - 18, RH - 2, 7)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    elseif vi > 1 and s.sel ~= i - 1 then
      for xx = px + 12, px + pw - 22, 4 do gfx.drawPixel(xx, y - 2) end     -- dotted line between rows
    end
    local fg, bgc = sel and WHITE or BLACK, sel and BLACK or WHITE
    -- the badge tile: a trophy once done, a padlock until then (centred in the row)
    local tyc = y + math.floor((RH - 2) / 2)
    if done then
      UI.ink(sel and "gold2" or "achgot")
      gfx.setColor(fg); gfx.fillRoundRect(px + 9, tyc - 12, 24, 24, 5)
      UI.ink(sel and "gold2" or "gold2")
      UI.trophy(px + 21, tyc, bgc, fg, sel)
      UI.ink(sel and "achtab" or "achgot")
    else
      gfx.setColor(fg); gfx.drawRoundRect(px + 9, tyc - 12, 24, 24, 5)
      UI.lock(px + 21, tyc, fg)
    end
    gfx.setImageDrawMode(sel and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    local cur, goal = UI.achProgress(a, vw.st)
    local right = done and "DONE" or (cur and (cur .. "/" .. goal) or "")
    local rw = (right ~= "") and (math.max(UI.pixWidth(right), 36) + 10) or 0
    local nm = CAFE.fitOne(a[3], pw - 70 - rw, true)
    drawT(nm, px + 40, y + ty0, true)
    drawT(CAFE.fitOne(a[4], pw - 70 - rw, false), px + 40, y + ty0 + hB - 3)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    if right ~= "" then
      gfx.setColor(fg)
      local rx = px + pw - 22
      if cur and not done then                                                 -- how far along: the count, and a little bar under it
        UI.pixText(right, rx - UI.pixWidth(right), tyc - 8)
        local bw = 36
        gfx.drawRoundRect(rx - bw, tyc + 2, bw, 6, 2)
        local f = math.floor((bw - 4) * math.min(cur, goal) / goal + 0.5)
        UI.ink(sel and "achtab" or "achbar")
        if f > 0 then gfx.fillRect(rx - bw + 2, tyc + 4, f, 2) end
        UI.ink(sel and "achtab" or "achlock")
      else
        UI.pixText(right, rx - UI.pixWidth(right), tyc - 3)
      end
    end
    UI.ink("none")
    gfx.setColor(BLACK)
    if sel then gfx.setFont(fontBold); CAFE.pointer(px + 46 + gfx.getTextSize(nm), y + ty0 + 3) end
  end
  -- a slim scroll bar down the right edge of the card
  local n = #list
  local tx, ty, th = px + pw - 10, py + 6, ph - 12
  UI.ink("chrome")                                              -- (PC: scroll bars are black)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(tx, ty, 5, th, 2)
  local thumb = (n <= UI.ACH_ROWS) and th or math.max(12, math.floor(th * UI.ACH_ROWS / n))
  local pos = (n <= 1) and 0 or (s.sel - 1) / (n - 1)
  gfx.fillRoundRect(tx, ty + math.floor((th - thumb) * pos + 0.5), 5, thumb, 2)
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- the daily gift (once a day, after midnight by the Playdate's clock, the first time you open a cafe) ----
function UI.dayNum(y, m, d)                                  -- days since 1 Jan 1970, from a calendar date
  if m <= 2 then y = y - 1 end
  local era = math.floor(y / 400)
  local yoe = y - era * 400
  local doy = math.floor((153 * ((m + 9) % 12) + 2) / 5) + d - 1
  local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
  return era * 146097 + doe - 719468
end
function UI.today()
  local ok, t = pcall(pd.getTime)
  if not ok or type(t) ~= "table" or not t.year then return nil end
  return UI.dayNum(t.year, t.month, t.day)
end
function UI.giftReady(d)                                     -- (each save file gets its own gift every day)
  local day = UI.today()
  d = d or CAFE.cur
  return day ~= nil and d ~= nil and tonumber(UI.prof(d).day) ~= day
end
UI.GIFTS = {
  tips = { "Tip Boost!", "Double tips for", "5 minutes of your shift" },
  stars = { "Review Boost!", "Reviews fill your star", "meter twice as fast for 5 min" },
  flash = { "FLASH SALE!", "Everything on sale is 50% off", "until the deals change" },
}
UI.GIFTSHORT = { tips = "Double tips for 5 minutes", stars = "Double reviews for 5 minutes", flash = "Everything on sale is 50% off" }
UI.GIFT_READ = 3                                 -- (the prize stays up this long before it can be closed, so it gets read)
function UI.giftStreakNow(d)                               -- the run of days a save has opened its gift (0 once a day is missed)
  local pr, day = UI.prof(d), UI.today()
  local last = tonumber(pr.day)
  if not (day and last) or day - last > 1 then return 0 end
  return math.floor(tonumber(pr.streak) or 0)
end
UI.GIFT_HOLD = 0.8                               -- (Playdate: how long A is held to open the gift)
function UI.giftUpdate(dt)
  local g = CAFE.gift
  WIN.updateWindow(dt)
  g.t = g.t + dt
  g.life = (g.life or 0) + dt
  for _, q in ipairs(g.conf or {}) do q.vy = q.vy + 260 * dt; q.vx = q.vx * (1 - dt * 1.5); q.x = q.x + q.vx * dt; q.y = q.y + q.vy * dt end
  if g.phase == "box" then                                        -- (it has to be opened: no "later")
    if UI.color then                                              -- PC: Enter / a tap of Space / a click, or holding Space
      g.crank = (g.crank or 0) + math.abs(pd.getCrankChange())
      if (pd.buttonJustPressed(pd.kButtonA) and g.t > 0.4) or g.crank >= 120 then UI.giftOpen() end
    else                                                          -- Playdate: hold A (the crank does nothing here); the box shakes harder as you hold
      if pd.buttonIsPressed(pd.kButtonA) and g.t > 0.4 then g.hold = (g.hold or 0) + dt
      else g.hold = math.max(0, (g.hold or 0) - dt * 2) end
      g.crank = math.min(1, (g.hold or 0) / UI.GIFT_HOLD) * 120
      if (g.hold or 0) >= UI.GIFT_HOLD then UI.giftOpen() end
    end
  else
    local ch = math.abs(pd.getCrankChange())
    if ch == 0 then g.let = true end                              -- (PC: Space has to be let go first, so holding it from opening the box doesn't skip this)
    if g.t < UI.GIFT_READ then return end
    local goA = pd.buttonJustPressed(pd.kButtonA) or (UI.color and g.let and ch > 0)
    if #(g.tix or {}) > 0 then                                    -- a scratch-off: A scratches it now, B keeps it for later (in the shop's Stuff tab)
      if goA then sfxClick(); UI.giftScratch()
      elseif pd.buttonJustPressed(pd.kButtonB) then CAFE.gift = nil; sfxClick() end
    elseif goA or pd.buttonJustPressed(pd.kButtonB) then
      CAFE.gift = nil
      sfxClick()
    end
  end
end
function UI.giftScratch()                                         -- scratch the gift's ticket right away (one already half done comes first)
  local g, d = CAFE.gift, CAFE.cur
  CAFE.gift = nil
  if not d then return end
  if not d.scratch then
    local tier = g.tix[1]
    local fk = CAFE.FREEK[tier]
    if (tonumber(d[fk]) or 0) > 0 then d[fk] = tonumber(d[fk]) - 1; d.scratch = CAFE.scratchMake(tier); CAFE.allC = nil; CAFE.write() end
  end
  if d.scratch then CAFE.scrBack = CAFE.mode; UI.fast(function() CAFE.scratchOpen() end) end
end
function UI.giftOpen()
  local g, d = CAFE.gift, CAFE.cur
  local m = UI.prof(d)
  local day = UI.today() or 0
  local streak = (tonumber(m.day) == day - 1) and (math.floor(tonumber(m.streak) or 0) + 1) or 1
  local roll = math.random()                                      -- a boost, a free scratch-off, or now and then both
  local hasBuff, hasTix = (roll < 0.55) or (roll >= 0.80), roll >= 0.55
  local kind, tix = nil, {}
  if hasBuff then
    local r = math.random()
    kind = (r < 0.10) and "flash" or ((r < 0.55) and "tips" or "stars")
    if kind == "tips" then d.boostT = (tonumber(d.boostT) or 0) + 300
    elseif kind == "stars" then d.boostS = (tonumber(d.boostS) or 0) + 300
    else
      if not CAFE.sale then CAFE.rollSale() end
      if CAFE.sale then CAFE.sale.flash = true end
    end
  end
  if hasTix then local t = math.random(); tix[#tix + 1] = (t < 0.70) and 1 or ((t < 0.95) and 2 or 3) end
  local week = (streak % 7 == 0)                                  -- every 7th day in a row: a free Golden Bean as well
  if week then table.insert(tix, 1, 3) end
  for _, tier in ipairs(tix) do local fk = CAFE.FREEK[tier]; d[fk] = (tonumber(d[fk]) or 0) + 1 end
  CAFE.allC = nil
  m.day, m.streak = day, streak
  UI.statAdd("gifts", 1)
  UI.statMax("gstreak", streak)
  g.phase, g.t, g.kind, g.streak, g.tix, g.week = "open", 0, kind, streak, tix, week
  g.conf = {}
  for i = 1, 30 do                                                 -- a burst of confetti from the present
    local a = -math.pi / 2 + (math.random() - 0.5) * 2.4
    local v = 90 + math.random() * 110
    g.conf[i] = { x = 200, y = 96, vx = math.cos(a) * v, vy = math.sin(a) * v, k = i % 5, w = (i % 3 == 0) and 3 or 2 }
  end
  sfxPlay("tip", false, 1.0)
  play(synthSine, 1319, 0.08, 0.3, 0.05); play(synthSine, 1760, 0.18, 0.3, 0.13)
  CAFE.write()
  UI.metaSave()
  UI.achCheck()
end
UI.BIGDOLLAR = { "....k....", "..kkkkk..", ".kk.k.kk.", ".kk.k....", ".kk.k....", "..kkkkk..", "....k.kk.", "....k.kk.", ".kk.k.kk.", "..kkkkk..", "....k...." }
function UI.giftBox(cx, cy, open)                          -- a present: a box with a ribbon and a bow
  local w, h = 44, 30
  gfx.setColor(BLACK); gfx.fillRect(cx - math.floor(w / (2)) + 3, cy - 9, w, h + 3)          -- shadow
  UI.ink("giftbox")
  gfx.setColor(WHITE); gfx.fillRect(cx - math.floor(w / (2)), cy - 12, w, h)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRect(cx - math.floor(w / (2)), cy - 12, w, h); gfx.setLineWidth(1)
  UI.ink("giftrib")
  gfx.setColor(BLACK); gfx.fillRect(cx - 3, cy - 12, 7, h)                                   -- ribbon down the front
  local ly = open and (cy - 30) or (cy - 18)
  local tilt = open and 6 or 0
  UI.ink("giftbox")
  gfx.setColor(WHITE); gfx.fillRect(cx - math.floor(w / (2)) - 3 + tilt, ly, w + 6, 8)           -- the lid
  gfx.setColor(BLACK); gfx.drawRect(cx - math.floor(w / (2)) - 3 + tilt, ly, w + 6, 8)
  UI.ink("giftrib")
  gfx.setColor(BLACK); gfx.fillRect(cx - 3 + tilt, ly, 7, 8)
  gfx.drawEllipseInRect(cx - 13 + tilt, ly - 8, 12, 9); gfx.drawEllipseInRect(cx + 2 + tilt, ly - 8, 12, 9)   -- the bow
  gfx.drawEllipseInRect(cx - 12 + tilt, ly - 7, 10, 7); gfx.drawEllipseInRect(cx + 3 + tilt, ly - 7, 10, 7)
  gfx.fillRect(cx - 2 + tilt, ly - 4, 5, 5)
  UI.ink("none")
  gfx.setColor(BLACK)
end
function UI.dimScreen()                                     -- darken whatever is behind (a fine checker, see-through)
  if UI.dimImg == nil then
    UI.dimImg = gfx.image.new(400, 240, gfx.kColorWhite)
    gfx.pushContext(UI.dimImg)
    gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(0, 0, 400, 240)
    gfx.popContext()
  end
  gfx.setImageDrawMode(gfx.kDrawModeWhiteTransparent)
  UI.dimImg:draw(0, 0)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end
function UI.streakRow(cx, y, n, fresh)                       -- the week: seven little cups, one filled for each day in a row
  local shown = ((n - 1) % 7) + 1
  local t = CAFE.gift and CAFE.gift.t or 9
  for k = 1, 7 do
    local x = cx - 45 + (k - 1) * 15
    local on = k <= shown and (not fresh or t > 0.25 + k * 0.08)      -- (after opening, they fill in one by one)
    local pop = (fresh and k == shown) and math.floor(math.max(0, 2 - CAFE.gift.t * 6)) or 0
    UI.ink((k == 7) and "gold2" or (on and "inkorange" or "none"))
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 5 - pop, y - 5 - pop, 11 + pop * 2, 11 + pop * 2, 3)
    if k == 7 then gfx.drawRoundRect(x - 6 - pop, y - 6 - pop, 13 + pop * 2, 13 + pop * 2, 4) end    -- (the 7th day: a Golden Bean ticket, so its box is bigger)
    if on then gfx.fillRoundRect(x - 3, y - 3, 7, 7, 2)
    elseif k == 7 then gfx.drawPixel(x, y - 2); gfx.fillRect(x - 1, y - 1, 3, 3); gfx.drawPixel(x, y + 2); gfx.drawPixel(x - 2, y); gfx.drawPixel(x + 2, y) end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end
function UI.giftDraw()
  local g = CAFE.gift
  UI.dimScreen()
  local life = g.life or 1
  local drop = 0
  if life < 0.45 then                                              -- the card drops in from the top and bounces
    local k = life / 0.45
    drop = math.floor(-240 * (1 - k) * (1 - k) + math.sin(k * math.pi) * 10 * (1 - k) + 0.5)
  end
  gfx.setDrawOffset(0, drop)
  local bx, by, bw, bh = 56, 22, 288, 198
  gfx.setColor(BLACK); gfx.fillRoundRect(bx + 4, by + 5, bw, bh, 14)               -- the card, with a shadow
  UI.ink("giftcard")
  gfx.setColor(WHITE); gfx.fillRoundRect(bx, by, bw, bh, 14)
  gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(bx, by, bw, bh, 14); gfx.setLineWidth(1)
  for xx = bx + 12, bx + bw - 12, 4 do gfx.drawPixel(xx, by + 7); gfx.drawPixel(xx, by + bh - 8) end   -- a stitched edge
  UI.ink("none")
  local streakNext = (g.phase == "box") and ((tonumber(UI.prof(CAFE.cur).day) == (UI.today() or 0) - 1) and (UI.giftStreakNow(CAFE.cur) + 1) or 1) or (g.streak or 1)
  if g.phase == "box" then
    UI.ink("giftrib")
    UI.fancyText("Daily Gift!", 200, by + 14, 0.55, 250, nil, UI.FX_RAINBOW)
    UI.ink("none")
    local shake = math.min(1, (g.crank or 0) / 120)
    local cyc = g.t % 1.6                                            -- every so often it hops and rattles, as if something's inside
    local hop = (cyc < 0.3) and math.floor(math.sin(cyc / 0.3 * math.pi) * 7 + 0.5) or 0
    local bob = math.floor(math.sin(g.t * 5) * 2 + 0.5) - hop
    local wig = math.floor(math.sin(g.t * 34) * (((cyc < 0.3) and 2 or 0) + shake * 4))
    if UI.giftImg == nil then UI.giftImg = gfx.image.new(70, 64, gfx.kColorClear) end
    UI.giftImg:clear(gfx.kColorClear)
    gfx.pushContext(UI.giftImg); UI.giftBox(35, 44, false); gfx.popContext()
    UI.giftImg:drawScaled(200 - 70 + wig, by + 46 + bob - 26, 2)                  -- the present, twice the size, bobbing (shaking as you crank)
    for k = 0, 5 do                                                               -- sparkles twinkling round it
      local ph = (math.floor(frames / (5)) + k * 2) % 8
      local r = (ph < 4) and ph or 7 - ph
      local a = k * 1.05 + 0.4
      local sx, sy = math.floor(200 + math.cos(a) * 66), math.floor(by + 92 + math.sin(a) * 40)
      gfx.setColor(BLACK); gfx.drawLine(sx - r, sy, sx + r, sy); gfx.drawLine(sx, sy - r, sx, sy + r)
    end
    UI.streakRow(200, by + 156, streakNext, false)
    local lbl = (streakNext % 7 == 0) and ("DAY " .. streakNext .. ": FREE GOLDEN BEAN!") or ((streakNext >= 2) and ("DAY " .. streakNext .. " IN A ROW") or "DAY 1")
    UI.pixText(lbl, 200 - math.floor(UI.pixWidth(lbl) / (2)), by + 166)
    local hint = UI.color and "Click or press SPACE to open!" or "Hold A to open!"
    gfx.setFont(fontBold)
    local hw = gfx.getTextSize(hint) + 20
    gfx.setColor(BLACK); gfx.fillRoundRect(200 - math.floor(hw / (2)), by + bh - 24, hw, 19, 8)
    local hp = math.min(1, (g.hold or 0) / UI.GIFT_HOLD)          -- (Playdate: a line fills along the bottom of the pill while A is held)
    if hp > 0 then gfx.setColor(WHITE); gfx.fillRect(200 - math.floor(hw / (2)) + 6, by + bh - 9, math.floor((hw - 12) * hp), 2); gfx.setColor(BLACK) end
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC(hint, 200, by + bh - 23, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  else
    local tix = g.tix or {}
    local info = g.kind and UI.GIFTS[g.kind]
    local head = g.week and "7 Day Streak!" or (info and info[1] or "Scratch-off!")
    UI.ink(g.week and "gold2" or (g.kind == "flash" and "inkred" or (g.kind == "tips" and "gperfect" or (g.kind == "stars" and "ggreat" or "inkorange"))))
    UI.fancyText(head, 200, by + 14, 0.6, 250, nil, g.week and UI.FX_RAINBOW or (UI.FX_GIFT[g.kind] or UI.FX_RAINBOW))
    UI.ink("none")
    local pt = math.min(1, g.t / 0.35)                                -- the prize pops up bigger than it is, then settles
    local pop = pt < 1 and (pt * (1 + 0.35 * math.sin(pt * math.pi))) or 1
    local cy = by + 74 + math.floor(math.sin(g.t * 3) * 2 + 0.5)
    local items = {}                                                  -- what's in the present: the boost, then the tickets
    if g.kind then items[#items + 1] = "buff" end
    for k = 1, math.min(2, #tix) do items[#items + 1] = tix[k] end
    local gap = (#items >= 3) and 88 or 92
    local x0 = 200 - math.floor((#items - 1) * gap / 2)
    if #items == 1 and g.kind then
      gfx.setColor(BLACK)                                             -- rays turning slowly behind the prize
      for k = 0, 11 do
        local a = k * math.pi / 6 + g.t * 0.6
        gfx.drawLine(math.floor(200 + math.cos(a) * 24), math.floor(cy + math.sin(a) * 20), math.floor(200 + math.cos(a) * (30 + (k % 2) * 6)), math.floor(cy + math.sin(a) * (25 + (k % 2) * 5)))
      end
    end
    for n, it in ipairs(items) do
      local cx = x0 + (n - 1) * gap
      if it ~= "buff" then                                            -- a scratch-off ticket
        if pop >= 1 then UI.scratchPreview(cx, cy, it) end
      elseif g.kind == "tips" then                                    -- a big coin
        UI.ink("gold2")
        gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, math.floor(18 * pop))
        gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, math.floor(15 * pop))
        gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy, math.floor(11 * pop))
        UI.ink("none")
        if pop >= 1 then UI.ink("gold2"); gfx.setColor(BLACK); CAFE.runPic(UI.BIGDOLLAR, cx - 4, cy - 5, 1); UI.ink("none") end   -- (a drawn $, exactly in the middle of the coin)
      elseif g.kind == "stars" then
        UI.ink("star")
        CAFE.star(cx, cy, math.max(1, math.floor(16 * pop)), 1, BLACK)
        UI.ink("none")
      else
        UI.ink("a12")
        if pop >= 1 then UI.saleSticker(cx - 30, cy - 8, 50, BLACK, WHITE) end
        UI.ink("none")
      end
    end
    local function tname(t) return CAFE.SCR[t].name end
    local l1, l2
    local other = nil                                                 -- (the ticket that isn't the 7th day's)
    for k = (g.week and 2 or 1), #tix do other = other or tix[k] end
    if #items == 1 and g.kind then l1, l2 = info[2], info[3]
    elseif #items == 1 then l1, l2 = "A free " .. tname(tix[1]) .. " ticket!", "Scratch it now, or keep it for later"
    else
      l1 = g.kind and UI.GIFTSHORT[g.kind] or ("A free " .. tname(other) .. " ticket!")
      if g.week and g.kind and other then l2 = "+ free " .. tname(other) .. " & Golden Bean!"
      elseif g.week then l2 = "7 days in a row: a free Golden Bean!"
      else l2 = "+ a free " .. tname(other) .. " ticket!" end
    end
    drawTC(CAFE.fitOne(l1, 270, false), 200, by + 104)
    drawTC(CAFE.fitOne(l2, 270, false), 200, by + 120)
    UI.streakRow(200, by + 148, g.streak or 1, true)
    local lbl = ((g.streak or 1) >= 2) and ("DAY " .. g.streak .. " IN A ROW!") or "DAY 1 - COME BACK TOMORROW!"
    UI.ink("inkorange")
    UI.pixTextCycle(lbl, 200 - math.floor(UI.pixWidth(lbl) / (2)), by + 158, UI.FX_STREAK)
    UI.ink("none")
    for _, q in ipairs(g.conf or {}) do                                          -- confetti
      if q.y < 240 then
        UI.ink(({ "redp", "yellow", "skyp", "leaf", "rose" })[q.k + 1])
        gfx.setColor(BLACK); gfx.fillRect(math.floor(q.x), math.floor(q.y), q.w, (q.w == 3) and 1 or 2)
      end
    end
    UI.ink("none")
    local hint
    if #tix > 0 then hint = UI.color and "SPACE: scratch it now    X: later" or "A: scratch it now    B: later"
    else hint = UI.color and "Press SPACE to go on" or "A: let's go!" end
    gfx.setFont(fontBold)
    local hw = gfx.getTextSize(hint) + 20
    local hx = 200 - math.floor(hw / (2))
    gfx.setColor(BLACK); gfx.fillRoundRect(hx, by + bh - 24, hw, 19, 8)
    local rd = g.t / UI.GIFT_READ
    if rd < 1 then                                                    -- (a moment to read it first: a line fills the pill, then it says how to go on)
      gfx.setColor(WHITE); gfx.fillRect(hx + 8, by + bh - 16, math.floor((hw - 16) * rd), 3)
      gfx.drawRect(hx + 7, by + bh - 17, hw - 14, 5)
    else
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      drawTC(hint, 200, by + bh - 23, true)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
    end
  end
  gfx.setDrawOffset(0, 0)
  gfx.setColor(BLACK)
end

-- ---- grades: after every Cafe order a sticker pops up, then flies into the star meter ----
UI.GRADES = { { "PERFECT!", 0.95, 0.06, "gperfect" }, { "GREAT!", 0.85, 0.045, "ggreat" }, { "GOOD", 0.75, 0.03, "ggood" },
              { "OKAY", 0.5, 0, "gokay" }, { "OOPS!", -1, 0, "goops" } }
UI.STAMP_T = 1.3
function UI.gradeOf(q)
  for i, g in ipairs(UI.GRADES) do if q >= g[2] then return i end end
  return #UI.GRADES
end
function UI.review(c, q)                                     -- the customer's review: it moves the star meter
  local d = G.cafe
  local gi = UI.gradeOf(q)
  local before = d.stars
  if gi == 5 then CAFE.mistake(0.3)
  elseif UI.GRADES[gi][3] > 0 then
    local gain = (UI.GRADES[gi][3] + 0.02 * CAFE.petCount()) * UI.decorReview(d) / math.min(3, 1 + 0.2 * (UI.lvl(d) - 1))
    if (tonumber(d.boostS) or 0) > 0 then gain = gain * 2 end                    -- (the daily gift's review boost)
    CAFE.addStars(gain)
  end
  d.pstreak = (gi == 1) and ((tonumber(d.pstreak) or 0) + 1) or 0
  UI.statAdd("served", 1)
  UI.statMax("pbest", d.pstreak)
  if before < 5 and d.stars >= 5 then G.fiveT = UI.STAMP_T + 0.4 end            -- (once the sticker lands: tell them about prestige)
  G.stamp = { g = gi, t = 0 }
  G.meterHold = UI.STAMP_T - 0.05
  UI.achCheck()
end
function UI.stampImg(gi)
  UI.stampImgs = UI.stampImgs or {}
  local im = UI.stampImgs[gi]
  if im then return im end
  local g = UI.GRADES[gi]
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(g[1])
  local w, h = tw + 40, 30
  im = gfx.image.new(w, h, gfx.kColorClear)
  gfx.pushContext(im)
  UI.ink(g[4])
  gfx.setColor(BLACK); gfx.fillRoundRect(0, 0, w, h, 11)
  gfx.setColor(WHITE); gfx.fillRoundRect(2, 2, w - 4, h - 4, 9)
  gfx.setColor(BLACK)
  for xx = 8, w - 9, 3 do gfx.drawPixel(xx, 5); gfx.drawPixel(xx, h - 6) end      -- a stitched edge
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  drawTC(g[1], math.floor(w / (2)), 7, true)
  if gi <= 2 then CAFE.star(11, 15, 4, 1, BLACK); CAFE.star(w - 12, 15, 4, 1, BLACK)
  elseif gi == 3 then gfx.fillCircleAtPoint(11, 15, 3); gfx.fillCircleAtPoint(w - 12, 15, 3)
  else gfx.drawCircleAtPoint(11, 15, 3); gfx.drawCircleAtPoint(w - 12, 15, 3) end
  UI.ink("none")
  gfx.popContext()
  UI.stampImgs[gi] = im
  return im
end
UI.METER_X, UI.METER_Y, UI.METER_W = 234, 5, 36
function UI.drawStamp()
  local s = G and G.stamp
  if not s then return end
  local im = UI.stampImg(s.g)
  local w, h = im:getSize()
  local t = s.t
  local x, y, sc = 200, 152, 2
  if t < 0.14 then sc = 0.6 + 1.8 * (t / 0.14)                    -- it slaps down a bit big...
  elseif t < 0.24 then sc = 2.4 - 0.4 * ((t - 0.14) / 0.1)         -- ...settles...
  elseif t >= 0.85 then                                            -- ...then shrinks away into the star meter
    local k = math.min(1, (t - 0.85) / (UI.STAMP_T - 0.85))
    local e = k * k
    x = 200 + (UI.METER_X + math.floor(UI.METER_W / (2)) - 200) * e
    y = 152 + (UI.METER_Y + 4 - 152) * e
    sc = 2 - 1.85 * e
  end
  if sc == 2 then im:drawScaled(math.floor(x - w), math.floor(y - h), 2)
  else im:drawScaled(math.floor(x - w * sc / 2), math.floor(y - h * sc / 2), sc) end
end
function UI.playTick(dt)                                     -- (Cafe shifts) the meter, the sticker, the boosts
  local d = G.cafe
  if not d then return end
  if G.meterV == nil then G.meterV = d.stars end
  local s = G.stamp
  if s then
    s.t = s.t + dt
    if s.t >= UI.STAMP_T then G.stamp = nil; G.spark = 0.45 end
  end
  if G.spark then G.spark = G.spark - dt; if G.spark <= 0 then G.spark = nil end end
  if G.starPop then G.starPop.t = G.starPop.t + dt; if G.starPop.t > 0.9 then G.starPop = nil end end
  if (G.meterHold or 0) > 0 then G.meterHold = G.meterHold - dt
  else
    local diff = d.stars - G.meterV
    if math.abs(diff) < 0.003 then G.meterV = d.stars
    else
      local old = G.meterV
      local stepv = diff * math.min(1, dt * 3)
      if math.abs(stepv) < dt * 0.04 then stepv = (diff > 0 and 1 or -1) * math.min(math.abs(diff), dt * 0.04) end
      G.meterV = old + stepv
      if math.floor(G.meterV + 0.001) > math.floor(old + 0.001) then G.starPop = { i = math.floor(G.meterV + 0.001), t = 0 }; sfxGood() end
    end
  end
  if G.fiveT then
    G.fiveT = G.fiveT - dt
    if G.fiveT <= 0 then G.fiveT = nil; say("5 stars! Prestige in the shop's Cafe tab") end
  end
  for _, k in ipairs({ "boostT", "boostS" }) do               -- the daily gift's boosts run down while you play
    local v = tonumber(d[k])
    if v then
      v = v - dt
      if v <= 0 then d[k] = nil; say(k == "boostT" and "Tip boost is over" or "Review boost is over") else d[k] = v end
    end
  end
  UI.statMax("tipshift", G.tips or 0)
  G.achT = (G.achT or 0) - dt
  if G.achT <= 0 then G.achT = 30; UI.achCheck() end         -- (anything earned mid-shift pops up)
end

-- ---- the top bar in the Cafe: the barista level, the stars, the meter to the next star ----
function UI.levelBadge(xr, cy, lv, onDark)                    -- "LV 2" on a little pill, right edge at xr
  local txt = "LV " .. lv
  local w = UI.pixWidth(txt) + 10
  local x = xr - w
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(onDark and WHITE or BLACK)
  gfx.fillRoundRect(x, cy - 6, w, 12, 5)
  gfx.setColor(onDark and BLACK or WHITE)
  UI.pixText(txt, x + 5, cy - 3)
  UI.ink("none")
  gfx.setColor(BLACK)
  return x
end
function UI.drawStarBar()
  local d = G.cafe
  local v = G.meterV or d.stars
  local lv = UI.lvl(d)
  local bx = UI.levelBadge(166, 9, lv, true)
  UI.drawBoostChip((UI.hudLeft or 60) + 6, bx - 5)
  CAFE.drawStars(178, 9, 5, 11, v, WHITE, lv)
  if G.starPop then                                           -- a new star: it pops up big, a ring flashes out and sparkles fly off it
    local i, t = G.starPop.i, G.starPop.t
    local k = math.min(1, t / 0.9)
    local sx = 178 + (i - 1) * 11
    local rr = 5 + math.floor(3.5 * math.sin(math.min(1, t / 0.45) * math.pi) + 0.5)    -- (swells, then settles back)
    if rr > 5 then
      UI.ink("none"); CAFE.star(sx, 9, rr + 1, 1, BLACK)
      if UI.starHook then UI.starHook(lv, i) end
      CAFE.star(sx, 9, rr, 1, WHITE)
      UI.starTint = nil
    end
    UI.ink(UI.starRow and UI.starRow(lv) or "none")
    gfx.setColor(WHITE)
    if k < 0.55 then                                          -- a ring of light flashing outward
      local rad = 6 + math.floor(k * 22)
      for a = 0, 15 do
        local an = a * math.pi / 8
        gfx.drawPixel(sx + math.floor(math.cos(an) * rad + 0.5), 9 + math.floor(math.sin(an) * rad * 0.7 + 0.5))
      end
    end
    for j = 0, 5 do                                           -- six little sparkles flying off and twinkling out
      local an = j * math.pi / 3 + 0.3 + t * 2
      local dist = 7 + k * 16
      local px, py = sx + math.floor(math.cos(an) * dist + 0.5), 9 + math.floor(math.sin(an) * dist * 0.75 + 0.5)
      gfx.drawPixel(px, py)
      if k < 0.6 then gfx.drawPixel(px - 1, py); gfx.drawPixel(px + 1, py); gfx.drawPixel(px, py - 1); gfx.drawPixel(px, py + 1) end
    end
    UI.ink("none")
  end
  -- the meter: how far along the next star is
  local mx, my, mw = UI.METER_X, UI.METER_Y, UI.METER_W
  local frac = (v >= 4.999) and 1 or (v - math.floor(v + 0.001))
  if frac < 0 then frac = 0 end
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(WHITE)
  gfx.drawRoundRect(mx, my, mw, 9, 4)
  local fw = math.floor((mw - 4) * frac + 0.5)
  if fw > 0 then gfx.fillRoundRect(mx + 2, my + 2, math.max(fw, 3), 5, 2) end
  if v >= 4.999 then                                          -- full: a shine runs along it
    local sx = mx + 2 + (math.floor(frames * 1.2)) % (mw + 20) - 10
    gfx.setColor(BLACK)
    if sx > mx + 2 and sx < mx + mw - 3 then gfx.drawLine(sx, my + 2, sx - 2, my + 6) end
  end
  if G.spark then                                             -- the sticker just landed
    gfx.setColor(WHITE)
    local t = 0.45 - G.spark
    for k = 0, 3 do
      local a = k * math.pi / 2 + 0.6
      local r = 4 + t * 22
      local px, py = math.floor(mx + mw / 2 + math.cos(a) * r * 1.4), math.floor(my + 4 + math.sin(a) * r * 0.5)
      gfx.drawLine(px - 1, py, px + 1, py); gfx.drawLine(px, py - 1, px, py + 1)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end
UI.COIN9 = { "..wwwww..", ".wwwkwww.", "wwwkkkwww", "wwwkwwwww", "wwwkkkwww", "wwwwwkwww", "wwwkkkwww", ".wwwkwww.", "..wwwww.." }
function UI.drawBoostChip(x, xmax)                                  -- a boost from the daily gift: what it is and how long it has left
  local d = G.cafe
  local bt, bs = tonumber(d.boostT) or 0, tonumber(d.boostS) or 0
  if bt <= 0 and bs <= 0 then return end
  local kind = (bt > 0 and (bs <= 0 or (math.floor(frames / (60))) % 2 == 0)) and "t" or "s"
  local left = math.ceil(kind == "t" and bt or bs)
  local txt = string.format("%d:%02d", math.floor(left / 60), left % 60)
  local w = UI.pixWidth(txt) + 22
  if x + w > xmax then return end                             -- (no room: a very long shift's clock)
  UI.ink(kind == "t" and "yellow" or "rose")
  gfx.setColor(WHITE)
  gfx.drawRoundRect(x, 3, w, 12, 5)
  if kind == "t" then                                          -- a little coin
    UI.pic(UI.COIN9, x + 4, 5)                                  -- (a round coin with the $ right in its middle)
  else
    CAFE.star(x + 8, 9, 3, 1, WHITE)
  end
  gfx.setColor(WHITE)
  UI.pixClock(txt, x + 15, 6)
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- prestige: at 5 of 5 stars, start the stars again as the next barista level ----
function UI.drawPrestigePreview(cx, cy)
  local lv = UI.lvl(CAFE.cur) + 1
  local bob = math.floor(math.sin(frames * 0.12) * 2 + 0.5)
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 24, cy - 22 + bob, 48, 30, 8)
  gfx.setColor(WHITE); gfx.drawRoundRect(cx - 21, cy - 19 + bob, 42, 24, 6)
  gfx.setColor(WHITE)
  local txt = "LV " .. lv
  UI.pixText(txt, cx - math.floor(UI.pixWidth(txt) / (2)), cy - 10 + bob)
  for i = 0, 4 do CAFE.star(cx - 22 + i * 11, cy + 18, 4, (i == 2) and 1 or 0, BLACK) end
  UI.ink("none")
  gfx.setColor(BLACK)
end
-- ---- rank up: the prestige show --------------------------------------------------------------------------------
-- Your five stars lift out of the bar and line up in an arc; one by one they leap and shower down into the level
-- badge, each one filling it a little more (with a rising chime); full, it shakes and cracks as light is sucked in,
-- then bursts in a flash and a shower of the new level's stars, and comes back as the new level: bigger, brighter,
-- in the new colour, with "RANK UP!" above it and five fresh empty stars to earn. A skips ahead; A at the end goes on.
UI.RANK_LAUNCH, UI.RANK_GAP, UI.RANK_FLY = 0.8, 0.3, 0.45     -- (when the first star leaps, the time between stars, how long each flies)
UI.RANK_BURST = 3.35                                            -- (the moment it bursts into the new level)
UI.RANK_PERK0, UI.RANK_PERKGAP = 0.75, 0.28                     -- (after the burst: when the perks card's first line slides in, and the next ones)
UI.RANK_ICON = {
  coin = { ".kkkkk.", "kwwwwwk", "kwwkwwk", "kwkkkwk", "kwwkwwk", "kwwwwwk", ".kkkkk." },
  lamp = { "..kkk..", ".kwwwk.", "kwwwwwk", "kkkkkkk", "...k...", "...k...", "..kkk.." },
  glass = { "kkkkkkk", ".kwwwk.", "..kwk..", "...k...", "..kwk..", ".kkkkk.", "kkkkkkk" },
  ticket = { ".kkkkk.", "kwwwwwk", "kwkkkwk", "kwwwwwk", "kwkkkwk", "kwwwwwk", ".kkkkk." },
}
UI.RANK_ICONINK = { coin = "gold2", glass = "skyp", ticket = "sym_gold" }
UI.RANK_CX, UI.RANK_CY = 200, 86                                -- (the badge's middle)
function UI.tintFor(lv) return nil end                          -- (PC: the palette row for a level's stars)
UI.RANK_CRACKS = { { -30, -14, -22, -6, -26, 2, -18, 10 }, { 22, -16, 14, -8, 20, 0, 12, 8 }, { -6, -20, 0, -12, -4, -4, 4, 6 },
                   { -40, 4, -32, 8, -36, 14 }, { 34, -4, 40, 4, 32, 12 } }

function UI.rankStart(from, to)
  local r = { t = 0, from = from, to = to, stars = {}, parts = {}, hits = 0, fill = 0, pulse = 0, flash = 0, done = false }
  for i = 1, 5 do r.stars[i] = { sx = 26 + (i - 1) * 11, sy = 224, state = "rise" } end      -- (from the shop's star bar)
  local up, all = UI.lvlTipPct(to) - UI.lvlTipPct(from), UI.lvlTipPct(to)                 -- what the new level brings
  local sl, sall = UI.lvlSlowPct(to) - UI.lvlSlowPct(from), UI.lvlSlowPct(to)
  r.perks = {}
  r.perks[#r.perks + 1] = { "coin", (up > 0) and ("Tips +" .. up .. "%   (now +" .. all .. "% in total)") or ("Tips: maxed at +" .. all .. "%") }
  r.perks[#r.perks + 1] = { "glass", (sl > 0) and ("Patience +" .. sl .. "%   (now " .. sall .. "% slower)") or ("Patience: maxed at " .. sall .. "% slower") }
  r.perks[#r.perks + 1] = { "ticket", "A free Golden Bean scratch-off!" }
  r.perks[#r.perks + 1] = { "stars", "Stars start again from 0" }
  CAFE.rank = r
end

function UI.rankTicket()                                       -- after the show: the free Golden Bean, ready to scratch (a ticket already half done comes first)
  local d = CAFE.cur
  if not d then return end
  if not d.scratch and (tonumber(d.freeGold) or 0) > 0 then
    d.freeGold = tonumber(d.freeGold) - 1
    d.scratch = CAFE.scratchMake(3)
    CAFE.allC = nil
    CAFE.write()
  end
  if d.scratch then CAFE.scratchOpen() end
end
function UI.rankArc(i) return 200 + (i - 3) * 38, 24 + (i - 3) * (i - 3) * 5 end                -- each star's spot in the arc

function UI.rankPart(r, x, y, vx, vy, life, kind, lv, grav)
  if #r.parts >= 70 then return end
  r.parts[#r.parts + 1] = { x = x, y = y, vx = vx, vy = vy, life = life, t = 0, kind = kind, lv = lv, g = grav or 0 }
end

function UI.rankBurst(r)                                         -- the moment it evolves
  r.burst = true
  r.flash = 0.35
  r.fill = 1
  for i = 1, 5 do r.stars[i].state = "in" end
  for k = 1, 44 do
    local a = (k / 44) * math.pi * 2 + math.random() * 0.2
    local sp = 70 + math.random() * 150
    UI.rankPart(r, UI.RANK_CX, UI.RANK_CY, math.cos(a) * sp, math.sin(a) * sp * 0.8, 0.9 + math.random() * 0.7, (k % 3 == 0) and "star" or "dot", r.to, 60)
  end
  if sfx.achieve then sfxPlay("achieve", false, 1.0) end
  sfxPlay("tip", false, 1.0)
  play(synthSine, 523, 0.20, 0.30); play(synthSine, 659, 0.20, 0.30, 0.06); play(synthSine, 784, 0.25, 0.30, 0.12); play(synthSine, 1047, 0.45, 0.32, 0.18)
end

function UI.rankUpdate(dt)
  local r = CAFE.rank
  if not r then return end
  local A = pd.buttonJustPressed(pd.kButtonA)
  if A and not r.burst and r.t > 0.3 then                        -- skip ahead to the burst
    r.t = UI.RANK_BURST; r.hits = 5
    UI.rankBurst(r)
    A = false
  end
  local endT = UI.RANK_BURST + UI.RANK_PERK0 + #r.perks * UI.RANK_PERKGAP + 0.3
  if (A or pd.buttonJustPressed(pd.kButtonB)) and r.burst then
    if r.t < endT then r.t = endT                                  -- (the first press shows the rest of the perks at once)
    else
      sfxClick()
      UI.fast(function() CAFE.rank = nil; UI.rankTicket() end)     -- (straight on to scratching the free ticket)
      return
    end
  end
  r.t = r.t + dt
  local t = r.t
  r.pulse = math.max(0, r.pulse - dt)
  r.flash = math.max(0, r.flash - dt)
  -- the stars leap one by one and fall into the badge
  for i, s in ipairs(r.stars) do
    local t0 = UI.RANK_LAUNCH + (i - 1) * UI.RANK_GAP
    if s.state == "rise" and t >= t0 then s.state = "fly"; play(synthSine, 880 + i * 60, 0.05, 0.15) end
    if s.state == "fly" then
      local p = (t - t0) / UI.RANK_FLY
      if math.random() < 0.8 then                                  -- a trail of sparkles behind it
        local x, y = UI.rankStarPos(r, i)
        UI.rankPart(r, x, y, (math.random() - 0.5) * 20, (math.random() - 0.5) * 20, 0.35, "dot", r.from)
      end
      if p >= 1 then
        s.state = "in"
        r.hits = r.hits + 1
        r.pulse = 0.18
        play(synthSine, ({ 523, 659, 784, 988, 1175 })[i], 0.16, 0.30)
        for k = 1, 12 do                                           -- a splash of light where it lands
          local a = math.random() * math.pi * 2
          local sp = 30 + math.random() * 60
          UI.rankPart(r, UI.RANK_CX, UI.RANK_CY - 8, math.cos(a) * sp, math.sin(a) * sp - 20, 0.5, "dot", r.from, 120)
        end
      end
    end
  end
  r.fill = r.fill + (r.hits / 5 - r.fill) * math.min(1, dt * 6)  -- the badge fills as they land
  -- full: it charges up (light is sucked in, a rising rumble), then bursts
  if not r.burst and r.hits >= 5 then
    if math.random() < 0.9 then
      local a = math.random() * math.pi * 2
      local d = 90 + math.random() * 60
      UI.rankPart(r, UI.RANK_CX + math.cos(a) * d, UI.RANK_CY + math.sin(a) * d * 0.7, 0, 0, 0.45, "suck", r.to)
    end
    if frames % 3 == 0 then play(UI.synthNoise, 300 + (t - 2.4) * 900, 0.04, 0.10) end
    if t >= UI.RANK_BURST then UI.rankBurst(r) end
  end
  if r.burst then
    for i = 1, #r.perks do
      if not r.perks[i].shown and t > UI.RANK_BURST + UI.RANK_PERK0 + (i - 1) * UI.RANK_PERKGAP then
        r.perks[i].shown = true
        play(synthSine, 1047 + i * 131, 0.08, 0.22)
      end
    end
  end
  -- the particles
  for k = #r.parts, 1, -1 do
    local q = r.parts[k]
    q.t = q.t + dt
    if q.kind == "suck" then                                       -- (pulled toward the badge, faster and faster)
      local p = q.t / q.life
      q.x = q.x + (UI.RANK_CX - q.x) * math.min(1, dt * (3 + p * 10))
      q.y = q.y + (UI.RANK_CY - q.y) * math.min(1, dt * (3 + p * 10))
    else
      q.vy = q.vy + q.g * dt
      q.vx, q.vy = q.vx * (1 - dt * 1.2), q.vy * (1 - dt * 1.2)
      q.x, q.y = q.x + q.vx * dt, q.y + q.vy * dt
    end
    if q.t >= q.life then table.remove(r.parts, k) end
  end
end

function UI.rankStarPos(r, i)                                    -- where star i is right now (and how big)
  local s = r.stars[i]
  local ax, ay = UI.rankArc(i)
  local t = r.t
  if s.state == "rise" then                                        -- out of the bar and up into the arc (with a little overshoot)
    local p = math.min(1, math.max(0, (t - (i - 1) * 0.06) / 0.5))
    local e = 1 + 2.2 * (p - 1) ^ 3 + 1.2 * (p - 1) ^ 2
    if p >= 1 then e = 1 end
    local bob = (p >= 1) and math.sin(t * 6 + i) * 1.5 or 0
    return s.sx + (ax - s.sx) * e, s.sy + (ay - s.sy) * e + bob, 3 + math.floor(4 * math.min(1, p * 1.4))
  elseif s.state == "fly" then                                     -- a hop up, then down into the badge, shrinking
    local p = math.min(1, (t - UI.RANK_LAUNCH - (i - 1) * UI.RANK_GAP) / UI.RANK_FLY)
    local ex, ey = UI.RANK_CX, UI.RANK_CY - 4
    local cx, cy = (ax + ex) / 2, math.min(ay, ey) - 46            -- (the top of its hop)
    local u = 1 - p
    local x = u * u * ax + 2 * u * p * cx + p * p * ex
    local y = u * u * ay + 2 * u * p * cy + p * p * ey
    return x, y, math.max(2, math.floor(7 - p * 4 + 0.5))
  end
  return nil
end

function UI.rankBadge(cx, cy, s, lv, fill, cracks, shine)      -- the big level badge: a dark frame filling with light, "LV n" across it
  local w, h = math.floor(92 * s + 0.5), math.floor(52 * s + 0.5)
  local x0, y0 = cx - math.floor(w / (2)), cy - math.floor(h / (2))
  local row = UI.starRow and UI.starRow(lv) or "none"
  UI.ink(row)
  gfx.setColor(WHITE); gfx.fillRoundRect(x0 - 4, y0 - 4, w + 8, h + 8, 14)       -- a bright rim round it
  gfx.setColor(BLACK); gfx.fillRoundRect(x0 - 2, y0 - 2, w + 4, h + 4, 12)        -- the frame
  if UI.color then UI.ink("rk_bg"); gfx.setColor(BLACK); gfx.fillRoundRect(x0 + 3, y0 + 3, w - 6, h - 6, 9); UI.ink(row) end   -- (PC: a dark inside, so the light filling it shows)
  gfx.setColor(WHITE); gfx.setLineWidth(2); gfx.drawRoundRect(x0 + 2, y0 + 2, w - 4, h - 4, 9); gfx.setLineWidth(1)
  local fh = math.floor((h - 8) * fill + 0.5)                     -- the light inside, rising with a gentle wave on top
  if fh > 0 then
    gfx.setClipRect(x0 + 4, y0 + 4, w - 8, h - 8)
    gfx.setColor(WHITE)
    local top = y0 + h - 4 - fh
    for xx = x0 + 4, x0 + w - 5, 2 do
      local wy = (fill < 0.99) and math.floor(math.sin(xx * 0.18 + frames * 0.3) * 1.5 + 0.5) or 0
      gfx.fillRect(xx, top + wy, 2, y0 + h - 4 - top - wy)
    end
    gfx.clearClipRect()
  end
  if shine and UI.color then                                       -- (PC) a bright gleam that sweeps across the finished badge now and then
    local sx = x0 + ((frames * 5) % (w + 160)) - 30
    UI.ink("sthi"); gfx.setColor(WHITE)
    gfx.setClipRect(x0 + 4, y0 + 4, w - 8, h - 8)
    gfx.drawLine(sx, y0 + 4, sx - 12, y0 + h - 5); gfx.drawLine(sx + 1, y0 + 4, sx - 11, y0 + h - 5); gfx.drawLine(sx + 4, y0 + 4, sx - 8, y0 + h - 5)
    gfx.clearClipRect()
    UI.ink(row)
  end
  if cracks and cracks > 0 then                                    -- light breaking through
    gfx.setColor((fill > 0.5) and BLACK or WHITE)
    for k = 1, math.min(cracks, #UI.RANK_CRACKS) do
      local c = UI.RANK_CRACKS[k]
      for j = 1, #c - 2, 2 do gfx.drawLine(cx + c[j], cy + c[j + 1], cx + c[j + 2], cy + c[j + 3]) end
    end
  end
  UI.ink("none")
  local txt = "LV " .. lv
  UI.fancyText(txt, cx, cy - 18, 0.35, math.floor(84 * s), true)     -- (the letters' middle sits on the badge's middle)
  gfx.setColor(BLACK)
end

function UI.rankDraw()
  local r = CAFE.rank
  if not r then return end
  local t = r.t
  local cx, cy = UI.RANK_CX, UI.RANK_CY
  -- the backdrop: the shop dims, then a dark stage with slowly turning rays (faster as it charges)
  if t < 0.25 then UI.dimScreen() end
  if t >= 0.12 then
    UI.ink("rk_bg")
    gfx.setColor(BLACK); gfx.fillRect(0, 0, 400, 240)
    local spin = t * 0.25 + ((r.hits >= 5 and not r.burst) and (t - 2.4) ^ 2 * 0.8 or 0)
    UI.ink(r.burst and "rk_ray2" or "rk_ray")
    if UI.color then gfx.setColor(WHITE) else gfx.setPattern({ 0x88, 0x00, 0x22, 0x00, 0x88, 0x00, 0x22, 0x00 }) end
    for k = 0, 11 do
      local a = spin + k * math.pi / 6
      gfx.fillPolygon(cx, cy, math.floor(cx + math.cos(a) * 300), math.floor(cy + math.sin(a) * 300),
                      math.floor(cx + math.cos(a + 0.2) * 300), math.floor(cy + math.sin(a + 0.2) * 300))
    end
    gfx.setColor(BLACK)
    UI.ink("none")
  end
  -- the badge: the old level filling up; shaking and cracking as it charges; after the burst, the new level
  local shake = 0
  if r.hits >= 5 and not r.burst then shake = math.floor(math.sin(t * 60) * math.min(3, (t - 2.3) * 3) + 0.5) end
  if not r.burst then
    local s = 1.2 + r.pulse * 0.7
    local cracks = (r.hits >= 5) and math.floor((t - 2.4) * 6) or 0
    UI.rankBadge(cx + shake, cy, s, r.from, r.fill, cracks, false)
  else
    local p = math.min(1, (t - UI.RANK_BURST) / 0.45)            -- it pops up bigger than it is, then settles
    local s = (p < 1) and (0.5 + p * 0.9 + 0.4 * math.sin(p * math.pi)) or (1.4 + math.sin(t * 2.5) * 0.03)
    for k = 0, 1 do                                                -- two rings of light going out from it (just after the burst)
      local rp = (t - UI.RANK_BURST) * 0.9 - k * 0.3
      if rp > 0 and rp < 1 then
      UI.ink(UI.starRow and UI.starRow(r.to) or "none")
      gfx.setColor(WHITE)
      gfx.drawEllipseInRect(cx - math.floor(60 + rp * 160), cy - math.floor(36 + rp * 96), math.floor(120 + rp * 320), math.floor(72 + rp * 192))
      end
    end
    UI.ink("none")
    UI.rankBadge(cx, cy, s, r.to, 1, 0, p >= 1)
  end
  -- the stars (rising into the arc, then leaping into the badge), with the old level's colour
  for i = 1, 5 do
    local x, y, rad = UI.rankStarPos(r, i)
    if x then
      UI.starTint = UI.tintFor(r.from)
      CAFE.star(math.floor(x + 0.5), math.floor(y + 0.5), rad, 1, WHITE)
      UI.starTint = nil
    end
  end
  -- the particles: sparkles, the light being drawn in, the burst of new stars
  for _, q in ipairs(r.parts) do
    local x, y = math.floor(q.x + 0.5), math.floor(q.y + 0.5)
    if q.kind == "star" then
      UI.starTint = UI.tintFor(q.lv)
      CAFE.star(x, y, (q.t < q.life * 0.6) and 3 or 2, 1, WHITE)
      UI.starTint = nil
    else
      UI.ink(UI.starRow and UI.starRow(q.lv) or "none")
      gfx.setColor(WHITE)
      if q.kind == "suck" then gfx.fillRect(x, y, 2, 1) elseif q.t < q.life * 0.5 then gfx.fillRect(x - 1, y, 3, 1); gfx.fillRect(x, y - 1, 1, 3)
      else gfx.drawPixel(x, y) end
    end
  end
  UI.ink("none")
  -- after the burst: the title, the new level's name, and five fresh stars to earn
  if r.burst then
    local tb = t - UI.RANK_BURST
    if tb > 0.2 then
      local drop = math.max(0, 1 - (tb - 0.2) / 0.35)
      UI.ink("fx_yellow")
      UI.fancyText("RANK UP!", 200, 12 - math.floor(drop * drop * 40), 0.7, 260, nil, UI.FX_RAINBOW)
      UI.ink("none")
    end
    if tb > 0.5 then                                               -- the perks card: what the new level brings, a line at a time
      local n = #r.perks
      local ch = 22 + n * 15
      local cy0 = 132
      local grow = math.min(1, (tb - 0.5) / 0.2)
      local cw = math.floor(272 * grow)
      UI.ink("pm_card")
      gfx.setColor(BLACK); gfx.fillRoundRect(200 - math.floor(cw / 2) + 2, cy0 + 3, cw, ch, 8)
      gfx.setColor(WHITE); gfx.fillRoundRect(200 - math.floor(cw / 2), cy0, cw, ch, 8)
      gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(200 - math.floor(cw / 2), cy0, cw, ch, 8); gfx.setLineWidth(1)
      UI.ink("none")
      if grow >= 1 then
        UI.ink(UI.starRow and UI.starRow(r.to) or "none")
        gfx.setColor(BLACK); gfx.fillRoundRect(80, cy0 + 3, 240, 15, 6)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite); drawTC("Barista Level " .. r.to .. " perks", 200, cy0 + 2, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
        UI.ink("none")
        for i, pk in ipairs(r.perks) do
          local ti = tb - UI.RANK_PERK0 - (i - 1) * UI.RANK_PERKGAP
          if ti > 0 then
            local p = math.min(1, ti / 0.22)
            local slide = math.floor((1 - p) * (1 - p) * 60 + 0.5)          -- (slides in from the right and settles)
            local ly = cy0 + 20 + (i - 1) * 15
            local lx = 84 + slide
            if pk[1] == "stars" then
              UI.starTint = UI.tintFor(r.to)
              for k = 0, 4 do CAFE.star(lx + 2 + k * 5, ly + 8, 2, 0, BLACK) end
              UI.starTint = nil
              lx = lx + 28
            else
              UI.ink(UI.RANK_ICONINK[pk[1]] or "none")
              UI.pic(UI.RANK_ICON[pk[1]], lx + 2, ly + 3)
              UI.ink("none")
              lx = lx + 14
            end
            gfx.setColor(BLACK); gfx.setFont(fontNormal)
            drawT(pk[2], lx, ly)
          end
        end
      end
    end
    if tb > UI.RANK_PERK0 + #r.perks * UI.RANK_PERKGAP + 0.3 then
      local hint = (CAFE.cur and (CAFE.cur.scratch or (tonumber(CAFE.cur.freeGold) or 0) > 0)) and "Press A to scratch your ticket!" or "Press A to go on"
      gfx.setFont(fontBold)
      local hw = gfx.getTextSize(hint) + 20
      gfx.setColor(WHITE); gfx.fillRoundRect(200 - math.floor(hw / (2)), 220, hw, 18, 8)
      drawTC(hint, 200, 220, true)
    end
  elseif t > 0.6 then
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC((r.hits >= 5) and "Here it comes..." or "Prestige!", 200, 136, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  -- the flash at the burst
  if r.flash > 0 then
    if r.flash > 0.25 then gfx.setColor(WHITE); gfx.fillRect(0, 0, 400, 240)
    elseif r.flash > 0.1 then                                      -- (then half of it, see-through, as it fades)
      if UI.flashImg == nil then
        UI.flashImg = gfx.image.new(400, 240, gfx.kColorWhite)
        gfx.pushContext(UI.flashImg); gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(0, 0, 400, 240); gfx.popContext()
      end
      gfx.setImageDrawMode(gfx.kDrawModeBlackTransparent); UI.flashImg:draw(0, 0); gfx.setImageDrawMode(gfx.kDrawModeCopy)
    end
  end
  gfx.setColor(BLACK)
end

function UI.prestige()
  local d = CAFE.cur
  local from = UI.lvl(d)
  d.lvl = from + 1
  d.stars = 0
  CAFE.allC = nil
  CAFE.write()
  UI.metaSave()
  d.freeGold = (tonumber(d.freeGold) or 0) + 1                    -- (every rank up: a free Golden Bean scratch-off, waiting on the Stuff tab)
  CAFE.write()
  UI.rankStart(from, d.lvl)                                       -- (the show: see UI.rankDraw)
end
function UI.askDraw()                                         -- "Prestige?" Yes / No
  local a = CAFE.ask
  local bx, by, bw, bh = 56, 44, 288, 150
  gfx.setColor(WHITE); gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14)
  gfx.setColor(BLACK)
  CAFE.wobbleBox(bx, by, bw, bh)
  local lv = UI.lvl(CAFE.cur)
  drawTC("Prestige to Barista Lv " .. (lv + 1) .. "?", 200, by + 12, true)
  drawTC("Your stars go back to 0 of 5.", 200, by + 34)
  drawTC("You keep your decor and money, and get", 200, by + 50)
  drawTC("bigger tips, more patient customers", 200, by + 66)
  drawTC("and a free Golden Bean scratch-off!", 200, by + 82)
  for i = 1, 2 do
    local x = (i == 1) and 86 or 206
    local on = (a.sel == i)
    gfx.setColor(BLACK)
    if on then
      gfx.fillRoundRect(x, by + 108, 108, 28, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2); gfx.drawRoundRect(x, by + 108, 108, 28, 8); gfx.setLineWidth(1)
    end
    drawTC(i == 1 and "Prestige!" or "Not yet", x + 54, by + 115, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if on then CAFE.pointer(x + 84, by + 128) end
  end
end
function UI.askUpdate()
  local a = CAFE.ask
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then a.sel = 3 - a.sel; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonA) then
    CAFE.ask = nil
    if a.sel == 1 then UI.prestige() else sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonB) then CAFE.ask = nil; sfxClick() end
end

-- ---- the Sale tab: its first line counts down to the next deals ----
function UI.saleTimerRow(y)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(10, y, 273, 19, 5)
  gfx.setColor(WHITE)
  local cx, cy = 22, y + 9                                     -- a little clock, its hand going round
  gfx.drawCircleAtPoint(cx, cy, 6)
  local a = (frames % 60) / 60 * 2 * math.pi
  gfx.drawLine(cx, cy, cx, cy - 4)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(a) * 4 + 0.5), math.floor(cy - math.cos(a) * 4 + 0.5))
  local txt
  local sl = CAFE.sale
  if sl then
    local left = math.max(0, math.ceil((sl.nextMs - pd.getCurrentTimeMilliseconds()) / 1000))
    local clock = string.format("%d:%02d", math.floor(left / 60), left % 60)
    local pre = sl.flash and "FLASH SALE! ALL 50% OFF  " or "NEW DEALS IN  "
    local tx = 147 - math.floor(UI.pixWidth(pre .. clock) / (2)) + 6
    UI.pixText(pre, tx, y + 6)                                  -- (the words stay put; the countdown is stamped a figure at a time)
    UI.pixClock(clock, tx + UI.pixWidth(pre) + 1, y + 6)
    gfx.setColor(BLACK)
    return
  else
    txt = "NEW DEALS SOON"
  end
  UI.pixText(txt, 147 - math.floor(UI.pixWidth(txt) / (2)) + 6, y + 6)
  gfx.setColor(BLACK)
end
function CAFE.visRows() return (CAFE.tab == CAFE.SALE_TAB) and 6 or 7 end      -- (the Sale tab's first line is its countdown)
function CAFE.rowY(vi) return 69 + (vi - 1 + 7 - CAFE.visRows()) * 20 end

----------------------------------------------------------------------
-- Playdate: the loading scene (a steaming cup that fills up) shown while a shift is built and the cafe is drawn for the first time.
-- The cafe's pictures are made once on the first draw, which is more than a frame's worth of work; doing it here, behind a scene
-- that is already on the screen, means the cafe then fades in with nothing left to catch up on.
----------------------------------------------------------------------
UI.LOAD_MIN = 0.5                                  -- the cup takes at least this long to fill (seconds)
function UI.cupScene(t, p, msg)                    -- t: seconds (for the movement); p: how full the cup is (0 to 1)
  gfx.setBackgroundColor(BLACK)
  gfx.clear()
  gfx.setColor(WHITE)
  gfx.setLineWidth(4)
  gfx.drawRoundRect(226, 98, 26, 28, 10)            -- the handle
  gfx.setLineWidth(1)
  gfx.fillRoundRect(165, 84, 70, 68, 14)            -- the mug: a white wall all round with a flat top (only the bottom corners are round) ...
  gfx.fillRect(165, 84, 70, 26)
  gfx.fillRect(162, 84, 76, 5)                      -- ... and a little lip along the top
  gfx.setColor(BLACK)
  gfx.fillRoundRect(169, 89, 62, 59, 11)            -- the inside, cut out in black
  gfx.fillRect(169, 89, 62, 26)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(144, 152, 112, 7, 3)            -- the saucer
  local lvl = math.floor(56 * math.max(0, math.min(1, p)))
  if lvl > 1 then
    local top = 147 - lvl
    gfx.setClipRect(170, 89, 60, 58)
    gfx.setPattern(CHECK)
    gfx.fillRect(170, top, 60, lvl + 1)
    gfx.setColor(WHITE)
    for x = 170, 228, 2 do                         -- the surface sloshes a little
      gfx.fillRect(x, top + math.floor(1.6 * math.sin(x * 0.28 + t * 7) + 0.5), 2, 2)
    end
    gfx.clearClipRect()
  end
  gfx.setColor(WHITE)
  for col = 1, 3 do                                -- steam
    local cx = 176 + col * 12
    for k = 0, 6 do
      local y = 78 - k * 7 - (t * 16) % 7
      if y > 28 and (k < 5 or math.floor(t * 8 + col) % 2 == 0) then
        local x = cx + 4 * math.sin(t * 2.6 + k * 0.9 + col * 1.7)
        gfx.fillCircleAtPoint(math.floor(x), math.floor(y), (k < 3) and 2 or 1)
      end
    end
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  gfx.setFont(fontBold)
  msg = msg or "Loading"
  local tw = gfx.getTextSize(msg)
  gfx.drawText(msg, 200 - math.floor(tw / 2), 182)
  gfx.drawText(string.rep(".", math.floor(t * 3) % 4), 200 - math.floor(tw / 2) + tw + 1, 182)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

function UI.loadStart()
  UI.loadOn = false
  local mode = G and G.mode or "cafe"
  UI.load = { t = 0, step = 0, msg = "Loading" }
end
function UI.loadDraw()
  local l = UI.load
  local flip = l.t2 and math.min(1, l.t2 / UI.LOAD_MIN) or 0      -- (the sign waits, still, while the work is done, then turns in one smooth go)
  local art = (G and G.mode == "cafe" and G.win) and CAFE.doorArt() or nil
  if art then                                      -- your cafe: the storefront from the door screen, its sign turning from CLOSED to OPEN
    local keep = CAFE.door
    CAFE.door = { p = flip, done = 1, tick = 0 }    -- (only borrowed for the drawing: the door screen's own state is put straight back)
    local ok = pcall(CAFE.doorDrawArt, art)
    CAFE.door = keep
    if ok then
      if flip >= 1 and not l.bell then l.bell = true; if sfx.bell then pcall(sfxPlay, "bell", false, 1.0) end end
      return
    end
  end
  local p = 0.4 * math.min(l.step, 5) / 5 + 0.6 * flip
  p = p * p * (3 - 2 * p)
  UI.cupScene(l.t, p, l.msg)                       -- Rush Hour / Evening Chill: a steaming cup that fills up
end
function UI.loadWarm(fn)                           -- one part of the cafe drawn once, off screen: that makes the cached pictures in it
  UI.warmImg = UI.warmImg or gfx.image.new(400, 240, WHITE)
  local ok = pcall(function()
    gfx.pushContext(UI.warmImg)
    gfx.setColor(BLACK); gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.inPlay = true
    fn()
    UI.inPlay = false
    gfx.popContext()
  end)
  if not ok then UI.inPlay = false; pcall(gfx.popContext) end
  gfx.setColor(BLACK); gfx.setImageDrawMode(gfx.kDrawModeCopy)
end
function UI.loadWork()                             -- (after the scene is drawn; one small part a frame, so the scene keeps moving)
  local l = UI.load
  l.step = l.step + 1
  local s = l.step
  if s == 2 then UI.loadWarm(function() CAFE.sceneTop() end)
  elseif s == 3 then UI.loadWarm(function() CAFE.sceneBottom() end)
  elseif s == 4 then UI.loadWarm(function() drawPlayer(); UI.drawDoor() end)
  elseif s == 5 then if G and G.pets then pcall(CAFE.petGrid) end          -- (the pets' map of the floor is worked out now too)
  end
end
function UI.loadDone(dt)                           -- true when the scene can fade out to the game
  local l = UI.load
  l.t = l.t + dt
  if l.step >= 5 then
    if l.t2 == nil then l.t2 = 0 else l.t2 = l.t2 + dt end        -- (the frame that did the last of the work does not count)
    if l.t2 >= UI.LOAD_MIN + 0.08 then UI.load = nil; return true end
  end
  return false
end

function pd.update()
  local now = pd.getCurrentTimeMilliseconds()
  local dt = (now - lastMs) / 1000
  lastMs = now
  if dt > 0.1 then dt = 0.1 end
  if dt < 0 then dt = 0 end
  frames = frames + 1
  UI.frameT0, UI.loadN = now, 0                     -- (the loading budget starts again each frame)
  UI.inPlay = false
  if not UI.color and not UI.bootDone and UI.bootStep() then return end     -- (Playdate: the loading screen, once, before the title)
  UI.applyDrinkLook()
  UI.musicTick()
  -- "Title screen" only exists in the menu while you're playing Rush Hour or Evening Chill
  UI.setTitleItem(state == STATE_PLAY and G ~= nil and G.mode ~= "cafe")
  if state ~= STATE_MENU then UI.settings = nil end
  if state ~= STATE_MENU and state ~= STATE_PLAY then UI.ach = nil end
  UI.achTick(dt)
  UI.bgSweep()
  UI.bgPreload()
  UI.fancyWarm()

  -- advance a screen fade: dark, switch screens, light again
  if trans then
    if trans.skip then trans.skip = nil else trans.t = trans.t + dt end      -- (Playdate: the frame that carried the heavy work does not count towards the fade-in)
    if trans.phase == "out" and trans.t >= trans.dur then
      trans.fn()
      if UI.loadOn then UI.loadStart(); trans.phase, trans.t = "load", 0     -- (Playdate only: the loading scene, then the fade in)
      else trans.phase, trans.t = "in", 0 end
    elseif trans.phase == "load" then
      if UI.loadDone(dt) then trans.phase, trans.t, trans.skip = "in", 0, true end
    elseif trans.phase == "in" and trans.t >= trans.dur then
      trans = nil
    end
  end

  -- only the screen we started the frame on reacts to the buttons, so one
  -- button press can't fall straight through into the next screen
  -- (nothing reacts while the screen is fading out)
  if trans == nil or trans.phase == "in" then
    if state == STATE_MENU then
      if UI.settings then UI.updateSettings() elseif UI.ach then UI.updateAch() else updateMenu() end
    elseif state == STATE_PLAY then if UI.ach then UI.updateAch() else updatePlay(dt) end
    elseif state == STATE_ENTRY then updateEntry(dt)
    elseif state == CAFE.STATE then CAFE.update(dt)
    else updateBoard(dt) end
  end

  gfx.setBackgroundColor(WHITE)
  gfx.clear()
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if trans and trans.phase == "load" then
    UI.loadDraw()                                    -- (the loading scene instead of the game screen; then the work, so the scene is up first)
    UI.achDraw()                                     -- (an achievement that came with the shift start shows over it)
    UI.loadWork()
    gfx.setBackgroundColor(WHITE); gfx.setColor(BLACK); gfx.setImageDrawMode(gfx.kDrawModeCopy)
    return
  end
  if state == STATE_MENU then
    if UI.settings then UI.drawSettings() elseif UI.ach then UI.drawAch() else drawMenu() end
  elseif state == STATE_PLAY then
    if UI.ach then UI.drawAch() else drawPlay() end
  elseif state == STATE_ENTRY then
    drawEntry()
  elseif state == CAFE.STATE then
    CAFE.draw()
  else
    drawBoard()
  end
  UI.drawFade()
  UI.achDraw()
  if pd.drawFPS and state == STATE_PLAY and CAFE.rich() then pd.drawFPS(372, 228) end     -- test cheat save: show the frame rate
  if state == STATE_PLAY and not UI.color then UI.livePace(pd.getCurrentTimeMilliseconds() - now) end
end
