-- Coffee Please!!!
-- by Christian G   (version 3.5)
--
-- A tiny coffee-shop game for the Playdate.
-- Ring them up, pour the coffee, mix in milk / sugar / espresso / ice, serve it,
-- ring the bell. Two ways to play:
--   RUSH HOUR    - open 7 AM to 2 PM, a fast time-limited shift
--   EVENING CHILL - open 4 PM to 12 AM, no timer: wash cups between customers

import "CoreLibs/graphics"
import "CoreLibs/ui"

local pd <const> = playdate
local gfx <const> = pd.graphics
local snd <const> = pd.sound

----------------------------------------------------------------------
-- Tuning knobs: change these numbers to adjust how the game feels
----------------------------------------------------------------------
local SECONDS_PER_HOUR <const> = 30    -- real seconds for one in-game hour
local OPEN_HOUR        <const> = 7     -- 7 AM
local CLOSE_HOUR       <const> = 14    -- 2 PM
local PATIENCE_SECONDS <const> = 75    -- how long a customer waits at the counter
local LINE_PATIENCE    <const> = 2.0   -- people in line are this many times more patient
local LINE_MAX         <const> = 3     -- people who can wait behind the one ordering
local TIP_MAX          <const> = 250   -- best possible tip, in cents
local WALK_SPEED       <const> = 110   -- barista speed (pixels per second)
local CUST_SPEED       <const> = 140   -- customer speed (pixels per second)
local RECEIPT_CRANK    <const> = 360   -- crank degrees to print the receipt
local MIX_CRANK        <const> = 720   -- crank degrees to mix the drink
local BELL_CRANK       <const> = 270   -- crank degrees to ring the bell
local POUR_RATE_MIN    <const> = 0.25  -- coffee fill per second (gentle tilt)
local POUR_RATE_MAX    <const> = 0.36  -- coffee fill per second (full tilt)
local DINE_IN_CHANCE   <const> = 0.65  -- chance a customer wants to sit down
local STAY_MIN         <const> = 40    -- seconds a customer stays seated (min)
local STAY_MAX         <const> = 90    -- seconds a customer stays seated (max)
local MUSIC_VOLUME     <const> = 0.85   -- the cafe music (0 to 1)
local BEEP_GAIN        <const> = 0.45   -- how loud the little beeps are (0 to 1)

-- Evening Chill mode
local CHILL_ARRIVE_MIN   <const> = 22    -- seconds between customers (min)
local CHILL_ARRIVE_SPAN  <const> = 14    -- ...plus up to this much extra
local CHILL_PATIENCE     <const> = 110   -- how long a customer waits at the counter
local CHILL_DINE_IN      <const> = 0.85  -- chance a customer wants to sit down
local CHILL_STAY_MIN     <const> = 45
local CHILL_STAY_MAX     <const> = 100
local CUPS_TOTAL         <const> = 5     -- ceramic cups in the whole shop
local DISH_CRANK         <const> = 540   -- crank degrees to scrub one cup clean
local COFFEE_KINDS_IN_RUSH <const> = false   -- true = matcha/decaf in Rush Hour too
local KINDS        <const> = { "coffee", "matcha", "decaf", "tea" }
local KIND_WEIGHTS <const> = { 46, 20, 17, 17 }
local KIND_PRICE   <const> = { coffee = 0, matcha = 100, decaf = 0, tea = 50 }   -- cents extra
local WIN, UI, CAFE = {}, {}, {}      -- grouped to stay under the 200-locals limit
UI.KIND_NAME = { coffee = "Coffee", matcha = "Matcha", decaf = "Decaf", tea = "Tea" }

-- How likely each amount is in an order (index 1 = none, 2 = one, 3 = two, ...)
local MILK_WEIGHTS  <const> = { 35, 35, 22, 8 }
local SUGAR_WEIGHTS <const> = { 35, 30, 25, 10 }
local SHOT_WEIGHTS  <const> = { 60, 30, 10 }
local ICE_WEIGHTS   <const> = { 55, 25, 14, 6 }

-- The starting high score table (scores are in cents)
local DEFAULT_SCORES <const> = {
  { n = "Grace",       s = 6000 },   -- needs a near-flawless day
  { n = "Christian",   s = 5300 },
  { n = "Kelly",       s = 4600 },
  { n = "Jay",         s = 3900 },
  { n = "Bellasmella", s = 3300 },
  { n = "Rosie",       s = 2700 },
  { n = "Otis",        s = 2200 },
  { n = "Juno",        s = 1700 },
  { n = "Mabel",       s = 1200 },
  { n = "Pip",         s = 800 },
}

-- Evening Chill has no timer, so its table is about how long you keep going
local DEFAULT_CHILL_SCORES <const> = {
  { n = "Grace",       s = 35000 },   -- roughly 25 minutes of near-perfect service
  { n = "Christian",   s = 27000 },
  { n = "Kelly",       s = 20500 },
  { n = "Jay",         s = 15500 },
  { n = "Bellasmella", s = 11500 },
  { n = "Rosie",       s = 8000 },
  { n = "Otis",        s = 5500 },
  { n = "Juno",        s = 3500 },
  { n = "Mabel",       s = 2000 },
  { n = "Pip",         s = 1000 },
}

----------------------------------------------------------------------
-- Basics
----------------------------------------------------------------------
local BLACK <const> = gfx.kColorBlack
local WHITE <const> = gfx.kColorWhite
local CHECK = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }

local fontNormal = gfx.getSystemFont()
local fontBold = gfx.getSystemFont(gfx.font.kVariantBold)

local function clamp(v, lo, hi)
  if v < lo then return lo elseif v > hi then return hi end
  return v
end

-- cents -> "$3.75"
local function money(c)
  c = math.floor(c + 0.5)
  return string.format("$%d.%02d", c // 100, c % 100)
end

local function clockString(t)
  local hr = OPEN_HOUR + math.floor(t / SECONDS_PER_HOUR)
  if hr > CLOSE_HOUR then hr = CLOSE_HOUR end
  local h12 = hr % 12
  if h12 == 0 then h12 = 12 end
  local ap = "AM"
  if hr >= 12 then ap = "PM" end
  return string.format("%d:00 %s", h12, ap)
end

local function drawT(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawText(str, x, y)
end
local function drawTC(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.center)
end
local function drawTR(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.right)
end

-- more fill patterns (the three drinks look different in the cup)
local DIAG   = { 0xEE, 0xDD, 0xBB, 0x77, 0xEE, 0xDD, 0xBB, 0x77 }
local STRIPE = { 0xCC, 0xCC, 0x33, 0x33, 0xCC, 0xCC, 0x33, 0x33 }
local TEA = { 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }
local DRINK_PATTERN = { coffee = CHECK, matcha = DIAG, decaf = STRIPE, tea = TEA }

-- a little ceramic cup (x, y = top-left, s = size 1 small .. 3 big)
local function drawCup(x, y, s, dirty)
  local w, h = 8 * s, 8 * s
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(s >= 2 and 2 or 1)
  gfx.drawRect(x, y, w, h)
  gfx.drawCircleAtPoint(x + w + s, y + h // 2, s + 1)
  gfx.setLineWidth(1)
  if dirty then
    gfx.setPattern(CHECK)
    gfx.fillRect(x + 2, y + h // 2, w - 4, h // 2 - 2)
    gfx.setColor(BLACK)
  end
end

-- a coffee bean (x, y = centre)
local function drawBean(x, y, s)
  s = s or 1
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x - 5 * s, y - 3 * s, 10 * s, 6 * s)
  gfx.setColor(WHITE)
  gfx.drawLine(x - 4 * s, y + s, x + 4 * s, y - s)
  gfx.setColor(BLACK)
end

-- a dashed outline (the empty spot on a shelf)
local function dashedRect(x, y, w, h)
  gfx.setColor(BLACK)
  for dx = 0, w - 3, 6 do
    gfx.drawLine(x + dx, y, x + dx + 2, y)
    gfx.drawLine(x + dx, y + h, x + dx + 2, y + h)
  end
  for dy = 0, h - 3, 6 do
    gfx.drawLine(x, y + dy, x, y + dy + 2)
    gfx.drawLine(x + w, y + dy, x + w, y + dy + 2)
  end
end

----------------------------------------------------------------------
-- Sound: little synth blips, recorded-style effects, and the cafe music
----------------------------------------------------------------------
local function newSynth(wave)
  local ok, s = pcall(function() return snd.synth.new(wave) end)
  if ok then return s end
  return nil
end
local synthSq   = newSynth(snd.kWaveSquare)
local synthSine = newSynth(snd.kWaveSine)

local function play(synth, hz, len, vol, when)
  if synth == nil then return end
  vol = (vol or 0.3) * BEEP_GAIN          -- beeps stay quiet; the music is the star
  pcall(function()
    if when then synth:playNote(hz, vol, len, when) else synth:playNote(hz, vol, len) end
  end)
end

local function sfxTick()  play(synthSq, 1800, 0.02, 0.10) end
local function sfxPop()   play(synthSine, 520, 0.08, 0.30) end
local function sfxWrong() play(synthSq, 110, 0.25, 0.30) end
local function sfxGood()
  play(synthSq, 660, 0.07, 0.25)
  play(synthSq, 990, 0.10, 0.25, 0.08)
end
local function sfxHello()
  play(synthSine, 880, 0.10, 0.30)
  play(synthSine, 1175, 0.20, 0.30, 0.10)
end

-- sound effect files live in the "sounds" folder
local sfx = {}
for _, name in ipairs({ "receipt", "receipt2", "pour", "pour2", "mixer", "plate", "bell", "slide", "tip", "chime", "slurp", "click1", "click2", "click3", "click4", "cup1", "cup2", "dash1", "dash2", "ice1", "ice2", "ice3", "cleaning", "sink" }) do
  local ok, sp = pcall(function() return snd.sampleplayer.new("sounds/" .. (name == "receipt2" and "receipt" or name)) end)
  if ok and sp then sfx[name] = sp end
end

local function sfxPlay(name, loop, vol, rate)
  local sp = sfx[name]
  if sp == nil then return end
  pcall(function()
    if vol then sp:setVolume(vol) end
    if rate then sp:setRate(rate) end
    if loop then
      if not sp:isPlaying() then sp:play(0) end
    else
      sp:play(1)
    end
  end)
end

-- the pretty register chime when a shift starts
local function sfxStart()
  if sfx.chime then
    sfxPlay("chime", false, 0.9)
  else
    play(synthSine, 1568, 0.25, 0.5)
    play(synthSine, 2093, 0.25, 0.5, 0.12)
    play(synthSine, 2637, 0.40, 0.5, 0.24)
  end
end

local function sfxStop(name)
  local sp = sfx[name]
  if sp then pcall(function() sp:stop() end) end
  if name == "pour" and sfx.pour2 then pcall(function() sfx.pour2:stop() end) end
end

-- the coffee pour: one of the two pour recordings, left alone while it plays
local function sfxPour()
  local a, b = sfx.pour, sfx.pour2
  if (a and a:isPlaying()) or (b and b:isPlaying()) then return end
  local name = (b and math.random() < 0.5) and "pour2" or "pour"
  sfxPlay(name, false, 1.0, 1.0)
end

-- cups clinking and ice cubes: one of the recordings, picked at random
local function sfxRandom(names)
  local list = {}
  for _, n in ipairs(names) do if sfx[n] then list[#list + 1] = n end end
  if #list == 0 then return false end
  sfxPlay(list[math.random(#list)], false, 1.0)
  return true
end
local function sfxCup() if not sfxRandom({ "cup1", "cup2" }) then sfxPlay("plate", false, 0.6) end end
local function sfxClick()
  if not sfxRandom({ "click1", "click2", "click3", "click4" }) then play(synthSq, 1200, 0.03, 0.15) end
end
local function sfxDash() if not sfxRandom({ "dash1", "dash2" }) then sfxPop() end end   -- a second of pouring
local function sfxIce() if not sfxRandom({ "ice1", "ice2", "ice3" }) then sfxPop() end end

-- the slurp that greets you when the game launches
if sfx.slurp then sfxPlay("slurp", false, 1.0) end

-- background music (loops forever)
do
  local ok, fp = pcall(function() return snd.fileplayer.new("music/cafe") end)
  if ok and fp then
    pcall(function()
      fp:setVolume(MUSIC_VOLUME)
      fp:play(0)
    end)
  end
end

----------------------------------------------------------------------
-- Layout
----------------------------------------------------------------------
local PLAYER_Y <const> = 58    -- the barista walks along behind the counter
local WALK_MIN <const> = 28
local WALK_MAX = 344
local JAR_X    = 368          -- the tip jar

local REG_X, REG_Y = 62, 136      -- where the customer being served stands
local PICK_X, PICK_Y = 308, 136   -- where they wait for their drink
local DOOR_X <const> = 28         -- customers walk in and out here (bottom left)
local LINE_SLOTS = { { 62, 166 }, { 62, 196 }, { 62, 226 } }
local DISH_X = 332                -- Evening Chill: where used cups get dropped off

local RUSH_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 62,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 144, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 226, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 308, stage = 4 },
}
-- Evening Chill squeezes in a dish bin, and the tip jar moves right
local CHILL_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 56,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 128, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 200, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 272, stage = 4 },
  { id = "dishes",   name = "Dishes",   label = "DISHES",   x = 332 },
}
local STATIONS = RUSH_STATIONS
local STAGE_ST = {}               -- STAGE_ST[1..4] = the station for each order step

local function stationById(id)
  for _, st in ipairs(STATIONS) do
    if st.id == id then return st end
  end
  return nil
end

local function setLayout(mode)
  do
    STATIONS = CHILL_STATIONS
    JAR_X, WALK_MAX = 384, 356
    REG_X, PICK_X, DISH_X = 56, 272, 332
    LINE_SLOTS = { { 56, 166 }, { 56, 196 }, { 56, 226 } }
  end
  STAGE_ST = {}
  for _, st in ipairs(STATIONS) do
    if st.stage then STAGE_ST[st.stage] = st end
  end
end
setLayout("rush")

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "ENT" }
local GREETS = { "Coffee please!", "One coffee, please!", "Morning! Coffee?", "Coffee time!" }

-- Round tables and where people sit (the last table is in the corner nook)
local TABLES = {
  { x = 132, y = 208, r = 13 }, { x = 186, y = 208, r = 13 },
  { x = 240, y = 208, r = 13 }, { x = 294, y = 208, r = 13 },
  { x = 350, y = 180, r = 13 },            -- the table inside the nook
}
local SEATS = {
  { x = 115, y = 208, t = 1 }, { x = 149, y = 208, t = 1 },
  { x = 169, y = 208, t = 2 }, { x = 203, y = 208, t = 2 },
  { x = 223, y = 208, t = 3 }, { x = 257, y = 208, t = 3 },
  { x = 277, y = 208, t = 4 }, { x = 311, y = 208, t = 4 },
  -- the L-shaped nook: three seats up the wall, two along the bottom
  { x = 386, y = 164, t = 5 }, { x = 386, y = 186, t = 5 }, { x = 386, y = 212, t = 5 },
  { x = 362, y = 218, t = 5 }, { x = 338, y = 218, t = 5 },
}

----------------------------------------------------------------------
-- High scores (saved on the Playdate)
----------------------------------------------------------------------
local boards = { rush = {}, chill = {} }     -- sorted lists of { n = name, s = cents }
local lastInitials = "AAA"

local function saveScores()
  pd.datastore.write({ v = 5, rush = boards.rush, chill = boards.chill, last = lastInitials })
end

do
  local function take(dst, src)
    if type(src) ~= "table" then return end
    for _, e in ipairs(src) do
      if type(e) == "table" and type(e.n) == "string" and type(e.s) == "number" then
        dst[#dst + 1] = { n = e.n, s = e.s }
      end
    end
  end
  local saved = pd.datastore.read()
  if saved then
    if saved.v == 5 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
    elseif saved.v == 4 then
      take(boards.chill, saved.chill)     -- Rush Hour got harder in 2.3: fresh table
    elseif saved.v == 3 then
      take(boards.rush, saved.scores)       -- version 1.x saved only the Rush Hour table
    end
    if type(saved.last) == "string" and #saved.last == 3 then lastInitials = saved.last end
  end
  if #boards.rush == 0 then
    for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
  end
  if #boards.chill == 0 then
    for _, e in ipairs(DEFAULT_CHILL_SCORES) do boards.chill[#boards.chill + 1] = { n = e.n, s = e.s } end
  end
  table.sort(boards.rush, function(a, b) return a.s > b.s end)
  table.sort(boards.chill, function(a, b) return a.s > b.s end)
end

-- returns the rank (1 = best) the new score landed at
local function insertScore(mode, name, s)
  local list = boards[mode]
  local rank = #list + 1
  for i, e in ipairs(list) do
    if s > e.s then rank = i; break end
  end
  table.insert(list, rank, { n = name, s = s })
  while #list > 100 do table.remove(list) end
  lastInitials = name
  saveScores()
  return rank
end

----------------------------------------------------------------------
-- Game state
----------------------------------------------------------------------
local STATE_MENU  <const> = 1
local STATE_PLAY  <const> = 2
local STATE_ENTRY <const> = 3   -- closing time: type your initials
local STATE_BOARD <const> = 4   -- the high score table

local state = STATE_MENU
local frames = 0
local lastMs = pd.getCurrentTimeMilliseconds()
local G = nil                   -- the current day (nil on the title screen)
local board = { mode = "view", rank = nil, m = "rush", view = "rush", t = 0 }
local entry = { letters = { 0, 0, 0 }, cur = 1, crank = 0 }
local menuSel = 1                   -- title screen: 1 Rush Hour, 2 Evening Chill, 3 High scores

-- screen fades: everything that changes screen goes through transitionTo()
local FADE_SECONDS <const> = 0.5
local trans = nil                   -- { phase = "out" or "in", t = seconds, fn = function }
local endDay, setShiftMenu          -- (defined further down)

local function transitionTo(fn)
  if trans == nil then trans = { phase = "out", t = 0, fn = fn } end
end

-- mix the clock and frame count into the random seed so every day differs
local function reseed()
  local secs, ms = pd.getSecondsSinceEpoch()
  local mixed = (secs or 0) + (ms or 0) * 7 + pd.getCurrentTimeMilliseconds() * 13 + frames * 101
  math.randomseed(math.floor(mixed))
  math.random(); math.random(); math.random()
end

-- The window: the weather changes now and then, people stroll past
WIN.FX = { "rain", "wind", "leaves" }

function WIN.newWindow()
  local fx = { rain = false, wind = false, leaves = false }
  local r, n = math.random(), 0
  if r < 0.22 then n = 0 elseif r < 0.67 then n = 1 elseif r < 0.90 then n = 2 else n = 3 end
  local pool = { 1, 2, 3 }
  for _ = 1, n do
    local k = table.remove(pool, math.random(#pool))
    fx[WIN.FX[k]] = true
  end
  return { fx = fx, nextChange = 70 + math.random() * 70, acc = { rain = 0, wind = 0, leaves = 0 },
           parts = {}, walkers = {}, walkIn = 4 + math.random() * 8 }
end

function WIN.updateWindow(dt)
  local w = G.win
  w.nextChange = w.nextChange - dt
  if w.nextChange <= 0 then                       -- slow: one effect flips every 70-140 s
    local k = WIN.FX[math.random(#WIN.FX)]
    w.fx[k] = not w.fx[k]
    w.nextChange = 70 + math.random() * 70
  end
  local rate = { rain = 16, wind = 1.5, leaves = 0.9 }
  for _, k in ipairs(WIN.FX) do
    if w.fx[k] then w.acc[k] = w.acc[k] + rate[k] * dt end
    while w.acc[k] >= 1 do
      w.acc[k] = w.acc[k] - 1
      if k == "rain" then
        local sl = w.fx.wind and 14 or -3
        w.parts[#w.parts + 1] = { k = "rain", x = 12 + math.random() * 56, y = 21, vx = sl, vy = 70 + math.random() * 25 }
      elseif k == "wind" then
        w.parts[#w.parts + 1] = { k = "wind", x = 8, y = 26 + math.random() * 18, vx = 26 + math.random() * 14, vy = 0,
                                  ph = math.random() * 6 }
      else
        w.parts[#w.parts + 1] = { k = "leaf", x = 15 + math.random() * 50, y = 21, vx = 0,
                                  vy = 12 + math.random() * 8, ph = math.random() * 6 }
      end
    end
  end
  for i = #w.parts, 1, -1 do
    local q = w.parts[i]
    if q.k == "leaf" then
      q.ph = q.ph + dt * 2.2
      q.x = q.x + math.sin(q.ph) * 12 * dt + (w.fx.wind and 10 * dt or 0)
    elseif q.k == "wind" then
      q.ph = q.ph + dt * 4
      q.x = q.x + q.vx * dt
    else
      q.x = q.x + q.vx * dt
    end
    q.y = q.y + q.vy * dt
    if q.x > 76 or q.x < 6 or q.y > 49 then table.remove(w.parts, i) end
  end
  -- someone walks by now and then (never a crowd)
  w.walkIn = w.walkIn - dt
  if w.walkIn <= 0 and #w.walkers == 0 then
    local dir = (math.random() < 0.5) and 1 or -1
    w.walkers[1] = { x = dir == 1 and 6 or 76, dir = dir, speed = 15 + math.random() * 8, t = 0,
                     umbrella = w.fx.rain }
    w.walkIn = 14 + math.random() * 18
  end
  for i = #w.walkers, 1, -1 do
    local q = w.walkers[i]
    q.x = q.x + q.dir * q.speed * dt
    q.t = q.t + dt * 9
    if q.x < 2 or q.x > 80 then table.remove(w.walkers, i) end
  end
end

local function newGame(mode)
  mode = mode or "rush"
  reseed()
  CAFE.applyLayout((mode == "cafe") and CAFE.cur or nil)
  setLayout(mode)
  G = {
    mode = mode,
    t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
    px = STATIONS[1].x, moving = false, walk = 0,
    cupMax = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL,
    seatLimit = (mode == "cafe") and CAFE.seatsOf(CAFE.cur.seatStep) or #SEATS,
    cafe = (mode == "cafe") and CAFE.cur or nil,
    cups = { shelf = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL, dirty = 0, hand = 0 },   -- dishes
    sink = { state = "empty", progress = 0, angle = 0, t = 0 },
    lastCount = nil, ending = false,
    flow = { m = 0.5, target = 0.5, timer = 20 },
    pets = (mode == "cafe") and CAFE.makePets() or nil,
    win = WIN.newWindow(),
    sel = "down",       -- Evening Chill: "up" = the wall shelf, "down" = the counter
    st = nil,           -- which station panel is open ("register", ...)
    cust = nil,         -- the customer being served right now
    line = {},          -- people waiting in line (line[1] is next)
    others = {},        -- people walking to a seat, sitting, or leaving
    seats = {},         -- seats[i] = the customer sitting there
    arriveIn = 0.8,     -- seconds until the next customer shows up
    stepT = 0,          -- short pause before the next person steps up
    door = 0,           -- 0 = closed, 1 = open
    popups = {},        -- floating "+$2.00" texts
    msg = nil, msgT = 0,
    endT = 0,
  }
  setShiftMenu(mode ~= "rush", mode == "cafe")
end

local function say(str)
  G.msg = str
  G.msgT = 2.2
end

local function addPopup(str, x, y, life, small)
  G.popups[#G.popups + 1] = { s = str, x = x, y = y, t = 0, life = life or 1.8, small = small }
end

----------------------------------------------------------------------
-- Crank helper (shows the "use the crank" hint if the crank is docked)
----------------------------------------------------------------------
local function crankHelpStart()
  local ci = pd.ui and pd.ui.crankIndicator
  if ci and ci.start then ci:start() end
end

local function crankHelpDraw()
  if not pd.isCrankDocked() then return end
  local ci = pd.ui and pd.ui.crankIndicator
  if ci == nil then return end
  if ci.update then ci:update() elseif ci.draw then ci:draw() end
end

----------------------------------------------------------------------
-- Customers
----------------------------------------------------------------------
local function weighted(w)
  local total = 0
  for _, v in ipairs(w) do total = total + v end
  local r = math.random() * total
  for i, v in ipairs(w) do
    r = r - v
    if r < 0 then return i - 1 end
  end
  return #w - 1
end

-- lines of text for the speech bubble (after the greeting)
local function orderLines(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. " espresso" end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 then
    if o.kind and o.kind ~= "coffee" then return { "Just plain, thanks!" } end
    return { "Just black, thanks!" }
  end
  if #items == 1 then return { "With " .. items[1] } end
  if #items == 2 then return { "With " .. items[1] .. " & " .. items[2] } end
  if #items == 3 then return { "With " .. items[1] .. ", " .. items[2], "& " .. items[3] } end
  return { "With " .. items[1] .. ", " .. items[2] .. ",", items[3] .. " & " .. items[4] }
end

-- short version for the panel headers
local function orderShort(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. (o.shot == 1 and " shot" or " shots") end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 and o.kind == "coffee" then return "Black coffee" end
  table.insert(items, 1, UI.KIND_NAME[o.kind or "coffee"])
  return table.concat(items, ", ")
end

local function newCustomer()
  local o = { milk = weighted(MILK_WEIGHTS), sugar = weighted(SUGAR_WEIGHTS),
              shot = weighted(SHOT_WEIGHTS), ice = weighted(ICE_WEIGHTS) }
  -- keep orders sensible: nobody wants more than 5 extras
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1
    elseif o.ice > 0 then o.ice = o.ice - 1
    elseif o.milk > 0 then o.milk = o.milk - 1
    else o.shot = o.shot - 1 end
  end
  local chill = (G ~= nil and G.mode ~= "rush")
  o.kind = KINDS[weighted(KIND_WEIGHTS) + 1]
  if o.kind == "matcha" or o.kind == "tea" or o.kind == "decaf" then o.shot = 0 end      -- no espresso in those
  local greet = GREETS[math.random(#GREETS)]
  if o.kind == "matcha" then greet = "One matcha, please!"
  elseif o.kind == "decaf" then greet = "Decaf, please!"
  elseif o.kind == "tea" then greet = "Tea, please!" end
  return {
    x = DOOR_X, y = 258, path = {}, walk = 0,
    state = "line",       -- line, active, toSeat, seated, leaving
    stage = 0,            -- 0 stepping up, 1 register, 2 coffee, 3 mixer, 4 serve
    order = o,
    price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind],   -- cents
    greet = greet,
    look = math.random(1, 4),
    patience = 1.0,       -- 1 = fresh, 0 = walks out
    q = 1.0,              -- order quality (mistakes lower it, it decides the tip)
    dine = math.random() < (chill and CHILL_DINE_IN or DINE_IN_CHANCE) and (G == nil or G.seatLimit > 0),
    hasCup = false,       -- Evening Chill: carrying one of the shop's ceramic cups
    seat = nil, stay = 0,
    reg = { digits = "", state = "type", cur = 5, crank = 0, flash = 0, tick = 0 },
    cof = { fill = 0, tilt = 0, base = nil,
            phase = "pick", pick = nil },
    mix = { milk = 0, sugar = 0, shot = 0, ice = 0, phase = 1, progress = 0, angle = 0, tick = 0, hold = 0 },
    srv = { phase = 1, slide = 0, crank = 0, ding = 0, tick = 0, recent = 0 },
  }
end

-- walking: customers follow a list of waypoints
local function routeTo(c, x, y)
  if c.y > 236 then
    c.path = { { DOOR_X, 228 }, { x, y } }     -- still outside: come in through the door first
  else
    c.path = { { x, y } }
  end
end

local function moveAlong(c, dt)
  local p = c.path[1]
  if p == nil then return end
  local dx, dy = p[1] - c.x, p[2] - c.y
  local d = math.sqrt(dx * dx + dy * dy)
  local step = CUST_SPEED * dt
  if d <= step then
    c.x, c.y = p[1], p[2]
    table.remove(c.path, 1)
    if p[3] == "drop" and c.hasCup then          -- leave the used cup in the dish bin
      c.hasCup = false
      G.cups.dirty = G.cups.dirty + 1
      sfxPlay("plate", false, 0.5)
    end
  else
    c.x = c.x + dx / d * step
    c.y = c.y + dy / d * step
  end
  c.walk = c.walk + dt * 14
end

local function leaveRoute(c)
  c.state = "leaving"
  local p = {}
  local sx, sy = c.x, c.y
  if c.hasCup then
    p[#p + 1] = { DISH_X, 152, "drop" }        -- bring the cup back to the dish bin first
    sx, sy = DISH_X, 152
  end
  local lx = sx
  if lx < 96 then
    lx = 96                                    -- slip out sideways, not through the line
    p[#p + 1] = { lx, sy }
  end
  if sy < 232 then p[#p + 1] = { lx, 232 } end
  p[#p + 1] = { DOOR_X, 234 }
  p[#p + 1] = { DOOR_X, 270 }
  c.path = p
end

local function relineup()
  for i, c in ipairs(G.line) do routeTo(c, LINE_SLOTS[i][1], LINE_SLOTS[i][2]) end
end

local function freeSeat()
  local free = {}
  for i = 1, G.seatLimit do
    if G.seats[i] == nil then free[#free + 1] = i end
  end
  if #free == 0 then return nil end
  return free[math.random(#free)]
end

----------------------------------------------------------------------
-- Stations
----------------------------------------------------------------------
local function stopLoops(keepMixer)
  sfxStop("pour")
  if not keepMixer then sfxStop("mixer") end
  sfxStop("sink")
  sfxStop("cleaning")
end

local function closeStation(keepMixer)
  if G and G.st == "coffee" then pcall(pd.stopAccelerometer) end
  stopLoops(keepMixer)
  if G then G.st = nil end
end

local function nearStation()
  for _, st in ipairs(STATIONS) do
    if math.abs(G.px - st.x) <= 22 then return st end
  end
  return nil
end

-- Evening Chill: the cup shelf hangs on the wall above the barista
local SHELF_X1, SHELF_X2 = 104, 194
local function nearWall()
  return G.px >= SHELF_X1 and G.px <= SHELF_X2
end

-- true when the shelf (up) is what A would open, false when it's the counter (down)
local function shelfSelected()
  if not nearWall() then return false end
  return G.sel == "up" or nearStation() == nil
end

local function tryOpen(st)
  if st.id == "dishes" then                          -- no customer needed
    local sk = G.sink
    if sk.state == "empty" and G.cups.dirty == 0 then
      say("No dirty cups right now.")
      sfxWrong()
      return
    end
    G.st = st.id
    sfxClick()
    if sk.state == "empty" then                      -- just crank: the first dirty cup is already in the sink
      G.cups.dirty = G.cups.dirty - 1
      sk.state, sk.progress, sk.angle = "washing", 0, 0
      sfxCup()
    end
    if sk.state == "washing" then crankHelpStart() end
    return
  end
  local c = G.cust
  if c == nil or c.stage < 1 then
    say("Waiting for a customer...")
    return
  end
  if c.stage ~= st.stage then
    if c.stage > st.stage then
      say(st.name .. " is already done!")
      if st.id == "mixer" then CAFE.mistake(0.03) end        -- clicked the mixer out of habit
    else
      say("Do the " .. STAGE_ST[c.stage].name .. " first!")
    end
    sfxWrong()
    return
  end
  if st.id == "serve" and #c.path > 0 then
    say("They're still walking over!")
    return
  end
  if st.id == "register" and G.cups.hand > 0 then
    say("Put the clean cups on the shelf first!")
    sfxWrong()
    return
  end
  if st.id == "coffee" and c.dine and not c.hasCup then
    if G.cups.shelf > 0 then                      -- grab a clean cup from the shelf
      G.cups.shelf = G.cups.shelf - 1
      c.hasCup = true
      sfxCup()
    else
      c.dine = false
      say("Out of clean cups - take-out!")
    end
  end
  G.st = st.id
  sfxClick()
  if st.id == "serve" and c.srv.phase == 1 then
    c.srv.phase = 2                    -- A at the counter slides the plate right away
    sfxPlay("slide", false, 1.0)
  end
  if st.id == "coffee" then
    pd.startAccelerometer()
    c.cof.base = nil
  end
  if (st.id == "register" and c.reg.state == "crank")
      or (st.id == "mixer" and c.mix.phase == 2) then
    crankHelpStart()
  end
end

-- ---- the order is finished: pay, tip, send the customer off ----------
local function finishOrder(c)
  local q = clamp(c.q, 0, 1)
  local tip = 0
  if q >= 0.5 then
    local f = 0.4 + 0.6 * c.patience
    local pm = (G.mode == "cafe") and (1 + 0.15 * CAFE.petCount()) or 1      -- pets help the tips
    if c.dine then pm = pm * 1.3 end                                           -- dining in tips better
    tip = math.floor(TIP_MAX * q * q * f * pm / 25 + 0.5) * 25
  end
  G.cash = G.cash + c.price
  G.tips = G.tips + tip
  G.served = G.served + 1
  if G.mode == "cafe" then
    if q >= 0.75 then CAFE.addStars(0.04 + 0.02 * CAFE.petCount()) elseif q < 0.5 then CAFE.mistake(0.3) end
  end
  addPopup("+" .. money(c.price), stationById("register").x, 54, 1.8)
  if tip > 0 then
    addPopup("+" .. money(tip), JAR_X, 54, 2.2, true)
    sfxPlay("tip")
  else
    addPopup("no tip", JAR_X, 54, 1.8, true)
  end
  if q >= 0.95 then say("Perfect order!")
  elseif q >= 0.75 then say("Nice work!")
  elseif q >= 0.5 then say("Good enough.")
  else say("Ouch... that was off.") end

  closeStation()
  G.cust = nil
  G.stepT = 0.7
  -- some people sit down with their drink, some take it to go
  if c.dine then
    local s = freeSeat()
    if s then
      G.seats[s] = c
      c.seat = s
      c.state = "toSeat"
      c.path = { { SEATS[s].x, SEATS[s].y } }
    else
      leaveRoute(c)           -- no free seat: they head out
    end
  else
    leaveRoute(c)
  end
  G.others[#G.others + 1] = c
end

-- ---- 1. register -----------------------------------------------------
local function regPress(c, key)
  local r = c.reg
  if key == "DEL" then
    r.digits = string.sub(r.digits, 1, -2)
    sfxClick()
  elseif key == "ENT" then
    local val = tonumber(r.digits) or 0
    if val == c.price then
      r.state = "crank"
      crankHelpStart()
      sfxGood()
    else
      c.q = c.q - 0.2
      CAFE.mistake(0.05)
      r.digits = ""
      r.flash = 0.9
      sfxWrong()
    end
  else
    if #r.digits < 4 then r.digits = r.digits .. key end
    sfxClick()
  end
end

local function updateRegister(c, dt)
  local r = c.reg
  if r.flash > 0 then r.flash = r.flash - dt end
  if r.state == "type" then
    local col = (r.cur - 1) % 3
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if col == 0 then r.cur = r.cur + 2 else r.cur = r.cur - 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if col == 2 then r.cur = r.cur - 2 else r.cur = r.cur + 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      r.cur = r.cur - 3
      if r.cur < 1 then r.cur = r.cur + 12 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      r.cur = r.cur + 3
      if r.cur > 12 then r.cur = r.cur - 12 end
      sfxClick()
    end
    if pd.buttonJustPressed(pd.kButtonA) then regPress(c, KEYS[r.cur]) end
  else
    local ch = math.abs(pd.getCrankChange())
    r.crank = r.crank + ch
    r.tick = r.tick + ch
    if ch > 0.8 then
      r.hold = 0.15
      if not (sfx.receipt and sfx.receipt:isPlaying()) then sfxPlay("receipt", false, 1.0, 1.0) end   -- plays once, no loop
    else
      r.hold = (r.hold or 0) - dt
      if r.hold <= 0 and r.crank < RECEIPT_CRANK then sfxStop("receipt") end
    end
    if r.tick >= 30 then r.tick = r.tick - 30; sfxTick() end
    if r.crank >= RECEIPT_CRANK then
      c.stage = 2
      closeStation()
      routeTo(c, PICK_X, PICK_Y)      -- the customer drifts over to the pickup end
      say("Receipt printed!")
    end
  end
end

-- ---- 2. coffee ------------------------------------------------------
local PICK_BUTTONS = {
  { pd.kButtonUp, "coffee" }, { pd.kButtonRight, "matcha" },
  { pd.kButtonDown, "decaf" }, { pd.kButtonLeft, "tea" },
}

local function updateCoffee(c, dt)
  local f = c.cof
  if f.phase == "pick" then
    for _, pb in ipairs(PICK_BUTTONS) do
      if pd.buttonJustPressed(pb[1]) then f.pick = pb[2]; sfxClick() end
    end
    if pd.buttonJustPressed(pd.kButtonA) then
      if f.pick == nil then
        say("Pick a drink first!")
        sfxWrong()
      else
        f.phase = "pour"
        f.base = nil
        if f.pick ~= c.order.kind then c.q = c.q - 0.35; CAFE.mistake(0.12) end    -- wrong drink!
        sfxClick()
      end
    end
    return
  end
  local ax, ay = 0, 0
  if pd.accelerometerIsRunning() then
    local x, y = pd.readAccelerometer()
    ax, ay = x or 0, y or 0
  end
  -- the pose you were holding when you stepped up counts as "level"
  if f.base == nil then f.base = { ax, ay } end
  local d = math.sqrt((ax - f.base[1]) ^ 2 + (ay - f.base[2]) ^ 2)
  local t = clamp((d - 0.2) / 0.5, 0, 1)
  if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
  f.tilt = t
  if t > 0 and f.fill < 1.25 then
    local rate = POUR_RATE_MIN + (POUR_RATE_MAX - POUR_RATE_MIN) * t
    f.fill = math.min(1.25, f.fill + rate * dt)
    sfxPour()
  else
    sfxStop("pour")
  end
  if pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB) then
    if f.fill < 0.2 then
      say("Pour some coffee first!")
      sfxWrong()
    else
      local err = math.abs(f.fill - 1.0)
      local pen = 0
      if err > 0.06 then pen = math.min(0.45, (err - 0.06) * 1.6) end
      if f.fill > 1.2 then pen = pen + 0.1 end   -- it spilled over
      c.q = c.q - pen
      if pen > 0 then CAFE.mistake(0.04 + pen * 0.2) end     -- missed the mark / overflowed
      sfxClick()
      local o = c.order
      if o.milk + o.sugar + o.shot + o.ice == 0 then
        c.stage = 4                      -- nothing to mix in: straight to pick up
      else
        c.stage = 3
      end
      closeStation()
      sfxGood()
    end
  end
end

-- ---- 3. mixer --------------------------------------------------------
local function updateMixer(c, dt)
  local m = c.mix
  if m.phase == 1 then
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if m.milk < 4 then m.milk = m.milk + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if m.sugar < 4 then m.sugar = m.sugar + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      if m.shot < 4 then m.shot = m.shot + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      if m.ice < 4 then m.ice = m.ice + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonA) then
      m.phase = 2
      crankHelpStart()
      sfxClick()
    end
  else
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    m.angle = m.angle + change
    m.progress = m.progress + ch / MIX_CRANK
    m.tick = m.tick + ch
    if m.tick >= 40 then m.tick = m.tick - 40; sfxTick() end
    -- electric mixer noise while you crank (faster crank = higher whirr)
    if ch > 0.8 then
      m.hold = 0.15
      if not (sfx.mixer and sfx.mixer:isPlaying()) then sfxPlay("mixer", false, 1.0, 1.0) end
    else
      m.hold = m.hold - dt
      if m.hold <= 0 and m.progress < 1 then sfxStop("mixer") end
    end
    if m.progress >= 1 then
      m.progress = 1
      local o = c.order
      local off = math.abs(m.milk - o.milk) + math.abs(m.sugar - o.sugar)
                + math.abs(m.shot - o.shot) + math.abs(m.ice - o.ice)
      c.q = c.q - 0.2 * off
      if off > 0 then CAFE.mistake(math.min(0.2, 0.04 * off)) end   -- wrong or missing ingredients
      c.stage = 4
      closeStation(true)               -- the mixer winds down by itself
      sfxGood()
    end
  end
end

-- ---- 4. serve + bell -------------------------------------------------
local function updateServe(c, dt)
  local s = c.srv
  if s.phase == 1 then
    s.phase = 2                       -- (safety: never wait for a second A)
  elseif s.phase == 2 then
    s.slide = math.min(1, s.slide + dt / 0.35)
    s.recent = s.recent * 0.85
    -- the plate has to land before the bell can be rung
    if pd.buttonJustPressed(pd.kButtonA) and s.slide >= 1 then
      s.phase = 3
      s.ding = 0.9
      sfxPlay("bell", false, 1.0)                 -- ding!
    end
  else
    s.ding = s.ding - dt
    if s.ding <= 0 then finishOrder(c) end
  end
end

-- ---- Evening Chill: dish bin and cup shelf ------------------------------
local function updateDishes(dt)
  local s, cu = G.sink, G.cups
  sfxPlay("sink", true, 0.6)                    -- the tap is already dripping when you open it
  if s.state == "empty" then
    sfxStop("cleaning")
    if cu.dirty > 0 then                          -- (safety) a dirty cup hops straight in
      cu.dirty = cu.dirty - 1
      s.state, s.progress, s.angle = "washing", 0, 0
      sfxCup()
    else                                          -- all clean: the screen closes by itself
      closeStation()
    end
  elseif s.state == "washing" then
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    s.angle = s.angle + change
    s.progress = s.progress + ch / DISH_CRANK
    s.tick = (s.tick or 0) + ch
    if s.tick >= 40 then s.tick = s.tick - 40; sfxTick() end
    if ch > 0.8 then sfxPlay("cleaning", true, 1.0) else sfxStop("cleaning") end
    if s.progress >= 1 then
      s.progress = 1
      s.state, s.t = "sparkle", 0
      cu.hand = cu.hand + 1                 -- the clean cup is in your hand right now
      sfxStop("cleaning")
      sfxGood()
      sfxCup()
    end
  else
    s.t = s.t + dt
    if s.t >= 0.8 then
      if cu.dirty > 0 then                  -- the next dirty cup hops into the sink
        cu.dirty = cu.dirty - 1
        s.state, s.progress, s.angle = "washing", 0, 0
      else
        s.state = "empty"
      end
    end
  end
end

local function updateShelf(dt)
  local cu = G.cups
  if pd.buttonJustPressed(pd.kButtonA) then
    if cu.hand > 0 and cu.shelf < G.cupMax then
      cu.hand = cu.hand - 1
      cu.shelf = cu.shelf + 1
      sfxCup()
    else
      say("You're not holding any cups.")
      sfxWrong()
    end
  end
end

local function updateStation(dt)
  if G.st == "dishes" or G.st == "shelf" then
    -- shelf with nothing left to place: A, B or the d-pad all step away from it
    local anyPad = pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
                or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight)
    if G.st == "shelf" and G.cups.hand == 0 and (anyPad or pd.buttonJustPressed(pd.kButtonA)) then
      closeStation()
      sfxClick()
      return
    end
    if pd.buttonJustPressed(pd.kButtonB) or (G.st == "dishes" and anyPad) then   -- walk away any time
      sfxStop("cleaning")
      closeStation()
      sfxClick()
      return
    end
    if G.st == "dishes" then updateDishes(dt) else updateShelf(dt) end
    return
  end
  local c = G.cust
  if c == nil then closeStation(); return end
  local locked = (G.st == "serve" and c.srv.phase == 3)
  local pouring = (G.st == "coffee" and c.cof.phase == "pour")   -- B = A while pouring
  if pd.buttonJustPressed(pd.kButtonB) and not locked and not pouring then
    sfxStop("receipt")
    closeStation()
    sfxClick()
    return
  end
  if G.st == "register" then updateRegister(c, dt)
  elseif G.st == "coffee" then updateCoffee(c, dt)
  elseif G.st == "mixer" then updateMixer(c, dt)
  elseif G.st == "serve" then updateServe(c, dt) end
end

----------------------------------------------------------------------
-- Updating the shop: arrivals, the line, seating, the door
----------------------------------------------------------------------
-- customers arrive faster during the morning and lunch rushes
local function patienceSecs()
  if G.mode == "cafe" then return 60 + 20 * G.cafe.stars end      -- a minute, plus 20 s per star
  if G.mode ~= "rush" then return CHILL_PATIENCE end
  return PATIENCE_SECONDS
end

local function arrivalGap()
  if G.mode == "cafe" then return CAFE.gap(24 - 2.6 * G.cafe.stars, 10 - G.cafe.stars) end   -- more stars, more customers
  if G.mode == "chill" then return CAFE.gap(CHILL_ARRIVE_MIN, CHILL_ARRIVE_SPAN) end
  local hourF = G.t / SECONDS_PER_HOUR
  if (hourF >= 1 and hourF < 2.5) or (hourF >= 5 and hourF < 6.5) then
    return 8 + math.random() * 6
  end
  return 14 + math.random() * 12
end

local function updateOthers(dt)
  for i = #G.others, 1, -1 do
    local c = G.others[i]
    moveAlong(c, dt)
    if c.state == "toSeat" and #c.path == 0 then
      c.state = "seated"
      if G.mode ~= "rush" then
        c.stay = CHILL_STAY_MIN + math.random() * (CHILL_STAY_MAX - CHILL_STAY_MIN)
      else
        c.stay = STAY_MIN + math.random() * (STAY_MAX - STAY_MIN)
      end
    elseif c.state == "seated" then
      c.stay = c.stay - dt
      if c.stay <= 0 then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      end
    elseif c.state == "leaving" and #c.path == 0 then
      table.remove(G.others, i)
    end
  end
end

local function anyoneAtDoor()
  local function near(c)
    return #c.path > 0 and math.abs(c.x - DOOR_X) < 40 and c.y > 205
  end
  if G.cust and near(G.cust) then return true end
  for _, c in ipairs(G.line) do if near(c) then return true end end
  for _, c in ipairs(G.others) do if near(c) then return true end end
  return false
end

local function updateCustomers(dt)
  if G.mode ~= "rush" then CAFE.flowUpdate(dt) end
  -- someone new comes in (if the line has room)
  G.arriveIn = G.arriveIn - dt
  if G.arriveIn <= 0 then
    G.arriveIn = arrivalGap()
    if #G.line < LINE_MAX then
      local c = newCustomer()
      G.line[#G.line + 1] = c
      routeTo(c, LINE_SLOTS[#G.line][1], LINE_SLOTS[#G.line][2])
    end
  end

  -- the next person in line steps up to the register
  if G.cust == nil then
    G.stepT = G.stepT - dt
    if G.stepT <= 0 and #G.line > 0 then
      local c = table.remove(G.line, 1)
      c.state = "active"
      G.cust = c
      routeTo(c, REG_X, REG_Y)
      relineup()
    end
  end

  -- people waiting in line slowly lose patience
  for i = #G.line, 1, -1 do
    local c = G.line[i]
    moveAlong(c, dt)
    if #c.path == 0 then
      c.patience = c.patience - dt / (patienceSecs() * LINE_PATIENCE)
      if c.patience <= 0 then
        table.remove(G.line, i)
        G.missed = G.missed + 1
        leaveRoute(c)
        G.others[#G.others + 1] = c
        relineup()
        say("Someone gave up waiting!")
      end
    end
  end

  -- the person at the counter
  local c = G.cust
  if c then
    moveAlong(c, dt)
    if c.stage == 0 and #c.path == 0 then
      c.stage = 1
      sfxHello()
    end
    if c.stage >= 1 then
      c.patience = c.patience - dt / patienceSecs()
      if c.patience <= 0 then
        c.patience = 0
        G.missed = G.missed + 1
        say("A customer walked out!")
        if G.mode == "cafe" then CAFE.mistake(0.4) end
        sfxWrong()
        if c.hasCup then c.hasCup = false; G.cups.shelf = G.cups.shelf + 1 end   -- the cup goes back
        closeStation()
        G.cust = nil
        G.stepT = 0.6
        leaveRoute(c)
        G.others[#G.others + 1] = c
      end
    end
  end

  updateOthers(dt)

  -- the door swings open when someone is coming or going
  local want = anyoneAtDoor() and 1 or 0
  if G.door < want then G.door = math.min(want, G.door + dt * 5)
  elseif G.door > want then G.door = math.max(want, G.door - dt * 5) end
end

local function updateWalking(dt)
  local dir = 0
  if pd.buttonIsPressed(pd.kButtonLeft) then dir = -1
  elseif pd.buttonIsPressed(pd.kButtonRight) then dir = 1 end
  G.moving = (dir ~= 0)
  if G.moving then
    G.px = clamp(G.px + dir * WALK_SPEED * dt, WALK_MIN, WALK_MAX)
    G.walk = G.walk + dt * 14
  end
  -- Up picks the wall shelf, Down picks the counter below (Evening Chill)
  if not nearWall() then
    G.sel = "down"
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    G.sel = "up"
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonDown) then
    G.sel = "down"
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonA) then
    if shelfSelected() then
      G.st = "shelf"
      sfxClick()
    else
      local st = nearStation()
      if st then tryOpen(st) end
    end
  end
end

endDay = function()
  closeStation()
  setShiftMenu(false)
  if G.mode == "cafe" then CAFE.finish(); return end
  G.total = G.cash + G.tips
  G.endT = 0
  entry.cur = 1
  entry.crank = 0
  for i = 1, 3 do
    entry.letters[i] = string.byte(lastInitials, i) - 65
    if entry.letters[i] < 0 or entry.letters[i] > 25 then entry.letters[i] = 0 end
  end
  state = STATE_ENTRY
end

-- Evening Chill and the Cafe have no clock: the Menu button has an "End shift" item
-- (and the Cafe adds "Save & quit" under it)
local shiftItem = nil
setShiftMenu = function(on, withSave)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if UI.setTitleItem then UI.setTitleItem(not withSave) end
  if on and shiftItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("End shift", function()
        if state == STATE_PLAY and G and G.mode ~= "rush" and not G.ending then
          G.ending = true
          transitionTo(endDay)
        end
      end)
    end)
    if ok then shiftItem = item end
  elseif (not on) and shiftItem ~= nil then
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
  if withSave and CAFE.saveItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Save & quit", function() CAFE.saveQuit() end)
    end)
    if ok then CAFE.saveItem = item end
  elseif (not withSave) and CAFE.saveItem ~= nil then
    pcall(function() menu:removeMenuItem(CAFE.saveItem) end)
    CAFE.saveItem = nil
  end
end

local function updatePlay(dt)
  G.t = G.t + dt
  if G.mode == "rush" then
    local limit = (CLOSE_HOUR - OPEN_HOUR) * SECONDS_PER_HOUR
    local rem = limit - G.t
    if rem <= 10 and rem > 0 then              -- the closing countdown
      local n = math.ceil(rem)
      if n ~= G.lastCount then
        G.lastCount = n
        play(synthSq, n <= 3 and 1500 or 1000, 0.07, 0.35)
      end
    end
    if rem <= 0 then
      G.t = limit
      if not G.ending then
        G.ending = true
        transitionTo(endDay)
      end
      return
    end
  end
  if G.msgT > 0 then
    G.msgT = G.msgT - dt
    if G.msgT <= 0 then G.msg = nil end
  end
  for i = #G.popups, 1, -1 do
    local p = G.popups[i]
    p.t = p.t + dt
    if p.t >= p.life then table.remove(G.popups, i) end
  end
  WIN.updateWindow(dt)
  if G.pets then CAFE.updatePets(dt) end
  updateCustomers(dt)
  if G.st then updateStation(dt) else updateWalking(dt) end
end

----------------------------------------------------------------------
-- Drawing: people
----------------------------------------------------------------------
-- look 1..4 = customers, 5 = the barista
local function drawPerson(x, y, look, angry)
  x, y = math.floor(x), math.floor(y)
  -- body
  if look == 5 then
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(WHITE)
    gfx.fillRect(x - 6, y + 10, 12, 12)
    gfx.setColor(BLACK)
    gfx.drawRect(x - 6, y + 10, 12, 12)
  else
    gfx.setColor(BLACK)
    if look == 2 then gfx.setPattern(CHECK) end
    if look == 3 then gfx.setColor(WHITE) end
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 12, y + 7, 24, 15, 6)
    if look == 4 then
      gfx.setColor(WHITE)
      gfx.fillRect(x - 10, y + 13, 20, 2)
    end
  end
  -- head
  if look == 1 or look == 5 then
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y + 3, 7)
  else
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawCircleAtPoint(x, y, 9)
    gfx.setLineWidth(1)
  end
  if look == 2 then          -- hat
    gfx.setColor(BLACK)
    gfx.fillRect(x - 12, y - 4, 24, 4)
    gfx.fillRect(x - 7, y - 11, 14, 8)
  elseif look == 4 then      -- beanie
    gfx.setPattern(CHECK)
    gfx.fillRect(x - 8, y - 9, 16, 6)
    gfx.setColor(BLACK)
    gfx.fillRect(x - 9, y - 4, 18, 2)
  end
  -- face
  gfx.setColor(BLACK)
  if look == 3 then          -- glasses
    gfx.drawCircleAtPoint(x - 4, y + 2, 3)
    gfx.drawCircleAtPoint(x + 4, y + 2, 3)
    gfx.drawLine(x - 1, y + 2, x + 1, y + 2)
  else
    gfx.fillRect(x - 4, y + 2, 2, 2)
    gfx.fillRect(x + 2, y + 2, 2, 2)
  end
  if angry then
    gfx.drawLine(x - 6, y - 1, x - 2, y + 1)
    gfx.drawLine(x + 6, y - 1, x + 2, y + 1)
    gfx.drawLine(x - 2, y + 7, x + 2, y + 7)
  else
    gfx.drawLine(x - 3, y + 5, x - 2, y + 6)
    gfx.drawLine(x - 2, y + 6, x + 2, y + 6)
    gfx.drawLine(x + 2, y + 6, x + 3, y + 5)
  end
end

-- A little bar that shrinks as the customer gets impatient.
-- onDark = true draws it in white so it shows up on a black band.
local function drawPatience(x, y, p, w, onDark)
  if onDark then
    gfx.setColor(WHITE)
    gfx.drawRect(x, y, w, 6)
    gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
    gfx.setColor(BLACK)
    return
  end
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, 6)
  gfx.setColor(BLACK)
  gfx.drawRect(x, y, w, 6)
  gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
end

local function drawCustomer(c, withBar)
  local bob = 0
  if #c.path > 0 then bob = math.floor(math.sin(c.walk) * 1.5 + 0.5) end
  local angry = c.patience < 0.3 and (c.state == "line" or c.state == "active")
  drawPerson(c.x, c.y + bob, c.look, angry)
  if withBar and c.stage >= 1 and c.stage <= 4 then
    drawPatience(math.floor(c.x) - 16, math.floor(c.y) - 20, c.patience, 32)
  end
  if angry and (frames // 6) % 2 == 0 then
    gfx.setColor(BLACK)
    drawT("!", math.floor(c.x) + 12, math.floor(c.y) - 22, true)
  end
end

local function drawBubble(c)
  local lines = orderLines(c.order)
  local bw = 206
  local bh = 8 + 17 * (1 + #lines)
  local cx = math.floor(c.x)
  local right = cx < 200
  local bx = right and (cx + 26) or (cx - 26 - bw)
  local by = 122
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, by, bw, bh, 8)
  gfx.setLineWidth(1)
  -- little tail pointing at the customer
  local ex = right and bx or (bx + bw)
  local dir = right and -1 or 1
  gfx.setColor(WHITE)
  gfx.fillTriangle(ex, by + 8, ex, by + 22, ex + dir * 10, by + 15)
  gfx.fillRect(ex - 2, by + 9, 4, 12)
  gfx.setColor(BLACK)
  gfx.drawLine(ex, by + 8, ex + dir * 10, by + 15)
  gfx.drawLine(ex + dir * 10, by + 15, ex, by + 22)
  drawTC(c.greet, bx + bw // 2, by + 3, true)
  for i, line in ipairs(lines) do
    drawTC(line, bx + bw // 2, by + 3 + 17 * i)
  end
end

----------------------------------------------------------------------
-- Drawing: the shop
----------------------------------------------------------------------
function WIN.drawWindowView()
  local w = G.win
  gfx.setClipRect(15, 23, 52, 24)
  gfx.setColor(BLACK)
  for _, q in ipairs(w.walkers) do                  -- a person walking by
    local x = math.floor(q.x)
    local step = math.floor(math.sin(q.t) * 2)
    gfx.fillCircleAtPoint(x, 34, 3)
    gfx.fillRoundRect(x - 4, 37, 8, 8, 2)
    gfx.drawLine(x - 1, 45, x - 1 + step, 49)
    gfx.drawLine(x + 1, 45, x + 1 - step, 49)
    if q.umbrella then
      gfx.fillTriangle(x - 8, 31, x + 8, 31, x, 24)
    end
  end
  for _, q in ipairs(w.parts) do
    local x, y = math.floor(q.x), math.floor(q.y)
    if q.k == "rain" then
      gfx.drawLine(x, y, x - (q.vx > 0 and -2 or 1), y + 3)
    elseif q.k == "wind" then                       -- a lazy, squiggly gust
      local px, py = x, y + math.floor(math.sin(q.ph) * 2.5)
      for j = 1, 7 do
        local nx = x - j * 3
        local ny = y + math.floor(math.sin(q.ph - j * 0.9) * 2.5)
        gfx.drawLine(px, py, nx, ny)
        px, py = nx, ny
      end
      gfx.drawLine(px, py, px - 2, py - 2)          -- the curl at the tail
    else
      gfx.fillEllipseInRect(x, y, 5, 3)             -- a falling leaf
      gfx.drawLine(x - 1, y + 3, x + 1, y + 1)
    end
  end
  gfx.clearClipRect()
  gfx.setColor(BLACK)
end

local function drawWall()
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 18, 400, 52)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 68, 400, 3)
  CAFE.drawLights()

  -- window
  gfx.setColor(WHITE)
  gfx.fillRect(14, 22, 54, 26)
  WIN.drawWindowView()
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(14, 22, 54, 26)
  gfx.setLineWidth(1)
  gfx.drawLine(41, 22, 41, 48)
  gfx.drawLine(14, 35, 68, 35)

  -- shelf with cups (in Evening Chill these are the shop's real clean cups)
  do
    if shelfSelected() then
      local pad = ((frames // 10) % 2 == 0) and 0 or 3
      gfx.setColor(WHITE)
      gfx.fillRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setLineWidth(1)
    end
    gfx.fillRect(102, 40, 92, 3)
    for i = 0, G.cupMax - 1 do
      if i < G.cups.shelf then
        local cx = 106 + i * math.min(17, 88 // G.cupMax)
        gfx.setColor(WHITE)
        gfx.fillRect(cx, 30, 10, 10)
        gfx.setColor(BLACK)
        gfx.drawRect(cx, 30, 10, 10)
        gfx.fillRect(cx + 11, 33, 2, 4)
      end
    end
  end

  CAFE.drawVines()

  -- opening hours sign (in the Cafe it shows your cafe's name, and can be taken down)
  if G.mode ~= "cafe" or G.cafe.sign ~= false then
    gfx.setColor(WHITE)
    gfx.fillRect(268, 22, 90, 26)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(268, 22, 90, 26)
    gfx.setLineWidth(1)
    if G.mode == "cafe" then
      CAFE.fitText(G.cafe.name, 313, 35, 80, 18)
    else
      drawTC(G.mode == "chill" and "4 - 12 PM" or "OPEN 7-2", 313, 28, true)
    end
  end
  if G.mode == "cafe" then CAFE.drawWallItems(); CAFE.drawTinyItems() end

  -- framed picture of the coffee mug from the title screen
  local fx, fy = 366, 21
  gfx.setColor(WHITE)
  gfx.fillRect(fx, fy, 30, 28)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(fx, fy, 30, 28)
  gfx.drawCircleAtPoint(fx + 22, fy + 16, 3)               -- handle
  gfx.setColor(WHITE)
  gfx.fillRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(fx + 8, fy + 12, 11, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(fx + 3, fy + 23, 22, 2)                      -- saucer
  gfx.drawLine(fx + 10, fy + 8, fx + 12, fy + 5)            -- steam
  gfx.drawLine(fx + 12, fy + 5, fx + 10, fy + 3)
  gfx.drawLine(fx + 16, fy + 8, fx + 18, fy + 5)
  gfx.drawLine(fx + 18, fy + 5, fx + 16, fy + 3)
end

local function drawCounter()
  gfx.setColor(WHITE)
  gfx.fillRect(0, 74, 400, 22)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 74, 400, 2)
  gfx.fillRect(0, 96, 400, 18)
  CAFE.drawCounterItems()

  -- station signs on the front of the counter; the one you're standing at
  -- gets a white bubble that pulses
  local near = (not shelfSelected()) and nearStation() or nil
  for _, st in ipairs(STATIONS) do
    gfx.setFont(fontNormal)
    local tw = gfx.getTextSize(st.label)
    if near == st then
      local pad = ((frames // 10) % 2 == 0) and 0 or 2
      local bw = tw + 12
      gfx.setColor(WHITE)
      gfx.fillRoundRect(st.x - bw // 2 - pad, 98, bw + pad * 2, 14, 5)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
    else
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTC(st.label, st.x, 97)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC("TIPS", JAR_X - 3, 97)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)

  -- register
  local x = stationById("register").x
  gfx.setColor(BLACK)
  gfx.fillRect(x - 14, 78, 28, 16)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 10, 80, 14, 5)
  for i = 0, 2 do gfx.fillRect(x - 10 + i * 5, 88, 3, 3) end
  gfx.fillRect(x + 8, 80, 3, 11)

  -- coffee machine: hood, display, two spouts, a cup and a drip tray
  x = stationById("coffee").x
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x - 16, 76, 32, 18, 3)
  gfx.fillRect(x - 13, 74, 26, 3)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 12, 79, 11, 6)              -- display
  gfx.setColor(BLACK)
  gfx.fillRect(x - 10, 81, 3, 2)
  gfx.fillRect(x - 5, 81, 3, 2)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x - 9, 90, 1)          -- buttons
  gfx.fillCircleAtPoint(x - 5, 90, 1)
  gfx.fillRect(x + 1, 80, 12, 3)               -- brew head
  gfx.fillRect(x + 4, 83, 2, 3)                -- spouts
  gfx.fillRect(x + 9, 83, 2, 3)
  gfx.fillRect(x + 3, 88, 10, 5)               -- cup
  gfx.setColor(BLACK)
  gfx.fillRect(x + 5, 89, 6, 2)
  gfx.fillRect(x - 17, 93, 34, 2)              -- drip tray

  -- mixer: stand mixer with a head, dial, paddle and bowl
  x = stationById("mixer").x
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x - 14, 90, 28, 5, 2)      -- base
  gfx.fillRect(x + 7, 78, 6, 13)               -- column
  gfx.fillRoundRect(x - 10, 76, 24, 8, 3)      -- head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x + 8, 80, 2)          -- dial
  gfx.setColor(BLACK)
  gfx.fillRect(x - 5, 84, 2, 5)                -- paddle shaft
  gfx.fillRect(x - 8, 87, 8, 2)
  gfx.fillRoundRect(x - 12, 85, 18, 7, 3)      -- bowl
  gfx.setColor(WHITE)
  gfx.fillRect(x - 9, 87, 12, 2)               -- bowl rim highlight
  gfx.setColor(BLACK)
  gfx.fillRect(x - 5, 84, 2, 4)

  -- pick-up area: a rectangular mat with a plate on it
  x = stationById("serve").x
  gfx.setColor(BLACK)
  gfx.fillRect(x - 17, 80, 34, 14)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 14, 82, 28, 10)
  gfx.setColor(BLACK)
  gfx.drawRect(x - 12, 84, 24, 6)
  gfx.drawCircleAtPoint(x, 87, 3)

  -- Evening Chill: the dish bin
  local dishSt = stationById("dishes")
  if dishSt then
    x = dishSt.x
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 17, 82, 34, 13, 3)             -- the bin
    gfx.setColor(WHITE)
    gfx.fillRect(x - 14, 84, 28, 8)
    gfx.setColor(BLACK)
    for i = 1, math.min(G.cups.dirty, 5) do              -- dirty cups piled up in it
      gfx.fillRect(x - 15 + (i - 1) * 6, 85, 5, 6)
    end
    gfx.fillRect(x + 9, 76, 3, 7)                        -- little faucet
    gfx.fillRect(x + 4, 76, 8, 3)
  end

  -- the 8-bit tip jar (coins pile up as you earn tips)
  local jx = JAR_X
  gfx.setColor(BLACK)
  gfx.fillRect(jx - 12, 66, 24, 5)
  gfx.setColor(WHITE)
  gfx.fillRect(jx - 10, 71, 20, 23)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(jx - 10, 71, 20, 23)
  gfx.setLineWidth(1)
  local coins = math.min(12, G.tips // 50)
  for i = 0, coins - 1 do
    gfx.fillRect(jx - 7 + (i % 3) * 5, 89 - (i // 3) * 5, 4, 3)
  end
end

-- tables, chairs, and the corner nook
local function drawFloor()
  local lim = G.seatLimit
  CAFE.drawRunner()
  CAFE.drawRug()
  if lim >= 9 then
    -- the corner nook: an L-shaped bench up the right wall and along the bottom
    gfx.setColor(BLACK)
    gfx.fillRoundRect(372, 150, 26, 82, 8)
    gfx.fillRoundRect(322, 206, 76, 26, 8)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(376, 154, 18, 74, 5)
    gfx.fillRoundRect(326, 210, 68, 18, 5)
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(376, 154, 18, 74, 5)
    gfx.fillRoundRect(326, 210, 68, 18, 5)
    gfx.setColor(BLACK)
  end

  -- chairs
  for i, s in ipairs(SEATS) do
    if s.t <= 4 and i <= lim then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(s.x - 6, s.y - 9, 12, 18, 3)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(s.x - 6, s.y - 9, 12, 18, 3)
    end
  end

  -- round tables
  local firstSeat = { 1, 3, 5, 7, 9 }
  for ti, t in ipairs(TABLES) do
    if firstSeat[ti] <= lim then
      CAFE.tableAt(t.x, t.y, t.r, CAFE.ownedOf("cloth"), CAFE.ownedOf("centerpiece"), 1)
    end
  end

  -- a coffee cup in front of everyone who is sitting down
  for i, s in ipairs(SEATS) do
    if G.seats[i] and G.seats[i].state == "seated" then
      local t = TABLES[s.t]
      local cx = math.floor(t.x + (s.x - t.x) * 0.45)
      local cy = math.floor(t.y + (s.y - t.y) * 0.45)
      gfx.setColor(BLACK)
      gfx.fillCircleAtPoint(cx, cy, 3)
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx, cy, 1)
    end
  end
  CAFE.drawFloorItems()
  gfx.setColor(BLACK)
end

-- the front door, bottom left: a line that swings open and shut (seen from above)
function UI.drawDoor()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 238, 12, 2)
  gfx.fillRect(46, 238, 354, 2)
  gfx.fillRect(10, 235, 4, 5)
  local a = math.rad(G.door * 90)
  local ex = 14 + math.floor(32 * math.cos(a) + 0.5)
  local ey = 238 - math.floor(32 * math.sin(a) + 0.5)
  gfx.setLineWidth(3)
  gfx.drawLine(14, 238, ex, ey)
  gfx.setLineWidth(1)
end

local function drawPlayer()
  local bob = 0
  if G.moving then bob = math.floor(math.sin(G.walk) * 1.5 + 0.5) end
  drawPerson(G.px, PLAYER_Y + bob, 5, false)
  local n = G.cups and G.cups.hand or 0
  if n > 0 then                               -- clean cups held up in hand
    local x0 = math.floor(G.px) + 16               -- carried beside the barista
    for i = 1, n do drawCup(x0 + (i - 1) * 12, PLAYER_Y + 7 + bob, 1, false) end
  end
end

----------------------------------------------------------------------
-- Drawing: station panels (they pop up over the customer area)
----------------------------------------------------------------------
local function drawPanelFrame(c, title, text)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(6, 116, 388, 122, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(6, 116, 388, 122, 8)
  gfx.setLineWidth(1)
  gfx.fillRect(10, 120, 380, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(title, 14, 121, true)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(title)
  if c then
    drawT(text or orderShort(c.order), 14 + tw + 12, 121)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawPatience(342, 126, c.patience, 46, true)
  else
    if G.st == "dishes" then
      drawTR("Dirty: " .. G.cups.dirty .. "     In hand: " .. G.cups.hand, 384, 121, true)
    else
      drawTR("In hand: " .. G.cups.hand, 384, 121, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
end

local function drawRegister(c)
  local r = c.reg
  drawPanelFrame(c, "REGISTER")

  -- keypad
  local x0, y0, kw, kh = 250, 144, 44, 22
  for i = 1, 12 do
    local col, row = (i - 1) % 3, (i - 1) // 3
    local kx, ky = x0 + col * kw, y0 + row * kh
    gfx.setColor(BLACK)
    if r.state == "type" and r.cur == i then
      gfx.fillRect(kx, ky, kw, kh)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.drawRect(kx, ky, kw, kh)
    end
    drawTC(KEYS[i], kx + kw // 2, ky + 3, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end

  gfx.setColor(BLACK)
  if r.state == "type" then
    gfx.drawRoundRect(16, 144, 226, 26, 5)
    drawT("CHARGE", 24, 150)
    drawTR(money(c.price), 234, 150, true)
    gfx.fillRect(16, 176, 226, 30)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    if r.flash > 0 then
      if (frames // 4) % 2 == 0 then drawTC("WRONG! Try again", 129, 183, true) end
    else
      drawT("TYPE", 24, 183)
      drawTR(money(tonumber(r.digits) or 0), 234, 183, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawT("D-pad + A: press keys", 16, 214)
  else
    drawT("Correct!", 16, 144, true)
    drawT("Crank to print the receipt.", 16, 162)
    gfx.setColor(BLACK)
    gfx.fillRect(24, 186, 160, 8)
    local h = math.floor(clamp(r.crank / RECEIPT_CRANK, 0, 1) * 40)
    if h > 0 then
      gfx.setColor(WHITE)
      gfx.fillRect(44, 194, 120, h)
      gfx.setColor(BLACK)
      gfx.drawRect(44, 194, 120, h)
      for ly = 200, 194 + h - 4, 8 do
        gfx.drawLine(52, ly, 52 + 40 + ((ly * 7) % 50), ly)
      end
    end
  end
end

-- A small d-pad with the words around it (up above, down below, left and right
-- beside it). `on` = "up" / "down" / "left" / "right" boxes that word.
function UI.drawSmallPad(px, py, words, on)
  local function fillArm(x, y, w, h, lit)
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x, y, w, h, 3)
    if lit then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x + 3, y + 3, w - 6, h - 6, 2)
      gfx.setColor(BLACK)
    end
  end
  gfx.setColor(BLACK)
  gfx.fillRect(px - 13, py - 9, 26, 18)                           -- centre
  fillArm(px - 13, py - 27, 26, 18, on == "up")
  fillArm(px - 13, py + 9, 26, 18, on == "down")
  fillArm(px - 39, py - 9, 26, 18, on == "left")
  fillArm(px + 13, py - 9, 26, 18, on == "right")
  gfx.fillRect(px - 13, py - 18, 26, 36)
  gfx.fillRect(px - 26, py - 9, 52, 18)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(px, py, 3)
  local function arrow(x1, y1, x2, y2, x3, y3, lit)
    gfx.setColor(lit and BLACK or WHITE)
    gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  end
  arrow(px, py - 25, px - 5, py - 18, px + 5, py - 18, on == "up")
  arrow(px, py + 25, px - 5, py + 18, px + 5, py + 18, on == "down")
  arrow(px - 36, py, px - 29, py - 5, px - 29, py + 5, on == "left")
  arrow(px + 36, py, px + 29, py - 5, px + 29, py + 5, on == "right")
  gfx.setColor(BLACK)
  -- the words
  local function word(txt, x, ty, align, lit)
    gfx.setFont(fontBold)
    local tw = gfx.getTextSize(txt)
    local left = x - tw // 2                      -- centred
    if align == "left" then left = x elseif align == "right" then left = x - tw end
    if lit then
      gfx.setColor(BLACK)
      gfx.fillRoundRect(left - 4, ty - 1, tw + 8, 17, 4)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawT(txt, left, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end
  if words.up then word(words.up, px, py - 46, "center", on == "up") end
  if words.down then word(words.down, px, py + 30, "center", on == "down") end
  if words.left then word(words.left, px - 45, py - 8, "right", on == "left") end
  if words.right then word(words.right, px + 45, py - 8, "left", on == "right") end
end

UI.PICK_KEY_SIDE = { coffee = "up", decaf = "down", tea = "left", matcha = "right" }

local function drawCoffee(c)
  local f = c.cof
  drawPanelFrame(c, "COFFEE")

  if f.phase == "pick" then
    UI.drawSmallPad(196, 187, { up = "COFFEE", down = "DECAF", left = "TEA", right = "MATCHA" },
                 f.pick and UI.PICK_KEY_SIDE[f.pick] or nil)
    drawT("Pick a drink,", 16, 150, true)
    drawT("then press A.", 16, 168)
    -- A button
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(322, 184, 12)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC("A", 322, 176, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawTC("POUR", 322, 200, true)
    -- a preview of what you picked
    gfx.setColor(WHITE)
    gfx.fillRect(352, 160, 36, 40)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(352, 160, 36, 40)
    gfx.setLineWidth(1)
    if f.pick then
      gfx.setPattern(DRINK_PATTERN[f.pick])
      gfx.fillRect(354, 168, 32, 30)
      gfx.setColor(BLACK)
    end
    return
  end

  drawT("Tilt Playdate", 16, 160, true)
  drawT("down to pour.", 16, 180, true)

  -- cup
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(300, 196, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRect(242, 164, 56, 66)
  local surface = 228 - math.floor(f.fill * 52)
  if surface < 166 then surface = 166 end
  gfx.setColor(BLACK)
  if f.pick == "matcha" then gfx.setPattern(DIAG) elseif f.pick == "decaf" then gfx.setPattern(STRIPE) end
  gfx.fillRect(244, surface, 52, 228 - surface)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(242, 164, 56, 66)
  gfx.setLineWidth(1)

  -- the "fill to here" line
  if surface <= 176 and (f.pick == nil or f.pick == "coffee") then gfx.setColor(WHITE) else gfx.setColor(BLACK) end
  for dx = 246, 290, 8 do gfx.drawLine(dx, 176, dx + 4, 176) end
  gfx.setColor(BLACK)
  gfx.fillTriangle(230, 171, 230, 181, 239, 176)
  drawT("FULL", 306, 169)

  -- spilled over
  if f.fill > 1.2 then
    gfx.fillRect(238, 200, 3, 24)
    gfx.fillRect(299, 214, 3, 14)
  end

  -- spout and stream
  gfx.fillRect(254, 142, 32, 8)
  gfx.fillRect(266, 150, 8, 6)
  if f.tilt > 0 and f.fill < 1.25 then
    gfx.fillRect(269, 156, 3, math.max(0, surface - 156))
  end

  -- tilt meter
  drawT("TILT", 340, 142)
  gfx.drawRect(346, 160, 22, 70)
  local h = math.floor(70 * f.tilt)
  gfx.fillRect(346, 230 - h, 22, h)
end

-- what's still missing from the order (they vanish from the black bar as you add them)
function UI.mixHeader(o, m)
  local items = {}
  local function need(n, one, many)
    if n > 0 then items[#items + 1] = n .. " " .. (n == 1 and one or many) end
  end
  need(o.shot - m.shot, "shot", "shots")
  need(o.milk - m.milk, "milk", "milk")
  need(o.sugar - m.sugar, "sugar", "sugar")
  need(o.ice - m.ice, "ice", "ice")
  if m.phase == 2 then return "Mixing it up!" end
  if #items == 0 then return "Ready to mix!" end
  return table.concat(items, ", ")
end

local function drawMixer(c)
  local m = c.mix
  drawPanelFrame(c, "MIXER", UI.mixHeader(c.order, m))

  -- the fridge
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(16, 144, 34, 88)
  gfx.setLineWidth(1)
  gfx.drawLine(18, 172, 47, 172)
  gfx.fillRect(40, 150, 3, 8)
  gfx.fillRect(40, 180, 3, 14)

  if m.phase == 1 then
    UI.drawSmallPad(160, 187, { up = "SHOT", down = "ICE", left = "MILK", right = "SUGAR" }, nil)
    -- the A button starts the mixing
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(288, 184, 11)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC("A", 288, 176, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawTC("MIX", 288, 200, true)
  else
    drawT("Crank to mix!", 70, 144, true)
    gfx.setColor(BLACK)
    gfx.drawRect(70, 172, 150, 14)
    gfx.fillRect(72, 174, math.floor(146 * clamp(m.progress, 0, 1)), 10)
    drawT("Keep turning!", 70, 196)
  end

  -- the cup, seen from above
  local cx, cy = 348, 190
  local a = math.rad(m.angle)
  local mixed = m.progress >= 0.6
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx, cy, 34)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 30)
  gfx.setColor(BLACK)
  if mixed and m.milk > 0 then gfx.setPattern(CHECK) end
  gfx.fillCircleAtPoint(cx, cy, 28)
  gfx.setColor(WHITE)
  if not mixed then
    for i = 1, m.milk do
      local t = a + (i - 1) * (2 * math.pi / m.milk)
      gfx.fillCircleAtPoint(math.floor(cx + 16 * math.cos(t)), math.floor(cy + 16 * math.sin(t)), 6)
    end
    for i = 1, m.sugar do
      local t = -a * 0.7 + (i - 1) * (2 * math.pi / m.sugar) + 0.5
      gfx.fillRect(math.floor(cx + 22 * math.cos(t)) - 2, math.floor(cy + 22 * math.sin(t)) - 2, 4, 4)
    end
    for i = 1, m.shot do
      local t = a * 1.3 + (i - 1) * (2 * math.pi / m.shot) + 2.0
      gfx.drawCircleAtPoint(math.floor(cx + 11 * math.cos(t)), math.floor(cy + 11 * math.sin(t)), 4)
    end
  end
  -- ice cubes float on top, mixed or not
  for i = 1, m.ice do
    local t = a * 0.4 + (i - 1) * (2 * math.pi / m.ice) + 1.0
    gfx.drawRect(math.floor(cx + 19 * math.cos(t)) - 3, math.floor(cy + 19 * math.sin(t)) - 3, 7, 7)
  end
  gfx.setLineWidth(3)
  gfx.drawLine(cx, cy, math.floor(cx + 25 * math.cos(a)), math.floor(cy + 25 * math.sin(a)))
  gfx.drawLine(cx, cy, math.floor(cx - 25 * math.cos(a)), math.floor(cy - 25 * math.sin(a)))
  gfx.setLineWidth(1)
  gfx.setColor(BLACK)
end

local function drawServe(c)
  local s = c.srv
  drawPanelFrame(c, "PICK UP")
  if s.phase <= 2 then
    if s.slide < 1 then
      drawT("Here it comes...", 16, 146, true)
    else
      drawT("Press A to ring", 16, 146, true)
      drawT("the bell!", 16, 164, true)
    end
  else
    drawT("Order up!", 16, 146, true)
  end

  -- the drink slides along the counter
  gfx.setColor(BLACK)
  gfx.fillRect(16, 226, 200, 4)
  local cx = 40 + math.floor(s.slide * 140)
  if c.order.ice > 0 then
    -- iced coffee: tall glass, ice cubes and a straw
    gfx.setColor(WHITE)
    gfx.fillPolygon(cx - 12, 190, cx + 12, 190, cx + 9, 226, cx - 9, 226)
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"])
    gfx.fillPolygon(cx - 11, 198, cx + 11, 198, cx + 9, 225, cx - 9, 225)
    gfx.setColor(WHITE)
    for _, q in ipairs({ { -7, 200 }, { 1, 204 }, { -5, 212 }, { 2, 216 } }) do
      gfx.fillRect(cx + q[1], q[2], 7, 7)
    end
    gfx.setColor(BLACK)
    for _, q in ipairs({ { -7, 200 }, { 1, 204 }, { -5, 212 }, { 2, 216 } }) do
      gfx.drawRect(cx + q[1], q[2], 7, 7)
    end
    gfx.setLineWidth(2)
    gfx.drawPolygon(cx - 12, 190, cx + 12, 190, cx + 9, 226, cx - 9, 226)
    gfx.setLineWidth(3)
    gfx.drawLine(cx + 3, 208, cx + 8, 178)
    gfx.drawLine(cx + 8, 178, cx + 14, 175)
    gfx.setLineWidth(1)
  else
    -- hot coffee: cup with a handle and steam
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 12, 198, 24, 28)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(cx - 12, 198, 24, 28)
    gfx.drawCircleAtPoint(cx + 14, 210, 6)
    gfx.setLineWidth(1)
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"])
    gfx.fillRect(cx - 10, 202, 20, 22)
    gfx.setColor(BLACK)
    for i = -1, 1, 2 do
      local sx = cx + i * 5
      gfx.drawLine(sx, 194, sx + 2, 190)
      gfx.drawLine(sx + 2, 190, sx, 186)
    end
  end
  gfx.setColor(BLACK)

  -- the bell
  local bx = 310
  if s.phase == 3 then bx = bx + ((frames // 2) % 2 == 0 and 2 or -2) end   -- the bell rings
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(bx, 206, 24)
  gfx.setColor(WHITE)
  gfx.fillRect(bx - 26, 206, 53, 26)
  gfx.setColor(BLACK)
  gfx.fillRect(bx - 30, 206, 61, 6)
  gfx.fillCircleAtPoint(bx, 180, 4)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(bx - 9, 195, 3)
  gfx.setColor(BLACK)
  if s.phase == 2 and s.slide >= 1 then
    -- a pulsing A button over the bell
    local r = ((frames // 8) % 2 == 0) and 12 or 14
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(bx, 150, r)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC("A", bx, 142, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  elseif s.phase == 3 then
    drawTC("DING!", bx, 146, true)
    for i = -2, 2 do
      local ang = math.rad(i * 25 - 90)
      gfx.drawLine(math.floor(bx + math.cos(ang) * 32), math.floor(206 + math.sin(ang) * 32),
                   math.floor(bx + math.cos(ang) * 44), math.floor(206 + math.sin(ang) * 44))
    end
  end
end

-- Evening Chill: the dish bin (left) and sink (right)
local function drawDishes()
  local s, cu = G.sink, G.cups
  drawPanelFrame(nil, "DISHES")

  -- dirty cups waiting in the bin
  drawT("DIRTY CUPS", 16, 142, true)
  if cu.dirty == 0 then drawT("none", 16, 168) end
  for i = 1, cu.dirty do
    local col, row = (i - 1) % 3, (i - 1) // 3
    drawCup(20 + col * 44, 164 + row * 26, 2, true)
  end

  -- the sink: a counter rim, a basin, a tall curved faucet and two taps
  local wx = 292                                        -- where the water falls
  gfx.setColor(BLACK)
  gfx.fillRoundRect(214, 186, 156, 48, 8)               -- basin
  gfx.setColor(WHITE)
  gfx.fillRoundRect(219, 190, 146, 38, 6)
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(221, 210, 142, 16)                       -- the water
  gfx.setColor(BLACK)
  local wave = math.floor(math.sin(frames * 0.3) * 1.5)
  gfx.drawLine(221, 210 + wave, 361, 210 - wave)
  gfx.fillRect(206, 182, 172, 6)                        -- rim of the sink
  gfx.fillRect(262, 150, 12, 34)                        -- faucet pipe
  gfx.fillRoundRect(262, 144, 40, 10, 5)                -- the curve over the sink
  gfx.fillRect(292 - 4, 144, 8, 16)                     -- spout
  gfx.fillRect(wx - 6, 158, 12, 5)                      -- nozzle
  gfx.fillRect(238, 174, 4, 10)                         -- hot tap
  gfx.fillCircleAtPoint(240, 172, 5)
  gfx.fillRect(342, 174, 4, 10)                         -- cold tap
  gfx.fillCircleAtPoint(344, 172, 5)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(240, 172, 2)
  gfx.fillCircleAtPoint(344, 172, 2)
  gfx.setColor(BLACK)

  -- the stream of water
  local flow = (frames * 2) % 8
  for y = 164 + flow - 8, 188, 8 do
    if y >= 164 then gfx.drawLine(wx, y, wx, math.min(188, y + 4)) end
  end

  -- the cup being scrubbed
  if s.state ~= "empty" then
    local cx, cy = wx, 198
    drawCup(cx - 12, cy - 14, 3, false)
    if s.state == "washing" then
      local h = math.floor(10 * (1 - s.progress))          -- the dirt wears away
      if h > 0 then
        gfx.setPattern(CHECK)
        gfx.fillRect(cx - 10, cy + 6 - h + 2, 20, h)
        gfx.setColor(BLACK)
      end
      local a = math.rad(s.angle)
      local sx = math.floor(cx + 30 * math.cos(a))
      local sy = math.floor(cy + 12 * math.sin(a))
      gfx.setColor(BLACK)
      gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3)         -- the sponge
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(sx - 3, sy - 1, 1)
      gfx.fillCircleAtPoint(sx + 3, sy + 2, 1)
      gfx.setColor(BLACK)
      for i = 0, 2 do                                       -- soap bubbles
        local bx = cx - 26 + ((frames * 0.7 + i * 23) % 56)
        gfx.drawCircleAtPoint(math.floor(bx), cy - 6 - ((frames // 3 + i * 5) % 12), 2 + i % 2)
      end
    else
      -- squeaky clean: sparkles
      gfx.setColor(BLACK)
      local big = ((frames // 3) % 2 == 0)
      for _, o in ipairs({ { -20, -12 }, { 22, -8 }, { -16, 10 }, { 20, 12 } }) do
        local r = big and 5 or 3
        gfx.drawLine(cx + o[1] - r, cy + o[2], cx + o[1] + r, cy + o[2])
        gfx.drawLine(cx + o[1], cy + o[2] - r, cx + o[1], cy + o[2] + r)
      end
    end
  end

  -- what to do (bottom left, away from the faucet)
  if s.state == "empty" then
    drawT("All clean!", 16, 214, true)
  elseif s.state == "washing" then
    drawT("Crank to scrub!", 16, 214, true)
    drawT("B or D-pad: back", 16, 196)
    gfx.setColor(BLACK)
    gfx.drawRect(312, 148, 72, 8)
    gfx.fillRect(314, 150, math.floor(68 * clamp(s.progress, 0, 1)), 4)
  else
    drawT("Squeaky clean!", 16, 214, true)
  end
end

-- Evening Chill: the cup shelf on the wall
local function drawShelf()
  local cu = G.cups
  drawPanelFrame(nil, "SHELF")
  gfx.setColor(BLACK)
  gfx.fillRect(20, 190, 300, 6)
  gfx.fillRect(28, 196, 6, 8)
  gfx.fillRect(306, 196, 6, 8)
  local gap = math.min(56, 270 // G.cupMax)
  for i = 0, G.cupMax - 1 do
    local x = 40 + i * gap
    if i < cu.shelf then
      drawCup(x, 164, 3, false)
    else
      dashedRect(x - 2, 162, 36, 28)
    end
  end
  drawT(string.format("%d of %d cups on the shelf", cu.shelf, G.cupMax), 20, 142, true)
  if cu.hand > 0 then
    drawT("A: put a cup up", 20, 210, true)
    for i = 1, cu.hand do drawCup(310 + ((i - 1) % 3) * 24, 150 + ((i - 1) // 3) * 24, 2, false) end
  else
    drawT("Hold a clean cup to place it.", 20, 210)
  end
  drawTR("B: back", 384, 216)
end

local function drawStationPanel()
  if G.st == "dishes" then drawDishes(); return end
  if G.st == "shelf" then drawShelf(); return end
  local c = G.cust
  if c == nil then return end
  if G.st == "register" then drawRegister(c)
  elseif G.st == "coffee" then drawCoffee(c)
  elseif G.st == "mixer" then drawMixer(c)
  elseif G.st == "serve" then drawServe(c) end
end

----------------------------------------------------------------------
-- Drawing: HUD, popups, messages
----------------------------------------------------------------------
function UI.stopwatch(t)
  local secs = math.floor(t)
  if secs >= 3600 then
    return string.format("%d:%02d:%02d", secs // 3600, (secs % 3600) // 60, secs % 60)
  end
  return string.format("%d:%02d", secs // 60, secs % 60)
end

local function drawHUD()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 0, 400, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTR(money(G.cash + G.tips), 394, 1, true)
  if G.mode == "rush" then
    drawT(clockString(G.t), 6, 1, true)
    local limit = (CLOSE_HOUR - OPEN_HOUR) * SECONDS_PER_HOUR
    local rem = limit - G.t
    if rem <= 10 and rem > 0 then               -- closing countdown: 10, 9, 8...
      drawTC("Closing in " .. math.ceil(rem), 200, 1, true)
    end
  else
    drawT(UI.stopwatch(G.t), 6, 1, true)           -- how long you've been playing
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if G.mode == "cafe" then CAFE.drawStars(170, 9, 6, 15, G.cafe.stars, WHITE) end
  if G.mode == "rush" then
    local prog = clamp(G.t / ((CLOSE_HOUR - OPEN_HOUR) * SECONDS_PER_HOUR), 0, 1)
    gfx.setColor(WHITE)
    gfx.fillRect(0, 16, math.floor(400 * prog), 2)
  end
  gfx.setColor(BLACK)
end

function UI.drawPopups()
  for _, p in ipairs(G.popups) do
    local k = p.t / p.life
    local y = math.floor(p.y - 22 * k)
    -- small popups (tips over the jar) use the thin font and tight padding
    local pad = p.small and 3 or 5
    gfx.setFont(p.small and fontNormal or fontBold)
    local w = gfx.getTextSize(p.s)
    local bw = w + pad * 2
    local bx = clamp(p.x - bw // 2, 2, 398 - bw)
    local bh = p.small and 20 or 20
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, y - 2, bw, bh, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(bx, y - 2, bw, bh, 4)
    drawT(p.s, bx + pad, p.small and y + 1 or y, not p.small)
  end
end

function UI.drawMessage()
  if G.msg == nil then return end
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(G.msg)
  local bw = w + 20
  local bx = 200 - bw // 2
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, 188, bw, 22, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, 188, bw, 22, 6)
  gfx.setLineWidth(1)
  drawTC(G.msg, 200, 191, true)
end

local function needsCrank()
  if G.st == "dishes" then return G.sink.state == "washing" end
  local c = G.cust
  if c == nil or G.st == nil then return false end
  if G.st == "register" then return c.reg.state == "crank" end
  if G.st == "mixer" then return c.mix.phase == 2 end
  return false
end

local function drawPlay()
  drawWall()
  drawCounter()
  drawFloor()
  UI.drawDoor()
  if G.pets then CAFE.drawPets() end
  -- people, back of the line first so the front of the line is on top
  for i = #G.line, 1, -1 do drawCustomer(G.line[i], false) end
  for _, c in ipairs(G.others) do drawCustomer(c, false) end
  local c = G.cust
  if c then drawCustomer(c, true) end
  drawPlayer()
  if c and c.stage >= 1 and c.stage <= 4 and G.st == nil then drawBubble(c) end
  if G.st then drawStationPanel() end
  UI.drawPopups()
  drawHUD()
  UI.drawMessage()
  if needsCrank() then crankHelpDraw() end
end

----------------------------------------------------------------------
-- Title screen
----------------------------------------------------------------------
-- Big headline text: drawn once into an image of exactly the text's size, then
-- scaled up to fill the box (boxH tall, as wide as the screen allows) and centred.
local bigTextCache = {}
local function bigText(str, boxY, boxH, maxScale)
  local e = bigTextCache[str]
  if e == nil then
    gfx.setFont(fontBold)
    local w, h = gfx.getTextSize(str)
    local img = nil
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setFont(fontBold)
      gfx.drawText(str, 0, 0)
      gfx.popContext()
    end)
    e = { img = ok and img or nil, w = w, h = h }
    bigTextCache[str] = e
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if e.img then
    local scale = math.min(maxScale, 376 / e.w, boxH / e.h)
    local x = math.floor((400 - e.w * scale) / 2 + 0.5)
    local y = math.floor(boxY + (boxH - e.h * scale) / 2 + 0.5)
    e.img:drawScaled(x, y, scale)
  else
    drawTC(str, 200, boxY + boxH // 2 - 8, true)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

-- the big steaming mug (ox, oy move it around the screen)
function UI.drawBigMug(ox, oy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawCircleAtPoint(224 + ox, 164 + oy, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(182 + ox, 150 + oy, 38, 10)
  gfx.setColor(BLACK)
  gfx.fillRect(166 + ox, 186 + oy, 70, 4)
  for k = -1, 1 do
    local px, py = 0, 0
    for i = 0, 8 do
      local yy = 140 + oy - i * 2.5
      local xx = 200 + ox + k * 10 + math.sin(frames * 0.15 + i * 0.7 + k) * 3
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

local function drawMenu()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 10, 400, 84)
  bigText("Coffee Please!!!", 14, 56, 5)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC("by Christian G", 200, 72, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)

  UI.drawBigMug(-100, 6)

  -- four boxes: three game modes and the high scores
  local opts = { { "RUSH HOUR", "7 AM - 2 PM, timed" },
                 { "EVENING CHILL", "4 PM - 12 AM, relaxed" },
                 { "CAFE", "build your own, 3 saves" },
                 { "HIGH SCORES" } }
  for i, o in ipairs(opts) do
    local y = 100 + (i - 1) * 35
    gfx.setColor(BLACK)
    if menuSel == i then
      gfx.fillRoundRect(196, y, 196, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      if (frames // 14) % 2 == 0 then
        gfx.setColor(BLACK)
        gfx.fillTriangle(182, y + 8, 182, y + 22, 191, y + 15)
      end
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(196, y, 196, 31, 8)
      gfx.setLineWidth(1)
    end
    if o[2] then
      drawT(o[1], 206, y + 1, true)
      drawT(o[2], 206, y + 15)
    else
      drawT(o[1], 206, y + 8, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end
end

----------------------------------------------------------------------
-- Closing time: initials entry, then the high score board
----------------------------------------------------------------------
local function drawEntry()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 6, 400, 40)
  bigText(G.mode == "chill" and "Shift Over!" or "Closing Time!", 9, 34, 3)

  local rows = {
    { "Customers served", tostring(G.served) },
    { "Sales", money(G.cash) },
    { "Tips", money(G.tips) },
    { "Walked out", tostring(G.missed) },
  }
  for i, row in ipairs(rows) do
    local y = 50 + (i - 1) * 15
    drawT(row[1], 90, y)
    drawTR(row[2], 310, y)
  end
  gfx.setColor(BLACK)
  gfx.fillRect(80, 112, 240, 2)
  drawT("TOTAL MADE", 90, 116, true)
  drawTR(money(G.total), 310, 116, true)

  drawTC("ENTER YOUR INITIALS", 200, 138, true)
  for i = 1, 3 do
    local bx = 200 - 54 + (i - 1) * 40
    gfx.setColor(BLACK)
    if i == entry.cur then
      gfx.fillRect(bx, 174, 32, 32)
      gfx.fillTriangle(bx + 10, 170, bx + 22, 170, bx + 16, 163)
      gfx.fillTriangle(bx + 10, 210, bx + 22, 210, bx + 16, 217)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRect(bx, 174, 32, 32)
      gfx.setLineWidth(1)
    end
    drawTC(string.char(65 + entry.letters[i]), bx + 16, 180, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setColor(BLACK)
  drawTC("Up/Down or crank: letter    A: next", 200, 222)
end

-- a small steaming mug for the corners of the board
function UI.drawSmallMug(x, y)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y + 10, 26, 20, 4)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(x, y + 10, 26, 20, 4)
  gfx.drawCircleAtPoint(x + 30, y + 20, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(x + 3, y + 13, 20, 5)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 4, y + 31, 38, 3)
  for k = 0, 1 do
    local px, py = 0, 0
    for i = 0, 5 do
      local yy = y + 6 - i * 2
      local xx = x + 8 + k * 9 + math.sin(frames * 0.15 + i * 0.8 + k * 2) * 2
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

-- the high-score look: double border, bobbing beans, steam rising from two cups
function UI.beanFrame()
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(2, 2, 396, 236, 10)
  gfx.setLineWidth(1)
  gfx.drawRoundRect(7, 7, 386, 226, 7)
  for i = 0, 5 do
    local bob = math.floor(math.sin(frames * 0.12 + i * 1.1) * 3 + 0.5)
    drawBean(22 + (i % 2) * 16, 50 + i * 24 + bob, 1)
    drawBean(378 - (i % 2) * 16, 50 + i * 24 - bob, 1)
  end
  for _, bx in ipairs({ 26, 35, 358, 367 }) do
    local px, py
    for yy = 204, 40, -3 do
      local xx = bx + math.sin(frames * 0.12 + yy * 0.09 + bx) * 3
      if px and (yy // 3 + (frames // 6)) % 6 ~= 0 then
        gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), yy)
      end
      px, py = xx, yy
    end
  end
  UI.drawSmallMug(18, 198)
  UI.drawSmallMug(350, 198)
  gfx.setColor(BLACK)
end

local function drawBoard()
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"

  UI.beanFrame()

  -- title band with arrows to switch boards
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(name .. " HIGH SCORES", 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(WHITE)
  gfx.fillTriangle(24, 23, 32, 17, 32, 29)
  gfx.fillTriangle(376, 23, 368, 17, 368, 29)
  gfx.setColor(BLACK)

  local function row(i, y, label)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (frames // 8) % 2 == 0 then
      gfx.setColor(BLACK)
      gfx.fillRect(58, y - 2, 286, 17)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTR(label or tostring(i), 92, y - 1, true)
    drawT(e.n, 104, y - 1, true)
    drawTR(money(e.s), 336, y - 1, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, 39 + (i - 1) * 16) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    for x = 60, 340, 6 do gfx.drawLine(x, 198, x + 2, 198) end
    row(board.rank, 199, "#" .. board.rank)
  end

  drawTC("B: back", 200, 216, true)
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------
local function goTitle()
  sfxClick()
  transitionTo(function()
    if G then closeStation() end
    setShiftMenu(false, false)
    state = STATE_MENU
  end)
end

CAFE.goTitle = function() goTitle() end

local function startGame(mode)
  sfxClick()
  sfxStart()
  transitionTo(function()
    newGame(mode)
    state = STATE_PLAY
  end)
end

function UI.openBoard(m)
  transitionTo(function()
    board = { mode = "view", rank = nil, m = m, view = m, t = 0 }
    state = STATE_BOARD
  end)
end

local function updateMenu()
  if pd.buttonJustPressed(pd.kButtonDown) then
    menuSel = menuSel % 4 + 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    menuSel = (menuSel + 2) % 4 + 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if menuSel == 4 then
      sfxClick()
      UI.openBoard("rush")
    elseif menuSel == 3 then
      sfxClick()
      CAFE.open()
    else
      startGame(menuSel == 2 and "chill" or "rush")
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick()
    UI.openBoard("rush")
  end
end

local function updateEntry(dt)
  G.endT = G.endT + dt
  if G.endT < 1.5 then return end   -- ignore button mashing as the shift ends
  local e = entry
  local function bump(d)
    e.letters[e.cur] = (e.letters[e.cur] + d) % 26
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonUp) then bump(1)
  elseif pd.buttonJustPressed(pd.kButtonDown) then bump(-1)
  elseif pd.buttonJustPressed(pd.kButtonLeft) then e.cur = math.max(1, e.cur - 1); sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonRight) then e.cur = math.min(3, e.cur + 1); sfxClick() end

  -- the crank spins through the alphabet too
  e.crank = e.crank + pd.getCrankChange()
  while e.crank >= 30 do e.crank = e.crank - 30; bump(1) end
  while e.crank <= -30 do e.crank = e.crank + 30; bump(-1) end

  if pd.buttonJustPressed(pd.kButtonA) then
    if e.cur < 3 then
      e.cur = e.cur + 1
      sfxPop()
    else
      local name = string.char(65 + e.letters[1], 65 + e.letters[2], 65 + e.letters[3])
      local rank = insertScore(G.mode, name, G.total)
      sfxGood()
      local m = G.mode
      transitionTo(function()
        board = { mode = "after", rank = rank, m = m, view = m, t = 0 }
        state = STATE_BOARD
      end)
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    if e.cur > 1 then e.cur = e.cur - 1; sfxClick() end
  end
end

local function updateBoard(dt)
  board.t = board.t + dt
  -- (after a game the buttons stay locked a moment so a mashed A can't restart it)
  if board.t < (board.mode == "after" and 1.2 or 0.2) then return end
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    board.view = (board.view == "rush") and "chill" or "rush"
    sfxClick()
    return
  end
  if board.mode == "after" then
    if pd.buttonJustPressed(pd.kButtonA) then
      startGame(board.m)
    elseif pd.buttonJustPressed(pd.kButtonB) then
      sfxClick()
      goTitle()
    end
  else
    if pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
      sfxClick()
      goTitle()
    end
  end
end

----------------------------------------------------------------------
-- CAFE mode: three save files, a shop between shifts, stars, decorations, pets
----------------------------------------------------------------------
CAFE.STATE = 5
CAFE.PRICE = 3          -- every shop price is multiplied by this
CAFE.CUP_COST  = { 10, 20, 35, 50, 70, 90 }   -- dollars (x PRICE): cup 3, 4, 5, 6, 7, 8
CAFE.SEAT_N    = { 2, 4, 6, 8, 13 }           -- seats after each seating upgrade (the last one is the corner booth)
CAFE.SEAT_COST = { 35 / CAFE.PRICE, 40, 60, 85, 120 }     -- (the first table is $35 in the shop)
-- everything you can buy for the looks. kind: wall / floor (placed on a grid spot),
-- rug (one at a time), ceiling, pet.
CAFE.ITEMS = {
  { id = "clock",    name = "Wall clock",     kind = "wall",    cost = 25 },
  { id = "cuckoo",   name = "Cuckoo clock",   kind = "wall",    cost = 55 },
  { id = "calendar", name = "Calendar",       kind = "wall",    cost = 20 },
  { id = "plant",    name = "Spiky plant",    kind = "floor",   cost = 30 },
  { id = "cactus",   name = "Cactus",         kind = "floor",   cost = 25 },
  { id = "fern",     name = "Leafy fern",     kind = "floor",   cost = 30 },
  { id = "flowers",  name = "Flower pot",     kind = "floor",   cost = 35 },
  { id = "tree",     name = "Christmas tree", kind = "floor",   cost = 80 },
  { id = "pumpkin",  name = "Pumpkin",        kind = "floor",   cost = 20 },
  { id = "palm",     name = "Palm tree",      kind = "floor",   cost = 45 },
  { id = "snake",    name = "Snake plant",    kind = "floor",   cost = 30 },
  { id = "sunflower", name = "Sunflowers",    kind = "floor",   cost = 35 },
  { id = "bonsai",   name = "Bonsai",         kind = "floor",   cost = 40 },
  { id = "monstera", name = "Monstera",       kind = "floor",   cost = 40 },
  { id = "tulips",   name = "Tulip pot",      kind = "counter", cost = 15 },
  { id = "succ",     name = "Succulent",      kind = "counter", cost = 12 },
  { id = "daisies",  name = "Daisy vase",     kind = "counter", cost = 18 },
  { id = "minicac",  name = "Mini cactus",    kind = "counter", cost = 12 },
  { id = "herbs",    name = "Herb pot",       kind = "counter", cost = 15 },
  { id = "ivy",      name = "Ivy vines",      kind = "shelf",   cost = 25 },
  { id = "bloomvine", name = "Flowering vines", kind = "shelf", cost = 35 },
  { id = "lights",   name = "String lights",  kind = "ceiling", cost = 45 },
  { id = "rug",      name = "Welcome rug",    kind = "rug",     cost = 35 },
  { id = "rug2",     name = "Striped rug",    kind = "rug",     cost = 40 },
  { id = "rug3",     name = "Checker rug",    kind = "rug",     cost = 45 },
  { id = "run1",     name = "Red carpet runner", kind = "runner", cost = 40 },
  { id = "run2",     name = "Striped runner", kind = "runner", cost = 35 },
  { id = "run3",     name = "Checker runner", kind = "runner", cost = 35 },
  { id = "run4",     name = "Diamond runner", kind = "runner", cost = 40 },
  { id = "run5",     name = "Coffee bean runner", kind = "runner", cost = 45 },
  { id = "t1",       name = "Tiny landscape",  kind = "tiny", cost = 8 },
  { id = "t2",       name = "Tiny heart",      kind = "tiny", cost = 8 },
  { id = "t3",       name = "Tiny sunburst",   kind = "tiny", cost = 10 },
  { id = "t4",       name = "Tiny mug print",  kind = "tiny", cost = 10 },
  { id = "t5",       name = "Cat portrait",    kind = "tiny", cost = 12 },
  { id = "t6",       name = "Tiny mirror",     kind = "tiny", cost = 12 },
  { id = "t7",       name = "Party bunting",   kind = "tiny", cost = 14 },
  { id = "t8",       name = "Paper plane",     kind = "tiny", cost = 8 },
  { id = "t9",       name = "Music notes",     kind = "tiny", cost = 10 },
  { id = "t10",      name = "Moon and stars",  kind = "tiny", cost = 12 },
  { id = "t12",      name = "Sailboat",        kind = "tiny", cost = 10 },
  { id = "cloth1",   name = "Checker tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth2",   name = "Striped tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth3",   name = "Lace tablecloth", kind = "cloth", cost = 40 },
  { id = "cp1",      name = "Table flowers",  kind = "centerpiece", cost = 20 },
  { id = "cp2",      name = "Table candle",   kind = "centerpiece", cost = 15 },
  { id = "cp3",      name = "Table sprig",    kind = "centerpiece", cost = 18 },
  { id = "cp4",      name = "Table cactus",   kind = "centerpiece", cost = 18 },
  { id = "cat",      name = "Cat",            kind = "pet",     cost = 150 },
  { id = "dog",      name = "Dog",            kind = "pet",     cost = 150 },
  { id = "cattree",  name = "Cat tree",       kind = "floor",   cost = 60, needs = "cat" },
  { id = "dogbed",   name = "Dog bed",        kind = "floor",   cost = 45, needs = "dog" },
}
CAFE.byId = {}
for _, it in ipairs(CAFE.ITEMS) do CAFE.byId[it.id] = it end
-- a few words under the price in the shop
CAFE.DESC = {
  clock = "Tick-tock!", cuckoo = "Cuckoo! Cuckoo!", calendar = "Every day counts",
  tree = "Ho ho ho!", pumpkin = "Spooky season!", palm = "Vacation vibes",
  cactus = "Ouch! Cute, though", flowers = "Smells lovely", plant = "Low maintenance",
  lights = "Cozy glow", ivy = "Hanging around", bloomvine = "In full bloom",
  rug = "Wipe your feet", rug2 = "Wipe your feet", rug3 = "Wipe your feet",
  run1 = "Roll out the red carpet", run2 = "Rolls out at the register", run3 = "Rolls out at the register",
  run4 = "Rolls out at the register", run5 = "Rolls out at the register",
  t1 = "Hang it up high", t2 = "Made with love", t3 = "Rise and shine", t4 = "Mug shot", t5 = "Meow",
  t6 = "Mirror, mirror", t7 = "Party time!", t8 = "Fly away", t9 = "La la la", t10 = "Sweet dreams",
  t12 = "Smooth sailing",
  cloth1 = "Dress up every table", cloth2 = "Dress up every table", cloth3 = "Dress up every table",
  cp1 = "A centrepiece for every table", cp2 = "Dinner by candlelight", cp3 = "A little green", cp4 = "Tiny and spiky",
  cat = "Boosts stars and tips", dog = "Boosts stars and tips",
  cattree = "The cat will love it", dogbed = "A nap spot for the dog",
}
-- grid spots. The wall has three free spots (the name sign uses the last two).
CAFE.WSLOT = { { 71, 21, 24, 28 }, { 268, 21, 43, 28 }, { 315, 21, 43, 28 }, { 214, 21, 24, 28 } }   -- (the 4th is where the fridge used to be)   -- x, y, w, h
CAFE.XSLOT = { { 112, 61 }, { 150, 61 }, { 190, 61 }, { 230, 61 }, { 268, 61 }, { 304, 61 }, { 340, 61 } }   -- tiny art, on the open wall
CAFE.CSLOT = { { 92, 86 }, { 164, 86 }, { 236, 86 }, { 302, 86 }, { 358, 86 } }   -- blank spots on the counter
-- floor spots hug the walls: down the left, in the right-hand corner, and along the counter
CAFE.FSLOT = { { 20, 134 }, { 20, 170 }, { 20, 204 }, { 382, 132 }, { 100, 130 }, { 200, 130 }, { 300, 130 } }
-- where the tables can go (the first four match the original row along the bottom)
CAFE.TSLOT = { { 132, 208 }, { 186, 208 }, { 240, 208 }, { 294, 208 }, { 150, 170 }, { 210, 170 }, { 270, 170 } }
function CAFE.applyLayout(d)
  if not CAFE.defT then
    CAFE.defT, CAFE.defS = {}, {}
    for i, t in ipairs(TABLES) do CAFE.defT[i] = { t.x, t.y } end
    for i, q in ipairs(SEATS) do CAFE.defS[i] = { q.x, q.y } end
  end
  for i, t in ipairs(CAFE.defT) do TABLES[i].x, TABLES[i].y = t[1], t[2] end
  for i, q in ipairs(CAFE.defS) do SEATS[i].x, SEATS[i].y = q[1], q[2] end
  if d then
    for k = 1, 4 do
      local sl = d.tables[k] and CAFE.TSLOT[d.tables[k]]
      if sl then
        TABLES[k].x, TABLES[k].y = sl[1], sl[2]
        SEATS[2 * k - 1].x, SEATS[2 * k - 1].y = sl[1] - 17, sl[2]
        SEATS[2 * k].x, SEATS[2 * k].y = sl[1] + 17, sl[2]
      end
    end
  end
end
CAFE.slots = {}
CAFE.sel, CAFE.mode, CAFE.erase = 1, "slots", nil
CAFE.name, CAFE.letter, CAFE.crank, CAFE.onDone = "", 0, 0, false
CAFE.shopSel, CAFE.scroll, CAFE.report, CAFE.msg, CAFE.msgT = 1, 0, nil, nil, 0
CAFE.cur, CAFE.slot = nil, 1
CAFE.pend, CAFE.spots, CAFE.spotSel = nil, {}, 1

function CAFE.seatsOf(step) if step <= 0 then return 0 end return CAFE.SEAT_N[step] end

function CAFE.fresh(name)
  return { v = 2, name = name, money = 0, cups = 2, seatStep = 0, stars = 0, decor = {}, place = {}, tables = {}, shifts = 0 }
end

-- ---- grid bookkeeping ----------------------------------------------------------------
function CAFE.slotTaken(d, kind, slot)
  if kind == "wall" and d.sign ~= false and (slot == 2 or slot == 3) then return true end
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == kind and d.decor[it.id] == "on" and d.place[it.id] == slot then return true end
  end
  return false
end

function CAFE.isGrid(it) return it.kind == "wall" or it.kind == "floor" or it.kind == "counter" or it.kind == "tiny" end

function CAFE.freeSlots(d, kind)
  local n = (kind == "wall") and #CAFE.WSLOT or ((kind == "counter") and #CAFE.CSLOT
            or ((kind == "tiny") and #CAFE.XSLOT or #CAFE.FSLOT))
  local list = {}
  for i = 1, n do
    if not CAFE.slotTaken(d, kind, i) then list[#list + 1] = i end
  end
  return list
end

function CAFE.fixPlacement(d)               -- old saves / odd data: give everything a legal spot
  local old = {}
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.isGrid(it) and d.decor[it.id] == "on" then
      old[it.id] = d.place[it.id]
      d.place[it.id] = nil
    end
  end
  for _, it in ipairs(CAFE.ITEMS) do
    if old[it.id] ~= nil or (CAFE.isGrid(it) and d.decor[it.id] == "on") then
      local want = old[it.id]
      local free = CAFE.freeSlots(d, it.kind)
      local ok = false
      for _, f in ipairs(free) do if f == want then ok = true end end
      if ok then d.place[it.id] = want
      elseif #free > 0 then d.place[it.id] = free[1]
      else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.read(i)
  local ok, d = pcall(pd.datastore.read, "cafe" .. i)
  if not ok or type(d) ~= "table" or type(d.name) ~= "string" then return nil end
  d.money = tonumber(d.money) or 0
  d.cups = clamp(math.floor(tonumber(d.cups) or 2), 2, 8)
  d.seatStep = clamp(math.floor(tonumber(d.seatStep) or 0), 0, 5)
  d.stars = clamp(tonumber(d.stars) or 0, 0, 5)
  d.shifts = tonumber(d.shifts) or 0
  if type(d.decor) ~= "table" then d.decor = {} end
  if type(d.place) ~= "table" then d.place = {} end
  if type(d.tables) ~= "table" then d.tables = {} end
  for k = 1, math.min(d.seatStep, 4) do if not CAFE.TSLOT[d.tables[k] or 0] then d.tables[k] = k end end
  CAFE.fixPlacement(d)
  return d
end

function CAFE.write()
  if CAFE.cur then pcall(pd.datastore.write, CAFE.cur, "cafe" .. CAFE.slot) end
end

function CAFE.addStars(d)
  if G and G.cafe then G.cafe.stars = clamp(math.floor((G.cafe.stars + d) * 100 + 0.5) / 100, 0, 5) end
end

-- a slip-up costs a little of a star; the more you've decorated, the less customers mind
function CAFE.mistake(amt)
  if not (G and G.mode == "cafe" and G.cafe) then return end
  local n = G.cafe.seatStep or 0
  for _, v in pairs(G.cafe.decor) do if v == "on" then n = n + 1 end end
  local mult = clamp(1 - 0.025 * n, 0.25, 1)
  CAFE.addStars(-amt * mult)
end

function CAFE.petCount()
  local d = G and G.cafe
  if not d then return 0 end
  return (d.decor.cat == "on" and 1 or 0) + (d.decor.dog == "on" and 1 or 0)
end

-- ---- customer flow: it ebbs and flows, but never goes dead ---------------------------------------
function CAFE.flowUpdate(dt)
  local f = G.flow
  f.timer = f.timer - dt
  if f.timer <= 0 then
    f.target = math.random()
    f.timer = 25 + math.random() * 40
  end
  f.m = f.m + (f.target - f.m) * math.min(1, dt * 0.15)
  -- nobody here at all? don't leave the shop empty for long
  if #G.line == 0 and G.cust == nil and G.arriveIn > 16 then G.arriveIn = 16 end
end

function CAFE.gap(lo, span)
  local f = G.flow
  local factor = 1.55 - 1.0 * f.m                      -- quiet spell 1.55x, rush 0.55x
  if math.random() < 0.14 then return 2.5 + math.random() * 3 end   -- a friend tags along
  return (lo + math.random() * span) * factor
end

-- ---- stars ---------------------------------------------------------------------------------------
function CAFE.star(cx, cy, r, fill, color)
  local pts = {}
  for i = 0, 9 do
    local a = -math.pi / 2 + i * math.pi / 5
    local rr = (i % 2 == 0) and r or r * 0.45
    pts[#pts + 1] = math.floor(cx + math.cos(a) * rr + 0.5)
    pts[#pts + 1] = math.floor(cy + math.sin(a) * rr + 0.5)
  end
  gfx.setColor(color)
  if fill >= 0.75 then
    gfx.fillPolygon(table.unpack(pts))
  else
    gfx.drawPolygon(table.unpack(pts))
    if fill >= 0.25 then
      gfx.setClipRect(cx - r - 1, cy - r - 1, r + 1, r * 2 + 2)     -- the left half
      gfx.fillPolygon(table.unpack(pts))
      gfx.clearClipRect()
    end
  end
end

function CAFE.drawStars(x0, cy, r, gap, value, color)
  for i = 1, 5 do
    CAFE.star(x0 + (i - 1) * gap, cy, r, clamp(value - (i - 1), 0, 1), color)
  end
  gfx.setColor(BLACK)
end

-- text squeezed to fit a box (scaled down if it's too wide)
CAFE.fitCache = {}
function CAFE.fitText(str, cx, cy, maxW, maxH)
  gfx.setFont(fontBold)
  local w, h = gfx.getTextSize(str)
  if w <= maxW then
    drawTC(str, cx, cy - h // 2, true)
    return
  end
  local img = CAFE.fitCache[str]
  if img == nil then
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      drawT(str, 0, 0, true)
      gfx.popContext()
    end)
    if not ok then img = false end
    CAFE.fitCache[str] = img
  end
  if img then
    local k = maxW / w
    local ok = pcall(function() img:drawScaled(cx - math.floor(w * k / 2), cy - math.floor(h * k / 2), k) end)
    if ok then gfx.setImageDrawMode(gfx.kDrawModeCopy); return end
  end
  drawTC(string.sub(str, 1, 7) .. "..", cx, cy - h // 2, true)
end

-- ---- decoration art: every piece is drawn around a centre point ----------------------------------
CAFE.art = {}
local function A() return CAFE.art end

function CAFE.art.clock(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 11)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 11)
  gfx.setLineWidth(1)
  for h = 0, 11 do
    local a = h * math.pi / 6
    gfx.drawLine(math.floor(cx + math.sin(a) * 8), math.floor(cy - math.cos(a) * 8),
                 math.floor(cx + math.sin(a) * 9.5), math.floor(cy - math.cos(a) * 9.5))
  end
  local t = (G and G.t) or 0
  local am = t * 0.105
  local ah = am / 12 + 1
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 8), math.floor(cy - math.cos(am) * 8))
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 5), math.floor(cy - math.cos(ah) * 5))
  gfx.setLineWidth(1)
end

function CAFE.art.cuckoo(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 11, cy - 3, cx, cy - 14, cx + 11, cy - 3)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 9, cy - 3, 18, 14)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 9, cy - 3, 18, 14)
  local t = (G and G.t) or 0
  if t % 30 < 2 then                                  -- the little bird pops out
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy + 2, 2)
    gfx.fillTriangle(cx + 2, cy + 1, cx + 6, cy + 2, cx + 2, cy + 3)
  else
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
  end
  local sw = math.floor(math.sin(frames * 0.08) * 4)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)
  gfx.fillCircleAtPoint(cx + sw, cy + 17, 2)
end

function CAFE.art.calendar(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 10, cy - 12, 20, 24)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 10, cy - 12, 20, 24)
  gfx.fillRect(cx - 10, cy - 12, 20, 6)
  gfx.fillRect(cx - 6, cy - 14, 2, 4)
  gfx.fillRect(cx + 4, cy - 14, 2, 4)
  for r = 0, 2 do
    for c = 0, 3 do
      gfx.fillRect(cx - 8 + c * 4, cy - 3 + r * 5, 2, 2)
    end
  end
  gfx.drawRect(cx + 2, cy + 6, 5, 4)
end

local function pot(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 9, cy + 5, cx + 9, cy + 5, cx + 6, cy + 14, cx - 6, cy + 14)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 7, cy + 7, 14, 2)
  gfx.setColor(BLACK)
end

function CAFE.art.plant(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx, cy + 5, cx - 9 + sw, cy - 9, cx - 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + 9 + sw, cy - 10, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + sw, cy - 15, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx - 13 + sw, cy - 2, cx - 4, cy + 6)
  gfx.fillTriangle(cx, cy + 5, cx + 13 + sw, cy - 3, cx + 4, cy + 6)
  pot(cx, cy)
end

function CAFE.art.cactus(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 4, cy - 14, 8, 22, 3)
  gfx.fillRoundRect(cx - 11, cy - 7, 6, 3, 1)
  gfx.fillRoundRect(cx - 11, cy - 11, 3, 7, 1)
  gfx.fillRoundRect(cx + 5, cy - 3, 6, 3, 1)
  gfx.fillRoundRect(cx + 8, cy - 8, 3, 8, 1)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 1, cy - 10)
  gfx.drawPixel(cx + 1, cy - 4)
  gfx.drawPixel(cx - 1, cy + 1)
  pot(cx, cy)
end

function CAFE.art.fern(cx, cy)
  local sw = math.floor(math.sin(frames * 0.06) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  for k = -2, 2 do
    gfx.drawLine(cx, cy + 5, cx + k * 5, cy - 5)
    gfx.drawLine(cx + k * 5, cy - 5, cx + k * 8 + sw, cy - 11)
  end
  gfx.setLineWidth(1)
  pot(cx, cy)
end

function CAFE.art.flowers(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 2, cy + 5, cx + k * 7, cy - 7)
  end
  for k = -1, 1 do
    local fx, fy = cx + k * 7, cy - 9 - (k == 0 and 3 or 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(fx, fy, 4)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(fx, fy, 4)
    gfx.fillCircleAtPoint(fx, fy, 1)
  end
  pot(cx, cy)
end

function CAFE.art.tree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 9, 4, 6)
  gfx.fillTriangle(cx, cy - 15, cx - 8, cy - 3, cx + 8, cy - 3)
  gfx.fillTriangle(cx, cy - 8, cx - 11, cy + 4, cx + 11, cy + 4)
  gfx.fillTriangle(cx, cy - 2, cx - 13, cy + 10, cx + 13, cy + 10)
  local spots = { { -3, -8 }, { 3, -1 }, { -7, 2 }, { 6, 6 }, { -3, 7 } }
  for i, sp in ipairs(spots) do
    if (i + frames // 20) % 2 == 0 then
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx + sp[1], cy + sp[2], 2)
    end
  end
  gfx.setColor(WHITE)
  gfx.fillTriangle(cx, cy - 19, cx - 2, cy - 15, cx + 2, cy - 15)
  gfx.setColor(BLACK)
end

function CAFE.art.pumpkin(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setLineWidth(1)
  gfx.drawLine(cx, cy - 3, cx, cy + 13)
  gfx.fillRect(cx - 1, cy - 7, 3, 5)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 2, cy + 5, cx - 4, cy + 1)
  gfx.fillTriangle(cx + 2, cy + 5, cx + 6, cy + 5, cx + 4, cy + 1)
  gfx.fillRect(cx - 4, cy + 8, 8, 2)
end

-- ---- tiny wall art (about 20 x 16, hung on the open wall above the counter) -------------------------
local function tinyFrame(cx, cy, w, h)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - w // 2, cy - h // 2, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(cx - w // 2, cy - h // 2, w, h)
  gfx.setLineWidth(1)
end
function CAFE.art.t1(cx, cy)                      -- landscape: mountains and a sun
  tinyFrame(cx, cy, 22, 16)
  gfx.fillTriangle(cx - 8, cy + 5, cx - 3, cy - 3, cx + 2, cy + 5)
  gfx.fillTriangle(cx - 1, cy + 5, cx + 4, cy - 1, cx + 9, cy + 5)
  gfx.drawCircleAtPoint(cx + 5, cy - 4, 2)
end
function CAFE.art.t2(cx, cy)                      -- heart
  tinyFrame(cx, cy, 18, 18)
  gfx.fillCircleAtPoint(cx - 3, cy - 2, 3)
  gfx.fillCircleAtPoint(cx + 3, cy - 2, 3)
  gfx.fillTriangle(cx - 6, cy - 1, cx + 6, cy - 1, cx, cy + 6)
end
function CAFE.art.t3(cx, cy)                      -- sunburst
  tinyFrame(cx, cy, 20, 16)
  gfx.setColor(BLACK)
  for a = 0, 315, 45 do
    local r = math.rad(a)
    gfx.drawLine(cx + math.floor(3 * math.cos(r) + 0.5), cy + math.floor(3 * math.sin(r) + 0.5),
                 cx + math.floor(6 * math.cos(r) + 0.5), cy + math.floor(6 * math.sin(r) + 0.5))
  end
  gfx.fillCircleAtPoint(cx, cy, 2)
end
function CAFE.art.t4(cx, cy)                      -- a mug print
  tinyFrame(cx, cy, 20, 18)
  gfx.fillRect(cx - 5, cy - 3, 9, 8)
  gfx.drawCircleAtPoint(cx + 5, cy + 1, 2)
  gfx.drawLine(cx - 3, cy - 6, cx - 3, cy - 4)
  gfx.drawLine(cx + 1, cy - 6, cx + 1, cy - 4)
end
function CAFE.art.t5(cx, cy)                      -- round cat portrait
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 9)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy, 9); gfx.setLineWidth(1)
  gfx.fillTriangle(cx - 6, cy - 1, cx - 5, cy - 7, cx - 2, cy - 3)
  gfx.fillTriangle(cx + 6, cy - 1, cx + 5, cy - 7, cx + 2, cy - 3)
  gfx.fillCircleAtPoint(cx, cy + 1, 6)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx - 2, cy, 1); gfx.fillCircleAtPoint(cx + 2, cy, 1)
  gfx.setColor(BLACK)
end
function CAFE.art.t6(cx, cy)                      -- oval mirror with a shine
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 7, cy - 9, 14, 18)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 7, cy - 9, 14, 18); gfx.setLineWidth(1)
  gfx.drawLine(cx - 3, cy - 4, cx - 1, cy - 6)
  gfx.drawLine(cx - 4, cy, cx + 1, cy - 7)
end
function CAFE.art.t7(cx, cy)                      -- bunting: a string of little flags
  tinyFrame(cx, cy, 34, 16)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 14, cy - 5, cx, cy - 2); gfx.drawLine(cx, cy - 2, cx + 14, cy - 5)
  for i = -2, 2 do
    local x = cx + i * 6
    local y = cy - 5 + (2 - math.abs(i)) * 1 + math.floor(math.abs(2 - math.abs(i)) * 0.5)
    y = cy - 5 + math.floor((2 - math.abs(i)) * 1.5 + 0.5)
    if i % 2 == 0 then gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
    else
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    end
  end
end
function CAFE.art.t8(cx, cy)                      -- paper plane
  tinyFrame(cx, cy, 22, 16)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 7, cy - 1, cx + 7, cy - 5, cx, cy + 4)
  gfx.setColor(WHITE); gfx.drawLine(cx - 7, cy - 1, cx + 2, cy - 1); gfx.drawLine(cx + 2, cy - 1, cx, cy + 4)
  gfx.setColor(BLACK)
end
function CAFE.art.t9(cx, cy)                      -- music notes
  tinyFrame(cx, cy, 18, 18)
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx - 3, cy + 4, 2); gfx.fillCircleAtPoint(cx + 3, cy + 3, 2)
  gfx.drawLine(cx - 1, cy + 4, cx - 1, cy - 4); gfx.drawLine(cx + 5, cy + 3, cx + 5, cy - 5)
  gfx.setLineWidth(2); gfx.drawLine(cx - 1, cy - 4, cx + 5, cy - 5); gfx.setLineWidth(1)
end
function CAFE.art.t10(cx, cy)                     -- moon and stars
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 12, cy - 9, 24, 18, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 3, cy, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx - 1, cy - 1, 5)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx + 5, cy - 4); gfx.drawPixel(cx + 8, cy + 3); gfx.drawPixel(cx + 4, cy + 5)
  gfx.drawLine(cx + 6, cy - 6, cx + 6, cy - 2)
  gfx.setColor(BLACK)
end
function CAFE.art.t12(cx, cy)                     -- sailboat
  tinyFrame(cx, cy, 22, 18)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 1, cy - 6, cx - 1, cy + 2, cx - 6, cy + 2)
  gfx.drawLine(cx + 1, cy - 4, cx + 1, cy + 2); gfx.drawLine(cx + 1, cy - 4, cx + 6, cy + 2); gfx.drawLine(cx + 1, cy + 2, cx + 6, cy + 2)
  gfx.fillPolygon(cx - 7, cy + 4, cx + 7, cy + 4, cx + 5, cy + 7, cx - 5, cy + 7)
end

function CAFE.art.table(cx, cy)
  for k = -1, 1, 2 do
    gfx.setColor(WHITE)
    gfx.fillRoundRect(cx + k * 17 - 6, cy - 9, 12, 18, 3)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(cx + k * 17 - 6, cy - 9, 12, 18, 3)
  end
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 13)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 13)
  gfx.setLineWidth(1)
end

local function smallPot(cx, cy)                -- a little pot for the counter
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 6, cy + 4, cx + 6, cy + 4, cx + 4, cy + 10, cx - 4, cy + 10)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 5, cy + 5, 10, 1)
  gfx.setColor(BLACK)
end

local function bloom(x, y, r)                  -- a flower head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.fillCircleAtPoint(x, y, math.max(1, r - 2))
end

function CAFE.art.tulips(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 3, cy + 4, cx + k * 4, cy - 4)
    gfx.fillTriangle(cx + k * 4 - 3, cy - 2, cx + k * 4 + 3, cy - 2, cx + k * 4, cy - 9)
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx, cy - 4)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.succ(cx, cy)
  gfx.setColor(BLACK)
  for k = -2, 2 do
    gfx.fillTriangle(cx, cy + 4, cx + k * 3 - 2, cy - 5 + math.abs(k), cx + k * 3 + 2, cy - 5 + math.abs(k))
  end
  gfx.setColor(WHITE)
  gfx.drawLine(cx, cy + 2, cx, cy - 3)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.daisies(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(cx - 4, cy + 1, 8, 9, 2)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(cx - 4, cy + 1, 8, 9, 2)
  for k = -1, 1 do
    gfx.drawLine(cx + k, cy + 1, cx + k * 5, cy - 6)
    bloom(cx + k * 5, cy - 7 - (k == 0 and 2 or 0), 3)
  end
end

function CAFE.art.minicac(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 2, cy - 7, 5, 12, 2)
  gfx.fillRoundRect(cx - 6, cy - 3, 3, 2, 1)
  gfx.fillRoundRect(cx - 6, cy - 6, 2, 5, 1)
  gfx.fillRoundRect(cx + 3, cy - 1, 3, 2, 1)
  gfx.fillRoundRect(cx + 5, cy - 4, 2, 5, 1)
  smallPot(cx, cy)
end

function CAFE.art.herbs(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do gfx.fillCircleAtPoint(cx + k * 4, cy - 1 - (k == 0 and 3 or 0), 3) end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 4, cy - 1)
  gfx.drawPixel(cx, cy - 4)
  gfx.drawPixel(cx + 4, cy - 1)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.palm(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 5, cx + 1, cy - 8)
  gfx.setLineWidth(1)
  for k = -3, 3 do
    gfx.drawLine(cx + 1, cy - 8, cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2)
    gfx.drawLine(cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2, cx + 1 + k * 5 + sw, cy - 11 + math.abs(k) * 3)
  end
  pot(cx, cy)
end

function CAFE.art.snake(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 3, cy + 5, cx - 5, cy - 12)
  gfx.fillTriangle(cx - 3, cy + 5, cx + 1, cy + 5, cx - 1, cy - 15)
  gfx.fillTriangle(cx + 1, cy + 5, cx + 4, cy + 5, cx + 3, cy - 10)
  gfx.fillTriangle(cx + 3, cy + 5, cx + 7, cy + 5, cx + 7, cy - 6)
  gfx.setColor(WHITE)
  gfx.drawLine(cx - 1, cy + 3, cx - 1, cy - 10)
  gfx.setColor(BLACK)
  pot(cx, cy)
end

function CAFE.art.sunflower(cx, cy)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 5, cx - 5, cy - 6)
  gfx.drawLine(cx + 3, cy + 5, cx + 6, cy - 3)
  gfx.fillTriangle(cx - 3, cy + 1, cx - 9, cy - 2, cx - 3, cy - 2)
  for _, f in ipairs({ { -5, -9, 5 }, { 6, -6, 4 } }) do
    for a = 0, 7 do
      local an = a * math.pi / 4
      gfx.fillCircleAtPoint(cx + f[1] + math.floor(math.cos(an) * (f[3] + 1)), cy + f[2] + math.floor(math.sin(an) * (f[3] + 1)), 1)
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 1)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 2)
  end
  pot(cx, cy)
end

function CAFE.art.bonsai(cx, cy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 6, cx - 2, cy + 1)
  gfx.drawLine(cx - 2, cy + 1, cx + 2, cy - 5)
  gfx.drawLine(cx + 2, cy - 5, cx - 1, cy - 9)
  gfx.setLineWidth(1)
  for _, c in ipairs({ { -7, -6, 5 }, { 0, -12, 6 }, { 8, -7, 5 }, { -2, -7, 4 } }) do
    gfx.fillCircleAtPoint(cx + c[1], cy + c[2], c[3])
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 7, cy - 6); gfx.drawPixel(cx + 1, cy - 12); gfx.drawPixel(cx + 8, cy - 7)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 9, cy + 6, 18, 2)
  gfx.fillRect(cx - 8, cy + 8, 3, 6)
  gfx.fillRect(cx + 5, cy + 8, 3, 6)
  gfx.fillRect(cx - 10, cy + 6, 20, 1)
end

function CAFE.art.monstera(cx, cy)
  gfx.setColor(BLACK)
  local leaves = { { -8, -4, 7, 5 }, { 1, -12, 8, 6 }, { 8, -3, 7, 5 }, { -2, -3, 6, 5 } }
  for _, l in ipairs(leaves) do
    gfx.fillEllipseInRect(cx + l[1] - l[3], cy + l[2] - l[4], l[3] * 2, l[4] * 2)
    gfx.setColor(WHITE)
    gfx.drawLine(cx + l[1] - 2, cy + l[2], cx + l[1] + 2, cy + l[2])         -- the leaf's splits
    gfx.drawPixel(cx + l[1], cy + l[2] - 2)
    gfx.setColor(BLACK)
  end
  gfx.drawLine(cx, cy + 5, cx - 6, cy - 2)
  gfx.drawLine(cx, cy + 5, cx + 7, cy - 2)
  pot(cx, cy)
end

function CAFE.art.cattree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy - 13, 4, 26)
  gfx.fillRect(cx - 10, cy + 12, 20, 3)
  gfx.fillRect(cx - 10, cy - 14, 20, 3)
  gfx.fillRect(cx - 9, cy - 1, 18, 3)
  gfx.setColor(WHITE)
  for k = -8, 6, 4 do gfx.drawPixel(cx + k, cy - 13) end
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy - 1, cx + 7, cy + 5)            -- a hanging toy
  gfx.fillCircleAtPoint(cx + 7, cy + 6, 2)
end

function CAFE.art.dogbed(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillEllipseInRect(cx - 9, cy + 3, 18, 8)
  gfx.setColor(BLACK)
end

function CAFE.drawWallItems()
  local d = G.cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "wall" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.WSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1] + sl[3] // 2, sl[2] + sl[4] // 2)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawTinyItems()
  local d = G.cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "tiny" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.XSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawCounterItems()
  if G.mode ~= "cafe" then return end
  local d = G.cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "counter" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.CSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

-- leafy vines hanging off the cup shelf's ends
function CAFE.drawVines()
  if G.mode ~= "cafe" then return end
  local d = G.cafe
  local function vine(x0, lens, flowers)
    for i, len in ipairs(lens) do
      local x = x0 + (i - 1) * 4
      local px, py = x, 43
      for yy = 45, 43 + len, 3 do
        local xx = x + math.floor(math.sin(frames * 0.05 + yy * 0.3 + i) * 1.5 + 0.5)
        gfx.setColor(BLACK)
        gfx.drawLine(px, py, xx, yy)
        px, py = xx, yy
        if (yy // 3) % 2 == 0 then
          gfx.setColor(WHITE)
          gfx.fillCircleAtPoint(xx + ((i % 2 == 0) and 2 or -2), yy, 2)
          gfx.setColor(BLACK)
          gfx.drawCircleAtPoint(xx + ((i % 2 == 0) and 2 or -2), yy, 2)
          if flowers and yy >= 43 + len - 4 then
            gfx.fillCircleAtPoint(xx, yy + 2, 2)
          end
        end
      end
    end
    gfx.setColor(BLACK)
  end
  if d.decor.ivy == "on" then vine(100, { 14, 24, 18 }, false) end
  if d.decor.bloomvine == "on" then vine(180, { 20, 14, 26 }, true) end
end

function CAFE.drawFloorItems()
  if G.mode ~= "cafe" then return end
  local d = G.cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.FSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.decorOn(id)
  return G ~= nil and G.mode == "cafe" and G.cafe.decor[id] == "on"
end

function CAFE.drawLights()
  if not CAFE.decorOn("lights") then return end
  local prev
  for x = 0, 400, 4 do
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    gfx.setColor(WHITE)
    if prev then gfx.drawLine(prev[1], prev[2], x, y) end
    prev = { x, y }
  end
  for i = 0, 20 do
    local x = i * 20 + 10
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5) + 3
    local lit = ((i + frames // 24) % 2 == 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, lit and 3 or 2)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(x, y, lit and 3 or 2)
  end
  gfx.setColor(BLACK)
end

-- a long runner rolled out in front of the register, down the line (drawn at any size, so the
-- shop preview can shrink it to fit its box)
function CAFE.runnerAt(which, x, y, w, h)
  local big = w >= 30
  local r = big and 5 or 2
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 4 or 2                      -- border width
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  local cx = x + w // 2
  if which == "run1" then                       -- red carpet
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(WHITE)
    if big then gfx.drawRoundRect(x + 7, y + 7, w - 14, h - 14, 2) end
    local step = math.max(4, h // 14)
    for yy = y + step + m, y + h - step - m, step do gfx.fillRect(cx - 1, yy, big and 3 or 2, big and 3 or 2) end
  elseif which == "run2" then                   -- stripes
    local step = math.max(3, h // 15)
    for yy = iy, iy + ih - 2, step do gfx.fillRect(ix, yy, iw, math.max(1, step // 2)) end
  elseif which == "run3" then                   -- checker
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(ix, iy, iw, ih, big and 3 or 1)
  elseif which == "run4" then                   -- diamonds
    local step = math.max(6, h * 14 // 118)
    local hw, hh = math.max(3, w * 8 // 36), math.max(3, step * 6 // 14)
    for yy = y + step, y + h - step + 1, step do
      gfx.drawLine(cx, yy - hh, cx + hw, yy)
      gfx.drawLine(cx + hw, yy, cx, yy + hh)
      gfx.drawLine(cx, yy + hh, cx - hw, yy)
      gfx.drawLine(cx - hw, yy, cx, yy - hh)
      gfx.fillCircleAtPoint(cx, yy, big and 2 or 1)
    end
  else                                          -- coffee beans
    local n = big and 7 or 5
    for i = 0, n - 1 do
      local bx = cx + ((i % 2 == 0) and -w // 5 or w // 5)
      local by = y + (h * (i + 0.5)) // n
      if big then drawBean(bx, by, 1) else gfx.fillCircleAtPoint(bx, by, 2) end
    end
  end
  gfx.setColor(BLACK)
  if big then for xx = x + 3, x + w - 3, 5 do gfx.drawLine(xx, y + h, xx, y + h + 3) end end   -- fringe at the door end
end

function CAFE.drawRunner()
  for _, id in ipairs({ "run1", "run2", "run3", "run4", "run5" }) do
    if CAFE.decorOn(id) then CAFE.runnerAt(id, 38, 116, 36, 118) end
  end
end

-- the big centre rug
function CAFE.rugAt(which, x, y, w, h)
  local big = w >= 100
  local r = big and 8 or 3
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 6 or 2
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  if big then gfx.drawRoundRect(ix, iy, iw, ih, 5) end
  local m2 = big and 2 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  if which == "rug" then
    gfx.setPattern(TEA)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
  elseif which == "rug2" then
    gfx.setColor(BLACK)
    local step = big and 6 or 3
    for yy = fy + 1, fy + fh - 2, step do gfx.fillRect(fx, yy, fw, big and 3 or 1) end
  else
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
    gfx.setColor(BLACK)
    local k = big and 6 or 2
    gfx.drawRoundRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k, big and 3 or 1)
  end
  gfx.setColor(BLACK)
  if big then
    for xx = x + 6, x + w - 8, 12 do            -- fringe
      gfx.drawLine(xx, y, xx, y - 3)
      gfx.drawLine(xx, y + h, xx, y + h + 3)
    end
  end
end

-- ---- table dressing: cloths and centrepieces ----------------------------------------------------------
function CAFE.ownedOf(kind)
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == kind and CAFE.decorOn(it.id) then return it.id end
  end
  return nil
end

function CAFE.clothAt(id, x, y, r)
  local R = r + math.max(2, r // 3)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, R)
  gfx.setColor(BLACK)
  if id == "cloth1" then                         -- checker
    gfx.setPattern(CHECK)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
  elseif id == "cloth2" then                     -- stripes
    for dy = -R + 1, R - 1, 3 do
      local hw = math.floor(math.sqrt(R * R - dy * dy))
      gfx.fillRect(x - hw, y + dy, 2 * hw, 2)
    end
  else                                           -- lace: scalloped edge and a dotted ring
    for a = 0, 330, 30 do
      local rad = math.rad(a)
      local sx, sy = x + math.floor(R * math.cos(rad) + 0.5), y + math.floor(R * math.sin(rad) + 0.5)
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx, sy, math.max(2, r // 6))
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(sx, sy, math.max(2, r // 6))
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 1)
    gfx.setColor(BLACK)
    for a = 0, 345, 15 do
      local rad = math.rad(a)
      gfx.drawPixel(x + math.floor((r + 1) * math.cos(rad) + 0.5), y + math.floor((r + 1) * math.sin(rad) + 0.5))
    end
  end
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, R)
end

function CAFE.centerAt(id, x, y, k)              -- a tiny thing in the middle of a table (k = size)
  gfx.setColor(BLACK)
  if id == "cp1" then                            -- flowers in a vase
    gfx.fillRect(x - k, y, 2 * k, 3 * k)
    for _, o in ipairs({ { -2, -2 }, { 0, -3 }, { 2, -2 } }) do
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + o[1] * k, y + o[2] * k, k)
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + o[1] * k, y + o[2] * k, k)
    end
  elseif id == "cp2" then                        -- candle
    gfx.setColor(WHITE); gfx.fillRect(x - k, y - 2 * k, 2 * k, 4 * k)
    gfx.setColor(BLACK); gfx.drawRect(x - k, y - 2 * k, 2 * k, 4 * k)
    gfx.fillTriangle(x - k, y - 2 * k, x + k, y - 2 * k, x, y - 5 * k + (frames // 6) % 2)
  elseif id == "cp3" then                        -- sprig in a pot
    gfx.fillPolygon(x - 2 * k, y, x + 2 * k, y, x + k, y + 3 * k, x - k, y + 3 * k)
    gfx.drawLine(x, y, x, y - 3 * k)
    gfx.drawLine(x, y - k, x - 2 * k, y - 3 * k)
    gfx.drawLine(x, y - 2 * k, x + 2 * k, y - 4 * k)
  else                                           -- cactus
    gfx.fillRect(x - k, y - 3 * k, 2 * k, 6 * k)
    gfx.fillRect(x - 3 * k, y - 2 * k, 2 * k, k)
    gfx.fillRect(x - 3 * k, y - 3 * k, k, 2 * k)
    gfx.fillRect(x + k, y - k, 2 * k, k)
    gfx.fillRect(x + 2 * k, y - 2 * k, k, 2 * k)
  end
  gfx.setColor(BLACK)
end

function CAFE.tableAt(x, y, r, cloth, cp, k)
  if cloth then CAFE.clothAt(cloth, x, y, r) end
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.setLineWidth(1)
  if cp then CAFE.centerAt(cp, x, y, k) end
end

function CAFE.drawRug()
  for _, id in ipairs({ "rug", "rug2", "rug3" }) do
    if CAFE.decorOn(id) then CAFE.rugAt(id, 112, 128, 190, 44) end
  end
end

-- ---- pets --------------------------------------------------------------------------------------------
function CAFE.homeOf(kind)               -- where the pet's own furniture is (if you've put it out)
  local d = G.cafe
  local id = (kind == "cat") and "cattree" or "dogbed"
  if d.decor[id] == "on" and d.place[id] then
    local sl = CAFE.FSLOT[d.place[id]]
    return sl[1], sl[2]
  end
  return nil
end

function CAFE.makePets()
  local pets = {}
  local d = CAFE.cur
  for _, kind in ipairs({ "cat", "dog" }) do
    if d.decor[kind] == "on" then
      pets[kind] = { x = 60 + math.random() * 280, y = 130 + math.random() * 90, tx = 0, ty = 0,
                     mode = "idle", wait = 1 + math.random() * 3, dir = 1, home = false,
                     pose = (kind == "cat") and "sit" or "sit" }
    end
  end
  return pets
end

function CAFE.updatePets(dt)
  for kind, p in pairs(G.pets) do
    local speed = (kind == "cat") and 20 or 26
    if p.mode == "walk" then
      local dx, dy = p.tx - p.x, p.ty - p.y
      local dist = math.sqrt(dx * dx + dy * dy)
      if dist <= speed * dt then
        p.x, p.y = p.tx, p.ty
        p.mode = p.home and "rest" or "idle"
        if kind == "cat" then
          p.pose = (math.random() < (p.home and 0.7 or 0.45)) and "sleep" or "sit"
        else
          p.pose = p.home and "lie" or ((math.random() < 0.55) and "sit" or "lie")
        end
        local sleepy = (p.pose == "sleep" or p.pose == "lie")
        p.wait = p.home and (12 + math.random() * 14) or (sleepy and (7 + math.random() * 9) or (2 + math.random() * 5))
      else
        p.x = p.x + dx / dist * speed * dt
        p.y = p.y + dy / dist * speed * dt
        if math.abs(dx) > 1 then p.dir = dx > 0 and 1 or -1 end
      end
    else
      p.wait = p.wait - dt
      if p.wait <= 0 then
        local hx, hy = CAFE.homeOf(kind)
        if hx and not p.home and math.random() < ((kind == "dog") and 0.65 or 0.45) then
          p.tx, p.ty, p.home = hx, hy + ((kind == "cat") and 14 or 10), true
        else
          p.tx, p.ty, p.home = 50 + math.random() * 330, 126 + math.random() * 100, false
        end
        p.mode = "walk"
      end
    end
  end
end

-- a floating "z" for sleepers
function CAFE.zzz(x, y)
  local k = (frames // 18) % 3
  for i = 0, 1 do
    local zy = y - 5 - i * 6 - k
    local sz = 2 + i
    gfx.drawLine(x + i * 4, zy, x + i * 4 + sz, zy)
    gfx.drawLine(x + i * 4 + sz, zy, x + i * 4, zy + sz)
    gfx.drawLine(x + i * 4, zy + sz, x + i * 4 + sz, zy + sz)
  end
end

-- an ear: black, with a thin white edge so it shows up against the black head
function CAFE.ear(x1, y1, x2, y2, x3, y3)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  gfx.setColor(WHITE)
  gfx.drawLine(x1, y1, x3, y3)
  gfx.setColor(BLACK)
end

-- x, y = where the feet are. cat: walk / sit / sleep.  dog: walk / sit / lie
function CAFE.pet(kind, x, y, dir, pose)
  x, y = math.floor(x), math.floor(y)
  gfx.setColor(BLACK)
  local step = math.floor(math.sin(frames * 0.5) * 1.5)
  local wag = math.floor(math.sin(frames * 0.35) * 3)
  local breathe = math.floor(math.sin(frames * 0.12) + 0.5)
  if kind == "cat" then
    if pose == "walk" then
      gfx.fillEllipseInRect(x - 7, y - 8, 14, 7)
      gfx.fillCircleAtPoint(x + dir * 7, y - 9, 3)
      CAFE.ear(x + dir * 5, y - 11, x + dir * 6, y - 16, x + dir * 8, y - 11)
      CAFE.ear(x + dir * 8, y - 11, x + dir * 10, y - 15, x + dir * 10, y - 10)
      gfx.drawLine(x - dir * 7, y - 6, x - dir * 11, y - 12 + step)
      gfx.drawLine(x - 4, y - 2, x - 4 + step, y)
      gfx.drawLine(x + 4, y - 2, x + 4 - step, y)
      gfx.setColor(WHITE); gfx.drawPixel(x + dir * 8, y - 10); gfx.setColor(BLACK)
    elseif pose == "sleep" then                     -- curled up in a ball
      gfx.fillEllipseInRect(x - 9, y - 8 - breathe, 18, 8 + breathe)
      gfx.fillCircleAtPoint(x + dir * 6, y - 5, 3)
      CAFE.ear(x + dir * 4, y - 7, x + dir * 5, y - 11, x + dir * 7, y - 7)
      CAFE.ear(x + dir * 7, y - 7, x + dir * 9, y - 10, x + dir * 9, y - 6)
      gfx.setColor(WHITE)
      gfx.drawLine(x + dir * 5, y - 5, x + dir * 7, y - 5)         -- closed eyes
      gfx.drawLine(x - 6, y - 3, x + 3, y - 1)                      -- the tail wrapped round
      gfx.setColor(BLACK)
      CAFE.zzz(x + dir * 9, y - 8)
    else                                            -- sitting, looking out
      gfx.fillEllipseInRect(x - 5, y - 9, 10, 9)
      gfx.fillCircleAtPoint(x + dir, y - 12, 4)
      CAFE.ear(x + dir - 3, y - 14, x + dir - 3, y - 18, x + dir, y - 15)
      CAFE.ear(x + dir + 3, y - 14, x + dir + 3, y - 18, x + dir, y - 15)
      gfx.drawLine(x - dir * 5, y - 2, x - dir * 10, y - 6)
      gfx.drawLine(x - dir * 10, y - 6, x - dir * 9, y - 10 + wag // 2)
      gfx.setColor(WHITE); gfx.drawPixel(x + dir - 1, y - 12); gfx.drawPixel(x + dir + 2, y - 12); gfx.setColor(BLACK)
    end
  else
    if pose == "walk" then
      gfx.fillEllipseInRect(x - 10, y - 12, 20, 9)
      gfx.fillCircleAtPoint(x + dir * 10, y - 14, 4)
      gfx.fillRect(x + dir * 10 + (dir > 0 and 2 or -7), y - 14, 5, 3)          -- snout
      CAFE.ear(x + dir * 8, y - 18, x + dir * 12, y - 17, x + dir * 10, y - 9)   -- a floppy ear
      gfx.drawLine(x - dir * 10, y - 10, x - dir * 15, y - 15 + wag)            -- wagging tail
      gfx.drawLine(x - 7, y - 4, x - 7 + step, y)
      gfx.drawLine(x - 3, y - 4, x - 3 - step, y)
      gfx.drawLine(x + 4, y - 4, x + 4 + step, y)
      gfx.drawLine(x + 8, y - 4, x + 8 - step, y)
      gfx.setColor(WHITE)
      gfx.drawPixel(x + dir * 11, y - 15)                                        -- eye
      gfx.fillEllipseInRect(x - 3, y - 7, 8, 3)                                  -- pale belly
      gfx.setColor(BLACK)
    elseif pose == "sit" then
      gfx.fillEllipseInRect(x - 10, y - 10, 14, 10)                              -- haunches
      gfx.fillRoundRect(x + (dir > 0 and 0 or -6), y - 16, 6, 16, 2)             -- chest and front legs
      gfx.fillCircleAtPoint(x + dir * 3, y - 19, 4)
      gfx.fillRect(x + dir * 3 + (dir > 0 and 2 or -7), y - 19, 5, 3)
      CAFE.ear(x + dir * 1, y - 23, x + dir * 5, y - 23, x + dir * 2, y - 14)
      gfx.drawLine(x - dir * 9, y - 2, x - dir * 14, y - 3 + wag)
      gfx.setColor(WHITE); gfx.drawPixel(x + dir * 4, y - 20); gfx.drawLine(x + dir * 3, y - 10, x + dir * 3, y - 3); gfx.setColor(BLACK)
    else                                                                          -- lying down, asleep
      gfx.fillEllipseInRect(x - 10, y - 7 - breathe, 20, 7 + breathe)
      gfx.fillCircleAtPoint(x + dir * 10, y - 4, 4)
      gfx.fillRect(x + dir * 10 + (dir > 0 and 2 or -7), y - 4, 5, 3)
      CAFE.ear(x + dir * 8, y - 8, x + dir * 12, y - 7, x + dir * 10, y)
      gfx.drawLine(x - dir * 10, y - 3, x - dir * 14, y - 5)
      gfx.setColor(WHITE); gfx.drawLine(x + dir * 9, y - 5, x + dir * 11, y - 5); gfx.setColor(BLACK)
      CAFE.zzz(x + dir * 4, y - 8)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawPets()
  for kind, p in pairs(G.pets) do
    if p.mode == "walk" then
      CAFE.pet(kind, p.x, p.y, p.dir, "walk")
    elseif p.mode == "rest" and p.home then
      local hx, hy = CAFE.homeOf(kind)
      if hx and kind == "cat" then CAFE.pet("cat", hx, hy - 14, p.dir, p.pose)
      elseif hx then CAFE.pet("dog", hx, hy + 10, 1, "lie")            -- curled up on the dog bed
      else CAFE.pet(kind, p.x, p.y, p.dir, p.pose) end
    else
      CAFE.pet(kind, p.x, p.y, p.dir, p.pose)
    end
  end
end

-- ---- going in and out --------------------------------------------------------------------------------
function CAFE.open()
  transitionTo(function()
    for i = 1, 3 do CAFE.slots[i] = CAFE.read(i) end
    CAFE.mode, CAFE.erase, CAFE.sel = "slots", nil, 1
    UI.setTitleItem(false)
    state = CAFE.STATE
  end)
end

function CAFE.begin()                          -- off to the store
  CAFE.write()                                 -- starting a shift saves the game
  sfxStart()
  transitionTo(function()
    newGame("cafe")
    state = STATE_PLAY
  end)
end

function CAFE.finish()                         -- the shift is over: bank it, open the shop
  G.total = G.cash + G.tips
  local d = CAFE.cur
  d.money = d.money + G.total
  d.shifts = d.shifts + 1
  CAFE.report = "Shift: " .. money(G.total) .. " from " .. G.served .. " customers"
  CAFE.write()
  CAFE.mode, CAFE.shopSel, CAFE.scroll, CAFE.msg = "shop", 1, 0, nil
  state = CAFE.STATE
end

function CAFE.saveQuit()                       -- Menu button: bank what you've made so far
  if state ~= STATE_PLAY or not G or G.mode ~= "cafe" or G.ending then return end
  G.ending = true
  CAFE.cur.money = CAFE.cur.money + G.cash + G.tips
  G.cash, G.tips = 0, 0
  CAFE.write()
  CAFE.goTitle()
end

-- ---- the shop ----------------------------------------------------------------------------------------
function CAFE.rows()
  local d = CAFE.cur
  local rows = {}
  rows[#rows + 1] = { "START NEXT SHIFT", "", "start" }
  rows[#rows + 1] = { "SAVE & QUIT", "", "quit" }
  if d.seatStep < 5 then
    local cost = math.floor(CAFE.SEAT_COST[d.seatStep + 1] * 100 * CAFE.PRICE + 0.5)
    local nxt = CAFE.SEAT_N[d.seatStep + 1]
    local label = (d.seatStep == 4) and "Corner booth (L-table)" or ("Add a table  " .. CAFE.seatsOf(d.seatStep) .. " > " .. nxt .. " seats")
    rows[#rows + 1] = { label, money(cost), "seat", cost, nil, (d.seatStep == 0) and "Allows customers to dine in" or "More seats, bigger tips" }
  else
    rows[#rows + 1] = { "Seats  " .. CAFE.seatsOf(5), "MAX", "none" }
  end
  if d.cups < 8 then
    local cost = CAFE.CUP_COST[d.cups - 1] * 100 * CAFE.PRICE
    rows[#rows + 1] = { "More cups  " .. d.cups .. " > " .. (d.cups + 1), money(cost), "cup", cost, nil, "Cups for dine-in drinks" }
  else
    rows[#rows + 1] = { "Cups  " .. d.cups, "MAX", "none" }
  end
  rows[#rows + 1] = { "Name sign", d.sign == false and "OFF" or "ON", "sign" }
  for _, it in ipairs(CAFE.ITEMS) do
    if it.needs == nil or d.decor[it.needs] ~= nil then
      local st = d.decor[it.id]
      if st == nil then
        rows[#rows + 1] = { it.name, money(it.cost * 100 * CAFE.PRICE), "buy", it.cost * 100 * CAFE.PRICE, it.id, CAFE.DESC[it.id] }
      else
        rows[#rows + 1] = { it.name, st == "on" and "ON" or "OFF", "toggle", 0, it.id, CAFE.DESC[it.id] }
      end
    end
  end
  return rows
end

function CAFE.say(str) CAFE.msg, CAFE.msgT = str, 2.4 end

-- put a wall/floor piece on the grid (picking the spot if there's a choice)
function CAFE.putOut(id)
  local d, it = CAFE.cur, CAFE.byId[id]
  if CAFE.isGrid(it) then
    local free = CAFE.freeSlots(d, it.kind)
    if #free == 0 then
      d.decor[id] = "off"
      CAFE.say((it.kind == "wall" or it.kind == "tiny") and "Wall's full: turn something off first." or (it.kind == "counter" and "Counter's full: turn something off first." or "Floor's full: turn something off first."))
    elseif #free == 1 then
      d.place[id] = free[1]
      d.decor[id] = "on"
    else
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      d.decor[id] = "off"
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
      return
    end
  elseif it.kind == "rug" or it.kind == "runner" or it.kind == "cloth" or it.kind == "centerpiece" then        -- one of each kind at a time
    for _, o in ipairs(CAFE.ITEMS) do
      if o.kind == it.kind and d.decor[o.id] == "on" then d.decor[o.id] = "off" end
    end
    d.decor[id] = "on"
  else
    d.decor[id] = "on"
  end
  CAFE.write()
end

function CAFE.buy(row)
  local d = CAFE.cur
  if d.money < row[4] then
    sfxWrong()
    CAFE.say("Not enough money yet.")
    return
  end
  if row[3] == "seat" and d.seatStep < 4 then       -- a table: choose where it goes, pay when it's down
    local used, free = {}, {}
    for k = 1, 4 do if d.tables[k] then used[d.tables[k]] = true end end
    for i = 1, #CAFE.TSLOT do if not used[i] then free[#free + 1] = i end end
    CAFE.pend, CAFE.spots, CAFE.spotSel, CAFE.pendCost = "table", free, 1, row[4]
    transitionTo(function()
      G = CAFE.stageG()
      CAFE.mode = "place"
    end)
    return
  end
  d.money = d.money - row[4]
  local it = CAFE.byId[row[5] or ""]
  d.stars = clamp(d.stars + (it and (it.kind == "pet" and 0.2 or 0.08) or 0.2), 0, 5)    -- upgrades earn stars
  sfxPlay("tip", false, 1.0)
  if row[3] == "cup" then d.cups = d.cups + 1; CAFE.say("Bought!")
  elseif row[3] == "seat" then d.seatStep = d.seatStep + 1; CAFE.say("Bought!")
  else
    d.decor[row[5]] = "off"
    CAFE.say("Bought!")
    CAFE.putOut(row[5])
    return
  end
  CAFE.write()
end

function CAFE.toggle(row)
  local d = CAFE.cur
  if row[3] == "sign" then
    if d.sign == false then
      if CAFE.slotTaken(d, "wall", 2) or CAFE.slotTaken(d, "wall", 3) then
        -- (sign is off, so the slot test is just about the other decor)
      end
      local blocked = false
      for _, it in ipairs(CAFE.ITEMS) do
        if it.kind == "wall" and d.decor[it.id] == "on" and (d.place[it.id] == 2 or d.place[it.id] == 3) then blocked = true end
      end
      if blocked then sfxWrong(); CAFE.say("Take down the wall decor in its spot first."); return end
      d.sign = true
    else
      d.sign = false
    end
    sfxClick()
    CAFE.write()
    return
  end
  local id = row[5]
  if d.decor[id] == "on" then
    d.decor[id] = "off"
    d.place[id] = nil
    sfxClick()
    CAFE.write()
  else
    sfxClick()
    CAFE.putOut(id)
  end
end

-- a stand-in for the cafe with nobody in it (for choosing where things go)
function CAFE.stageG()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  return { mode = "cafe", cafe = d, t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
           px = -300, moving = false, walk = 0, sel = "down", st = nil, cust = nil,
           cupMax = d.cups, seatLimit = CAFE.seatsOf(d.seatStep),
           cups = { shelf = d.cups, dirty = 0, hand = 0 },
           sink = { state = "empty", progress = 0, angle = 0, t = 0 },
           win = WIN.newWindow(), line = {}, others = {}, seats = {}, door = 0, popups = {}, ending = true }
end

function CAFE.spotRect(kind, i)
  if kind == "counter" then
    local sl = CAFE.CSLOT[i]
    return sl[1] - 14, 74, 28, 24
  end
  if kind == "tiny" then
    local sl = CAFE.XSLOT[i]
    return sl[1] - 19, sl[2] - 9, 38, 18
  end
  if kind == "table" then
    local sl = CAFE.TSLOT[i]
    return sl[1] - 27, sl[2] - 19, 54, 38
  end
  if kind == "wall" then
    local sl = CAFE.WSLOT[i]
    return sl[1], sl[2], sl[3], sl[4]
  end
  local sl = CAFE.FSLOT[i]
  return sl[1] - 16, sl[2] - 18, 32, 36
end

function CAFE.leavePlace(placed)
  local id = CAFE.pend
  if placed then
    local d = CAFE.cur
    if id == "table" then
      d.money = d.money - CAFE.pendCost
      d.seatStep = d.seatStep + 1
      d.tables[d.seatStep] = CAFE.spots[CAFE.spotSel]
      d.stars = clamp(d.stars + 0.2, 0, 5)
    else
      d.place[id] = CAFE.spots[CAFE.spotSel]
      d.decor[id] = "on"
    end
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  transitionTo(function()
    G = nil
    CAFE.pend = nil
    CAFE.mode = "shop"
  end)
end

-- ---- screens -------------------------------------------------------------------------------------------
function CAFE.update(dt)
  if CAFE.msgT > 0 then CAFE.msgT = CAFE.msgT - dt; if CAFE.msgT <= 0 then CAFE.msg = nil end end
  local A_, B_ = pd.buttonJustPressed(pd.kButtonA), pd.buttonJustPressed(pd.kButtonB)
  local U, D = pd.buttonJustPressed(pd.kButtonUp), pd.buttonJustPressed(pd.kButtonDown)
  local L, R = pd.buttonJustPressed(pd.kButtonLeft), pd.buttonJustPressed(pd.kButtonRight)
  if CAFE.mode == "slots" then
    if CAFE.erase then
      if A_ then
        pcall(pd.datastore.delete, "cafe" .. CAFE.erase)
        CAFE.slots[CAFE.erase] = nil
        CAFE.erase = nil
        sfxClick()
      elseif B_ then CAFE.erase = nil; sfxClick() end
      return
    end
    if D then CAFE.sel = CAFE.sel % 3 + 1; sfxClick()
    elseif U then CAFE.sel = (CAFE.sel + 1) % 3 + 1; sfxClick()
    elseif R and CAFE.slots[CAFE.sel] then CAFE.erase = CAFE.sel; sfxClick()
    elseif B_ then CAFE.goTitle()
    elseif A_ then
      sfxClick()
      local i = CAFE.sel
      CAFE.slot = i
      if CAFE.slots[i] then
        CAFE.cur = CAFE.slots[i]
        transitionTo(function() CAFE.mode, CAFE.shopSel, CAFE.scroll, CAFE.report, CAFE.msg = "shop", 1, 0, "Welcome back!", nil end)
      else
        transitionTo(function() CAFE.mode, CAFE.name, CAFE.letter, CAFE.onDone = "name", "", 0, false end)
      end
    end
  elseif CAFE.mode == "name" then
    if CAFE.onDone then
      if L or B_ then CAFE.onDone = false; sfxClick()
      elseif A_ then
        local nm = CAFE.name:gsub("%s+$", "")
        if #nm >= 1 then
          CAFE.cur = CAFE.fresh(nm)
          CAFE.write()
          CAFE.begin()
        else
          sfxWrong()
          CAFE.onDone = false
        end
      end
      return
    end
    CAFE.crank = CAFE.crank + pd.getCrankChange()
    local step = 0
    if U then step = 1 elseif D then step = -1 end
    while CAFE.crank >= 24 do CAFE.crank = CAFE.crank - 24; step = step + 1 end
    while CAFE.crank <= -24 do CAFE.crank = CAFE.crank + 24; step = step - 1 end
    if step ~= 0 then CAFE.letter = (CAFE.letter + step) % 27; sfxClick() end
    if R then
      CAFE.onDone = true
      sfxClick()
    elseif A_ then
      if #CAFE.name < 10 then
        local ch = (CAFE.letter == 26) and " " or string.char(65 + CAFE.letter)
        if not (ch == " " and #CAFE.name == 0) then CAFE.name = CAFE.name .. ch; sfxClick() else sfxWrong() end
      else
        sfxWrong()
      end
    elseif B_ then
      if #CAFE.name > 0 then
        CAFE.name = CAFE.name:sub(1, -2)
        sfxClick()
      else
        sfxClick()
        transitionTo(function() CAFE.mode = "slots" end)
      end
    end
  elseif CAFE.mode == "place" then
    local n = #CAFE.spots
    if R or D then CAFE.spotSel = CAFE.spotSel % n + 1; sfxClick()
    elseif L or U then CAFE.spotSel = (CAFE.spotSel - 2) % n + 1; sfxClick()
    elseif A_ then CAFE.leavePlace(true)
    elseif B_ then CAFE.leavePlace(false) end
  else   -- shop
    local rows = CAFE.rows()
    if D then CAFE.shopSel = CAFE.shopSel % #rows + 1; sfxClick()
    elseif U then CAFE.shopSel = (CAFE.shopSel - 2) % #rows + 1; sfxClick()
    elseif A_ then
      local row = rows[CAFE.shopSel]
      local k = row[3]
      if k == "cup" or k == "seat" or k == "buy" then CAFE.buy(row)
      elseif k == "toggle" or k == "sign" then CAFE.toggle(row)
      elseif k == "start" then
        CAFE.write()
        sfxClick()
        CAFE.begin()
      elseif k == "quit" then
        CAFE.write()
        CAFE.goTitle()
      else
        sfxWrong()
      end
    end
    -- keep the highlighted row in view (8 rows fit)
    if CAFE.shopSel <= CAFE.scroll then CAFE.scroll = CAFE.shopSel - 1 end
    if CAFE.shopSel > CAFE.scroll + 8 then CAFE.scroll = CAFE.shopSel - 8 end
    if CAFE.scroll < 0 then CAFE.scroll = 0 end
  end
end

function CAFE.band(title)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(title, 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

-- a little box showing the highlighted item, inside a wobbly animated border
function CAFE.drawPreview(row)
  if row == nil or row[3] == "start" or row[3] == "quit" or row[3] == "none" then return end
  local id = row[5]
  if row[3] == "seat" then id = "table" end
  local art = id and CAFE.art[id]
  local bx, by, bw, bh = 298, 54, 92, 80
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  -- squiggly border: points on the rectangle edge pushed in/out by a moving sine
  local t = frames * 0.25
  local pts = {}
  local per = 2 * (bw + bh)
  local n = 40
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < bw then x, y, nx, ny = bx + d, by, 0, -1
    elseif d < bw + bh then x, y, nx, ny = bx + bw, by + (d - bw), 1, 0
    elseif d < 2 * bw + bh then x, y, nx, ny = bx + bw - (d - bw - bh), by + bh, 0, 1
    else x, y, nx, ny = bx, by + bh - (d - 2 * bw - bh), -1, 0 end
    local o = math.sin(i * 1.3 + t) * 1.8
    pts[#pts + 1] = { x + nx * o, y + ny * o }
  end
  gfx.setLineWidth(2)
  for i = 1, #pts - 1 do gfx.drawLine(pts[i][1], pts[i][2], pts[i + 1][1], pts[i + 1][2]) end
  gfx.drawLine(pts[#pts][1], pts[#pts][2], pts[1][1], pts[1][2])
  gfx.setLineWidth(1)
  gfx.setClipRect(bx + 4, by + 4, bw - 8, bh - 8)
  local cx, cy = bx + bw // 2, by + bh // 2 + 2
  local it = id and CAFE.byId[id]
  local function drawAs(fn, ox, oy)             -- run a "draw what's owned" routine as if only this id were on
    local save, saveG = CAFE.decorOn, G
    CAFE.decorOn = function(q) return q == id end
    G = { mode = "cafe", cafe = { decor = { [id] = "on" } } }
    gfx.setDrawOffset(ox, oy)
    pcall(fn)
    gfx.setDrawOffset(0, 0)
    G = saveG
    CAFE.decorOn = save
  end
  if it and it.kind == "runner" then
    local h = bh - 22                            -- shrunk to fit the box, whole
    local w = math.floor(h * 36 / 118 + 0.5)
    CAFE.runnerAt(id, cx - w // 2, by + 8, w, h)
  elseif it and it.kind == "rug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 44 / 190 + 0.5) + 4
    CAFE.rugAt(id, cx - w // 2, by + 10 + (bh - 22 - h) // 2, w, h)
  elseif it and it.kind == "shelf" then
    drawAs(CAFE.drawVines, cx - (id == "ivy" and 104 or 188), by + 10 - 43)
  elseif it and it.kind == "ceiling" then
    gfx.setColor(BLACK)                          -- (the real lights are white on the dark wall)
    local prev
    for x = bx + 4, bx + bw - 4, 3 do
      local y = cy - 6 + math.floor(4 * math.sin(math.pi * (x % 30) / 30) + 0.5)
      if prev then gfx.drawLine(prev[1], prev[2], x, y) end
      prev = { x, y }
    end
    for i = 0, 3 do
      local x, lit = bx + 12 + i * 22, ((i + frames // 24) % 2 == 0)
      local y = cy - 2
      if lit then gfx.fillCircleAtPoint(x, y, 4) else gfx.drawCircleAtPoint(x, y, 3) end
    end
  elseif it and it.kind == "cloth" then
    CAFE.tableAt(cx, cy, 22, id, nil, 2)
  elseif it and it.kind == "centerpiece" then
    CAFE.tableAt(cx, cy, 22, nil, id, 2)
  elseif id == "cat" or id == "dog" then
    CAFE.pet(id, cx, cy + 10, 1, "sit")
  elseif art then
    art(cx, cy)
  else
    local label = (row[3] == "cup") and "CUPS" or (row[3] == "sign") and "SIGN" or ""
    gfx.setColor(BLACK)
    if label ~= "" then drawTC(label, cx, cy - 8, true) end
  end
  gfx.clearClipRect()
  gfx.setColor(BLACK)
  if row[2] ~= "" then drawTC(row[2], bx + bw // 2, by + bh + 6, true) end   -- the price, always in view
  if row[6] then                                  -- a few words under it, wrapped to the box
    gfx.setFont(fontNormal or gfx.getSystemFont())
    local line, ly = "", by + bh + 24
    local function flush() if line ~= "" then drawTC(line, bx + bw // 2, ly); ly = ly + 14; line = "" end end
    for word in string.gmatch(row[6], "%S+") do
      local try = (line == "") and word or (line .. " " .. word)
      if gfx.getTextSize(try) > bw + 12 then flush(); line = word else line = try end
    end
    flush()
  end
end

function CAFE.draw()
  if CAFE.mode == "place" then
    drawWall()
    drawCounter()
    drawFloor()
    UI.drawDoor()
    local it = CAFE.byId[CAFE.pend] or { kind = "table", name = "table" }
    for i, sp in ipairs(CAFE.spots) do
      local x, y, w, h = CAFE.spotRect(it.kind, i == CAFE.spotSel and sp or sp)
      x, y, w, h = CAFE.spotRect(it.kind, sp)
      if i == CAFE.spotSel then
        gfx.setColor(WHITE)
        gfx.fillRoundRect(x, y, w, h, 4)
        gfx.setColor(BLACK)
        gfx.setLineWidth(2)
        gfx.drawRoundRect(x, y, w, h, 4)
        gfx.setLineWidth(1)
        CAFE.art[CAFE.byId[CAFE.pend] and CAFE.pend or "table"](x + w // 2, y + h // 2)
      else
        gfx.setColor(WHITE)
        for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
        for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
        gfx.setColor(BLACK)
        for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
        for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w - 1, yy, x + w - 1, yy + 2) end
      end
    end
    gfx.setColor(WHITE)
    local by = (it.kind == "table") and 114 or 196              -- keep the box off the spots
    gfx.fillRoundRect(60, by, 280, 36, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(60, by, 280, 36, 6)
    drawTC("Where should the " .. it.name .. " go?", 200, by + 2, true)
    drawTC("D-pad: choose    A: place    B: cancel", 200, by + 18)
    return
  end
  if CAFE.mode == "slots" then
    UI.beanFrame()
    CAFE.band("CAFE  -  CHOOSE A SAVE")
    for i = 1, 3 do
      local y = 42 + (i - 1) * 50
      local d = CAFE.slots[i]
      gfx.setColor(BLACK)
      if CAFE.sel == i then
        gfx.fillRoundRect(60, y, 280, 44, 8)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.setLineWidth(2)
        gfx.drawRoundRect(60, y, 280, 44, 8)
        gfx.setLineWidth(1)
      end
      local col = (CAFE.sel == i) and WHITE or BLACK
      drawT(tostring(i), 70, y + 13, true)
      if d then
        drawT(d.name, 88, y + 4, true)
        drawT(string.format("%s  %d cups  %d seats", money(d.money), d.cups, CAFE.seatsOf(d.seatStep)), 88, y + 24)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        CAFE.drawStars(298, y + 12, 4, 10, d.stars, col)
      else
        drawT("NEW CAFE", 88, y + 13, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
    end
    drawTC("B: back      Right: erase", 200, 208)
    if CAFE.erase then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(60, 80, 280, 70, 8)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(60, 80, 280, 70, 8)
      gfx.setLineWidth(1)
      drawTC("Erase " .. CAFE.slots[CAFE.erase].name .. "?", 200, 92, true)
      drawTC("A: erase it     B: keep it", 200, 118)
    end
  elseif CAFE.mode == "name" then
    UI.beanFrame()
    CAFE.band("NAME YOUR CAFE")
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(64, 42, 272, 38, 8)
    gfx.setLineWidth(1)
    gfx.setFont(fontBold)
    local w = gfx.getTextSize(CAFE.name)
    local x0 = 200 - (w + 10) // 2
    drawT(CAFE.name, x0, 52, true)
    if (frames // 10) % 2 == 0 and #CAFE.name < 10 then gfx.fillRect(x0 + w + 2, 70, 9, 3) end
    -- the letter dial
    local lc = (CAFE.letter == 26) and "space" or string.char(65 + CAFE.letter)
    gfx.fillTriangle(186, 92, 214, 92, 200, 84)
    if CAFE.onDone then gfx.setLineWidth(2); gfx.drawRoundRect(150, 96, 100, 36, 8); gfx.setLineWidth(1)
    else gfx.fillRoundRect(150, 96, 100, 36, 8) end
    gfx.setImageDrawMode(CAFE.onDone and gfx.kDrawModeCopy or gfx.kDrawModeFillWhite)
    drawTC(lc, 200, 106, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    gfx.fillTriangle(186, 136, 214, 136, 200, 144)
    -- the DONE button, under the dial
    if CAFE.onDone then gfx.fillRoundRect(150, 152, 100, 28, 8) else gfx.setLineWidth(2); gfx.drawRoundRect(150, 152, 100, 28, 8); gfx.setLineWidth(1) end
    gfx.setImageDrawMode(CAFE.onDone and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC("DONE", 200, 158, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if CAFE.onDone then
      drawTC("A: start the cafe     Left: back", 200, 190)
    else
      drawTC("Up/Down/crank: letter   A: add   B: delete", 200, 190)
      drawTC("Right: DONE button", 200, 206)
    end
  else
    -- the shop
    -- a browser's address bar: a globe, the address, your stars and your money
    gfx.setColor(WHITE)
    gfx.fillRoundRect(8, 4, 384, 24, 12)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(8, 4, 384, 24, 12)
    gfx.setLineWidth(1)
    gfx.drawCircleAtPoint(26, 16, 7)                       -- globe
    gfx.drawEllipseInRect(23, 9, 6, 14)
    gfx.drawLine(19, 16, 33, 16)
    drawT("coffeesupply.com", 42, 8, true)
    gfx.setColor(BLACK)
    -- the matching bar along the bottom: your stars on the left, your money on the right
    gfx.setColor(WHITE)
    gfx.fillRoundRect(8, 212, 384, 24, 12)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(8, 212, 384, 24, 12)
    gfx.setLineWidth(1)
    CAFE.drawStars(32, 224, 6, 15, CAFE.cur.stars, BLACK)
    drawTR(money(CAFE.cur.money), 380, 216, true)
    gfx.setColor(BLACK)
    if CAFE.report then drawTC(CAFE.report, 200, 32, true) end
    local rows = CAFE.rows()
    for vi = 1, 8 do
      local i = CAFE.scroll + vi
      local row = rows[i]
      if row == nil then break end
      local y = 50 + (vi - 1) * 20
      gfx.setColor(BLACK)
      if CAFE.shopSel == i then
        gfx.fillRoundRect(10, y, 270, 18, 5)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(10, y, 270, 18, 5)               -- every choice is a button with a border
      end
      local bold = row[3] == "start" or row[3] == "quit"
      drawT(row[1], 20, y + 1, bold)
      if row[2] ~= "" then drawTR(row[2], 272, y + 1, true) end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if CAFE.shopSel == i then                            -- the mouse pointer, resting on the choice
        gfx.setFont(bold and fontBold or fontNormal)
        local mx = 20 + math.min(gfx.getTextSize(row[1]) * 0.6, 150) + math.floor(math.sin(frames * 0.15) * 2 + 0.5)
        mx = math.floor(mx)
        local my = y + 8 + math.floor(math.sin(frames * 0.15 + 1) * 1.5 + 0.5)
        gfx.setColor(WHITE)
        gfx.fillPolygon(mx, my, mx, my + 13, mx + 3, my + 10, mx + 6, my + 15, mx + 8, my + 14, mx + 5, my + 9, mx + 9, my + 9)
        gfx.setColor(BLACK)
        gfx.drawLine(mx, my, mx, my + 13); gfx.drawLine(mx, my + 13, mx + 3, my + 10)
        gfx.drawLine(mx + 3, my + 10, mx + 6, my + 15); gfx.drawLine(mx + 6, my + 15, mx + 8, my + 14)
        gfx.drawLine(mx + 8, my + 14, mx + 5, my + 9); gfx.drawLine(mx + 5, my + 9, mx + 9, my + 9)
        gfx.drawLine(mx + 9, my + 9, mx, my)
      end
    end
    CAFE.drawPreview(rows[CAFE.shopSel])
    if CAFE.scroll > 0 then gfx.fillTriangle(285, 60, 291, 60, 288, 54) end
    if CAFE.scroll + 8 < #rows then gfx.fillTriangle(285, 202, 291, 202, 288, 208) end
    if CAFE.msg then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(40, 184, 320, 20, 6)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(40, 184, 320, 20, 6)
      drawTC(CAFE.msg, 200, 186, true)
    end
  end
  gfx.setColor(BLACK)
end


-- System menu (the Menu button): jump back to the title screen
-- (the Cafe hides this item: there you only get End shift / Save & quit)
function UI.setTitleItem(on)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if on and UI.titleItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Title screen", function()
        if state ~= STATE_MENU then goTitle() end
      end)
    end)
    if ok then UI.titleItem = item end
  elseif (not on) and UI.titleItem ~= nil then
    pcall(function() menu:removeMenuItem(UI.titleItem) end)
    UI.titleItem = nil
  end
end
UI.setTitleItem(true)

-- the fade to black and back that covers every change of screen
local fadeImg = nil
do
  local ok, img = pcall(function() return gfx.image.new(400, 240, BLACK) end)
  if ok then fadeImg = img end
end

function UI.drawFade()
  if trans == nil then return end
  local k = clamp(trans.t / FADE_SECONDS, 0, 1)
  local a = (trans.phase == "out") and k or (1 - k)
  if a <= 0.02 then return end
  if a >= 0.98 then
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 400, 240)
    return
  end
  if fadeImg then
    local ok = pcall(function() fadeImg:drawFaded(0, 0, a, gfx.image.kDitherTypeBayer8x8) end)
    if ok then return end
  end
  gfx.setColor(BLACK)                       -- fallback: a coarse checker fade
  if a > 0.3 then gfx.setPattern(CHECK) end
  if a > 0.3 then gfx.fillRect(0, 0, 400, 240) end
  gfx.setColor(BLACK)
end

function pd.update()
  local now = pd.getCurrentTimeMilliseconds()
  local dt = (now - lastMs) / 1000
  lastMs = now
  if dt > 0.1 then dt = 0.1 end
  if dt < 0 then dt = 0 end
  frames = frames + 1

  -- advance a screen fade: dark, switch screens, light again
  if trans then
    trans.t = trans.t + dt
    if trans.phase == "out" and trans.t >= FADE_SECONDS then
      trans.fn()
      trans.phase, trans.t = "in", 0
    elseif trans.phase == "in" and trans.t >= FADE_SECONDS then
      trans = nil
    end
  end

  -- only the screen we started the frame on reacts to the buttons, so one
  -- button press can't fall straight through into the next screen
  -- (nothing reacts while the screen is fading out)
  if trans == nil or trans.phase == "in" then
    if state == STATE_MENU then updateMenu()
    elseif state == STATE_PLAY then updatePlay(dt)
    elseif state == STATE_ENTRY then updateEntry(dt)
    elseif state == CAFE.STATE then CAFE.update(dt)
    else updateBoard(dt) end
  end

  gfx.setBackgroundColor(WHITE)
  gfx.clear()
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if state == STATE_MENU then
    drawMenu()
  elseif state == STATE_PLAY then
    drawPlay()
  elseif state == STATE_ENTRY then
    drawEntry()
  elseif state == CAFE.STATE then
    CAFE.draw()
  else
    drawBoard()
  end
  UI.drawFade()
end
