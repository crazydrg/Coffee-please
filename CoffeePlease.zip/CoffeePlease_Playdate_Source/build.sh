#!/bin/sh
# Builds CoffeePlease.pdx from the CoffeePlease folder next to this script.
# Uses the Playdate SDK from PLAYDATE_SDK_PATH, or a PlaydateSDK-* folder next to this one (or one level up), or pdc on your PATH.
cd "$(dirname "$0")"
PDC=""
if [ -n "$PLAYDATE_SDK_PATH" ] && [ -x "$PLAYDATE_SDK_PATH/bin/pdc" ]; then PDC="$PLAYDATE_SDK_PATH/bin/pdc"; fi
if [ -z "$PDC" ]; then for d in ./PlaydateSDK* ../PlaydateSDK* "$HOME"/Desktop/PlaydateSDK* "$HOME"/PlaydateSDK* "$HOME"/Developer/PlaydateSDK; do
  if [ -x "$d/bin/pdc" ]; then PDC="$d/bin/pdc"; break; fi; done; fi
if [ -z "$PDC" ]; then PDC="pdc"; fi
"$PDC" CoffeePlease CoffeePlease.pdx && echo "Built CoffeePlease.pdx"
