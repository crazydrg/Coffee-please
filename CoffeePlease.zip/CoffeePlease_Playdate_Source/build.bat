@echo off
rem Builds CoffeePlease.pdx from the CoffeePlease folder next to this file (needs the Playdate SDK installed).
cd /d "%~dp0"
set PDC=pdc
if defined PLAYDATE_SDK_PATH set PDC="%PLAYDATE_SDK_PATH%\bin\pdc.exe"
%PDC% CoffeePlease CoffeePlease.pdx
if %errorlevel%==0 echo Built CoffeePlease.pdx
pause
