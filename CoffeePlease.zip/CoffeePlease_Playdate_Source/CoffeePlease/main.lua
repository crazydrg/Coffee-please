-- Coffee Please!!!
-- by Christian G   (version 3.5)
--
-- A tiny coffee-shop game for the Playdate.
-- Ring them up, pour the coffee, mix in milk / sugar / espresso / ice, serve it,
-- ring the bell. Two ways to play:
--   RUSH HOUR    - open 7 AM to 2 PM, a fast time-limited shift
--   EVENING CHILL - open 4 PM to 12 AM, no timer: wash cups between customers

import "CoreLibs/graphics"
import "CoreLibs/ui"
import "bitlib"

local pd  = playdate
local gfx  = pd.graphics
local snd  = pd.sound

----------------------------------------------------------------------
-- Tuning knobs: change these numbers to adjust how the game feels
----------------------------------------------------------------------
local RUSH_SECONDS      = 90    -- Rush Hour is a 90 second countdown
local PATIENCE_SECONDS  = 75    -- how long a customer waits at the counter
local LINE_PATIENCE     = 2.0   -- people in line are this many times more patient
local LINE_MAX          = 3     -- people who can wait behind the one ordering
local TIP_MAX           = 250   -- best possible tip, in cents
local WALK_SPEED        = 110   -- barista speed (pixels per second)
local CUST_SPEED        = 140   -- customer speed (pixels per second)
local RECEIPT_CRANK     = 360   -- crank degrees to print the receipt
local MIX_CRANK         = 720   -- crank degrees to mix the drink
local BELL_CRANK        = 270   -- crank degrees to ring the bell
local POUR_RATE_MIN     = 0.25  -- coffee fill per second (gentle tilt)
local POUR_RATE_MAX     = 0.36  -- coffee fill per second (full tilt)
local DINE_IN_CHANCE    = 0.65  -- chance a customer wants to sit down
local STAY_MIN          = 40    -- seconds a customer stays seated (min)
local STAY_MAX          = 90    -- seconds a customer stays seated (max)
local MUSIC_VOLUME      = 0.85   -- the cafe music (0 to 1)
local BEEP_GAIN         = 0.45   -- how loud the little beeps are (0 to 1)

-- Evening Chill mode
local CHILL_ARRIVE_MIN    = 22    -- seconds between customers (min)
local CHILL_ARRIVE_SPAN   = 14    -- ...plus up to this much extra
local CHILL_PATIENCE      = 110   -- how long a customer waits at the counter
local CHILL_DINE_IN       = 0.85  -- chance a customer wants to sit down
local CHILL_STAY_MIN      = 45
local CHILL_STAY_MAX      = 100
local CUPS_TOTAL          = 5     -- ceramic cups in the whole shop
local DISH_CRANK          = 540   -- crank degrees to scrub one cup clean
local COFFEE_KINDS_IN_RUSH  = false   -- true = matcha/decaf in Rush Hour too
local KINDS         = { "coffee", "matcha", "decaf", "tea" }
local KIND_WEIGHTS  = { 46, 20, 17, 17 }
local KIND_PRICE    = { coffee = 0, matcha = 100, decaf = 0, tea = 50 }   -- cents extra
local WIN, UI, CAFE = {}, {}, {}      -- grouped to stay under the 200-locals limit
function UI.ink() end                 -- colour hook: does nothing on the 1-bit Playdate; the PC version paints the next shapes in the named colour
function UI.inkPush() end             -- (the same, but remembers the colour before it ...)
function UI.inkPop() end              -- (... and goes back to it)
UI.color = false                      -- true on the PC (in colour): a few things are drawn a little differently there
UI.SIZE_NAME = { "Small", "Medium", "Large" }
UI.SIZE_FILL = { 0.55, 0.78, 1.0 }          -- where the "fill to here" line sits for each cup size
UI.KIND_NAME = { coffee = "Coffee", matcha = "Matcha", decaf = "Decaf", tea = "Tea" }
-- With the Halloween music on, the matcha slot becomes Pumpkin Spice; with the Christmas music on, Hot Cocoa. (Inside, the drink is still kind "matcha":
-- its button, price and cup are the same, only the name, the picture and what people put in it change.)
UI.SPECIAL = {
  fall   = { name = "Pumpkin Spice", word = "PUMPKIN", greet = "Pumpkin spice, please!", icon = "pumpkin" },
  winter = { name = "Hot Cocoa",     word = "COCOA",   greet = "Hot cocoa, please!",     icon = "cocoa" },
}


-- How likely each amount is in an order (index 1 = none, 2 = one, 3 = two, ...)
local MILK_WEIGHTS   = { 35, 35, 22, 8 }
local SUGAR_WEIGHTS  = { 35, 30, 25, 10 }
local SHOT_WEIGHTS   = { 60, 30, 10 }
local ICE_WEIGHTS    = { 45, 30, 17, 8 }

-- The starting high score table (scores are in cents)
local DEFAULT_SCORES  = {
  { n = "Grace",       s = 5500 },   -- six clean orders in a row: only for someone really good at it
  { n = "Christian",   s = 4600 },
  { n = "Kelly",       s = 3800 },
  { n = "Jay",         s = 3100 },
  { n = "Bellasmella", s = 2600 },
  { n = "Rosie",       s = 2200 },
  { n = "Otis",        s = 1700 },
  { n = "Juno",        s = 1350 },
  { n = "Mabel",       s = 1000 },
  { n = "Pip",         s = 700 },
}

-- Evening Chill has no timer, so its table is about how long you keep going
local DEFAULT_CHILL_SCORES  = {
  { n = "Grace",       s = 35000 },   -- roughly 25 minutes of near-perfect service
  { n = "Christian",   s = 27000 },
  { n = "Kelly",       s = 20500 },
  { n = "Jay",         s = 15500 },
  { n = "Bellasmella", s = 11500 },
  { n = "Rosie",       s = 8000 },
  { n = "Otis",        s = 5500 },
  { n = "Juno",        s = 3500 },
  { n = "Mabel",       s = 2000 },
  { n = "Pip",         s = 1000 },
}

----------------------------------------------------------------------
-- Basics
----------------------------------------------------------------------
local BLACK  = gfx.kColorBlack
local WHITE  = gfx.kColorWhite
local CHECK = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }

local fontNormal = gfx.getSystemFont()
local fontBold = gfx.getSystemFont(gfx.font.kVariantBold)

local function clamp(v, lo, hi)
  if v < lo then return lo elseif v > hi then return hi end
  return v
end

-- cents -> "$3.75"
local function money(c)
  c = math.floor(c + 0.5)
  return string.format("$%d.%02d", math.floor(c / (100)), c % 100)
end

local function drawT(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawText(str, x, y)
end
local function drawTC(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.center)
end
local function drawTR(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.right)
end

-- more fill patterns (the three drinks look different in the cup)
local DIAG   = { 0xEE, 0xDD, 0xBB, 0x77, 0xEE, 0xDD, 0xBB, 0x77 }
local STRIPE = { 0xCC, 0xCC, 0x33, 0x33, 0xCC, 0xCC, 0x33, 0x33 }
local TEA = { 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }
local DRINK_PATTERN = { coffee = CHECK, matcha = DIAG, decaf = STRIPE, tea = { 0x77, 0xAA, 0xDD, 0xAA, 0x77, 0xAA, 0xDD, 0xAA } }   -- (tea is an amber mesh: darker than matcha, lighter than coffee)

-- a little ceramic cup (x, y = top-left, s = size 1 small .. 3 big)
local function drawCup(x, y, s, dirty)
  local w, h = 8 * s, 8 * s
  UI.inkPush("mugc")
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(s >= 2 and 2 or 1)
  gfx.drawRect(x, y, w, h)
  gfx.drawCircleAtPoint(x + w + s, y + math.floor(h / (2)), s + 1)
  gfx.setLineWidth(1)
  if dirty then
    UI.ink("coffee")
    gfx.setPattern(CHECK)
    gfx.fillRect(x + 2, y + math.floor(h / (2)), w - 4, math.floor(h / (2)) - 2)
    gfx.setColor(BLACK)
  end
  UI.inkPop()
end

-- a coffee bean (x, y = centre)
local function drawBean(x, y, s)
  s = s or 1
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x - 5 * s, y - 3 * s, 10 * s, 6 * s)
  gfx.setColor(WHITE)
  gfx.drawLine(x - 4 * s, y + s, x + 4 * s, y - s)
  gfx.setColor(BLACK)
end

-- a dashed outline (the empty spot on a shelf)
local function dashedRect(x, y, w, h)
  gfx.setColor(BLACK)
  for dx = 0, w - 3, 6 do
    gfx.drawLine(x + dx, y, x + dx + 2, y)
    gfx.drawLine(x + dx, y + h, x + dx + 2, y + h)
  end
  for dy = 0, h - 3, 6 do
    gfx.drawLine(x, y + dy, x, y + dy + 2)
    gfx.drawLine(x + w, y + dy, x + w, y + dy + 2)
  end
end

----------------------------------------------------------------------
-- Sound: little synth blips, recorded-style effects, and the cafe music
----------------------------------------------------------------------
local function newSynth(wave)
  local ok, s = pcall(function() return snd.synth.new(wave) end)
  if ok then return s end
  return nil
end
local synthSq   = newSynth(snd.kWaveSquare)
local synthSine = newSynth(snd.kWaveSine)

local function play(synth, hz, len, vol, when)
  if synth == nil then return end
  vol = (vol or 0.3) * BEEP_GAIN          -- beeps stay quiet; the music is the star
  pcall(function()
    if when then synth:playNote(hz, vol, len, when) else synth:playNote(hz, vol, len) end
  end)
end

local function sfxTick()  play(synthSq, 1800, 0.02, 0.10) end
local function sfxPop()   play(synthSine, 520, 0.08, 0.30) end
local function sfxWrong() play(synthSq, 110, 0.25, 0.30) end
local function sfxGood()
  play(synthSq, 660, 0.07, 0.25)
  play(synthSq, 990, 0.10, 0.25, 0.08)
end
local function sfxHello()
  play(synthSine, 880, 0.10, 0.30)
  play(synthSine, 1175, 0.20, 0.30, 0.10)
end

-- sound effect files live in the "sounds" folder
local sfx = {}
for _, name in ipairs({ "receipt", "receipt2", "pour", "pour2", "mixer", "icemixer", "plate", "bell", "slide", "tip", "chime", "door", "click1", "click2", "click3", "click4", "cup1", "cup2", "dash1", "dash2", "ice1", "ice2", "ice3", "cleaning", "sink", "alarm" }) do
  local ok, sp = pcall(function() return snd.sampleplayer.new("sounds/" .. (name == "receipt2" and "receipt" or name)) end)
  if ok and sp then sfx[name] = sp end
end

local function sfxPlay(name, loop, vol, rate)
  local sp = sfx[name]
  if sp == nil then return end
  pcall(function()
    if vol then sp:setVolume(vol) end
    if rate then sp:setRate(rate) end
    if loop then
      if not sp:isPlaying() then sp:play(0) end
    else
      sp:play(1)
    end
  end)
end

-- the pretty register chime when a shift starts
local function sfxStart()
  if sfx.chime then
    sfxPlay("chime", false, 0.9)
  else
    play(synthSine, 1568, 0.25, 0.5)
    play(synthSine, 2093, 0.25, 0.5, 0.12)
    play(synthSine, 2637, 0.40, 0.5, 0.24)
  end
end

local function sfxStop(name)
  local sp = sfx[name]
  if name == "receipt" and UI.rcptPaused then UI.rcptPaused = false; if sp then pcall(function() sp:setPaused(false) end) end end
  if sp then pcall(function() sp:stop() end) end
  if name == "pour" and sfx.pour2 then pcall(function() sfx.pour2:stop() end) end
  if name == "mixer" and sfx.icemixer then pcall(function() sfx.icemixer:stop() end) end     -- (the icy mixer sound goes quiet with it)
end

-- the coffee pour: one of the two pour recordings, left alone while it plays
local function sfxPour()
  local a, b = sfx.pour, sfx.pour2
  if (a and a:isPlaying()) or (b and b:isPlaying()) then return end
  local name = (b and math.random() < 0.5) and "pour2" or "pour"
  sfxPlay(name, false, 1.0, 1.0)
end

-- cups clinking and ice cubes: one of the recordings, picked at random
local function sfxRandom(names)
  local list = {}
  for _, n in ipairs(names) do if sfx[n] then list[#list + 1] = n end end
  if #list == 0 then return false end
  sfxPlay(list[math.random(#list)], false, 1.0)
  return true
end
local function sfxCup() if not sfxRandom({ "cup1", "cup2" }) then sfxPlay("plate", false, 0.6) end end
local function sfxClick()
  if not sfxRandom({ "click1", "click2", "click3", "click4" }) then play(synthSq, 1200, 0.03, 0.15) end
end
local function sfxDash() if not sfxRandom({ "dash1", "dash2" }) then sfxPop() end end   -- a second of pouring
local function sfxIce() if not sfxRandom({ "ice1", "ice2", "ice3" }) then sfxPop() end end

-- (the slurp now plays from the launcher, as the game's launch sound)

-- background music: the Menu button has a Music check box to switch it off.
-- Every tune is loaded whole into memory (a sampleplayer) rather than streamed from the disk, which hitched the frame rate every few seconds.
-- That is a lot of memory, so only the tune that is playing, the one that comes next and the shop's tune are kept (see UI.musicTick).
UI.tunes, UI.badTunes = {}, {}
UI.POOL = { "latte", "bossa", "piano", "swing", "closing" }       -- title screen, cafe and Evening Chill: one of these, picked at random
UI.musicOn, UI.musicNow = true, nil
UI.mus = { recent = {} }
function UI.tune(name)                                           -- the player for a tune (loaded the first time; nil if the file will not load)
  local p = UI.tunes[name]
  if p then return p end
  if UI.badTunes[name] then return nil end
  local ok, sp = pcall(function() return snd.sampleplayer.new("music/" .. name) end)
  if not (ok and sp) then UI.badTunes[name] = true; return nil end
  pcall(function() sp:setVolume(MUSIC_VOLUME) end)
  UI.tunes[name] = sp
  return sp
end
UI.tune("shop")                                                  -- the coffee supply website's tune
do                                                               -- (and one for the title screen, ready to go)
  local first = UI.POOL[math.random(#UI.POOL)]
  if UI.tune(first) then UI.mus.pick = first end
end
pcall(function()
  local menu = pd.getSystemMenu()
  if menu and menu.addCheckmarkMenuItem then
    UI.musicItem = menu:addCheckmarkMenuItem("Music", true, function(on) UI.musicOn = on end)
  end
end)

----------------------------------------------------------------------
-- Layout
----------------------------------------------------------------------
local PLAYER_Y  = 58    -- the barista walks along behind the counter
local WALK_MIN  = 28
local WALK_MAX = 344
local JAR_X    = 368          -- the tip jar

local REG_X, REG_Y = 62, 136      -- where the customer being served stands
local PICK_X, PICK_Y = 308, 136   -- where they wait for their drink
local DOOR_X  = 28         -- customers walk in and out here (bottom left)
local LINE_SLOTS = { { 62, 166 }, { 62, 196 }, { 62, 226 } }
local DISH_X = 332                -- Evening Chill: where used cups get dropped off

local RUSH_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 62,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 144, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 226, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 308, stage = 4 },
}
-- Evening Chill squeezes in a dish bin, and the tip jar moves right
local CHILL_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 56,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 128, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 200, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 272, stage = 4 },
  { id = "dishes",   name = "Dishes",   label = "DISHES",   x = 332 },
}
local STATIONS = RUSH_STATIONS
local STAGE_ST = {}               -- STAGE_ST[1..4] = the station for each order step

local function stationById(id)
  for _, st in ipairs(STATIONS) do
    if st.id == id then return st end
  end
  return nil
end

local function setLayout(mode)
  do
    STATIONS = CHILL_STATIONS
    JAR_X, WALK_MAX = 384, 356
    REG_X, PICK_X, DISH_X = 56, 272, 332
    LINE_SLOTS = { { 56, 166 }, { 56, 196 }, { 56, 226 } }
  end
  STAGE_ST = {}
  for _, st in ipairs(STATIONS) do
    if st.stage then STAGE_ST[st.stage] = st end
  end
end
setLayout("rush")

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "ENT" }
local GREETS = { "Coffee please!", "One coffee, please!", "Morning! Coffee?", "Coffee time!" }

-- Round tables and where people sit (the last table is in the corner nook)
local TABLES = {
  { x = 132, y = 208, r = 13 }, { x = 186, y = 208, r = 13 },
  { x = 240, y = 208, r = 13 }, { x = 294, y = 208, r = 13 },
  { x = 350, y = 180, r = 13 },            -- the table inside the nook
}
local SEATS = {
  { x = 115, y = 208, t = 1 }, { x = 149, y = 208, t = 1 },
  { x = 169, y = 208, t = 2 }, { x = 203, y = 208, t = 2 },
  { x = 223, y = 208, t = 3 }, { x = 257, y = 208, t = 3 },
  { x = 277, y = 208, t = 4 }, { x = 311, y = 208, t = 4 },
  -- the L-shaped nook: three seats up the wall, two along the bottom
  { x = 386, y = 164, t = 5 }, { x = 386, y = 186, t = 5 }, { x = 386, y = 212, t = 5 },
  { x = 362, y = 218, t = 5 }, { x = 338, y = 218, t = 5 },
  -- and two chairs on the open sides of the nook table (left and top)
  { x = 327, y = 180, t = 5, back = "l" }, { x = 350, y = 157, t = 5, back = "u" },
}

----------------------------------------------------------------------
-- High scores (saved on the Playdate)
----------------------------------------------------------------------
local boards = { rush = {}, chill = {} }     -- sorted lists of { n = name, s = cents }
local lastInitials = "AAA"
UI.crankPour = true                       -- pour with the crank unless you picked Tilt in Settings

local function saveScores()
  pd.datastore.write({ v = 7, rush = boards.rush, chill = boards.chill, last = lastInitials, crank = UI.crankPour == true, pour = UI.crankPour and "crank" or "tilt" })
end

do
  local function take(dst, src)
    if type(src) ~= "table" then return end
    for _, e in ipairs(src) do
      if type(e) == "table" and type(e.n) == "string" and type(e.s) == "number" then
        dst[#dst + 1] = { n = e.n, s = e.s }
      end
    end
  end
  local saved = pd.datastore.read()
  if saved then
    if saved.v == 7 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
    elseif saved.v == 6 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
      -- the Rush Hour starting scores were lowered after the first 1.3 builds: swap the old starting entries for the new ones, keeping every score you really made
      local old = { Grace = 9000, Christian = 7800, Kelly = 6600, Jay = 5600, Bellasmella = 4700, Rosie = 3900, Otis = 3100, Juno = 2400, Mabel = 1700, Pip = 1100 }
      for i = #boards.rush, 1, -1 do
        local e = boards.rush[i]
        if old[e.n] == e.s then table.remove(boards.rush, i) end
      end
      for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
    elseif saved.v == 5 then
      take(boards.chill, saved.chill)     -- Rush Hour got combos in 1.3 (scores run much higher): fresh table
    elseif saved.v == 4 then
      take(boards.chill, saved.chill)     -- Rush Hour got harder in 2.3: fresh table
    elseif saved.v == 3 then
      take(boards.rush, saved.scores)       -- version 1.x saved only the Rush Hour table
    end
    if type(saved.last) == "string" and #saved.last == 3 then lastInitials = saved.last end
    if saved.pour == "tilt" then UI.crankPour = false end             -- (Crank to pour is the default; only a saved choice of Tilt changes it)
  end
  if #boards.rush == 0 then
    for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
  end
  if #boards.chill == 0 then
    for _, e in ipairs(DEFAULT_CHILL_SCORES) do boards.chill[#boards.chill + 1] = { n = e.n, s = e.s } end
  end
  table.sort(boards.rush, function(a, b) return a.s > b.s end)
  table.sort(boards.chill, function(a, b) return a.s > b.s end)
end

-- returns the rank (1 = best) the new score landed at
local function insertScore(mode, name, s)
  local list = boards[mode]
  local rank = #list + 1
  for i, e in ipairs(list) do
    if s > e.s then rank = i; break end
  end
  table.insert(list, rank, { n = name, s = s })
  while #list > 100 do table.remove(list) end
  lastInitials = name
  saveScores()
  return rank
end

----------------------------------------------------------------------
-- Game state
----------------------------------------------------------------------
local STATE_MENU   = 1
local STATE_PLAY   = 2
local STATE_ENTRY  = 3   -- closing time: type your initials
local STATE_BOARD  = 4   -- the high score table

local state = STATE_MENU
local frames = 0
local lastMs = pd.getCurrentTimeMilliseconds()
local G = nil                   -- the current day (nil on the title screen)
local board = { mode = "view", rank = nil, m = "rush", view = "rush", t = 0 }
local entry = { letters = { 0, 0, 0 }, cur = 1, crank = 0 }
local menuSel = 1                   -- title screen: 1 Cafe, 2 Rush Hour, 3 Evening Chill, 4 High scores / Achievements / Settings (UI.menuCol: 1, 2 or 3)
UI.menuCol = 1

-- screen fades: everything that changes screen goes through transitionTo()
local FADE_SECONDS  = 0.5
local trans = nil                   -- { phase = "out" or "in", t = seconds, fn = function }
function UI.season() return (G ~= nil and G.mode == "cafe" and G.win ~= nil) and G.win.season or nil end
function UI.kindName(kind)
  local sp = (kind == "matcha") and UI.SPECIAL[UI.season() or ""] or nil
  return sp and sp.name or UI.KIND_NAME[kind or "coffee"]
end
local endDay, setShiftMenu          -- (defined further down)

local function transitionTo(fn, dur)
  if trans == nil then trans = { phase = "out", t = 0, fn = fn, dur = dur or FADE_SECONDS } end
end
function UI.fast(fn) transitionTo(fn, 0.2) end       -- the title-screen pages: a quick dip to black instead of a long fade

-- mix the clock and frame count into the random seed so every day differs
local function reseed()
  local secs, ms = pd.getSecondsSinceEpoch()
  local mixed = (secs or 0) + (ms or 0) * 7 + pd.getCurrentTimeMilliseconds() * 13 + frames * 101
  math.randomseed(math.floor(mixed))
  math.random(); math.random(); math.random()
end

-- The window: the weather changes now and then, people stroll past
WIN.FX = { "rain", "wind", "leaves", "snow", "clouds" }      -- (snow never mixes with rain or leaves; wind goes with anything)

-- With the Halloween or the Christmas music on in the shop, the weather follows the season:
--   "fall":   it rains or clouds over now and then, and the leaves are always falling (no snow, no wind)
--   "winter": it only snows, all day (no rain, no clouds, no leaves, no wind)
WIN.SEASON_FX = { fall = { "rain", "clouds" }, winter = { "clouds" } }
function WIN.applySeason(fx, season)
  if season == "fall" then fx.leaves = true; fx.snow = false; fx.wind = false
  elseif season == "winter" then fx.snow = true; fx.leaves = false; fx.rain = false; fx.wind = false end        -- (clouds come and go)
end

function WIN.newWindow(season)
  local fx = { rain = false, wind = false, leaves = false, snow = false, clouds = false }
  local r, n = math.random(), 0
  if r < 0.22 then n = 0 elseif r < 0.67 then n = 1 elseif r < 0.90 then n = 2 else n = 3 end
  local pool = { 1, 2, 3, 4, 5 }
  for _ = 1, n do
    local k = table.remove(pool, math.random(#pool))
    fx[WIN.FX[k]] = true
  end
  if fx.snow then fx.rain = false; fx.leaves = false end
  WIN.applySeason(fx, season)
  local parts = {}
  if fx.clouds then                                  -- already cloudy when you arrive
    parts[1] = { k = "cloud", x = 22, y = 29, vx = 4 + math.random() * 3, vy = 0, s = 1 }
    parts[2] = { k = "cloud", x = 52, y = 31, vx = 4 + math.random() * 3, vy = 0, s = 0 }
  end
  local w = { fx = fx, nextChange = 70 + math.random() * 70, acc = { rain = 0, wind = 0, leaves = 0, snow = 0, clouds = 0 },
              parts = parts, walkers = {}, walkIn = 4 + math.random() * 8,
              skyIn = 12 + math.random() * 25, season = season }
  WIN.startSky(w)
  return w
end

-- day and night take turns all shift long: the sun crosses the window by day, the moon by night.
-- With the Halloween music on it is always night, and the moon stays up.
function WIN.startSky(w)
  if w.season == "fall" then
    w.sky = { kind = "moon", t = 36, dur = 60, still = true }
  else
    local dur = 50 + math.random() * 20
    w.sky = { kind = (math.random() < 0.5) and "moon" or "sun", t = math.random() * dur * 0.6, dur = dur }
  end
end
function WIN.isNight(w) return w ~= nil and w.sky ~= nil and w.sky.kind == "moon" end
function WIN.nightAmt(w)                      -- 0 = full day, 1 = full night; it eases across the turn from one to the other
  local s = w and w.sky
  if not s then return 0 end
  if s.still then return (s.kind == "moon") and 1 or 0 end
  local moon = (s.kind == "moon")
  local n = moon and 1 or 0
  local T = math.min(8, s.dur / 4)
  local dir = moon and -1 or 1
  if s.t > s.dur - T then n = n + dir * 0.5 * (s.t - (s.dur - T)) / T
  elseif s.t < T then n = n + dir * 0.5 * (1 - s.t / T) end
  return n
end
function UI.skyBlend() end                    -- (PC: blends the sky's colours; nothing to do on the 1-bit Playdate)

function WIN.updateWindow(dt)
  local w = G.win
  w.nextChange = w.nextChange - dt
  if w.nextChange <= 0 then                       -- slow: one effect flips every 70-140 s
    local list = (w.season and WIN.SEASON_FX[w.season]) or WIN.FX              -- (in a season only some kinds of weather happen)
    local k = (#list > 0) and list[math.random(#list)] or nil                    -- (winter: nothing changes, it just keeps snowing)
    if k then w.fx[k] = not w.fx[k] else k = "none" end
    if w.fx[k] then                                -- snow and rain/leaves never share a sky
      if k == "snow" then w.fx.rain = false; w.fx.leaves = false
      elseif k == "rain" or k == "leaves" then w.fx.snow = false end
    end
    WIN.applySeason(w.fx, w.season)
    w.nextChange = 70 + math.random() * 70
  end
  -- the sun crosses the window, then the moon, then the sun again: a day and night cycle (Halloween: the moon just stays up)
  if not w.sky then WIN.startSky(w) end
  if not w.sky.still then
    w.sky.t = w.sky.t + dt
    if w.sky.t >= w.sky.dur then
      w.sky = { kind = (w.sky.kind == "sun") and "moon" or "sun", t = 0, dur = 50 + math.random() * 20 }
    end
  end
  local rate = { rain = 16, wind = 1.5, leaves = 0.9, snow = 7, clouds = 0.16 }
  for _, k in ipairs(WIN.FX) do
    if w.fx[k] then w.acc[k] = w.acc[k] + rate[k] * dt end
    while w.acc[k] >= 1 do
      w.acc[k] = w.acc[k] - 1
      if k == "rain" then
        local sl = w.fx.wind and 14 or -3
        w.parts[#w.parts + 1] = { k = "rain", x = 12 + math.random() * 56, y = 21, vx = sl, vy = 70 + math.random() * 25 }
      elseif k == "clouds" then
        w.parts[#w.parts + 1] = { k = "cloud", x = 7, y = 27 + math.random() * 5, vx = 4 + math.random() * 3, vy = 0,
                                  s = math.random(0, 1) }
      elseif k == "snow" then
        w.parts[#w.parts + 1] = { k = "snow", x = 12 + math.random() * 56, y = 21, vx = 0,
                                  vy = 9 + math.random() * 8, ph = math.random() * 6 }
      elseif k == "wind" then
        w.parts[#w.parts + 1] = { k = "wind", x = 8, y = 26 + math.random() * 18, vx = 26 + math.random() * 14, vy = 0,
                                  ph = math.random() * 6 }
      else
        w.parts[#w.parts + 1] = { k = "leaf", x = 15 + math.random() * 50, y = 21, vx = 0,
                                  vy = 12 + math.random() * 8, ph = math.random() * 6 }
      end
    end
  end
  for i = #w.parts, 1, -1 do
    local q = w.parts[i]
    if q.k == "snow" then
      q.ph = q.ph + dt * 1.6
      q.x = q.x + math.sin(q.ph) * 6 * dt + (w.fx.wind and 14 * dt or 0)
    elseif q.k == "leaf" then
      q.ph = q.ph + dt * 2.2
      q.x = q.x + math.sin(q.ph) * 12 * dt + (w.fx.wind and 10 * dt or 0)
    elseif q.k == "wind" then
      q.ph = q.ph + dt * 4
      q.x = q.x + q.vx * dt
    else
      q.x = q.x + q.vx * dt
    end
    q.y = q.y + q.vy * dt
    if q.x > 76 or q.x < 6 or q.y > 49 then table.remove(w.parts, i) end
  end
  -- someone walks by now and then (never a crowd)
  w.walkIn = w.walkIn - dt
  if w.walkIn <= 0 and #w.walkers == 0 then
    local dir = (math.random() < 0.5) and 1 or -1
    w.walkers[1] = { x = dir == 1 and 6 or 76, dir = dir, speed = 15 + math.random() * 8, t = 0,
                     umbrella = w.fx.rain }
    w.walkIn = (w.gap or 14) + math.random() * (w.gapSpan or 18)
  end
  for i = #w.walkers, 1, -1 do
    local q = w.walkers[i]
    q.x = q.x + q.dir * q.speed * dt
    q.t = q.t + dt * 9
    if q.x < 2 or q.x > 80 then table.remove(w.walkers, i) end
  end
end

UI.COCOA_PAT = { 0x55, 0x22, 0x55, 0x88, 0x55, 0x22, 0x55, 0x88 }      -- (dark, so hot cocoa looks different from coffee in the cup)
UI.PUMPKIN_PAT = nil                     -- (the PC version gives pumpkin spice a pattern of its own, so it can be pumpkin coloured)
function UI.applyDrinkLook()
  local s = UI.season()
  DRINK_PATTERN.matcha = (s == "winter") and UI.COCOA_PAT or ((s == "fall" and UI.PUMPKIN_PAT) or DIAG)
end
function UI.drinkInk(kind)               -- PC: the colour of a drink (the coffee stream, ...)
  if kind == "matcha" then
    local s = UI.season()
    UI.ink((s == "fall") and "pspice" or ((s == "winter") and "cocoa" or "matcha"))
  else UI.ink(kind or "coffee") end
end

-- the season the cafe is in: "fall" with the Halloween music on, "winter" with the Christmas music on (one or the other each day if both are on).
-- (the window is made again whenever the music that is switched on changes, e.g. after a visit to the shop in the middle of a shift)
function CAFE.newWindowFor(d)
  local f, x = d and d.decor and d.decor.hmus == "on", d and d.decor and d.decor.xmus == "on"
  local season = nil
  if f and x then season = (math.random() < 0.5) and "fall" or "winter"
  elseif f then season = "fall"
  elseif x then season = "winter" end
  local w = WIN.newWindow(season)
  w.sk = (f and "H" or "") .. (x and "X" or "")
  return w
end

local function newGame(mode)
  mode = mode or "rush"
  reseed()
  local room = (mode ~= "cafe") and CAFE.randomRoom(mode) or nil      -- rush / chill: a new random room each time
  local dd = room or CAFE.cur
  CAFE.applyLayout(dd)
  setLayout(mode)
  G = {
    deco = room,
    mode = mode,
    t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
    px = STATIONS[1].x, moving = false, walk = 0,
    cupMax = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL,
    seatLimit = CAFE.seatsOf(dd.seatStep),
    seatOff = CAFE.seatOffOf(dd),
    seatCount = CAFE.seatCountOf(dd),
    cafe = (mode == "cafe") and CAFE.cur or nil,
    cups = { shelf = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL, dirty = 0, hand = 0 },   -- dishes
    sink = { state = "empty", progress = 0, angle = 0, t = 0 },
    lastCount = nil, ending = false,
    flow = { m = 0.5, target = 0.5, timer = 20 },
    pets = (mode == "cafe") and CAFE.makePets() or nil,
    win = (mode == "cafe") and CAFE.newWindowFor(CAFE.cur) or WIN.newWindow(),
    sel = "down",       -- Evening Chill: "up" = the wall shelf, "down" = the counter
    st = nil,           -- which station panel is open ("register", ...)
    cust = nil,         -- the customer being served right now
    line = {},          -- people waiting in line (line[1] is next)
    others = {},        -- people walking to a seat, sitting, or leaving
    seats = {},         -- seats[i] = the customer sitting there
    arriveIn = 0.8,     -- seconds until the next customer shows up
    stepT = 0,          -- short pause before the next person steps up
    door = 0,           -- 0 = closed, 1 = open
    popups = {},        -- floating "+$2.00" texts
    msg = nil, msgT = 0,
    endT = 0,
  }
  setShiftMenu(mode ~= "rush", mode == "cafe")
end

local function say(str)
  G.msg = str
  G.msgT = 2.2
end

local function addPopup(str, x, y, life, small)
  G.popups[#G.popups + 1] = { s = str, x = x, y = y, t = 0, life = life or 1.8, small = small }
end

----------------------------------------------------------------------
-- Crank helper (shows the "use the crank" hint if the crank is docked)
----------------------------------------------------------------------
local function crankHelpStart()
  local ci = pd.ui and pd.ui.crankIndicator
  if ci and ci.start then ci:start() end
end

local function crankHelpDraw()
  if not pd.isCrankDocked() then return end
  local ci = pd.ui and pd.ui.crankIndicator
  if ci == nil then return end
  if ci.update then ci:update() elseif ci.draw then ci:draw() end
end

----------------------------------------------------------------------
-- Customers
----------------------------------------------------------------------
local function weighted(w)
  local total = 0
  for _, v in ipairs(w) do total = total + v end
  local r = math.random() * total
  for i, v in ipairs(w) do
    r = r - v
    if r < 0 then return i - 1 end
  end
  return #w - 1
end

-- lines of text for the speech bubble (after the greeting)
local function orderLines(o)
  local lines = UI.orderLines0(o)
  table.insert(lines, 1, UI.SIZE_NAME[o.size or 3] .. " size")
  return lines
end

function UI.orderLines0(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. " espresso" end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 then
    if o.kind and o.kind ~= "coffee" then return { "Just plain, thanks!" } end
    return { "Just black, thanks!" }
  end
  if #items == 1 then return { "With " .. items[1] } end
  if #items == 2 then return { "With " .. items[1] .. " & " .. items[2] } end
  if #items == 3 then return { "With " .. items[1] .. ", " .. items[2], "& " .. items[3] } end
  return { "With " .. items[1] .. ", " .. items[2] .. ",", items[3] .. " & " .. items[4] }
end

-- short version for the panel headers
local function orderShort(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. (o.shot == 1 and " shot" or " shots") end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 and o.kind == "coffee" then return "Black coffee" end
  table.insert(items, 1, string.sub(UI.SIZE_NAME[o.size or 3], 1, 1) .. ". " .. UI.kindName(o.kind))
  return table.concat(items, ", ")
end

function UI.specialMix(o, sp)                       -- what goes in the season's drink
  if sp.icon == "pumpkin" then                        --   pumpkin spice latte: espresso, milk and sugar welcome, almost always hot
    o.milk = math.max(o.milk, 1)
    if math.random() < 0.85 then o.ice = 0 end
  else                                                --   hot cocoa: milk and sugar, no espresso, no ice
    o.shot, o.ice = 0, 0
    o.milk = math.max(o.milk, 1)
  end
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1 elseif o.ice > 0 then o.ice = o.ice - 1 else o.shot = o.shot - 1 end
  end
end

function UI.reseason(c)                             -- the season changed while this matcha customer had not ordered yet: they ask for what is on the menu now
  local o = c.order
  if not o or o.kind ~= "matcha" then return end
  local sp = UI.SPECIAL[UI.season() or ""]
  if sp then UI.specialMix(o, sp) else o.shot = 0 end
  c.greet = sp and sp.greet or "One matcha, please!"
  c.price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind]
end

local function newCustomer()
  local o = { milk = weighted(MILK_WEIGHTS), sugar = weighted(SUGAR_WEIGHTS),
              shot = weighted(SHOT_WEIGHTS), ice = weighted(ICE_WEIGHTS), size = math.random(1, 3) }
  -- keep orders sensible: nobody wants more than 5 extras
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1
    elseif o.ice > 0 then o.ice = o.ice - 1
    elseif o.milk > 0 then o.milk = o.milk - 1
    else o.shot = o.shot - 1 end
  end
  local chill = (G ~= nil and G.mode ~= "rush")
  o.kind = KINDS[weighted(KIND_WEIGHTS) + 1]
  local special = (o.kind == "matcha") and UI.SPECIAL[UI.season() or ""] or nil
  if special then                                            -- the season's drink: what people put in it makes sense
    UI.specialMix(o, special)
  elseif o.kind == "matcha" or o.kind == "tea" or o.kind == "decaf" then o.shot = 0 end      -- no espresso in those
  local greet = GREETS[math.random(#GREETS)]
  if special then greet = special.greet
  elseif o.kind == "matcha" then greet = "One matcha, please!"
  elseif o.kind == "decaf" then greet = "Decaf, please!"
  elseif o.kind == "tea" then greet = "Tea, please!" end
  local look = UI.LOOKS[math.random(#UI.LOOKS)]
  local hat, glass = CAFE.pickWear(look)                  -- now and then a customer comes in wearing a hat and / or glasses
  return {
    x = DOOR_X, y = 258, path = {}, walk = 0,
    state = "line",       -- line, active, toSeat, seated, leaving
    stage = 0,            -- 0 stepping up, 1 register, 2 coffee, 3 mixer, 4 serve
    order = o,
    price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind],   -- cents
    greet = greet,
    look = look, hat = hat, glass = glass,
    patience = 1.0,       -- 1 = fresh, 0 = walks out
    q = 1.0,              -- order quality (mistakes lower it, it decides the tip)
    dine = math.random() < (chill and CHILL_DINE_IN or DINE_IN_CHANCE) and (G == nil or (G.seatCount or G.seatLimit) > 0),
    hasCup = false,       -- Evening Chill: carrying one of the shop's ceramic cups
    seat = nil, stay = 0,
    reg = { digits = "", state = "type", cur = 5, crank = 0, flash = 0, tick = 0 },
    cof = { fill = 0, tilt = 0, base = nil,
            phase = "pick", pick = nil },
    mix = { milk = 0, sugar = 0, shot = 0, ice = 0, phase = 1, progress = 0, angle = 0, tick = 0, hold = 0 },
    srv = { phase = 1, slide = 0, crank = 0, ding = 0, tick = 0, recent = 0 },
  }
end

-- Walking around things: tables (with their chairs) and floor decor are obstacles that people and pets go round.
-- An obstacle is a short line with a thickness; one that you start or finish inside is ignored (your own seat, a pet's bed).
function CAFE.obstacles()
  local obs = {}
  local lim = G.seatLimit or 0
  for ti, t in ipairs(TABLES) do
    local fs = 2 * ti - 1
    if fs <= lim and not (G.seatOff and G.seatOff[fs]) then
      obs[#obs + 1] = { x1 = t.x - 17, y1 = t.y, x2 = t.x + 17, y2 = t.y, r = 15 }
    end
  end
  if lim >= 15 then obs[#obs + 1] = { x1 = 350, y1 = 157, x2 = 350, y2 = 157, r = 9 } end      -- the nook table's top chair
  local d = G.cafe or G.deco
  if d then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] then
        local sl = CAFE.FSLOT[d.place[it.id]]
        obs[#obs + 1] = { x1 = sl[1], y1 = sl[2] + 6, x2 = sl[1], y2 = sl[2] + 6, r = 11 }
      end
    end
  end
  return obs
end

function CAFE.dist(o, px, py)                  -- how far a point is from an obstacle's line
  local dx, dy = o.x2 - o.x1, o.y2 - o.y1
  local len2 = dx * dx + dy * dy
  local t = 0
  if len2 > 0 then t = clamp(((px - o.x1) * dx + (py - o.y1) * dy) / len2, 0, 1) end
  local qx, qy = o.x1 + dx * t, o.y1 + dy * t
  return math.sqrt((px - qx) ^ 2 + (py - qy) ^ 2)
end

function CAFE.firstBlock(obs, skip, ax, ay, bx, by)     -- the first obstacle a straight walk would go through
  local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
  local n = math.max(1, math.floor(len / 3))
  for i = 1, n do
    local px, py = ax + (bx - ax) * i / n, ay + (by - ay) * i / n
    for _, o in ipairs(obs) do
      if not skip[o] and CAFE.dist(o, px, py) < o.r then return o end
    end
  end
  return nil
end

function CAFE.routeR(obs, skip, ax, ay, bx, by, depth)
  local hit = CAFE.firstBlock(obs, skip, ax, ay, bx, by)
  if not hit or depth >= 4 then return {} end
  local m = hit.r + 5
  local cx, cy = (hit.x1 + hit.x2) / 2, (hit.y1 + hit.y2) / 2
  local cand = {
    { hit.x1 - m, hit.y1 }, { hit.x2 + m, hit.y2 }, { cx, hit.y1 - m }, { cx, hit.y1 + m },
    { hit.x1 - m * 0.7, hit.y1 - m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 - m * 0.7 },
    { hit.x1 - m * 0.7, hit.y1 + m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 + m * 0.7 },
  }
  local best, bc
  for _, w in ipairs(cand) do
    local wx, wy = clamp(w[1], 14, 392), clamp(w[2], 124, 238)
    local inside = false
    for _, o in ipairs(obs) do if not skip[o] and CAFE.dist(o, wx, wy) < o.r then inside = true end end
    if not inside and (wx - ax) ^ 2 + (wy - ay) ^ 2 > 9 and not CAFE.firstBlock(obs, skip, ax, ay, wx, wy) then
      local cost = math.sqrt((wx - ax) ^ 2 + (wy - ay) ^ 2) + math.sqrt((bx - wx) ^ 2 + (by - wy) ^ 2)
      if bc == nil or cost < bc then best, bc = { wx, wy }, cost end
    end
  end
  if not best then return {} end
  local out = { best }
  for _, w in ipairs(CAFE.routeR(obs, skip, best[1], best[2], bx, by, depth + 1)) do out[#out + 1] = w end
  return out
end

function CAFE.route(ax, ay, bx, by)            -- waypoints (not counting the start or the goal) that go round things
  if not G then return {} end
  local obs = CAFE.obstacles()
  local skip = {}
  for _, o in ipairs(obs) do
    if CAFE.dist(o, ax, ay) < o.r + 1 or CAFE.dist(o, bx, by) < o.r + 1 then skip[o] = true end
  end
  return CAFE.routeR(obs, skip, ax, ay, bx, by, 0)
end

function CAFE.pointBlocked(x, y)
  if not G then return false end
  for _, o in ipairs(CAFE.obstacles()) do if CAFE.dist(o, x, y) < o.r then return true end end
  return false
end

function CAFE.avoidPath(sx, sy, pts)           -- a list of stops, with the detours put in
  local out = {}
  for _, pt in ipairs(pts) do
    for _, w in ipairs(CAFE.route(sx, sy, pt[1], pt[2])) do out[#out + 1] = { w[1], w[2] } end
    out[#out + 1] = pt
    sx, sy = pt[1], pt[2]
  end
  return out
end

-- walking: customers follow a list of waypoints
local function routeTo(c, x, y)
  if c.y > 236 then
    c.path = CAFE.avoidPath(c.x, c.y, { { DOOR_X, 228 }, { x, y } })     -- still outside: come in through the door first
  else
    c.path = CAFE.avoidPath(c.x, c.y, { { x, y } })
  end
end

local function moveAlong(c, dt)
  local p = c.path[1]
  if p == nil then return end
  local dx, dy = p[1] - c.x, p[2] - c.y
  local d = math.sqrt(dx * dx + dy * dy)
  local step = CUST_SPEED * dt
  if d <= step then
    c.x, c.y = p[1], p[2]
    table.remove(c.path, 1)
    if p[3] == "drop" and c.hasCup then          -- leave the used cup in the dish bin
      c.hasCup = false
      G.cups.dirty = G.cups.dirty + 1
      sfxPlay("plate", false, 0.5)
    end
  else
    c.x = c.x + dx / d * step
    c.y = c.y + dy / d * step
  end
  c.walk = c.walk + dt * 14
end

local function leaveRoute(c)
  c.state = "leaving"
  local p = {}
  local sx, sy = c.x, c.y
  if c.hasCup then
    p[#p + 1] = { DISH_X, 152, "drop" }        -- bring the cup back to the dish bin first
    sx, sy = DISH_X, 152
  end
  local lx = sx
  if lx < 96 then
    lx = 96                                    -- slip out sideways, not through the line
    p[#p + 1] = { lx, sy }
  end
  if sy < 232 then p[#p + 1] = { lx, 232 } end
  p[#p + 1] = { DOOR_X, 234 }
  p[#p + 1] = { DOOR_X, 270 }
  c.path = CAFE.avoidPath(c.x, c.y, p)
end

local function relineup()
  for i, c in ipairs(G.line) do routeTo(c, LINE_SLOTS[i][1], LINE_SLOTS[i][2]) end
end

local function freeSeat()
  local free = {}
  for i = 1, G.seatLimit do
    if G.seats[i] == nil and not (G.seatOff and G.seatOff[i]) then free[#free + 1] = i end
  end
  if #free == 0 then return nil end
  return free[math.random(#free)]
end

----------------------------------------------------------------------
-- Stations
----------------------------------------------------------------------
local function stopLoops(keepMixer)
  sfxStop("pour")
  if not keepMixer then sfxStop("mixer") end
  sfxStop("sink")
  sfxStop("cleaning")
end

local function closeStation(keepMixer)
  if G and G.st == "coffee" then pcall(pd.stopAccelerometer) end
  stopLoops(keepMixer)
  if G then G.st = nil end
end

local function nearStation()
  for _, st in ipairs(STATIONS) do
    if math.abs(G.px - st.x) <= 22 then return st end
  end
  return nil
end

-- Evening Chill: the cup shelf hangs on the wall above the barista
local SHELF_X1, SHELF_X2 = 104, 194
local function nearWall()
  return G.px >= SHELF_X1 and G.px <= SHELF_X2
end

-- true when the shelf (up) is what A would open, false when it's the counter (down)
local function shelfSelected()
  if not nearWall() then return false end
  return G.sel == "up" or nearStation() == nil
end

local function tryOpen(st)
  if st.id == "dishes" then                          -- no customer needed
    local sk = G.sink
    if sk.state == "empty" and G.cups.dirty == 0 then
      say("No dirty cups right now.")
      sfxWrong()
      return
    end
    G.st = st.id
    if sk.state == "empty" then                      -- just crank: the first dirty cup is already in the sink
      G.cups.dirty = G.cups.dirty - 1
      sk.state, sk.progress, sk.angle = "washing", 0, 0
      sfxCup()
    end
    if sk.state == "washing" then crankHelpStart() end
    return
  end
  local c = G.cust
  if c == nil or c.stage < 1 then
    say("Waiting for a customer...")
    return
  end
  if c.stage ~= st.stage then
    if c.stage > st.stage then
      say("This machine is already done.")
      if st.id == "mixer" then CAFE.mistake(0.03) end        -- clicked the mixer out of habit
    else
      say("Do the " .. STAGE_ST[c.stage].name .. " first!")
    end
    sfxWrong()
    return
  end
  if st.id == "serve" and #c.path > 0 then
    say("They're still walking over!")
    return
  end
  if st.id == "register" and G.cups.hand > 0 then
    say("Put the clean cups on the shelf first!")
    sfxWrong()
    return
  end
  if st.id == "coffee" and c.dine and not c.hasCup then
    if G.cups.shelf > 0 then                      -- grab a clean cup from the shelf
      G.cups.shelf = G.cups.shelf - 1
      c.hasCup = true
      sfxCup()
    else
      c.dine = false
    end
  end
  G.st = st.id
  if st.id == "serve" and c.srv.phase == 1 then
    c.srv.phase = 2                    -- A at the counter slides the plate right away
    sfxPlay("slide", false, 1.0)
  end
  if st.id == "coffee" then
    pd.startAccelerometer()
    c.cof.base = nil
  end
  if (st.id == "register" and c.reg.state == "crank")
      or (st.id == "mixer" and c.mix.phase == 2) then
    crankHelpStart()
  end
end

-- Rush Hour combo: 1 good order = x1, then +0.25 for each one in a row, up to x3
function UI.comboMult(streak) return 1 + 0.25 * math.min(math.max(streak - 1, 0), 8) end
function UI.comboTxt(streak) return string.format("%g", UI.comboMult(streak)) end

-- ---- the order is finished: pay, tip, send the customer off ----------
local function finishOrder(c)
  local q = clamp(c.q, 0, 1)
  c.final = q
  local tip = 0
  if q >= 0.5 then
    local f = 0.4 + 0.6 * c.patience
    local pm = (G.mode == "cafe") and (1 + 0.15 * CAFE.petCount()) * UI.tipMult(G.cafe) or 1      -- pets help the tips (and in the Cafe: the barista level, the decor after a prestige, the tip boost)
    if c.dine then pm = pm * 1.3 end                                           -- dining in tips better
    tip = math.floor(TIP_MAX * q * q * f * pm * (1 + 0.15 * (c.precise or 0)) / 25 + 0.5) * 25
  end
  local combo, lost = 0, false
  if G.mode == "rush" then                        -- Rush Hour: back-to-back good orders build a combo, and the combo multiplies what each order earns
    if q >= 0.9 then G.streak = (G.streak or 0) + 1 else lost = (G.streak or 0) >= 2; G.streak = 0 end
    G.bestStreak = math.max(G.bestStreak or 0, G.streak)
    local mult = UI.comboMult(G.streak)
    combo = math.floor((c.price + tip) * (mult - 1) / 25 + 0.5) * 25
  end
  G.cash = G.cash + c.price
  G.tips = G.tips + tip + combo
  G.served = G.served + 1
  if G.mode == "cafe" then UI.review(c, q) end              -- (the review: a grade sticker, and the star meter moves)
  if G.mode == "rush" then UI.statMax("combo", G.streak or 0) end
  addPopup("+" .. money(c.price), stationById("register").x, 54, 1.8)
  if tip > 0 then
    addPopup("+" .. money(tip), JAR_X, 54, 2.2, true)
    sfxPlay("tip")
  else
    addPopup("no tip", JAR_X, 54, 1.8, true)
  end
  if combo > 0 then say("Combo x" .. UI.comboTxt(G.streak) .. "!  +" .. money(combo))
  elseif lost then say("Combo lost!")
  elseif G.mode == "cafe" then                     -- (the Cafe shows its grade as a sticker instead)
  elseif q >= 0.95 then say("Perfect order!")
  elseif q >= 0.75 then say("Nice work!")
  elseif q >= 0.5 then say("Good enough.")
  else say("Ouch... that was off.") end

  closeStation()
  G.cust = nil
  G.stepT = 0.7
  -- some people sit down with their drink, some take it to go
  if c.dine then
    local s = freeSeat()
    if s then
      G.seats[s] = c
      c.seat = s
      c.state = "toSeat"
      c.path = CAFE.avoidPath(c.x, c.y, { { SEATS[s].x, SEATS[s].y } })
    else
      leaveRoute(c)           -- no free seat: they head out
    end
  else
    leaveRoute(c)
  end
  G.others[#G.others + 1] = c
end

-- ---- 1. register -----------------------------------------------------
local function regPress(c, key)
  local r = c.reg
  if key == "DEL" then
    r.digits = string.sub(r.digits, 1, -2)
    sfxClick()
  elseif key == "ENT" then
    local val = tonumber(r.digits) or 0
    if val == c.price then
      G.lastSale = c.price                -- (the till's screen on the counter shows this sale from now on)
      r.state = "crank"
      crankHelpStart()
      sfxGood()
    else
      c.q = c.q - 0.2
      CAFE.mistake(0.05)
      r.digits = ""
      r.flash = 0.9
      sfxWrong()
    end
  else
    if #r.digits < 4 then r.digits = r.digits .. key end
    sfxClick()
  end
end

local function updateRegister(c, dt)
  local r = c.reg
  if r.flash > 0 then r.flash = r.flash - dt end
  if r.state == "type" then
    local col = (r.cur - 1) % 3
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if col == 0 then r.cur = r.cur + 2 else r.cur = r.cur - 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if col == 2 then r.cur = r.cur - 2 else r.cur = r.cur + 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      r.cur = r.cur - 3
      if r.cur < 1 then r.cur = r.cur + 12 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      r.cur = r.cur + 3
      if r.cur > 12 then r.cur = r.cur - 12 end
      sfxClick()
    end
    if pd.buttonJustPressed(pd.kButtonA) then regPress(c, KEYS[r.cur]) end
  else
    local ch = math.abs(pd.getCrankChange())
    r.crank = r.crank + ch
    r.tick = r.tick + ch
    if ch > 0.8 then
      r.hold = 0.15
      local sp = sfx.receipt
      if UI.rcptPaused and sp then                                      -- (cranking again after a pause: the printer sound carries on where it stopped)
        UI.rcptPaused = false
        if not pcall(function() sp:setPaused(false) end) then sfxPlay("receipt", false, 1.0, 1.0) end
      elseif not (sp and sp:isPlaying()) then sfxPlay("receipt", false, 1.0, 1.0) end   -- plays once, no loop
    else
      r.hold = (r.hold or 0) - dt
      if r.hold <= 0 and r.crank < RECEIPT_CRANK and not UI.rcptPaused and sfx.receipt and sfx.receipt:isPlaying() then
        UI.rcptPaused = pcall(function() sfx.receipt:setPaused(true) end)    -- (a pause in the cranking pauses it, rather than starting it over next time)
      end
    end
    if r.tick >= 30 then r.tick = r.tick - 30; sfxTick() end
    if r.crank >= RECEIPT_CRANK then
      c.stage = 2
      closeStation()
      routeTo(c, PICK_X, PICK_Y)      -- the customer drifts over to the pickup end
      say("Receipt printed!")
    end
  end
end

-- ---- 2. coffee ------------------------------------------------------
local PICK_BUTTONS = {
  { pd.kButtonUp, "coffee" }, { pd.kButtonRight, "matcha" },
  { pd.kButtonDown, "decaf" }, { pd.kButtonLeft, "tea" },
}

local function updateCoffee(c, dt)
  local f = c.cof
  if f.phase == "pick" then
    for _, pb in ipairs(PICK_BUTTONS) do
      if pd.buttonJustPressed(pb[1]) then f.pick = pb[2]; sfxClick() end
    end
    if pd.buttonJustPressed(pd.kButtonA) then
      if f.pick == nil then
        say("Pick a drink first!")
        sfxWrong()
      else
        f.phase = "pour"
        f.base = nil
        if UI.crankPour then crankHelpStart() end
        if f.pick ~= c.order.kind then c.q = c.q - 0.35; CAFE.mistake(0.12) end    -- wrong drink!
        sfxClick()
      end
    end
    return
  end
  local t = 0
  local autoDone = false
  if UI.crankPour then
    -- crank option: only turning it clockwise pours, and the faster you turn the faster it flows
    -- a real tap: turning the crank clockwise opens the valve, and the further you turn it the faster it flows;
    -- it keeps flowing by itself until you turn the crank back to close it
    local ch = pd.getCrankChange() or 0
    if ch == 0 and UI.color then ch = -24 end           -- (PC: letting go of the space bar closes the tap; on the Playdate the tap stays where you left it)
    f.valve = clamp((f.valve or 0) + ch / 180, 0, 1)         -- half a turn is wide open (and that's as fast as it gets)
    if not f.open and f.valve > 0.15 then f.open = true; f.hadOpen = true      -- a bit of cranking before it starts to flow
    elseif f.open and f.valve < 0.25 then f.open = false end                  -- and a roomy zone near the start where it shuts off
    t = f.open and math.max(0.02, (f.valve - 0.15) / 0.85) or 0
    if f.hadOpen and not f.open and f.fill >= UI.SIZE_FILL[c.order.size or 3] - 0.1 then autoDone = true end   -- tap closed and the cup is full (or a hair under): done
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  else
    local ax, ay = 0, 0
    if pd.accelerometerIsRunning() then
      local x, y = pd.readAccelerometer()
      ax, ay = x or 0, y or 0
    end
    -- the pose you were holding when you stepped up counts as "level"
    if f.base == nil then f.base = { ax, ay } end
    local d = math.sqrt((ax - f.base[1]) ^ 2 + (ay - f.base[2]) ^ 2)
    t = clamp((d - 0.2) / 0.5, 0, 1)
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  end
  if not UI.crankPour then                           -- tilt: back to resting with the cup full (or a hair under) counts as done
    if t > 0 then f.hadOpen = true
    elseif f.hadOpen and f.fill >= UI.SIZE_FILL[c.order.size or 3] - 0.1 then autoDone = true end
  end
  if t > 0 and f.fill < 1.25 then
    local rate = UI.crankPour and (0.6 * t ^ 1.3) or (POUR_RATE_MIN + (POUR_RATE_MAX - POUR_RATE_MIN) * t)
    f.fill = math.min(1.25, f.fill + rate * dt)
    sfxPour()
  else
    sfxStop("pour")
  end
  -- the drink sloshes: bigger ripples the harder it pours, and splashes that fall back with gravity
  do
    local pouring = t > 0 and f.fill < 1.25
    local target = pouring and (0.9 + t * 2.0) or 0.3
    local a = f.amp or 0.3
    a = a + (target - a) * math.min(1, dt * (target > a and 6 or 2.2))
    a = a + math.abs(t - (f.lastT or 0)) * 2                 -- a sudden change sloshes it about
    f.amp, f.lastT = math.min(a, 3), t
    f.drops = f.drops or {}
    local surfY = math.max(173, 221 - math.floor(f.fill * 48))
    if pouring and f.fill > 0.04 and #f.drops < 10 and math.random() < t * 0.9 then
      f.drops[#f.drops + 1] = { x = 270 + math.random(-2, 2), y = surfY, vx = (math.random() - 0.5) * 36, vy = -(25 + math.random() * 40 * t) }
    end
    for i = #f.drops, 1, -1 do
      local q = f.drops[i]
      q.vy = q.vy + 230 * dt
      q.x, q.y = q.x + q.vx * dt, q.y + q.vy * dt
      if q.y >= surfY or q.x < 246 or q.x > 294 then table.remove(f.drops, i) end
    end
  end
  if autoDone or pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB) then
    if f.fill < 0.2 then
      say("Pour some coffee first!")
      sfxWrong()
    else
      local err = math.abs(f.fill - UI.SIZE_FILL[c.order.size or 3])
      local pen = 0
      if err > 0.03 then pen = math.min(0.5, (err - 0.03) * 2.2) end      -- the further from the line, the bigger the mess-up
      c.precise = clamp(1 - err / 0.1, 0, 1)                              -- a spot-on pour earns a bonus on the tip
      if f.fill > 1.2 then                                                -- it spilled over: much worse
        pen = pen + 0.2
        c.patience = math.max(0.05, c.patience - 0.25)                    -- they watch the mess get cleaned up
        CAFE.mistake(0.12)
        sfxWrong()
      end
      c.q = c.q - pen
      c.patience = math.max(0.05, c.patience - pen * 0.4)                 -- sloppy pours annoy people
      if pen > 0 then CAFE.mistake(0.04 + pen * 0.2) end                  -- missed the mark / overflowed
      sfxClick()
      local o = c.order
      if o.milk + o.sugar + o.shot + o.ice == 0 then
        c.stage = 4                      -- nothing to mix in: straight to pick up
      else
        c.stage = 3
      end
      closeStation()
    end
  end
end

-- ---- 3. mixer --------------------------------------------------------
local function updateMixer(c, dt)
  local m = c.mix
  if m.phase == 1 then
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if m.milk < 4 then m.milk = m.milk + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if m.sugar < 4 then m.sugar = m.sugar + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      if m.shot < 4 then m.shot = m.shot + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      if m.ice < 4 then m.ice = m.ice + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonA) then
      m.phase = 2
      crankHelpStart()
      sfxClick()
    end
  else
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    m.angle = m.angle + change
    m.progress = m.progress + ch / MIX_CRANK
    m.tick = m.tick + ch
    if m.tick >= 40 then m.tick = m.tick - 40; sfxTick() end
    -- electric mixer noise while you crank (faster crank = higher whirr)
    if ch > 0.8 then
      m.hold = 0.15
      local icy = (m.ice > 0 and sfx.icemixer) and "icemixer" or "mixer"            -- a drink with ice rattles while it mixes
      if not ((sfx.mixer and sfx.mixer:isPlaying()) or (sfx.icemixer and sfx.icemixer:isPlaying())) then sfxPlay(icy, false, 1.0, 1.0) end
    else
      m.hold = m.hold - dt
      if m.hold <= 0 and m.progress < 1 then sfxStop("mixer") end
    end
    if m.progress >= 1 then
      m.progress = 1
      local o = c.order
      local off = math.abs(m.milk - o.milk) + math.abs(m.sugar - o.sugar)
                + math.abs(m.shot - o.shot) + math.abs(m.ice - o.ice)
      c.q = c.q - 0.2 * off
      if off > 0 then CAFE.mistake(math.min(0.2, 0.04 * off)) end   -- wrong or missing ingredients
      c.stage = 4
      closeStation(true)               -- the mixer winds down by itself
    end
  end
end

-- ---- 4. serve + bell -------------------------------------------------
local function updateServe(c, dt)
  local s = c.srv
  if s.phase == 1 then
    s.phase = 2                       -- (safety: never wait for a second A)
  elseif s.phase == 2 then
    s.slide = math.min(1, s.slide + dt / 0.35)
    s.recent = s.recent * 0.85
    -- the plate has to land before the bell can be rung
    if pd.buttonJustPressed(pd.kButtonA) and s.slide >= 1 then
      s.phase = 3
      s.ding = 0.9
      sfxPlay("bell", false, 1.0)                 -- ding!
    end
  else
    s.ding = s.ding - dt
    if s.ding <= 0 then finishOrder(c) end
  end
end

-- ---- Evening Chill: dish bin and cup shelf ------------------------------
local function updateDishes(dt)
  local s, cu = G.sink, G.cups
  sfxPlay("sink", true, 0.6)                    -- the tap is already dripping when you open it
  if s.state == "empty" then
    sfxStop("cleaning")
    if cu.dirty > 0 then                          -- (safety) a dirty cup hops straight in
      cu.dirty = cu.dirty - 1
      s.state, s.progress, s.angle = "washing", 0, 0
      sfxCup()
    else                                          -- all clean: the screen closes by itself
      closeStation()
    end
  elseif s.state == "washing" then
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    s.angle = s.angle + change
    s.progress = s.progress + ch / DISH_CRANK
    s.tick = (s.tick or 0) + ch
    if s.tick >= 40 then s.tick = s.tick - 40; sfxTick() end
    if ch > 0.8 then sfxPlay("cleaning", true, 1.0) else sfxStop("cleaning") end
    if s.progress >= 1 then
      s.progress = 1
      s.state, s.t = "sparkle", 0
      cu.hand = cu.hand + 1                 -- the clean cup is in your hand right now
      sfxStop("cleaning")
      sfxGood()
      sfxCup()
    end
  else
    s.t = s.t + dt
    if s.t >= 0.8 then
      if cu.dirty > 0 then                  -- the next dirty cup hops into the sink
        cu.dirty = cu.dirty - 1
        s.state, s.progress, s.angle = "washing", 0, 0
      else
        s.state = "empty"
      end
    end
  end
end

local function updateShelf(dt)
  local cu = G.cups
  if pd.buttonJustPressed(pd.kButtonA) then
    if cu.hand > 0 and cu.shelf < G.cupMax then
      cu.hand = cu.hand - 1
      cu.shelf = cu.shelf + 1
      sfxCup()
      if cu.hand == 0 then closeStation() end            -- that was the last one: step away on its own
    else
      say("You're not holding any cups.")
      sfxWrong()
    end
  end
end

local function updateStation(dt)
  if G.st == "dishes" or G.st == "shelf" then
    -- shelf with nothing left to place: A, B or the d-pad all step away from it
    local anyPad = pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
                or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight)
    if G.st == "shelf" and G.cups.hand == 0 and (anyPad or pd.buttonJustPressed(pd.kButtonA)) then
      closeStation()
      sfxClick()
      return
    end
    if pd.buttonJustPressed(pd.kButtonB) or (G.st == "dishes" and anyPad) then   -- walk away any time
      sfxStop("cleaning")
      closeStation()
      sfxClick()
      return
    end
    if G.st == "dishes" then updateDishes(dt) else updateShelf(dt) end
    return
  end
  local c = G.cust
  if c == nil then closeStation(); return end
  local locked = (G.st == "serve" and c.srv.phase == 3)
  local pouring = (G.st == "coffee" and c.cof.phase == "pour")   -- B = A while pouring
  if pd.buttonJustPressed(pd.kButtonB) and not locked and not pouring then
    sfxStop("receipt")
    closeStation()
    sfxClick()
    return
  end
  if G.st == "register" then updateRegister(c, dt)
  elseif G.st == "coffee" then updateCoffee(c, dt)
  elseif G.st == "mixer" then updateMixer(c, dt)
  elseif G.st == "serve" then updateServe(c, dt) end
end

----------------------------------------------------------------------
-- Updating the shop: arrivals, the line, seating, the door
----------------------------------------------------------------------
-- customers arrive faster during the morning and lunch rushes
local function patienceSecs()
  if G.mode == "cafe" then return 60 + 20 * G.cafe.stars end      -- a minute, plus 20 s per star
  if G.mode ~= "rush" then return CHILL_PATIENCE end
  return 20                                  -- Fast Cafe: twenty seconds per customer
end

local function arrivalGap()
  if G.mode == "cafe" then
    return CAFE.gap(24 - 2.6 * G.cafe.stars, 10 - G.cafe.stars)                                -- more stars, more customers
  end
  if G.mode == "chill" then return CAFE.gap(CHILL_ARRIVE_MIN, CHILL_ARRIVE_SPAN) end
  local hourF = G.t / RUSH_SECONDS * 7
  if (hourF >= 1 and hourF < 2.5) or (hourF >= 5 and hourF < 6.5) then
    return 5 + math.random() * 3
  end
  return 7 + math.random() * 4
end

local function updateOthers(dt)
  for i = #G.others, 1, -1 do
    local c = G.others[i]
    moveAlong(c, dt)
    if c.state == "toSeat" and #c.path == 0 then
      c.state = "seated"
      if G.mode ~= "rush" then
        c.stay = CHILL_STAY_MIN + math.random() * (CHILL_STAY_MAX - CHILL_STAY_MIN)
      else
        c.stay = STAY_MIN + math.random() * (STAY_MAX - STAY_MIN)
      end
    elseif c.state == "seated" then
      c.stay = c.stay - dt
      if c.stay <= 0 then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      end
    elseif c.state == "leaving" and #c.path == 0 then
      table.remove(G.others, i)
    end
  end
end

local function anyoneAtDoor()
  local function near(c)
    return #c.path > 0 and math.abs(c.x - DOOR_X) < 40 and c.y > 205
  end
  if G.cust and near(G.cust) then return true end
  for _, c in ipairs(G.line) do if near(c) then return true end end
  for _, c in ipairs(G.others) do if near(c) then return true end end
  return false
end

local function updateCustomers(dt)
  if G.mode ~= "rush" then CAFE.flowUpdate(dt) end
  -- someone new comes in (if the line has room)
  G.arriveIn = G.arriveIn - dt
  if G.arriveIn <= 0 then
    G.arriveIn = arrivalGap()
    local room = #G.line < LINE_MAX
    if room and G.mode == "cafe" and not CAFE.admit(#G.line + (G.cust and 1 or 0) + 1) then
      room = false
      G.arriveIn = 3 + math.random() * 4               -- (the street was quiet: try again in a few seconds)
    end
    if room then
      local c = newCustomer()
      G.line[#G.line + 1] = c
      routeTo(c, LINE_SLOTS[#G.line][1], LINE_SLOTS[#G.line][2])
    end
  end

  -- the next person in line steps up to the register
  if G.cust == nil then
    G.stepT = G.stepT - dt
    if G.stepT <= 0 and #G.line > 0 then
      local c = table.remove(G.line, 1)
      c.state = "active"
      G.cust = c
      routeTo(c, REG_X, REG_Y)
      relineup()
    end
  end

  -- people waiting in line slowly lose patience
  for i = #G.line, 1, -1 do
    local c = G.line[i]
    moveAlong(c, dt)
    if #c.path == 0 then
      if G.mode == "cafe" and not CAFE.rich() then c.patience = c.patience - dt / (patienceSecs() * LINE_PATIENCE) end   -- (only the Cafe has people losing patience in line; in Rush Hour and Evening Chill just the person at the counter does)
      if c.patience <= 0 then
        table.remove(G.line, i)
        G.missed = G.missed + 1
        leaveRoute(c)
        G.others[#G.others + 1] = c
        relineup()
        say("Someone gave up waiting!")
      end
    end
  end

  -- the person at the counter
  local c = G.cust
  if c then
    moveAlong(c, dt)
    if c.stage == 0 and #c.path == 0 then
      c.stage = 1
    end
    if c.stage >= 1 then
      if not UI.noWait() then c.patience = c.patience - dt / patienceSecs() end     -- (Evening Chill and the test cafe: nobody runs out of patience)
      if c.patience <= 0 then
        c.patience = 0
        G.missed = G.missed + 1
        G.streak = 0
        say("A customer walked out!")
        if G.mode == "cafe" then CAFE.mistake(0.4); G.cafe.pstreak = 0 end      -- (a walk-out ends a run of perfect orders too)
        sfxWrong()
        if c.hasCup then c.hasCup = false; G.cups.shelf = G.cups.shelf + 1 end   -- the cup goes back
        closeStation()
        G.cust = nil
        G.stepT = 0.6
        leaveRoute(c)
        G.others[#G.others + 1] = c
      end
    end
  end

  updateOthers(dt)

  -- the door swings open when someone is coming or going
  local want = anyoneAtDoor() and 1 or 0
  if want == 1 and G.door == 0 then sfxPlay("door", false, 1.0) end      -- the door chime, each time it opens
  if G.door < want then G.door = math.min(want, G.door + dt * 5)
  elseif G.door > want then G.door = math.max(want, G.door - dt * 5) end
end

local function updateWalking(dt)
  local dir = 0
  if pd.buttonIsPressed(pd.kButtonLeft) then dir = -1
  elseif pd.buttonIsPressed(pd.kButtonRight) then dir = 1 end
  G.moving = (dir ~= 0)
  if G.moving then
    G.px = clamp(G.px + dir * WALK_SPEED * dt, WALK_MIN, WALK_MAX)
    G.walk = G.walk + dt * 14
  end
  -- Up picks the wall shelf, Down picks the counter below (Evening Chill)
  if not nearWall() then
    G.sel = "down"
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    G.sel = "up"
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonDown) then
    G.sel = "down"
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonA) then
    if shelfSelected() then
      G.st = "shelf"
      sfxClick()
    else
      local st = nearStation()
      if st then tryOpen(st) end
    end
  end
end

endDay = function()
  closeStation()
  setShiftMenu(false)
  if G.mode == "cafe" then CAFE.finish(); return end
  G.total = G.cash + G.tips
  if G.mode == "rush" then UI.statAdd("rushes", 1); UI.statMax("rushbest", G.total); UI.achCheck(); UI.metaSave() end
  G.endT = 0
  entry.cur = 1
  entry.crank = 0
  for i = 1, 3 do
    entry.letters[i] = string.byte(lastInitials, i) - 65
    if entry.letters[i] < 0 or entry.letters[i] > 25 then entry.letters[i] = 0 end
  end
  state = STATE_ENTRY
end

-- Evening Chill and the Cafe have no clock: the Menu button has an "End shift" item
-- (and the Cafe adds "Save & quit" under it)
local shiftItem = nil
setShiftMenu = function(on, withSave)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if UI.setTitleItem then UI.setTitleItem(not withSave) end
  if withSave and CAFE.saveItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Save & quit", function() CAFE.saveQuit() end)
    end)
    if ok then CAFE.saveItem = item; CAFE.saveJustAdded = true end
  elseif (not withSave) and CAFE.saveItem ~= nil then
    pcall(function() menu:removeMenuItem(CAFE.saveItem) end)
    CAFE.saveItem = nil
  end
  if withSave and shiftItem ~= nil and CAFE.saveJustAdded then      -- (Save & quit goes above Go to Shop, so Go to Shop is the bottom item)
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
  CAFE.saveJustAdded = nil
  local title = withSave and "Go to Shop" or "End shift"      -- (in the Cafe it opens the shop)
  if shiftItem ~= nil and UI.shiftTitle ~= title then
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
  if on and shiftItem == nil then
    UI.shiftTitle = title
    local ok, item = pcall(function()
      return menu:addMenuItem(title, function()
        if state == STATE_PLAY and G and G.mode ~= "rush" and not G.ending then
          G.ending = true
          transitionTo(endDay)
        end
      end)
    end)
    if ok then shiftItem = item end
  elseif (not on) and shiftItem ~= nil then
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
end

local function updatePlay(dt)
  G.t = G.t + dt
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    if rem <= 1 and not G.alarmed then         -- the classic alarm clock starts a second before time is up, so it is already ringing as the clock hits 0:00
      G.alarmed = true
      sfxPlay("alarm", false, 1.0)
    end
    if rem <= 0 then
      G.t = limit
      if not G.ending then
        G.ending = true
        transitionTo(endDay)
      end
      return
    end
  end
  if G.msgT > 0 then
    G.msgT = G.msgT - dt
    if G.msgT <= 0 then G.msg = nil end
  end
  for i = #G.popups, 1, -1 do
    local p = G.popups[i]
    p.t = p.t + dt
    if p.t >= p.life then table.remove(G.popups, i) end
  end
  WIN.updateWindow(dt)
  if G.mode == "cafe" then UI.playTick(dt) end
  if G.pets then CAFE.updatePets(dt) end
  updateCustomers(dt)
  if G.st then updateStation(dt) else updateWalking(dt) end
end

----------------------------------------------------------------------
-- Drawing: people
----------------------------------------------------------------------
-- look 1..4 = customers, 5 = the barista
UI.LOOKS = { 1, 2, 3, 4, 6, 7, 8, 9, 10 }
UI.BARISTA = { 5, 11, 12 }                     -- the three starting barista models

local function drawPerson(x, y, look, angry, mood)
  x, y = math.floor(x), math.floor(y)
  -- body
  if look == 5 or look == 11 or look == 12 then              -- the three barista models share the apron
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(WHITE)
    gfx.fillRect(x - 6, y + 10, 12, 12)
    gfx.setColor(BLACK)
    gfx.drawRect(x - 6, y + 10, 12, 12)
  else
    gfx.setColor(BLACK)
    if look == 2 then gfx.setPattern(CHECK) end
    if look == 3 then gfx.setColor(WHITE) end
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 12, y + 7, 24, 15, 6)
    if look == 4 then
      gfx.setColor(WHITE)
      gfx.fillRect(x - 10, y + 13, 20, 2)
    end
  end
  -- head
  if look == 1 or look == 5 or look == 12 then
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y + 3, 7)
  else
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawCircleAtPoint(x, y, 9)
    gfx.setLineWidth(1)
  end
  if look == 6 then          -- long hair
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 10, y - 9, 20, 9, 4)
    gfx.fillRect(x - 10, y - 3, 4, 14)
    gfx.fillRect(x + 6, y - 3, 4, 14)
    gfx.setColor(WHITE); gfx.drawLine(x - 3, y - 5, x + 4, y - 3); gfx.setColor(BLACK)
  elseif look == 5 then      -- the barista with short, spiky hair
    gfx.setColor(BLACK)
    gfx.fillTriangle(x - 8, y - 6, x - 5, y - 11, x - 2, y - 7)
    gfx.fillTriangle(x - 3, y - 7, x, y - 12, x + 3, y - 7)
    gfx.fillTriangle(x + 2, y - 7, x + 5, y - 11, x + 8, y - 6)
    gfx.fillRect(x - 9, y - 4, 2, 7)
    gfx.fillRect(x + 7, y - 4, 2, 7)
  elseif look == 12 then     -- the barista with long hair and a little bow
    gfx.setColor(BLACK)
    gfx.fillRect(x - 11, y - 4, 4, 17)                    -- long hair down both sides, flicked out at the ends
    gfx.fillRect(x + 7, y - 4, 4, 17)
    gfx.fillCircleAtPoint(x - 11, y + 12, 3)
    gfx.fillCircleAtPoint(x + 11, y + 12, 3)
    gfx.fillRect(x - 8, y - 6, 16, 4)                      -- bangs
    gfx.fillTriangle(x - 8, y - 2, x - 2, y - 2, x - 8, y + 2)
    gfx.fillTriangle(x + 8, y - 2, x + 2, y - 2, x + 8, y + 2)
    if not UI.noBow then
      gfx.setColor(WHITE)                               -- a white bow with a black outline, tilted to sit on the hair
      gfx.fillTriangle(x + 6, y - 6, x + 2, y - 10, x + 1, y - 5)
      gfx.fillTriangle(x + 6, y - 6, x + 10, y - 6, x + 8, y - 1)
      gfx.setColor(BLACK)
      gfx.drawLine(x + 6, y - 6, x + 2, y - 10); gfx.drawLine(x + 2, y - 10, x + 1, y - 5); gfx.drawLine(x + 1, y - 5, x + 6, y - 6)
      gfx.drawLine(x + 6, y - 6, x + 10, y - 6); gfx.drawLine(x + 10, y - 6, x + 8, y - 1); gfx.drawLine(x + 8, y - 1, x + 6, y - 6)
      gfx.fillRect(x + 5, y - 7, 2, 2)
    end
  elseif look == 8 then      -- a cap with the brim to one side
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 8, y - 11, 16, 8, 4)
    gfx.fillRect(x - 9, y - 4, 22, 2)
    gfx.setColor(WHITE); gfx.drawPixel(x, y - 10); gfx.setColor(BLACK)
  elseif look == 9 then      -- big curly hair
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x - 6, y - 6, 4); gfx.fillCircleAtPoint(x, y - 9, 4); gfx.fillCircleAtPoint(x + 6, y - 6, 4)
    gfx.fillCircleAtPoint(x - 9, y - 1, 3); gfx.fillCircleAtPoint(x + 9, y - 1, 3)
    gfx.fillRect(x - 7, y - 6, 14, 3)
  elseif look == 10 then     -- ponytail
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 9, y - 10, 18, 8, 4)
    gfx.fillCircleAtPoint(x + 11, y - 3, 3)
    gfx.fillRect(x + 9, y - 6, 3, 4)
  elseif look == 2 then      -- hat
    gfx.setColor(BLACK)
    gfx.fillRect(x - 12, y - 4, 24, 4)
    gfx.fillRect(x - 7, y - 11, 14, 8)
  elseif look == 4 then      -- beanie
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x - 8, y - 11, 16, 9, 4)
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(x - 8, y - 11, 16, 9, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 8, y - 11, 16, 9, 4)            -- an outline, so the shading stays inside its rounded box
    gfx.fillRect(x - 9, y - 4, 18, 2)
  end
  -- face: everything is placed from "e", the top row of the eyes, so it always fits inside the round head
  gfx.setColor(BLACK)
  local gl = (look == 3) or (UI.glasses == true)             -- wearing glasses
  local e = UI.eyeRow(look, gl)
  if gl and look == 3 then CAFE.WEAR.g_round(x, y + e) end   -- (the customer with round glasses)
  gfx.fillRect(x - 4, y + e, 2, 2)                           -- two eyes the same size, the same distance either side of the middle
  gfx.fillRect(x + 3, y + e, 2, 2)
  if look == 12 then         -- lashes
    gfx.drawPixel(x - 5, y + e - 1); gfx.drawPixel(x + 5, y + e - 1)
  end
  mood = mood or (angry and 0 or 2)
  if gl and mood == 3 then mood = 2 end                      -- (no room for the big grin under glasses)
  if UI.noMouth then return end                              -- (a test switch: draw the face without its mouth)
  local m = y + e + 4 + (gl and 2 or 0)                      -- the row the bottom of a smile sits on
  if mood == 0 then                                -- a frown, with cross eyebrows
    if not gl then
      gfx.drawLine(x - 6, y + e - 4, x - 2, y + e - 2)
      gfx.drawLine(x + 6, y + e - 4, x + 2, y + e - 2)
    end
    gfx.drawLine(x - 3, m, x - 2, m - 1)
    gfx.drawLine(x - 2, m - 1, x + 2, m - 1)
    gfx.drawLine(x + 2, m - 1, x + 3, m)
  elseif mood == 1 then                            -- so-so: a small, slightly lopsided mouth
    gfx.drawLine(x - 2, m, x + 1, m)
    gfx.drawLine(x + 1, m, x + 3, m - 1)
  elseif mood == 3 then                            -- delighted: a wide, happy smile
    gfx.drawLine(x - 4, m - 1, x - 3, m)                   -- (the smile, with a little more underneath: an open grin)
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x + 3, m, x + 4, m - 1)
    gfx.drawLine(x - 1, m + 1, x + 1, m + 1)
  else
    gfx.drawLine(x - 4, m - 1, x - 3, m)                   -- a smile as wide as the eyes, the same either side of the middle
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x + 3, m, x + 4, m - 1)
  end
end

-- the row (from the middle of the head) where the top of the eyes sits: bald heads have the most face to spare,
-- dark-haired heads have their face a little lower, and glasses lift the eyes a row to leave room for the mouth
function UI.eyeRow(look, gl)
  local e
  if look == 7 or look == 11 then e = -1; if gl then e = e - 1 end
  elseif look == 1 or look == 5 or look == 12 then e = 2; if gl then e = e - 1 end
  else e = 1; if gl then e = e - 2 end end
  return e
end

-- 3 = delighted, 2 = smiling, 1 = flat, 0 = frowning (patience running out, a bungled order, a walk-out)
function UI.mood(c)
  if c.state == "line" or c.state == "active" then
    local m = (c.patience > 0.6) and 2 or ((c.patience > 0.3) and 1 or 0)
    if c.stage >= 2 then
      if c.q < 0.5 then m = 0
      elseif c.q < 0.8 then m = math.min(m, 1)
      elseif c.q >= 0.97 and c.stage >= 4 and m >= 1 then m = 3 end
    end
    return m
  end
  if c.final then return (c.final >= 0.9 and 3) or (c.final >= 0.7 and 2) or (c.final >= 0.5 and 1) or 0 end
  return (c.patience <= 0) and 0 or 2
end

-- A little bar that shrinks as the customer gets impatient.
-- onDark = true draws it in white so it shows up on a black band.
local function drawPatience(x, y, p, w, onDark)
  if onDark then
    gfx.setColor(WHITE)
    gfx.drawRect(x, y, w, 6)
    gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
    gfx.setColor(BLACK)
    return
  end
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, 6)
  gfx.setColor(BLACK)
  gfx.drawRect(x, y, w, 6)
  gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
end

function UI.heldCup(c, x, y)                       -- served people carry their drink, and the ones sitting down take a sip now and then
  if not c.final then return end
  if not (c.state == "toSeat" or c.state == "seated" or c.state == "leaving") then return end
  local p = 0
  if c.state == "seated" then
    local ph = (frames + c.look * 53 + (c.seat or 0) * 17) % 210
    if ph < 40 then p = math.sin(math.pi * ph / 40) end
  end
  local cx, cy = math.floor(x + 12 - p * 9), math.floor(y + 16 - p * 10)
  local o = c.order
  gfx.setColor(BLACK)
  gfx.drawLine(x + 9, y + 13, cx - 3, cy - 1)                        -- the arm
  if o.ice > 0 then                                                  -- a little iced glass with a straw
    gfx.setColor(WHITE); gfx.fillPolygon(cx - 3, cy - 4, cx + 3, cy - 4, cx + 2, cy + 5, cx - 2, cy + 5)
    gfx.setColor(BLACK); gfx.drawPolygon(cx - 3, cy - 4, cx + 3, cy - 4, cx + 2, cy + 5, cx - 2, cy + 5)
    gfx.setPattern(DRINK_PATTERN[o.kind or "coffee"]); gfx.fillRect(cx - 2, cy - 1, 5, 5); gfx.setColor(BLACK)
    gfx.drawLine(cx + 1, cy + 4, cx + 1, cy - 4); gfx.drawLine(cx + 1, cy - 4, cx + 4, cy - 9)
  else                                                               -- a hot cup with a handle
    gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy - 3, 7, 8)
    gfx.setColor(BLACK); gfx.drawRect(cx - 3, cy - 3, 7, 8)
    gfx.setPattern(DRINK_PATTERN[o.kind or "coffee"]); gfx.fillRect(cx - 2, cy - 2, 5, 3); gfx.setColor(BLACK)
    gfx.drawLine(cx + 4, cy - 1, cx + 6, cy - 1); gfx.drawLine(cx + 6, cy - 1, cx + 6, cy + 2); gfx.drawLine(cx + 6, cy + 2, cx + 4, cy + 2)
    if p < 0.3 then                                                  -- squiggly steam
      for i = 0, 1 do
        local px, py
        for yy = cy - 5, cy - 12, -2 do
          local xx = cx - 1 + i * 3 + math.floor(math.sin(frames * 0.25 + yy * 0.8 + i * 2) * 1.4 + 0.5)
          if px then gfx.drawLine(px, py, xx, yy) end
          px, py = xx, yy
        end
      end
    end
  end
  gfx.setColor(BLACK)
end

local function drawCustomer(c, withBar)
  local bob = 0
  if #c.path > 0 then bob = math.floor(math.sin(c.walk) * 1.5 + 0.5) end
  local angry = c.patience < 0.3 and (c.state == "line" or c.state == "active")
  UI.glasses = c.glass ~= nil
  drawPerson(c.x, c.y + bob, c.look, angry, UI.mood(c))
  UI.glasses = false
  if c.hat or c.glass then
    local wx, wy = math.floor(c.x), math.floor(c.y + bob)
    if c.hat then CAFE.drawHat(c.hat, wx, wy, c.look) end
    if c.glass then CAFE.WEAR[c.glass](wx, wy + UI.eyeRow(c.look, true)) end
    gfx.setColor(BLACK)
  end
  UI.heldCup(c, math.floor(c.x), math.floor(c.y + bob))
  if withBar and c.stage >= 1 and c.stage <= 4 and not UI.noWait() then
    drawPatience(math.floor(c.x) - 16, math.floor(c.y) - 20, c.patience, 32)
  elseif c.state == "line" and G.mode == "cafe" and not CAFE.rich() and #c.path == 0 then      -- people waiting show a little bar beside them (Cafe only)
    drawPatience(math.floor(c.x) + 16, math.floor(c.y) + 2, c.patience, 24)
  end
  if angry and (math.floor(frames / (6))) % 2 == 0 then
    gfx.setColor(BLACK)
    drawT("!", math.floor(c.x) + 12, math.floor(c.y) - 22, true)
  end
end

local function drawBubble(c)
  local lines = orderLines(c.order)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(c.greet)
  gfx.setFont(fontNormal)
  for _, line in ipairs(lines) do tw = math.max(tw, (gfx.getTextSize(line))) end
  local bw = math.min(206, tw + 28)                      -- hugs the words, with room at the sides
  local bh = 8 + 17 * (1 + #lines)
  local cx = math.floor(c.x)
  local right = cx < 200
  local bx = right and (cx + 26) or (cx - 26 - bw)
  local by = 122
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, by, bw, bh, 8)
  gfx.setLineWidth(1)
  -- little tail pointing at the customer
  local ex = right and bx or (bx + bw)
  local dir = right and -1 or 1
  gfx.setColor(WHITE)
  gfx.fillTriangle(ex, by + 8, ex, by + 22, ex + dir * 10, by + 15)
  gfx.fillRect(ex - 2, by + 9, 4, 12)
  gfx.setColor(BLACK)
  gfx.drawLine(ex, by + 8, ex + dir * 10, by + 15)
  gfx.drawLine(ex + dir * 10, by + 15, ex, by + 22)
  drawTC(c.greet, bx + math.floor(bw / (2)), by + 3, true)
  for i, line in ipairs(lines) do
    drawTC(line, bx + math.floor(bw / (2)), by + 3 + 17 * i)
  end
end

----------------------------------------------------------------------
-- Drawing: the shop
----------------------------------------------------------------------
-- the view out of a window: bx, by = the top-left of the glass on screen, k = how much bigger than the cafe's window
function WIN.sunAt(cx, cy, r, spin)                 -- a sun with little rays that turn
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy, r)
  for i = 0, 7 do
    local a = i * math.pi / 4 + spin
    gfx.drawLine(cx + math.cos(a) * (r + 2), cy + math.sin(a) * (r + 2), cx + math.cos(a) * (r + 4), cy + math.sin(a) * (r + 4))
  end
end

function WIN.moonAt(cx, cy, r)                      -- a crescent
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + math.max(1, math.floor(r / (2)) + 1), cy - 1, r - 1)
  gfx.setColor(BLACK)
end

function WIN.cloudAt(cx, cy, k, big)              -- a puffy cloud that covers whatever is behind it
  local b = big and 1 or 0
  local function blob(ex, fill)
    gfx.setColor(fill)
    gfx.fillCircleAtPoint(cx - 5 * k, cy + k, 3 * k + ex)
    gfx.fillCircleAtPoint(cx, cy - k, (4 + b) * k + ex)
    gfx.fillCircleAtPoint(cx + 5 * k, cy + k, 3 * k + ex)
    gfx.fillRect(cx - 8 * k - ex, cy + k - ex, 16 * k + 2 * ex, 3 * k + 2 * ex)
  end
  blob(1, BLACK); blob(0, WHITE)
  gfx.setColor(BLACK)
end

function WIN.drawView(w, bx, by, k, noPeople)
  local function X(x) return math.floor(bx + (x - 15) * k) end
  local function Y(y) return math.floor(by + (y - 23) * k) end
  local function L(x0, y0, x1, y1) gfx.drawLine(X(x0), Y(y0), X(x1), Y(y1)) end
  gfx.setClipRect(bx + 1, by + 1, 52 * k - 2, 24 * k - 2)
  local na = WIN.nightAmt(w)
  local night = na > 0.5
  if UI.color then                                  -- (PC: the colour of the sky, fading between day and night)
    UI.skyBlend(na, w.fx.rain or w.fx.clouds)
    UI.ink("dyn_sky")
    gfx.setColor(WHITE); gfx.fillRect(bx + 1, by + 1, 52 * k - 2, 24 * k - 2)
    if na > 0.05 then                               -- stars, twinkling (they fade in with the dark)
      UI.ink("dyn_star"); gfx.setColor(BLACK)
      for i, st in ipairs(WIN.STARS) do
        if (math.floor(frames / (14)) + i) % 5 ~= 0 then gfx.fillRect(X(st[1]), Y(st[2]), k, k) end
      end
    end
  end
  gfx.setColor(BLACK)
  gfx.setLineWidth(k)
  if w.sky then
    local p = w.sky.t / w.sky.dur
    local sx = X(8 + p * 66)
    local sy = Y(41 - math.sin(math.pi * p) * 15)
    if w.sky.kind == "sun" and (w.fx.rain or w.fx.snow) then
      -- no sun while it rains or snows (Christmas days are just snow and clouds)
    elseif w.sky.kind == "sun" then UI.ink("yellow"); WIN.sunAt(sx, sy, 3 * k, (w.sky.t * 0.4) % 6.28)
    else UI.ink("dyn_moon"); WIN.moonAt(sx, sy, 4 * k) end
    gfx.setColor(BLACK)
  end
  UI.ink("dyn_cloud")
  for _, q in ipairs(w.parts) do                    -- clouds drift in front of the sun and moon
    if q.k == "cloud" then WIN.cloudAt(X(math.floor(q.x)), Y(math.floor(q.y)), k, q.s == 1) end
  end
  gfx.setColor(BLACK)
  UI.ink("dyn_walk")
  for _, q in ipairs(noPeople and {} or w.walkers) do   -- a person walking by (not on the door screens)
    local x = math.floor(q.x)
    local step = math.floor(math.sin(q.t) * 2)
    gfx.fillCircleAtPoint(X(x), Y(34), 3 * k)
    gfx.fillRoundRect(X(x - 4), Y(37), 8 * k, 8 * k, 2 * k)
    L(x - 1, 45, x - 1 + step, 49)
    L(x + 1, 45, x + 1 - step, 49)
    if q.umbrella then
      UI.inkPush("inkred")
      gfx.fillTriangle(X(x - 8), Y(31), X(x + 8), Y(31), X(x), Y(24))
      UI.inkPop()
    end
  end
  for _, q in ipairs(w.parts) do
    local x, y = math.floor(q.x), math.floor(q.y)
    if q.k == "cloud" then
      -- (drawn above, behind the people)
    elseif q.k == "rain" then
      UI.ink("dyn_rain")
      L(x, y, x - (q.vx > 0 and -2 or 1), y + 3)
    elseif q.k == "snow" then                       -- a soft flake
      UI.ink("inkwhite")
      local fx, fy = X(x), Y(y)
      if fx >= bx + 3 and fx + 2 * k <= bx + 52 * k - 3 and fy >= by + 3 and fy + 2 * k <= by + 24 * k - 3 then
        gfx.fillRect(fx, fy, 2 * k, 2 * k)
        if (math.floor(q.ph * 2) % 2) == 0 then gfx.drawPixel(fx - 1, fy); gfx.drawPixel(fx + 2 * k, fy + 1) end
      end
    elseif q.k == "wind" then                       -- a lazy, squiggly gust
      UI.ink(night and "dyn_rain" or "inkwhite")
      local px, py = x, y + math.floor(math.sin(q.ph) * 2.5)
      for j = 1, 7 do
        local nx = x - j * 3
        local ny = y + math.floor(math.sin(q.ph - j * 0.9) * 2.5)
        L(px, py, nx, ny)
        px, py = nx, ny
      end
      L(px, py, px - 2, py - 2)                     -- the curl at the tail
    else
      UI.ink(((x + y) % 3 == 0) and "inkred" or "inkorange")
      gfx.fillEllipseInRect(X(x), Y(y), 5 * k, 3 * k)             -- a falling leaf
      L(x - 1, y + 3, x + 1, y + 1)
    end
  end
  gfx.setLineWidth(1)
  gfx.clearClipRect()
  gfx.setColor(BLACK)
end

function WIN.drawWindowView() WIN.drawView(G.win, 33, 23, 1) end
WIN.STARS = { { 12, 26 }, { 20, 31 }, { 31, 25 }, { 40, 29 }, { 49, 24 }, { 58, 30 }, { 66, 26 }, { 26, 36 }, { 53, 36 }, { 63, 34 } }

-- The still parts of the wall are drawn once into a picture (CAFE.sceneTop); this is only what moves.
function CAFE.wallStatic()
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 18, 400, 52)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 68, 400, 3)

  -- opening hours sign (in the Cafe it shows your cafe's name, and can be taken down)
  if G.mode ~= "cafe" or G.cafe.sign ~= false then      -- (the sign)
    gfx.setColor(WHITE)
    gfx.fillRect(272, 22, 90, 26)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(272, 22, 90, 26)
    gfx.setLineWidth(1)
    if G.mode == "cafe" then
      CAFE.fitText(CAFE.cafeName(), 317, 35, 80, 18, 84)          -- (a full 13-letter name fits, and so does a 14-letter one from an older save)
    else
      CAFE.fitText(G.mode == "chill" and "CHILL CAFE" or "FAST CAFE", 317, 35, 80, 18)
    end
  end
  if CAFE.dec() then CAFE.wallItemsRaw(false) end

  -- framed picture of the coffee mug from the title screen
  local fx, fy = 366, 21
  gfx.setColor(WHITE)
  gfx.fillRect(fx, fy, 30, 28)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(fx, fy, 30, 28)
  gfx.drawCircleAtPoint(fx + 22, fy + 16, 3)               -- handle
  gfx.setColor(WHITE)
  gfx.fillRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(fx + 8, fy + 12, 11, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(fx + 3, fy + 23, 22, 2)                      -- saucer
  gfx.drawLine(fx + 10, fy + 8, fx + 12, fy + 5)            -- steam
  gfx.drawLine(fx + 12, fy + 5, fx + 10, fy + 3)
  gfx.drawLine(fx + 16, fy + 8, fx + 18, fy + 5)
  gfx.drawLine(fx + 18, fy + 5, fx + 16, fy + 3)
  gfx.setColor(BLACK)
end

local function drawWall()
  -- window
  CAFE.drawWindowNow()

  -- shelf with cups (in Evening Chill these are the shop's real clean cups)
  do
    if shelfSelected() then
      local pad = ((math.floor(frames / (10))) % 2 == 0) and 0 or 3
      gfx.setColor(WHITE)
      gfx.fillRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setLineWidth(1)
    end
    gfx.setColor(BLACK)
    gfx.fillRect(102, 40, 92, 3)
    local two = G.cupMax > 5                      -- past 5 cups the shelf gets a second row behind the first
    local step = two and 17 or math.min(17, math.floor(88 / (math.max(1, G.cupMax))))
    for pass = 0, 1 do                            -- (the back row first, so the front row covers it)
      for i = 0, G.cupMax - 1 do
        local back = two and i >= 5
        if i < G.cups.shelf and ((pass == 0) == back) then
          local cx = 106 + (back and (i - 5) * step + 8 or i * step)
          local cy = back and 28 or 30
          UI.inkPush("mugc")
          gfx.setColor(WHITE)
          gfx.fillRect(cx, cy, 10, 10)
          gfx.setColor(BLACK)
          gfx.drawRect(cx, cy, 10, 10)
          gfx.fillRect(cx + 11, cy + 3, 2, 4)
          UI.inkPop()
        end
      end
    end
  end

  if CAFE.dec() then CAFE.wallItemsRaw(true) end           -- the clocks and signs that move
  CAFE.drawVines()                                          -- hanging things go over everything below them
  CAFE.drawDangles()
  CAFE.drawLights()                                         -- the string of lights is over everything on the wall
end

function CAFE.counterStatic()
  gfx.setColor(WHITE)
  gfx.fillRect(0, 74, 400, 22)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 74, 400, 2)
  gfx.fillRect(0, 96, 400, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)             -- the station names (the one you stand at gets a bubble over its name)
  gfx.setFont(fontNormal)
  for _, st in ipairs(STATIONS) do drawTC(st.label, st.x, 97) end
  drawTC("TIPS", JAR_X - 3, 97)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)

  -- the machines stand a little way up from the front edge, each with a soft shadow on the counter
  local function stand(key, cx)
    CAFE.stamp(key, cx, 92)
    local w = CAFE.spr(key):getSize()
    gfx.setColor(BLACK)
    for px = cx - math.floor(w / (2)) + 2, cx - math.floor(w / (2)) + w - 3 do
      if (px + 93) % 2 == 0 then gfx.drawPixel(px, 93) end
    end
  end
  stand("m_register", stationById("register").x)        -- the till: customer screen, keys, drawer
  stand("m_coffee", stationById("coffee").x)            -- the espresso machine
  stand("m_mixer", stationById("mixer").x - 1)          -- the drinks blender (a pixel left, so the gaps either side are even)
  stand("m_pickup", stationById("serve").x + 1)         -- the pick-up mat and bell: empty until a cup slides on (a pixel right, so the gaps either side are even)
  local dishSt = stationById("dishes")
  if dishSt then stand("m_sink", dishSt.x) end          -- the sink, with a dotted spot for every cup it can show
  stand("m_jar", JAR_X + 1)                             -- the tip jar (the coins are added live)

  gfx.setColor(BLACK)
end

-- the till's customer screen on the counter: the most recent sale in 3x5 pixel digits, centred in the screen's 15 pixels
function UI.tillDigits(x0, y, cents)
  local str = string.format("%d.%02d", math.floor(cents / (100)), cents % 100)
  local function advance(k, gap)                                        -- how far to move on after glyph k
    local ch, nx = str:sub(k, k), str:sub(k + 1, k + 1)
    local w = (ch == ".") and 1 or 3
    if k < #str then w = w + ((ch == "." or nx == ".") and gap or 1) end
    return w
  end
  local function total(gap) local w = 0; for k = 1, #str do w = w + advance(k, gap) end return w end
  local gap = (total(1) > 15) and 0 or 1                                -- ($10 and up: no air round the dot, so it still fits)
  local x = x0 + math.floor((15 - total(gap)) / (2))
  gfx.setColor(BLACK)
  for k = 1, #str do
    local ch = str:sub(k, k)
    if ch == "." then
      gfx.drawPixel(x, y + 4)
    else
      local g = UI.DIG[ch]
      for gy = 1, 5 do
        local row = g[gy]
        for gx = 1, 3 do
          if row:sub(gx, gx) == "#" then gfx.drawPixel(x + gx - 1, y + gy - 1) end
        end
      end
    end
    x = x + advance(k, gap)
  end
end

CAFE.MUGS = { { 1, 7 }, { 11, 7 }, { 21, 7 }, { 1, 13 }, { 11, 13 }, { 21, 13 }, }     -- where the sink's mugs sit (back row first)

local function drawCounter()
  if CAFE.dec() then CAFE.counterRaw() end                  -- the lamps glow and the plants sway, so these are drawn live

  -- the station you're standing at gets a white bubble that pulses
  local near = (not shelfSelected()) and nearStation() or nil
  if near then
    gfx.setFont(fontNormal)
    local tw = gfx.getTextSize(near.label)
    local pad = ((math.floor(frames / (10))) % 2 == 0) and 0 or 2
    local bw = tw + 12
    gfx.setColor(BLACK)
    gfx.fillRect(near.x - math.floor(bw / (2)) - 3, 96, bw + 6, 18)       -- (wipe the still name first)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(near.x - math.floor(bw / (2)) - pad, 98, bw + pad * 2, 14, 5)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    drawTC(near.label, near.x, 97)
    gfx.setColor(BLACK)
  end

  -- the sink: one mug for every dirty cup, up to six (the dotted spots are already in the picture)
  local dishSt = stationById("dishes")
  if dishSt then
    local mug = CAFE.spr("m_mug")
    local sx = dishSt.x - 15
    local sy = 93 - 21
    for i = 1, math.min(G.cups.dirty, 6) do
      local m = CAFE.MUGS[i]
      mug:draw(sx + m[1], sy + m[2])
    end
  end

  UI.tillDigits(stationById("register").x - 15 + 3, 72 + 2, G.lastSale or 0)       -- the till's screen: the most recent sale

  -- the tip jar: coins pile up as you earn tips
  local coins = math.min(12, math.floor(G.tips / (((G.mode == "cafe") and 1200 or 400))))       -- (fills up slowly)
  if coins > 0 then
    local coin = CAFE.spr("m_coin")
    local jx, jy = JAR_X + 1 - 10, 93 - 27
    for i = 0, coins - 1 do
      local row, col = math.floor(i / (3)), i % 3
      coin:draw(jx + 3 + col * 4 + ((row % 2 == 1) and 2 or 0), jy + 22 - row * 3)
    end
  end
  gfx.setColor(BLACK)
end

-- a chair seen from above: a wooden back on the side away from the table, and a cushioned seat
-- back = "l" / "r" (the back is on that side) or "u" (the back is on top)
function CAFE.chairAt(x, y, back)
  UI.ink("chairwood")
  gfx.setColor(BLACK)
  if back == "u" then gfx.fillRoundRect(x - 9, y - 7, 18, 4, 2)
  elseif back == "l" then gfx.fillRoundRect(x - 7, y - 9, 4, 18, 2)
  else gfx.fillRoundRect(x + 3, y - 9, 4, 18, 2) end
  local sx, sy, sw, sh = x - 4, y - 7, 11, 14                   -- the seat
  if back == "r" then sx = x - 6 elseif back == "u" then sx, sy, sw, sh = x - 7, y - 4, 14, 11 end
  UI.ink("cushion")
  gfx.setColor(WHITE); gfx.fillRoundRect(sx, sy, sw, sh, 3)
  gfx.setColor(BLACK); gfx.drawRoundRect(sx, sy, sw, sh, 3)
  if not UI.color then                                       -- (1-bit: a stitched cushion in the middle of the seat)
    gfx.setPattern(CHECK); gfx.fillRoundRect(sx + 2, sy + 2, sw - 4, sh - 4, 2); gfx.setColor(BLACK)
  else
    gfx.drawPixel(sx + math.floor(sw / 2), sy + math.floor(sh / 2))     -- (a button in the cushion)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- the corner couch: a back along both walls, an arm at each end, and a cushion for every seat
function CAFE.couch()
  UI.ink("couch")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(388, 146, 11, 89, 4)                      -- the back up the right wall...
  gfx.fillRoundRect(316, 224, 83, 11, 4)                      -- ...and along the bottom
  gfx.fillRoundRect(369, 145, 30, 8, 4)                       -- the arm at the top end
  gfx.fillRoundRect(315, 203, 8, 32, 4)                       -- the arm at the left end
  local function cushion(x, y, w, h)
    gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 4)
    gfx.setColor(BLACK); gfx.drawRoundRect(x, y, w, h, 4)
    gfx.drawPixel(x + math.floor(w / 2), y + math.floor(h / 2))                  -- a tufted button
  end
  cushion(370, 153, 19, 22)                                   -- three cushions up the wall (the seats at y 164, 186)...
  cushion(370, 175, 19, 23)
  cushion(370, 198, 19, 27)                                   -- ...the corner one (y 212)...
  cushion(348, 204, 23, 21)                                   -- ...and two along the bottom (x 362, 338)
  cushion(323, 204, 26, 21)
  UI.ink("rsun")                                              -- a throw pillow tucked into the corner
  gfx.setColor(WHITE); gfx.fillRoundRect(371, 199, 8, 8, 2)
  gfx.setColor(BLACK); gfx.drawRoundRect(371, 199, 8, 8, 2)
  if not UI.color then gfx.setPattern(CHECK); gfx.fillRect(373, 201, 4, 4); gfx.setColor(BLACK) end
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- tables, chairs, and the corner nook
local function drawFloorStatic()
  local lim = G.seatLimit
  CAFE.drawRunner()
  CAFE.drawRug()
  CAFE.drawOval()
  if lim >= 9 then CAFE.couch() end                     -- the corner nook: an L-shaped couch up the right wall and along the bottom

  -- chairs
  for i, s in ipairs(SEATS) do
    if i <= lim and not (G.seatOff and G.seatOff[i]) then
      if s.t <= 4 then CAFE.chairAt(s.x, s.y, (s.x < TABLES[s.t].x) and "l" or "r")
      elseif s.back then CAFE.chairAt(s.x, s.y, s.back) end
    end
  end

  -- round tables
  local firstSeat = { 1, 3, 5, 7, 9 }
  for ti, t in ipairs(TABLES) do
    if firstSeat[ti] <= lim and not (G.seatOff and G.seatOff[firstSeat[ti]]) then
      CAFE.tableAt(t.x, t.y, t.r, CAFE.ownedOf("cloth"))
    end
  end

  CAFE.drawFloorItems(false)
  gfx.setColor(BLACK)
end

-- the floor (rugs, chairs, tables, plants) never changes during a shift, so it is drawn once into a
-- picture and stamped on every frame: far fewer drawing calls
local function drawFloor()
  -- the things that move stay live: swaying plants, the blinking tree, candle flames
  CAFE.drawFloorItems(true)
  CAFE.tableTopRaw()                                        -- lamps, candles and plants standing on the tables
  -- a coffee cup in front of everyone who is sitting down
  for i, s in ipairs(SEATS) do
    if G.seats[i] and G.seats[i].state == "seated" then
      local t = TABLES[s.t]
      local cx = math.floor(t.x + (s.x - t.x) * 0.45)
      local cy = math.floor(t.y + (s.y - t.y) * 0.45)
      gfx.setColor(BLACK)
      gfx.fillCircleAtPoint(cx, cy, 3)
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx, cy, 1)
    end
  end
  gfx.setColor(BLACK)
end

-- Everything that never moves (the wall, the counter, the floor) is drawn once into two pictures and stamped on
-- every frame, so each frame has a few hundred fewer drawing calls. The barista is drawn between the two pictures.
function CAFE.scenePic(key, y0, h, drawfn, white)
  local st = G.scn
  if not st then st = {}; G.scn = st end
  local im = st[key]
  if im == nil then
    st[key] = false
    local ok, img = pcall(function() return gfx.image.new(400, h, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      if white then UI.ink((key == "bottom") and "floor" or "none"); gfx.setColor(WHITE); gfx.fillRect(0, white, 400, h - white); UI.ink("none") end    -- (PC: the floor is a soft beige)
      gfx.setDrawOffset(0, -y0)
      drawfn()
      gfx.setDrawOffset(0, 0)
      gfx.setColor(BLACK)
      gfx.popContext()
      im = img
    else
      im = false
    end
    st[key] = im
  end
  return im
end
function CAFE.wallPic() gfx.setColor(WHITE); gfx.fillRect(0, 0, 400, 74); CAFE.wallStatic() end
function CAFE.floorPic() CAFE.counterStatic(); drawFloorStatic() end
function CAFE.sceneTop()
  local im = CAFE.scenePic("top", 0, 74, CAFE.wallPic)
  if im then im:draw(0, 0) else CAFE.wallPic() end
  drawWall()
end
function CAFE.sceneBottom()
  local im = CAFE.scenePic("bottom", 72, 168, CAFE.floorPic, 2)
  if im then im:draw(0, 72) else CAFE.floorPic() end
  drawCounter()
  drawFloor()
end

-- the front door, bottom left: a line that swings open and shut (seen from above)
function UI.drawDoor()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 238, 12, 2)
  gfx.fillRect(46, 238, 354, 2)
  gfx.fillRect(10, 235, 4, 5)
  local a = math.rad(G.door * 90)
  local ex = 14 + math.floor(32 * math.cos(a) + 0.5)
  local ey = 238 - math.floor(32 * math.sin(a) + 0.5)
  gfx.setLineWidth(3)
  gfx.drawLine(14, 238, ex, ey)
  gfx.setLineWidth(1)
end

-- ---- clothes for the barista: hats and glasses (x, y = the middle of the head) --------------------------
CAFE.WEAR = {}
CAFE.WEARIDS = {}
CAFE.WEARCOL = { h_cap = "inkred", h_top = "pcat", h_beanie = "gingham", h_cowboy = "cowboy", h_chef = "white", h_crown = "inkgold",
                 h_party = "inkpink", h_beret = "inkpurple", h_santa = "inkred", h_wizard = "gingham", h_bow = "inkpink", h_flower = "inkgreen",
                 h_witch = "inkpurple", g_round = "brass", g_square = "inkblue", g_shades = "fur", g_heart = "inkpink", g_cat = "inkpurple",
                 g_nerd = "choc", g_monocle = "inkgold", g_3d = "inkred" }          -- (PC: the main colour of each piece; some paint their trims too)
function CAFE.defWear(id, fn)
  CAFE.WEAR[id] = function(x, y) UI.inkPush(CAFE.WEARCOL[id]); fn(x, y); UI.inkPop() end
  CAFE.WEARIDS[#CAFE.WEARIDS + 1] = id
end
CAFE.defWear("h_cap", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 8, y - 12, 16, 9, 4); gfx.fillRect(x - 9, y - 5, 22, 3)
  gfx.setColor(WHITE); gfx.drawPixel(x, y - 11); gfx.drawLine(x - 6, y - 7, x + 6, y - 7); gfx.setColor(BLACK)
end)
CAFE.defWear("h_top", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 6, y - 19, 12, 14); gfx.fillRect(x - 11, y - 7, 22, 3)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 11, 12, 2); gfx.setColor(BLACK)
end)
CAFE.defWear("h_beanie", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 9, y - 14, 18, 9, 5); gfx.fillCircleAtPoint(x, y - 16, 3)
  gfx.setColor(WHITE); gfx.fillRect(x - 10, y - 8, 20, 5); gfx.setColor(BLACK); gfx.drawRect(x - 10, y - 8, 20, 5)    -- a wide folded cuff that covers the top of the head
  for i = -8, 8, 3 do gfx.drawLine(x + i, y - 8, x + i, y - 4) end
end)
CAFE.defWear("h_cowboy", function(x, y)
  gfx.setColor(BLACK); gfx.fillRoundRect(x - 14, y - 8, 28, 4, 2); gfx.fillRoundRect(x - 6, y - 16, 12, 10, 3)
  gfx.fillTriangle(x - 14, y - 8, x - 10, y - 8, x - 14, y - 11); gfx.fillTriangle(x + 14, y - 8, x + 10, y - 8, x + 14, y - 11)
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 9, 12, 1); gfx.setColor(BLACK)
end)
CAFE.defWear("h_chef", function(x, y)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(x - 5, y - 13, 6); gfx.fillCircleAtPoint(x + 5, y - 13, 6); gfx.fillCircleAtPoint(x, y - 16, 6)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x - 5, y - 13, 5); gfx.fillCircleAtPoint(x + 5, y - 13, 5); gfx.fillCircleAtPoint(x, y - 16, 5)
  gfx.fillRect(x - 9, y - 10, 18, 7); gfx.setColor(BLACK); gfx.drawRect(x - 9, y - 10, 18, 7)
  gfx.setColor(WHITE); gfx.fillRect(x - 8, y - 11, 16, 2); gfx.setColor(BLACK)
end)
CAFE.defWear("h_crown", function(x, y)
  gfx.setColor(BLACK); gfx.fillPolygon(x - 9, y - 5, x - 9, y - 16, x - 4, y - 10, x, y - 17, x + 4, y - 10, x + 9, y - 16, x + 9, y - 5)
  gfx.setColor(WHITE); gfx.drawLine(x - 8, y - 6, x + 8, y - 6)
  UI.ink("redp"); gfx.drawPixel(x, y - 12); gfx.drawPixel(x - 6, y - 8); gfx.drawPixel(x + 6, y - 8); gfx.setColor(BLACK)        -- (PC: red jewels)
end)
CAFE.defWear("h_party", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 4, x + 8, y - 4, x, y - 21)
  gfx.setColor(WHITE); gfx.drawLine(x - 4, y - 9, x + 3, y - 12); gfx.drawLine(x - 3, y - 14, x + 2, y - 16)
  UI.ink("yellow")
  gfx.fillCircleAtPoint(x, y - 21, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, y - 21, 2)
end)
CAFE.defWear("h_beret", function(x, y)
  gfx.setColor(BLACK); gfx.fillEllipseInRect(x - 11, y - 14, 22, 10); gfx.fillRect(x - 9, y - 7, 18, 3); gfx.fillRect(x - 1, y - 16, 3, 3)
  gfx.setColor(WHITE); gfx.drawLine(x - 7, y - 9, x - 3, y - 11); gfx.setColor(BLACK)
end)
CAFE.defWear("h_santa", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 9, y - 5, x + 9, y - 5, x + 6, y - 17)
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillRect(x - 10, y - 7, 20, 4); gfx.setColor(BLACK); gfx.drawRect(x - 10, y - 7, 20, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + 6, y - 17, 3); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + 6, y - 17, 3)
end)
CAFE.defWear("h_wizard", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 5, x + 8, y - 5, x + 2, y - 22); gfx.fillRect(x - 12, y - 6, 24, 3)
  UI.ink("yellow")
  gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - 11); gfx.drawPixel(x + 3, y - 15); gfx.drawPixel(x - 3, y - 7); gfx.setColor(BLACK)
end)
CAFE.defWear("h_bow", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 8, y - 14, x - 8, y - 6, x, y - 10); gfx.fillTriangle(x + 8, y - 14, x + 8, y - 6, x, y - 10)
  gfx.fillCircleAtPoint(x, y - 10, 2)
end)
CAFE.defWear("h_flower", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 9, y - 6, 18, 2)
  UI.ink("inkpink")
  for i = 0, 4 do
    local a = i * 1.2566
    gfx.fillCircleAtPoint(x + 5 + math.floor(math.cos(a) * 3 + 0.5), y - 9 + math.floor(math.sin(a) * 3 + 0.5), 2)
  end
  UI.ink("yellow")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + 5, y - 9, 1); gfx.setColor(BLACK)
end)
CAFE.defWear("h_witch", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 12, y - 7, 24, 3)
  gfx.fillTriangle(x - 7, y - 6, x + 7, y - 6, x + 2, y - 19)
  gfx.fillTriangle(x + 2, y - 19, x + 8, y - 18, x + 1, y - 14)
  UI.ink("orangep")
  gfx.setColor(WHITE); gfx.fillRect(x - 6, y - 10, 12, 3); gfx.setColor(BLACK); gfx.drawRect(x - 6, y - 10, 12, 3)
  UI.ink("inkgold")
  gfx.fillRect(x - 1, y - 10, 3, 3)
end)
-- glasses are drawn from the top row of the eyes (y here is that row, not the middle of the head), so they always sit over the eyes.
-- Each lens is 6 wide and 6 tall (rows y-2 .. y+3), so the 2 x 2 eye sits exactly in the middle of it.
CAFE.defWear("g_round", function(x, y)
  gfx.setColor(BLACK)
  gfx.drawEllipseInRect(x - 6, y - 2, 6, 6); gfx.drawEllipseInRect(x + 1, y - 2, 6, 6)
  gfx.drawPixel(x, y)
  gfx.drawLine(x - 7, y, x - 9, y - 1); gfx.drawLine(x + 7, y, x + 9, y - 1)
end)
CAFE.defWear("g_square", function(x, y)
  gfx.setColor(BLACK); gfx.drawRect(x - 6, y - 2, 6, 6); gfx.drawRect(x + 1, y - 2, 6, 6); gfx.drawPixel(x, y)
end)
CAFE.defWear("g_shades", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 7, y - 1, 7, 5); gfx.fillRect(x + 1, y - 1, 7, 5); gfx.drawLine(x, y - 1, x, y - 1)
  gfx.drawLine(x - 8, y - 1, x - 9, y - 1); gfx.drawLine(x + 8, y - 1, x + 9, y - 1)
  gfx.setColor(WHITE); gfx.drawPixel(x - 5, y); gfx.drawPixel(x + 3, y); gfx.setColor(BLACK)
end)
CAFE.defWear("g_heart", function(x, y)
  gfx.setColor(BLACK)
  for _, cx in ipairs({ x - 6, x + 1 }) do          -- a little heart, 6 wide and 5 tall, over each eye
    gfx.fillRect(cx, y - 1, 2, 1); gfx.fillRect(cx + 4, y - 1, 2, 1)
    gfx.fillRect(cx, y, 6, 2); gfx.fillRect(cx + 1, y + 2, 4, 1); gfx.fillRect(cx + 2, y + 3, 2, 1)
  end
  gfx.drawPixel(x, y)
end)
CAFE.defWear("g_cat", function(x, y)
  gfx.setColor(BLACK); gfx.fillTriangle(x - 9, y - 3, x, y - 1, x - 3, y + 3); gfx.fillTriangle(x + 10, y - 3, x + 1, y - 1, x + 4, y + 3)
  gfx.drawLine(x, y - 1, x + 1, y - 1)
end)
CAFE.defWear("g_nerd", function(x, y)
  gfx.setColor(BLACK)
  gfx.drawEllipseInRect(x - 7, y - 2, 8, 6); gfx.drawEllipseInRect(x, y - 2, 8, 6)     -- big frames, joined in the middle
  gfx.fillRect(x - 6, y - 2, 12, 1)                                                      -- a thick top bar
  gfx.drawLine(x - 8, y - 1, x - 9, y - 1); gfx.drawLine(x + 8, y - 1, x + 9, y - 1)
end)
CAFE.defWear("g_monocle", function(x, y)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(x + 1, y - 2, 6, 6); gfx.drawLine(x + 6, y + 4, x + 8, y + 7); gfx.drawLine(x + 8, y + 7, x + 7, y + 12)
end)
CAFE.defWear("g_3d", function(x, y)
  gfx.setColor(BLACK); gfx.fillRect(x - 6, y - 1, 6, 5)
  UI.ink("inkteal")
  if UI.color then gfx.fillRect(x + 1, y - 1, 6, 5) else gfx.setPattern(CHECK); gfx.fillRect(x + 1, y - 1, 6, 5); gfx.setColor(BLACK) end
  UI.ink("white")
  gfx.drawRect(x + 1, y - 1, 6, 5); gfx.drawPixel(x, y - 1)
end)
-- how many rows a hat is raised for each hairstyle, so big or spiky hair sits under the hat and nothing pokes out of the top
CAFE.HATLIFT = {
  h_cap = { [5] = 1, [6] = 3, [9] = 5, [10] = 4, [12] = 2 },
  h_top = { [5] = 2, [6] = 2, [9] = 3, [10] = 3 },
  h_beanie = { [9] = 3, [10] = 3, [12] = 2 },
  h_cowboy = { [5] = 1, [6] = 1, [9] = 2, [10] = 2 },
  h_chef = { [6] = 3, [9] = 5, [10] = 3, [12] = 3 },
  h_crown = { [6] = 1, [9] = 3, [10] = 2, [12] = 1 },
  h_party = { [5] = 1, [6] = 4, [9] = 6, [10] = 4, [12] = 3 },
  h_beret = { [6] = 2, [9] = 4, [10] = 2, [12] = 2 },
  h_santa = { [5] = 3, [6] = 2, [9] = 3, [10] = 3, [12] = 2 },
  h_wizard = { [5] = 1, [6] = 2, [9] = 3, [10] = 3 },
  h_witch = { [5] = 1, [6] = 1, [9] = 3, [10] = 2 },
}
function CAFE.drawHat(id, x, y, look)
  local t = CAFE.HATLIFT[id]
  CAFE.WEAR[id](x, y - ((t and t[look]) or 0))
end

function CAFE.pickWear(look)
  if CAFE.hatIds == nil then
    CAFE.hatIds, CAFE.glassIds = {}, {}
    for _, id in ipairs(CAFE.WEARIDS) do
      if string.sub(id, 1, 2) == "g_" then CAFE.glassIds[#CAFE.glassIds + 1] = id else CAFE.hatIds[#CAFE.hatIds + 1] = id end
    end
  end
  local hat, glass
  if look ~= 2 and look ~= 4 and look ~= 8 and math.random() < 0.25 then hat = CAFE.hatIds[math.random(#CAFE.hatIds)] end    -- (not on top of a hat they already have)
  if look ~= 3 and math.random() < 0.22 then glass = CAFE.glassIds[math.random(#CAFE.glassIds)] end
  return hat, glass
end

function CAFE.drawWorn(x, y, look)                    -- whatever the barista has on (hat and glasses)
  local d = CAFE.dec()
  if d == nil then return end
  local glasses = false
  for i = 1, #CAFE.WEARIDS do
    local id = CAFE.WEARIDS[i]
    if d.decor[id] == "on" then
      if string.sub(id, 1, 2) == "g_" then CAFE.WEAR[id](x, y + UI.eyeRow(look, true)); glasses = true      -- (glasses go right over the eyes)
      else CAFE.drawHat(id, x, y, look) end
    end
  end
  gfx.setColor(BLACK)
  return glasses
end

local function drawPlayer()
  local bob = 0
  if G.moving then bob = math.floor(math.sin(G.walk) * 1.5 + 0.5) end
  local px, py = math.floor(G.px), math.floor(PLAYER_Y + bob)
  local dec = CAFE.dec()
  if dec and G.mode == "cafe" then
    local gl = false                                   -- glasses sit over the eyes, so the mouth drops a pixel
    for i = 1, #CAFE.WEARIDS do
      local id = CAFE.WEARIDS[i]
      if dec.decor[id] == "on" and string.sub(id, 1, 2) == "g_" then gl = true end
    end
    UI.glasses = gl
    local hatOn = false
    for i = 1, #CAFE.WEARIDS do
      local id = CAFE.WEARIDS[i]
      if dec.decor[id] == "on" and string.sub(id, 1, 2) == "h_" then hatOn = true end
    end
    UI.noBow = hatOn or dec.nobow == true               -- the bow hides under a hat, or when you've turned it off
    local blook = UI.BARISTA[dec.char or 1] or 5
    drawPerson(px, py, blook, false)
    UI.glasses = false; UI.noBow = false
    CAFE.drawWorn(px, py, blook)
  else
    drawPerson(G.px, PLAYER_Y + bob, 5, false)
  end
  local n = G.cups and G.cups.hand or 0
  if n > 0 then                               -- clean cups held up in hand
    local x0 = math.floor(G.px) + 16               -- carried beside the barista
    for i = 1, n do drawCup(x0 + (i - 1) * 12, PLAYER_Y + 7 + bob, 1, false) end
  end
end

----------------------------------------------------------------------
-- Drawing: station panels (they pop up over the customer area)
----------------------------------------------------------------------
local function drawPanelFrame(c, title, text)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(6, 116, 388, 122, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(6, 116, 388, 122, 8)
  gfx.setLineWidth(1)
  gfx.fillRect(10, 120, 380, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(title, 14, 121, true)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(title)
  if c then
    local x0 = 14 + tw + 12
    local str = text or orderShort(c.order)
    local room = (UI.noWait() and 384 or 340) - x0                 -- (the patience meter sits at the right end of the bar: the words stop before it)
    gfx.setFont(fontNormal)
    if gfx.getTextSize(str) > room then str = str:gsub(", ", ",") end                    -- a long order: squeeze the gaps...
    if gfx.getTextSize(str) > room then str = str:gsub("Pumpkin Spice", "Pumpkin") end   -- ...then the drink's name...
    if gfx.getTextSize(str) > room then str = str:gsub(" shots?", "sh"):gsub(" milk", "mk"):gsub(" sugar", "sg") end   -- ...then the other words
    if gfx.getTextSize(str) > room then str = CAFE.fitOne(str, room, false) end            -- (never under the meter)
    drawT(str, x0, 121)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    if not UI.noWait() then drawPatience(346, 126, c.patience, 42, true) end
  else
    if G.st == "dishes" then
      drawTR("Dirty: " .. G.cups.dirty .. "     In hand: " .. G.cups.hand, 384, 121, true)
    else
      drawTR("In hand: " .. G.cups.hand, 384, 121, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
end

-- ---- the station screens (new look): little helpers first
function UI.textMid(word, cx, midY)               -- a bold word whose letters' own middle lands exactly on (cx, midY): the same measuring the placement bubbles use
  local m = CAFE.bubbleMeasure(word)
  gfx.setFont(fontBold)
  gfx.drawText(word, math.floor(cx - m.dx + 0.5), math.floor(midY - m.dy + 0.5))
end
function UI.pic(rows, x, y, k, inv)               -- draw a text picture (k = black, w = white); k = how many pixels each dot is
  k = k or 1
  for j, r in ipairs(rows) do
    local i = 1
    while i <= #r do
      local ch = r:sub(i, i)
      if ch == "k" or ch == "w" then
        local n = 1
        while r:sub(i + n, i + n) == ch do n = n + 1 end
        local black = (ch == "k")
        if inv then black = not black end
        gfx.setColor(black and BLACK or WHITE)
        gfx.fillRect(x + (i - 1) * k, y + (j - 1) * k, n * k, k)
        i = i + n
      else i = i + 1 end
    end
  end
  gfx.setColor(BLACK)
end

function UI.icon(kind, x, y, inv)                                         -- little drawn icons, 12x12; inv = white on black
  local fg, bg = BLACK, WHITE
  if inv then fg, bg = WHITE, BLACK end
  gfx.setColor(fg)
  if kind == "bean" then
    gfx.fillEllipseInRect(x, y + 1, 12, 10)
    gfx.setColor(bg); gfx.setLineWidth(2); gfx.drawLine(x + 3, y + 9, x + 6, y + 6); gfx.drawLine(x + 6, y + 6, x + 9, y + 3); gfx.setLineWidth(1)
  elseif kind == "decaf" then
    gfx.setLineWidth(2); gfx.drawEllipseInRect(x + 1, y + 2, 10, 8); gfx.setLineWidth(1)
    gfx.drawLine(x + 3, y + 8, x + 6, y + 6); gfx.drawLine(x + 6, y + 6, x + 9, y + 4)
  elseif kind == "tea" then
    gfx.fillPolygon(x + 1, y + 11, x + 1, y + 5, x + 6, y + 1, x + 11, y + 1, x + 11, y + 6, x + 6, y + 11)
    gfx.setColor(bg); gfx.drawLine(x + 2, y + 10, x + 9, y + 3); gfx.setColor(fg)
  elseif kind == "matcha" then
    gfx.fillRoundRect(x, y + 5, 12, 7, 3)
    gfx.setColor(bg); gfx.drawLine(x + 2, y + 7, x + 9, y + 7); gfx.setColor(fg)
    gfx.drawLine(x + 7, y + 4, x + 10, y); gfx.drawLine(x + 8, y + 4, x + 11, y + 1); gfx.drawLine(x + 5, y + 4, x + 8, y)   -- the whisk
  elseif kind == "pumpkin" then                       -- a little pumpkin
    gfx.fillEllipseInRect(x, y + 3, 12, 9)
    gfx.fillRect(x + 5, y, 2, 4)
    gfx.setColor(bg); gfx.drawLine(x + 4, y + 5, x + 4, y + 10); gfx.drawLine(x + 8, y + 5, x + 8, y + 10); gfx.setColor(fg)
  elseif kind == "cocoa" then                         -- a mug with steam
    gfx.fillRoundRect(x, y + 4, 9, 8, 2)
    gfx.drawCircleAtPoint(x + 10, y + 8, 2)
    gfx.drawLine(x + 3, y, x + 4, y + 2); gfx.drawLine(x + 6, y, x + 7, y + 2)
  elseif kind == "shot" then
    gfx.fillPolygon(x + 2, y, x + 10, y, x + 9, y + 11, x + 3, y + 11)
    gfx.setColor(bg); gfx.fillRect(x + 4, y + 2, 4, 3); gfx.setColor(fg)
  elseif kind == "milk" then
    gfx.fillRect(x + 2, y + 4, 8, 8)
    gfx.fillTriangle(x + 2, y + 4, x + 10, y + 4, x + 6, y)
    gfx.setColor(bg); gfx.fillRect(x + 4, y + 7, 4, 3); gfx.drawLine(x + 5, y + 3, x + 7, y + 3); gfx.setColor(fg)
  elseif kind == "sugar" then
    gfx.fillRect(x + 1, y + 2, 10, 9)
    gfx.setColor(bg); gfx.fillRect(x + 3, y + 4, 2, 2); gfx.fillRect(x + 7, y + 4, 2, 2); gfx.fillRect(x + 5, y + 7, 2, 2); gfx.setColor(fg)
  elseif kind == "ice" then
    gfx.setLineWidth(2); gfx.drawRect(x + 1, y + 1, 10, 10); gfx.setLineWidth(1)
    gfx.drawLine(x + 3, y + 4, x + 5, y + 4); gfx.drawLine(x + 3, y + 4, x + 3, y + 7)
  end
  gfx.setColor(BLACK)
end
UI.DIG = { ["0"] = { "###", "#.#", "#.#", "#.#", "###" }, ["1"] = { ".#.", "##.", ".#.", ".#.", "###" }, ["2"] = { "###", "..#", "###", "#..", "###" },
  ["3"] = { "###", "..#", "###", "..#", "###" }, ["4"] = { "#.#", "#.#", "###", "..#", "..#" }, ["5"] = { "###", "#..", "###", "..#", "###" },
  ["6"] = { "###", "#..", "###", "#.#", "###" }, ["7"] = { "###", "..#", ".#.", ".#.", ".#." }, ["8"] = { "###", "#.#", "###", "#.#", "###" },
  ["9"] = { "###", "#.#", "###", "..#", "###" }, ["."] = { ".", ".", ".", ".", "#" } }
function UI.bigWidth(s, k) local w = 0; for ch in s:gmatch(".") do w = w + (#UI.DIG[ch][1] + 1) * k end return w - k end
function UI.bigNum(s, rx, y, k, inv)                  -- chunky pixel digits, right edge at rx
  local x = rx - UI.bigWidth(s, k) + 1
  gfx.setColor(inv and WHITE or BLACK)
  for ch in s:gmatch(".") do
    local g = UI.DIG[ch]
    for j, row in ipairs(g) do
      for i = 1, #row do
        if row:sub(i, i) == "#" then gfx.fillRect(x + (i - 1) * k, y + (j - 1) * k, k, k) end
      end
    end
    x = x + (#g[1] + 1) * k
  end
  gfx.setColor(BLACK)
end

function UI.textW(s, bold) gfx.setFont(bold and fontBold or fontNormal); return (gfx.getTextSize(s)) end
-- Round shapes for the little icons, built pixel by pixel round the centre pixel so they come out perfectly even:
-- every pixel whose distance from the centre is between rin and rout (and, for an arc, whose angle lies between a0 and a1,
-- measured clockwise on screen from "3 o'clock"). The pixel runs are worked out once and kept.
UI.ringCache = {}
function UI.ringRuns(rin, rout, a0, a1)
  local key = rin .. "/" .. rout .. "/" .. (a0 or "") .. "/" .. (a1 or "")
  local runs = UI.ringCache[key]
  if runs then return runs end
  runs = {}
  local lim = math.ceil(rout)
  local i2, o2 = rin * rin, rout * rout
  for dy = -lim, lim do
    local x0
    for dx = -lim, lim + 1 do
      local on = false
      if dx <= lim then
        local d2 = dx * dx + dy * dy
        if d2 >= i2 and d2 <= o2 then
          on = true
          if a0 then
            local deg = math.deg(math.atan(dy, dx)) % 360
            on = deg >= a0 and deg <= a1
          end
        end
      end
      if on then
        if not x0 then x0 = dx end
      elseif x0 then
        runs[#runs + 1] = { x0, dy, dx - x0 }
        x0 = nil
      end
    end
  end
  UI.ringCache[key] = runs
  return runs
end

function UI.ringDraw(x, y, rin, rout, a0, a1)
  local runs = UI.ringRuns(rin, rout, a0, a1)
  for i = 1, #runs do
    local r = runs[i]
    gfx.fillRect(x + r[1], y + r[2], r[3], 1)
  end
end

function UI.disc(x, y, r) UI.ringDraw(x, y, 0, r) end

function UI.thickLine(x0, y0, x1, y1, r)                                   -- a line with round ends, `r` being the radius of its pen
  local n = math.max(1, math.floor(math.sqrt((x1 - x0) ^ 2 + (y1 - y0) ^ 2) + 0.5))
  for k = 0, n do
    UI.disc(math.floor(x0 + (x1 - x0) * k / n + 0.5), math.floor(y0 + (y1 - y0) * k / n + 0.5), r)
  end
end

-- the turn-arrow ring both icons sit in: a bold circle open on the right, an arrowhead at its end pointing clockwise
-- (ri and ro are the innermost and outermost pixel of the ring along the compass points)
function UI.turnRing(x, y, ri, ro, head)
  local a0, a1 = 40, 312
  UI.ringDraw(x, y, ri - 0.5, ro + 0.5, a0, a1)
  local R = (ri + ro) / 2
  local ea = math.rad(a1 - 3)                                               -- arrowhead: base across the ring, tip following the curve
  local ta = ea + (head * 1.35) / R
  local function P(ang, r) return math.floor(x + math.cos(ang) * r + 0.5), math.floor(y + math.sin(ang) * r + 0.5) end
  local bx0, by0 = P(ea, R + head * 0.62)
  local bx1, by1 = P(ea, R - head * 0.62)
  local tx, ty = P(ta, R)
  gfx.fillTriangle(bx0, by0, bx1, by1, tx, ty)
end

function UI.crankIcon(x, y, ang, s)                                     -- the crank: arm and handle turning inside a clockwise arrow
  s = s or 1
  gfx.setColor(BLACK)
  local small = s < 0.8
  if small then UI.turnRing(x, y, 10, 12, 4.5) else UI.turnRing(x, y, 22, 25, 8) end
  local a = math.rad(ang)
  local arm = small and 5 or 12
  local hx, hy = math.floor(x + math.cos(a) * arm + 0.5), math.floor(y + math.sin(a) * arm + 0.5)
  UI.thickLine(x, y, hx, hy, small and 1.0 or 2.0)                           -- the arm
  UI.disc(x, y, small and 1.5 or 3.6)                                        -- the hub
  UI.disc(hx, hy, small and 2.6 or 5.2)                                      -- the handle (with a hole in the big one)
  if not small then
    gfx.setColor(WHITE)
    UI.disc(hx, hy, 1.9)
    gfx.setColor(BLACK)
  end
end

-- a d-pad with a picture beside each word (the pad itself is the game's own)
UI.ICONINK = { bean = "coffee", decaf = "decaf", tea = "tea", matcha = "matcha", pumpkin = "pspice", cocoa = "cocoa",
               shot = "coffee", milk = "inkblue", sugar = "inkpink", ice = "inkteal" }      -- (PC: the colour of each choice)
function UI.padWords(pxx, pyy, words, icons, on)
  UI.ink("slate")
  UI.drawSmallPad(pxx, pyy, {}, on)
  UI.ink("none")
  local function group(side, txt, icon, cx, ty, lit)
    local tw = UI.textW(txt, true)
    local gw = 15 + tw
    local x0
    if side == "up" or side == "down" then x0 = cx - math.floor(gw / (2))
    elseif side == "left" then x0 = cx - gw
    else x0 = cx end
    UI.ink(UI.ICONINK[icon])
    if lit then
      gfx.setColor(BLACK); gfx.fillRoundRect(x0 - 4, ty - 2, gw + 8, 18, 4)
    end
    UI.icon(icon, x0, ty + 2, lit)
    gfx.setFont(fontBold)
    if lit then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) end
    drawT(txt, x0 + 15, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.ink("none")
    gfx.setColor(BLACK)
  end
  group("up", words.up, icons.up, pxx, pyy - 47, on == "up")
  group("down", words.down, icons.down, pxx, pyy + 29, on == "down")
  group("left", words.left, icons.left, pxx - 44, pyy - 9, on == "left")
  group("right", words.right, icons.right, pxx + 44, pyy - 9, on == "right")
end

function UI.steam(x, y, n, len, phase)
  UI.inkPush("gray")
  gfx.setColor(BLACK)
  for i = 1, n do
    local sx = x + (i - (n + 1) / 2) * 9
    local px, py
    for yy = y, y - len, -3 do
      local xx = sx + math.floor(math.sin(frames * 0.18 + yy * 0.45 + i * 1.7 + (phase or 0)) * 2.2 + 0.5)
      if px then gfx.drawLine(px, py, xx, yy) end
      px, py = xx, yy
    end
  end
  UI.inkPop()
end
-- a chunky mug (flat top, handle on the right); `pat` fills the drink inside (nil = empty)
function UI.mug(cx, top, w, h, pat, handle, fillTo)
  local x = cx - math.floor(w / (2))
  UI.inkPush("mugc")
  if handle then
    gfx.setColor(BLACK); gfx.setLineWidth(4)
    gfx.drawCircleAtPoint(x + w + 2, top + math.floor(h / (2)) - 1, math.floor(h / (4)) + 2)
    gfx.setLineWidth(1)
  end
  gfx.setColor(BLACK); gfx.fillRoundRect(x, top, w, h, 8)
  gfx.setColor(WHITE); gfx.fillRoundRect(x + 3, top + 3, w - 6, h - 6, 6)
  gfx.setColor(BLACK); gfx.fillRect(x - 1, top, w + 2, 4)                       -- the rim
  if pat then
    UI.ink("none")
    local dTop = fillTo or (top + 8)
    gfx.setPattern(pat); gfx.fillRoundRect(x + 5, dTop, w - 10, top + h - 5 - dTop, 4); gfx.setColor(BLACK)
    gfx.setColor(WHITE); gfx.fillRect(x + 8, dTop + 4, 2, top + h - dTop - 14); gfx.setColor(BLACK)      -- a shine on the glass
  end
  UI.inkPop()
end
function UI.saucer(cx, y, w)
  UI.inkPush("mugc")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - math.floor(w / (2)), y, w, 6, 3)
  gfx.setColor(WHITE); gfx.drawLine(cx - math.floor(w / (2)) + 5, y + 2, cx + math.floor(w / (2)) - 6, y + 2); gfx.setColor(BLACK)
  UI.inkPop()
end
function UI.plaque(cx, y, w, txt)                                        -- a little name plate
  w = math.max(w, UI.textW(txt, true) + 22)
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - math.floor(w / (2)), y, w, 17, 5)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid(txt, cx, y + 8.5, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end
function UI.tiltIcon(x, y, ang)                                         -- a plain "rotate" symbol: a turn-arrow round a tilting bar
  gfx.setColor(BLACK)
  UI.turnRing(x, y, 22, 25, 8)
  local a = math.rad(ang)                                                   -- the bar tips over as you tilt
  local bx, by = math.cos(a) * 11, math.sin(a) * 11
  UI.thickLine(math.floor(x - bx + 0.5), math.floor(y - by + 0.5), math.floor(x + bx + 0.5), math.floor(y + by + 0.5), 3.4)
  gfx.setColor(WHITE)
  UI.disc(x, y, 1.9)                                                        -- a pivot dot in the middle of the bar
  gfx.setColor(BLACK)
end

function UI.patCircle(cx, cy, r, pat)                                    -- a filled circle in a pattern (row by row)
  gfx.setPattern(pat)
  for dy = -r, r do
    local dx = math.floor(math.sqrt(r * r - dy * dy) + 0.5)
    gfx.fillRect(cx - dx, cy + dy, 2 * dx + 1, 1)
  end
  gfx.setColor(BLACK)
end

local function drawRegister(c)
  local r = c.reg
  drawPanelFrame(c, "REGISTER")
  local x0, y0, kw, kh = 248, 144, 46, 23
  for i = 1, 12 do
    local col, row = (i - 1) % 3, math.floor((i - 1) / (3))
    local kx, ky = x0 + col * kw, y0 + row * kh
    local sel = (r.state == "type" and r.cur == i)
    local label = KEYS[i]
    UI.ink((label == "DEL") and "rred" or ((label == "ENT") and "rsage" or "cushion"))     -- (PC: coloured keys)
    if sel then
      gfx.setColor(BLACK); gfx.fillRoundRect(kx + 2, ky + 3, kw - 5, kh - 5, 5)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      if label == "ENT" then
        gfx.setColor(WHITE); gfx.setLineWidth(2)
        gfx.drawLine(kx + math.floor(kw / (2)) - 8, ky + 12, kx + math.floor(kw / (2)) - 4, ky + 16); gfx.drawLine(kx + math.floor(kw / (2)) - 4, ky + 16, kx + math.floor(kw / (2)) + 7, ky + 7)
        gfx.setLineWidth(1); gfx.setColor(BLACK)
      else
        UI.textMid(label, kx + kw / 2 - 0.5, ky + 12, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(WHITE); gfx.drawRoundRect(kx + 4, ky + 5, kw - 9, kh - 9, 3)
      gfx.setColor(BLACK)
    else
      gfx.setColor(BLACK); gfx.fillRoundRect(kx + 2, ky + 3, kw - 5, kh - 5, 5)
      gfx.setColor(WHITE); gfx.fillRoundRect(kx + 2, ky + 1, kw - 5, kh - 6, 5)
      gfx.setColor(BLACK); gfx.drawRoundRect(kx + 2, ky + 1, kw - 5, kh - 6, 5)
      if label == "ENT" then
        gfx.setPattern(CHECK); gfx.fillRoundRect(kx + 4, ky + 3, kw - 9, kh - 10, 3); gfx.setColor(BLACK)
        gfx.setLineWidth(2); gfx.drawLine(kx + math.floor(kw / (2)) - 8, ky + 10, kx + math.floor(kw / (2)) - 4, ky + 14); gfx.drawLine(kx + math.floor(kw / (2)) - 4, ky + 14, kx + math.floor(kw / (2)) + 7, ky + 5); gfx.setLineWidth(1)
      else
        UI.textMid(label, kx + kw / 2 - 0.5, ky + 9.5, true)
      end
    end
  end
  -- the till's glass
  UI.ink("lcd")
  gfx.setColor(BLACK); gfx.fillRoundRect(14, 142, 224, 49, 9)
  gfx.setColor(WHITE); gfx.fillRoundRect(19, 147, 214, 39, 6)
  local paid = (r.state ~= "type")
  if not paid then
    drawT("CHARGE", 26, 150, true)
    drawT("$", 104, 150, true)
    UI.bigNum((money(c.price):gsub("%$", "")), 224, 148, 3)
    gfx.setColor(BLACK); for x = 24, 226, 4 do gfx.drawPixel(x, 167) end
    drawT("TYPE", 26, 171, true)
    drawT("$", 104, 171, true)
    if r.flash > 0 then
      if (math.floor(frames / (4))) % 2 == 0 then
        gfx.setColor(BLACK); gfx.fillRoundRect(98, 169, 130, 16, 4)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid("WRONG! Try again", 163, 177, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
      end
    else
      UI.bigNum((money(tonumber(r.digits) or 0):gsub("%$", "")), 224, 169, 3)
      if (math.floor(frames / (8))) % 2 == 0 then gfx.setColor(BLACK); gfx.fillRect(227, 169, 2, 15) end
    end
  else
    local gw = UI.textW("Correct!", true) + 22
    local gx = 126 - math.floor(gw / (2))
    gfx.setColor(BLACK); gfx.setLineWidth(3)
    gfx.drawLine(gx, 158, gx + 5, 163); gfx.drawLine(gx + 5, 163, gx + 14, 151); gfx.setLineWidth(1)
    drawT("Correct!", gx + 22, 151, true)
    drawTC("Crank to print!", 126, 167, false)
  end
  -- the receipt mouth
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.fillRoundRect(14, 194, 224, 11, 4)
  gfx.setColor(WHITE); gfx.fillRect(26, 198, 200, 2)
  UI.ink("white")
  local px0, px1 = 66, 186
  local maxH = 35
  local h = paid and math.floor(clamp(r.crank / 360, 0, 1) * maxH) or 4          -- a corner of paper peeks out while you type
  if h > 0 then
    gfx.setColor(WHITE); gfx.fillRect(px0, 199, px1 - px0, h)
    gfx.setColor(BLACK); gfx.drawLine(px0, 198, px0, 198 + h); gfx.drawLine(px1, 198, px1, 198 + h)
    if paid then
      for i = 0, 14 do                                                                  -- the torn end
        local zx = px0 + i * 8
        gfx.drawLine(zx, 198 + h, zx + 4, 198 + h - 3); gfx.drawLine(zx + 4, 198 + h - 3, zx + 8, 198 + h)
      end
      local ly, widths = 205, { 78, 50, 64 }
      for i = 1, 3 do
        if ly + 5 < 198 + h then gfx.drawLine(px0 + 10, ly, px0 + 10 + widths[i], ly); gfx.drawLine(px0 + 10, ly + 1, px0 + 10 + widths[i], ly + 1) end
        ly = ly + 5
      end
      if h >= maxH - 2 then UI.ink("inkred"); UI.pic({ ".kk.kk.", "kkkkkkk", "kkkkkkk", ".kkkkk.", "..kkk..", "...k..." }, 123, 220, 1); UI.ink("white") end
    else
      gfx.drawLine(px0, 198 + h, px1, 198 + h)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  if paid then UI.crankIcon(37, 220, frames * 18, 0.55) end
end


function UI.sunA(x, y)                          -- the A button: a ring round the A with little rays, like a sun
  UI.inkPush("flame")
  local pulse = (math.floor(frames / (6))) % 2
  if UI.color then                              -- (PC: the space bar does it, so a little space bar key sits in the middle)
    local down = (math.floor(frames / (12))) % 4 == 0                              -- the key bobs down now and then, as if pressed
    local ky = y - 6 + (down and 1 or 0)
    UI.ink("slate")
    gfx.setColor(BLACK); gfx.fillRoundRect(x - 15, y - 6 + 2, 30, 14, 4)          -- the key's side
    UI.ink("white")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 14, ky, 28, 11, 3)                  -- its top
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 15, ky - 1, 30, 13, 4)
    UI.ink("slate")
    gfx.drawLine(x - 7, ky + 4, x - 7, ky + 6); gfx.drawLine(x - 7, ky + 6, x + 7, ky + 6); gfx.drawLine(x + 7, ky + 6, x + 7, ky + 4)   -- the space sign
    UI.ink("flame")
    for i = 0, 11 do
      local ang = math.rad(i * 30 + (pulse == 0 and 0 or 7))
      local r0, r1 = 19, (i % 2 == 0) and 25 or 23
      if pulse == 1 then r1 = r1 - 1 end
      gfx.drawLine(math.floor(x + math.cos(ang) * r0 + 0.5), math.floor(y + math.sin(ang) * r0 * 0.75 + 0.5),
                   math.floor(x + math.cos(ang) * r1 + 0.5), math.floor(y + math.sin(ang) * r1 * 0.75 + 0.5))
    end
    UI.inkPop()
    return
  end
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, 12)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, 12)
  gfx.setLineWidth(1)
  for i = 0, 11 do
    local ang = math.rad(i * 30 + (pulse == 0 and 0 or 7))
    local r0, r1 = 16, (i % 2 == 0) and 22 or 20
    if pulse == 1 then r1 = r1 - 1 end
    gfx.drawLine(math.floor(x + math.cos(ang) * r0 + 0.5), math.floor(y + math.sin(ang) * r0 + 0.5),
                 math.floor(x + math.cos(ang) * r1 + 0.5), math.floor(y + math.sin(ang) * r1 + 0.5))
  end
  drawTC("A", x, y - 8, true)
  UI.inkPop()
end

-- A small d-pad with the words around it (up above, down below, left and right
-- beside it). `on` = "up" / "down" / "left" / "right" boxes that word.
function UI.drawSmallPad(px, py, words, on)
  local function fillArm(x, y, w, h, lit)
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x, y, w, h, 3)
    if lit then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x + 3, y + 3, w - 6, h - 6, 2)
      gfx.setColor(BLACK)
    end
  end
  gfx.setColor(BLACK)
  gfx.fillRect(px - 13, py - 9, 26, 18)                           -- centre
  fillArm(px - 13, py - 27, 26, 18, on == "up")
  fillArm(px - 13, py + 9, 26, 18, on == "down")
  fillArm(px - 39, py - 9, 26, 18, on == "left")
  fillArm(px + 13, py - 9, 26, 18, on == "right")
  gfx.fillRect(px - 13, py - 18, 26, 36)
  gfx.fillRect(px - 26, py - 9, 52, 18)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(px, py, 3)
  local function arrow(x1, y1, x2, y2, x3, y3, lit)
    gfx.setColor(lit and BLACK or WHITE)
    gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  end
  arrow(px, py - 25, px - 5, py - 18, px + 5, py - 18, on == "up")
  arrow(px, py + 25, px - 5, py + 18, px + 5, py + 18, on == "down")
  arrow(px - 36, py, px - 29, py - 5, px - 29, py + 5, on == "left")
  arrow(px + 36, py, px + 29, py - 5, px + 29, py + 5, on == "right")
  gfx.setColor(BLACK)
  -- the words
  local function word(txt, x, ty, align, lit)
    gfx.setFont(fontBold)
    local tw = gfx.getTextSize(txt)
    local left = x - math.floor(tw / (2))                      -- centred
    if align == "left" then left = x elseif align == "right" then left = x - tw end
    if lit then
      gfx.setColor(BLACK)
      gfx.fillRoundRect(left - 4, ty - 1, tw + 8, 17, 4)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawT(txt, left, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end
  if words.up then word(words.up, px + (words.upDx or 0), py - 46, "center", on == "up") end
  if words.down then word(words.down, px, py + 30, "center", on == "down") end
  if words.left then word(words.left, px - 45, py - 8, "right", on == "left") end
  if words.right then word(words.right, px + 45, py - 8, "left", on == "right") end
end

UI.PICK_KEY_SIDE = { coffee = "up", decaf = "down", tea = "left", matcha = "right" }

local function drawCoffee(c)
  local f = c.cof
  drawPanelFrame(c, "COFFEE")
  if f.phase == "pick" then
    local sp = UI.SPECIAL[UI.season() or ""]                                          -- (the matcha button is the season's drink while its music is on)
    UI.padWords(112, 189, { up = "COFFEE", down = "DECAF", left = "TEA", right = sp and sp.word or "MATCHA" },
      { up = "bean", down = "decaf", left = "tea", right = sp and sp.icon or "matcha" }, f.pick and UI.PICK_KEY_SIDE[f.pick] or nil)
    UI.sunA(272, 178)
    drawTC("POUR", 272, 206, true)
    local mx = 345                                                                    -- the cup that shows what you picked
    if f.pick then UI.steam(mx, 164, 3, 14) end
    UI.mug(mx, 168, 46, 40, f.pick and DRINK_PATTERN[f.pick] or nil, true)
    UI.saucer(mx - 2, 208, 66)
    UI.plaque(mx - 2, 218, 84, f.pick and ((f.pick == "matcha" and sp) and sp.word or string.upper(f.pick)) or "PICK ONE")
    return
  end
  -- ---- pouring (the same picture for tilt and for crank; only the control on the left and the gauge differ) ----
  local crank = (UI.crankPour == true)
  local mcx = 270
  local top, bot = 168, 225
  local inTop, inBot = 173, 221
  local surface = inBot - math.floor(f.fill * (inBot - inTop))
  if surface < inTop then surface = inTop end
  local flow = f.tilt or 0
  -- left: what to do
  if crank then
    drawT("Crank to pour.", 16, 144, true)
    drawT("Back to stop.", 16, 160)
    UI.crankIcon(40, 206, (f.valve or 0) * 180 + 25, 1)
  else
    drawT("Tilt Playdate", 16, 144, true)
    drawT("down to pour.", 16, 160, true)
    UI.tiltIcon(40, 206, 8 + 40 * flow)
  end
  -- the coffee machine head with its dial, buttons and spout
  UI.ink("inkred")
  gfx.setColor(BLACK); gfx.fillRoundRect(mcx - 30, 140, 60, 15, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(mcx - 19, 148, 5)
  gfx.setColor(BLACK); gfx.setLineWidth(2)
  local na = math.rad(200 + 140 * flow)
  gfx.drawLine(mcx - 19, 148, math.floor(mcx - 19 + math.cos(na) * 4 + 0.5), math.floor(148 + math.sin(na) * 4 + 0.5)); gfx.setLineWidth(1)
  gfx.setColor(WHITE); gfx.fillRect(mcx + 0, 144, 16, 2); gfx.fillRect(mcx + 0, 148, 10, 2); gfx.fillCircleAtPoint(mcx + 22, 148, 2)
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.fillRect(mcx - 8, 155, 16, 5); gfx.fillRect(mcx - 3, 160, 6, 3)
  if flow <= 0 and f.fill > 0.05 and (math.floor(frames / (10))) % 2 == 0 then gfx.fillRect(mcx - 1, 165 + math.floor((frames % 10) / (3)), 2, 3) end   -- a last drip
  -- the drip tray and the mug
  UI.ink("gray")
  gfx.setColor(BLACK); gfx.fillRoundRect(mcx - 46, 226, 92, 8, 3)
  gfx.setColor(WHITE); for dx = -38, 34, 8 do gfx.fillRect(mcx + dx, 229, 4, 2) end
  local x = mcx - 28
  UI.ink("mugc")
  gfx.setColor(BLACK); gfx.setLineWidth(4); gfx.drawCircleAtPoint(x + 60, 197, 13); gfx.setLineWidth(1)
  gfx.fillRoundRect(x, top, 56, bot - top, 9)
  gfx.setColor(WHITE); gfx.fillRoundRect(x + 3, top + 3, 50, bot - top - 6, 7)
  gfx.setColor(BLACK); gfx.fillRect(x - 1, top, 58, 4)
  UI.ink("none")
  -- the drink
  gfx.setColor(BLACK)
  if f.pick == "matcha" then gfx.setPattern(DRINK_PATTERN.matcha) elseif f.pick == "decaf" then gfx.setPattern(STRIPE) elseif f.pick == "tea" then gfx.setPattern(DRINK_PATTERN.tea) else gfx.setPattern(DRINK_PATTERN.coffee) end
  local amp = f.amp or 0.3
  for dx = x + 5, x + 50 do
    local near = 1 / (1 + ((dx - mcx) / 14) ^ 2)
    local y = surface + math.floor(math.sin(dx * 0.45 + frames * 0.4) * amp * (0.45 + 0.9 * near) + 0.5)
    if y < inTop then y = inTop end
    if y <= inBot then gfx.fillRect(dx, y, 1, inBot - y + 1) end
  end
  gfx.setColor(BLACK)
  for _, q in ipairs(f.drops or {}) do gfx.fillRect(math.floor(q.x) + (mcx - 270), math.floor(q.y), 2, 2) end
  if f.fill > 0.1 then gfx.setColor(WHITE); gfx.fillRect(x + 8, surface + 6, 2, math.max(0, inBot - surface - 12)); gfx.setColor(BLACK) end
  -- the stream (with a white glint when it's wide)
  if flow > 0 and f.fill < 1.25 then
    local sw = (flow > 0.66) and 5 or ((flow > 0.33) and 3 or 1)
    UI.drinkInk(f.pick)
    gfx.setColor(BLACK); gfx.fillRect(mcx - math.floor(sw / (2)), 163, sw, math.max(0, surface - 163))
    if sw >= 5 then gfx.setColor(WHITE); for yy = 164 + (frames * 3) % 8, surface - 3, 8 do gfx.fillRect(mcx, yy, 1, 3) end; gfx.setColor(BLACK) end
    UI.ink("none")
  end
  -- the size marks: the one the order wants is a flag pointing at the mug
  local sz = c.order.size or 3
  UI.ink("inkred")
  for i = 1, 3 do
    local ly = inBot - math.floor(UI.SIZE_FILL[i] * (inBot - inTop))
    gfx.setColor(BLACK)
    if i == sz then
      for dx = x + 5, x + 49, 6 do gfx.drawLine(dx, ly, dx + 3, ly) end
      local label = string.upper(UI.SIZE_NAME[i])
      local fw = UI.textW(label, true) + 12
      gfx.fillRoundRect(x - 11 - fw, ly - 8, fw, 16, 4)
      gfx.fillTriangle(x - 12, ly - 8, x - 12, ly + 8, x - 3, ly)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite); UI.textMid(label, x - 11 - fw / 2, ly, true); gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
    else
      gfx.drawLine(x - 8, ly, x - 2, ly)
    end
  end
  UI.drinkInk(f.pick)                                                                -- (PC: a spill is the drink's colour)
  if f.fill > 1.2 then gfx.fillRect(x - 3, 200, 3, 24); gfx.fillRect(x + 57, 214, 3, 14) end
  UI.ink("none")
  if f.fill > 0.3 then UI.steam(mcx - 21, top - 4, 1, 10); UI.steam(mcx + 21, top - 4, 1, 10, 2) end
  -- the gauge on the right: how far you are tilting, or how far the tap is open
  local gx = 350
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(gx, 160, 24, 68, 5); gfx.setLineWidth(1)
  local lvl = crank and (f.valve or 0) or flow
  local h = math.floor(56 * lvl)
  UI.drinkInk(f.pick)
  gfx.fillRoundRect(gx + 4, 224 - h, 16, h, 2)
  UI.ink("none")
  gfx.setColor(WHITE); for i = 1, 4 do gfx.drawLine(gx + 4, 224 - i * 14, gx + 9, 224 - i * 14) end
  gfx.setColor(BLACK); for i = 1, 4 do gfx.drawLine(gx - 5, 224 - i * 14, gx - 1, 224 - i * 14) end
  if crank then                                                                      -- the tap handle riding on the gauge
    gfx.fillCircleAtPoint(gx + 12, 224 - h, 9)
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(gx + 12, 224 - h, 6); gfx.setColor(BLACK); gfx.fillCircleAtPoint(gx + 12, 224 - h, 3)
  end
end


-- what's still missing from the order (they vanish from the black bar as you add them)
function UI.mixHeader(o, m)
  local items = {}
  local function need(n, one, many)
    if n > 0 then items[#items + 1] = n .. " " .. (n == 1 and one or many) end
  end
  need(o.shot - m.shot, "shot", "shots")
  need(o.milk - m.milk, "milk", "milk")
  need(o.sugar - m.sugar, "sugar", "sugar")
  need(o.ice - m.ice, "ice", "ice")
  if m.phase == 2 then return "Mixing it up!" end
  if #items == 0 then return "Ready to mix!" end
  return table.concat(items, ", ")
end

local function drawMixer(c)
  local m, o = c.mix, c.order
  drawPanelFrame(c, "MIXER", UI.mixHeader(c.order, m))
  local cx, cy = 333, 191
  local a = math.rad(m.angle or 0)
  local mixing = (m.phase == 2)
  local mixed = mixing and m.progress >= 0.6
  -- the saucer, the handle and the cup seen from above
  UI.ink("mugc")
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 44)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 41)
  gfx.setColor(BLACK); gfx.fillRoundRect(cx + 30, cy - 10, 24, 20, 8)
  gfx.setColor(WHITE); gfx.fillRoundRect(cx + 36, cy - 4, 12, 8, 3)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 39)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 36)
  UI.drinkInk(o.kind)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 34)                             -- the drink
  if mixed and m.milk > 0 then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 34); gfx.setColor(BLACK); UI.patCircle(cx, cy, 34, CHECK) end
  gfx.setColor(WHITE)
  -- ingredients ride round the cup; dotted rings show what the order still wants
  local function slot(i, n, R, off, spin)
    local t = a * spin + (i - 1) * (2 * math.pi / math.max(n, 1)) + off
    return math.floor(cx + R * math.cos(t) + 0.5), math.floor(cy + R * math.sin(t) + 0.5)
  end
  local function row(kind, have, want, R, off, spin, draw)
    local n = math.max(have, want)                                  -- (spots stay put as the order's own amount is added)
    for i = 1, math.min(have, n) do
      local px, py = slot(i, n, R, off, spin)
      if not (mixed and kind ~= "ice") then draw(px, py) end
    end
  end
  row("shot", m.shot, o.shot, 11, 2.0, 1.3,
    function(x, y) UI.ink("coffee"); gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 6); gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawLine(x - 3, y + 3, x + 3, y - 3); gfx.setLineWidth(1); gfx.setColor(WHITE) end)
  row("milk", m.milk, o.milk, 22, 0.0, 1.0,
    function(x, y) UI.ink("snow"); gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 7); gfx.setColor(BLACK); gfx.drawLine(x - 4, y - 1, x - 2, y - 4); gfx.drawLine(x - 4, y, x - 3, y - 3); gfx.setColor(WHITE) end)
  row("sugar", m.sugar, o.sugar, 27, 0.5, -0.7,
    function(x, y) UI.ink("white"); gfx.setColor(WHITE); gfx.fillRect(x - 4, y - 4, 9, 9); gfx.setColor(BLACK); gfx.drawPixel(x - 1, y - 1); gfx.drawPixel(x + 1, y + 1); gfx.drawPixel(x - 1, y + 2); gfx.setColor(WHITE) end)
  row("ice", m.ice, o.ice, 17, 1.0, 0.4,
    function(x, y) UI.ink("water"); gfx.setColor(BLACK); gfx.fillRect(x - 5, y - 5, 11, 11); gfx.setColor(WHITE); gfx.setLineWidth(2); gfx.drawRect(x - 5, y - 5, 11, 11); gfx.setLineWidth(1); gfx.drawLine(x - 2, y - 2, x - 2, y + 1); gfx.drawLine(x - 2, y - 2, x + 1, y - 2) end)
  UI.drinkInk(o.kind)
  if mixing and not mixed then                                                       -- a swirl chasing the spoon
    gfx.setColor(WHITE)
    for i = 0, 22 do
      local t = a - i * 0.14
      local rr = 5 + (22 - i) * 1.3
      gfx.drawPixel(math.floor(cx + rr * math.cos(t) + 0.5), math.floor(cy + rr * math.sin(t) + 0.5))
    end
  end
  -- the spoon that turns with the crank
  local ex, ey = math.floor(cx + 29 * math.cos(a) + 0.5), math.floor(cy + 29 * math.sin(a) + 0.5)
  local fx, fy = math.floor(cx - 9 * math.cos(a) + 0.5), math.floor(cy - 9 * math.sin(a) + 0.5)
  UI.ink("gray")
  gfx.setColor(BLACK); gfx.setLineWidth(6); gfx.drawLine(fx, fy, ex, ey); gfx.setLineWidth(1)
  gfx.setColor(WHITE); gfx.setLineWidth(3); gfx.drawLine(fx, fy, ex, ey); gfx.setLineWidth(1)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(ex, ey, 8)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(ex, ey, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(ex, ey, 2)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, 5); gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 2)
  UI.ink("none")
  -- left side
  if m.phase == 1 then
    UI.padWords(112, 189, { up = "SHOT", down = "ICE", left = "MILK", right = "SUGAR" },
      { up = "shot", down = "ice", left = "milk", right = "sugar" }, nil)
    UI.sunA(254, 178)
    drawTC("MIX", 254, 206, true)
  else
    drawT("Crank to mix!", 16, 146, true)
    local pw = 168
    UI.ink("leaf")
    gfx.setColor(BLACK); gfx.fillRoundRect(16, 176, pw, 20, 7)
    gfx.setColor(WHITE); gfx.fillRoundRect(19, 179, pw - 6, 14, 5)
    UI.ink("inkgreen")
    local prog = clamp(m.progress, 0, 1)
    local segs = 14
    for i = 1, segs do
      local sx = 22 + (i - 1) * (math.floor((pw - 12) / (segs)))
      if i <= math.floor(prog * segs + 0.001) then gfx.setColor(BLACK); gfx.fillRoundRect(sx, 182, math.floor((pw - 12) / (segs)) - 2, 8, 2) end
    end
    UI.ink("none")
    gfx.setColor(BLACK)
    drawT("Keep turning!", 16, 204)
    UI.crankIcon(244, 192, frames * 18)
  end
end


local function drawServe(c)
  local s = c.srv
  drawPanelFrame(c, "PICK UP")
  -- the striped awning
  UI.ink("inkred")
  gfx.setClipRect(10, 140, 380, 24)
  for i = 0, 18 do
    local x = 10 + i * 20
    gfx.setColor((i % 2 == 0) and BLACK or WHITE)
    gfx.fillRect(x, 140, 20, 6)
    gfx.fillCircleAtPoint(x + 10, 146, 10)
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + 10, 146, 10)
  end
  gfx.setColor(WHITE); gfx.fillRect(10, 140, 380, 0); gfx.setColor(BLACK)
  gfx.clearClipRect()
  gfx.setColor(BLACK); gfx.fillRect(10, 138, 380, 3)
  UI.ink("none")
  -- words
  if s.phase <= 2 then
    if s.slide < 1 then drawT("Here it comes...", 16, 166, true)
    else drawT("Press A to ring", 16, 166, true); drawT("the bell!", 16, 184, true) end
  else
    drawT("Order up!", 16, 166, true)
  end
  -- the ledge
  UI.ink("woodl")
  gfx.setColor(BLACK); gfx.fillRect(10, 226, 380, 8)
  gfx.setColor(WHITE)
  for x = 12, 386, 6 do gfx.drawPixel(x, 229); gfx.drawPixel(x + 1, 229) end
  UI.ink("none")
  gfx.setColor(BLACK)
  -- the drink slides in along the ledge
  local cx = 52 + math.floor(s.slide * 130)
  if s.phase > 2 then
    -- picked up: the ledge is bare
  elseif c.order.ice > 0 then
    UI.ink("glass")
    gfx.setColor(WHITE); gfx.fillPolygon(cx - 12, 192, cx + 12, 192, cx + 9, 226, cx - 9, 226)
    UI.ink("none")
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"]); gfx.fillPolygon(cx - 11, 200, cx + 11, 200, cx + 9, 225, cx - 9, 225)
    UI.ink("snow")
    gfx.setColor(WHITE)
    for _, q in ipairs({ { -7, 202 }, { 1, 206 }, { -5, 214 }, { 2, 218 } }) do gfx.fillRect(cx + q[1], q[2], 7, 7) end
    gfx.setColor(BLACK)
    for _, q in ipairs({ { -7, 202 }, { 1, 206 }, { -5, 214 }, { 2, 218 } }) do gfx.drawRect(cx + q[1], q[2], 7, 7) end
    UI.ink("slate")
    gfx.setLineWidth(2); gfx.drawPolygon(cx - 12, 192, cx + 12, 192, cx + 9, 226, cx - 9, 226)
    gfx.fillRect(cx - 14, 190, 28, 3)                                              -- the lid
    UI.ink("inkred")
    gfx.setLineWidth(3); gfx.drawLine(cx + 2, 223, cx + 8, 180); gfx.drawLine(cx + 8, 180, cx + 14, 177); gfx.setLineWidth(1)
    UI.ink("none")
  else
    UI.ink("mugc")
    gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawCircleAtPoint(cx + 16, 211, 6); gfx.setLineWidth(1)
    gfx.fillRoundRect(cx - 13, 197, 26, 29, 4)
    gfx.setColor(WHITE); gfx.fillRoundRect(cx - 11, 199, 22, 25, 3)
    UI.ink("none")
    gfx.setColor(BLACK); gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"]); gfx.fillRect(cx - 9, 204, 18, 18); gfx.setColor(BLACK)
    UI.ink("mugc")
    gfx.fillRect(cx - 14, 197, 28, 4)
    UI.ink("gray")
    UI.steam(cx, 192, 3, 18)
    UI.ink("none")
  end
  gfx.setColor(BLACK)
  -- the A button and the bell
  local bx = 336
  if s.phase == 3 then bx = bx + ((math.floor(frames / (2))) % 2 == 0 and 2 or -2) end
  if s.phase == 2 and s.slide >= 1 then
    UI.sunA(262, 180)
    drawTC("RING", 262, 203, true)
  end
  gfx.setColor(BLACK)
  UI.ink("slate")
  gfx.fillRoundRect(bx - 36, 219, 72, 7, 3)                                         -- the tray
  UI.ink("gold2")
  gfx.setClipRect(0, 0, 400, 219)
  gfx.fillCircleAtPoint(bx, 219, 28)                                                -- the dome
  gfx.clearClipRect()
  gfx.fillRect(bx - 3, 187, 6, 4)                                                    -- the stem
  gfx.fillCircleAtPoint(bx, 185, 5)                                                  -- the button
  gfx.setColor(WHITE)
  gfx.drawLine(bx - 22, 212, bx + 22, 212)                                           -- a band round the dome
  UI.ink("inkwhite")
  if UI.color then gfx.setColor(BLACK) end
  gfx.fillCircleAtPoint(bx - 12, 201, 4); gfx.drawLine(bx - 17, 194, bx - 9, 190)    -- the shine
  UI.ink("none")
  gfx.setColor(BLACK)
  if s.phase == 3 then
    drawTC("DING!", 262, 180, true)
    for i = -2, 2 do
      local ang = math.rad(i * 25 - 90)
      UI.ink("inkorange")
      gfx.drawLine(math.floor(bx + math.cos(ang) * 34), math.floor(219 + math.sin(ang) * 34), math.floor(bx + math.cos(ang) * 46), math.floor(219 + math.sin(ang) * 46))
    end
  end
  UI.ink("none")
end

-- Evening Chill: the dish bin (left) and sink (right)
local function drawDishes()
  local G = G
  local s, cu = G.sink, G.cups
  drawPanelFrame(nil, "DISHES")
  -- the rack: two shelves, up to 6 dirty mugs on show
  UI.ink("woodl")
  gfx.setColor(BLACK)
  for r = 0, 1 do
    local y0 = 163 + r * 24
    gfx.fillRect(14, y0 + 17, 116, 3)
    gfx.fillRect(16, y0 + 20, 3, 4); gfx.fillRect(125, y0 + 20, 3, 4)
  end
  UI.ink("none")
  local E_drawCup = drawCup
  for i = 1, math.min(cu.dirty, 6) do
    local col, row = (i - 1) % 3, math.floor((i - 1) / (3))
    E_drawCup(24 + col * 36, 163 + row * 24, 2, true)
  end
  -- the sink
  local wx = 276
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(158, 178, 222, 36, 9)                                           -- the basin
  UI.ink("snow")
  gfx.setColor(WHITE); gfx.fillRoundRect(163, 182, 212, 28, 6)
  UI.ink("water")
  gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(165, 197, 208, 11); gfx.setColor(BLACK)
  local wave = math.floor(math.sin(frames * 0.3) * 1.5)
  gfx.drawLine(165, 197 + wave, 373, 197 - wave)
  UI.ink("gray")
  gfx.fillRoundRect(152, 171, 234, 7, 3)                                            -- the rim
  UI.ink("slate")
  gfx.fillRect(238, 151, 12, 21)                                                    -- faucet pipe
  gfx.fillRoundRect(238, 142, 48, 12, 6)                                            -- the curve over the sink
  gfx.fillRect(wx - 5, 142, 10, 17)                                                 -- spout
  gfx.fillRect(wx - 7, 156, 14, 5)
  UI.ink("redp")
  gfx.fillCircleAtPoint(180, 164, 5); gfx.fillRect(178, 164, 4, 8)                  -- the two taps (hot and cold)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(180, 164, 2); gfx.setColor(BLACK)
  UI.ink("skyp")
  gfx.fillCircleAtPoint(358, 164, 5); gfx.fillRect(356, 164, 4, 8)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(358, 164, 2); gfx.setColor(BLACK)
  UI.ink("inkblue")
  local flow = (frames * 2) % 8
  for y = 161 + flow - 8, 180, 8 do if y >= 161 then gfx.drawLine(wx, y, wx, math.min(180, y + 4)) end end
  UI.ink("none")
  -- the cup in the sink
  if s.state ~= "empty" then
    local cxx, cyy = wx, 190
    E_drawCup(cxx - 12, cyy - 14, 3, false)
    if s.state == "washing" then
      local h = math.floor(10 * (1 - s.progress))
      UI.ink("coffee")
      if h > 0 then gfx.setPattern(CHECK); gfx.fillRect(cxx - 10, cyy + 8 - h, 20, h); gfx.setColor(BLACK) end
      local a = math.rad(s.angle)
      local sx, sy = math.floor(cxx + 30 * math.cos(a)), math.floor(cyy + 6 + 8 * math.sin(a))
      UI.ink("yellow")
      if UI.color then gfx.setColor(WHITE); gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3); gfx.setColor(BLACK); gfx.drawRoundRect(sx - 8, sy - 5, 16, 10, 3); UI.ink("leaf"); gfx.fillRect(sx - 8, sy + 2, 16, 3)
      else gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3) end                         -- (PC: a yellow sponge with a green scrubber)
      UI.ink("yellow")
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx - 3, sy - 1, 1); gfx.fillCircleAtPoint(sx + 3, sy + 2, 1); gfx.setColor(BLACK)
      UI.ink("inkblue")
      for i = 0, 2 do
        local bxx = cxx - 26 + ((frames * 0.7 + i * 23) % 56)
        gfx.drawCircleAtPoint(math.floor(bxx), cyy - 8 - ((math.floor(frames / (3)) + i * 5) % 12), 2 + i % 2)
      end
    else
      local big = ((math.floor(frames / (3))) % 2 == 0)
      UI.ink("inkyellow")
      for _, o in ipairs({ { -22, -10 }, { 24, -6 }, { -18, 12 }, { 22, 12 } }) do
        local r = big and 5 or 3
        gfx.drawLine(cxx + o[1] - r, cyy + o[2], cxx + o[1] + r, cyy + o[2]); gfx.drawLine(cxx + o[1], cyy + o[2] - r, cxx + o[1], cyy + o[2] + r)
      end
    end
  end
  -- progress as a row of soap bubbles
  local prog = (s.state == "washing") and clamp(s.progress, 0, 1) or ((s.state == "sparkle") and 1 or 0)
  UI.ink("water")
  for i = 1, 6 do
    local bx = 296 + i * 14
    gfx.setColor(BLACK)
    if i <= math.floor(prog * 6 + 0.001) then gfx.fillCircleAtPoint(bx, 148, 5)
    else gfx.drawCircleAtPoint(bx, 148, 5) end
  end
  gfx.setColor(WHITE); gfx.setColor(BLACK)
  UI.ink("none")
  -- the hint strip
  gfx.setColor(BLACK); gfx.setPattern(CHECK); gfx.fillRect(12, 216, 376, 1); gfx.setColor(BLACK)
  if s.state == "empty" then drawTC("All clean!", 200, 219, true)
  elseif s.state == "washing" then drawTC("Crank to scrub!", 200, 219, true)
  else drawTC("Squeaky clean!", 200, 219, true) end
end


-- Evening Chill: the cup shelf on the wall
-- a clean cup for the shelf: round-cornered body, a rim, a shine and a ring handle (x, y = top-left, 26 wide, 24 tall)
function UI.shelfCup(x, y)
  UI.inkPush("mugc")
  gfx.setColor(BLACK)
  UI.ringDraw(x + 27, y + 12, 3.6, 6.2)                                        -- the handle (the body covers its left half)
  gfx.fillRect(x, y, 27, 12)                                                   -- flat top: square corners up here, round ones only at the bottom
  gfx.fillRoundRect(x, y + 4, 27, 20, 7)
  gfx.setColor(WHITE)
  gfx.fillRect(x + 3, y + 3, 21, 9)                                            -- the inside, square at the top as well
  gfx.fillRoundRect(x + 3, y + 8, 21, 13, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 1, y, 29, 3)                                                -- the lip of the rim, a little wider than the cup
  gfx.fillRect(x + 6, y + 8, 3, 8); gfx.setColor(WHITE); gfx.fillRect(x + 7, y + 9, 1, 6); gfx.setColor(BLACK)   -- a little shine
  UI.inkPop()
end

function UI.shelfSlot(x, y)                                                    -- an empty spot on the plank: a dotted cup shape
  UI.inkPush("gray")
  gfx.setColor(BLACK)
  for dx = 3, 23, 4 do gfx.fillRect(x + dx, y, 2, 1); gfx.fillRect(x + dx, y + 23, 2, 1) end
  for dy = 3, 19, 4 do gfx.fillRect(x, y + dy, 1, 2); gfx.fillRect(x + 26, y + dy, 1, 2) end
  UI.inkPop()
end

function UI.plank(x0, x1, y, bare)                                            -- one wooden plank with its two brackets (none when there's a row right below)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x0, y, x1 - x0, 7, 3)
  gfx.setColor(WHITE); gfx.fillRect(x0 + 5, y + 2, x1 - x0 - 10, 1); gfx.setColor(BLACK)
  if bare then UI.ink("none"); return end
  for _, bx in ipairs({ x0 + 14, x1 - 24 }) do
    gfx.fillTriangle(bx, y + 7, bx, y + 18, bx + 10, y + 7)
    gfx.setColor(WHITE); gfx.drawLine(bx + 2, y + 10, bx + 2, y + 14); gfx.setColor(BLACK)
  end
  UI.ink("none")
end

local function drawShelf()
  local cu = G.cups
  drawPanelFrame(nil, "SHELF")
  local two = G.cupMax > 5
  local perRow = two and 5 or math.max(1, G.cupMax)
  local gap = 48
  local x0 = 16 + (two and 0 or math.floor((5 - perRow) * gap / 2))           -- (a short shelf sits in the middle of the wall)
  local lowY = two and 206 or 192                                             -- where the lower plank is
  local plankX0, plankX1 = 12, 262
  if two then UI.plank(plankX0, plankX1, lowY - 38, true) end
  UI.plank(plankX0, plankX1, lowY)
  for i = 0, G.cupMax - 1 do
    local back = two and i >= 5
    local col = back and (i - 5) or i
    local x = 18 + col * gap + (two and 0 or math.floor((5 - perRow) * gap / 2))
    local y = (back and (lowY - 38) or lowY) - 24
    if i < cu.shelf then UI.shelfCup(x, y) else UI.shelfSlot(x, y) end
  end
  -- on the right: how many are up, the cups in hand, and what A does
  local cx = 330
  UI.plaque(cx, 144, 110, string.format("%d of %d cups", cu.shelf, G.cupMax))
  if cu.hand > 0 then
    local n = math.min(cu.hand, 3)                                            -- (the title bar says how many in all)
    local span = n * 36
    for i = 1, n do UI.shelfCup(cx - math.floor(span / (2)) + (i - 1) * 36 + 2, 172) end
    UI.sunA(298, 214)
    drawT("PUT UP", 322, 206, true)
  else
    drawTC("Hold a clean cup", cx, 176, false)
    drawTC("to place it.", cx, 194, false)
  end
  UI.ink("none")
end

local function drawStationPanel()
  if G.st == "dishes" then drawDishes(); UI.ink("none"); return end
  if G.st == "shelf" then drawShelf(); UI.ink("none"); return end
  local c = G.cust
  if c == nil then return end
  if G.st == "register" then drawRegister(c)
  elseif G.st == "coffee" then drawCoffee(c)
  elseif G.st == "mixer" then drawMixer(c)
  elseif G.st == "serve" then drawServe(c) end
  UI.ink("none")                                       -- (PC: nothing a panel painted in carries on to the rest of the screen)
end

----------------------------------------------------------------------
-- Drawing: HUD, popups, messages
----------------------------------------------------------------------
function UI.stopwatch(t)
  local secs = math.floor(t)
  if secs >= 3600 then
    return string.format("%d:%02d:%02d", math.floor(secs / (3600)), math.floor((secs % 3600) / (60)), secs % 60)
  end
  return string.format("%d:%02d", math.floor(secs / (60)), secs % 60)
end

local function drawHUD()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 0, 400, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if G.mode == "cafe" and G.cafe and G.cafe.money then          -- in the Cafe the corner shows everything you have, not just this session
    drawTR(money(G.cafe.money + G.cash + G.tips - (G.banked or 0)), 394, 1, true)
  else
    drawTR(money(G.cash + G.tips), 394, 1, true)
  end
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    drawT(UI.stopwatch(math.max(0, math.ceil(rem))), 6, 1, true)           -- counting down from 1:30
    if rem <= 10 and rem > 0 then               -- closing countdown: 10, 9, 8...
      drawTC("Closing in " .. math.ceil(rem), 200, 1, true)
    end
    if (G.streak or 0) >= 2 then drawT("COMBO x" .. UI.comboTxt(G.streak), 76, 1, true) end         -- what the good orders in a row are worth now
  else
    local tx = (G.mode == "cafe") and UI.hudTimeX or 6
    local ts = UI.stopwatch(G.t)
    drawT(ts, tx, 1, true)           -- how long you've been playing
    gfx.setFont(fontBold)
    UI.hudLeft = tx + gfx.getTextSize(ts)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if G.mode == "cafe" then UI.drawStarBar() end         -- the barista level, the stars, and the meter to the next star
  if UI.hudExtra then UI.hudExtra() end
  if G.mode == "rush" then
    local prog = clamp(G.t / RUSH_SECONDS, 0, 1)
    gfx.setColor(WHITE)
    gfx.fillRect(0, 16, math.floor(400 * prog), 2)
  end
  gfx.setColor(BLACK)
end

function UI.drawPopups()
  for _, p in ipairs(G.popups) do
    local k = p.t / p.life
    local y = math.floor(p.y - 22 * k)
    -- small popups (tips over the jar) use the thin font and tight padding
    local pad = p.small and 3 or 5
    gfx.setFont(p.small and fontNormal or fontBold)
    local w = gfx.getTextSize(p.s)
    local bw = w + pad * 2
    local bx = clamp(p.x - math.floor(bw / (2)), 2, 398 - bw)
    local bh = p.small and 20 or 20
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, y - 2, bw, bh, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(bx, y - 2, bw, bh, 4)
    drawT(p.s, bx + pad, p.small and y + 1 or y, not p.small)
  end
end

function UI.drawMessage()
  if G.msg == nil then return end
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(G.msg)
  local bw = w + 20
  local bx = 200 - math.floor(bw / (2))
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, 188, bw, 22, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, 188, bw, 22, 6)
  gfx.setLineWidth(1)
  drawTC(G.msg, 200, 191, true)
end

local function needsCrank()
  if G.st == "dishes" then return G.sink.state == "washing" end
  local c = G.cust
  if c == nil or G.st == nil then return false end
  if G.st == "register" then return c.reg.state == "crank" end
  if G.st == "coffee" then return UI.crankPour == true and c.cof.phase == "pour" end
  if G.st == "mixer" then return c.mix.phase == 2 end
  return false
end

local function drawPlay()
  CAFE.sceneTop()
  drawPlayer()                                 -- the barista stands behind the counter and the machines
  CAFE.sceneBottom()
  UI.drawDoor()
  if G.pets then CAFE.drawPets() end
  -- people, back of the line first so the front of the line is on top
  for i = #G.line, 1, -1 do drawCustomer(G.line[i], false) end
  for _, c in ipairs(G.others) do drawCustomer(c, false) end
  local c = G.cust
  if c then drawCustomer(c, true) end
  if c and c.stage == 1 and G.st == nil then drawBubble(c) end           -- (gone once the order has been rung in)
  if G.st then drawStationPanel() end
  UI.drawPopups()
  drawHUD()
  UI.drawStamp()
  UI.drawMessage()
  if needsCrank() then crankHelpDraw() end
end

----------------------------------------------------------------------
-- Title screen
----------------------------------------------------------------------
-- Big headline text: drawn once into an image of exactly the text's size, then
-- scaled up to fill the box (boxH tall, as wide as the screen allows) and centred.
local bigTextCache = {}
local function bigText(str, boxY, boxH, maxScale)
  local e = bigTextCache[str]
  if e == nil then
    gfx.setFont(fontBold)
    local w, h = gfx.getTextSize(str)
    local img = nil
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setFont(fontBold)
      gfx.drawText(str, 0, 0)
      gfx.popContext()
    end)
    e = { img = ok and img or nil, w = w, h = h }
    bigTextCache[str] = e
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if e.img then
    local scale = math.min(maxScale, 376 / e.w, boxH / e.h)
    local x = math.floor((400 - e.w * scale) / 2 + 0.5)
    local y = math.floor(boxY + (boxH - e.h * scale) / 2 + 0.5)
    e.img:drawScaled(x, y, scale)
  else
    drawTC(str, 200, boxY + math.floor(boxH / (2)) - 8, true)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

-- the big steaming mug (ox, oy move it around the screen)
function UI.drawBigMug(ox, oy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawCircleAtPoint(224 + ox, 164 + oy, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(182 + ox, 150 + oy, 38, 10)
  gfx.setColor(BLACK)
  gfx.fillRect(166 + ox, 186 + oy, 70, 4)
  for k = -1, 1 do
    local px, py = 0, 0
    for i = 0, 8 do
      local yy = 140 + oy - i * 2.5
      local xx = 200 + ox + k * 10 + math.sin(frames * 0.15 + i * 0.7 + k) * 3
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

UI.TITLE_N = 40                                  -- one picture per game frame, so the sunburst and lettering move smoothly
UI.NEW_SHOP = true                               -- the dark-backdrop shop page; set false to get the plain white page back
function UI.shopBgImg()
  if not UI.NEW_SHOP then return false end
  local im = UI.shopBg
  if im == nil then
    local ok, got = pcall(function() return gfx.image.new("images/shopbg") end)
    im = (ok and got) or false
    UI.shopBg = im
  end
  return im
end

UI.SHOPBEANS = { { 303, 48, 0.045, 0 }, { 330, 46, 0.060, 2.1 }, { 359, 49, 0.050, 4.2 } }   -- x, y, speed, start
function UI.drawShopBeans()
  local imgs = UI.shopBeanImgs
  if imgs == nil then
    imgs = {}
    for i = 1, 3 do
      local ok, im = pcall(function() return gfx.image.new("images/shopbean" .. i) end)
      if ok and im then imgs[i] = im else imgs = false; break end
    end
    UI.shopBeanImgs = imgs
  end
  if not imgs then return end
  for i, b in ipairs(UI.SHOPBEANS) do
    imgs[i]:draw(b[1], b[2] + math.floor(math.sin(frames * b[3] + b[4]) * 2.4 + 0.5))
  end
end

function UI.titleArt()                          -- the pictures of the title screen (sunburst, lettering, mug), loaded once
  local imgs = UI.titleImgs
  if imgs == nil then
    imgs = {}
    for i = 1, UI.TITLE_N do
      local ok, im = pcall(function() return gfx.image.new("images/title/" .. i) end)
      if ok and im then imgs[i] = im else imgs = false; break end
    end
    UI.titleImgs = imgs
  end
  return imgs
end

-- one title-screen box: a white sticker edge when chosen, a drop shadow when not (leaves the draw mode white-on-black when chosen)
function UI.menuBox(x, y, w, sel, art)
  if art then
    if sel then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x - 2, y - 2, w + 4, 35, 10)
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setColor(BLACK)
      gfx.fillRoundRect(x + 3, y + 3, w, 31, 8)
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(x, y, w, 31, 8)
      gfx.setLineWidth(1)
    end
  else
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(x, y, w, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(x, y, w, 31, 8)
      gfx.setLineWidth(1)
    end
  end
end

-- a little gear (eight teeth, a hole in the middle), ink on bg, turned by `ang`
function UI.gear(cx, cy, ink, bg, ang)
  gfx.setColor(ink)
  for k = 0, 7 do
    local a = ang + k * math.pi / 4
    local function P(r, da)
      return cx + math.cos(a + da) * r, cy + math.sin(a + da) * r
    end
    local x1, y1 = P(6, -0.34); local x2, y2 = P(11, -0.20)
    local x3, y3 = P(11, 0.20); local x4, y4 = P(6, 0.34)
    gfx.fillPolygon(x1, y1, x2, y2, x3, y3, x4, y4)
  end
  gfx.fillCircleAtPoint(cx, cy, 8)
  gfx.setColor(bg)
  gfx.fillCircleAtPoint(cx, cy, 3)
end

local function drawMenu()
  local art = UI.titleArt()
  if art then
    art[frames % UI.TITLE_N + 1]:draw(0, 0)                           -- the turning sunburst, the wavy lettering, the smiling mug
  else
    gfx.setColor(BLACK)                                              -- (fallback if the pictures are missing)
    gfx.fillRect(0, 10, 400, 84)
    bigText("Coffee Please!!!", 14, 56, 5)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    drawTC("by Christian G", 200, 72, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.drawBigMug(-100, 6)
  end

  -- boxes: three game modes, then a row with the high scores (half length) and Settings (a gear) side by side
  local opts = { { "CAFE", "build your own cafe" },
                 { "RUSH HOUR", "90 sec score chase" },
                 { "EVENING CHILL", "time free mode, relax" } }
  local mx, my = 196, 100                                          -- (art: sits a little up and left so nothing touches the white border)
  if art then mx, my = 188, 89 end
  for i, o in ipairs(opts) do
    local y = my + (i - 1) * 35
    UI.ink(({ "m_cafe", "m_rush", "m_chill" })[i])                  -- (PC: each box its own soft colour)
    UI.menuBox(mx, y, 196, menuSel == i, art)
    drawT(o[1], mx + 10, y + 1, true)
    drawT(o[2], mx + 10, y + 15)
    UI.ink("none")
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if menuSel == i then CAFE.pointer(mx + 162, y + 11) end           -- the same mouse arrow the shop uses, resting on the box
  end
  local y4 = my + 3 * 35
  local hs, ac, st = menuSel == 4 and UI.menuCol == 1, menuSel == 4 and UI.menuCol == 2, menuSel == 4 and UI.menuCol == 3
  UI.ink("m_high")
  UI.menuBox(mx, y4, 98, hs, art)                                  -- HIGH SCORES: half the length it was
  drawT("HIGH", mx + 10, y4 + 1, true)
  drawT("SCORES", mx + 10, y4 + 15, true)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if hs then CAFE.pointer(mx + 74, y4 + 11) end
  UI.ink("m_ach")
  UI.menuBox(mx + 106, y4, 41, ac, art)                            -- ACHIEVEMENTS: a trophy
  UI.trophy(mx + 106 + 20, y4 + 15, ac and WHITE or BLACK, ac and BLACK or WHITE, ac)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if ac then CAFE.pointer(mx + 106 + 27, y4 + 15) end
  UI.ink("m_gear")
  UI.menuBox(mx + 155, y4, 41, st, art)                            -- SETTINGS: a turning gear in a box of its own
  UI.gear(mx + 155 + 20, y4 + 15, st and WHITE or BLACK, st and BLACK or WHITE, st and frames * 0.06 or 0)
  UI.ink("none")
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  if st then CAFE.pointer(mx + 155 + 27, y4 + 15) end
  gfx.setColor(BLACK)
  if art then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(7, 211, 42, 19, 6)                          -- the version sits on a little white label
    gfx.setColor(BLACK)
    gfx.drawRoundRect(7, 211, 42, 19, 6)
  end
  drawT("V.1.3", art and 12 or 6, art and 213 or 220)               -- the version, lower left
end

-- ---- settings (the gear box on the title screen) ------------------
function UI.decoCup(x, y)
  gfx.setColor(WHITE); gfx.fillRect(x, y + 3, 8, 7)
  gfx.setColor(BLACK); gfx.drawRect(x, y + 3, 8, 7)
  gfx.drawCircleAtPoint(x + 9, y + 6, 2)
  gfx.fillRect(x + 1, y + 4, 6, 2)
  gfx.drawPixel(x + 3, y); gfx.drawPixel(x + 2, y + 1); gfx.drawPixel(x + 4, y + 1)
end

function UI.decoBean(x, y)
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x, y + 1, 8, 7)
  gfx.setColor(WHITE)
  gfx.drawLine(x + 2, y + 7, x + 5, y + 2)
  gfx.setColor(BLACK)
end

-- the pictures behind the Settings, High Scores, save and new-cafe screens: each set is 40 frames. They are loaded a few
-- pictures at a time while you sit on the title screen (see UI.bgPreload), the one under the cursor first, so pressing a
-- button finds them ready. A screen whose set is not all in yet never waits for it: it shows the pictures it has (the
-- sunburst holds still a moment) while the rest come in a few a frame. A set is let go once its screens are out of reach.
UI.bgSets = {}
UI.bgPart = {}                                     -- sets that are part-way loaded
function UI.bgLoadOne(name)                        -- load the next picture of a set; true once the set is complete
  if UI.bgSets[name] ~= nil then return true end
  local part = UI.bgPart[name]
  if not part then part = {}; UI.bgPart[name] = part end
  local i = #part + 1
  local ok, im = pcall(function() return gfx.image.new("images/" .. name .. "/" .. i) end)
  if not (ok and im) then
    collectgarbage("collect")                      -- (memory may be tight: let go of anything unused and try once more)
    ok, im = pcall(function() return gfx.image.new("images/" .. name .. "/" .. i) end)
  end
  if not (ok and im) then UI.bgSets[name] = false; UI.bgPart[name] = nil; UI.bgFailT = frames; return true end
  part[i] = im
  if i >= UI.TITLE_N then UI.bgSets[name] = part; UI.bgPart[name] = nil; return true end
  return false
end
UI.bgView = {}                                     -- a stand-in for a set that is part-way in: frame i, or the last one loaded so far
UI.bgViewMeta = { __index = function(v, i)
  local part = rawget(v, "part")
  return part[i] or part[#part]
end }
function UI.bgSet(name)
  local set = UI.bgSets[name]
  if set ~= nil then return set end
  if name == "scores" and (UI.bgSets.closing ~= nil or UI.bgPart.closing ~= nil or UI.bgSets.shift ~= nil or UI.bgPart.shift ~= nil) then
    UI.bgSets.closing, UI.bgPart.closing, UI.bgSets.shift, UI.bgPart.shift = nil, nil, nil, nil   -- (the high score pictures come in right after a
    collectgarbage("collect")                                                                    --  shift's closing pictures: put those away first)
  end
  local part = UI.bgPart[name]
  if part == nil or #part == 0 then                -- (nothing of it yet: the first picture now, the rest a few a frame)
    if UI.bgLoadOne(name) then return UI.bgSets[name] end
    part = UI.bgPart[name]
  end
  local v = UI.bgView[name]
  if v == nil or rawget(v, "part") ~= part then
    v = setmetatable({ part = part }, UI.bgViewMeta)
    UI.bgView[name] = v
  end
  return v
end

function UI.bgMenus()                              -- the title screen, the high scores, or the save / new-cafe screens
  if state == STATE_MENU or state == STATE_BOARD then return true end
  if state ~= CAFE.STATE then return false end
  local m = CAFE.mode
  return m == "slots" or m == "name" or m == "char"
end
function UI.bgWanted(name)                         -- is a screen that uses this set on show, or a button or two away?
  if name == "settings" or name == "scores" or name == "achieve" then return UI.bgMenus() end
  if name == "closing" or name == "shift" then                     -- the initials screen of this shift (kept from the start of the shift)
    return G ~= nil and (state == STATE_PLAY or state == STATE_ENTRY) and G.mode == (name == "closing" and "rush" or "chill")
  end
  local m = (state == CAFE.STATE) and CAFE.mode or nil
  if name == "slots" then return UI.bgMenus() end
  if name == "name" then return m == "slots" or m == "name" or m == "char" end
  if name == "char" then return m == "name" or m == "char" end
  return false
end

function UI.bgSweep()                              -- every frame: drop a set once its screens are gone
  for _, name in ipairs({ "settings", "scores", "slots", "name", "char", "closing", "shift", "achieve" }) do
    if (UI.bgSets[name] ~= nil or UI.bgPart[name] ~= nil) and not UI.bgWanted(name) then
      UI.bgSets[name] = nil
      UI.bgPart[name] = nil
    end
  end
end

-- a little work each frame: the rest of the pictures for the screen on show, then (on the title and save screens) your saves
-- and the pictures you are likely to ask for next, the one under the cursor first. A few pictures a frame, as long as the
-- frame has time for them, so neither the screen nor a fade ever waits.
UI.idle = 0
function UI.bgShown()                              -- the set the screen on show uses (nil if none)
  if state == STATE_MENU then return (UI.settings ~= nil and "settings") or (UI.ach ~= nil and "achieve") or nil end
  if state == STATE_BOARD then return "scores" end
  if state == CAFE.STATE then
    local m = CAFE.mode
    if m == "slots" or m == "name" or m == "char" then return m end
  end
  return nil
end
function UI.bgLoadSome(name, most, ms)             -- up to `most` pictures of a set, while the frame has `ms` to spare
  local t0 = pd.getCurrentTimeMilliseconds()
  for _ = 1, most do
    if UI.bgLoadOne(name) then return true end
    if pd.getCurrentTimeMilliseconds() - t0 >= ms then return false end
  end
  return UI.bgSets[name] ~= nil
end
function UI.bgPreload()
  if state == STATE_PLAY and G ~= nil and (G.mode == "rush" or G.mode == "chill") then   -- during a shift: one picture for the closing screen every few frames
    local name = (G.mode == "rush") and "closing" or "shift"
    if UI.bgSets[name] == nil and frames % 5 == 0 and (G.t or 0) > 2 then UI.bgLoadOne(name) end
    return
  end
  local shown = UI.bgShown()
  if shown and UI.bgPart[shown] then UI.bgLoadSome(shown, 4, 10); return end   -- (the screen on show is still missing some: those first)
  local onTitle = state == STATE_MENU
  if not (onTitle or (state == CAFE.STATE and (CAFE.mode == "slots" or CAFE.mode == "name"))) then UI.idle = 0; return end
  if trans == nil and UI.anyButton() then
    UI.idle = 0                                    -- (somebody is pressing buttons: wait till they stop for a moment, so scrolling the menu never hitches)
    return
  end
  UI.idle = UI.idle + 1
  if trans == nil and UI.idle < 4 then return end
  if onTitle then
    local next = nil                               -- what the cursor is on
    if UI.settings == nil then
      if menuSel == 1 then next = "slots"
      elseif menuSel == 4 then next = ({ "scores", "achieve", "settings" })[UI.menuCol] or "scores" end
    end
    if next ~= nil and next ~= "slots" and UI.bgSets[next] == nil then UI.bgLoadSome(next, 2, 5); return end
    if not CAFE.preRead() then return end          -- (your saves, one a frame, for the save screen)
    if next ~= nil and UI.bgSets[next] == nil then UI.bgLoadSome(next, 2, 5); return end
    for _, name in ipairs({ "slots", "settings", "scores", "achieve" }) do
      if UI.bgSets[name] == nil then UI.bgLoadSome(name, 2, 5); return end
    end
  elseif CAFE.mode == "slots" then
    if UI.bgSets.name == nil then UI.bgLoadSome("name", 2, 5) end
  else
    if UI.bgSets.char == nil then UI.bgLoadSome("char", 2, 5) end
  end
end

-- one sticker box, the same look as the title screen's (white edge when chosen, drop shadow when not)
function UI.stickerBox(x, y, w, h, sel)
  if sel then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x - 2, y - 2, w + 4, h + 4, 10)
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x, y, w, h, 8)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  else
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x + 3, y + 3, w, h, 8)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(x, y, w, h, 8)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(x, y, w, h, 8)
    gfx.setLineWidth(1)
  end
end

function UI.drawSettings()
  local art = UI.bgSet("settings")
  if not art then UI.drawSettingsPlain(); return end
  art[frames % UI.TITLE_N + 1]:draw(0, 0)                          -- the turning sunburst, the "Settings" lettering, the smiling mug
  local mx = 188
  local rows = { { "Pour with", UI.crankPour and "CRANK" or "TILT" },
                 { "Music", UI.musicOn and "ON" or "OFF" },
                 { "Back" } }
  for i, r in ipairs(rows) do
    local y = 76 + (i - 1) * 40
    local sel = UI.settings.sel == i
    UI.stickerBox(mx, y, 196, 31, sel)
    drawT(r[1], mx + 10, y + 8, true)
    if r[2] then drawTR(r[2], mx + 150, y + 8, true) end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if sel then CAFE.pointer(mx + 164, y + 11) end
  end
  if UI.settings.sel == 1 then                                      -- a little hint plate, only while "Pour with" is chosen
    UI.stickerBox(mx, 198, 196, 22, false)
    drawTC(UI.crankPour and "Turn the crank" or "Tilt the Playdate", mx + 98, 201, false)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

function UI.drawSettingsPlain()                    -- (the old look, if the pictures are missing)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 16, 400, 34)
  bigText("Settings", 19, 28, 3)
  -- cups and beans all round the border
  local n = 0
  for x = 6, 386, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoCup(x, 2); UI.decoCup(x, 226) else UI.decoBean(x, 3); UI.decoBean(x, 227) end
  end
  n = 0
  for y = 58, 206, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoBean(4, y); UI.decoBean(388, y) else UI.decoCup(3, y); UI.decoCup(386, y) end
  end
  local rows = { { "Pour with", UI.crankPour and "CRANK" or "TILT" },
                 { "Music", UI.musicOn and "ON" or "OFF" },
                 { "Back" } }
  for i, r in ipairs(rows) do
    local y = 72 + (i - 1) * 40
    local sel = UI.settings.sel == i
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(100, y, 200, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(100, y, 200, 31, 8)
      gfx.setLineWidth(1)
    end
    if r[2] then
      drawT(r[1], 112, y + 8, true)
      drawTR(r[2], 262, y + 8, true)
    else
      drawTC(r[1], 200, y + 8, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if sel then CAFE.pointer(272, y + 12) end
  end
  drawTC(UI.settings.sel == 1 and (UI.crankPour and "Turn the crank to pour" or "Tilt the Playdate to pour") or " ", 200, 196, false)
end

function UI.updateSettings()
  local st = UI.settings
  local function toggle()
    if st.sel == 1 then
      UI.crankPour = not UI.crankPour
      saveScores()
    elseif st.sel == 2 then
      UI.musicOn = not UI.musicOn
      pcall(function() if UI.musicItem then UI.musicItem:setValue(UI.musicOn) end end)
    end
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonDown) then st.sel = st.sel % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then st.sel = (st.sel + 1) % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    if st.sel < 3 then toggle() end
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if st.sel == 3 then sfxClick(); UI.fast(function() UI.settings = nil end) else toggle() end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick(); UI.fast(function() UI.settings = nil end)
  end
end

----------------------------------------------------------------------
-- Closing time: initials entry, then the high score board
----------------------------------------------------------------------
-- a white arrow with a black edge, pointing up (d = -1) or down (d = 1)
function UI.vertArrow(x, y, d)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x, y + d * 8, x - 8, y - d * 2, x + 8, y - d * 2)
  gfx.setColor(WHITE)
  gfx.fillTriangle(x, y + d * 6, x - 5, y, x + 5, y)
  gfx.setColor(BLACK)
end

function UI.drawEntryNew(art)                       -- the results on a white receipt, then the three initials, on the sunburst
  art[frames % UI.TITLE_N + 1]:draw(0, 0)
  local rows
  if G.mode == "rush" then                          -- (served and walked-out share a line; tips include the combo bonuses)
    rows = {
      { "Served / walked out", G.served .. " / " .. G.missed },
      { "Sales", money(G.cash) },
      { "Tips & combos", money(G.tips) },
      { "Best combo", (G.bestStreak or 0) .. " in a row" },
    }
  else
    rows = {
      { "Customers served", tostring(G.served) },
      { "Sales", money(G.cash) },
      { "Tips", money(G.tips) },
      { "Walked out", tostring(G.missed) },
    }
  end
  UI.stickerBox(76, 48, 248, 84, false)
  for i, row in ipairs(rows) do
    local y = 52 + (i - 1) * 14
    drawT(row[1], 92, y)
    drawTR(row[2], 308, y)
  end
  gfx.setColor(BLACK)
  for x = 86, 312, 6 do gfx.drawLine(x, 111, x + 2, 111) end
  drawT("TOTAL MADE", 92, 114, true)
  drawTR(money(G.total), 308, 114, true)

  UI.stickerBox(96, 141, 208, 20, false)
  drawTC("ENTER YOUR INITIALS", 200, 143, true)
  for i = 1, 3 do
    local bx, by = 140 + (i - 1) * 44, 181
    local on = (i == entry.cur)
    UI.stickerBox(bx, by, 32, 32, on)
    drawTC(string.char(65 + entry.letters[i]), bx + 16, by + 9, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if on then
      local nudge = (math.floor(frames / (6))) % 2                -- the arrows tick in and out
      UI.vertArrow(bx + 16, by - 5 - nudge, -1)
      UI.vertArrow(bx + 16, by + 37 + nudge, 1)
    end
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

local function drawEntry()
  local art = UI.bgSet(G.mode == "rush" and "closing" or "shift")
  if art then UI.drawEntryNew(art); return end
  gfx.setColor(BLACK)
  gfx.fillRect(0, 6, 400, 40)
  bigText(G.mode == "chill" and "Shift Over!" or "Closing Time!", 9, 34, 3)

  local rows = {
    { "Customers served", tostring(G.served) },
    { "Sales", money(G.cash) },
    { "Tips", money(G.tips) },
    { "Walked out", tostring(G.missed) },
  }
  if G.mode == "rush" then                                     -- (still four rows: served and walked-out share one, tips include the combo bonuses)
    rows = {
      { "Served / walked out", G.served .. " / " .. G.missed },
      { "Sales", money(G.cash) },
      { "Tips & combos", money(G.tips) },
      { "Best combo", (G.bestStreak or 0) .. " in a row" },
    }
  end
  local pitch = 15
  for i, row in ipairs(rows) do
    local y = 50 + (i - 1) * pitch
    drawT(row[1], 90, y)
    drawTR(row[2], 310, y)
  end
  gfx.setColor(BLACK)
  gfx.fillRect(80, 112, 240, 2)
  drawT("TOTAL MADE", 90, 116, true)
  drawTR(money(G.total), 310, 116, true)

  drawTC("ENTER YOUR INITIALS", 200, 138, true)
  for i = 1, 3 do
    local bx = 200 - 54 + (i - 1) * 40
    gfx.setColor(BLACK)
    if i == entry.cur then
      gfx.fillRect(bx, 174, 32, 32)
      gfx.fillTriangle(bx + 10, 170, bx + 22, 170, bx + 16, 163)
      gfx.fillTriangle(bx + 10, 210, bx + 22, 210, bx + 16, 217)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRect(bx, 174, 32, 32)
      gfx.setLineWidth(1)
    end
    drawTC(string.char(65 + entry.letters[i]), bx + 16, 180, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setColor(BLACK)
end

-- a small steaming mug for the corners of the board
function UI.drawSmallMug(x, y)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y + 10, 26, 20, 4)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(x, y + 10, 26, 20, 4)
  gfx.drawCircleAtPoint(x + 30, y + 20, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(x + 3, y + 13, 20, 5)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 4, y + 31, 38, 3)
  for k = 0, 1 do
    local px, py = 0, 0
    for i = 0, 5 do
      local yy = y + 6 - i * 2
      local xx = x + 8 + k * 9 + math.sin(frames * 0.15 + i * 0.8 + k * 2) * 2
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

-- the high-score look: double border, bobbing beans, steam rising from two cups
function UI.beanFrame()
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(2, 2, 396, 236, 10)
  gfx.setLineWidth(1)
  gfx.drawRoundRect(7, 7, 386, 226, 7)
  for i = 0, 5 do
    local bob = math.floor(math.sin(frames * 0.12 + i * 1.1) * 3 + 0.5)
    drawBean(22 + (i % 2) * 16, 50 + i * 24 + bob, 1)
    drawBean(378 - (i % 2) * 16, 50 + i * 24 - bob, 1)
  end
  for _, bx in ipairs({ 26, 35, 358, 367 }) do
    local px, py
    for yy = 204, 40, -3 do
      local xx = bx + math.sin(frames * 0.12 + yy * 0.09 + bx) * 3
      if px and (math.floor(yy / (3)) + (math.floor(frames / (6)))) % 6 ~= 0 then
        gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), yy)
      end
      px, py = xx, yy
    end
  end
  UI.drawSmallMug(18, 198)
  UI.drawSmallMug(350, 198)
  gfx.setColor(BLACK)
end

-- the new look: sunburst, lettering, a white sheet with dotted rows (all in the picture) and the words written on top
UI.BOARD_ROW0, UI.BOARD_ROWH = 77, 13               -- must match the picture: first row's top, row pitch
function UI.drawBoardArt(art)
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"
  art[frames % UI.TITLE_N + 1]:draw(0, 0)
  gfx.setColor(BLACK)
  drawTC(name, 200, 51, true)                        -- on the little plate between the arrows

  local function row(i, top)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (math.floor(frames / (8))) % 2 == 0 then          -- your own score blinks
      gfx.setColor(BLACK)
      if i <= 3 then gfx.fillRect(110, top, 208, 12) else gfx.fillRect(82, top, 236, 12) end
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    if i > 3 then drawTC(tostring(i), 98, top - 2, true) end   -- ranks 1-3 are already in their medals
    drawT(e.n, 114, top - 2, true)
    drawTR(money(e.s), 314, top - 2, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, UI.BOARD_ROW0 + (i - 1) * UI.BOARD_ROWH) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    local top = UI.BOARD_ROW0 + 10 * UI.BOARD_ROWH + 4
    for x = 86, 314, 6 do gfx.drawLine(x, top - 3, x + 2, top - 3) end
    row(board.rank, top)
  end

  local back = "B: back"                              -- on the little label, bottom left (a shorter form if this font runs wide)
  if gfx.getTextSize(back) > 60 then back = "B:back" end
  if gfx.getTextSize(back) > 60 then back = "B" end
  drawTC(back, 39, 209, false)
end

local function drawBoard()
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"

  local art = UI.bgSet("scores")
  if art then UI.drawBoardArt(art); return end
  if art == false and frames - (UI.bgFailT or 0) > 45 then UI.bgSets.scores = nil end       -- (the new look did not load: try again in a moment)

  UI.beanFrame()

  -- title band with arrows to switch boards
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(name .. " HIGH SCORES", 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(WHITE)
  gfx.fillTriangle(24, 23, 32, 17, 32, 29)
  gfx.fillTriangle(376, 23, 368, 17, 368, 29)
  gfx.setColor(BLACK)

  local function row(i, y, label)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (math.floor(frames / (8))) % 2 == 0 then
      gfx.setColor(BLACK)
      gfx.fillRect(58, y - 2, 286, 17)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTR(label or tostring(i), 92, y - 1, true)
    drawT(e.n, 104, y - 1, true)
    drawTR(money(e.s), 336, y - 1, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, 39 + (i - 1) * 16) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    for x = 60, 340, 6 do gfx.drawLine(x, 198, x + 2, 198) end
    row(board.rank, 199, "#" .. board.rank)
  end

  drawTC("B: back", 200, 216, true)
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------
local function goTitle()
  sfxClick()
  UI.fast(function()
    if G then closeStation() end
    setShiftMenu(false, false)
    state = STATE_MENU
  end)
end

CAFE.goTitle = function() goTitle() end

local function startGame(mode)
  sfxClick()
  sfxStart()
  transitionTo(function()
    newGame(mode)
    state = STATE_PLAY
  end)
end

function UI.openBoard(m)
  UI.fast(function()
    board = { mode = "view", rank = nil, m = m, view = m, t = 0 }
    state = STATE_BOARD
    UI.bgSet("scores")
  end)
end

local function updateMenu()
  if pd.buttonJustPressed(pd.kButtonDown) then
    menuSel = menuSel % 4 + 1
    UI.menuCol = 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    menuSel = (menuSel + 2) % 4 + 1
    UI.menuCol = 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonLeft) then
    if menuSel == 4 and UI.menuCol > 1 then UI.menuCol = UI.menuCol - 1; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonRight) then
    if menuSel == 4 and UI.menuCol < 3 then UI.menuCol = UI.menuCol + 1; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if menuSel == 4 and UI.menuCol == 2 then
      UI.openAch()
    elseif menuSel == 4 and UI.menuCol == 3 then
      sfxClick()
      UI.fast(function() UI.settings = { sel = 1 }; UI.bgSet("settings") end)
    elseif menuSel == 4 then
      sfxClick()
      UI.openBoard("rush")
    elseif menuSel == 1 then
      sfxClick()
      CAFE.open()
    else
      startGame(menuSel == 3 and "chill" or "rush")
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick()
    UI.openBoard("rush")
  end
end

local function updateEntry(dt)
  G.endT = G.endT + dt
  if G.endT < 1.5 then return end   -- ignore button mashing as the shift ends
  local e = entry
  local function bump(d)
    e.letters[e.cur] = (e.letters[e.cur] + d) % 26
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonUp) then bump(1)
  elseif pd.buttonJustPressed(pd.kButtonDown) then bump(-1)
  elseif pd.buttonJustPressed(pd.kButtonLeft) then e.cur = math.max(1, e.cur - 1); sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonRight) then e.cur = math.min(3, e.cur + 1); sfxClick() end

  -- the crank spins through the alphabet too
  e.crank = e.crank + pd.getCrankChange()
  while e.crank >= 30 do e.crank = e.crank - 30; bump(1) end
  while e.crank <= -30 do e.crank = e.crank + 30; bump(-1) end

  if pd.buttonJustPressed(pd.kButtonA) then
    if e.cur < 3 then
      e.cur = e.cur + 1
      sfxClick()
    else
      local name = string.char(65 + e.letters[1], 65 + e.letters[2], 65 + e.letters[3])
      local rank = insertScore(G.mode, name, G.total)
      sfxClick()
      local m = G.mode
      transitionTo(function()
        board = { mode = "after", rank = rank, m = m, view = m, t = 0 }
        state = STATE_BOARD
        UI.bgSet("scores")
      end)
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    if e.cur > 1 then e.cur = e.cur - 1; sfxClick() end
  end
end

local function updateBoard(dt)
  board.t = board.t + dt
  -- (after a game the buttons stay locked a moment so a mashed A can't restart it)
  if board.t < (board.mode == "after" and 1.2 or 0.2) then return end
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    board.view = (board.view == "rush") and "chill" or "rush"
    sfxClick()
    return
  end
  if board.mode == "after" then
    if pd.buttonJustPressed(pd.kButtonA) then
      startGame(board.m)
    elseif pd.buttonJustPressed(pd.kButtonB) then
      sfxClick()
      goTitle()
    end
  else
    if pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
      sfxClick()
      goTitle()
    end
  end
end

----------------------------------------------------------------------
-- CAFE mode: three save files, a shop between shifts, stars, decorations, pets
----------------------------------------------------------------------
CAFE.STATE = 5
CAFE.PRICE = 3          -- every shop price is multiplied by this
CAFE.CUP_COST  = { 10, 20, 35, 50, 70, 90, 110, 130 }   -- dollars (x PRICE): cup 3, 4 ... 10
CAFE.SEAT_N    = { 2, 4, 6, 8, 15 }           -- seats after each seating upgrade (the last one is the corner booth: 5 on the couch, 2 chairs)
CAFE.SEAT_COST = { 60 / CAFE.PRICE, 40, 60, 85, 120 }     -- (the first table, in the starting kit, is $60 in the shop)
-- everything you can buy for the looks. kind: wall / floor (placed on a grid spot),
-- rug (one at a time), ceiling, pet.
CAFE.ITEMS = {
  { id = "clock",    name = "Wall clock",     kind = "wall",    cost = 25 },
  { id = "cuckoo",   name = "Cuckoo clock",   kind = "wall",    cost = 55 },
  { id = "calendar", name = "Calendar",       kind = "wall",    cost = 20 },
  { id = "plant",    name = "Spiky plant",    kind = "floor",   cost = 30 },
  { id = "cactus",   name = "Cactus",         kind = "floor",   cost = 25 },
  { id = "fern",     name = "Leafy fern",     kind = "floor",   cost = 30 },
  { id = "flowers",  name = "Flower pot",     kind = "floor",   cost = 35 },
  { id = "tree",     name = "Christmas tree", kind = "floor",   cost = 80 },
  { id = "pumpkin",  name = "Pumpkin",        kind = "floor",   cost = 20 },
  { id = "palm",     name = "Palm tree",      kind = "floor",   cost = 45 },
  { id = "snake",    name = "Snake plant",    kind = "floor",   cost = 30 },
  { id = "sunflower", name = "Sunflowers",    kind = "floor",   cost = 35 },
  { id = "bonsai",   name = "Bonsai",         kind = "floor",   cost = 40 },
  { id = "monstera", name = "Monstera",       kind = "floor",   cost = 40 },
  { id = "saltlamp", name = "Salt lamp",      kind = "counter", cost = 16, lit = true },
  { id = "lavalamp", name = "Lava lamp",      kind = "counter", cost = 18, lit = true },
  { id = "floorlamp", name = "Floor lamp",    kind = "floor",   cost = 35, lit = true },
  { id = "arclamp",  name = "Arc lamp",       kind = "floor",   cost = 45, lit = true },
  { id = "torchiere", name = "Torchiere lamp", kind = "floor",  cost = 40, lit = true },
  { id = "tripodlamp", name = "Tripod lamp",  kind = "floor",   cost = 38, lit = true },
  { id = "globelamp", name = "Globe lamp",    kind = "floor",   cost = 42, lit = true },
  { id = "tiffany",  name = "Tiffany lamp",   kind = "floor",   cost = 55, lit = true },
  { id = "tiffanytab", name = "Tiffany table lamp", kind = "counter", cost = 26, lit = true },
  { id = "streetlamp", name = "Street lamp",  kind = "floor",   cost = 60, lit = true },
  { id = "paperlamp", name = "Paper lantern lamp", kind = "floor", cost = 36, lit = true },
  { id = "neoncup",  name = "Neon cup sign",  kind = "wall",    cost = 40 },
  { id = "neonheart", name = "Neon heart sign", kind = "wall",   cost = 38 },
  { id = "neonbolt", name = "Neon bolt sign", kind = "wall",     cost = 36 },
  { id = "neonstar", name = "Neon star sign", kind = "wall",     cost = 40 },
  { id = "neonmoon", name = "Neon moon sign", kind = "wall",     cost = 42 },
  { id = "neonarrow", name = "Neon arrow sign", kind = "wall",   cost = 34 },
  { id = "discoball", name = "Disco ball",    kind = "wall",     cost = 50 },
  { id = "itemstand", name = "Item stand",    kind = "floor",    cost = 25, stuff = true },
  { id = "pinwheel", name = "Pinwheel",       kind = "counter",  cost = 28, stuff = true },
  { id = "radio",    name = "Retro radio",    kind = "counter",  cost = 45, stuff = true },
  { id = "boombox",  name = "Boom box",       kind = "counter",  cost = 50, stuff = true },
  { id = "luckycat", name = "Lucky cat",      kind = "counter",  cost = 48, stuff = true },
  { id = "record",   name = "Record player",  kind = "counter",  cost = 55, stuff = true },
  { id = "snowglobe", name = "Snow globe",    kind = "counter",  cost = 36, stuff = true },
  { id = "gumball",  name = "Gumball machine", kind = "counter", cost = 40, stuff = true },
  { id = "cradle",   name = "Newton's cradle", kind = "counter", cost = 34, stuff = true },
  { id = "miniplaydate", name = "Pee-Dee",    kind = "counter",  cost = 60, stuff = true },
  { id = "jukebox",  name = "Juke box",       kind = "floor",    cost = 85, stuff = true },
  { id = "wf1", name = "Single pane", kind = "frame", cost = 25 },
  { id = "wf2", name = "Six panes", kind = "frame", cost = 30 },
  { id = "wf3", name = "Diamond panes", kind = "frame", cost = 35 },
  { id = "wf4", name = "Windowsill", kind = "frame", cost = 35 },
  { id = "wf5", name = "Arched window", kind = "frame", cost = 40 },
  { id = "wf6", name = "Shutters", kind = "frame", cost = 45 },
  { id = "wc1", name = "Plain curtains", kind = "curtain", cost = 15 },
  { id = "wc2", name = "Checker curtains", kind = "curtain", cost = 18 },
  { id = "wc3", name = "Striped curtains", kind = "curtain", cost = 18 },
  { id = "wc4", name = "Scalloped valance", kind = "curtain", cost = 20 },
  { id = "wc5", name = "Lace curtains", kind = "curtain", cost = 22 },
  { id = "wc6", name = "Polka dot curtains", kind = "curtain", cost = 20 },
  { id = "wc7", name = "Coffee bean curtains", kind = "curtain", cost = 25 },
  { id = "wc8", name = "Window blinds", kind = "curtain", cost = 20 },
  { id = "wc9", name = "Heart curtains", kind = "curtain", cost = 22 },
  { id = "wc10", name = "Starry night curtains", kind = "curtain", cost = 28 },
  { id = "tulips",   name = "Tulip pot",      kind = "counter", cost = 15 },
  { id = "succ",     name = "Succulent",      kind = "counter", cost = 12 },
  { id = "daisies",  name = "Daisy vase",     kind = "counter", cost = 18 },
  { id = "minicac",  name = "Mini cactus",    kind = "counter", cost = 12 },
  { id = "herbs",    name = "Herb pot",       kind = "counter", cost = 15 },
  { id = "ivy",      name = "Ivy vines",      kind = "shelf",   cost = 25 },
  { id = "bloomvine", name = "Flowering vines", kind = "shelf", cost = 35 },
  { id = "fernvine", name = "Fern fronds",    kind = "shelf",   cost = 28 },
  { id = "heartvine", name = "Heart vines",   kind = "shelf",   cost = 32 },
  { id = "berryvine", name = "Berry vines",   kind = "shelf",   cost = 30 },
  { id = "starvine", name = "Twinkle vines",  kind = "shelf",   cost = 38 },
  { id = "moss",     name = "Hanging moss",   kind = "shelf",   cost = 22 },
  { id = "beadvine", name = "Bead strands",   kind = "shelf",   cost = 26 },
  { id = "wisteria", name = "Wisteria",       kind = "shelf",   cost = 40 },
  { id = "lanternvine", name = "Lantern strings", kind = "shelf", cost = 42 },
  { id = "lights",   name = "String lights",  kind = "ceiling", cost = 45, lit = true },
  { id = "fairylights", name = "Fairy lights", kind = "ceiling", cost = 40, lit = true },
  { id = "globelights", name = "Globe lights", kind = "ceiling", cost = 50, lit = true },
  { id = "lanternlights", name = "Lantern lights", kind = "ceiling", cost = 48, lit = true },
  { id = "heartlights", name = "Heart lights", kind = "ceiling", cost = 52, lit = true },
  { id = "starlights", name = "Star lights",  kind = "ceiling", cost = 55, lit = true },
  { id = "candle1",  name = "Pillar candle",  kind = "counter", cost = 12, lit = true },
  { id = "candle2",  name = "Taper candle",   kind = "counter", cost = 14, lit = true },
  { id = "candle3",  name = "Tealight trio",  kind = "counter", cost = 14, lit = true },
  { id = "candle4",  name = "Jar candle",     kind = "counter", cost = 16, lit = true },
  { id = "candle5",  name = "Candelabra",     kind = "counter", cost = 28, lit = true },
  { id = "candle6",  name = "Candle lantern", kind = "counter", cost = 24, lit = true },
  { id = "candle7",  name = "Floating candles", kind = "counter", cost = 22, lit = true },
  { id = "incense",  name = "Incense stick", kind = "counter", cost = 10, lit = true },
  { id = "rug",      name = "Welcome rug",    kind = "rug",     cost = 35 },
  { id = "rug2",     name = "Striped rug",    kind = "rug",     cost = 40 },
  { id = "rug3",     name = "Checker rug",    kind = "rug",     cost = 45 },
  { id = "rug4",     name = "Polka dot rug",  kind = "rug",     cost = 45 },
  { id = "rug5",     name = "Lattice rug",    kind = "rug",     cost = 50 },
  { id = "rug6",     name = "Plaid rug",      kind = "rug",     cost = 50 },
  { id = "rug7",     name = "Coffee bean rug", kind = "rug",    cost = 55 },
  { id = "orug1",    name = "Cozy oval rug",  kind = "orug",    cost = 60 },
  { id = "orug2",    name = "Ripple oval rug", kind = "orug",   cost = 65 },
  { id = "orug3",    name = "Checker oval rug", kind = "orug",  cost = 65 },
  { id = "orug4",    name = "Polka dot oval rug", kind = "orug", cost = 70 },
  { id = "orug5",    name = "Sunburst oval rug", kind = "orug", cost = 75 },
  { id = "orug6",    name = "Coffee bean oval rug", kind = "orug", cost = 80 },
  { id = "run6",     name = "Polka dot runner", kind = "runner", cost = 38 },
  { id = "run7",     name = "Zigzag runner",  kind = "runner", cost = 40 },
  { id = "run8",     name = "Plaid runner",   kind = "runner", cost = 42 },
  { id = "run1",     name = "Red carpet runner", kind = "runner", cost = 40 },
  { id = "run2",     name = "Striped runner", kind = "runner", cost = 35 },
  { id = "run3",     name = "Checker runner", kind = "runner", cost = 35 },
  { id = "run4",     name = "Diamond runner", kind = "runner", cost = 40 },
  { id = "run5",     name = "Coffee bean runner", kind = "runner", cost = 45 },
  { id = "t1",       name = "Tiny landscape",  kind = "tiny", cost = 8 },
  { id = "t2",       name = "Tiny heart",      kind = "tiny", cost = 8 },
  { id = "t3",       name = "Tiny sunburst",   kind = "tiny", cost = 10 },
  { id = "t4",       name = "Tiny mug print",  kind = "tiny", cost = 10 },
  { id = "t5",       name = "Cat portrait",    kind = "tiny", cost = 12 },
  { id = "t6",       name = "Tiny mirror",     kind = "tiny", cost = 12 },
  { id = "t7",       name = "Party bunting",   kind = "tiny", cost = 14 },
  { id = "t8",       name = "Little stars",    kind = "tiny", cost = 8 },
  { id = "t9",       name = "Music notes",     kind = "tiny", cost = 10 },
  { id = "t10",      name = "Moon and stars",  kind = "tiny", cost = 12 },
  { id = "t12",      name = "Sailboat",        kind = "tiny", cost = 10 },
  { id = "cloth1",   name = "Checker tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth2",   name = "Striped tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth3",   name = "Lace tablecloth", kind = "cloth", cost = 40 },
  { id = "cloth4",   name = "Polka dot tablecloth", kind = "cloth", cost = 32 },
  { id = "cloth5",   name = "Plaid tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth6",   name = "Diamond tablecloth", kind = "cloth", cost = 36 },
  { id = "cloth7",   name = "Coffee bean tablecloth", kind = "cloth", cost = 38 },
  { id = "cloth8",   name = "Heart tablecloth", kind = "cloth", cost = 36 },
  { id = "cloth9",   name = "Bordered tablecloth", kind = "cloth", cost = 34 },
  { id = "cloth10",  name = "Starry tablecloth", kind = "cloth", cost = 42 },
  { id = "cloth11",  name = "Zigzag tablecloth", kind = "cloth", cost = 38 },
  { id = "cattree",  name = "Cat tree",       kind = "floor",   cost = 60, needs = "cat" },
  { id = "dogbed",   name = "Dog bed",        kind = "floor",   cost = 45, needs = "dog" },
  { id = "aquarium", name = "Fish tank",      kind = "counter", cost = 55, pettab = true },
  { id = "snaketank", name = "Snake tank",    kind = "counter", cost = 70, pettab = true },
  { id = "cat",      name = "Black cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "tuxcat",   name = "Tuxedo cat",     kind = "pet",     cost = 150, species = "cat" },
  { id = "tabbycat", name = "Tabby cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "calicocat", name = "Calico cat",    kind = "pet",     cost = 160, species = "cat" },
  { id = "graycat",  name = "Gray cat",       kind = "pet",     cost = 150, species = "cat" },
  { id = "dog",      name = "Black dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "dalmatian", name = "Dalmatian",     kind = "pet",     cost = 160, species = "dog" },
  { id = "husky",    name = "Husky",          kind = "pet",     cost = 170, species = "dog" },
  { id = "patchdog", name = "Patch dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "goldendog", name = "Golden dog",    kind = "pet",     cost = 160, species = "dog" },
  { id = "turtle",   name = "Green turtle",   kind = "pet",     cost = 120, species = "turtle" },
  { id = "boxturtle", name = "Box turtle",    kind = "pet",     cost = 130, species = "turtle" },
  { id = "tortoise", name = "Tortoise",       kind = "pet",     cost = 140, species = "turtle" },
  { id = "slider",   name = "Red-ear turtle", kind = "pet",     cost = 130, species = "turtle" },
  { id = "h_cap",     name = "Baseball cap",   kind = "hat",     cost = 12 },
  { id = "h_top",     name = "Top hat",        kind = "hat",     cost = 25 },
  { id = "h_beanie",  name = "Pom beanie",     kind = "hat",     cost = 14 },
  { id = "h_cowboy",  name = "Cowboy hat",     kind = "hat",     cost = 22 },
  { id = "h_chef",    name = "Chef hat",       kind = "hat",     cost = 18 },
  { id = "h_crown",   name = "Golden crown",   kind = "hat",     cost = 60 },
  { id = "h_party",   name = "Party hat",      kind = "hat",     cost = 10 },
  { id = "h_beret",   name = "Beret",          kind = "hat",     cost = 16 },
  { id = "h_santa",   name = "Santa hat",      kind = "hat",     cost = 20 },
  { id = "h_wizard",  name = "Wizard hat",     kind = "hat",     cost = 40 },
  { id = "h_witch",   name = "Witch hat",      kind = "hat",     cost = 35 },
  { id = "h_bow",     name = "Big bow",        kind = "hat",     cost = 12 },
  { id = "h_flower",  name = "Flower band",    kind = "hat",     cost = 14 },
  { id = "g_round",   name = "Round glasses",  kind = "glasses", cost = 10 },
  { id = "g_square",  name = "Square glasses", kind = "glasses", cost = 12 },
  { id = "g_shades",  name = "Sunglasses",     kind = "glasses", cost = 18 },
  { id = "g_heart",   name = "Heart glasses",  kind = "glasses", cost = 20 },
  { id = "g_cat",     name = "Cat-eye glasses", kind = "glasses", cost = 22 },
  { id = "g_nerd",    name = "Thick frames",   kind = "glasses", cost = 14 },
  { id = "g_monocle", name = "Fancy monocle",  kind = "glasses", cost = 30 },
  { id = "g_3d",      name = "3D glasses",     kind = "glasses", cost = 16 },
}
CAFE.byId = {}
CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = "hmus", name = "Halloween music", kind = "music", cost = 60 }       -- the Music tab: two records, either or both
CAFE.ITEMS[#CAFE.ITEMS + 1] = { id = "xmus", name = "Christmas music", kind = "music", cost = 60 }
for _, it in ipairs(CAFE.ITEMS) do CAFE.byId[it.id] = it end
-- a few words under the price in the shop
CAFE.DESC = {
  clock = "Tick-tock!", cuckoo = "Cuckoo! Cuckoo!", calendar = "Every day counts",
  tree = "Ho ho ho!", pumpkin = "Spooky season!", palm = "Vacation vibes",
  cactus = "Ouch! Cute, though", flowers = "Smells lovely", plant = "Low maintenance",
  fern = "Lush little jungle", snake = "Tough as nails", sunflower = "Soak up the sun", bonsai = "Zen in a pot",
  monstera = "Big leafy energy", tulips = "Spring in a pot", succ = "Hardly needs water", daisies = "Fresh and cheerful",
  minicac = "Small but prickly", herbs = "Fresh and fragrant",
  lights = "Cozy glow", fairylights = "Tiny twinkling lights", globelights = "An old-time glow", lanternlights = "Paper lanterns on a string",
  heartlights = "Hearts all around", starlights = "A sky of little stars", ivy = "Hanging around", bloomvine = "In full bloom",
  fernvine = "Feathery and fresh", heartvine = "Love is in the air", berryvine = "Ripe for the picking",
  starvine = "Twinkle, twinkle", moss = "Soft and wispy", beadvine = "Strings of beads",
  wisteria = "Dreamy purple vibes", lanternvine = "Little glowing lanterns",
  rug = "Wipe your feet", rug2 = "Wipe your feet", rug3 = "Wipe your feet",
  run1 = "Roll out the red carpet", run2 = "Rolls out at the register", run3 = "Rolls out at the register",
  run4 = "Rolls out at the register", run5 = "Rolls out at the register",
  t1 = "Hang it up high", t2 = "Made with love", t3 = "Rise and shine", t4 = "Mug shot", t5 = "Meow",
  t6 = "Mirror, mirror", t7 = "Party time!", t8 = "Wish upon a star", t9 = "La la la", t10 = "Sweet dreams",
  t12 = "Smooth sailing",
  cloth1 = "Dress up every table", cloth2 = "Dress up every table", cloth3 = "Dress up every table",
  cloth4 = "Dress up every table", cloth5 = "Dress up every table", cloth6 = "Dress up every table", cloth7 = "Dress up every table",
  cloth8 = "Dress up every table", cloth9 = "Dress up every table", cloth10 = "Dress up every table", cloth11 = "Dress up every table",
  candle1 = "Sits on a counter or table", candle2 = "Sits on a counter or table", candle3 = "Sits on a counter or table",
  candle4 = "Sits on a counter or table", candle5 = "Sits on a counter or table", candle6 = "Sits on a counter or table", candle7 = "Sits on a counter or table", incense = "Calm, smoky and fragrant",
  neonheart = "Be still my heart", neonbolt = "Shocking!", neonstar = "You're a star", neonmoon = "Open past midnight",
  arclamp = "Reach for the light", torchiere = "Light up the ceiling", tripodlamp = "Standing tall",
  globelamp = "A glowing moon", tiffany = "Stained glass glow", streetlamp = "Gaslight vibes", paperlamp = "Soft paper glow",
  neonarrow = "This way for coffee!", discoball = "Let's dance!", aquarium = "Swimming along", snaketank = "Slithers all day", turtle = "Slow and steady", boxturtle = "Snug in its shell", tortoise = "Old and wise", slider = "Sunbathing champ", pinwheel = "Spin, spin, spin", radio = "Tunes all day",
  boombox = "Pump up the volume", luckycat = "Waves in good luck", record = "Spin that record", snowglobe = "Shake, shake, shake",
  gumball = "A penny for a gumball", cradle = "Click, clack, click", miniplaydate = "Cranking it all day", jukebox = "Drop a coin, pick a tune",
  cp1 = "A centrepiece for every table", cp2 = "Dinner by candlelight", cp3 = "A little green", cp4 = "Tiny and spiky",
  rug4 = "Wipe your feet", rug5 = "Wipe your feet", rug6 = "Wipe your feet", rug7 = "Wipe your feet",
  orug1 = "Sits under the tables", orug2 = "Ripples under the tables", orug3 = "Sits under the tables", orug4 = "Spots under the tables", orug5 = "Sunshine for your tables", orug6 = "Beans under the tables",
  run6 = "Rolls out at the register", run7 = "Rolls out at the register", run8 = "Rolls out at the register",
  cp5 = "Spooky season, every table", cp6 = "Merry little tables",
  cat = "Boosts stars and tips", dog = "Boosts stars and tips",
  cattree = "The cat will love it", dogbed = "A nap spot for the dog",
  wf1 = "One big pane", wf2 = "Six little panes", wf3 = "Fancy diamonds", wf4 = "A ledge for plants", wf5 = "A rounded top", wf6 = "Open the shutters",
  wc1 = "Soft and simple", wc2 = "Checked and cozy", wc3 = "Stripes all the way", wc4 = "A frilly top", wc5 = "Light and lacy",
  wc6 = "Spot on", wc7 = "Smells like coffee", wc8 = "Half way down", wc9 = "Made with love", wc10 = "Twinkle twinkle",
  tuxcat = "Dressed for dinner", tabbycat = "Stripes and sass", calicocat = "Patches of everything", graycat = "Soft and silvery",
  dalmatian = "Spots on spots", husky = "Fluffy and loud", patchdog = "One patchy eye", goldendog = "A very good boy",
  h_cap = "Brim to the back", h_top = "Very fancy", h_beanie = "Warm and fuzzy", h_cowboy = "Howdy, partner", h_chef = "Order up!",
  h_crown = "Royal barista", h_party = "Every day's a party", h_beret = "Oui oui", h_santa = "Ho ho ho!", h_wizard = "Brews magic coffee",
  h_witch = "Brews spooky coffee", h_bow = "So cute", h_flower = "Fresh as a daisy",
  g_round = "Classic look", g_square = "Sharp and smart", g_shades = "Too cool", g_heart = "Love at first sip", g_cat = "Purr-fect",
  g_nerd = "Very studious", g_monocle = "Quite posh", g_3d = "Coffee in 3D",
  saltlamp = "A warm, glowing rock", lavalamp = "Groovy, baby", floorlamp = "Soft, cozy light", neoncup = "Always open",
  hmus = "Spooky fall vibes", xmus = "Cozy winter vibes",
  itemstand = "A table spot on the floor", tiffanytab = "Stained glass for tables",
}
-- grid spots. The wall has three free spots (the name sign uses the last two).
CAFE.WSLOT = { { 3, 21, 24, 28 }, { 272, 21, 43, 28 }, { 319, 21, 43, 28 }, { 224, 21, 24, 28 }, { 200, 21, 24, 28 }, { 248, 21, 24, 28 } }   -- (the 4th is where the fridge used to be)   -- x, y, w, h
CAFE.XSLOT = { { 112, 61 }, { 150, 61 }, { 190, 61 }, { 230, 61 }, { 268, 61 }, { 304, 61 }, { 340, 61 } }   -- the lower row of the wall
-- All wall decor (clocks, pictures, signs) share one set of tiles: the six up by the ceiling, then the seven below them.
CAFE.TILES = {}
for i, sl in ipairs(CAFE.WSLOT) do CAFE.TILES[i] = { sl[1], sl[2], sl[3], sl[4] } end
for j, sl in ipairs(CAFE.XSLOT) do CAFE.TILES[#CAFE.WSLOT + j] = { sl[1] - 19, 51, 38, 20 } end
function CAFE.gk(kind) return (kind == "tiny") and "wall" or kind end         -- tiny pictures live on the same grid as wall decor
function CAFE.tileCenter(i) local t = CAFE.TILES[i]; return t[1] + math.floor(t[3] / (2)), t[2] + math.floor(t[4] / (2)) end
CAFE.CSLOT = { { 91, 81 }, { 165, 81 }, { 236, 81 }, { 302, 81 }, { 361, 81 }, { 20, 81 } }   -- blank spots on the counter: each one is exactly halfway across the gap between the two machines beside it (6: the end of the counter, left of the register)
-- how far (in pixels, either side of the middle of a spot) something can reach before it would come within 2 pixels of a machine
CAFE.SCAP = { { -17, 17 }, { -17, 17 }, { -20, 20 }, { -12, 12 }, { -11, 11 }, { -18, 17 } }
-- how far each wide counter thing really reaches (measured over every frame of its animation); anything not listed is 21 wide or less
CAFE.AEXT = { saltlamp = { -17, 17 }, cradle = { -15, 14 }, luckycat = { -9, 18 }, miniplaydate = { -14, 13 }, snaketank = { -13, 14 },
              boombox = { -12, 12 }, record = { -12, 11 }, aquarium = { -12, 10 }, incense = { -11, 11 }, radio = { -11, 11 }, tiffanytab = { -12, 12 } }
CAFE.ADX = { aquarium = 1, luckycat = -4 }          -- a nudge so the whole thing sits in the middle of its spot
function CAFE.fitsSlot(id, i)                       -- does this thing fit the counter spot without touching the machines beside it?
  local cap, e = CAFE.SCAP[i], id and CAFE.AEXT[id]
  if not cap or not e then return true end
  local dx = CAFE.ADX[id] or 0
  return e[1] + dx >= cap[1] and e[2] + dx <= cap[2]
end
-- floor spots hug the walls: down the left, in the right-hand corner, and along the counter
CAFE.FSLOT = { { 20, 134 }, { 20, 170 }, { 20, 204 }, { 382, 132 }, { 100, 130 }, { 200, 130 }, { 300, 130 }, { 298, 206 } }   -- (the last one is by the left end of the corner bench)
-- where the tables can go (the first four match the original row along the bottom)
-- the six table spots: 1-3 along the bottom, 5-7 evenly spaced above them (spot 4's old square is a floor decor spot now)
CAFE.TSLOT = { { 132, 208 }, { 186, 208 }, { 240, 208 }, { 294, 208 }, { 132, 170 }, { 186, 170 }, { 240, 170 } }
CAFE.TFREE = { 1, 2, 3, 5, 6, 7 }
function CAFE.tableSpots(k) return CAFE.TFREE end
function CAFE.applyLayout(d)
  if not CAFE.defT then
    CAFE.defT, CAFE.defS = {}, {}
    for i, t in ipairs(TABLES) do CAFE.defT[i] = { t.x, t.y } end
    for i, q in ipairs(SEATS) do CAFE.defS[i] = { q.x, q.y } end
  end
  for i, t in ipairs(CAFE.defT) do TABLES[i].x, TABLES[i].y = t[1], t[2] end
  for i, q in ipairs(CAFE.defS) do SEATS[i].x, SEATS[i].y = q[1], q[2] end
  if d then
    for k = 1, 4 do
      local sl = d.tables[k] and CAFE.TSLOT[d.tables[k]]
      if sl then
        TABLES[k].x, TABLES[k].y = sl[1], sl[2]
        SEATS[2 * k - 1].x, SEATS[2 * k - 1].y = sl[1] - 17, sl[2]
        SEATS[2 * k].x, SEATS[2 * k].y = sl[1] + 17, sl[2]
      end
    end
  end
end
CAFE.slots = {}
CAFE.sel, CAFE.mode, CAFE.erase = 1, "slots", nil
CAFE.name, CAFE.letter, CAFE.crank, CAFE.onDone = "", 0, 0, false
CAFE.shopSel, CAFE.scroll, CAFE.report, CAFE.msg, CAFE.msgT = 1, 0, nil, nil, 0
CAFE.tab, CAFE.focus, CAFE.crankAcc, CAFE.tabPos = 1, "tabs", 0, 1       -- shop: which tab, list or bottom buttons, crank scrolling
CAFE.cur, CAFE.slot = nil, 1
CAFE.pend, CAFE.spots, CAFE.spotSel = nil, {}, 1

function CAFE.seatsOf(step) if step <= 0 then return 0 end return CAFE.SEAT_N[step] end
function CAFE.seatOffOf(d)                     -- seats that belong to tables you've switched off
  local off = {}
  for k = 1, 4 do
    if d.off and d.off[k] then off[2 * k - 1] = true; off[2 * k] = true end
  end
  return off
end
function CAFE.seatCountOf(d)
  local n, off = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d)
  for i in pairs(off) do if i <= CAFE.seatsOf(d.seatStep) then n = n - 1 end end
  return n
end

function CAFE.fresh(name)
  local rich = (string.upper(name or "") == "RICH")      -- test cheat: $99999 to start, and nobody gets impatient
  return { v = 2, tv = 2, name = name, money = rich and 9999900 or 0, cups = 0, seatStep = 0, stars = 0, decor = {}, place = {}, tables = {}, off = {}, shifts = 0 }
end

-- ---- grid bookkeeping ----------------------------------------------------------------
function CAFE.slotTaken(d, kind, slot)
  kind = CAFE.gk(kind)
  if kind == "wall" and d.sign ~= false and (slot == 2 or slot == 3) then return true end
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.gk(it.kind) == kind and d.decor[it.id] == "on" and d.place[it.id] == slot then return true end
  end
  return false
end

function CAFE.isGrid(it) return it.kind == "wall" or it.kind == "floor" or it.kind == "counter" or it.kind == "tiny" end

function CAFE.tableOn(d, k)                    -- is table k standing in the cafe (so something can sit in the middle of it)?
  if k == 5 then return (d.seatStep or 0) >= 5 end
  return k >= 1 and k <= 4 and k <= (d.seatStep or 0) and not (d.off and d.off[k]) and (d.tables[k] or 0) > 0
end

function CAFE.standSpots(d)                    -- the floor spots that have an Item stand standing on them (you can own several)
  local out = {}
  for k = 1, CAFE.copyCount(d, "itemstand") do
    local cid = CAFE.copyId("itemstand", k)
    if d.decor[cid] == "on" and d.place[cid] then out[#out + 1] = d.place[cid] end
  end
  return out
end
function CAFE.topOn(d, pl)                     -- is there something to stand on at this counter-style spot? (1-5 counter, 11-15 a table, 21-28 an Item stand)
  if pl <= 10 then return true end
  if pl <= 15 then return CAFE.tableOn(d, pl - 10) end
  if pl <= 20 then return false end
  for _, f in ipairs(CAFE.standSpots(d)) do if f == pl - 20 then return true end end
  return false
end
function CAFE.topXY(pl)                        -- where the things on a table / stand are drawn
  if pl > 20 then local sl = CAFE.FSLOT[pl - 20]; return sl[1], sl[2] - 10 end
  local t = TABLES[pl - 10]; return t.x, t.y - 7
end

function CAFE.freeSlots(d, kind, id)
  kind = CAFE.gk(kind)
  local n = (kind == "wall") and #CAFE.TILES or ((kind == "counter") and #CAFE.CSLOT or #CAFE.FSLOT)
  if kind == "wall" and id == "cuckoo" then n = #CAFE.WSLOT end        -- (its pendulum needs the tall tiles up top)
  local list = {}
  for i = 1, n do
    if not CAFE.slotTaken(d, kind, i) and (kind ~= "counter" or CAFE.fitsSlot(id, i)) then list[#list + 1] = i end
  end
  if kind == "counter" then                         -- the middle of each table is a counter-style spot too (11 = table 1 ... 15 = the nook table)
    for k = 1, 5 do
      if CAFE.tableOn(d, k) and not CAFE.slotTaken(d, kind, 10 + k) then list[#list + 1] = 10 + k end
    end
    for _, sf in ipairs(CAFE.standSpots(d)) do          -- an Item stand turns its floor spot into a table spot too
      if not CAFE.slotTaken(d, kind, 20 + sf) then list[#list + 1] = 20 + sf end
    end
  end
  if kind == "wall" then
    table.sort(list, function(a, b)
      local ta, tb = CAFE.TILES[a], CAFE.TILES[b]
      if ta[2] ~= tb[2] then return ta[2] < tb[2] end
      return ta[1] < tb[1]
    end)
  end
  return list
end

function CAFE.fixPlacement(d)               -- old saves / odd data: give everything a legal spot
  local old = {}
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.isGrid(it) and d.decor[it.id] == "on" then
      old[it.id] = d.place[it.id]
      d.place[it.id] = nil
    end
  end
  local order = {}                                   -- (the Item stands first, so what stands on them can find their spots)
  for _, it in ipairs(CAFE.ITEMS) do if it.id == "itemstand" or it.copyOf == "itemstand" then order[#order + 1] = it end end
  for _, it in ipairs(CAFE.ITEMS) do if not (it.id == "itemstand" or it.copyOf == "itemstand") then order[#order + 1] = it end end
  for _, it in ipairs(order) do
    if old[it.id] ~= nil or (CAFE.isGrid(it) and d.decor[it.id] == "on") then
      local want = old[it.id]
      local free = CAFE.freeSlots(d, it.kind, it.id)
      local ok = false
      for _, f in ipairs(free) do if f == want then ok = true end end
      if ok then d.place[it.id] = want
      elseif #free > 0 then d.place[it.id] = free[1]
      else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.fixTops(d)                      -- a table went away or was switched off: what stood on it moves to the counter
  for _, it in ipairs(CAFE.ITEMS) do
    local pl = d.place[it.id]
    if it.kind == "counter" and d.decor[it.id] == "on" and pl and pl > 10 and not CAFE.topOn(d, pl) then
      d.place[it.id] = nil
      local free = CAFE.freeSlots(d, "counter", it.id)
      if #free > 0 then d.place[it.id] = free[1] else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.fixTables(d)                    -- old saves: every table gets one of the six spots, none doubled up
  local taken = {}
  for k = 1, math.min(d.seatStep, 4) do
    if d.off[k] then d.tables[k] = 0
    else
      local t = d.tables[k]
      local ok = false
      for _, f in ipairs(CAFE.TFREE) do if f == t then ok = true end end
      if not ok or taken[t] then
        t = nil
        for _, f in ipairs(CAFE.TFREE) do if not taken[f] then t = f; break end end
      end
      d.tables[k] = t
      taken[t] = true
    end
  end
end

function CAFE.read(i)
  local ok, d = pcall(pd.datastore.read, "cafe" .. i)
  if not ok or type(d) ~= "table" or type(d.name) ~= "string" then return nil end
  d.money = tonumber(d.money) or 0
  d.cups = clamp(math.floor(tonumber(d.cups) or 2), 0, 10)
  d.seatStep = clamp(math.floor(tonumber(d.seatStep) or 0), 0, 5)
  d.stars = clamp(tonumber(d.stars) or 0, 0, 5)
  d.lvl = clamp(math.floor(tonumber(d.lvl) or 1), 1, 999)
  d.pstreak = math.max(0, math.floor(tonumber(d.pstreak) or 0))
  d.boostT = (tonumber(d.boostT) or 0) > 0 and tonumber(d.boostT) or nil
  d.boostS = (tonumber(d.boostS) or 0) > 0 and tonumber(d.boostS) or nil
  d.char = clamp(math.floor(tonumber(d.char) or 1), 1, 3)
  d.shifts = tonumber(d.shifts) or 0
  if type(d.decor) ~= "table" then d.decor = {} end
  if type(d.place) ~= "table" then d.place = {} end
  if type(d.tables) ~= "table" then d.tables = {} end
  if type(d.off) ~= "table" then d.off = {} end
  CAFE.fixTables(d)
  CAFE.ensureCopies(d)                           -- (copies you bought of floor and table-top decor)
  CAFE.fixVines(d)
  if d.decor.hmus == "on" and d.decor.xmus == "on" then d.decor.xmus = "off" end      -- (one season's music at a time)
  if d.tv ~= 2 then                              -- older saves: the little pictures were numbered on their own row
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "tiny" and d.place[it.id] then d.place[it.id] = d.place[it.id] + #CAFE.WSLOT end
    end
    d.tv = 2
  end
  CAFE.fixPlacement(d)
  return d
end

CAFE.NAME_MAX = 13                              -- the longest cafe name: the most letters that sit properly inside the wall sign and the shop preview
function CAFE.cafeName()                       -- the name of the cafe you're in, found wherever it's kept (never blank)
  local function ok(n) return type(n) == "string" and n:gsub("%s", "") ~= "" end
  local c = CAFE.cur
  if c and ok(c.name) then return c.name end
  local sl = CAFE.slot and CAFE.slots and CAFE.slots[CAFE.slot]
  if sl and ok(sl.name) then return sl.name end
  if G and G.cafe and ok(G.cafe.name) then return G.cafe.name end
  if CAFE.slot then                              -- straight from the save file
    local okr, d = pcall(pd.datastore.read, "cafe" .. CAFE.slot)
    if okr and type(d) == "table" and ok(d.name) then return d.name end
  end
  if ok(CAFE.name) then return CAFE.name end
  return "COFFEE"
end

function CAFE.rich() return G ~= nil and G.mode == "cafe" and G.cafe ~= nil and string.upper(G.cafe.name or "") == "RICH" end

function CAFE.preRead()                          -- (idle on the title screen) read your saves one a frame; true once all three are in
  local pre = CAFE.pre
  if pre == nil then pre = { n = 0 }; CAFE.pre = pre end
  if pre.n < 3 then
    pre.n = pre.n + 1
    pre[pre.n] = CAFE.read(pre.n) or false
  end
  return pre.n >= 3
end

function CAFE.write()
  CAFE.rc = nil
  CAFE.pre = nil
  if CAFE.cur then pcall(pd.datastore.write, CAFE.cur, "cafe" .. CAFE.slot) end
  if CAFE.cur then UI.achCheck() end
  UI.metaSave()
end

function CAFE.addStars(d)
  if G and G.cafe then G.cafe.stars = clamp(math.floor((G.cafe.stars + d) * 100 + 0.5) / 100, 0, 5) end
end

-- a slip-up costs a little of a star; the more you've decorated, the less customers mind
function CAFE.mistake(amt)
  if not (G and G.mode == "cafe" and G.cafe) then return end
  local n = G.cafe.seatStep or 0
  for _, v in pairs(G.cafe.decor) do if v == "on" then n = n + 1 end end
  local mult = clamp(1 - 0.025 * n, 0.25, 1)
  CAFE.addStars(-amt * mult)
end

function CAFE.petOn(d, species)                 -- which cat / dog (if any) is out in the cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.species == species and d.decor[it.id] == "on" then return it.id end
  end
  return nil
end

function CAFE.hasNeed(d, need)                  -- cat tree wants a cat of any coat, dog bed any dog
  if need == "cat" or need == "dog" then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.species == need and d.decor[it.id] ~= nil then return true end
    end
    return false
  end
  return d.decor[need] ~= nil
end

function CAFE.petCount()
  local d = G and G.cafe
  if not d then return 0 end
  return (CAFE.petOn(d, "cat") and 1 or 0) + (CAFE.petOn(d, "dog") and 1 or 0) + (CAFE.petOn(d, "turtle") and 1 or 0)
end

-- ---- customer flow: it ebbs and flows, but never goes dead ---------------------------------------
function CAFE.flowUpdate(dt)
  local f = G.flow
  f.timer = f.timer - dt
  if f.timer <= 0 then
    f.target = math.random()
    f.timer = 25 + math.random() * 40
  end
  f.m = f.m + (f.target - f.m) * math.min(1, dt * 0.15)
  -- Busy and quiet spells (a cafe of 3 stars or more): a busy spell of a minute or so, then nobody new comes in until the line has been
  -- served, and then 10 to 15 seconds with nobody at the register at all: time for the dishes. Then it gets busy again.
  if G.mode == "cafe" and (G.cafe.stars or 0) >= 3 then
    local dirty = G.cups and G.cups.dirty or 0
    if not G.phase then G.phase, G.phaseT, G.phaseLen = "busy", 0, 30 + math.random() * 25 end
    G.phaseT = G.phaseT + dt
    if G.phase == "busy" then
      if G.phaseT >= G.phaseLen or (#G.line >= LINE_MAX and G.phaseT >= 15) or (dirty >= 4 and G.phaseT >= 15) then G.phase, G.phaseT = "drain", 0 end     -- (a full line, or four dirty cups piling up, cuts it short)
    else
      if G.arriveIn < 1 then G.arriveIn = 1 end
      if G.phase == "drain" then
        if (#G.line == 0 and G.cust == nil) or G.phaseT > 120 then G.phase, G.phaseT, G.phaseLen = "quiet", 0, (dirty >= 4) and (14 + math.random()) or (10 + math.random() * 5) end
      elseif G.phaseT >= G.phaseLen then
        G.phase, G.phaseT, G.phaseLen = "busy", 0, 30 + math.random() * 25
        G.arriveIn = 1 + math.random() * 2                       -- the first of the next busy spell is already at the door
      end
    end
  end
  -- nobody here at all? don't leave the shop empty for long
  if #G.line == 0 and G.cust == nil and G.arriveIn > 16 and (G.phase == nil or G.phase == "busy") then G.arriveIn = 16 end
end

-- how likely a new customer is to join, given how many people the line would hold with them in it:
-- a new cafe keeps short lines, and only a well-liked one gets a long queue
function CAFE.admit(n)
  local st = G.cafe.stars or 0
  local t
  if st < 2 then t = { 1, 0.5, 0.1, 0 }
  elseif st < 3 then t = { 1, 0.9, 0.3, 0 }
  elseif st < 4 then t = { 1, 1, 0.7, 0.2 }
  else t = { 1, 1, 1, 0.6 } end
  return math.random() < (t[n] or 0)
end

function CAFE.gap(lo, span)
  local f = G.flow
  local factor = 1.55 - 1.0 * f.m                      -- quiet spell 1.55x, rush 0.55x
  if math.random() < 0.14 then return 2.5 + math.random() * 3 end   -- a friend tags along
  return (lo + math.random() * span) * factor
end

-- ---- stars ---------------------------------------------------------------------------------------
CAFE.starImgs = {}
function CAFE.starImg(r, kind)                       -- a ready-made pixel star (made once per size): "f" full, "h" half, "e" empty
  local key = r * 10 + (kind == "f" and 1 or kind == "h" and 2 or 3)
  local im = CAFE.starImgs[key]
  if im ~= nil then return im end
  local S, c = 2 * r + 3, r + 1
  local vx, vy = {}, {}
  for i = 0, 9 do
    local a = -math.pi / 2 + i * math.pi / 5
    local rr = (i % 2 == 0) and (r + 1.0) or (r + 1.0) * 0.45
    vx[i + 1] = c + 0.5 + math.cos(a) * rr
    vy[i + 1] = c + 0.8 + math.sin(a) * rr
  end
  local function inside(x, y)                        -- even-odd test against the ten corners
    local ins = false
    local j = 10
    for i = 1, 10 do
      if (vy[i] > y) ~= (vy[j] > y) and x < (vx[j] - vx[i]) * (y - vy[i]) / (vy[j] - vy[i]) + vx[i] then ins = not ins end
      j = i
    end
    return ins
  end
  local mask = {}
  for py = 0, S - 1 do
    for px = 0, S - 1 do mask[py * S + px] = inside(px + 0.5, py + 0.5) end
  end
  im = gfx.image.new(S, S, gfx.kColorClear)
  gfx.pushContext(im)
  gfx.setColor(BLACK)
  for py = 0, S - 1 do
    for px = 0, S - 1 do
      if mask[py * S + px] then
        local edge = px == 0 or py == 0 or px == S - 1 or py == S - 1
          or not (mask[py * S + px - 1] and mask[py * S + px + 1] and mask[(py - 1) * S + px] and mask[(py + 1) * S + px])
        local left = px + 0.5 < c + 0.5
        if kind == "f" or edge or (kind == "h" and left) then gfx.drawPixel(px, py) end
      end
    end
  end
  gfx.popContext()
  CAFE.starImgs[key] = im
  return im
end

function CAFE.star(cx, cy, r, fill, color)
  local kind = (fill >= 0.75) and "f" or (fill >= 0.25) and "h" or "e"
  local im = CAFE.starImg(r, kind)
  gfx.setImageDrawMode(color == WHITE and gfx.kDrawModeFillWhite or gfx.kDrawModeFillBlack)
  im:draw(cx - r - 1, cy - r - 1)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

function CAFE.drawStars(x0, cy, r, gap, value, color, lvl)
  for i = 1, 5 do
    if lvl and UI.starHook then UI.starHook(lvl, i) end      -- (PC: every barista level has its own colour of star, with a shine running over them)
    CAFE.star(x0 + (i - 1) * gap, cy, r, clamp(value - (i - 1), 0, 1), color)
  end
  UI.starTint = nil
  gfx.setColor(BLACK)
end

-- text squeezed to fit a box (scaled down if it's too wide)
CAFE.fitCache = {}
function CAFE.fitText(str, cx, cy, maxW, maxH, thinMax)
  gfx.setFont(fontBold)
  local w, h = gfx.getTextSize(str)
  if w <= maxW then
    drawTC(str, cx, cy - math.floor(h / (2)), true)
    return
  end
  local up = string.upper(str)
  if thinMax and UI.thinWidth(up) <= thinMax then            -- too wide for the bold font: small clear capitals instead
    gfx.setColor(BLACK)
    UI.thinText(up, cx - math.floor(UI.thinWidth(up) / (2)), cy - 3)
    return
  end
  local img = CAFE.fitCache[str]
  if img == nil then
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      drawT(str, 0, 0, true)
      gfx.popContext()
    end)
    if not ok then img = false end
    CAFE.fitCache[str] = img
  end
  if img then
    local k = maxW / w
    img:drawScaled(cx - math.floor(w * k / 2), cy - math.floor(h * k / 2), k)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    return
  end
  drawTC(string.sub(str, 1, 7) .. "..", cx, cy - math.floor(h / (2)), true)
end

-- ---- decoration art: every piece is drawn around a centre point ----------------------------------
CAFE.art = {}
local function A() return CAFE.art end

function CAFE.art.clock(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 11)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 11)
  gfx.setLineWidth(1)
  for h = 0, 11 do
    local a = h * math.pi / 6
    gfx.drawLine(math.floor(cx + math.sin(a) * 8), math.floor(cy - math.cos(a) * 8),
                 math.floor(cx + math.sin(a) * 9.5), math.floor(cy - math.cos(a) * 9.5))
  end
  local t = (G and G.t) or 0
  local am = t * 0.105
  local ah = am / 12 + 1
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 8), math.floor(cy - math.cos(am) * 8))
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 5), math.floor(cy - math.cos(ah) * 5))
  gfx.setLineWidth(1)
end

-- ---- candles: a flickering flame and a little curl of smoke ---------------------------------------------
function CAFE.flame(x, y, seed, big)             -- x, y = the bottom of the flame; it leans and bobs
  local ph = (math.floor(frames / (4)) + (seed or 0)) % 4
  local lean = (ph == 1) and -1 or ((ph == 3) and 1 or 0)
  local h = big and 6 or 4
  if ph == 2 then h = h - 1 end
  UI.inkPush("flame")
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(x, y - 1, big and 2 or 1)
  gfx.fillTriangle(x - (big and 2 or 1), y - 1, x + (big and 2 or 1), y - 1, x + lean, y - 1 - h)
  gfx.setColor(WHITE)
  gfx.drawPixel(x, y - 1)
  if big then gfx.drawPixel(x, y - 2) end
  UI.inkPop()
  gfx.setColor(BLACK)
end

function CAFE.smoke(x, y, seed)                  -- y = just above the flame; three pixels drift up and fade away
  UI.ink("gray")
  gfx.setColor(BLACK)
  for j = 0, 2 do
    local tt = (math.floor(frames / (3)) + (seed or 0) * 5 + j * 4) % 12
    if tt >= 1 and tt <= 10 then
      gfx.drawPixel(x + math.floor(math.sin(tt * 0.8 + (seed or 0) + j) * (1 + tt / 5) + 0.5), y - 1 - tt)
    end
  end
end

function CAFE.art.candle1(cx, cy)                -- a fat pillar candle on a dish, wax pooling at the top, with drips
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 8, cy + 8, 17, 3, 1)                       -- the dish (an odd width, so it sits dead centre)
  gfx.fillRect(cx - 3, cy + 7, 7, 1)
  UI.ink("rose")
  gfx.setColor(WHITE); gfx.fillRect(cx - 4, cy - 1, 9, 9)
  gfx.setColor(BLACK); gfx.drawRect(cx - 4, cy - 1, 9, 9)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 4, cy - 3, 9, 5)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 4, cy - 3, 9, 5)  -- the melted top
  gfx.drawLine(cx - 2, cy + 1, cx - 2, cy + 4); gfx.drawLine(cx + 2, cy + 1, cx + 2, cy + 3)   -- drips
  gfx.drawPixel(cx - 2, cy + 5); UI.ink("none"); gfx.drawLine(cx, cy - 1, cx, cy - 2)
  CAFE.flame(cx, cy - 3, 0, true)
  CAFE.smoke(cx, cy - 10, 0)
end

function CAFE.art.candle2(cx, cy)                -- a tall taper in a brass-style holder
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 6, cy + 9, 13, 2, 1)                       -- saucer
  gfx.fillRect(cx - 1, cy + 4, 3, 6)                                 -- stem
  gfx.fillCircleAtPoint(cx, cy + 7, 2)                               -- a bead on the stem
  gfx.fillPolygon(cx - 4, cy + 3, cx + 4, cy + 3, cx + 2, cy + 6, cx - 2, cy + 6)      -- the cup
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillRect(cx - 1, cy - 9, 3, 12)
  gfx.setColor(BLACK); gfx.drawRect(cx - 1, cy - 9, 3, 12)
  UI.ink("none")
  gfx.drawLine(cx, cy - 9, cx, cy - 10)
  CAFE.flame(cx, cy - 10, 1, false)
  CAFE.smoke(cx, cy - 16, 1)
end

function CAFE.art.candle3(cx, cy)                -- three tealights in a little dish
  UI.ink("skyp")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 10, cy + 6, 21, 4, 2)                      -- (odd width: centred under the middle light)
  for i = -1, 1 do
    local x = cx + i * 7
    local y = cy + 2 + ((i == 0) and -2 or 0)
    UI.ink("gray")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y + 1, 5, 4, 1)
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 2, y + 1, 5, 4, 1)
    CAFE.flame(x, y + 1, i + 2, false)
  end
  CAFE.smoke(cx, cy - 6, 2)
end

function CAFE.art.candle4(cx, cy)                -- a candle in a glass jar with a label
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRoundRect(cx - 6, cy - 1, 13, 12, 2)
  gfx.setColor(BLACK); gfx.drawRoundRect(cx - 6, cy - 1, 13, 12, 2)
  UI.ink("lav")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 5, cy + 4, 11, 6); gfx.setColor(BLACK)
  UI.ink("cream")
  gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy + 5, 7, 3)
  gfx.setColor(BLACK); gfx.drawRect(cx - 3, cy + 5, 7, 3)
  UI.ink("none")
  gfx.drawLine(cx, cy + 1, cx, cy + 3)
  CAFE.flame(cx, cy + 2, 3, true)
  UI.ink("slate")
  gfx.fillRect(cx - 7, cy - 2, 15, 2)                      -- the jar's rim
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy + 2); gfx.drawPixel(cx - 5, cy + 3); gfx.setColor(BLACK)   -- a shine on the glass
  CAFE.smoke(cx, cy - 6, 3)
end

function CAFE.art.candle5(cx, cy)                -- a three-armed candelabra
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 6, cy + 9, 13, 2, 1)
  gfx.fillRect(cx - 1, cy + 1, 3, 9)
  gfx.fillCircleAtPoint(cx, cy + 6, 2)
  gfx.drawLine(cx, cy + 3, cx - 8, cy - 1); gfx.drawLine(cx, cy + 3, cx + 8, cy - 1)
  gfx.drawLine(cx - 8, cy - 1, cx - 8, cy + 1); gfx.drawLine(cx + 8, cy - 1, cx + 8, cy + 1)
  for i = -1, 1 do
    local x = cx + i * 8
    local top = (i == 0) and cy - 7 or cy - 5
    UI.ink("cream")
    gfx.setColor(WHITE); gfx.fillRect(x - 1, top, 3, 7)
    gfx.setColor(BLACK); gfx.drawRect(x - 1, top, 3, (i == 0) and 9 or 6)
    CAFE.flame(x, top - 1, i + 1, false)
  end
  CAFE.smoke(cx, cy - 14, 4)
end

function CAFE.art.candle6(cx, cy)                -- a little lantern with a candle inside
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(cx, cy - 6, 3)                    -- the carrying ring
  gfx.fillRect(cx - 5, cy - 3, 11, 2)
  gfx.fillRect(cx - 6, cy + 9, 13, 2)
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillRect(cx - 5, cy - 1, 11, 10)
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 1, 11, 10)
  gfx.drawLine(cx - 2, cy - 1, cx - 2, cy + 9); gfx.drawLine(cx + 2, cy - 1, cx + 2, cy + 9)
  UI.ink("redp")
  gfx.fillRect(cx - 1, cy + 5, 3, 4)                      -- the candle
  CAFE.flame(cx, cy + 4, 1, false)
  UI.ink("inkorange")
  local g = (math.floor(frames / (6))) % 2                              -- the glow flickers round the glass
  gfx.drawPixel(cx - 8 - g, cy + 3); gfx.drawPixel(cx + 8 + g, cy + 3); gfx.drawPixel(cx - 8, cy + 6 + g); gfx.drawPixel(cx + 8, cy + 6 + g)
  CAFE.smoke(cx, cy - 9, 5)
end

function CAFE.art.candle7(cx, cy)                -- candles floating in a bowl of water
  UI.ink("skyp")
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(cx - 10, cy + 3, 21, 8)           -- (an odd width: the bowl is centred on the same column as everything else)
  UI.ink("water")
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 8, cy + 4, 17, 4)
  gfx.setColor(BLACK)
  local rp = (math.floor(frames / (6))) % 3                              -- ripples
  gfx.drawEllipseInRect(cx - 4 - rp, cy + 5 - math.floor(rp / (2)), 9 + rp * 2, 2 + rp)
  for _, o in ipairs({ { -5, 0 }, { 5, 1 } }) do
    local x, y = cx + o[1], cy + 3 + o[2]
    UI.ink(o[1] < 0 and "rose" or "cream")
    gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y - 1, 5, 4, 1)
    gfx.setColor(BLACK); gfx.drawRoundRect(x - 2, y - 1, 5, 4, 1)
    CAFE.flame(x, y - 1, o[1] + 4, false)
  end
  CAFE.smoke(cx, cy - 4, 6)
end

function CAFE.art.incense(cx, cy)                -- a stick of incense burning in a wooden holder, smoke curling up
  local t = frames
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 11, cy + 8, 23, 3, 1)                          -- the long thin holder
  gfx.fillRect(cx - 9, cy + 11, 3, 1); gfx.fillRect(cx + 7, cy + 11, 3, 1)             -- its little feet
  gfx.fillRect(cx - 8, cy + 6, 3, 2)                                    -- the stick goes into this bump
  local tx, ty = cx + 3, cy - 8                                          -- the glowing tip
  UI.ink("berry")
  gfx.drawLine(cx - 7, cy + 7, tx - 2, ty + 5)                           -- the unburnt stick
  UI.ink("gray")
  for i = 0, 2 do gfx.drawPixel(tx - 2 + i, ty + 5 - math.floor(i * 5 / (2))) end     -- the burnt part: a dotted ash line
  UI.ink("flame")
  if (math.floor(t / (5))) % 2 == 0 then                                              -- the ember glows and dims
    gfx.fillCircleAtPoint(tx, ty + 1, 1); gfx.drawPixel(tx + 2, ty + 1); gfx.drawPixel(tx - 2, ty + 1); gfx.drawPixel(tx, ty - 1)
  else
    gfx.drawPixel(tx, ty + 1); gfx.drawPixel(tx - 1, ty + 1); gfx.drawPixel(tx, ty)
  end
  UI.ink("gray")
  local f = t % 90                                                       -- a flake of ash drops now and then
  if f < 16 then gfx.drawPixel(tx - 2, ty + 6 + f - math.floor(f / (6))) end
  for j = 1, 18 do                                                       -- the main curl of smoke, thick at the bottom and fading to dots
    if j < 11 or j % 2 == 0 then
      local x = tx + math.floor(math.sin(j * 0.4 - t * 0.14) * (0.8 + j * 0.16) + 0.5)
      gfx.drawPixel(x, ty - 2 - j)
      if j < 7 then gfx.drawPixel(x + 1, ty - 2 - j) end
    end
  end
  for j = 3, 11 do                                                        -- and a faint second wisp that drifts the other way
    if j % 2 == 1 then gfx.drawPixel(tx + 3 + math.floor(math.sin(j * 0.6 - t * 0.2 + 2) * (0.8 + j * 0.1) + 0.5), ty - 2 - j) end
  end
end

-- ---- animated signs: they sit on the wall tiles (about 22 x 16 each) ----------------------------------
function CAFE.neonPlate(cx, cy)                  -- the dark board the neon tubes are fixed to
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 11, cy - 9, 22, 18, 4)
  gfx.setColor(WHITE)
end

function CAFE.pix(rows, x0, y0, ch)              -- the ch ("X") pixels of a little text picture, in the current colour
  ch = ch or "X"
  for y = 1, #rows do
    local r = rows[y]
    for x = 1, #r do if string.sub(r, x, x) == ch then gfx.drawPixel(x0 + x - 1, y0 + y - 1) end end
  end
end

-- neon tubes, drawn as clean pixel pictures (a thin tube, and the same tube glowing brighter)
CAFE.NHEART = { "..XXX...XXX..", ".X...X.X...X.", "X.....X.....X", "X...........X", "X...........X", ".X.........X.",
                "..X.......X..", "...X.....X...", "....X...X....", ".....X.X.....", "......X......" }
CAFE.NHEART2 = { "..XXX...XXX..", ".XXXXX.XXXXX.", "XXX..XXX..XXX", "XX.........XX", "XX.........XX", ".XX.......XX.",
                 "..XX.....XX..", "...XX...XX...", "....XX.XX....", ".....XXX.....", "......X......" }
CAFE.NSTAR = { "......X......", ".....XoX.....", ".....XoX.....", "....XoooX....", "XXXXXoooXXXXX", "XoooooooooooX",
               ".XoooooooooX.", "..XoooooooX..", "...XoooooX...", "..XoooooooX..", "..XoooXoooX..", ".XooXX.XXooX.", ".XXX.....XXX." }

function CAFE.art.neonheart(cx, cy)
  CAFE.neonPlate(cx, cy)
  local beat = ({ 0, 1, 0, 0, 1, 0, 0, 0 })[(math.floor(frames / (4))) % 8 + 1]      -- a double heartbeat: the tube glows thick, then settles
  CAFE.pix(beat == 1 and CAFE.NHEART2 or CAFE.NHEART, cx - 6, cy - 6)
  if beat == 1 then gfx.drawPixel(cx - 9, cy - 7); gfx.drawPixel(cx + 8, cy - 7); gfx.drawPixel(cx - 9, cy + 5); gfx.drawPixel(cx + 8, cy + 5) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonbolt(cx, cy)
  CAFE.neonPlate(cx, cy)
  local f = (math.floor(frames / (3))) % 14
  if f ~= 4 and f ~= 5 and f ~= 9 then                                   -- it flickers off now and then
    gfx.fillPolygon(cx + 2, cy - 8, cx - 5, cy + 1, cx - 1, cy + 1, cx - 3, cy + 8, cx + 5, cy - 2, cx + 1, cy - 2)
  else
    gfx.drawLine(cx + 2, cy - 7, cx - 4, cy + 1)
  end
  if f == 0 or f == 6 then gfx.drawPixel(cx - 9, cy - 5); gfx.drawPixel(cx + 8, cy + 5) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonstar(cx, cy)
  CAFE.neonPlate(cx, cy)
  local f = frames % 60                                                                -- the tube stays lit; now and then the whole star flashes full
  if f < 4 or (f >= 8 and f < 11) then CAFE.pix(CAFE.NSTAR, cx - 6, cy - 7, "o") end
  CAFE.pix(CAFE.NSTAR, cx - 6, cy - 7)
  local t = (math.floor(frames / (7))) % 4                                             -- a twinkle hops round the corners
  local c = ({ { -9, -6 }, { 8, -6 }, { 8, 5 }, { -9, 5 } })[t + 1]
  gfx.drawPixel(cx + c[1], cy + c[2]); gfx.drawPixel(cx + c[1] + 1, cy + c[2]); gfx.drawPixel(cx + c[1], cy + c[2] + 1)
  gfx.setColor(BLACK)
end

function CAFE.art.neonmoon(cx, cy)
  CAFE.neonPlate(cx, cy)
  gfx.fillCircleAtPoint(cx - 2, cy, 7)
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx + 1, cy - 2, 6)
  gfx.setColor(WHITE)
  local t = (math.floor(frames / (9))) % 3
  if t ~= 1 then gfx.drawLine(cx + 5, cy - 5, cx + 5, cy - 1); gfx.drawLine(cx + 3, cy - 3, cx + 7, cy - 3) end
  if t ~= 0 then gfx.drawPixel(cx + 6, cy + 4); gfx.drawPixel(cx + 7, cy + 4) end
  gfx.setColor(BLACK)
end

function CAFE.art.neonarrow(cx, cy)
  CAFE.neonPlate(cx, cy)
  local on = (math.floor(frames / (6))) % 4                                           -- three chevrons light up one after another
  for i = 0, 2 do
    if on == i or on == 3 then
      local y = cy - 6 + i * 5
      gfx.drawLine(cx - 5, y, cx, y + 4); gfx.drawLine(cx, y + 4, cx + 5, y)
      gfx.drawLine(cx - 5, y + 1, cx, y + 5); gfx.drawLine(cx, y + 5, cx + 5, y + 1)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.art.discoball(cx, cy)
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy - 14, cx, cy - 6)
  gfx.fillRect(cx - 2, cy - 7, 5, 2)                                         -- the hook
  UI.ink("snow")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy + 1, 8)
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(cx, cy + 1, 8)
  gfx.setClipRect(cx - 8, cy - 7, 17, 17)
  for k = -1, 1 do gfx.drawLine(cx - 8, cy + 1 + k * 4, cx + 8, cy + 1 + k * 4) end      -- the mirror tiles
  local sh = (math.floor(frames / (4))) % 4
  for k = -2, 2 do
    local x = cx + ((k * 4 + sh * 2) % 16) - 8
    gfx.drawLine(x, cy - 7, x, cy + 9)
  end
  gfx.clearClipRect()
  local sh2 = (math.floor(frames / (5))) % 3                                              -- a few tiles flash dark as it turns
  for j = -1, 1 do
    for i = -1, 1 do
      if (i * 2 + j + sh2) % 4 == 0 then UI.ink(({ "lav", "skyp", "rose" })[(i + j + 3) % 3 + 1]); gfx.fillRect(cx + i * 4 - 1, cy + 1 + j * 4 - 1, 3, 3) end
    end
  end
  local a = frames * 0.12                                                    -- sparkles circle it
  for k = 0, 2 do
    local ang = a + k * 2.1
    local sx, sy = cx + math.floor(math.cos(ang) * 12), cy + 1 + math.floor(math.sin(ang) * 10)
    UI.ink(({ "inkpink", "inkblue", "inkyellow" })[k + 1])
    gfx.drawLine(sx - 1, sy, sx + 1, sy); gfx.drawLine(sx, sy - 1, sx, sy + 1)
  end
end

function CAFE.smooth(a, b, x)                    -- eases 0 -> 1 as x goes from a to b
  local k = (x - a) / (b - a)
  if k < 0 then k = 0 elseif k > 1 then k = 1 end
  return k * k * (3 - 2 * k)
end

function CAFE.art.aquarium(cx, cy)               -- two fish at different depths, bubbles rising, a swaying weed, and now and then a pinch of food
  local fl, sin = math.floor, math.sin
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(cx - 11, cy - 8, 22, 16)
  gfx.setColor(BLACK)
  UI.ink("water")
  gfx.setPattern(TEA); gfx.fillRect(cx - 10, cy - 4, 20, 11); gfx.setColor(BLACK)                    -- the water (light, so the fish stand out)
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 10, cy - 4, 20, 11); gfx.setColor(BLACK) end     -- (in colour: clear water, the fish show through)
  UI.ink("tan")
  if UI.color then gfx.setPattern(CHECK); gfx.fillRect(cx - 10, cy + 5, 20, 2); gfx.setColor(BLACK) end     -- gravel
  UI.ink("slate")
  gfx.setLineWidth(2); gfx.drawRect(cx - 11, cy - 8, 22, 16); gfx.setLineWidth(1)
  UI.ink("leaf")
  for j = 1, 3 do                                                                                       -- a strand of weed, swaying
    local x1 = cx + 7 + fl(sin(frames * 0.1 + j * 0.8) * j * 0.5 + 0.5)
    local x0 = cx + 7 + fl(sin(frames * 0.1 + (j - 1) * 0.8) * (j - 1) * 0.5 + 0.5)
    gfx.drawLine(x0, cy + 5 - (j - 1) * 2, x1, cy + 5 - j * 2)
  end
  local cyc = frames % 300                                                                              -- feeding time: flakes sink, the big fish comes up for them
  local feed = CAFE.smooth(205, 220, cyc) - CAFE.smooth(262, 280, cyc)
  local t2 = frames * 0.11 + 2                                                                          -- the little fish: fast, low down, black
  local c2 = cx - 1 + sin(t2) * 4
  local d2 = (math.cos(t2) >= 0) and 1 or -1
  local y2 = fl(cy + 3.5 + sin(t2 * 0.7) * 0.6)
  local b2 = fl(c2 + d2 * 1)
  UI.ink("inkorange")
  gfx.fillEllipseInRect(b2 - 2, y2 - 1, 5, 3)
  gfx.fillTriangle(b2 - d2 * 2, y2, b2 - d2 * 4, y2 - 1 + (math.floor(frames / (2))) % 2, b2 - d2 * 4, y2 + 1)
  local t1 = frames * 0.045                                                                             -- the big fish: slow, easing round at each end
  local c1 = cx - 0.5 + sin(t1) * 3.5 * (1 - feed * 0.5) - feed
  local d1 = (math.cos(t1) >= 0) and 1 or -1
  local y1 = fl(cy - 0.5 + sin(t1 * 1.7 + 1) * 1.2 - feed * 1)
  local bc = fl(c1 + d1 * 1.5)
  local wag = (math.floor(frames / ((feed > 0.4 and 2 or 4)))) % 2                                                   -- (a busier tail while it's feeding)
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(bc - 3, y1 - 2, 7, 5)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(bc - 3, y1 - 2, 7, 5)
  gfx.fillTriangle(bc - d1 * 3, y1, bc - d1 * 6, y1 - 2 + wag, bc - d1 * 6, y1 + 3 - wag)               -- the tail
  gfx.drawPixel(bc + d1 * 2, y1 - 1)                                                                    -- the eye
  gfx.drawPixel(bc - d1, y1 - 3)                                                                        -- the dorsal fin
  if feed > 0.5 and (math.floor(frames / (3))) % 2 == 0 then gfx.drawPixel(bc + d1 * 4, y1) end                      -- a nibble
  UI.ink("bark")
  if cyc > 200 and cyc < 280 then
    for k = 0, 2 do
      local age = cyc - 205 - k * 11
      if age >= 0 then
        local fy = cy - 4 + fl(age * 0.12)
        if fy <= cy + 4 then gfx.drawPixel(cx - 5 + k * 4 + fl(sin(age * 0.3 + k) + 0.5), fy) end
      end
    end
  end
  UI.ink("inkblue")
  for k = 0, 1 do                                                                                       -- bubbles rising from the gravel
    local p = ((frames + k * 20) % 40) / 40
    local by = cy + 4 - fl(p * 9)
    if by > cy - 4 then gfx.drawPixel(cx - 8 + fl(sin(p * 9 + k) * 1.2 + 0.5), by) end
  end
end

function CAFE.art.pinwheel(cx, cy)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy + 2, cx, cy + 13)
  local a = frames * 0.25
  for i = 0, 3 do
    local ang = a + i * math.pi / 2
    local x1, y1 = cx + math.floor(math.cos(ang) * 9), cy - 2 + math.floor(math.sin(ang) * 9)
    local x2, y2 = cx + math.floor(math.cos(ang + 0.9) * 6), cy - 2 + math.floor(math.sin(ang + 0.9) * 6)
    UI.ink(({ "redp", "yellow", "skyp", "leaf" })[i + 1])
    gfx.setColor((i % 2 == 0 and not UI.color) and BLACK or WHITE)
    gfx.fillTriangle(cx, cy - 2, x1, y1, x2, y2)
    gfx.setColor(BLACK)
    gfx.drawLine(cx, cy - 2, x1, y1); gfx.drawLine(x1, y1, x2, y2)
  end
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy - 2, 1)
  gfx.setColor(BLACK)
end

do                                              -- (the tank and the pinwheel were drawn for the wall: stand them on the counter / table line instead)
  local tank, wheel = CAFE.art.aquarium, CAFE.art.pinwheel
  CAFE.art.aquarium = function(cx, cy) tank(cx, cy + 2) end
  CAFE.art.pinwheel = function(cx, cy) wheel(cx, cy - 3) end
end

-- where a snake that loops round the tank is, a distance s along its track: along the front, round the end, back along the rear, round the other end
function CAFE.snakeAt(s)
  local a, r = 5, 3.4                               -- half the length of the straight bits, and how tight the ends turn
  local straight, turn = 2 * a, math.pi * r
  local per = 2 * straight + 2 * turn
  s = s % per
  if s < straight then return -a + s, r end
  s = s - straight
  if s < turn then local f = s / r; return a + r * math.sin(f), r * math.cos(f) end
  s = s - turn
  if s < straight then return a - s, -r end
  s = s - straight
  local f = s / r
  return -a - r * math.sin(f), -r * math.cos(f)
end

function CAFE.art.snaketank(cx, cy)             -- a terrarium: the snake slithers round and round, slowing now and then to flick its tongue
  local fl, sin, cos = math.floor, math.sin, math.cos
  local top, bot = cy - 8, cy + 11
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillRect(cx - 12, top, 25, bot - top)
  gfx.setColor(BLACK)
  UI.ink("tan")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 11, bot - 4, 23, 3) end
  gfx.setPattern(CHECK); gfx.fillRect(cx - 11, bot - 3, 23, 2); gfx.setColor(BLACK)         -- sandy floor
  UI.ink("slate")
  gfx.drawRect(cx - 12, top, 25, bot - top)
  gfx.fillRect(cx - 13, top - 2, 27, 2)                                                       -- the lid
  gfx.fillTriangle(cx + 4, top - 2, cx + 10, top - 2, cx + 7, top - 6)                       -- the heat lamp's hood
  UI.ink("leaf")
  -- one trip round its track takes 14 seconds; it slows right down twice a trip (that's when the tongue comes out)
  local Tc = 420
  local T = frames % Tc
  local w = 4 * math.pi / Tc
  local slow = 0.5 - 0.5 * cos(w * T)                                                          -- 0 = at its slowest
  local V = 41.4 / (0.625 * Tc)
  local sH = V * (0.625 * T - 0.375 * sin(w * T) / w) + 41.4 * ((math.floor(frames / (Tc))) % 2)
  local yc = cy + 2
  local function at(s)                                                                         -- a point on the track, with the slither wave across it
    local x, y = CAFE.snakeAt(s)
    local x2, y2 = CAFE.snakeAt(s + 0.4)
    local tx, ty = x2 - x, y2 - y
    local tl = math.sqrt(tx * tx + ty * ty); if tl < 0.001 then tl = 1 end
    tx, ty = tx / tl, ty / tl
    local wob = 0.7 * sin(s * 0.95 + frames * 0.05)
    return cx + x - ty * wob, yc + y + tx * wob, tx, ty
  end
  local pts = {}
  for i = 0, 9 do pts[i] = { at(sH - (9 - i) * 1.6) } end
  for i = 1, 9 do                                                                              -- thin at the tail and round the ends, fatter in the middle of the front lane
    local front = (pts[i][2] + pts[i - 1][2]) / 2 > yc - 0.5
    gfx.setLineWidth((i > 3 and front and math.abs(pts[i][4]) < 0.5) and 3 or 2)
    gfx.drawLine(fl(pts[i - 1][1] + 0.5), fl(pts[i - 1][2] + 0.5), fl(pts[i][1] + 0.5), fl(pts[i][2] + 0.5))
  end
  gfx.setLineWidth(1)
  local ex, ey, tx, ty = pts[9][1], pts[9][2], pts[9][3], pts[9][4]
  local hcx, hcy = fl(ex + tx * 1.5 + 0.5), fl(ey + ty * 1.5 + 0.5)
  local near = ey > yc - 0.5
  if math.abs(ty) > math.abs(tx) then gfx.fillEllipseInRect(hcx - 2, hcy - 3, 5, 7)           -- its head (upright while it turns)
  elseif near then gfx.fillEllipseInRect(hcx - 3, hcy - 2, 7, 5)
  else gfx.fillEllipseInRect(hcx - 2, hcy - 2, 5, 4) end                                       -- (smaller along the rear)
  gfx.setColor(WHITE)
  gfx.drawPixel(hcx + (tx >= 0 and 1 or -1), hcy - 1)                                          -- the eye
  gfx.drawPixel(fl(pts[4][1] + 0.5), fl(pts[4][2] + 0.5)); gfx.drawPixel(fl(pts[6][1] + 0.5), fl(pts[6][2] + 0.5))   -- the pattern on its back
  gfx.setColor(BLACK)
  local period = (slow < 0.35) and 34 or 120
  local fk = frames % period
  if fk < 7 then                                                                                -- the tongue flicks out and back
    local len = (fk < 4) and 4 or 3
    local ax, ay = (tx >= 0 and 1 or -1) * math.max(math.abs(tx), 0.6), math.max(-0.3, math.min(0.3, ty))
    local bx, by = fl(hcx + ax * 3.5 + 0.5), fl(hcy + ay * 3.5 + 0.5)
    local fx, fy = fl(hcx + ax * (3.5 + len) + 0.5), fl(hcy + ay * (3.5 + len) + 0.5)
    fx = math.max(cx - 9, math.min(cx + 9, fx))                                                -- (never through the glass)
    bx = math.max(cx - 9, math.min(cx + 9, bx))
    UI.ink("inkred")
    gfx.drawLine(bx, by, fx, fy)
    if fx > cx - 9 and fx < cx + 9 then gfx.drawPixel(fx + (tx >= 0 and 1 or -1), fy - 1); gfx.drawPixel(fx + (tx >= 0 and 1 or -1), fy + 1) end
  end
  UI.ink("inkorange")
  local lt = (math.floor(frames / (4))) % 6                                                                  -- warm light drifts down from the lamp
  gfx.drawPixel(cx + 5 + math.floor(lt / (3)), top + 2 + lt); gfx.drawPixel(cx + 9 - math.floor(lt / (3)), top + 2 + (lt + 3) % 6)
end

function CAFE.art.radio(cx, cy)
  UI.ink("mint")
  gfx.setColor(WHITE); gfx.fillRoundRect(cx - 11, cy - 3, 22, 13, 3)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(cx - 11, cy - 3, 22, 13, 3); gfx.setLineWidth(1)
  UI.ink("tan")
  if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 4, cy + 3, 4); gfx.setColor(BLACK) end
  UI.ink("bark")
  gfx.drawCircleAtPoint(cx - 4, cy + 3, 4)                                 -- the speaker
  gfx.drawPixel(cx - 4, cy + 3); gfx.drawPixel(cx - 6, cy + 2); gfx.drawPixel(cx - 2, cy + 4)
  UI.ink("brass")
  gfx.fillRect(cx + 3, cy, 6, 2)                                           -- the dial
  UI.ink("inkred")
  gfx.drawLine(cx + 4 + (math.floor(frames / (20))) % 4, cy, cx + 4 + (math.floor(frames / (20))) % 4, cy + 5)
  UI.ink("gray")
  gfx.drawLine(cx + 7, cy - 3, cx + 11, cy - 10)                           -- the aerial
  UI.ink("inkpurple")
  for k = 0, 1 do                                                          -- music notes float up from it
    local tt = (math.floor(frames / (3)) + k * 8) % 16
    local x, y = cx - 7 + k * 5 + math.floor(math.sin(tt * 0.6) * 2), cy - 4 - tt
    if tt < 14 then gfx.fillCircleAtPoint(x, y, 1); gfx.drawLine(x + 1, y, x + 1, y - 3) end
  end
end

-- ---- the rest of the Stuff tab: little things for the counter, and a juke box for the floor --------------
function CAFE.outRR(x, y, w, h, r, fill)          -- a rounded box with a 2px outline
  gfx.setColor(fill or WHITE); gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(x, y, w, h, r); gfx.setLineWidth(1)
end
function CAFE.noteAt(x, y)                        -- a little music note
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(x, y, 1); gfx.drawLine(x + 1, y, x + 1, y - 3)
end

function CAFE.art.boombox(cx, cy)                 -- two thumping speakers, a tape deck, and notes floating up
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.setLineWidth(2)
  gfx.drawLine(cx - 8, cy - 2, cx - 8, cy - 6); gfx.drawLine(cx - 8, cy - 6, cx + 8, cy - 6); gfx.drawLine(cx + 8, cy - 6, cx + 8, cy - 2)
  gfx.setLineWidth(1)
  UI.ink("redp")
  CAFE.outRR(cx - 12, cy - 3, 24, 14, 3)
  local beat = ((math.floor(frames / (3))) % 3 == 0)
  for sx = -7, 7, 14 do
    UI.ink("fur")
    if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + sx, cy + 4, 4) end
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx + sx, cy + 4, 4)
    gfx.fillCircleAtPoint(cx + sx, cy + 4, beat and 3 or 2)
    gfx.setColor(WHITE); gfx.drawPixel(cx + sx, cy + 4)
  end
  UI.ink("skyp")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 3, cy - 1, 7, 5) end
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 3, cy - 1, 7, 5)                                       -- the tape window with its two reels
  gfx.drawPixel(cx - 1, cy + 1); gfx.drawPixel(cx + 2, cy + 1)
  UI.ink("navyy")
  gfx.fillRect(cx - 3, cy + 6, 7, 2)                                       -- the tuning strip
  gfx.setColor(WHITE); gfx.drawPixel(cx - 2 + (math.floor(frames / (6))) % 5, cy + 6); gfx.setColor(BLACK)
  UI.ink("gray")
  gfx.drawLine(cx + 10, cy - 3, cx + 13, cy - 12)                          -- the aerial
  for k = 0, 1 do
    UI.ink(k == 0 and "inkpink" or "inkblue")
    local tt = (math.floor(frames / (2)) + k * 8) % 16
    if tt < 13 then CAFE.noteAt(cx - 5 + k * 9 + math.floor(math.sin(tt * 0.6) * 2), cy - 9 - math.floor(tt / (2))) end
  end
end

function CAFE.art.luckycat(cx, cy)                -- a maneki-neko: big dark eyes with a glint, a little mouth, one paw swinging slowly
  local ph = 0.5 + 0.5 * math.sin(frames * 0.2)                               -- 0 = paw up, 1 = paw swung right down
  local sw = math.rad(-62 + 68 * ph * ph * (3 - 2 * ph))                      -- (eased, so it lingers at the top and bottom of each beckon)
  local sx, sy = cx + 9, cy + 4
  local ex, ey = sx + math.floor(math.cos(sw) * 6 + 0.5), sy + math.floor(math.sin(sw) * 6 + 0.5)
  local ox, oy = math.floor(-math.sin(sw) * 2 + 0.5), math.floor(math.cos(sw) * 2 + 0.5)    -- the arm is a little padded bar, not a hairline
  UI.ink("white")
  gfx.setColor(WHITE); gfx.fillPolygon(sx + ox, sy + oy, ex + ox, ey + oy, ex - ox, ey - oy, sx - ox, sy - oy)
  gfx.setColor(BLACK)
  gfx.drawLine(sx + ox, sy + oy, ex + ox, ey + oy); gfx.drawLine(sx - ox, sy - oy, ex - ox, ey - oy)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(ex, ey, 3)                      -- the paw
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(ex, ey, 3); gfx.drawPixel(ex, ey + 1); gfx.drawPixel(ex - 1, ey); gfx.drawPixel(ex + 1, ey)
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 9, cy - 1, 19, 12)         -- the body
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 9, cy - 1, 19, 12); gfx.setLineWidth(1)
  gfx.setColor(WHITE); gfx.fillTriangle(cx - 8, cy - 9, cx - 6, cy - 16, cx - 2, cy - 11)      -- the ears
  gfx.fillTriangle(cx + 8, cy - 9, cx + 6, cy - 16, cx + 2, cy - 11)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 8, cy - 9, cx - 6, cy - 16); gfx.drawLine(cx - 6, cy - 16, cx - 2, cy - 11)
  gfx.drawLine(cx + 8, cy - 9, cx + 6, cy - 16); gfx.drawLine(cx + 6, cy - 16, cx + 2, cy - 11)
  UI.ink("inkpink")
  gfx.drawPixel(cx - 6, cy - 13); gfx.drawPixel(cx + 6, cy - 13)
  if UI.color then gfx.drawPixel(cx - 6, cy - 12); gfx.drawPixel(cx + 6, cy - 12) end
  UI.ink("white")
  CAFE.outRR(cx - 9, cy - 12, 19, 13, 4)                                      -- the head
  UI.ink("none")
  gfx.setColor(BLACK)
  if (math.floor(frames / (6))) % 9 == 8 then                                              -- a blink
    gfx.drawLine(cx - 6, cy - 8, cx - 3, cy - 8); gfx.drawLine(cx + 3, cy - 8, cx + 6, cy - 8)
  else                                                                        -- big dark eyes, each with a glint
    gfx.fillRect(cx - 6, cy - 9, 4, 3); gfx.fillRect(cx + 3, cy - 9, 4, 3)
    gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy - 9); gfx.drawPixel(cx + 4, cy - 9); gfx.setColor(BLACK)
  end
  UI.ink("inkpink")
  gfx.fillRect(cx - 1, cy - 6, 3, 1); gfx.drawPixel(cx, cy - 5)               -- the nose
  UI.ink("none")
  gfx.drawPixel(cx - 2, cy - 4); gfx.drawPixel(cx - 1, cy - 3); gfx.drawPixel(cx + 1, cy - 3); gfx.drawPixel(cx + 2, cy - 4)   -- and a little w of a mouth
  UI.ink("inkred")
  gfx.fillRect(cx - 6, cy + 1, 13, 2)                                         -- the collar and its bell
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy + 5, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy + 5, 2); gfx.drawPixel(cx, cy + 5)
  UI.ink("redp")
  gfx.fillRect(cx - 9, cy + 10, 19, 1)
end

-- the Music tab's pictures: a vinyl record sliding out of its sleeve, turning a little (which = "hmus" the pumpkin one, "xmus" the Christmas tree one)
CAFE.VPAT = { hmus = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }, xmus = { 0x88, 0x22, 0x88, 0x22, 0x88, 0x22, 0x88, 0x22 } }
function CAFE.vinyl(cx, cy, which)
  local floor, cos, sin, rad = math.floor, math.cos, math.sin, math.rad
  cx = cx + 3                                                   -- (sleeve and record together sit in the middle of the picture box)
  local dx, r = cx + 11, 24
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(dx, cy, r)
  gfx.setColor(WHITE)                                           -- the grooves
  gfx.drawCircleAtPoint(dx, cy, r - 3)
  gfx.drawCircleAtPoint(dx, cy, r - 6)
  gfx.drawCircleAtPoint(dx, cy, r - 9)
  gfx.setLineWidth(2)                                           -- a bright streak on each side, turning with the record
  local a0 = (frames * 5) % 360
  for k = 0, 1 do
    local px, py
    for da = 0, 36, 6 do
      local a = rad(a0 + k * 180 + da)
      local x, y = floor(dx + cos(a) * (r - 1.5) + 0.5), floor(cy + sin(a) * (r - 1.5) + 0.5)
      if px then gfx.drawLine(px, py, x, y) end
      px, py = x, y
    end
  end
  gfx.setLineWidth(1)
  UI.ink(which == "hmus" and "pumpk" or "redp")
  gfx.setColor(WHITE)                                           -- the paper label in the middle
  gfx.fillCircleAtPoint(dx, cy, 10)
  gfx.setPattern(CAFE.VPAT[which])
  gfx.fillCircleAtPoint(dx, cy, 8)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(dx, cy, 10)
  gfx.fillCircleAtPoint(dx, cy, 2)
  -- the sleeve, covering the left of the record
  local x0, y0, w, h = cx - 42, cy - 27, 42, 54
  UI.ink(which == "hmus" and "lav" or "skyp")
  gfx.setColor(WHITE)
  gfx.fillRect(x0, y0, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(x0, y0, w, h)
  gfx.setLineWidth(1)
  gfx.drawRect(x0 + 4, y0 + 4, w - 8, h - 8)
  local sx, sy = x0 + math.floor(w / (2)), y0 + 31
  if which == "hmus" then                                       -- a jack-o'-lantern under a few stars
    UI.ink("leafdk")
    gfx.fillRect(sx - 2, sy - 17, 4, 7)
    UI.ink("jack")
    gfx.fillEllipseInRect(sx - 14, sy - 11, 28, 24)
    gfx.setColor(WHITE)
    gfx.fillTriangle(sx - 9, sy - 1, sx - 3, sy - 1, sx - 6, sy - 6)          -- eyes
    gfx.fillTriangle(sx + 3, sy - 1, sx + 9, sy - 1, sx + 6, sy - 6)
    gfx.fillTriangle(sx - 2, sy + 3, sx + 2, sy + 3, sx, sy)                  -- nose
    gfx.drawLine(sx - 8, sy + 5, sx - 5, sy + 9); gfx.drawLine(sx - 5, sy + 9, sx - 2, sy + 5)      -- the grin
    gfx.drawLine(sx - 2, sy + 5, sx + 1, sy + 9); gfx.drawLine(sx + 1, sy + 9, sx + 4, sy + 5)
    gfx.drawLine(sx + 4, sy + 5, sx + 8, sy + 9)
    gfx.setColor(BLACK)
    UI.ink("inkyellow")
    for _, st in ipairs({ { -13, -22 }, { 11, -24 }, { 13, -14 }, { -14, -13 } }) do gfx.fillRect(sx + st[1], sy + st[2], 2, 2) end
  else                                                          -- a Christmas tree in the snow
    UI.ink("inkgreen")
    gfx.fillTriangle(sx, sy - 23, sx - 8, sy - 9, sx + 8, sy - 9)
    gfx.fillTriangle(sx, sy - 15, sx - 11, sy + 2, sx + 11, sy + 2)
    gfx.fillTriangle(sx, sy - 6, sx - 14, sy + 13, sx + 14, sy + 13)
    UI.ink("bark")
    gfx.fillRect(sx - 2, sy + 13, 4, 5)
    UI.ink(which == "hmus" and "lav" or "skyp")
    gfx.setColor(WHITE)
    gfx.setClipRect(x0 + 2, y0 + 2, w - 4, h - 4)
    CAFE.starAt(sx, sy - 25, 6)                                  -- a halo the colour of the sleeve, so the star stands apart from the tree...
    gfx.clearClipRect()
    gfx.setColor(BLACK)
    UI.ink("goldbk")
    CAFE.starAt(sx, sy - 25, 4)                                  -- ...and the star on top (a real five-pointed star)
    gfx.setColor(WHITE)
    local orn = { "redp", "yellow", "lav", "redp", "skyp", "yellow" }
    for i, o in ipairs({ { -3, -10 }, { 4, -4 }, { -8, 3 }, { 1, 7 }, { 9, 8 }, { -10, 10 } }) do UI.ink(orn[i]); gfx.fillCircleAtPoint(sx + o[1], sy + o[2], 1) end
    gfx.setColor(BLACK)
    UI.ink("inkwhite")
    for _, sn in ipairs({ { -14, -20 }, { 12, -21 }, { 15, -8 }, { -16, -6 }, { 15, 6 }, { -16, 18 } }) do gfx.fillRect(sx + sn[1], sy + sn[2], 2, 2) end
  end
  gfx.setColor(BLACK)
end
function CAFE.art.hmus(cx, cy) CAFE.vinyl(cx, cy, "hmus") end
function CAFE.art.xmus(cx, cy) CAFE.vinyl(cx, cy, "xmus") end

function CAFE.art.record(cx, cy)                  -- a turntable: the record spins and the notes float away
  UI.ink("woodl")
  CAFE.outRR(cx - 12, cy + 2, 24, 9, 2)
  UI.ink("none")
  gfx.setColor(BLACK); gfx.fillEllipseInRect(cx - 10, cy - 4, 20, 9)
  local a = frames * 0.5
  gfx.setColor(WHITE)
  gfx.drawLine(cx + math.floor(math.cos(a) * 7), cy + math.floor(math.sin(a) * 3), cx + math.floor(math.cos(a) * 3), cy + math.floor(math.sin(a) * 1.4))
  UI.ink("redp")
  gfx.fillCircleAtPoint(cx, cy, 2); gfx.setColor(BLACK); gfx.drawPixel(cx, cy)
  UI.ink("gray")
  gfx.drawLine(cx + 10, cy - 1, cx + 10, cy - 7)                             -- the arm
  gfx.setLineWidth(2); gfx.drawLine(cx + 10, cy - 7, cx + 4, cy - 1); gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(cx + 10, cy - 7, 1)
  UI.ink("brass")
  gfx.fillCircleAtPoint(cx - 9, cy + 6, 1)
  for k = 0, 1 do
    UI.ink(k == 0 and "inkblue" or "inkorange")
    local tt = (math.floor(frames / (2)) + k * 8) % 16
    if tt < 13 then CAFE.noteAt(cx - 4 + k * 8 + math.floor(math.sin(tt * 0.6) * 2), cy - 8 - math.floor(tt / (2))) end
  end
end

function CAFE.art.snowglobe(cx, cy)               -- a little pine tree in a globe, snow drifting down
  UI.ink("redbk")
  gfx.setColor(BLACK); gfx.fillRect(cx - 7, cy + 5, 14, 6)
  UI.ink("gold2")
  gfx.setColor(WHITE); gfx.fillRect(cx - 4, cy + 7, 8, 1)
  UI.ink("glass")
  gfx.fillCircleAtPoint(cx, cy - 3, 9)
  UI.ink("slate")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy - 3, 9); gfx.setLineWidth(1)
  UI.ink("inkgreen")
  gfx.fillTriangle(cx - 5, cy + 2, cx + 5, cy + 2, cx, cy - 3)           -- a pine tree in two tiers
  gfx.fillTriangle(cx - 4, cy - 1, cx + 4, cy - 1, cx, cy - 7)
  UI.ink("bark")
  gfx.fillRect(cx - 1, cy + 2, 2, 2)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.drawPixel(cx, cy - 4); gfx.drawPixel(cx - 2, cy + 1); gfx.drawPixel(cx + 2, cy + 1)
  UI.ink("snow")
  gfx.drawLine(cx - 7, cy + 3, cx + 7, cy + 3)                            -- snow on the ground
  gfx.setColor(BLACK)
  UI.ink("skyp")
  for k = 0, 7 do
    local x = cx - 6 + (k * 5) % 12 + math.floor(math.sin(frames * 0.2 + k) * 1)
    local y = cy - 10 + ((math.floor(frames / (2))) + k * 3) % 14
    if (x - cx) ^ 2 + (y - cy + 3) ^ 2 < 64 then gfx.drawPixel(x, y) end
  end
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawPixel(cx - 5, cy - 8); gfx.drawPixel(cx - 5, cy - 7); gfx.setColor(BLACK)
end

CAFE.GUMCOL = { "redp", "yellow", "skyp", "leaf", "rose", "orangep", "lav", "mint" }     -- (the PC version: every gumball its own colour)
function CAFE.art.gumball(cx, cy)                 -- a glass bowl of gumballs on a little stand
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy - 4, 9)
  UI.ink("redp")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy - 4, 9); gfx.setLineWidth(1)
  local balls = { { -4, -7, 0 }, { 1, -9, 1 }, { 5, -5, 2 }, { -6, -3, 1 }, { -1, -4, 2 }, { 4, -1, 0 }, { -4, 0, 2 }, { 0, 1, 0 } }
  for i = 1, #balls do
    local b = balls[i]
    local x, y = cx + b[1], cy + b[2] + 1
    UI.ink(CAFE.GUMCOL[i])
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(x, y, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, y, 2)
    if UI.color then UI.ink("white"); gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - 1); gfx.setColor(BLACK)      -- (a shine on every ball)
    elseif b[3] == 1 then gfx.fillCircleAtPoint(x, y, 1) elseif b[3] == 2 then gfx.drawPixel(x - 1, y - 1) end
  end
  UI.ink("redbk")
  if UI.color then gfx.setColor(WHITE) end
  gfx.fillRect(cx - 6, cy + 4, 12, 7)
  if UI.color then gfx.setColor(BLACK); UI.ink("redp"); gfx.drawRect(cx - 6, cy + 4, 12, 7) end
  UI.ink("brass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy + 7, 2); gfx.setColor(BLACK); gfx.drawPixel(cx, cy + 7)
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawLine(cx - 4, cy + 5, cx + 4, cy + 5); gfx.setColor(BLACK)
  UI.ink("inkblue")
  if (math.floor(frames / (3))) % 4 < 2 then gfx.drawPixel(cx - 7, cy - 9); gfx.drawPixel(cx - 7, cy - 8) end      -- a sparkle on the glass
end

function CAFE.art.cradle(cx, cy)                  -- Newton's cradle: four balls, the end ones swing out, click, and swing back
  UI.ink("woodl")
  gfx.setColor(BLACK); gfx.fillRect(cx - 15, cy + 9, 30, 2)
  UI.ink("slate")
  gfx.fillRect(cx - 14, cy - 10, 2, 19); gfx.fillRect(cx + 12, cy - 10, 2, 19)
  gfx.fillRect(cx - 14, cy - 10, 28, 2)
  local ph = (frames % 28) / 28
  local L, R = 0, 0
  if ph < 0.5 then L = math.sin(ph * 2 * math.pi) else R = math.sin((ph - 0.5) * 2 * math.pi) end
  for i = 0, 3 do
    local ang = (i == 0) and -L * 0.34 or ((i == 3) and R * 0.34 or 0)
    local px = cx - 8 + i * 5
    local bx, by = px + math.floor(math.sin(ang) * 14 + 0.5), cy - 8 + math.floor(math.cos(ang) * 14 + 0.5)
    UI.ink("gray")
    gfx.setColor(BLACK); gfx.drawLine(px, cy - 8, bx, by - 2)
    UI.ink("snow")
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(bx, by, 2); gfx.setColor(BLACK); gfx.drawCircleAtPoint(bx, by, 2)
    UI.ink("slate")
  end
end

function CAFE.art.miniplaydate(cx, cy)            -- a tiny handheld (the Pee-Dee): a cup steaming on its screen, the crank turning now and then
  local bx, by = cx - 14, cy - 10
  UI.ink("yellow")
  CAFE.outRR(bx, by, 22, 21, 4)                                              -- the body
  UI.ink("glass")
  gfx.setColor(BLACK); gfx.fillRect(bx + 4, by + 4, 14, 9)                   -- the screen
  gfx.setColor(WHITE)
  gfx.drawPixel(bx + 5, by + 5)                                              -- a glint on the glass
  gfx.fillRect(bx + 7, by + 7, 6, 4)                                         -- a cup with a handle, on a saucer...
  gfx.drawPixel(bx + 13, by + 8); gfx.drawPixel(bx + 13, by + 9)
  gfx.drawLine(bx + 6, by + 11, bx + 13, by + 11)
  gfx.setColor(BLACK); gfx.drawLine(bx + 8, by + 8, bx + 11, by + 8)         -- (the coffee)
  gfx.setColor(WHITE)
  local f = (math.floor(frames / (5))) % 3                                                -- ...and its steam
  gfx.drawPixel(bx + 8, by + 5 + (f == 1 and 1 or 0)); gfx.drawPixel(bx + 11, by + 5 + (f == 2 and 1 or 0))
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.fillRect(bx + 4, by + 15, 4, 2); gfx.fillRect(bx + 5, by + 14, 2, 4)   -- the d-pad
  gfx.fillRect(bx + 17, by + 14, 2, 2); gfx.fillRect(bx + 13, by + 16, 2, 2)   -- the A and B buttons
  local c = CAFE.pdc                                                         -- the crank: it sits still, then every 8 to 10 seconds gets a good turning
  if not c or frames < c.last then c = { last = frames, nxt = frames + math.random(60, 150), left = 0, ang = 0 }; CAFE.pdc = c end
  if c.last ~= frames then
    c.last = frames
    if c.left > 0 then c.left = c.left - 1; c.ang = c.ang + 0.5
    elseif frames >= c.nxt then c.left = 36; c.nxt = frames + math.random(240, 300) end
  end
  local a = c.ang
  UI.ink("brass")
  local kx, ky = bx + 22 + math.floor(math.cos(a) * 4), by + 9 + math.floor(math.sin(a) * 4)
  gfx.setLineWidth(2); gfx.drawLine(bx + 22, by + 9, kx, ky); gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(kx, ky, 1)
  gfx.fillCircleAtPoint(bx + 22, by + 9, 1)
end

CAFE.JB = {}
function CAFE.jukeShape(cx, cy, grow)             -- the juke box's arched outline (cached: one polygon call instead of a dozen lines)
  local key = cx * 1000 + cy + (grow or 0) * 1000000
  local c = CAFE.JB[key]
  if c then return c end
  local pts, g = {}, grow or 0
  local rx, ry, top = 12 - g, 11 - g, cy - 5
  for k = 0, 12 do
    local a = math.pi + k * math.pi / 12
    pts[#pts + 1] = cx + math.floor(math.cos(a) * rx + 0.5)
    pts[#pts + 1] = top + math.floor(math.sin(a) * ry + 0.5)
  end
  pts[#pts + 1] = cx + rx; pts[#pts + 1] = cy + 14 - g
  pts[#pts + 1] = cx - rx; pts[#pts + 1] = cy + 14 - g
  CAFE.JB[key] = pts
  return pts
end
function CAFE.jukeDome(cx, cy)                    -- the dark half-moon of glass at the top, where the lights run round
  local key = "d" .. cx * 1000 + cy
  local c = CAFE.JB[key]
  if c then return c end
  local pts = {}
  for k = 0, 10 do
    local a = math.pi + k * math.pi / 10
    pts[#pts + 1] = cx + math.floor(math.cos(a) * 8 + 0.5)
    pts[#pts + 1] = cy - 6 + math.floor(math.sin(a) * 7 + 0.5)
  end
  CAFE.JB[key] = pts
  return pts
end

function CAFE.art.jukebox(cx, cy)                 -- a glowing juke box: chasing lights, a spinning record, notes drifting up
  UI.ink("wine")
  gfx.setColor(BLACK); gfx.fillPolygon(table.unpack(CAFE.jukeShape(cx, cy, 0)))
  UI.ink("peach")
  gfx.setColor(WHITE); gfx.fillPolygon(table.unpack(CAFE.jukeShape(cx, cy, 2)))
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillPolygon(table.unpack(CAFE.jukeDome(cx, cy)))              -- the glass dome...
  local tick = math.floor(frames / (4))
  gfx.setColor(WHITE)
  for k = 0, 4 do                                                           -- ...with its bulbs chasing round
    local a = math.pi + (k + 0.5) * math.pi / 5
    local x, y = cx + math.floor(math.cos(a) * 5.5 + 0.5), cy - 6 + math.floor(math.sin(a) * 4.5 + 0.5)
    if (k + tick) % 3 == 0 then gfx.fillRect(x - 1, y - 1, 2, 2) else gfx.drawPixel(x, y) end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 3, 11, 9)                                        -- the window with the record in it
  gfx.fillCircleAtPoint(cx, cy + 1, 3)
  local a = frames * 0.6
  gfx.setColor(WHITE)
  gfx.drawPixel(cx + math.floor(math.cos(a) * 2 + 0.5), cy + 1 + math.floor(math.sin(a) * 2 + 0.5))
  gfx.drawPixel(cx, cy + 1)
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 5, cy - 2, cx + 2, cy + 1)                               -- the arm
  UI.ink("redp")
  local sel = (math.floor(frames / (12))) % 3                                             -- the song buttons
  for k = 0, 2 do
    if k == sel then gfx.drawRect(cx - 6 + k * 5, cy + 7, 3, 2) else gfx.fillRect(cx - 6 + k * 5, cy + 7, 3, 2) end
  end
  UI.ink("gray")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 8, cy + 10, 16, 2); gfx.setColor(BLACK)      -- the speaker grille
  for j = 0, 4 do                                                           -- a column of lights down each side
    UI.ink(({ "inkpink", "inkyellow", "inkblue", "inkmint", "inkorange" })[j + 1])
    if (j + tick) % 3 == 0 then gfx.fillRect(cx - 9, cy - 3 + j * 3, 2, 2); gfx.fillRect(cx + 8, cy - 3 + j * 3, 2, 2) end
  end
  UI.ink("inkpink")
  for k = 0, 1 do                                                           -- notes float up out of the top
    local tt = (math.floor(frames / (2)) + k * 9) % 18
    if tt < 14 then CAFE.noteAt(cx - 4 + k * 8 + math.floor(math.sin(tt * 0.6) * 2), cy - 18 - math.floor(tt / (2))) end
  end
end

function CAFE.art.cuckoo(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 11, cy - 3, cx, cy - 14, cx + 11, cy - 3)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 9, cy - 3, 18, 14)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 9, cy - 3, 18, 14)
  local t = (G and G.t) or 0
  if t % 30 < 2 then                                  -- the little bird pops out
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy + 2, 2)
    gfx.fillTriangle(cx + 2, cy + 1, cx + 6, cy + 2, cx + 2, cy + 3)
  else
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
  end
  local sw = math.floor(math.sin(frames * 0.08) * 4)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)
  gfx.fillCircleAtPoint(cx + sw, cy + 17, 2)
end

function CAFE.art.calendar(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 10, cy - 12, 20, 24)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 10, cy - 12, 20, 24)
  gfx.fillRect(cx - 10, cy - 12, 20, 6)
  gfx.fillRect(cx - 6, cy - 14, 2, 4)
  gfx.fillRect(cx + 4, cy - 14, 2, 4)
  for r = 0, 2 do
    for c = 0, 3 do
      gfx.fillRect(cx - 8 + c * 4, cy - 3 + r * 5, 2, 2)
    end
  end
  gfx.drawRect(cx + 2, cy + 6, 5, 4)
end

local function pot(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 9, cy + 5, cx + 9, cy + 5, cx + 6, cy + 14, cx - 6, cy + 14)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 7, cy + 7, 14, 2)
  gfx.setColor(BLACK)
end

function CAFE.art.plant(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx, cy + 5, cx - 9 + sw, cy - 9, cx - 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + 9 + sw, cy - 10, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + sw, cy - 15, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx - 13 + sw, cy - 2, cx - 4, cy + 6)
  gfx.fillTriangle(cx, cy + 5, cx + 13 + sw, cy - 3, cx + 4, cy + 6)
  pot(cx, cy)
end

function CAFE.art.cactus(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 4, cy - 14, 8, 22, 3)
  gfx.fillRoundRect(cx - 11, cy - 7, 6, 3, 1)
  gfx.fillRoundRect(cx - 11, cy - 11, 3, 7, 1)
  gfx.fillRoundRect(cx + 5, cy - 3, 6, 3, 1)
  gfx.fillRoundRect(cx + 8, cy - 8, 3, 8, 1)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 1, cy - 10)
  gfx.drawPixel(cx + 1, cy - 4)
  gfx.drawPixel(cx - 1, cy + 1)
  pot(cx, cy)
end

function CAFE.art.fern(cx, cy)
  local sw = math.floor(math.sin(frames * 0.06) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  for k = -2, 2 do
    gfx.drawLine(cx, cy + 5, cx + k * 5, cy - 5)
    gfx.drawLine(cx + k * 5, cy - 5, cx + k * 8 + sw, cy - 11)
  end
  gfx.setLineWidth(1)
  pot(cx, cy)
end

function CAFE.art.flowers(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 2, cy + 5, cx + k * 7, cy - 7)
  end
  for k = -1, 1 do
    local fx, fy = cx + k * 7, cy - 9 - (k == 0 and 3 or 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(fx, fy, 4)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(fx, fy, 4)
    gfx.fillCircleAtPoint(fx, fy, 1)
  end
  pot(cx, cy)
end

function CAFE.art.tree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 9, 4, 6)
  gfx.fillTriangle(cx, cy - 15, cx - 8, cy - 3, cx + 8, cy - 3)
  gfx.fillTriangle(cx, cy - 8, cx - 11, cy + 4, cx + 11, cy + 4)
  gfx.fillTriangle(cx, cy - 2, cx - 13, cy + 10, cx + 13, cy + 10)
  local spots = { { -3, -8 }, { 3, -1 }, { -7, 2 }, { 6, 6 }, { -3, 7 } }
  for i, sp in ipairs(spots) do
    if (i + math.floor(frames / (20))) % 2 == 0 then
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx + sp[1], cy + sp[2], 2)
    end
  end
  gfx.setColor(WHITE)
  gfx.fillTriangle(cx, cy - 19, cx - 2, cy - 15, cx + 2, cy - 15)
  gfx.setColor(BLACK)
end

function CAFE.art.pumpkin(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setLineWidth(1)
  gfx.drawLine(cx, cy - 3, cx, cy + 13)
  gfx.fillRect(cx - 1, cy - 7, 3, 5)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 2, cy + 5, cx - 4, cy + 1)
  gfx.fillTriangle(cx + 2, cy + 5, cx + 6, cy + 5, cx + 4, cy + 1)
  gfx.fillRect(cx - 4, cy + 8, 8, 2)
end

-- ---- tiny wall art (about 20 x 16, hung on the open wall above the counter) -------------------------
local function tinyFrame(cx, cy, w, h, bg)        -- bg = the colour behind the picture (PC version)
  UI.ink(bg or "white")
  gfx.setColor(WHITE)
  gfx.fillRect(cx - math.floor(w / (2)), cy - math.floor(h / (2)), w, h)
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(cx - math.floor(w / (2)), cy - math.floor(h / (2)), w, h)
  gfx.setLineWidth(1)
end
function CAFE.art.t1(cx, cy)                      -- landscape: mountains and a sun
  tinyFrame(cx, cy, 22, 16, "skyp")
  UI.ink("leaf")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 9, cy + 4, 18, 3); gfx.setColor(BLACK) end      -- a green meadow
  UI.ink("slate")
  gfx.fillTriangle(cx - 8, cy + 5, cx - 3, cy - 3, cx + 2, cy + 5)
  UI.ink("plum")
  gfx.fillTriangle(cx - 1, cy + 5, cx + 4, cy - 1, cx + 9, cy + 5)
  UI.ink("yellow")
  if UI.color then gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + 5, cy - 4, 2); gfx.setColor(BLACK) end
  gfx.drawCircleAtPoint(cx + 5, cy - 4, 2)
end
function CAFE.art.t2(cx, cy)                      -- heart
  tinyFrame(cx, cy, 18, 18, "blush")
  UI.ink("inkred")
  gfx.fillCircleAtPoint(cx - 3, cy - 2, 3)
  gfx.fillCircleAtPoint(cx + 3, cy - 2, 3)
  gfx.fillTriangle(cx - 6, cy - 1, cx + 6, cy - 1, cx, cy + 6)
  UI.ink("inkwhite"); gfx.drawPixel(cx - 4, cy - 3)
end
function CAFE.art.t3(cx, cy)                      -- sunburst
  tinyFrame(cx, cy, 20, 16, "skyp")
  gfx.setColor(BLACK)
  UI.ink("inkorange")
  for a = 0, 315, 45 do
    local r = math.rad(a)
    gfx.drawLine(cx + math.floor(3 * math.cos(r) + 0.5), cy + math.floor(3 * math.sin(r) + 0.5),
                 cx + math.floor(6 * math.cos(r) + 0.5), cy + math.floor(6 * math.sin(r) + 0.5))
  end
  UI.ink("inkgold")
  gfx.fillRect(cx - 1, cy - 2, 3, 5)                 -- the sun: an odd-sized disc, so it sits exactly in the middle of its rays
  gfx.fillRect(cx - 2, cy - 1, 5, 3)
end
function CAFE.art.t4(cx, cy)                      -- a mug print
  tinyFrame(cx, cy, 20, 18, "mint")
  UI.ink("inkred")
  gfx.fillRect(cx - 5, cy - 3, 9, 8)
  gfx.drawCircleAtPoint(cx + 5, cy + 1, 2)
  UI.ink("gray")
  gfx.drawLine(cx - 3, cy - 6, cx - 3, cy - 4)
  gfx.drawLine(cx + 1, cy - 6, cx + 1, cy - 4)
end
CAFE.CATFACE = { ".k.......k.", ".kk.....kk.", ".kpkkkkkpk.", "kwwwwkwwwwk", "kwkkwwwkkwk",
                 "kwwwwwwwwwk", "kwwwwpwwwwk", ".kwwkwkwwk.", "..kkkkkkk.." }
CAFE.CATDOTS = { 0xFF, 0xDD, 0xFF, 0xFF, 0xFF, 0x77, 0xFF, 0xFF }          -- a light sprinkle of dots behind the face
function CAFE.art.t5(cx, cy)                      -- round cat portrait: a little tabby face in a gold frame
  UI.ink("brass")
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 9)
  UI.ink("skyp")
  if UI.color then gfx.setColor(WHITE) else gfx.setPattern(CAFE.CATDOTS) end
  gfx.fillCircleAtPoint(cx, cy, 7)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy, 9); gfx.setLineWidth(1)
  local x0, y0 = cx - 5, cy - 4
  UI.ink("ginger")
  gfx.setColor(WHITE); CAFE.pix(CAFE.CATFACE, x0, y0, "w")
  gfx.setColor(BLACK); CAFE.pix(CAFE.CATFACE, x0, y0, "k")
  UI.ink("inkpink")
  CAFE.pix(CAFE.CATFACE, x0, y0, "p")
  gfx.setColor(BLACK)
end
function CAFE.art.t6(cx, cy)                      -- oval mirror with a shine
  UI.ink("glass")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 7, cy - 9, 14, 18)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 7, cy - 9, 14, 18); gfx.setLineWidth(1)
  UI.ink("inkblue")
  gfx.drawLine(cx - 3, cy - 4, cx - 1, cy - 6)
  gfx.drawLine(cx - 4, cy, cx + 1, cy - 7)
end
function CAFE.art.t7(cx, cy)                      -- bunting: a string of little flags
  tinyFrame(cx, cy, 34, 16, "cream")
  gfx.setColor(BLACK)
  UI.ink("bark")
  gfx.drawLine(cx - 14, cy - 5, cx, cy - 2); gfx.drawLine(cx, cy - 2, cx + 14, cy - 5)
  for i = -2, 2 do
    local x = cx + i * 6
    local y = cy - 5 + (2 - math.abs(i)) * 1 + math.floor(math.abs(2 - math.abs(i)) * 0.5)
    y = cy - 5 + math.floor((2 - math.abs(i)) * 1.5 + 0.5)
    UI.ink(({ "redp", "yellow", "skyp", "leaf", "rose" })[i + 3])
    if UI.color then
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    elseif i % 2 == 0 then gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
    else
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    end
  end
end
function CAFE.art.t8(cx, cy)                      -- three little stars (this used to be a paper plane)
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 11, cy - 8, 22, 16, 3)
  gfx.setColor(WHITE)
  local function star(x, y, r)                  -- a five-point star
    local pts = {}
    for i = 0, 9 do
      local rad = math.rad(-90 + i * 36)
      local rr = (i % 2 == 0) and r or r * 0.45
      pts[#pts + 1] = x + math.floor(rr * math.cos(rad) + 0.5)
      pts[#pts + 1] = y + math.floor(rr * math.sin(rad) + 0.5)
    end
    gfx.fillPolygon(table.unpack(pts))
  end
  star(cx - 1, cy - 1, 5)
  star(cx + 7, cy - 5, 2)
  star(cx - 7, cy + 4, 2)
  gfx.drawPixel(cx + 6, cy + 4); gfx.drawPixel(cx - 6, cy - 5)
  gfx.setColor(BLACK)
end
function CAFE.art.t9(cx, cy)                      -- music notes
  tinyFrame(cx, cy, 18, 18, "lilac")
  gfx.setColor(BLACK)
  UI.ink("inkpurple")
  gfx.fillCircleAtPoint(cx - 3, cy + 4, 2); gfx.fillCircleAtPoint(cx + 3, cy + 3, 2)
  gfx.drawLine(cx - 1, cy + 4, cx - 1, cy - 4); gfx.drawLine(cx + 5, cy + 3, cx + 5, cy - 5)
  gfx.setLineWidth(2); gfx.drawLine(cx - 1, cy - 4, cx + 5, cy - 5); gfx.setLineWidth(1)
end
function CAFE.art.t10(cx, cy)                     -- moon and stars
  UI.ink("navyy")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 12, cy - 9, 24, 18, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 3, cy, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx - 1, cy - 1, 5)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx + 5, cy - 4); gfx.drawPixel(cx + 8, cy + 3); gfx.drawPixel(cx + 4, cy + 5)
  gfx.drawLine(cx + 6, cy - 6, cx + 6, cy - 2)
  gfx.setColor(BLACK)
end
function CAFE.art.t12(cx, cy)                     -- sailboat
  tinyFrame(cx, cy, 22, 18, "skyp")
  gfx.setColor(BLACK)
  UI.ink("water")
  if UI.color then gfx.setColor(WHITE); gfx.fillRect(cx - 9, cy + 5, 18, 3); gfx.setColor(BLACK) end      -- the sea
  UI.ink("inkred")
  gfx.fillTriangle(cx - 1, cy - 6, cx - 1, cy + 2, cx - 6, cy + 2)
  UI.ink("white")
  if UI.color then gfx.setColor(WHITE); gfx.fillTriangle(cx + 1, cy - 4, cx + 1, cy + 2, cx + 6, cy + 2); gfx.setColor(BLACK) end
  gfx.drawLine(cx + 1, cy - 4, cx + 1, cy + 2); gfx.drawLine(cx + 1, cy - 4, cx + 6, cy + 2); gfx.drawLine(cx + 1, cy + 2, cx + 6, cy + 2)
  UI.ink("woodl")
  gfx.fillPolygon(cx - 7, cy + 4, cx + 7, cy + 4, cx + 5, cy + 7, cx - 5, cy + 7)
end

function CAFE.art.table(cx, cy)                    -- a table with its two chairs (the shop picture, and the place-a-table screen)
  CAFE.chairAt(cx - 17, cy, "l")
  CAFE.chairAt(cx + 17, cy, "r")
  CAFE.tableAt(cx, cy, 13, nil)
  gfx.setColor(BLACK)
end

function CAFE.art.booth(cx, cy)                    -- the corner booth, small: the L couch, the table and its two chairs
  UI.ink("couch")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx + 16, cy - 25, 7, 48, 3)                -- the back up the side...
  gfx.fillRoundRect(cx - 31, cy + 16, 54, 7, 3)                -- ...and along the bottom
  gfx.fillRoundRect(cx + 3, cy - 26, 20, 6, 3)                 -- the arms
  gfx.fillRoundRect(cx - 32, cy + 3, 6, 20, 3)
  local function cushion(x, y, w, h)
    gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 3)
    gfx.setColor(BLACK); gfx.drawRoundRect(x, y, w, h, 3)
    gfx.drawPixel(x + math.floor(w / 2), y + math.floor(h / 2))
  end
  cushion(cx + 4, cy - 20, 13, 13); cushion(cx + 4, cy - 7, 13, 12); cushion(cx + 4, cy + 4, 13, 13)
  cushion(cx - 26, cy + 4, 15, 13); cushion(cx - 11, cy + 4, 15, 13)
  CAFE.chairAt(cx - 26, cy - 7, "l")
  CAFE.chairAt(cx - 8, cy - 25, "u")
  CAFE.tableAt(cx - 8, cy - 7, 9, nil)
  UI.ink("none")
  gfx.setColor(BLACK)
end

local function smallPot(cx, cy)                -- a little pot for the counter
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 6, cy + 4, cx + 6, cy + 4, cx + 4, cy + 10, cx - 4, cy + 10)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 5, cy + 5, 10, 1)
  gfx.setColor(BLACK)
end

local function bloom(x, y, r)                  -- a flower head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.fillCircleAtPoint(x, y, math.max(1, r - 2))
end

function CAFE.art.tulips(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 3, cy + 4, cx + k * 4, cy - 4)
    gfx.fillTriangle(cx + k * 4 - 3, cy - 2, cx + k * 4 + 3, cy - 2, cx + k * 4, cy - 9)
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx, cy - 4)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.succ(cx, cy)
  gfx.setColor(BLACK)
  for k = -2, 2 do
    gfx.fillTriangle(cx, cy + 4, cx + k * 3 - 2, cy - 5 + math.abs(k), cx + k * 3 + 2, cy - 5 + math.abs(k))
  end
  gfx.setColor(WHITE)
  gfx.drawLine(cx, cy + 2, cx, cy - 3)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.daisies(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(cx - 4, cy + 1, 8, 9, 2)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(cx - 4, cy + 1, 8, 9, 2)
  for k = -1, 1 do
    gfx.drawLine(cx + k, cy + 1, cx + k * 5, cy - 6)
    bloom(cx + k * 5, cy - 7 - (k == 0 and 2 or 0), 3)
  end
end

function CAFE.art.minicac(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 2, cy - 7, 5, 12, 2)
  gfx.fillRoundRect(cx - 6, cy - 3, 3, 2, 1)
  gfx.fillRoundRect(cx - 6, cy - 6, 2, 5, 1)
  gfx.fillRoundRect(cx + 3, cy - 1, 3, 2, 1)
  gfx.fillRoundRect(cx + 5, cy - 4, 2, 5, 1)
  smallPot(cx, cy)
end

function CAFE.art.herbs(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do gfx.fillCircleAtPoint(cx + k * 4, cy - 1 - (k == 0 and 3 or 0), 3) end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 4, cy - 1)
  gfx.drawPixel(cx, cy - 4)
  gfx.drawPixel(cx + 4, cy - 1)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.palm(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 5, cx + 1, cy - 8)
  gfx.setLineWidth(1)
  for k = -3, 3 do
    gfx.drawLine(cx + 1, cy - 8, cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2)
    gfx.drawLine(cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2, cx + 1 + k * 5 + sw, cy - 11 + math.abs(k) * 3)
  end
  pot(cx, cy)
end

function CAFE.art.snake(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 3, cy + 5, cx - 5, cy - 12)
  gfx.fillTriangle(cx - 3, cy + 5, cx + 1, cy + 5, cx - 1, cy - 15)
  gfx.fillTriangle(cx + 1, cy + 5, cx + 4, cy + 5, cx + 3, cy - 10)
  gfx.fillTriangle(cx + 3, cy + 5, cx + 7, cy + 5, cx + 7, cy - 6)
  gfx.setColor(WHITE)
  gfx.drawLine(cx - 1, cy + 3, cx - 1, cy - 10)
  gfx.setColor(BLACK)
  pot(cx, cy)
end

function CAFE.art.sunflower(cx, cy)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 5, cx - 5, cy - 6)
  gfx.drawLine(cx + 3, cy + 5, cx + 6, cy - 3)
  gfx.fillTriangle(cx - 3, cy + 1, cx - 9, cy - 2, cx - 3, cy - 2)
  for _, f in ipairs({ { -5, -9, 5 }, { 6, -6, 4 } }) do
    for a = 0, 7 do
      local an = a * math.pi / 4
      gfx.fillCircleAtPoint(cx + f[1] + math.floor(math.cos(an) * (f[3] + 1)), cy + f[2] + math.floor(math.sin(an) * (f[3] + 1)), 1)
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 1)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 2)
  end
  pot(cx, cy)
end

function CAFE.art.bonsai(cx, cy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 6, cx - 2, cy + 1)
  gfx.drawLine(cx - 2, cy + 1, cx + 2, cy - 5)
  gfx.drawLine(cx + 2, cy - 5, cx - 1, cy - 9)
  gfx.setLineWidth(1)
  for _, c in ipairs({ { -7, -6, 5 }, { 0, -12, 6 }, { 8, -7, 5 }, { -2, -7, 4 } }) do
    gfx.fillCircleAtPoint(cx + c[1], cy + c[2], c[3])
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 7, cy - 6); gfx.drawPixel(cx + 1, cy - 12); gfx.drawPixel(cx + 8, cy - 7)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 9, cy + 6, 18, 2)
  gfx.fillRect(cx - 8, cy + 8, 3, 6)
  gfx.fillRect(cx + 5, cy + 8, 3, 6)
  gfx.fillRect(cx - 10, cy + 6, 20, 1)
end

function CAFE.art.monstera(cx, cy)
  gfx.setColor(BLACK)
  local leaves = { { -8, -4, 7, 5 }, { 1, -12, 8, 6 }, { 8, -3, 7, 5 }, { -2, -3, 6, 5 } }
  for _, l in ipairs(leaves) do
    gfx.fillEllipseInRect(cx + l[1] - l[3], cy + l[2] - l[4], l[3] * 2, l[4] * 2)
    gfx.setColor(WHITE)
    gfx.drawLine(cx + l[1] - 2, cy + l[2], cx + l[1] + 2, cy + l[2])         -- the leaf's splits
    gfx.drawPixel(cx + l[1], cy + l[2] - 2)
    gfx.setColor(BLACK)
  end
  gfx.drawLine(cx, cy + 5, cx - 6, cy - 2)
  gfx.drawLine(cx, cy + 5, cx + 7, cy - 2)
  pot(cx, cy)
end

-- ---- more floor lamps (they stand on y = cy + 14; every piece is centred on the pair of columns cx-1 / cx) -------
function CAFE.lampBase(cx, B, wide)               -- a flat weighted foot, 2 * wide pixels across
  UI.ink("brass")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - wide, B - 2, wide * 2, 3, 1)
end

CAFE.ARC = {}
do                                                -- the sweep of the arc lamp's pole, worked out once
  for i = 0, 8 do
    local a = math.pi - i * (math.pi - 0.55) / 8
    CAFE.ARC[#CAFE.ARC + 1] = { math.floor(2 + 9 * math.cos(a) + 0.5), math.floor(-6 - 9 * math.sin(a) + 0.5) }
  end
end

function CAFE.art.arclamp(cx, cy)               -- a heavy base, a pole that sweeps over, and a dome shade hanging from the tip
  local B = cy + 14
  UI.ink("gray")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 13, B - 3, 13, 4, 1)                         -- the marble block it stands on
  gfx.setColor(WHITE); gfx.drawLine(cx - 11, B - 2, cx - 4, B - 2); gfx.setColor(BLACK)
  UI.ink("slate")
  gfx.setLineWidth(2)
  gfx.drawLine(cx - 7, B - 3, cx - 7, cy - 6)                         -- up the pole...
  local A = CAFE.ARC
  for i = 1, #A - 1 do gfx.drawLine(cx + A[i][1], cy + A[i][2], cx + A[i + 1][1], cy + A[i + 1][2]) end   -- ...and over
  gfx.setLineWidth(1)
  local sx, yb = cx + A[#A][1], cy - 4                                 -- the shade hangs right under the tip of the arc
  local rows = CAFE.domeRows(5, 6)
  UI.ink("inkteal")
  for r = 0, 5 do gfx.drawLine(sx - rows[r], yb - r, sx + rows[r], yb - r) end
  UI.ink("brass")
  gfx.fillRect(sx - 6, yb, 13, 2)                                      -- its rim
  gfx.fillRect(sx - 1, A[#A][2] + cy, 3, 2)                             -- the little collar where it joins the arc
  if (math.floor(frames / (24))) % 11 ~= 10 then                                    -- the bulb, and light falling in a fan (with a rare flicker)
    UI.ink("glow")
    gfx.setColor(WHITE); gfx.fillEllipseInRect(sx - 2, yb + 2, 5, 4)
    gfx.setColor(BLACK); gfx.drawEllipseInRect(sx - 2, yb + 2, 5, 4)
    UI.ink("inkyellow")
    for k = -1, 1 do
      for j = 0, 1 do
        local s = (math.floor(frames / (3)) + j * 6) % 12
        gfx.drawPixel(sx + math.floor(k * (1 + s * 0.4) + 0.5), cy + 2 + s)
      end
    end
  end
end

function CAFE.art.torchiere(cx, cy)             -- a glass bowl on a tall slim pole that throws its light up at the ceiling
  local B = cy + 14
  CAFE.lampBase(cx, B, 7)
  gfx.setColor(BLACK)
  UI.ink("brass")
  gfx.fillRect(cx - 1, cy - 7, 2, B - cy + 5)                           -- the pole
  gfx.fillRect(cx - 3, cy - 8, 6, 2)                                    -- where the bowl sits
  gfx.fillRect(cx - 2, cy + 4, 4, 2)                                    -- a collar half way up
  UI.ink("peach")
  gfx.setColor(WHITE)
  gfx.fillPolygon(cx - 8, cy - 13, cx + 7, cy - 13, cx + 5, cy - 10, cx + 2, cy - 7, cx - 3, cy - 7, cx - 6, cy - 10)
  gfx.fillEllipseInRect(cx - 8, cy - 15, 16, 5)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 8, cy - 13, cx - 6, cy - 10); gfx.drawLine(cx - 6, cy - 10, cx - 3, cy - 7); gfx.drawLine(cx - 3, cy - 7, cx + 2, cy - 7)
  gfx.drawLine(cx + 2, cy - 7, cx + 5, cy - 10); gfx.drawLine(cx + 5, cy - 10, cx + 7, cy - 13)
  gfx.drawEllipseInRect(cx - 8, cy - 15, 16, 5)                          -- the rim of the bowl, seen from above
  UI.ink("flame")
  gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 5, cy - 14, 10, 3); gfx.setColor(BLACK)    -- the lit inside
  UI.ink("inkyellow")
  if (math.floor(frames / (20))) % 13 ~= 12 then                                      -- light climbs up the wall (with a rare flicker)
    for j = 0, 1 do
      local s = (math.floor(frames / (3)) + j * 3) % 6
      gfx.drawPixel(cx - 1 - (1 + math.floor(s / (2))), cy - 17 - s)
      gfx.drawPixel(cx + (1 + math.floor(s / (2))), cy - 17 - s)
      if s < 5 then gfx.drawPixel(cx - 1 + (j % 2), cy - 17 - s) end
    end
  end
end

function CAFE.art.tripodlamp(cx, cy)            -- three wooden legs holding up a tapered, pleated shade
  local B = cy + 14
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx - 1, cy + 3, cx - 11, B - 1); gfx.drawLine(cx, cy + 3, cx + 10, B - 1)       -- the two legs you can see splayed out...
  gfx.setLineWidth(1)
  gfx.fillRect(cx - 1, cy + 3, 2, B - cy - 5)                                                   -- ...and the third, coming towards you
  gfx.drawLine(cx - 7, cy + 9, cx + 6, cy + 9)                                                   -- a crossbar tying the legs
  gfx.fillRect(cx - 3, cy + 1, 6, 3)                                                             -- the hub
  gfx.fillRect(cx - 1, cy - 3, 2, 4)
  UI.ink("glow")
  gfx.setColor(WHITE)
  gfx.fillPolygon(cx - 6, cy - 14, cx + 5, cy - 14, cx + 8, cy - 4, cx - 9, cy - 4)
  gfx.setColor(BLACK)
  UI.ink("flame")
  gfx.setPattern(CHECK); gfx.fillRect(cx - 7, cy - 8, 14, 3); gfx.setColor(BLACK)                -- the glow is brightest at the bottom
  UI.ink("tan")
  gfx.drawLine(cx - 6, cy - 14, cx - 9, cy - 4); gfx.drawLine(cx + 5, cy - 14, cx + 8, cy - 4)
  gfx.drawLine(cx - 3, cy - 14, cx - 4, cy - 8); gfx.drawLine(cx + 2, cy - 14, cx + 3, cy - 8)     -- the pleats
  gfx.drawLine(cx - 6, cy - 14, cx + 5, cy - 14); gfx.drawLine(cx - 9, cy - 4, cx + 8, cy - 4)
  gfx.drawLine(cx - 7, cy - 15, cx + 6, cy - 15)
  UI.ink("inkyellow")
  local g = (math.floor(frames / (8))) % 2                                                                    -- the glow spills out of the bottom
  gfx.drawLine(cx - 7, cy - 2, cx - 8 - g, cy + 1); gfx.drawLine(cx - 1, cy - 1, cx - 1, cy + 2 + g)
  gfx.drawLine(cx + 6, cy - 2, cx + 7 + g, cy + 1); gfx.drawPixel(cx - 12 - g, cy - 9); gfx.drawPixel(cx + 11 + g, cy - 9)
end

function CAFE.art.globelamp(cx, cy)             -- a big frosted globe on a slim stem, a bulb glowing inside
  local B = cy + 14
  CAFE.lampBase(cx, B, 6)
  gfx.setColor(BLACK)
  UI.ink("brass")
  gfx.fillRect(cx - 1, cy + 6, 2, B - cy - 8)
  gfx.fillRect(cx - 3, cy + 4, 6, 3)                                    -- the socket it sits in
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 9, cy - 14, 18, 18)
  UI.ink("brass")
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 9, cy - 14, 18, 18)
  local big = (math.floor(frames / (8))) % 2 == 0                                    -- the bulb pulses
  UI.ink("flame")
  if big then gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 3, cy - 10, 6, 6); gfx.setColor(BLACK) end
  gfx.drawEllipseInRect(cx - 3, cy - 10, 6, 6)
  UI.ink("gray")
  gfx.fillRect(cx - 2, cy - 4, 4, 2); gfx.fillRect(cx - 1, cy - 2, 2, 3)   -- the bulb's neck and base
  UI.ink("inkorange")
  gfx.drawLine(cx - 1, cy - 8, cx - 1, cy - 6); gfx.drawLine(cx, cy - 8, cx, cy - 6)     -- the filament
  UI.ink("white")
  gfx.setColor(WHITE); gfx.drawLine(cx - 6, cy - 9, cx - 5, cy - 11); gfx.setColor(BLACK)    -- a shine on the glass
  UI.ink("inkyellow")
  local p = (math.floor(frames / (6))) % 4                                           -- a ring of light sparkles round it
  for i = 0, 7 do
    if (i + p) % 4 < 2 then
      local a = i * math.pi / 4
      gfx.drawPixel(cx + math.floor(math.cos(a) * 12 + 0.5), cy - 5 + math.floor(math.sin(a) * 12 + 0.5))
    end
  end
end

function CAFE.art.tiffany(cx, cy, drop)          -- a stained-glass dome on a round vase base: leaded panes and a jewelled rim (drop = a shorter stem, for the table lamp)
  local B = cy + 14
  local yb = cy - 2 + (drop or 0)                                                      -- the dome's lower edge
  UI.ink("bark")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 7, B - 2, 14, 3, 1)                             -- foot
  gfx.fillEllipseInRect(cx - 6, B - 11, 12, 10)                          -- the round base
  gfx.fillRect(cx - 1, yb + 1, 2, B - 11 - yb)                           -- stem
  gfx.fillRect(cx - 3, yb + 1, 6, 2)
  local out = CAFE.domeRows(12, 11)
  for r = 0, 10 do gfx.drawLine(cx - out[r], yb - r, cx + out[r] - 1, yb - r) end              -- the dome (a black frame)
  local ins = CAFE.domeRows(11, 8)
  gfx.setColor(WHITE)
  for r = 0, 7 do UI.ink((r < 2) and "redp" or ((r < 5) and "jack" or "leaf")); gfx.drawLine(cx - ins[r], yb - 2 - r, cx + ins[r] - 1, yb - 2 - r) end        -- the panes of glass
  gfx.setColor(BLACK)
  local f1, f2 = 0.34, 0.68
  UI.ink("lav")
  for r = 3, 5 do                                                        -- the outer panes are a darker colour
    local y, k1, k2 = yb - 2 - r, math.floor(f1 * ins[r]), math.floor(f2 * ins[r])
    gfx.setPattern(CHECK)
    gfx.fillRect(cx + k1 + 1, y, k2 - k1 - 1, 1); gfx.fillRect(cx - k2, y, k2 - k1 - 1, 1)
  end
  UI.ink("bark")
  gfx.setColor(BLACK)
  for _, f in ipairs({ f1, f2 }) do                                      -- the leading that runs up the dome, curving with it
    local px, py, qx
    for r = 0, 7 do
      local k = math.floor(f * ins[r])
      local x, y = cx + k, yb - 2 - r
      if px then gfx.drawLine(px, py, x, y); gfx.drawLine(qx, py, cx - 1 - k, y) end
      px, py, qx = x, y, cx - 1 - k
    end
  end
  gfx.drawLine(cx - ins[5], yb - 7, cx + ins[5] - 1, yb - 7); gfx.drawLine(cx - ins[2], yb - 4, cx + ins[2] - 1, yb - 4)
  gfx.fillRect(cx - 12, yb - 1, 24, 3)                                   -- the rim, with a row of jewels
  gfx.setColor(WHITE)
  UI.ink("skyp")
  for x = cx - 10, cx + 9, 4 do gfx.drawPixel(x, yb) end
  UI.ink("white")
  local t = (math.floor(frames / (3))) % 14                                           -- a glint runs across the glass
  gfx.drawPixel(cx - 7 + t, yb - 6 - math.floor(math.abs(t - 7) / (3))); gfx.setColor(BLACK)
  UI.ink("inkorange")
  local g = (math.floor(frames / (9))) % 2                                            -- coloured light falls on the table
  gfx.drawLine(cx - 10, yb + 4, cx - 12 - g, yb + 7); gfx.drawLine(cx + 9, yb + 4, cx + 11 + g, yb + 7)
  gfx.drawLine(cx - 1, yb + 4, cx - 1, yb + 5)
end

function CAFE.art.streetlamp(cx, cy)            -- an old iron lamp post: a glass lantern with a roof, curved brackets and a moth
  local B = cy + 14
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 5, B - 3, 10, 4); gfx.fillRect(cx - 3, B - 7, 6, 4)       -- stepped base
  gfx.fillRect(cx - 1, cy - 8, 2, B - 7 - cy + 8)                             -- the post
  gfx.fillRect(cx - 2, cy + 3, 4, 2); gfx.fillRect(cx - 2, cy - 4, 4, 2)       -- collars
  gfx.drawLine(cx - 2, cy - 3, cx - 6, cy - 8); gfx.drawLine(cx + 1, cy - 3, cx + 5, cy - 8)   -- brackets that hold the lantern up
  gfx.drawLine(cx - 2, cy - 2, cx - 6, cy - 6); gfx.drawLine(cx + 1, cy - 2, cx + 5, cy - 6)
  gfx.fillRect(cx - 6, cy - 9, 12, 2)                                          -- the lantern's floor
  UI.ink("glow")
  gfx.setColor(WHITE); gfx.fillRect(cx - 5, cy - 17, 10, 8)
  UI.ink("slate")
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 5, cy - 17, 10, 8)
  gfx.fillRect(cx - 5, cy - 17, 1, 8); gfx.fillRect(cx + 4, cy - 17, 1, 8)
  gfx.fillPolygon(cx - 7, cy - 17, cx + 6, cy - 17, cx, cy - 20, cx - 1, cy - 20)             -- the roof
  gfx.fillRect(cx - 1, cy - 22, 2, 3)
  if (math.floor(frames / (5))) % 7 ~= 3 then                                               -- the light (it flickers now and then)
    UI.ink("flame")
    gfx.fillEllipseInRect(cx - 2, cy - 15, 4, 5)
    gfx.setColor(WHITE); gfx.drawPixel(cx - 1, cy - 14); gfx.setColor(BLACK)
    UI.ink("inkyellow")
    gfx.drawLine(cx - 8, cy - 15, cx - 10, cy - 17); gfx.drawLine(cx + 7, cy - 15, cx + 9, cy - 17)
    gfx.drawLine(cx - 8, cy - 11, cx - 10, cy - 10); gfx.drawLine(cx + 7, cy - 11, cx + 9, cy - 10)
  end
  UI.ink("gray")
  local a = frames * 0.2                                                       -- the moth
  local mx, my = cx + math.floor(math.cos(a) * 11), cy - 13 + math.floor(math.sin(a * 1.3) * 5)
  gfx.drawPixel(mx, my); gfx.drawPixel(mx - 1, my - 1 + (math.floor(frames / (2))) % 2); gfx.drawPixel(mx + 1, my - 1 + (math.floor(frames / (2))) % 2)
end

function CAFE.art.paperlamp(cx, cy)             -- a ribbed paper lantern on a little wooden tripod
  local B = cy + 14
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 8, cx - 8, B); gfx.drawLine(cx + 2, cy + 8, cx + 7, B)             -- the legs
  gfx.fillRect(cx - 1, cy + 8, 2, B - cy - 9)
  gfx.fillRect(cx - 9, B - 1, 3, 2); gfx.fillRect(cx + 6, B - 1, 3, 2)
  UI.ink("redp")
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 8, cy - 13, 16, 22)
  gfx.setColor(BLACK); gfx.drawEllipseInRect(cx - 8, cy - 13, 16, 22)
  for k = 1, 5 do                                                                              -- paper ribs, curved round the belly
    local y = cy - 13 + math.floor(k * 22 / (6))
    local fy = (y - (cy - 2)) / 11
    local hw = math.floor(8 * math.sqrt(math.max(0, 1 - fy * fy)) + 0.5)
    gfx.drawLine(cx - hw, y, cx - 1, y + 1); gfx.drawLine(cx, y + 1, cx + hw - 1, y)
  end
  UI.ink("bark")
  gfx.fillRect(cx - 3, cy - 14, 6, 3); gfx.fillRect(cx - 3, cy + 7, 6, 3)                      -- the top and bottom rings
  gfx.fillRect(cx - 1, cy - 16, 2, 2)
  if (math.floor(frames / (12))) % 2 == 0 then                                                              -- the lantern breathes with light
    UI.ink("flame")
    gfx.setPattern(CHECK); gfx.fillEllipseInRect(cx - 4, cy - 6, 8, 10); gfx.setColor(BLACK)
  end
  UI.ink("inkyellow")
  local g = (math.floor(frames / (10))) % 2
  gfx.drawPixel(cx - 11 - g, cy - 4); gfx.drawPixel(cx + 10 + g, cy - 4); gfx.drawPixel(cx - 11, cy + 2 + g); gfx.drawPixel(cx + 10, cy + 2 + g)
end

function CAFE.art.cattree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy - 13, 4, 26)
  gfx.fillRect(cx - 10, cy + 12, 20, 3)
  gfx.fillRect(cx - 10, cy - 14, 20, 3)
  gfx.fillRect(cx - 9, cy - 1, 18, 3)
  gfx.setColor(WHITE)
  for k = -8, 6, 4 do gfx.drawPixel(cx + k, cy - 13) end
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy - 1, cx + 7, cy + 5)            -- a hanging toy
  gfx.fillCircleAtPoint(cx + 7, cy + 6, 2)
end

function CAFE.art.dogbed(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillEllipseInRect(cx - 9, cy + 3, 18, 8)
  gfx.setColor(BLACK)
end

CAFE.SPR = {
  plant = { "...........kk...........", "...........kk...........", "..........kwkk..........", "....k.....kwwk....kk....", "...kwk....kwkk...kwk....", "...kwkk..kwwwkk.kwwk....", "...kwwkk.kwwkwk.kwkk....", "...kwwwk.kwwwkkkwwwk....", "...kwwkwkkwwkwkkwwkk....", "kk..kwwkkkwwwkkwwkwk.kk.", "kwkkkwwwkkwwkwkwwwkkkwk.", "kwwkkwwkwkwwwkkwwkkwwkk.", ".kwwkkwwkkwwkwkwkwkwkk..", ".kwwwkwwwkkwwkkwwkwkwk..", "..kwwwkwkkkwkkkwkkkwk...", "...kwwkwwkkwwkkkkkwk....", "....kkwkwk.kk.kwkkk.....", "......kkkk.kk.kkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  fern = { "........................", "........................", "...........kk...........", "...........kk...........", "...........kk...........", "..........kwwk..........", "..........kwkk..........", "..........kwwk..........", "...kkk....kwkk....kkk...", "....kkkk..kwwk..kkwk....", "....kwkwk.kwkk.kkwkk....", ".....kwkwkkwwkkwwkk.....", ".....kwwkkkwkkkwkwk.....", "......kwwkkwwkwkwk......", "..kkkkkkkwkwkkwwkkkkkk..", ".kwwwwwkkkkkkwkkwwwkwkk.", "kkkkwkkwkkkkkkkkkwkkkkkk", "....kkkkkkkkkkwwkkkk....", "....kkkkkkkkkkkkkkkk....", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  flowers = { "...........kkk..........", "........kkkwwwk.........", "......k.kwwkkkkk........", ".....kwkkwkkkkwwk.k.....", "..kkkwwwkkkkwkwk.kwk....", "..kwwkkkkwwkkwkkkwwwk...", "..kwkkkkkwwkwwkwwkkkkk..", "..kkkkwkwkkkkkkwkkkkwwk.", "..kwwkkwkk..k.kkkkwkwk..", "..kwwkwwk...k.kwwkkwkk..", "...kkkkkk...k.kwwkwwk...", ".......k....k..kkkkkk...", ".....kkkkk..k.kkkkk.....", ".....kwwwwk.kkwwwwk.....", ".....kwwwwk.kkwwwwk.....", "......kwwwwkkwwwwk......", "......kwwwwkkwwwwk......", ".......kkkkkkkkkk.......", ".........k..k..k........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  pumpkin = { "................kk......", "...........kkk.k........", "...........kkk..........", "..........kkkk..........", "......kkkkwwwwkkkk......", ".....kwwkwwwwwwkwkk.....", "...kkwwkwwwwwwwwkwkkk...", "..kwwwkwkwwwwwwkwkwkwk..", "..kwwwkkkkwwwwkkkkkwkk..", ".kwwwwkkkkkwwkkkkkwkwkk.", ".kwwwwkwwwwwwwwwkkkwkwk.", ".kwwwwkwwwwkkwwwwkwkwkk.", ".kwwwwkkkwwwwwwkkkkwkwk.", "..kwwwkkkkkkkkkkkkwkwk..", "..kwwwkwwkkwwkkwkkkwkk..", "...kkwwkwwwwwwwwkkwkk...", ".....kwwkwwwwwwkkwk.....", "......kkkkwwwwkkkk......", "..........kkkk.........." },
  snake = { "...........kk...........", ".......kk..kk...........", ".......kkkkwkk..........", ".......kwkkwwk.kk.......", "..kk..kwkkkwkwkwk.......", "..kkk.kwwkkwwkkwk...kk..", "..kwk.kwwkwwkwkwkk.kwk..", "..kwwkkwwkwwwkkkwk.kwk..", "..kwkkkwwkwwkwkwkkkwkk..", "..kwwkkwwkwwwkkkwkkwwk..", "...kwwkwwkwwkwkwkkwwkk..", "...kwkkkwkwwwkkkwkwkk...", "...kwwkkwwkwkwkwkkwwk...", "...kwwwkwkkwwkkkkwwkk...", "....kwkkwwkwkwkwkwkk....", "....kwwkkwkwwkkkkwwk....", ".....kkkkwkkkkkkkwk.....", ".....kwkkwkkwkwkkkk.....", "......kk.kk.kkk.kk......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  tree0 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kkkwkk.........", "........kwkkkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwwwkwk.......", "......kkwkwkwwkkwk......", ".....kkkkwwwkwkkkkk.....", ".......kwwwkwkwkk.......", ".......kkwkwkwkwk.......", "......kkkkkkwkwkwk......", ".....kkkkkkwkwwwkwk.....", "....kkwkkkwkwwwkkkwk....", "...kkkkkkwkwwwkkkkkkk...", "......kkwkwwwkwkkk......", "......kwkwkkkwkwwwk.....", "....kkwkwkwkwkwkwwwk....", "...kkkkwkwkkkwkwkwkkk...", "..kkwkkkwwwkkkwwwkkkwk..", ".kkkkkkkwkkkkkwwkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  tree1 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kwwwkk.........", "........kwwwkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwkkkwk.......", "......kkwkwkkkwwwk......", ".....kkkkkkwkwwwkkk.....", ".......kwkkkwkwkk.......", ".......kkwkwkwkwk.......", "......kwwkkkwkwkwk......", ".....kkwwkkwkkkwkwk.....", "....kkwkkkwkwkkwwkwk....", "...kkkkkkwkkkwkwwkkkk...", "......kkwkwkkkwkkk......", "......kwkwkkkwkwkkk.....", "....kkwkwkwkwkwkkkwk....", "...kkwwwkwkwwwkwkwwwk...", "..kkwwwkkkwwwkkkwkwwwk..", ".kkkkkkkkkkkkkkkkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  monstera = { "..........kkkk..........", "........kkwwwwkk........", ".......kwwwwwwwwkk......", ".......kwwwkwwwwwk......", "...kkkk.kwwkwwwwkk.kkkk.", ".kkwwwwkkwwkwwwkwkkwwwkk", "kwwwwkwwkwwkwwwwkwwkwwwk", "kwwwkwwwwkwkwwwkkwwwkwwk", ".kwwwwwwwwkkkwkwkwwwwwkk", "..kkwwwwwkkkkkwkkwwwwkk.", "....kkkkkwkkkkkwkkkkkk..", ".......kkkkkkkkkkk......", ".........kk.kk.kk.......", "..........kk.k.kk.......", "...........kkkk.........", "............kk..........", "............kk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  palm = { ".......kkkk......kkkk...", ".....kkwwwwkk..kkwwwwkk.", "...kkwwwwwwwkkkkwwwwwwkk", "..kwwwwkwwwwwkkwwwwkwwwk", ".kwwkkkkkkwwwkwwwkkkkkwk", "kwwk......kkwwkkk.....kk", "kk..........kkk.........", "......kkkk..kwk..kkkk...", "....kkwwwwkkkwkkkwwwwkk.", "...kwwwkwkwwkwkwwkwkwwwk", "..kwkkk.kwwwkkwwwk.kkkwk", ".kk......kkwkkwkk.....kk", "...........kkk..........", "..........kwkkk.........", "..........kwkwk.........", "...........kwk..........", "..........kwkwk.........", "..........kkkwk.........", "...........kkk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  sunflower = { ".........kkkkkk.........", "......kk.kwwwwk.kk......", ".....kwwkkwwwwkkwwk.....", "..kk..kwwkkkwkkwwk..kk..", ".kwwk.kkkkkwkwkkkk.kwwk.", ".kwwwkkkwkkkwkwkkkkwwwk.", "..kwwwkkkkkkkwkwkkwwwk..", "...kkwwkkkwkwkkkwkwwkk..", ".....kkwkkkwkwkkkkwkk...", ".......kkwwkkkkwwkk.....", ".........kkkkkkkk.......", "...........kk...........", "...........kkk..........", "....kkk....kwk....kkk...", "..kkwwwkk..kkk..kkwwwkk.", ".kwwwkwwwkkkwkkkwwwkwwwk", "..kkkkkwwwkkkkkwwwkkkkk.", ".......kkkkkwkkkk.......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  cactus = { "..........kkkk..........", ".........kwwwwk.........", "........kwwwwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", "........kwwkwwwk...kkk..", "..kkk...kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwk..kwwkk.", ".kwwkk..kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwkkkkwwkk.", ".kwwkk..kwwkwwkkwwwwwwk.", ".kwwwkkkkwwkwwwkkkkkkkk.", ".kwwwwwwkwwkwwkk..kkkk..", "..kkkkkwkwwkwwwk........", ".......kkwwkwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", ".........kwwwkk.........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  bonsai = { "........................", ".........kkkkkkkk.......", ".......kkwwwwwwwwkk.....", "......kwwwwkwwwkwwwk....", "..kkkkwwwwkwwwkwwwwwkkk.", ".kwwwwkwwwwwwwwwwwwwwwwk", "kwwwkwwkkkkkkkkkwwwwwwwk", "kwwwwwwwkkwwkkwwwwwwwkwk", ".kkkwwwkkkwwwkkwwwwkkkk.", "....kkkk..kwwk..kkkk....", "..........kwwk..........", "..........kkwk..........", ".........kwwk...........", "........kkwkk...........", "........kwwwkk..........", ".......kkwwkkkk.........", "......kkkkkkkkkkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  daisies = { ".....kkkkk......", ".....kwkkkk.....", "....kkkkkkwk....", ".kkkkwkkkkk.k...", ".kwkkkkkkkkkwk..", ".kkkkkkwkkwkkkk.", "kwkkkkkkkkkkkkwk", ".kkkkwk.kwkkkkk.", "..kwkkk.kkkkkwk.", "...kk...k.kwkkk.", ".....k..k..kk...", ".....k..k..k....", "....kkkkkkkk....", "....kwkwkkkk....", "....kwwwwwkk....", "....kwwwwkwk....", "....kwwwwwkk....", "....kwwwwkwk....", ".....kwwwwk.....", ".....kwwwkk.....", ".....kwwwwk.....", ".....kkkkkk....." },
  tulips = { "......kk.k......", ".....kwwkkk.....", ".....kwwkwk.....", "..kk.kwwwkk.....", ".kwwkwkwkkkk.k..", ".kwwwkkkkkwwkkk.", ".kwwkwk.kkwwkwk.", "..kwwk..kkwwwkk.", "..kkkk..k.kwkk..", "..kwwkk.kkkkkk..", "...kwwk.kkwwk...", "...kkwwkkwwkk...", ".....kkkkkk.....", "......k.k.k.....", ".......kk.......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  succ = { ".......kk.......", ".......kk.......", "......kwkk......", "...kk.kwwk.kk...", "..kwkkkwkkkwkk..", "..kwwkwwwkkwwk..", ".kkwwkwwkwkwkkk.", ".kwkwkwwwkkkkwk.", ".kwkwwkwkkkwkwk.", "..kkwwkwwkwkkk..", "..kwkwkwkkkkkk..", "...kkkwkkkkkk...", ".....kkkkkk.....", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  minicac = { "................", "......kkkk......", "......kwkk......", ".....kwwkkk.....", "...kkkwwkwk.....", "...kkkwwwkk.kk..", "...kkkwwkwk.kk..", "...kwkwwkkk.kk..", "...kkkwwkwkkwk..", ".....kwwwkkkkk..", ".....kwwkwk.....", "......kwkk......", "......kkkk......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  herbs = { "................", "................", "......kkkk......", ".....kwwwkk.....", "....kwwwkwkk....", "....kwwkwkwk....", "....kwwwkwkk....", "..kkkwkkkkwkkk..", ".kwwkkwwkwkwkwk.", ".kwwwkwwwkkkwkk.", ".kwwkkwwkkkwkwk.", ".kwwwkwwwkkwwkk.", "..kkkkkkkkkkkk..", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  clock = { "........................", ".......kkkkkkkkkk.......", "......kwwwwwwwwwwk......", "....kkwwkkkkkkkkwwkk....", "...kwwwkwwwwwwwwkwwwk...", "...kwkkwwwwwkwwwwkkwk...", "..kwwkwwkwwwwwwwkwkwwk..", ".kwwkwwwwwwwwwwwwwwkwwk.", ".kwkwwkwwwwwwwwwwwkwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwkwwwwwwwwwwwwwkkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwwkwkwwwwwwwwwwwkkwwk.", "..kwwkwwwwwwwwwwwwkwwk..", "...kwkkwkwwwwwwwkkkwk...", "...kwwwkwwwwkwwwkwwwk...", "....kkwwkkkkkkkkwwkk....", "......kwwwwwwwwwwk......", ".......kkkkkkkkkk.......", "........................" },
  cuckoo = { "...........kk...........", "..........kwwk..........", ".........kwwkwk.........", "........kkkkkkkk........", ".......kwkkkkkkwk.......", ".....kkwwkkkkkkkwk......", "....kwwwwkkkkkkwkwk.....", "...kwkwkwkkkkkkkwkwk....", "..kwwwwwwkkkkkkwkwkwk...", ".kkkkkkkkkkkkkkkkkkkkk..", "..kkkkkkkkkkkkkkkkkkk...", "..kwwwwwwwwkkwwwwwwkk...", "..kwwkwwwkkwwkkwwwkwk...", "..kwwwwwkwwwkwwkwwwkk...", "..kwwwwkwwwwwwwwkwkwk...", "..kwwwwkwwwwwwwwkwwkk...", "..kwwwkwwwwwwwwwwkkwk...", "..kwwwkwkwwwwwwwkkwkk...", "..kwwwwkwwwwwwwwkwkwk...", "..kwwwwkwwwwwwwwkwwkk...", "..kwwwwwkwwwwwwkwwkwk...", "..kwwwwwwkkwkkkwwwwkk...", "..kwwwwwwwwkkwwwwwkwk...", "..kkkkkkkkkkkkkkkkkkk...", "........................" },
  calendar = { "......k........k......", "......k........k......", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkwkwkwkwkwkwkwkwkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kkkkkkkkkkkkkkkkkkk..", "......................", "......................" },
  cattree = { "........................", ".kkkkkkkkkkkkkkkkkkkkk..", ".kwkwkwkwkwkwkwkwkwkwk..", ".kkkkkkkkkkkkkkkkkkkkk..", "..........kkk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "...kkkkkkkkkkkkkkkkk....", "...kwwwwwwwwwwwwwwwk....", "...kkkkkkkkkkkkkkkkk....", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..kkkkkkkkkkkkkkkkkkk...", "..kwwwwwwwwwwwwwwwwwk...", "..kkkkkkkkkkkkkkkkkkk...", "........................" },
  dogbed = { "..............................", "..............................", "..............................", ".......kkkkkkkkkkkkkkkk.......", ".....kkwwwwwwwwwwwwwwwwkk.....", "...kkwwwwkkkkkkkkkkkkwwwwkk...", "..kwwwkkkwkwkwkwkwkwkkkkwwwk..", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kwwwkkwkwkwkwkwkwkwkwkwkwwwk.", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kkwkwkkkwkwkwkwkwkwkkkkkwkwk.", "..kkwkwkwkkkkkkkkkkkkkwkwkwk..", "...kkwkwkwkwkwkwkwkwkwkwkkk...", ".....kkkwkwkwkwkwkwkwkwkk.....", ".......kkkkkkkkkkkkkkkk.......", ".............................." },
}
CAFE.SPRPOT = { plant = 18, fern = 19, flowers = 20, snake = 20, palm = 20, monstera = 18, sunflower = 19, bonsai = 17, cactus = 18, tulips = 15, succ = 13, minicac = 13, herbs = 13, daisies = 12 }

-- ---- pixel-art sprites: drawn once from the text pictures above into images, then just stamped ------
CAFE.SPRIMG = {}

-- ---- the counter machines (drawn once into the counter picture; the mugs and coins are stamped live)
CAFE.SPR.m_register = {
  "...kkkkkkkkkkkkkkk....kkkk.....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkkk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkwk....",
  "..kwwwwwwwwwwwwwwwk...kwwwk....",
  "..kwwwwwwwwwwwwwwwk...kkkkk....",
  "...kkkkkkkkkkkkkkk....kwwwk....",
  "........kkkkk.........kwwwk....",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk.",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkkkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkwkkwwk",
  "kwwwwwwwwwwwwwwwwwwwkkwwwwkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkwkkkwwk",
  "kwwkkwkkwkkwkkwkkwwwkkkkkkkkwwk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkkkkkkwwwwwwwwwkkkkkkkkkkk",
  "kkkkkkkkkkkwwkkkkkwwkkkkkkkkkkk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"
}
CAFE.SPR.m_coffee = {
  "..........kkkkkkkkkkkkkkk..........",
  ".......kkkkkkkkkwwwkkkkkkkkk.......",
  ".....kkkwwkkkkkwwwkwkkkkkkwkkk.....",
  "..kkkkkwkkkkkkwwwkkwwkkkkkkwkkkkk..",
  ".kkkkkkkkkkkkkwwwkwwwkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkwwwwwwwkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkkwwwwwkkkkkkkkkkkkkk.",
  ".kkkkkkkkkkkkkkkwwwkkkkkkkkkkkkkkk.",
  ".kkkkkkkkkwwwwwwwwwwwwwwwkkkkkkkkk.",
  ".kkkwwwkkwkkkkwwkkkwwkkkkwkwwwwwwk.",
  ".kkwwkwwkwkkkkwwkkkwwkkkkwkwkwkkwk.",
  ".kkwwkwwkwkkkkwkkkkkwkkkkwkwwwwwwk.",
  ".kkwwwwwkwkkkwwwwwwwwwkkkwkkkkkkkk.",
  ".kkkwwwkkwkkkwkkkkkkkwwwkwkkkkkkkk.",
  ".kkkkkkkkwkkkwwwwwwwwwkwkwkwwkkwwk.",
  ".kkwkwkwkwkkkkwwwwwwwkwwkwkwwkkwwk.",
  ".kkkkkkkkwkwwwwwwwwwwwwwkwkkkkkkkk.",
  "..kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk..",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkwkwkwkwkwkwkwkwkwkwkwkwkwkwkwkwkk",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk."
}
CAFE.SPR.m_mixer = {
  ".............kkk.............",
  "............kkkkk............",
  ".......kkkkkkkkkkkkkk........",
  ".......kkwwwwwwwwwwwk........",
  "........kkkwwwwwwwwwkkkk.....",
  "........kkwwwwwwwwwwk..k.....",
  "........kwkwkwkwkwkwk..k.....",
  ".........kkwkwkwkwkk...k.....",
  ".........kwwwwwwwwwk...k.....",
  ".........kkwwwkwkwkk...k.....",
  "..........kwkwkwkwk.kkkk.....",
  "..........kkwkwkwkk..........",
  "..........kwkwkwkwk..........",
  "...........kkkkkkk...........",
  "..kkkkkkkkkkkkkkkkkkkkkkkkk..",
  ".kkkkkwwwkkkkkkkkkkkkkkkkkkk.",
  ".kkkkwwkwwkkkwwkkwwkkwwkkkkk.",
  ".kkkkwwkwwkkkwwkkwwkkwwkkkkk.",
  ".kkkkwwwwwkkkkkkkkkkkkkkkkkk.",
  ".kkkkkwwwkkkkkkkkkkkkkkkkkkk.",
  "..k.kkkkkkkkkkkkkkkkkkkkkkk.."
}
CAFE.SPR.m_pickup = {
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  ".............................",
  "..................k.....k....",
  ".....................kkk.....",
  ".................k...kkk.k...",
  "..................wkkkkkkkw..",
  "..................kkkkkkkkk..",
  "..................kkwkkkkkk..",
  ".....kkkkkkkkk....kkwkkkkkk..",
  ".kk.kkwwwwwwwkk..kkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kkkwwwwwwwwwwwwwwwwwwwwwwwkkk",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkk"
}
CAFE.SPR.m_sink = {
  ".........................kkkkk.",
  "..................kkkkkkkkkkk..",
  "..................kkk.....kkk..",
  ".................kkkkk....kkk..",
  "...................k.....kkkkk.",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwkwkwkwwwwwkwkwkwwwwwkwkwkwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwwkwwwwk",
  "kwwwwwwwwwwwwwwwwwwwwwwwkwkkwwk",
  "kwkwkwkwwwwwkwkwkwwwwwkwkkkwkwk",
  "kwkwkwkwkwkwkwkwkwkwkwkwkwkkkwk",
  "kkwwwwwwwwwwwwwwwwwwwwwwwwwwwkk",
  ".kkkkkkkkkkkkkkkkkkkkkkkkkkkkk."
}
CAFE.SPR.m_jar = {
  ".......kkkkkkk.......",
  ".......kwwwwwk.......",
  ".......kwwkwwk.......",
  "kkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkwwwwwwwwwkkkkkk",
  "kkwkkwkkwkkwkkwkkwkkk",
  "kkwkkwkkwkkwkkwkkwkkk",
  "kkkkkkkkkkkkkkkkkkkkk",
  "kkkkkkkkkkkkkkkkkkkkk",
  "..kkkkkkkkkkkkkkkkk..",
  "..kwwwwwwwwwwwwwwwk..",
  ".kkwwwwwwwkwwwwwwwkk.",
  ".kkwwwwwwkkkkwwkwkkk.",
  ".kkwwwwwkwkwwwwwkwkk.",
  ".kkwwwwwwkkkwwwkwkkk.",
  ".kkwwwwwwwkwkwwwkwkk.",
  ".kkwwwwwkkkkwwwkwkkk.",
  ".kkwwwwwwwkwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkwwwwwwwwwwwwkwkkk.",
  ".kkwwwwwwwwwwwwwkwkk.",
  ".kkkwwwwwwwwwwwwwkkk.",
  ".kkkkkkkkkkkkkkkkkkk.",
  "..kkkkkkkkkkkkkkkkk.."
}
CAFE.SPR.m_mug = {                                 -- a dirty mug in the sink: solid dark, so you can count them at a glance
  "kkkkkkww",
  "kwkkkkkk",
  "kkkkkkwk",
  "kkkkkkkk",
  "kkkkkkww"
}
CAFE.SPR.m_coin = {
  "wkkkw",
  "kkwkk",
  "wkkkw"
}
CAFE.SPR.saltlamp = {
  "......kkkk......",
  ".....kwwwwk.....",
  "....kwwwwwwk....",
  "...kwwwkwwwwk...",
  "..kwwwwkwwwwwk..",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkkwwwk.",
  ".kwwwkwwwkwkwwk.",
  ".kwwwkwwwkkwkwk.",
  ".kwwwwkwwwkwkwk.",
  ".kwwwwkwwwkkwwk.",
  "..kwwwwkwwwkwk..",
  "..kwwwwwkwwwwk..",
  "...kkwwwwwwkk...",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk.",
  "..kkkkkkkkkkkk.."
}
CAFE.SPR.lavalamp = {
  ".....kk.....",
  "....kwwk....",
  "...kwwwwk...",
  "..kkkkkkkk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  "..kkkkkkkk..",
  "...kkkkkk...",
  "..kkkkkkkk..",
  ".kkkkkkkkkk.",
  "kkkkkkkkkkkk",
  "kkkkkkkkkkkk"
}
CAFE.SPR.neoncup = {
  ".kkkkkkkkkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkwwwwwwwwwwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkkwwwwwwwwkkkwkk",
  "kkwkwwwwwwwwwwwwkwkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkkkkkkkkkkkkkkkkkkk",
  ".kkkkkkkkkkkkkkkkkk."
}

CAFE.SPR.floorlamp = {
  ".....kkkkkk.....",
  "....kwwwwwwk....",
  "...kwwkwwkwwk...",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkwwwwk.",
  ".kwwwwkwwkwwwwk.",
  "kkkkkkkkkkkkkkkk",
  "..kkkkkkkkkkkk..",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  "......kkkk......",
  "....kkkkkkkk....",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk."
}

CAFE.SPR.cp5 = {
  "......kk......",
  "......kk......",
  "...kkkkkkkk...",
  ".kkwwwkkwwwkk.",
  "kwwwwwkkwwwwwk",
  "kwwkkwwwwkkwwk",
  "kwwkkwwwwkkwwk",
  "kwwwwwwwwwwwwk",
  "kwwwkwkwkwkwwk",
  "kwwwwkwkwkwwwk",
  ".kwwwwkkwwwwk.",
  "..kkkkkkkkkk.."
}
CAFE.SPR.cp6 = {
  "......k......",
  ".....kkk.....",
  "...kkkkkkk...",
  "....kkkkk....",
  "....kk.kk....",
  "......k......",
  ".....kkk.....",
  "....kkwkk....",
  ".....kkk.....",
  "....kwkkk....",
  "...kkkkkwk...",
  "....kkkkk....",
  "...kwkkkkk...",
  "..kkkkkwkkk..",
  "...kkkkkkk...",
  "..kkkkwkkwk..",
  ".kkwkkkkkkkk.",
  ".....kkk.....",
  ".....kkk....."
}

function CAFE.spr(key, part)
  local ck = part and (key .. part) or key
  local im = CAFE.SPRIMG[ck]
  if im == nil then
    local rows = CAFE.SPR[key]
    local w, h = #rows[1], #rows
    local y0, y1 = 1, h
    if part and CAFE.SPRPOT[key] then
      if part == "top" then y1 = CAFE.SPRPOT[key] else y0 = CAFE.SPRPOT[key] + 1 end
    end
    im = gfx.image.new(w, y1 - y0 + 1, gfx.kColorClear)
    gfx.pushContext(im)
    for y = y0, y1 do
      local r = rows[y]
      for x = 1, w do
        local c = string.sub(r, x, x)
        if c == "k" then gfx.setColor(BLACK); gfx.drawPixel(x - 1, y - y0)
        elseif c == "w" then gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - y0) end
      end
    end
    gfx.popContext()
    CAFE.SPRIMG[ck] = im
  end
  return im
end

function CAFE.stamp(key, cx, bottom, dx)         -- centred on cx, standing on y = bottom
  local im = CAFE.spr(key)
  local w, h = im:getSize()
  im:draw(cx - math.floor(w / (2)) + (dx or 0), bottom - h + 1)
end

CAFE.SWK = {}
function CAFE.stampSway(key, cx, bottom, sw)     -- the leaves sway, the pot stays put
  local ks = CAFE.SWK[key]
  if not ks then ks = { key .. "top", key .. "bot" }; CAFE.SWK[key] = ks end
  local top = CAFE.SPRIMG[ks[1]] or CAFE.spr(key, "top")
  local bot = CAFE.SPRIMG[ks[2]] or CAFE.spr(key, "bot")
  local w, h = top:getSize()
  local _, h2 = bot:getSize()
  top:draw(cx - math.floor(w / (2)) + sw, bottom - h2 - h + 1)
  bot:draw(cx - math.floor(w / (2)), bottom - h2 + 1)
end

function CAFE.swayOf(speed, cx) return math.floor(math.sin(frames * speed + cx * 0.13) * 1.5 + 0.5) end
CAFE.FL = { plant = true, cactus = true, fern = true, flowers = true, palm = true, snake = true,
            sunflower = true, bonsai = true, monstera = true }
function CAFE.defFloor()
  for id in pairs(CAFE.FL) do
    CAFE.art[id] = function(cx, cy)
      CAFE.stampSway(id, cx, cy + 14, CAFE.swayOf(id == "fern" and 0.06 or 0.05, cx))
    end
  end
end
CAFE.defFloor()
function CAFE.art.tree(cx, cy)
  CAFE.stamp(((math.floor(frames / (20))) % 2 == 0) and "tree0" or "tree1", cx, cy + 15)
  UI.ink("inkgold")
  gfx.setColor(BLACK)                                   -- the star twinkles
  if (math.floor(frames / (10))) % 2 == 0 then
    gfx.drawPixel(cx - 5, cy - 12); gfx.drawPixel(cx + 5, cy - 12); gfx.drawPixel(cx, cy - 17)
  else
    gfx.drawPixel(cx - 6, cy - 13); gfx.drawPixel(cx + 6, cy - 13); gfx.drawPixel(cx - 5, cy - 10); gfx.drawPixel(cx + 5, cy - 10)
  end
end
function CAFE.art.pumpkin(cx, cy)
  CAFE.stamp("pumpkin", cx, cy + 13)
  if (frames + cx) % 90 < 6 then                        -- it blinks
    UI.ink("pumpk")
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 6, cy + 2, 5, 3); gfx.fillRect(cx + 1, cy + 2, 5, 3)
    gfx.setColor(BLACK)
    gfx.drawLine(cx - 6, cy + 3, cx - 2, cy + 3); gfx.drawLine(cx + 1, cy + 3, cx + 5, cy + 3)
  end
end
function CAFE.art.cattree(cx, cy)
  CAFE.stamp("cattree", cx, cy + 15)
  local sw = math.floor(math.sin(frames * 0.1) * 2 + 0.5)       -- the toy swings
  UI.ink("inkred")
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy + 3, cx + 7 + sw, cy + 9)
  gfx.fillCircleAtPoint(cx + 7 + sw, cy + 10, 2)
end
function CAFE.art.dogbed(cx, cy)
  CAFE.stamp("dogbed", cx, cy + 15)
  UI.ink("inkblue")
  gfx.setColor(BLACK)                                    -- little sleepy z's drift up
  for k = 0, 1 do
    local ph = (math.floor(frames / (6)) + k * 4) % 8
    local x, y = cx + 6 + k * 4, cy - 1 - ph
    if ph < 7 then
      gfx.drawLine(x, y, x + 2, y); gfx.drawPixel(x + 1, y + 1); gfx.drawLine(x, y + 2, x + 2, y + 2)
    end
  end
end
function CAFE.defCounter()
  for _, id in ipairs({ "tulips", "succ", "daisies", "minicac", "herbs" }) do
    CAFE.art[id] = function(cx, cy) CAFE.stampSway(id, cx, cy + 10, CAFE.swayOf(0.07, cx)) end
  end
end
CAFE.defCounter()
function CAFE.art.calendar(cx, cy)
  CAFE.stamp("calendar", cx, cy + 13)
  if (math.floor(frames / (15))) % 2 == 1 then                         -- a page corner flutters
    UI.ink("white")
    gfx.setColor(WHITE); gfx.fillRect(cx + 8, cy + 10, 3, 3)
    gfx.setColor(BLACK); gfx.drawLine(cx + 8, cy + 10, cx + 10, cy + 12)
  end
end

function CAFE.art.clock(cx, cy)
  CAFE.stamp("clock", cx, cy + 12)
  UI.ink("none")
  gfx.setColor(BLACK)
  local t = frames / 30                                  -- (always alive, here and in the shop preview)
  local am = t * 0.3                                     -- the minute hand sweeps round
  local ah = am / 12 + 1
  local sa = math.floor(t * 2) * (math.pi / 6)           -- the second hand ticks: a jump every half second
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 6), math.floor(cy - math.cos(am) * 6))
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 4), math.floor(cy - math.cos(ah) * 4))
  gfx.setLineWidth(1)
  UI.ink("inkred")
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(sa) * 8), math.floor(cy - math.cos(sa) * 8))
  UI.ink("brass")
  gfx.fillCircleAtPoint(cx, cy, 2)
  if math.floor(t * 2) % 2 == 0 then gfx.fillRect(cx - 1, cy + 5, 2, 2) end   -- a tick-tock dot under the middle
end

function CAFE.art.saltlamp(cx, cy)             -- a glowing crystal on a dark base: a wave of light ripples through its rays
  CAFE.stamp("saltlamp", cx, cy + 10)
  UI.ink("inkorange")
  gfx.setColor(BLACK)
  for i = 0, 8 do
    local a = math.pi + (i + 0.5) * math.pi / 9
    local len = 1 + math.abs((math.floor(frames / (3)) + i * 2) % 8 - 4)       -- every ray grows and shrinks, a beat behind its neighbour
    local r1, r2 = 12, 12 + len
    gfx.drawLine(cx + math.floor(math.cos(a) * r1 + 0.5), cy - 3 + math.floor(math.sin(a) * (r1 + 2) + 0.5),
                 cx + math.floor(math.cos(a) * r2 + 0.5), cy - 3 + math.floor(math.sin(a) * (r2 + 2) + 0.5))
  end
  UI.ink("inkwhite")
  if (math.floor(frames / (10))) % 2 == 0 then gfx.drawPixel(cx - 4, cy - 8); gfx.drawPixel(cx + 3, cy - 5) else gfx.drawPixel(cx + 4, cy - 9); gfx.drawPixel(cx - 3, cy - 4) end   -- the crystal twinkles
end

function CAFE.art.tiffanytab(cx, cy)             -- the same lamp, a little squatter so it sits on a table
  CAFE.art.tiffany(cx, cy - 3, 4)
end

function CAFE.art.itemstand(cx, cy)               -- a little round-topped stand: a floor spot that holds a table-top piece
  UI.ink("woodl")
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 13, cy + 1, 26, 5, 2)                           -- the top
  gfx.setColor(WHITE); gfx.drawLine(cx - 10, cy + 2, cx + 8, cy + 2); gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 6, 4, 8)                                     -- the stem
  gfx.fillRect(cx - 5, cy + 9, 10, 2)
  gfx.fillRoundRect(cx - 9, cy + 13, 18, 4, 2)                           -- the foot
end

function CAFE.art.lavalamp(cx, cy)             -- blobs of wax drift up and down inside the glass
  CAFE.stamp("lavalamp", cx, cy + 11)
  UI.ink("inkpink")
  gfx.setColor(BLACK)
  gfx.setClipRect(cx - 4, cy - 7, 8, 13)
  local a = frames * 0.045
  gfx.fillCircleAtPoint(cx - 1 + math.floor(math.sin(a * 1.3) * 1.5), cy + 3 - math.floor((math.sin(a) + 1) * 4.5), 3)
  gfx.fillCircleAtPoint(cx + 1, cy + 3 - math.floor((math.sin(a * 0.7 + 2.2) + 1) * 4.5), 2)
  gfx.fillRect(cx - 4, cy + 4, 8, 2)                                    -- the pool at the bottom
  gfx.clearClipRect()
end

function CAFE.art.floorlamp(cx, cy)            -- a pleated shade on a slim pole: its light flickers on and off
  CAFE.stamp("floorlamp", cx, cy + 14)
  local lit = (math.floor(frames / (24))) % 9 ~= 8                                   -- (an occasional flicker)
  if lit then
    UI.ink("inkyellow")
    gfx.setColor(BLACK)
    local r = ((math.floor(frames / (10))) % 2 == 0) and 3 or 1
    gfx.drawLine(cx - 9, cy - 6 + 1, cx - 12 - r, cy - 3 + r)
    gfx.drawLine(cx + 8, cy - 6 + 1, cx + 11 + r, cy - 3 + r)
    gfx.drawLine(cx - 4, cy - 5, cx - 5, cy - 2 + r)
    gfx.drawLine(cx + 3, cy - 5, cx + 4, cy - 2 + r)
  end
  gfx.setColor(BLACK)
end

function CAFE.art.neoncup(cx, cy)              -- a glowing cup sign on a dark plate, with blinking steam
  CAFE.stamp("neoncup", cx, cy + 12)
  UI.ink("nblue")
  gfx.setColor(WHITE)
  local ph = (math.floor(frames / (12))) % 2
  for i = 0, 1 do
    if (i + ph) % 2 == 0 then
      local x = cx - 3 + i * 5
      gfx.drawLine(x, cy - 1, x + 1, cy - 3); gfx.drawLine(x + 1, cy - 3, x, cy - 5); gfx.drawLine(x, cy - 5, x + 1, cy - 7)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.art.cuckoo(cx, cy)
  CAFE.cuckooBody(cx, cy)
  CAFE.cuckooDangle(cx, cy)
end

function CAFE.drawDangles()                    -- the cuckoo's pendulum and weights, drawn last so they hang in front
  local d = CAFE.dec()
  if not d or d.decor.cuckoo ~= "on" or not d.place.cuckoo then return end
  local cx, cy = CAFE.tileCenter(d.place.cuckoo)
  CAFE.cuckooDangle(cx, cy)
  gfx.setColor(BLACK)
end

function CAFE.cuckooBody(cx, cy)
  CAFE.stamp("cuckoo", cx, cy + 10)
  UI.ink("none")
  gfx.setColor(BLACK)
  local t = (G and G.t) or 0
  local am = t * 0.105
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am) * 4), math.floor(cy + 3 - math.cos(am) * 4))
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am / 12 + 1) * 2), math.floor(cy + 3 - math.cos(am / 12 + 1) * 2))
  if t % 30 < 2 then                                  -- the little bird pops out of the door
    UI.ink("yellow")
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 2, cy - 10, 5, 5)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy - 8, 2)
    gfx.fillTriangle(cx + 2, cy - 9, cx + 5, cy - 8, cx + 2, cy - 7)
  end
end

function CAFE.cuckooDangle(cx, cy)
  UI.ink("brass")
  gfx.setColor(BLACK)
  local sw = math.floor(math.sin(frames * 0.08) * 3)
  local s2 = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)                      -- pendulum
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + sw, cy + 19, 3)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx + sw, cy + 19, 3)
  UI.ink("bark")
  gfx.drawLine(cx - 8, cy + 11, cx - 8 + s2, cy + 18)             -- chains with pine-cone weights
  gfx.drawLine(cx + 8, cy + 11, cx + 8 - s2, cy + 16)
  gfx.fillTriangle(cx - 11 + s2, cy + 18, cx - 5 + s2, cy + 18, cx - 8 + s2, cy + 25)
  gfx.fillTriangle(cx + 5 - s2, cy + 16, cx + 11 - s2, cy + 16, cx + 8 - s2, cy + 23)
end

-- draw something that stays the same for the whole shift into a picture once, then just stamp it
-- (only the strip of the screen that holds the thing, y0 .. y0+h, is kept, so stamping it is cheap)
-- draw something once into a picture of just the area it covers (x0, y0, w, h); false if there's no memory for it
function CAFE.snap(drawfn, y0, h, x0, w)
  x0 = x0 or 0
  local ok, img = pcall(function() return gfx.image.new(w or 400, h, gfx.kColorClear) end)
  if ok and img then
    gfx.pushContext(img)
    gfx.setDrawOffset(-x0, -y0)
    drawfn()
    gfx.setDrawOffset(0, 0)
    gfx.popContext()
    return img
  end
  return false
end

function CAFE.cached(key, drawfn, y0, h, x0, w)
  local c = G[key]
  if c == nil then
    G[key] = false
    G[key] = CAFE.snap(drawfn, y0, h, x0, w)
    c = G[key]
  end
  if c then c:draw(x0 or 0, y0) else drawfn() end
end

CAFE.LIVEWALL = { clock = true, cuckoo = true, neoncup = true, neonheart = true, neonbolt = true, neonstar = true, neonmoon = true,
                  neonarrow = true, discoball = true }      -- (these move, so they are drawn every frame)
function CAFE.wallItemsRaw(live)               -- live = the moving ones (clocks), otherwise the still ones
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if (it.kind == "wall" or it.kind == "tiny") and d.decor[it.id] == "on" and d.place[it.id] and CAFE.TILES[d.place[it.id]]
       and ((CAFE.LIVEWALL[it.id] == true) == live) then
      local cx, cy = CAFE.tileCenter(d.place[it.id])
      local fn = (it.id == "cuckoo") and CAFE.cuckooBody or CAFE.art[it.id]     -- (the cuckoo's dangly bits come later)
      fn(cx, cy)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.tinyRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "tiny" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.XSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.counterRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "counter" and d.decor[it.id] == "on" and d.place[it.id] and d.place[it.id] <= #CAFE.CSLOT then
      local sl = CAFE.CSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1] + (CAFE.ADX[it.id] or 0), sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.tableTopRaw()                    -- whatever stands in the middle of a table (drawn live, after the tables)
  local d = CAFE.dec()
  if not d then return end
  local tops = G.tops
  if not tops then
    tops = {}
    for _, it in ipairs(CAFE.ITEMS) do
      local pl = d.place[it.id]
      if it.kind == "counter" and d.decor[it.id] == "on" and pl and pl > 10 and CAFE.topOn(d, pl) then
        tops[#tops + 1] = { CAFE.art[it.id], pl }
      end
    end
    G.tops = tops
  end
  for i = 1, #tops do
    local tx, ty = CAFE.topXY(tops[i][2])
    tops[i][1](tx, ty)
  end
  gfx.setColor(BLACK)
end

-- vines hanging off the cup shelf's ends: ten styles, each hung from the left or the right end
CAFE.VINEIDS = { "ivy", "bloomvine", "fernvine", "heartvine", "berryvine", "starvine", "moss", "beadvine", "wisteria", "lanternvine" }
CAFE.VINES = {                                  -- strand lengths (kept short so they stop above the counter)
  ivy        = { 13, 22, 17 },
  bloomvine  = { 19, 13, 22 },
  fernvine   = { 22, 16, 21 },
  heartvine  = { 16, 22, 12 },
  berryvine  = { 20, 14, 22 },
  starvine   = { 14, 22, 18 },
  moss       = { 20, 22, 16, 21 },
  beadvine   = { 18, 22, 14 },
  wisteria   = { 18, 22, 15 },
  lanternvine = { 16, 22, 19 },
}

function CAFE.vineSide(d, id)                  -- 1 = hangs from the left end of the shelf, 2 = the right end
  local s = d.place and d.place[id]
  if s == 1 or s == 2 then return s end
  return (id == "bloomvine") and 2 or 1        -- (saves from before you could choose)
end

function CAFE.vineX(id, side)                  -- x of the first strand
  local n = #CAFE.VINES[id]
  if side == 2 then return 188 - (n - 1) * 4 end
  return 100
end

-- one vine of the given style, first strand at x0, hanging from y0
CAFE.VINESTEM = { beadvine = "bark", lanternvine = "bark", moss = "olive", wisteria = "bark" }      -- (PC colours)
CAFE.VINEPOP = { "rose", "lav", "yellow", "skyp", "orangep" }
function CAFE.vineDraw(id, x0, y0, ph)
  local lens, style = CAFE.VINES[id], id
  if not lens then return end
  local stem = CAFE.VINESTEM[id] or "leafdk"
  for i, len in ipairs(lens) do
    local x = x0 + (i - 1) * 4
    local px, py = x, y0
    local dirn = (i % 2 == 0) and 1 or -1
    gfx.setLineWidth(1)
    for yy = y0 + 2, y0 + len, 3 do
      local xx = x + math.floor(math.sin(ph * 0.3927 + yy * 0.3 + i) * 1.5 + 0.5)
      UI.ink(stem)
      gfx.setColor(BLACK)
      gfx.drawLine(px, py, xx, yy)
      px, py = xx, yy
      local even = (math.floor((yy - y0) / (3))) % 2 == 0
      local nth = math.floor((yy - y0) / (3)) + i
      if style == "ivy" then
        UI.ink("leaf")
        if even then
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx + dirn * 2, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx + dirn * 2, yy, 2)
        end
      elseif style == "bloomvine" then
        if even then
          UI.ink("leaf")
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx + dirn * 2, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx + dirn * 2, yy, 2)
        else
          UI.ink(CAFE.VINEPOP[nth % 3 + 1])
          local fx = xx - dirn * 3
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(fx, yy, 3)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(fx, yy, 3); gfx.fillCircleAtPoint(fx, yy, 1)
          gfx.drawPixel(fx, yy - 4); gfx.drawPixel(fx, yy + 4); gfx.drawPixel(fx - 4, yy); gfx.drawPixel(fx + 4, yy)
        end
      elseif style == "fernvine" then          -- feathery fronds branching off both sides
        UI.ink("inkgreen")
        if even then
          gfx.drawLine(xx, yy, xx - 4, yy + 3); gfx.drawLine(xx, yy, xx + 4, yy + 3)
          gfx.drawLine(xx - 4, yy + 3, xx - 4, yy + 5); gfx.drawLine(xx + 4, yy + 3, xx + 4, yy + 5)
        end
      elseif style == "heartvine" then
        if even then
          UI.ink((nth % 2 == 0) and "redp" or "rose")
          local fx = xx + dirn * 3
          gfx.setColor(WHITE)
          gfx.fillCircleAtPoint(fx - 2, yy - 1, 2); gfx.fillCircleAtPoint(fx + 2, yy - 1, 2)
          gfx.fillPolygon(fx - 4, yy, fx + 4, yy, fx, yy + 5)
          gfx.setColor(BLACK)
          gfx.drawCircleAtPoint(fx - 2, yy - 1, 2); gfx.drawCircleAtPoint(fx + 2, yy - 1, 2)
          gfx.drawLine(fx - 4, yy, fx, yy + 5); gfx.drawLine(fx + 4, yy, fx, yy + 5)
        end
      elseif style == "berryvine" then
        if even then
          UI.ink((nth % 3 == 0) and "inkpurple" or "inkred")
          local fx = xx + dirn * 3
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(fx, yy, 3)
          gfx.setColor(BLACK); gfx.fillCircleAtPoint(fx, yy, 2)
          gfx.setColor(WHITE); gfx.drawPixel(fx - 1, yy - 1)
        else
          UI.ink("inkgreen")
          gfx.setColor(BLACK); gfx.drawLine(xx, yy, xx - dirn * 3, yy - 2)
        end
      elseif style == "starvine" then          -- little sparkles that twinkle
        UI.ink("yellow")
        if even then
          local fx = xx + dirn * 3
          local big = (math.floor(ph / (2)) + i * 3 + math.floor(yy / (3))) % 5 < 3
          local r = big and 3 or 2
          gfx.setColor(BLACK); gfx.setLineWidth(3)
          gfx.drawLine(fx - r, yy, fx + r, yy); gfx.drawLine(fx, yy - r, fx, yy + r)
          gfx.setColor(WHITE); gfx.setLineWidth(1)
          gfx.drawLine(fx - r, yy, fx + r, yy); gfx.drawLine(fx, yy - r, fx, yy + r)
        end
      elseif style == "moss" then              -- wispy strands, a little tuft at every step
        UI.ink(even and "leaf" or "sage")
        gfx.drawLine(xx, yy, xx + 2, yy + 2); gfx.drawLine(xx, yy, xx - 2, yy + 2)
        if even then gfx.drawLine(xx, yy, xx + dirn * 4, yy - 1) end
      elseif style == "beadvine" then
        UI.ink(CAFE.VINEPOP[nth % 5 + 1])
        if even then
          gfx.setColor(WHITE); gfx.fillCircleAtPoint(xx, yy, 2)
          gfx.setColor(BLACK); gfx.drawCircleAtPoint(xx, yy, 2)
        else
          gfx.setColor(BLACK); gfx.fillCircleAtPoint(xx, yy, 1)
        end
      elseif style == "wisteria" then          -- drooping clusters of blossoms
        UI.ink((nth % 2 == 0) and "lav" or "lilac")
        if even and yy > y0 + 3 then
          gfx.setPattern(CHECK)
          gfx.fillPolygon(xx - 3, yy - 2, xx + 3, yy - 2, xx, yy + 5)
          gfx.setColor(BLACK)
          gfx.drawLine(xx - 3, yy - 2, xx, yy + 5); gfx.drawLine(xx + 3, yy - 2, xx, yy + 5)
          gfx.drawLine(xx - 3, yy - 2, xx + 3, yy - 2)
        end
      elseif style == "lanternvine" then       -- tiny paper lanterns that flicker
        if (math.floor((yy - y0) / (3))) % 3 == 1 then
          UI.ink(({ "redp", "jack", "rose" })[i % 3 + 1])
          gfx.setColor(WHITE); gfx.fillRoundRect(xx - 2, yy - 1, 5, 7, 2)
          gfx.setColor(BLACK); gfx.drawRoundRect(xx - 2, yy - 1, 5, 7, 2)
          UI.ink("flame")
          if (math.floor(ph / (3)) + i) % 3 ~= 0 then gfx.fillRect(xx, yy + 1, 1, 3) else gfx.drawPixel(xx, yy + 2) end
        end
      end
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  gfx.setLineWidth(1)
end

function CAFE.drawVines()
  local d = CAFE.dec()
  if not d then return end
  local any = false
  for _, id in ipairs(CAFE.VINEIDS) do if d.decor[id] == "on" then any = true; break end end
  if not any then return end
  local ph = (math.floor(frames / (4))) % 16                -- sixteen sway poses, each drawn once into a picture
  local st = G.vineImgs
  if not st then st = {}; G.vineImgs = st end
  local im = st[ph]
  if im == nil then
    st[ph] = false
    im = CAFE.snap(function() CAFE.vinesRaw(ph) end, 40, 44, 90, 112)
    st[ph] = im
  end
  if im then im:draw(90, 40) else CAFE.vinesRaw(ph) end
end

function CAFE.vinesRaw(ph)
  local d = CAFE.dec()
  for _, id in ipairs(CAFE.VINEIDS) do
    if d.decor[id] == "on" then CAFE.vineDraw(id, CAFE.vineX(id, CAFE.vineSide(d, id)), 43, ph) end
  end
end

function CAFE.vineSidesFree(d, id)             -- the shelf ends nobody else is hanging from
  local free = {}
  for side = 1, 2 do
    local taken = false
    for _, o in ipairs(CAFE.VINEIDS) do
      if o ~= id and d.decor[o] == "on" and CAFE.vineSide(d, o) == side then taken = true end
    end
    if not taken then free[#free + 1] = side end
  end
  return free
end

function CAFE.fixVines(d)                      -- old/odd saves: every vine that's out has its own end of the shelf
  local used = {}
  for _, id in ipairs(CAFE.VINEIDS) do
    if d.decor[id] == "on" then
      local side = CAFE.vineSide(d, id)
      if used[side] then side = (side == 1) and 2 or 1 end
      if used[side] then d.decor[id] = "off"; d.place[id] = nil
      else used[side] = true; d.place[id] = side end
    end
  end
end

for _, id in ipairs(CAFE.VINEIDS) do           -- the picture used on the "where should it go" screen
  CAFE.art[id] = function(cx, cy) CAFE.vineDraw(id, cx - math.floor(4 * (#CAFE.VINES[id] - 1) / (2)), cy - 16, 0) end
end

CAFE.ANIM = { arclamp = true, torchiere = true, tripodlamp = true, globelamp = true, tiffany = true, streetlamp = true, paperlamp = true, plant = true, fern = true, tree = true, palm = true, cactus = true, flowers = true, snake = true,
              sunflower = true, bonsai = true, monstera = true, pumpkin = true, cattree = true, dogbed = true, floorlamp = true, jukebox = true }      -- floor pieces that sway / blink
function CAFE.drawFloorItems(live)             -- live = just the moving ones (the rest are in the floor picture)
  local d = CAFE.dec()
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] and ((CAFE.ANIM[it.id] == true) == (live == true)) then
      local sl = CAFE.FSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.shuffle(t)
  for i = #t, 2, -1 do local j = math.random(i); t[i], t[j] = t[j], t[i] end
  return t
end

-- Rush Hour and Evening Chill: a different little cafe every time (3 or more tables, some decor)
function CAFE.randomRoom(mode)
  local d = { decor = {}, place = {}, tables = {}, off = {}, sign = true, cups = 5, stars = 0, name = "" }
  local n = (mode == "chill") and 3 or (3 + math.random(0, 1))
  local pool = {}
  for i, f in ipairs(CAFE.TFREE) do pool[i] = f end
  CAFE.shuffle(pool)
  for k = 1, n do d.tables[k] = pool[k] end
  d.seatStep = n
  local function fill(kind, slots, lo, hi)
    local ids = {}
    for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind and not it.needs and not it.copyOf then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    for i = 1, math.min(math.random(lo, hi), #ids, #slots) do
      d.decor[ids[i]] = "on"; d.place[ids[i]] = slots[i]
    end
  end
  do                                            -- wall decor: clocks and pictures on any of the free tiles
    local ids, slots = {}, { 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 }
    for _, it in ipairs(CAFE.ITEMS) do if (it.kind == "wall" or it.kind == "tiny") and not it.needs then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    local put = 0
    for _, id in ipairs(ids) do
      if put >= math.random(3, 6) then break end
      for si, sl in ipairs(slots) do
        if sl ~= false and (id ~= "cuckoo" or sl <= #CAFE.WSLOT) then
          d.decor[id] = "on"; d.place[id] = sl; slots[si] = false; put = put + 1
          break
        end
      end
    end
  end
  do
    local cs = { 1, 2, 3, 4, 5 }
    for k = 1, 5 do if CAFE.tableOn(d, k) then cs[#cs + 1] = 10 + k end end
    fill("counter", cs, 2, 5)
  end
  fill("floor", { 1, 2, 3, 4, 5, 6, 7, 8 }, 2, 4)
  for _, kind in ipairs({ "rug", "runner", "orug", "cloth", "frame", "curtain" }) do
    if math.random() < 0.5 then
      local ids = {}
      for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind then ids[#ids + 1] = it.id end end
      d.decor[ids[math.random(#ids)]] = "on"
    end
  end
  local hasRug = false
  for _, it in ipairs(CAFE.ITEMS) do if it.kind == "rug" and d.decor[it.id] == "on" then hasRug = true end end
  if hasRug then for _, it in ipairs(CAFE.ITEMS) do if it.kind == "orug" then d.decor[it.id] = nil end end end
  for side = 1, 2 do                            -- a vine from each end of the shelf now and then (any style)
    if math.random() < 0.4 then
      local id
      repeat id = CAFE.VINEIDS[math.random(#CAFE.VINEIDS)] until d.decor[id] ~= "on"
      d.decor[id] = "on"
      d.place[id] = side
    end
  end
  if math.random() < 0.5 then d.decor[CAFE.LIGHTIDS[math.random(#CAFE.LIGHTIDS)]] = "on" end
  return d
end

function CAFE.decorOn(id)
  local d = CAFE.dec()
  return d ~= nil and d.decor[id] == "on"
end

function CAFE.dec() return G ~= nil and (G.cafe or G.deco) or nil end      -- the decor being shown (a cafe save, or a random room)

-- ---- string lights: six styles, one on the wall at a time -------------------------------------------------
CAFE.LIGHTIDS = { "lights", "fairylights", "globelights", "lanternlights", "heartlights", "starlights" }
CAFE.LSTY = { lights = { 2, 24, 20 }, fairylights = { 3, 12, 10 }, globelights = { 2, 30, 20 },     -- { blink phases, frames per phase, pixels between bulbs }
              lanternlights = { 2, 36, 20 }, heartlights = { 2, 22, 20 }, starlights = { 2, 18, 20 } }

function CAFE.lightLit(id, i, phase)             -- is bulb number i glowing in this phase?
  if id == "fairylights" then return (i + phase) % 3 == 0 end
  return (i + phase) % 2 == 0
end

function CAFE.lightPaint(lit, card)              -- the colour a bulb is filled with: white when glowing on the dark wall (black on the white shop card); dim ones are the opposite
  if UI.color then gfx.setColor(lit and WHITE or BLACK); return end     -- (in colour: lit bulbs are the bright shade of their colour, dim ones the dark shade)
  if lit then gfx.setColor(card and BLACK or WHITE)
  elseif card then gfx.setColor(WHITE)
  else gfx.setColor(BLACK) end
end
function CAFE.lightRim(lit, card)               -- the outline round a bulb: a dim one on the dark wall is edged in white so it never disappears
  gfx.setColor((not lit and not card) and WHITE or BLACK)
end

CAFE.STARP = {}
function CAFE.starAt(x, y, r, outline)           -- a five-pointed star (outer radius r), as a filled polygon (or just its edge)
  local u = CAFE.STARP[r]
  if not u then
    u = {}
    for k = 0, 9 do
      local a = -math.pi / 2 + k * math.pi / 5
      local rr = (k % 2 == 0) and r or r * 0.45
      u[#u + 1] = math.floor(math.cos(a) * rr + 0.5 + 100) - 100
      u[#u + 1] = math.floor(math.sin(a) * rr + 0.5 + 100) - 100
    end
    CAFE.STARP[r] = u
  end
  if outline then
    for k = 1, 20, 2 do
      local n = (k + 2 > 20) and 1 or (k + 2)
      gfx.drawLine(x + u[k], y + u[k + 1], x + u[n], y + u[n + 1])
    end
    return
  end
  local pts = {}
  for k = 1, 20, 2 do pts[k] = x + u[k]; pts[k + 1] = y + u[k + 1] end
  gfx.fillPolygon(table.unpack(pts))
end

-- the colours the bulbs take in turn along the string (PC version)
CAFE.BULBCOL = { lights = { "redp", "yellow", "skyp", "leaf", "orangep", "rose" }, fairylights = { "gold2", "glow", "gold2", "snow" },
                 globelights = { "gold2", "glow" }, lanternlights = { "redp", "jack", "rose", "skyp", "lav", "leaf" },
                 heartlights = { "rose", "redp", "lav" }, starlights = { "yellow", "snow", "gold2" } }
-- one bulb hanging from the wire at (x, wy). k = how big (1 on the wall, bigger on the shop card); card = drawn black-on-white
function CAFE.lightBulb(id, x, wy, lit, k, card)
  local function K(v) return math.floor(v * k + 0.5) end
  local ink = card and BLACK or WHITE
  local cols = CAFE.BULBCOL[id] or CAFE.BULBCOL.lights
  UI.ink(cols[math.floor(x / (math.floor(CAFE.LSTY[id or "lights"][3] * k + 0.5))) % #cols + 1])
  if UI.color then ink = WHITE end
  if id == "fairylights" then                      -- tiny pinpricks that twinkle in turn
    local y = wy + K(2)
    gfx.setColor(card and BLACK or WHITE)
    if lit then
      local a = K(2)
      if card then
        gfx.fillCircleAtPoint(x, y, K(1)); gfx.drawLine(x - a - 1, y, x + a + 1, y); gfx.drawLine(x, y - a - 1, x, y + a + 1)
      else
        gfx.drawPixel(x, y); gfx.drawPixel(x - 1, y); gfx.drawPixel(x + 1, y); gfx.drawPixel(x, y - 1); gfx.drawPixel(x, y + 1)
        gfx.drawPixel(x - 2, y); gfx.drawPixel(x + 2, y); gfx.drawPixel(x, y - 2); gfx.drawPixel(x, y + 2)
      end
    else
      if card then gfx.fillCircleAtPoint(x, y, K(1)) else gfx.drawPixel(x, y) end
    end
  elseif id == "globelights" then                  -- big round bulbs screwed into little sockets: lit ones glow, dim ones show their filament
    local cy, r = wy + K(7), K(4)
    UI.inkPush("gray")
    gfx.setColor(ink); gfx.fillRect(x - K(1), wy + K(1), K(2) + 1, K(2))
    gfx.setColor(BLACK); gfx.drawRect(x - K(1), wy + K(1), K(2) + 1, K(2))
    UI.inkPop()
    CAFE.lightRim(lit, card); gfx.fillCircleAtPoint(x, cy, r + 1)
    CAFE.lightPaint(lit, card); gfx.fillCircleAtPoint(x, cy, r)
    if lit then                                    -- a glass shine and a halo
      gfx.setColor(card and WHITE or BLACK)
      gfx.drawLine(x - r + 2, cy - 1, x - r + 3, cy - 2)
      gfx.setColor(ink)
      gfx.drawPixel(x - r - 3, cy); gfx.drawPixel(x + r + 3, cy); gfx.drawPixel(x, cy - r - 3)
      if k >= 1.5 then gfx.drawPixel(x - r - 2, cy - r - 1); gfx.drawPixel(x + r + 2, cy - r - 1) end
    else                                           -- the cold filament: a little loop on two posts
      gfx.setColor(card and BLACK or WHITE)
      local h = K(2)
      gfx.drawLine(x - 1, cy + h, x - 1, cy - 1); gfx.drawLine(x + 1, cy + h, x + 1, cy - 1); gfx.drawLine(x - 1, cy - 1, x + 1, cy - 1)
    end
  elseif id == "lanternlights" then                -- little paper lanterns with ribs and a tassel
    local w, h, y0 = K(8), K(8), wy + K(2)
    gfx.setColor(ink); gfx.drawLine(x, wy, x, y0)
    CAFE.lightRim(lit, card); gfx.fillRoundRect(x - math.floor(w / (2)) - 1, y0 - 1, w + 2, h + 2, K(3))
    CAFE.lightPaint(lit, card)
    gfx.fillRoundRect(x - math.floor(w / (2)), y0, w, h, K(3))
    gfx.setColor((lit or card) and BLACK or WHITE)
    gfx.drawLine(x - math.floor(w / (2)) + 1, y0 + math.floor(h / (3)), x + math.floor(w / (2)) - 1, y0 + math.floor(h / (3)))         -- the ribs
    gfx.drawLine(x - math.floor(w / (2)) + 1, y0 + math.floor(2 * h / (3)), x + math.floor(w / (2)) - 1, y0 + math.floor(2 * h / (3)))
    gfx.setColor(ink); gfx.drawLine(x, y0 + h, x, y0 + h + K(2))                   -- the tassel
  elseif id == "heartlights" then                  -- hearts
    local cy = wy + K(5)
    CAFE.lightRim(lit, card)                       -- (the outline: the same heart a bit bigger)
    gfx.fillCircleAtPoint(x - K(2), cy - K(1), K(2) + 1); gfx.fillCircleAtPoint(x + K(2), cy - K(1), K(2) + 1)
    gfx.fillTriangle(x - K(4) - 1, cy, x + K(4) + 1, cy, x, cy + K(5) + 1)
    CAFE.lightPaint(lit, card)
    gfx.fillCircleAtPoint(x - K(2), cy - K(1), K(2)); gfx.fillCircleAtPoint(x + K(2), cy - K(1), K(2))
    gfx.fillTriangle(x - K(4), cy, x + K(4), cy, x, cy + K(5))
  elseif id == "starlights" then                   -- stars: bright ones and little dim ones
    local r = K(5)
    local cy = wy + K(6)
    if lit then
      CAFE.lightRim(lit, card); CAFE.starAt(x, cy, r + 1)
      CAFE.lightPaint(lit, card); CAFE.starAt(x, cy, r)
    elseif card then                               -- a dim star on the shop card: a white star with a plain thick black edge (a hollow star)
      gfx.setColor(WHITE); CAFE.starAt(x, cy, r + 1)
      gfx.setColor(BLACK); gfx.setLineWidth(2); CAFE.starAt(x, cy, r, true); gfx.setLineWidth(1)
    else                                           -- a dim star on the dark wall: just its white outline (never invisible)
      gfx.setColor(BLACK); CAFE.starAt(x, cy, r + 1)
      gfx.setColor(WHITE); CAFE.starAt(x, cy, r)
      gfx.setColor(BLACK); CAFE.starAt(x, cy, r - 2)             -- (a white star with a smaller dark star cut out of it: a clean hollow star)
    end
    if lit then                                    -- a glint
      gfx.setColor(card and BLACK or WHITE)
      gfx.drawLine(x, cy - r - 2, x, cy - r - 1 - K(1)); gfx.drawLine(x - r - 2, cy, x - r - 1 - K(1), cy); gfx.drawLine(x + r + 2, cy, x + r + 1 + K(1), cy)
    end
  else                                             -- plain round bulbs
    local r = K(lit and 3 or 2)
    if lit then gfx.setColor(card and BLACK or WHITE) else gfx.setColor(WHITE) end
    gfx.fillCircleAtPoint(x, wy + K(3), r)
    gfx.setColor(BLACK); gfx.drawCircleAtPoint(x, wy + K(3), r)
  end
  gfx.setColor(BLACK)
end

-- the string is drawn once into a picture (one for each blink phase) and just stamped on
function CAFE.lightsRaw(id, phase)
  local gap = CAFE.LSTY[id][3]
  local prev
  UI.ink("leafdk")
  gfx.setColor(WHITE)
  for x = 0, 400, 4 do
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    if prev then gfx.drawLine(prev[1], prev[2], x, y) end
    prev = { x, y }
  end
  for i = 0, math.floor(400 / (gap)) do
    local x = i * gap + math.floor(gap / (2))
    local wy = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    CAFE.lightBulb(id, x, wy, CAFE.lightLit(id, i, phase), 1, false)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.lightsId()                         -- which string is up (if any)
  for i = 1, #CAFE.LIGHTIDS do
    if CAFE.decorOn(CAFE.LIGHTIDS[i]) then return CAFE.LIGHTIDS[i] end
  end
  return nil
end

function CAFE.drawLights()
  local id = CAFE.lightsId()
  if not id then return end
  local st = CAFE.LSTY[id]
  local phase = (math.floor(frames / (st[2]))) % st[1]
  CAFE.limg = CAFE.limg or {}
  local key = id .. phase
  if CAFE.limg[key] == nil then
    local ok, img = pcall(function() return gfx.image.new(400, 28, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      gfx.setDrawOffset(0, -14)
      CAFE.lightsRaw(id, phase)
      gfx.setDrawOffset(0, 0)
      gfx.popContext()
      CAFE.limg[key] = img
    else
      CAFE.limg[key] = false
    end
  end
  local im = CAFE.limg[key]
  if im then im:draw(0, 14) else CAFE.lightsRaw(id, phase) end
  gfx.setColor(BLACK)
end

-- a long runner rolled out in front of the register, down the line (drawn at any size, so the
-- shop preview can shrink it to fit its box)
CAFE.RUGCOL = { rug = "rrose", rug2 = "skyp", rug3 = "rred", rug4 = "rlav", rug5 = "rpeach", rug6 = "rsage", rug7 = "rsand",
                run1 = "rcarpet", run2 = "rteal", run3 = "gingham", run4 = "rpeach", run5 = "rsand", run6 = "rrose", run7 = "rapricot", run8 = "rsage",
                orug1 = "rsage", orug2 = "skyp", orug3 = "rlav", orug4 = "rteal", orug5 = "rsun", orug6 = "rsand" }     -- (PC colours: soft, so the big pieces never shout)
function CAFE.runnerAt(which, x, y, w, h)
  local big = w >= 30
  local r = big and 5 or 2
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 4 or 2                      -- border width
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  local cx = x + math.floor(w / (2))
  if which == "run1" then                       -- red carpet: a dark pile, a gold trim and a row of royal diamonds
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(WHITE)
    if big then gfx.drawRoundRect(x + 7, y + 7, w - 14, h - 14, 2) end
    local st = math.max(10, math.floor(h * 16 / (118)))
    local hw, hh = math.max(2, math.floor(w * 7 / (36))), math.max(3, math.floor(st * 5 / (8)))
    for yy = y + st, y + h - math.floor(st / (2)), st do
      gfx.drawLine(cx, yy - hh, cx + hw, yy); gfx.drawLine(cx + hw, yy, cx, yy + hh)
      gfx.drawLine(cx, yy + hh, cx - hw, yy); gfx.drawLine(cx - hw, yy, cx, yy - hh)
      if big then gfx.fillRect(cx - 1, yy - 1, 3, 3) else gfx.drawPixel(cx, yy) end
    end
    if big then                                 -- tassel dots along the two trims
      for yy = y + 10, y + h - 10, 6 do gfx.drawPixel(x + 10, yy); gfx.drawPixel(x + w - 11, yy) end
    end
  elseif which == "run2" then                   -- stripes
    local step = math.max(3, math.floor(h / (15)))
    for yy = iy, iy + ih - 2, step do gfx.fillRect(ix, yy, iw, math.max(1, math.floor(step / (2)))) end
  elseif which == "run3" then                   -- checker
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(ix, iy, iw, ih, big and 3 or 1)
  elseif which == "run4" then                   -- diamonds
    local step = math.max(6, math.floor(h * 14 / (118)))
    local hw, hh = math.max(3, math.floor(w * 8 / (36))), math.max(3, math.floor(step * 6 / (14)))
    for yy = y + step, y + h - step + 1, step do
      gfx.drawLine(cx, yy - hh, cx + hw, yy)
      gfx.drawLine(cx + hw, yy, cx, yy + hh)
      gfx.drawLine(cx, yy + hh, cx - hw, yy)
      gfx.drawLine(cx - hw, yy, cx, yy - hh)
      gfx.fillCircleAtPoint(cx, yy, big and 2 or 1)
    end
  elseif which == "run6" then                   -- polka dots
    local st = math.max(5, math.floor(h / (12)))
    for yy = y + st, y + h - math.floor(st / (2)), st do
      local off = ((math.floor(yy / (st))) % 2 == 0) and math.floor(-w / (6)) or math.floor(w / (6))
      gfx.fillCircleAtPoint(cx + off, yy, big and 3 or 1)
    end
  elseif which == "run7" then                   -- zigzag
    local st = math.max(6, math.floor(h / (10)))
    local hw = math.max(3, math.floor(w / (3)))
    local px, py = cx - hw, y + m + 1
    for yy = y + m + 1 + st, y + h - m, st do
      local nx = (px < cx) and (cx + hw) or (cx - hw)
      gfx.drawLine(px, py, nx, yy)
      if big then gfx.drawLine(px, py + 1, nx, yy + 1) end
      px, py = nx, yy
    end
  elseif which == "run8" then                   -- plaid
    local st = math.max(6, math.floor(h / (9)))
    gfx.setPattern(CHECK)
    for yy = iy + 1, iy + ih - 3, st do gfx.fillRect(ix, yy, iw, big and 5 or 2) end
    gfx.setColor(BLACK)
    gfx.drawLine(cx, iy, cx, iy + ih)
    if big then gfx.drawLine(cx - 8, iy, cx - 8, iy + ih); gfx.drawLine(cx + 8, iy, cx + 8, iy + ih) end
  else                                          -- coffee beans
    UI.ink("choc")
    local n = big and 7 or 5
    for i = 0, n - 1 do
      local bx = cx + ((i % 2 == 0) and math.floor(-w / (5)) or math.floor(w / (5)))
      local by = y + math.floor((h * (i + 0.5)) / (n))
      if big then drawBean(bx, by, 1) else gfx.fillCircleAtPoint(bx, by, 2) end
    end
  end
  UI.ink("tan")
  gfx.setColor(BLACK)
  if big then for xx = x + 3, x + w - 3, 5 do gfx.drawLine(xx, y + h, xx, y + h + 3) end end   -- fringe at the door end
end

function CAFE.drawRunner()
  for _, id in ipairs({ "run1", "run2", "run3", "run4", "run5", "run6", "run7", "run8" }) do
    if CAFE.decorOn(id) then CAFE.runnerAt(id, 38, 116, 36, 118) end
  end
end

-- an oval rug that sits under the six table spots (it fits whole inside them: x 105-267, y 151-227)
function CAFE.ovalAt(which, x, y, w, h)
  local big = w >= 100
  local lw = big and 2 or 1
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(lw)
  gfx.drawEllipseInRect(x, y, w, h)
  local m = big and 7 or 3
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  gfx.drawEllipseInRect(ix, iy, iw, ih)
  gfx.setLineWidth(1)
  local m2 = big and 3 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  local cx, cy = x + w / 2, y + h / 2
  local function inside(px, py, pad)             -- is the point well inside the pattern area?
    local dx, dy = (px - cx) / (fw / 2 - pad), (py - cy) / (fh / 2 - pad)
    return dx * dx + dy * dy <= 1
  end
  if which == "orug1" then
    gfx.setPattern(TEA)
    gfx.fillEllipseInRect(fx, fy, fw, fh)
  elseif which == "orug2" then                   -- ripples
    gfx.setLineWidth(lw)
    local st = big and 8 or 4
    for k = 1, 6 do
      local sx, sy = k * st, k * st * fh / fw
      if sy * 2 >= fh - 2 or sx * 2 >= fw - 2 then break end
      gfx.drawEllipseInRect(fx + sx, fy + sy, fw - 2 * sx, fh - 2 * sy)
    end
    gfx.setLineWidth(1)
  elseif which == "orug3" then
    gfx.setPattern(CHECK)
    gfx.fillEllipseInRect(fx, fy, fw, fh)
    gfx.setColor(BLACK)
    local k = big and 8 or 3
    gfx.drawEllipseInRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k)
  elseif which == "orug4" then                   -- polka dots
    local st = big and 12 or 6
    local row = 0
    for yy = fy + math.floor(st / (2)) + 1, fy + fh - 2, st do
      for xx = fx + math.floor(st / (2)) + (row % 2) * (math.floor(st / (2))) + 1, fx + fw - 2, st do
        if inside(xx, yy, big and 4 or 2) then gfx.fillCircleAtPoint(xx, yy, big and 3 or 1) end
      end
      row = row + 1
    end
  elseif which == "orug5" then                   -- sunburst
    local n = 16
    for i = 0, n - 1 do
      local a = i * math.pi * 2 / n
      gfx.drawLine(math.floor(cx + 0.5), math.floor(cy + 0.5), math.floor(cx + math.cos(a) * (fw / 2 - 1) + 0.5), math.floor(cy + math.sin(a) * (fh / 2 - 1) + 0.5))
    end
    UI.ink("rpeach")
    gfx.setColor(WHITE)
    gfx.fillEllipseInRect(math.floor(cx - fw * 0.12), math.floor(cy - fh * 0.12), math.max(3, math.floor(fw * 0.24)), math.max(3, math.floor(fh * 0.24)))
    gfx.setColor(BLACK)
    gfx.drawEllipseInRect(math.floor(cx - fw * 0.12), math.floor(cy - fh * 0.12), math.max(3, math.floor(fw * 0.24)), math.max(3, math.floor(fh * 0.24)))
  else                                           -- coffee beans, laid out in a mirror-matched pattern round the middle
    UI.ink("choc")
    local sx, sy = big and 14 or 6, big and 10 or 5                   -- spacing across / down
    local mx, my = math.floor(cx), math.floor(cy)
    local rows = math.floor((fh / 2) / sy)
    for k = -rows, rows do
      local yy = my + k * sy
      local half = (k % 2 ~= 0) and math.floor(sx / 2) or 0          -- every other row sits half a step over, the same on both sides
      for j = 0, math.floor(fw / sx) do
        for side = -1, 1, 2 do
          local off = half + j * sx
          if not (side == 1 and off == 0) then                         -- (the bean right in the middle only once)
            local xx = mx + side * off
            if inside(xx, yy, big and 6 or 2) then
              if big then
                gfx.setColor(BLACK); gfx.fillEllipseInRect(xx - 4, yy - 2, 9, 5)          -- a bean, its crease turned to mirror the other side
                gfx.setColor(WHITE)
                if side < 0 or off == 0 then gfx.drawLine(xx - 2, yy + 1, xx + 2, yy - 1) else gfx.drawLine(xx - 2, yy - 1, xx + 2, yy + 1) end
                gfx.setColor(BLACK)
              else gfx.fillCircleAtPoint(xx, yy, 1) end
            end
          end
        end
      end
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawOval()
  for _, id in ipairs({ "orug1", "orug2", "orug3", "orug4", "orug5", "orug6" }) do
    if CAFE.decorOn(id) then CAFE.ovalAt(id, 105, 151, 162, 76) end
  end
end

-- the big centre rug
function CAFE.rugAt(which, x, y, w, h)
  local big = w >= 100
  local r = big and 8 or 3
  UI.ink(CAFE.RUGCOL[which])
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 6 or 2
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  if big then gfx.drawRoundRect(ix, iy, iw, ih, 5) end
  local m2 = big and 2 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  if which == "rug" then
    UI.ink("tan")
    gfx.setPattern(TEA)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
  elseif which == "rug2" then
    gfx.setColor(BLACK)
    local step = big and 6 or 3
    for yy = fy + 1, fy + fh - 2, step do gfx.fillRect(fx, yy, fw, big and 3 or 1) end
  elseif which == "rug4" then                   -- polka dots
    gfx.setColor(BLACK)
    local st = big and 11 or 5
    local row = 0
    for yy = fy + math.floor(st / (2)) + 1, fy + fh - 2, st do
      for xx = fx + math.floor(st / (2)) + (row % 2) * (math.floor(st / (2))) + 1, fx + fw - (big and 6 or 3), st do gfx.fillCircleAtPoint(xx, yy, big and 3 or 1) end
      row = row + 1
    end
  elseif which == "rug5" then                   -- a lattice of diamonds
    gfx.setColor(BLACK)
    gfx.setClipRect(fx, fy, fw, fh)
    local st = big and 14 or 6
    for xx = fx - fh, fx + fw, st do
      gfx.drawLine(xx, fy, xx + fh, fy + fh)
      gfx.drawLine(xx + fh, fy, xx, fy + fh)
    end
    gfx.clearClipRect()
  elseif which == "rug6" then                   -- plaid
    local st = big and 18 or 8
    local bw = big and 6 or 3
    gfx.setPattern(CHECK)
    for xx = fx + 2, fx + fw - bw, st do gfx.fillRect(xx, fy, bw, fh) end
    for yy = fy + 2, fy + fh - bw, st do gfx.fillRect(fx, yy, fw, bw) end
    gfx.setColor(BLACK)
    UI.ink("slate")
    for xx = fx + 2 + math.floor(bw / (2)), fx + fw - 1, st do gfx.drawLine(xx, fy, xx, fy + fh) end
    for yy = fy + 2 + math.floor(bw / (2)), fy + fh - 1, st do gfx.drawLine(fx, yy, fx + fw, yy) end
  elseif which == "rug7" then                   -- scattered coffee beans
    UI.ink("choc")
    gfx.setColor(BLACK)
    local st = big and 14 or 8
    local row = 0
    for yy = fy + math.floor(st / (2)), fy + fh - 2, st do
      for xx = fx + math.floor(st / (2)) + (row % 2) * (math.floor(st / (2))), fx + fw - (big and 8 or 3), st do
        if big then drawBean(xx, yy, 1) else gfx.fillCircleAtPoint(xx, yy, 1) end
      end
      row = row + 1
    end
  else
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
    gfx.setColor(BLACK)
    local k = big and 6 or 2
    gfx.drawRoundRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k, big and 3 or 1)
  end
  UI.ink("tan")
  gfx.setColor(BLACK)
  if big then
    for xx = x + 6, x + w - 8, 12 do            -- fringe
      gfx.drawLine(xx, y, xx, y - 3)
      gfx.drawLine(xx, y + h, xx, y + h + 3)
    end
  end
end

-- ---- table dressing: cloths and centrepieces ----------------------------------------------------------
function CAFE.ownedOf(kind)
  local own = G and (G.cafe or G.deco) and G.own
  if G and (G.cafe or G.deco) and not own then own = {}; G.own = own end
  if own then
    local v = own[kind]
    if v ~= nil then return v or nil end
  end
  local r
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == kind and CAFE.decorOn(it.id) then r = it.id; break end
  end
  if own then own[kind] = r or false end
  return r
end

CAFE.CLOTHCOL = { cloth1 = "inkred", cloth2 = "skyp", cloth3 = "white", cloth4 = "rose", cloth5 = "forest", cloth6 = "lav", cloth7 = "tan",
                  cloth8 = "inkred", cloth9 = "teal", cloth10 = "navyy", cloth11 = "orangep" }      -- (PC colours)
function CAFE.clothAt(id, x, y, r)               -- only the rim of the cloth shows round the table, so each pattern runs round the rim
  local R = r + math.max(2, math.floor(r / (3)))
  local mid = (r + R) / 2
  local function around(n, fn, off)               -- call fn(px, py, angle) at n evenly spaced points on the rim
    for i = 0, n - 1 do
      local a = math.rad((off or 0) + i * 360 / n)
      fn(x + math.floor(mid * math.cos(a) + 0.5), y + math.floor(mid * math.sin(a) + 0.5), a)
    end
  end
  UI.ink(CAFE.CLOTHCOL[id] or "white")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, R)
  gfx.setColor(BLACK)
  if id == "cloth1" then                         -- checker
    gfx.setPattern(CHECK)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
  elseif id == "cloth2" then                     -- stripes
    for dy = -R + 1, R - 1, 3 do
      local hw = math.floor(math.sqrt(R * R - dy * dy))
      gfx.fillRect(x - hw, y + dy, 2 * hw, 2)
    end
  elseif id == "cloth4" then                     -- polka dots
    around(16, function(px, py) gfx.fillCircleAtPoint(px, py, math.max(1, math.floor((R - r) / (3)))) end)
  elseif id == "cloth5" then                     -- plaid: a woven tone with a cross-hatch of lines
    gfx.setPattern(DIAG)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
    around(12, function(px, py, a)
      gfx.drawLine(x + math.floor(r * math.cos(a) + 0.5), y + math.floor(r * math.sin(a) + 0.5),
                   x + math.floor(R * math.cos(a) + 0.5), y + math.floor(R * math.sin(a) + 0.5))
    end, 7)
  elseif id == "cloth6" then                     -- diamonds
    local q = math.max(2, math.floor((R - r) / (2)))
    around(12, function(px, py)
      gfx.drawLine(px, py - q, px + q, py); gfx.drawLine(px + q, py, px, py + q)
      gfx.drawLine(px, py + q, px - q, py); gfx.drawLine(px - q, py, px, py - q)
      gfx.drawPixel(px, py)
    end)
  elseif id == "cloth7" then                     -- coffee beans
    local q = math.max(2, math.floor((R - r) / (2)))
    around(12, function(px, py)
      gfx.fillEllipseInRect(px - q, py - q + 1, q * 2, q * 2 - 1)
      gfx.setColor(WHITE); gfx.drawLine(px - q + 1, py, px + q - 1, py + 1); gfx.setColor(BLACK)
    end, 15)
  elseif id == "cloth8" then                     -- little hearts
    local q = math.max(1, math.floor((R - r) / (3)))
    around(9, function(px, py)
      gfx.fillCircleAtPoint(px - q, py - q, q); gfx.fillCircleAtPoint(px + q, py - q, q)
      gfx.fillTriangle(px - 2 * q, py - q, px + 2 * q, py - q, px, py + 2 * q)
    end, 20)
  elseif id == "cloth9" then                     -- a bold border with a thin line inside it
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 2)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(x, y, r + 2)
  elseif id == "cloth10" then                    -- night sky
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(WHITE)
    around(14, function(px, py, a)
      gfx.drawPixel(px, py)
      if math.floor(a * 10) % 3 == 0 then
        gfx.drawPixel(px - 1, py); gfx.drawPixel(px + 1, py); gfx.drawPixel(px, py - 1); gfx.drawPixel(px, py + 1)
      end
    end, 9)
    gfx.setColor(BLACK)
  elseif id == "cloth11" then                    -- a zigzag edge
    for i = 0, 15 do
      local a0, a1 = math.rad(i * 22.5), math.rad(i * 22.5 + 22.5)
      local am = (a0 + a1) / 2
      gfx.fillTriangle(x + math.floor((r + 1) * math.cos(a0) + 0.5), y + math.floor((r + 1) * math.sin(a0) + 0.5),
                       x + math.floor((r + 1) * math.cos(a1) + 0.5), y + math.floor((r + 1) * math.sin(a1) + 0.5),
                       x + math.floor(R * math.cos(am) + 0.5), y + math.floor(R * math.sin(am) + 0.5))
    end
  else                                           -- lace: scalloped edge and a dotted ring
    for a = 0, 330, 30 do
      local rad = math.rad(a)
      local sx, sy = x + math.floor(R * math.cos(rad) + 0.5), y + math.floor(R * math.sin(rad) + 0.5)
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx, sy, math.max(2, math.floor(r / (6))))
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(sx, sy, math.max(2, math.floor(r / (6))))
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 1)
    gfx.setColor(BLACK)
    for a = 0, 345, 15 do
      local rad = math.rad(a)
      gfx.drawPixel(x + math.floor((r + 1) * math.cos(rad) + 0.5), y + math.floor((r + 1) * math.sin(rad) + 0.5))
    end
  end
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, R)
end

function CAFE.tableAt(x, y, r, cloth)
  if cloth then CAFE.clothAt(cloth, x, y, r) end
  UI.ink("tan")
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.setLineWidth(1)
  UI.ink("none")
end

function CAFE.drawRug()
  for _, id in ipairs({ "rug", "rug2", "rug3", "rug4", "rug5", "rug6", "rug7" }) do
    if CAFE.decorOn(id) then CAFE.rugAt(id, 112, 128, 190, 44) end
  end
end

-- ---- the window: frames and curtains -------------------------------------------------------------------
CAFE.FRAMES = { "wf1", "wf2", "wf3", "wf4", "wf5", "wf6" }
CAFE.CURTAINS = { "wc1", "wc2", "wc3", "wc4", "wc5", "wc6", "wc7", "wc8", "wc9", "wc10" }

CAFE.CURTCOL = { wc1 = "redp", wc2 = "gingham", wc3 = "mint", wc4 = "yellow", wc5 = "white", wc6 = "rose", wc7 = "tan", wc8 = "woodl",
                 wc9 = "blush", wc10 = "navyy" }                                                    -- (PC colours)
CAFE.FRAMECOL = { wf1 = "woodl", wf2 = "white", wf3 = "brass", wf4 = "woodl", wf5 = "bark", wf6 = "forest" }
function CAFE.drape(x0, y0, wd, h, dir, style, sway)   -- one side curtain, tied back in the middle; dir = 1 hangs from the left edge
  local function X(dx) return dir == 1 and (x0 + dx) or (x0 - dx) end
  local pinch = 3 + sway
  local pts = { X(0), y0, X(wd), y0, X(wd - pinch), y0 + 13, X(wd + 1), y0 + h, X(0), y0 + h }
  UI.ink(CAFE.CURTCOL[style] or "redp")
  gfx.setColor(WHITE)
  gfx.fillPolygon(table.unpack(pts))
  gfx.setColor(BLACK)
  if style == "wc2" then                                  -- checker
    gfx.setPattern(CHECK); gfx.fillPolygon(table.unpack(pts)); gfx.setColor(BLACK)
  elseif style == "wc3" then                              -- stripes
    for dx = 1, wd - 1, 4 do gfx.drawLine(X(dx), y0, X(dx), y0 + h) end
  elseif style == "wc10" then                             -- night sky with stars
    gfx.fillPolygon(table.unpack(pts))
    gfx.setColor(WHITE)
    for _, p in ipairs({ { 2, 4 }, { 6, 9 }, { 3, 15 }, { 7, 20 }, { 4, 23 } }) do
      if p[1] < wd - 1 then gfx.drawPixel(X(p[1]), y0 + p[2]); gfx.drawPixel(X(p[1]) + 1, y0 + p[2]) end
    end
    gfx.setColor(BLACK)
  elseif style == "wc6" then                              -- polka dots
    for _, p in ipairs({ { 3, 4 }, { 7, 9 }, { 3, 14 }, { 7, 19 }, { 3, 23 } }) do
      if p[1] < wd - 1 then gfx.fillCircleAtPoint(X(p[1]), y0 + p[2], 1) end
    end
  elseif style == "wc7" then                              -- coffee beans
    UI.ink("choc")
    for _, p in ipairs({ { 3, 5 }, { 7, 11 }, { 3, 17 }, { 7, 22 } }) do
      if p[1] < wd - 1 then gfx.fillEllipseInRect(X(p[1]) - 2, y0 + p[2] - 1, 4, 3) end
    end
  elseif style == "wc9" then                              -- little hearts
    UI.ink("inkred")
    for _, p in ipairs({ { 3, 5 }, { 7, 12 }, { 3, 19 } }) do
      if p[1] < wd - 1 then
        local hx, hy = X(p[1]), y0 + p[2]
        gfx.drawPixel(hx - 1, hy); gfx.drawPixel(hx + 1, hy)
        gfx.drawLine(hx - 1, hy + 1, hx + 1, hy + 1); gfx.drawPixel(hx, hy + 2)
      end
    end
  else                                                    -- plain: soft folds
    gfx.drawLine(X(3), y0, X(3), y0 + 12); gfx.drawLine(X(6), y0 + 14, X(6), y0 + h)
  end
  UI.ink(CAFE.CURTCOL[style] or "redp")
  if style == "wc9" then UI.ink("rose") end
  gfx.setColor(BLACK)
  gfx.drawLine(pts[1], pts[2], pts[3], pts[4]); gfx.drawLine(pts[3], pts[4], pts[5], pts[6])
  gfx.drawLine(pts[5], pts[6], pts[7], pts[8])
  UI.ink("brass")
  gfx.fillRect(math.min(X(wd - pinch) - 1, X(wd - pinch) + 1), y0 + 12, 3, 3)        -- the tie-back
end

function CAFE.windowBase(x, y, frame, preview)
  local w, h = 54, 26
  UI.ink("sky")
  gfx.setColor(WHITE)
  if frame == "wf5" then gfx.fillRoundRect(x, y, w, h, 12) else gfx.fillRect(x, y, w, h) end   -- (arched corners show the wall, not white)
  if preview then                                         -- (a little sky for the shop picture)
    UI.ink("skyp")
    gfx.setColor(BLACK)
    gfx.drawLine(x + 6, y + 18, x + 20, y + 16); gfx.drawLine(x + 30, y + 8, x + 44, y + 9)
    UI.ink("yellow")
    WIN.sunAt(x + 40, y + 14, 3, 0.3)
  else
    WIN.drawView(G.win, x + 1, y + 1, 1)
  end
end

function CAFE.windowTop(x, y, frame, curtain, preview, swayIn)
  local w, h = 54, 26
  UI.ink(CAFE.FRAMECOL[frame or "wf1"] or "woodl")
  if frame == "wf2" then UI.ink("gray") end
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  if frame == "wf5" then gfx.drawRoundRect(x, y, w, h, 12) else gfx.drawRect(x, y, w, h) end
  gfx.setLineWidth(1)
  if frame == nil or frame == "wf4" or frame == "wf5" then   -- the usual four panes
    gfx.drawLine(x + 27, y, x + 27, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf2" then                              -- six panes
    gfx.drawLine(x + 18, y, x + 18, y + h); gfx.drawLine(x + 36, y, x + 36, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf3" then                              -- diamond panes
    gfx.setClipRect(x + 1, y + 1, w - 2, h - 2)
    for xx = x - h, x + w, 11 do
      gfx.drawLine(xx, y, xx + h, y + h); gfx.drawLine(xx + h, y, xx, y + h)
    end
    gfx.clearClipRect()
  elseif frame == "wf6" then                              -- shutters folded open at both sides
    for _, sx in ipairs({ x + 1, x + w - 10 }) do
      gfx.setColor(WHITE); gfx.fillRect(sx, y + 1, 9, h - 2)
      gfx.setColor(BLACK); gfx.drawRect(sx, y + 1, 9, h - 2)
      for yy = y + 4, y + h - 4, 3 do gfx.drawLine(sx + 1, yy, sx + 7, yy) end
    end
  end
  if frame == "wf4" then                                  -- a sill with two little brackets
    gfx.fillRect(x - 3, y + h, w + 6, 3)
    gfx.fillRect(x + 5, y + h + 3, 5, 2); gfx.fillRect(x + w - 10, y + h + 3, 5, 2)
  end
  if curtain then
    UI.ink(CAFE.CURTCOL[curtain] or "redp")
    local sway = swayIn or 0
    if swayIn == nil and not preview and G and G.win and G.win.fx and G.win.fx.wind then sway = (math.floor(frames / (14))) % 2 end   -- they stir in the wind
    if curtain == "wc4" then                              -- a scalloped valance across the top
      gfx.setColor(WHITE); gfx.fillRect(x, y, w, 6)
      gfx.setColor(BLACK)
      for cx = x + 4, x + w - 3, 8 do
        gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, y + 5, 4)
        gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, y + 5, 4)
      end
      gfx.setColor(WHITE); gfx.fillRect(x + 1, y - 1, w - 2, 5); gfx.setColor(BLACK)
      gfx.drawLine(x, y + 3, x + w, y + 3)
      for cx = x + 4, x + w - 3, 8 do gfx.drawPixel(cx, y + 6); gfx.drawPixel(cx, y + 8) end
    elseif curtain == "wc5" then                          -- lace across the whole window
      gfx.setColor(BLACK)
      for yy = y + 3, y + h - 3, 3 do
        for xx = x + 3 + ((math.floor(yy / (3))) % 2) * 2, x + w - 3, 4 do gfx.drawPixel(xx, yy) end
      end
      for cx = x + 3, x + w - 3, 6 do gfx.drawCircleAtPoint(cx, y + h - 2, 2) end
      gfx.drawLine(x + 1, y + 2, x + w - 1, y + 2)
    elseif curtain == "wc8" then                          -- blinds, pulled down a little over half way
      gfx.setColor(WHITE); gfx.fillRect(x + 1, y + 1, w - 2, 15)
      gfx.setColor(BLACK)
      for yy = y + 2, y + 15, 3 do gfx.drawLine(x + 1, yy, x + w - 1, yy) end
      gfx.drawLine(x + 1, y + 16, x + w - 1, y + 16)
      UI.ink("cream")
      gfx.drawLine(x + w - 6, y + 16, x + w - 6, y + 21); gfx.fillCircleAtPoint(x + w - 6, y + 22, 2)   -- the pull cord
    else                                                  -- two drapes with tie-backs
      CAFE.drape(x + 1, y + 1, 11, h - 2, 1, curtain, sway)
      CAFE.drape(x + w - 1, y + 1, 11, h - 2, -1, curtain, sway)
      UI.ink("brass")
      gfx.setColor(BLACK)
      gfx.fillRect(x - 2, y - 2, w + 4, 2)                -- the curtain rod
      gfx.fillCircleAtPoint(x - 3, y - 1, 2); gfx.fillCircleAtPoint(x + w + 3, y - 1, 2)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

function CAFE.windowAt(x, y, frame, curtain, preview)
  CAFE.windowBase(x, y, frame, preview)
  CAFE.windowTop(x, y, frame, curtain, preview, nil)
end

function CAFE.drawWindowNow()
  local frame, curtain = CAFE.ownedOf("frame"), CAFE.ownedOf("curtain")
  CAFE.windowBase(32, 22, frame, false)          -- the glass and what's outside move...
  local sway = 0
  if curtain and G and G.win and G.win.fx and G.win.fx.wind then sway = (math.floor(frames / (14))) % 2 end
  local st = G.winOv
  if not st then st = {}; G.winOv = st end
  local im = st[sway]
  if im == nil then                              -- ...the frame and curtains on top are drawn once
    st[sway] = false
    im = CAFE.snap(function() CAFE.windowTop(6, 8, frame, curtain, false, sway) end, 0, 40, 0, 66)
    st[sway] = im
  end
  if im then im:draw(26, 14) else CAFE.windowTop(32, 22, frame, curtain, false, sway) end
end

function CAFE.windowPreview(id, cx, cy)                 -- the shop picture: the window at 1.6 times its size
  CAFE.WPREV = CAFE.WPREV or {}
  local im = CAFE.WPREV[id]
  if im == nil then
    im = gfx.image.new(66, 40, gfx.kColorClear)
    gfx.pushContext(im)
    local isFrame = CAFE.byId[id].kind == "frame"
    CAFE.windowAt(6, 8, isFrame and id or nil, (not isFrame) and id or nil, true)
    gfx.popContext()
    CAFE.WPREV[id] = im
  end
  im:drawScaled(cx - 52, cy - 32, 1.6, 1.6)
end

for _, id in ipairs(CAFE.FRAMES) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end
for _, id in ipairs(CAFE.CURTAINS) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end

-- ---- pets --------------------------------------------------------------------------------------------
function CAFE.homeOf(kind)               -- where the pet's own furniture is (if you've put it out)
  local d = G.cafe
  local id = (kind == "cat") and "cattree" or ((kind == "dog") and "dogbed" or nil)      -- (turtles don't have a bed)
  if id and d.decor[id] == "on" and d.place[id] then
    local sl = CAFE.FSLOT[d.place[id]]
    return sl[1], sl[2]
  end
  return nil
end

-- ---- keeping pets off the tables and the floor decor --------------------------------------------------
-- The floor is cut into 6-pixel squares. A square is "taken" when it lies within a table (with its chairs) or a piece of floor decor
-- (plus a little margin), so a pet that plans its walk over the free squares only can never cross a filled spot. Each taken
-- square remembers which things cover it (one bit each), so a pet's own bed or tree can be let through for that pet alone.
CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH = 6, 12, 124, 64, 20       -- square size, left, top, columns, rows

function CAFE.petGrid()                          -- the squares that are taken (made once, when the shift starts or comes back from the shop)
  local g = G.petGrid
  if g then return g, g.obs end
  local obs = CAFE.obstacles()
  local C, X0, Y0, W, Hh = CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  local mask = {}
  for k, o in ipairs(obs) do
    local bit, rr = BITLIB.lshift(1, k - 1), o.r + 4
    local i0 = math.max(0, math.floor((math.min(o.x1, o.x2) - rr - X0) / C))
    local i1 = math.min(W - 1, math.ceil((math.max(o.x1, o.x2) + rr - X0) / C))
    local j0 = math.max(0, math.floor((math.min(o.y1, o.y2) - rr - Y0) / C))
    local j1 = math.min(Hh - 1, math.ceil((math.max(o.y1, o.y2) + rr - Y0) / C))
    for j = j0, j1 do
      for i = i0, i1 do
        if CAFE.dist(o, X0 + i * C, Y0 + j * C) < rr then mask[j * W + i] = BITLIB.bor((mask[j * W + i] or 0), bit) end
      end
    end
  end
  g = { obs = obs, mask = mask }
  G.petGrid = g
  return g, obs
end

function CAFE.petTaken(mask, n, ex)               -- is square n taken by anything but the things in ex?
  local m = mask[n]
  return m ~= nil and BITLIB.band(m, BITLIB.bnot(ex)) ~= 0
end

function CAFE.petCell(x, y)                       -- the square a point is in
  local C, W, Hh = CAFE.PGC, CAFE.PGW, CAFE.PGH
  local i = math.max(0, math.min(W - 1, math.floor((x - CAFE.PGX) / C + 0.5)))
  local j = math.max(0, math.min(Hh - 1, math.floor((y - CAFE.PGY) / C + 0.5)))
  return j * W + i
end

function CAFE.petLOS(g, ax, ay, bx, by, ex)       -- can a pet walk straight from a to b without touching a taken square?
  local mask, C, X0, Y0, W, Hh = g.mask, CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  local n = math.max(1, math.floor(math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2) / 3))
  for k = 1, n do
    local x, y = ax + (bx - ax) * k / n, ay + (by - ay) * k / n
    local i, j = math.floor((x - X0) / C + 0.5), math.floor((y - Y0) / C + 0.5)
    if i < 0 or i >= W or j < 0 or j >= Hh then return false end
    if CAFE.petTaken(mask, j * W + i, ex) then return false end
  end
  return true
end

-- Working out a walk is done a little at a time (a few squares a frame), so a pet that is deciding where to go never stalls the game.
function CAFE.petSearch(g, si, gi, ex)            -- start looking for a way from square si to square gi over free squares
  return { g = g, si = si, gi = gi, nex = BITLIB.bnot(ex), best = { [si] = 0 }, from = { [si] = si }, done = {},
           hk = { 0 }, hv = { si }, hn = 1 }
end

function CAFE.petStep(st, budget)                 -- look at up to `budget` squares: the way (a list of squares) when found, false if there is none, nil if still looking
  local mask, W, Hh, nex = st.g.mask, CAFE.PGW, CAFE.PGH, st.nex
  local gx, gy, gi, si = st.gi % W, math.floor(st.gi / (W)), st.gi, st.si
  local best, from, done, hk, hv, hn = st.best, st.from, st.done, st.hk, st.hv, st.hn
  while hn > 0 and budget > 0 do
    local cur = hv[1]
    local lk, lv = hk[hn], hv[hn]
    hk[hn], hv[hn] = nil, nil
    hn = hn - 1
    if hn > 0 then
      local i = 1
      while true do
        local l = i * 2
        if l > hn then break end
        if l < hn and hk[l + 1] < hk[l] then l = l + 1 end
        if hk[l] < lk then hk[i], hv[i] = hk[l], hv[l]; i = l else break end
      end
      hk[i], hv[i] = lk, lv
    end
    if not done[cur] then
      done[cur] = true
      budget = budget - 1
      if cur == gi then
        local path, c = {}, cur
        while c ~= si do path[#path + 1] = c; c = from[c] end
        for a = 1, math.floor(#path / (2)) do path[a], path[#path + 1 - a] = path[#path + 1 - a], path[a] end
        return path
      end
      local ci, cj, cg = cur % W, math.floor(cur / (W)), best[cur]
      for dj = -1, 1 do
        for di = -1, 1 do
          local ni, nj = ci + di, cj + dj
          if (di ~= 0 or dj ~= 0) and ni >= 0 and ni < W and nj >= 0 and nj < Hh then
            local n = nj * W + ni
            local m = mask[n]
            if not done[n] and (m == nil or BITLIB.band(m, nex) == 0) then
              local ok = true
              if di ~= 0 and dj ~= 0 then                                   -- (a diagonal step may not cut between two taken squares)
                local m1, m2 = mask[cj * W + ni], mask[nj * W + ci]
                ok = (m1 == nil or BITLIB.band(m1, nex) == 0) and (m2 == nil or BITLIB.band(m2, nex) == 0)
              end
              if ok then
                local ng = cg + ((di ~= 0 and dj ~= 0) and 1.4142 or 1)
                if best[n] == nil or ng < best[n] then
                  best[n], from[n] = ng, cur
                  local dx, dy = math.abs(ni - gx), math.abs(nj - gy)
                  local f = ng + dx + dy - 0.5858 * math.min(dx, dy)
                  hn = hn + 1
                  local i = hn
                  while i > 1 do
                    local pi = math.floor(i / (2))
                    if hk[pi] > f then hk[i], hv[i] = hk[pi], hv[pi]; i = pi else break end
                  end
                  hk[i], hv[i] = f, n
                end
              end
            end
          end
        end
      end
    end
  end
  st.hn = hn
  if hn == 0 then return false end
  return nil
end

function CAFE.petCorners(g, path, sx, sy, tx, ty, ex)    -- the corners to go round on the way from (sx, sy) to (tx, ty): the squares of the way, pulled straight where a pet can see ahead
  local W, C, X0, Y0 = CAFE.PGW, CAFE.PGC, CAFE.PGX, CAFE.PGY
  local cells = {}
  for k, n in ipairs(path) do cells[k] = { X0 + (n % W) * C, Y0 + (math.floor(n / (W))) * C } end
  local out, ax, ay, k = {}, sx, sy, 1
  while k <= #cells do
    if CAFE.petLOS(g, ax, ay, tx, ty, ex) then break end         -- the goal is in sight from here: no more corners
    local best, j = k, k
    while j <= #cells and CAFE.petLOS(g, ax, ay, cells[j][1], cells[j][2], ex) do best = j; j = j + 1 end
    out[#out + 1] = cells[best]
    ax, ay = cells[best][1], cells[best][2]
    k = best + 1
  end
  return out
end

function CAFE.petAim(kind, p)                     -- pick the next place for a pet to go and start looking for the way: false if it is boxed in
  local th = p.think
  local g, obs = CAFE.petGrid()
  local C, X0, Y0, W, Hh, mask = CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH, g.mask
  if th == nil then
    local hx, hy = CAFE.homeOf(kind)
    local ex = 0
    if hx then for k, o in ipairs(obs) do if o.x1 == hx and o.y1 == hy + 6 then ex = BITLIB.lshift(1, k - 1) end end end   -- (its own bed or tree is open to it)
    th = { ex = ex, sx = p.x, sy = p.y, tries = 0, hx = hx, hy = hy }
    local si = CAFE.petCell(p.x, p.y)
    if CAFE.petTaken(mask, si, ex) then            -- standing inside something: step out to the nearest free square first
      local ci, cj, bestN, bd = si % W, math.floor(si / (W)), nil, 1e9
      for dj = -6, 6 do
        for di = -6, 6 do
          local ni, nj = ci + di, cj + dj
          if ni >= 0 and ni < W and nj >= 0 and nj < Hh and not CAFE.petTaken(mask, nj * W + ni, ex) and di * di + dj * dj < bd then
            bestN, bd = nj * W + ni, di * di + dj * dj
          end
        end
      end
      if not bestN then return false end
      si = bestN
      th.first = { X0 + (si % W) * C, Y0 + (math.floor(si / (W))) * C }
      th.sx, th.sy = th.first[1], th.first[2]
    end
    th.si = si
    p.think = th
  end
  th.tries, th.picks = th.tries + 1, (th.picks or 0) + 1
  if th.tries > 4 or th.picks > 14 then p.think = nil; return false end
  if th.tries == 1 and th.hx and not p.home and math.random() < ((kind == "dog") and 0.65 or 0.45) then     -- off to its own bed or tree
    th.tx, th.ty, th.home = th.hx, th.hy + ((kind == "cat") and 14 or 10), true
  else
    local i = math.random(math.ceil((50 - X0) / C), math.floor((380 - X0) / C))
    local j = math.random(math.ceil((126 - Y0) / C), math.floor((226 - Y0) / C))
    local x, y = X0 + i * C, Y0 + j * C
    if mask[j * W + i] ~= nil or (x - p.x) ^ 2 + (y - p.y) ^ 2 <= 400 then th.st, th.tries = nil, th.tries - 1; return true end   -- (not a good spot: pick again next frame)
    th.tx, th.ty, th.home = x + math.random(-2, 2), y + math.random(-2, 2), false
  end
  th.st = CAFE.petSearch(g, th.si, CAFE.petCell(th.tx, th.ty), th.ex)
  return true
end

function CAFE.petThink(kind, p)                   -- a pet that is deciding: a few squares of looking each frame; sets it walking when the way is found
  local th = p.think
  if th == nil or th.st == nil then
    if not CAFE.petAim(kind, p) then p.think = nil; p.wait = 1 + math.random() * 2 end       -- boxed in: have another look in a moment
    return
  end
  local res = CAFE.petStep(th.st, 30)
  if res == nil then return end
  if res == false then th.st = nil; return end                                   -- no way there: try another place
  local g = CAFE.petGrid()
  local wp = CAFE.petCorners(g, res, th.sx, th.sy, th.tx, th.ty, th.ex)
  if th.first then table.insert(wp, 1, th.first) end
  p.tx, p.ty, p.home, p.wp = th.tx, th.ty, th.home, wp
  p.mode, p.think = "walk", nil
end

function CAFE.petPlace(p)                         -- a pet that has just arrived starts on a free bit of floor
  local g = CAFE.petGrid()
  local cand, C, X0, Y0, W, Hh = {}, CAFE.PGC, CAFE.PGX, CAFE.PGY, CAFE.PGW, CAFE.PGH
  for j = 0, Hh - 1 do
    for i = 0, W - 1 do
      local x, y = X0 + i * C, Y0 + j * C
      if g.mask[j * W + i] == nil and x >= 60 and x <= 340 and y >= 130 and y <= 220 then cand[#cand + 1] = { x, y } end
    end
  end
  if #cand > 0 then
    local c = cand[math.random(#cand)]
    p.x, p.y = c[1] + math.random(-2, 2), c[2] + math.random(-2, 2)
  end
  p.fresh = nil
end

function CAFE.makePets()
  local pets = {}
  local d = CAFE.cur
  for _, kind in ipairs({ "cat", "dog", "turtle" }) do
    local var = CAFE.petOn(d, kind)
    if var then
      pets[kind] = { var = var, x = 60 + math.random() * 280, y = 130 + math.random() * 90, tx = 0, ty = 0,
                     mode = "idle", wait = 1 + math.random() * 3, dir = 1, home = false, fresh = true,
                     pose = (kind == "cat") and "sit" or "sit" }
    end
  end
  return pets
end

function CAFE.updatePets(dt)
  for kind, p in pairs(G.pets) do
    local speed = (kind == "cat") and 20 or ((kind == "turtle") and 9 or 26)
    if p.fresh then CAFE.petPlace(p) end                  -- (first thing: stand on a free bit of floor, not on a table)
    if p.mode == "walk" then
      local gx, gy = p.tx, p.ty
      local via = p.wp and p.wp[1]
      if via then gx, gy = via[1], via[2] end
      local dx, dy = gx - p.x, gy - p.y
      local dist = math.sqrt(dx * dx + dy * dy)
      if via and dist <= speed * dt then          -- reached a corner of the detour: carry on to the next
        p.x, p.y = gx, gy
        table.remove(p.wp, 1)
      elseif dist <= speed * dt then
        p.x, p.y = p.tx, p.ty
        p.mode = p.home and "rest" or "idle"
        if kind == "cat" then
          p.pose = (math.random() < (p.home and 0.7 or 0.45)) and "sleep" or "sit"
        elseif kind == "turtle" then
          p.pose = (math.random() < 0.4) and "hide" or "sit"
        else
          p.pose = p.home and "lie" or ((math.random() < 0.55) and "sit" or "lie")
        end
        local sleepy = (p.pose == "sleep" or p.pose == "lie" or p.pose == "hide")
        p.wait = p.home and (12 + math.random() * 14) or (sleepy and (7 + math.random() * 9) or (2 + math.random() * 5))
      else
        p.x = p.x + dx / dist * speed * dt
        p.y = p.y + dy / dist * speed * dt
        if math.abs(dx) > 1 then p.dir = dx > 0 and 1 or -1 end
      end
    else
      p.wait = p.wait - dt
      if p.wait <= 0 then
        CAFE.petThink(kind, p)                                -- (works out a way to a spot it can really get to, round the tables and the floor decor)
      end
    end
  end
end

-- a floating "z" for sleepers
function CAFE.zzz(x, y)
  UI.inkPush("inkblue")
  local k = (math.floor(frames / (18))) % 3
  for i = 0, 1 do
    local zy = y - 5 - i * 6 - k
    local sz = 2 + i
    gfx.drawLine(x + i * 4, zy, x + i * 4 + sz, zy)
    gfx.drawLine(x + i * 4 + sz, zy, x + i * 4, zy + sz)
    gfx.drawLine(x + i * 4, zy + sz, x + i * 4 + sz, zy + sz)
  end
  UI.inkPop()
end

-- an ear: black, with a thin white edge so it shows up against the black head
function CAFE.ear(x1, y1, x2, y2, x3, y3)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  gfx.setColor(WHITE)
  gfx.drawLine(x1, y1, x3, y3)
  gfx.setColor(BLACK)
end

-- x, y = where the feet are. cat: walk / sit / sleep.  dog: walk / sit / lie
-- ---- turtles: slow little shells (they walk, look about, or tuck right in) -----------------------------
CAFE.TSPEC = {                                       -- w = half the shell's width, h = how tall the dome is, leg = leg length
  turtle    = { w = 8,  h = 8,  leg = 3, st = "hex" },
  boxturtle = { w = 7,  h = 9,  leg = 3, st = "dots" },
  tortoise  = { w = 10, h = 11, leg = 4, st = "grid", head = 3 },
  slider    = { w = 9,  h = 6,  leg = 3, st = "stripes" },
}
CAFE.TDOME = {}
function CAFE.domeRows(w, h)                         -- how wide the shell is on every row (bottom row first), worked out once
  local key = w * 100 + h
  local t = CAFE.TDOME[key]
  if not t then
    t = {}
    for r = 0, h - 1 do t[r] = math.floor(w * math.sqrt(1 - ((r + 0.5) / h) ^ 2) + 0.5) end
    CAFE.TDOME[key] = t
  end
  return t
end

function CAFE.turtle(x, y, d, pose, var)             -- x, y = where the feet are. poses: walk / sit / hide
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.TSPEC[var] or CAFE.TSPEC.turtle
  local w, h, leg = sp.w, sp.h, sp.leg
  local hid = (pose == "hide")
  local yb = hid and (y - 1) or (y - leg)             -- the row the shell sits on
  local rows = CAFE.domeRows(w, h)
  local col = CAFE.TCOL[var] or CAFE.TCOL.turtle
  UI.ink(col[1])
  gfx.setColor(BLACK)
  for r = 0, h - 1 do gfx.drawLine(x - rows[r], yb - r, x + rows[r], yb - r) end
  gfx.fillRect(x - w, yb, w * 2 + 1, 2)                -- the flat underside
  if not hid then
    UI.ink(col[2])
    local walk = (pose == "walk")
    local st = walk and ((math.floor(frames / (7))) % 2) or 0
    gfx.fillRect(x + d * (w - 3) - 1, yb + 2, 3, leg - 1 - st)           -- front foot
    gfx.fillRect(x - d * (w - 3) - 1, yb + 2, 3, leg - 2 + st)           -- back foot
    gfx.drawLine(x - d * w, yb + 1, x - d * (w + 3), yb + 2)             -- a stubby tail
    local hr = sp.head or 2
    local bob = walk and ((math.floor(frames / (9))) % 2) or 0
    local up = (pose == "sit") and 2 or 0                                -- looking about: the neck stretches up
    local hx, hy = x + d * (w + 3 + hr), yb - up - bob
    gfx.setLineWidth(hr + 1)
    gfx.drawLine(x + d * (w - 1), yb + 1, hx - d, hy)                    -- the neck
    gfx.setLineWidth(1)
    gfx.fillCircleAtPoint(hx, hy, hr)
    gfx.setColor(WHITE)
    gfx.drawPixel(hx + d, hy - 1)                                         -- an eye
    if var == "slider" then UI.ink("redp"); gfx.drawPixel(hx - d * 2, hy); gfx.drawPixel(hx - d * 2, hy + 1) end   -- the red ear patch
  else
    gfx.setColor(WHITE)
  end
  UI.ink(col[1])
  gfx.setColor(WHITE)                                   -- the pattern on the shell
  local m = yb - math.floor(h / (2))
  if sp.st == "hex" then
    gfx.drawLine(x - 3, m, x + 3, m)
    gfx.drawLine(x - 2, yb - h + 2, x - 3, m); gfx.drawLine(x + 2, yb - h + 2, x + 3, m)
    gfx.drawLine(x - 3, m, x - 5, yb - 1); gfx.drawLine(x + 3, m, x + 5, yb - 1)
  elseif sp.st == "dots" then
    gfx.drawPixel(x, yb - h + 3); gfx.drawPixel(x - 3, m + 1); gfx.drawPixel(x + 3, m + 1)
    gfx.drawPixel(x, m); gfx.drawPixel(x - 2, yb - 2); gfx.drawPixel(x + 2, yb - 2)
  elseif sp.st == "grid" then
    gfx.drawLine(x - 6, yb - 3, x + 6, yb - 3); gfx.drawLine(x - 4, yb - 7, x + 4, yb - 7)
    gfx.drawLine(x, yb - h + 2, x, yb - 3); gfx.drawLine(x - 4, yb - 7, x - 5, yb - 1); gfx.drawLine(x + 4, yb - 7, x + 5, yb - 1)
  else                                                  -- stripes
    gfx.drawLine(x - 6, yb - 2, x + 6, yb - 2); gfx.drawLine(x - 4, yb - 4, x + 4, yb - 4)
    gfx.drawPixel(x, yb - h + 2)
  end
  gfx.setColor(BLACK)
  if hid then CAFE.zzz(x + d * (w + 1), yb - h) end
end

-- the PC colours: each coat is a (body, markings) pair; turtles are { shell, skin }; cats get coloured eyes
CAFE.PETCOL = { cat = "pcat", tuxcat = "ptux", tabbycat = "ptabby", calicocat = "pcalico", graycat = "pgray",
                dog = "pchoc", dalmatian = "pdal", husky = "phusky", patchdog = "ppatch", goldendog = "pgold" }
CAFE.PETEYE = { cat = "yellow", tuxcat = "leaf", tabbycat = "leaf", calicocat = "yellow", graycat = "yellow" }
CAFE.TCOL = { turtle = { "tsh1", "olive" }, boxturtle = { "tsh2", "bark" }, tortoise = { "tsh3", "tan" }, slider = { "tsh4", "forest" } }
function CAFE.pet(kind, x, y, dir, pose, var)
  if kind == "turtle" then CAFE.turtle(x, y, dir, pose, var); UI.ink("none"); return end
  UI.ink(CAFE.PETCOL[var or kind] or "pcat")
  CAFE.petBody(kind, x, y, dir, pose, var)
  if var and var ~= "cat" and var ~= "dog" then CAFE.petCoat(kind, var, math.floor(x), math.floor(y), dir, pose) end
  UI.ink("none")
end

-- coat markings drawn over the plain black pet (white marks, or a grey dither)
function CAFE.petCoat(kind, var, x, y, dir, pose)
  local bx, by, hw, hh, hx, hy                      -- body centre and half sizes, head centre
  if kind == "cat" then
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 5, 6, 3, x + dir * 7, y - 9
    elseif pose == "sleep" then bx, by, hw, hh, hx, hy = x, y - 4, 8, 3, x + dir * 6, y - 5
    else bx, by, hw, hh, hx, hy = x, y - 5, 4, 4, x + dir, y - 12 end
  else
    local sp = CAFE.PETSPEC[var] or CAFE.PETSPEC.dog
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 8 - sp.up, 9 + sp.bl, 4, x + dir * (10 + sp.bl), y - 14 - sp.up
    elseif pose == "lie" then bx, by, hw, hh, hx, hy = x, y - 4, 9 + sp.bl, 3, x + dir * (10 + sp.bl), y - 4
    else bx, by, hw, hh, hx, hy = x - 2, y - 6, 5, 4, x + dir * 3, y - 19 - math.floor(sp.up / (2)) end
  end
  local function grey(cx, cy, w, h)
    gfx.setColor(BLACK); gfx.setPattern(CHECK)
    gfx.fillEllipseInRect(cx - w, cy - h, w * 2, h * 2)
    gfx.setColor(BLACK)
  end
  gfx.setColor(WHITE)
  if var == "tuxcat" then                          -- white bib, belly and a pale nose
    gfx.fillEllipseInRect(bx - 2, by, 5, hh)
    gfx.drawPixel(hx + dir, hy + 1)
    gfx.drawLine(hx, hy + 2, hx + dir, hy + 2)
  elseif var == "tabbycat" then                    -- stripes across the back
    for i = -3, 3, 3 do                              -- wobbly stripes, not ruler-straight
      gfx.drawLine(bx + i, by - hh + 1, bx + i + 1, by)
      gfx.drawLine(bx + i + 1, by, bx + i, by + hh - 1)
    end
  elseif var == "calicocat" then                   -- patches
    gfx.fillEllipseInRect(bx - hw + 1, by - hh + 1, 4, 3)
    gfx.fillEllipseInRect(bx + 1, by, 4, 3)
    gfx.drawPixel(hx - dir, hy - 2)
  elseif var == "graycat" then
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1)                   -- (the head stays dark so the face shows)
  elseif var == "dalmatian" then                   -- spots all over
    gfx.fillCircleAtPoint(bx - hw + 2, by - 1, 1); gfx.fillCircleAtPoint(bx + 1, by + 1, 1)
    gfx.fillCircleAtPoint(bx + hw - 3, by - 1, 1); gfx.fillCircleAtPoint(bx - 2, by - 2, 1)
    gfx.fillCircleAtPoint(bx + 3, by - 2, 1); gfx.fillCircleAtPoint(bx - hw + 3, by + 2, 1)
    gfx.drawPixel(hx - dir * 2, hy - 2)
  elseif var == "husky" then                       -- grey coat, white face mask and belly
    gfx.setColor(BLACK); grey(bx, by, hw + 1, hh + 1); gfx.setColor(WHITE)
    gfx.drawLine(hx + (dir > 0 and 2 or -6), hy + 2, hx + (dir > 0 and 6 or -2), hy + 2)      -- pale muzzle
    gfx.drawLine(hx, hy - 3, hx, hy - 1)                                                       -- the blaze
  elseif var == "patchdog" then                    -- one white patch and a white chest
    gfx.fillEllipseInRect(bx + dir * 2 - 2, by - hh + 1, 5, 4)         -- a white patch on the back
    gfx.fillEllipseInRect(bx - dir * 4 - 1, by, 3, 3)                   -- and one on the haunch
    gfx.drawLine(hx, hy - 3, hx, hy - 1)                                -- a little blaze
  elseif var == "goldendog" then                   -- a pale golden coat (ears and nose stay dark)
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1); grey(hx, hy, 3, 3)
  end
  gfx.setColor(BLACK)
  CAFE.petEyes(kind, var, x, y, dir, pose)
end

function CAFE.petEyes(kind, var, x, y, d, pose)   -- the coats paint over the face, so the eyes go back on top
  local sp = CAFE.PETSPEC[var] or CAFE.PETSPEC[kind]
  gfx.setColor(WHITE)
  if kind == "cat" then
    if pose ~= "sleep" then UI.ink(CAFE.PETEYE[var] or "yellow") end
    local f = sp.fat
    if pose == "walk" then gfx.drawPixel(x + d * 8, y - 10); gfx.drawPixel(x + d * 6, y - 10)
    elseif pose == "sleep" then gfx.drawLine(x + d * 5, y - 5, x + d * 7, y - 5)
    else gfx.drawPixel(x + d - 1, y - 12 - math.floor(f / (2))); gfx.drawPixel(x + d + 2, y - 12 - math.floor(f / (2))) end
  else
    local bl, up = sp.bl, sp.up
    local hs = (sp.hr or 4) - 4
    local ex, ey
    if pose == "walk" then ex, ey = x + d * (11 + bl), y - 15 - up - hs
    elseif pose == "lie" then
      gfx.drawLine(x + d * (9 + bl), y - 5, x + d * (11 + bl), y - 5)
      gfx.setColor(BLACK); return
    else ex, ey = x + d * 4, y - 20 - math.floor(up / (2)) - hs end
    if var == "husky" or var == "goldendog" then   -- grey face: a small white patch with black eyes
      gfx.fillRect(math.min(ex, ex + d) - 1, ey - 1, 4, 3)
      gfx.setColor(BLACK); gfx.drawPixel(ex, ey); gfx.drawPixel(ex + d, ey)
      return
    end
    gfx.drawPixel(ex, ey); gfx.drawPixel(ex + d, ey)
  end
  gfx.setColor(BLACK)
end

CAFE.PETSPEC = {                                    -- every coat has its own ears, tail and shape
  cat      = { ears = "point", fat = 0, tail = { len = 1.0, g = 1 } },     -- tails differ only in length and thickness
  tuxcat   = { ears = "tall",  fat = 0, tail = { len = 1.35, g = 1 } },
  tabbycat = { ears = "tuft",  fat = 1, tail = { len = 0.45, g = 2 } },
  calicocat = { ears = "point", fat = 1, tail = { len = 1.1, g = 3 } },
  graycat  = { ears = "short", fat = 2, tail = { len = 0.8, g = 2 } },
  dog       = { ears = "floppy", up = 0,  sn = 5, tail = { len = 1.0, g = 1 }, bl = 0, thick = 0 },
  dalmatian = { ears = "fold",   up = 3,  sn = 6, tail = { len = 1.3, g = 1 }, bl = 0, thick = 0 },
  husky     = { ears = "point",  up = 0,  sn = 4, tail = { len = 0.9, g = 2 }, bl = 1, thick = 1 },
  patchdog  = { ears = "long",   up = -2, sn = 4, tail = { len = 0.5, g = 2 }, bl = 2, thick = 0 },
  goldendog = { ears = "floppy", up = 0,  sn = 6, tail = { len = 1.2, g = 3 }, bl = 2, thick = 2 },
}

function CAFE.catEars(hx, hy, d, kind, sit, tipH)
  local tall = (kind == "tall") and 3 or 0
  if sit then
    if kind == "short" then
      CAFE.ear(hx - 3, hy - 2, hx - 3, hy - 6, hx, hy - 3)
      CAFE.ear(hx + 3, hy - 2, hx + 3, hy - 6, hx, hy - 3)
    elseif kind == "round" then
      gfx.fillCircleAtPoint(hx - 3, hy - 4, 2); gfx.fillCircleAtPoint(hx + 3, hy - 4, 2)
    elseif kind == "fold" then
      gfx.fillRect(hx - 5, hy - 5, 4, 2); gfx.fillRect(hx + 2, hy - 5, 4, 2)
    else
      CAFE.ear(hx - 3, hy - 2, hx - 3, hy - 6 - tall, hx, hy - 3)
      CAFE.ear(hx + 3, hy - 2, hx + 3, hy - 6 - tall, hx, hy - 3)
      if kind == "tuft" then gfx.drawPixel(hx - 3, hy - 7); gfx.drawPixel(hx + 3, hy - 7) end
    end
    return
  end
  if kind == "round" then
    gfx.fillCircleAtPoint(hx - d, hy - 4, 2); gfx.fillCircleAtPoint(hx + d * 2, hy - 3, 2)
  elseif kind == "short" then
    CAFE.ear(hx - d * 2, hy - 2, hx - d, hy - 6, hx + d, hy - 2)
    CAFE.ear(hx + d, hy - 2, hx + d * 3, hy - 5, hx + d * 3, hy - 1)
  elseif kind == "fold" then
    gfx.fillRoundRect(hx - 2, hy - 5, 5, 3, 1)
  else
    CAFE.ear(hx - d * 2, hy - 2, hx - d, hy - 2 - tipH - tall, hx + d, hy - 2)
    CAFE.ear(hx + d, hy - 2, hx + d * 3, hy - 1 - tipH - tall, hx + d * 3, hy - 1)
    if kind == "tuft" then gfx.drawPixel(hx - d, hy - 3 - tipH); gfx.drawPixel(hx + d * 3, hy - 2 - tipH) end
  end
end

function CAFE.tailLine(t, bx, by, ex, ey)        -- a tail is a line: t.len says how long, t.g how thick
  ex = bx + (ex - bx) * t.len; ey = by + (ey - by) * t.len
  ex, ey = math.floor(ex + 0.5), math.floor(ey + 0.5)
  gfx.drawLine(bx, by, ex, ey)
  if t.g >= 2 then gfx.drawLine(bx, by + 1, ex, ey + 1) end
  if t.g >= 3 then gfx.drawLine(bx, by - 1, ex, ey - 1); gfx.drawLine(bx + 1, by, ex + 1, ey) end
end

function CAFE.catTail(t, d, bx, by, mx, my, ex, ey)
  mx = bx + (mx - bx) * 1.0
  -- two segments, stretched by the tail's length
  local sx, sy = bx + (mx - bx) * t.len, by + (my - by) * t.len
  local fx, fy = bx + (ex - bx) * t.len, by + (ey - by) * t.len
  sx, sy, fx, fy = math.floor(sx + 0.5), math.floor(sy + 0.5), math.floor(fx + 0.5), math.floor(fy + 0.5)
  for o = 0, t.g - 1 do
    local oy = (o == 0) and 0 or ((o % 2 == 1) and 1 or -1)
    gfx.drawLine(bx, by + oy, sx, sy + oy); gfx.drawLine(sx, sy + oy, fx, fy + oy)
  end
end

function CAFE.dogEars(hx, hy, d, kind)
  if kind == "point" then
    CAFE.ear(hx - 2 * d, hy - 3, hx - d, hy - 9, hx + d, hy - 3)
    CAFE.ear(hx + d, hy - 3, hx + 3 * d, hy - 8, hx + 3 * d, hy - 2)
  elseif kind == "long" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 3 * d, hy - 3, hx - d, hy + 8)
  elseif kind == "fold" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 4, hx + 2 * d, hy + 1)
  else
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 3, hx, hy + 5)
  end
end

function CAFE.dogTail(t, d, bx, by, ex, ey)
  CAFE.tailLine(t, bx, by, ex, ey)
end

function CAFE.petBody(kind, x, y, dir, pose, var)
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.PETSPEC[var or kind] or CAFE.PETSPEC[kind]
  gfx.setColor(BLACK)
  local step = math.floor(math.sin(frames * 0.5) * 1.5)
  local wag = math.floor(math.sin(frames * 0.35) * 3)
  local breathe = math.floor(math.sin(frames * 0.12) + 0.5)
  local d = dir
  if kind == "cat" then
    local f = sp.fat
    if pose == "walk" then
      gfx.fillEllipseInRect(x - 7 - f, y - 8 - f, 14 + 2 * f, 7 + f)
      gfx.fillCircleAtPoint(x + d * 7, y - 9, 3)
      CAFE.catEars(x + d * 7, y - 9, d, sp.ears, false, 5)
      CAFE.catTail(sp.tail, d, x - d * 7, y - 6, x - d * 9, y - 9, x - d * 11, y - 12 + step)
      gfx.drawLine(x - 4, y - 2, x - 4 + step, y)
      gfx.drawLine(x + 4, y - 2, x + 4 - step, y)
      UI.inkPush(CAFE.PETEYE[var or kind])
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 8, y - 10); gfx.setColor(BLACK)
      UI.inkPop()
    elseif pose == "sleep" then                     -- curled up in a ball
      gfx.fillEllipseInRect(x - 9 - f, y - 8 - f - breathe, 18 + 2 * f, 8 + f + breathe)
      gfx.fillCircleAtPoint(x + d * 6, y - 5, 3)
      CAFE.catEars(x + d * 6, y - 5, d, sp.ears, false, 4)
      gfx.setColor(WHITE)
      gfx.drawLine(x + d * 5, y - 5, x + d * 7, y - 5)         -- closed eyes
      if sp.tail.len >= 0.6 then gfx.drawLine(x - 6, y - 3, x + 3, y - 1) end   -- the tail wrapped round
      gfx.setColor(BLACK)
      CAFE.zzz(x + d * 9, y - 8)
    else                                            -- sitting, looking out
      gfx.fillEllipseInRect(x - 5 - f, y - 9 - f, 10 + 2 * f, 9 + f)
      gfx.fillCircleAtPoint(x + d, y - 12 - math.floor(f / (2)), 4)
      CAFE.catEars(x + d, y - 12 - math.floor(f / (2)), d, sp.ears, true, 4)
      CAFE.catTail(sp.tail, d, x - d * 5, y - 2, x - d * 10, y - 6, x - d * 9, y - 10 + math.floor(wag / (2)))
      UI.inkPush(CAFE.PETEYE[var or kind])
      gfx.setColor(WHITE); gfx.drawPixel(x + d - 1, y - 12 - math.floor(f / (2))); gfx.drawPixel(x + d + 2, y - 12 - math.floor(f / (2))); gfx.setColor(BLACK)
      UI.inkPop()
    end
  else
    local up, sn, bl, th = sp.up, sp.sn, sp.bl, sp.thick
    local function snout(hx, hy) gfx.fillRect(d > 0 and (hx + 2) or (hx - 2 - sn), hy, sn, 3) end
    if pose == "walk" then
      local hr = sp.hr or 4
      local hx, hy = x + d * (10 + bl), y - 14 - up - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - bl, y - 12 - up - th, 20 + 2 * bl, 9 + th)
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 10 - up, x - d * (15 + bl), y - 15 - up + wag)
      gfx.drawLine(x - 7 - bl, y - 4 - up, x - 7 - bl + step, y)
      gfx.drawLine(x - 3, y - 4 - up, x - 3 - step, y)
      gfx.drawLine(x + 4, y - 4 - up, x + 4 + step, y)
      gfx.drawLine(x + 8 + bl, y - 4 - up, x + 8 + bl - step, y)
      gfx.setColor(WHITE)
      gfx.drawPixel(x + d * (11 + bl), y - 15 - up)                                  -- eye
      if var == nil or var == "dog" then gfx.fillEllipseInRect(x - 3, y - 7 - up, 8, 3) end   -- pale belly
      gfx.setColor(BLACK)
    elseif pose == "sit" then
      local hr = sp.hr or 4
      local hx, hy = x + d * 3, y - 19 - math.floor(up / (2)) - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - math.floor(bl / (2)), y - 10 - th, 14 + math.floor(bl / (2)), 10 + th)     -- haunches
      gfx.fillRoundRect(x + (d > 0 and 0 or -6), y - 16 - math.floor(up / (2)), 6, 16 + math.floor(up / (2)), 2)   -- chest and front legs
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * 9, y - 2, x - d * 14, y - 3 + wag)
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 4, hy - 1); gfx.drawLine(x + d * 3, y - 10, x + d * 3, y - 3); gfx.setColor(BLACK)
    else                                                                          -- lying down, asleep
      local hr = sp.hr or 4
      local hx, hy = x + d * (10 + bl), y - 4 - (hr - 4)
      gfx.fillEllipseInRect(x - 10 - bl, y - 7 - breathe - th, 20 + 2 * bl, 7 + breathe + th)
      gfx.fillCircleAtPoint(hx, hy, hr)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 3, x - d * (14 + bl), y - 5)
      gfx.setColor(WHITE); gfx.drawLine(x + d * (9 + bl), y - 5, x + d * (11 + bl), y - 5); gfx.setColor(BLACK)
      CAFE.zzz(x + d * 4, y - 8)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawPets()
  for kind, p in pairs(G.pets) do
    if p.mode == "walk" then
      CAFE.pet(kind, p.x, p.y, p.dir, "walk", p.var)
    elseif p.mode == "rest" and p.home then
      local hx, hy = CAFE.homeOf(kind)
      if hx and kind == "cat" then CAFE.pet("cat", hx, hy - 14, p.dir, p.pose, p.var)
      elseif hx then CAFE.pet("dog", hx, hy + 10, 1, "lie", p.var)            -- curled up on the dog bed
      else CAFE.pet(kind, p.x, p.y, p.dir, p.pose, p.var) end
    else
      CAFE.pet(kind, p.x, p.y, p.dir, p.pose, p.var)
    end
  end
end

-- ---- going in and out --------------------------------------------------------------------------------
function CAFE.open()
  UI.fast(function()
    local pre = CAFE.pre
    local ready = pre ~= nil and pre.n >= 3                  -- (already read while you were looking at the title)
    for i = 1, 3 do
      if ready then CAFE.slots[i] = pre[i] or nil else CAFE.slots[i] = CAFE.read(i) end
    end
    CAFE.pre = nil
    CAFE.mode, CAFE.erase, CAFE.sel = "slots", nil, 1
    UI.setTitleItem(false)
    state = CAFE.STATE
    UI.bgSet("slots")
  end)
end

function CAFE.begin()                          -- off to the store
  CAFE.write()                                 -- starting a shift saves the game
  sfxStart()
  transitionTo(function()
    if CAFE.keep then CAFE.resume() else newGame("cafe"); UI.shiftStartAch(CAFE.cur) end
    state = STATE_PLAY
  end)
end

function CAFE.resume()                         -- back from the shop: same people, same clock, new purchases
  local g, d = CAFE.keep, CAFE.cur
  CAFE.keep = nil
  CAFE.applyLayout(d)
  setLayout("cafe")
  G = g
  G.ending, G.cafe, G.msg = false, d, nil
  G.cups.shelf = math.max(0, G.cups.shelf + d.cups - G.cupMax)
  G.cupMax = d.cups
  G.seatLimit, G.seatOff, G.seatCount = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d), CAFE.seatCountOf(d)
  G.petGrid = nil                                 -- (the tables and floor decor may have moved: the pets' map is made again)
  local sk = ((d.decor.hmus == "on") and "H" or "") .. ((d.decor.xmus == "on") and "X" or "")
  if (G.win and G.win.sk or "") ~= sk then G.win = CAFE.newWindowFor(d) end        -- (Halloween or Christmas music was switched on or off in the shop: new weather)
  for _, c in ipairs(G.line or {}) do UI.reseason(c) end                           -- (and a matcha order not taken yet becomes the new season's drink)
  if G.cust and (G.cust.stage or 0) < 2 then UI.reseason(G.cust) end
  G.scn, G.own, G.winOv, G.vineImgs, G.tops = nil, nil, nil, nil, nil     -- every cached picture (wall, counter, floor, window, vines...) is drawn again with the new decor
  for key in pairs(G) do
    if type(key) == "string" and (key:find("Img$") or key:find("^vine")) then G[key] = nil end
  end
  G.pets = CAFE.makePets()
  for i = #G.others, 1, -1 do                   -- tables may have moved or been switched off
    local c = G.others[i]
    if c.seat then
      if c.seat > G.seatLimit or G.seatOff[c.seat] then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      elseif c.state == "seated" then
        c.x, c.y = SEATS[c.seat].x, SEATS[c.seat].y
      elseif c.state == "toSeat" then
        c.path = { { SEATS[c.seat].x, SEATS[c.seat].y } }
      end
    end
  end
  setShiftMenu(true, true)
end

function CAFE.finish()                         -- the shift is over: bank it, open the shop
  G.total = G.cash + G.tips - (G.banked or 0)
  local d = CAFE.cur
  d.money = d.money + G.total
  d.shifts = d.shifts + 1
  CAFE.report = "Shift: " .. money(G.total) .. " from " .. (G.served - (G.servedBank or 0)) .. " customers"
  CAFE.keep = G                                -- the cafe waits as it is: the line, the diners, the clock, the tip jar
  G.banked = G.cash + G.tips                   -- (what has been paid into your money so far; the totals on screen carry on)
  G.servedBank = G.served
  CAFE.write()
  CAFE.mode, CAFE.shopSel, CAFE.scroll, CAFE.msg = "shop", 1, 0, nil
  CAFE.tab, CAFE.focus, CAFE.tabPos = 1, "tabs", 1
  state = CAFE.STATE
end

function CAFE.saveQuit()                       -- Menu button: bank what you've made so far
  if state ~= STATE_PLAY or not G or G.mode ~= "cafe" or G.ending then return end
  G.ending = true
  CAFE.cur.money = CAFE.cur.money + G.cash + G.tips - (G.banked or 0)
  G.banked = G.cash + G.tips
  CAFE.write()
  CAFE.closeDoor()
end

-- ---- the shop ----------------------------------------------------------------------------------------
CAFE.TABINK = { "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12" }     -- (PC: each tab's colour)
-- the shop's pages, like browser tabs (Left / Right to switch)
CAFE.TABS = { "Cafe", "Plants", "Lighting", "Stuff", "Wall", "Window", "Rugs", "Tables", "Pets", "Clothes", "Music", "Sale" }
CAFE.TABPATH = { "cafe", "plants", "lighting", "stuff", "wall", "window", "rugs", "tables", "pets", "clothes", "music", "sale" }
CAFE.TABKIND = { floor = 2, counter = 2, shelf = 2, wall = 5, tiny = 5, ceiling = 3, frame = 6, curtain = 6, rug = 7, runner = 7, orug = 7, cloth = 8, hat = 10, glasses = 10, music = 11 }
CAFE.SALE_TAB = 12                                -- (Sale stays the last tab)
function CAFE.tabOf(row)
  local k = row[3]
  if k == "bow" then return 10 end
  if k == "seat" or k == "cup" or k == "sign" or k == "layout" then return 1 end
  local it = CAFE.byId[row[5] or ""]
  if not it then return 1 end
  if it.needs or it.kind == "pet" or it.pettab then return 9 end          -- pet furniture and tanks first, then the pets
  if it.stuff then return 4 end                    -- the radio, the fish tank, the pinwheel
  if it.lit then return 3 end                      -- lamps, candles and string lights
  return CAFE.TABKIND[it.kind] or 2
end

function CAFE.rowSig()                          -- a cheap number that changes whenever the rows would (no garbage made)
  local d = CAFE.cur
  local sg = (d.seatStep or 0) * 7 + (d.cups or 0) * 13 + (d.sign == false and 1 or 0) * 3 + (d.nobow and 11 or 0)
  local items = CAFE.ITEMS
  for i = 1, #items do
    local st = d.decor[items[i].id]
    if st == "on" then sg = sg + i * 3 elseif st == "off" then sg = sg + i * 5 end
  end
  if CAFE.sale then sg = sg + CAFE.sale.nextMs % 100003 + (CAFE.sale.flash and 29 or 0) end
  sg = sg + math.floor((d.stars or 0) * 100) * 31 + UI.lvl(d) * 37      -- (a prestige row comes and goes with the stars)
  return sg
end

function CAFE.rows()                           -- the rows on the tab you're looking at (kept between frames, rebuilt only when something changes)
  if CAFE.sale and pd.getCurrentTimeMilliseconds() >= CAFE.sale.nextMs then CAFE.rollSale() end
  local sg = CAFE.rowSig()
  local ac = CAFE.allC
  if not (ac and ac.sig == sg and ac.cur == CAFE.cur) then
    ac = { sig = sg, cur = CAFE.cur, rows = CAFE.allRows(), tabs = {} }
    CAFE.allC = ac
  end
  local out = ac.tabs[CAFE.tab]
  if out == nil then
    out = {}
    if CAFE.tab == CAFE.SALE_TAB then                       -- Sale: whatever is marked down right now (it's still on its own tab too)
      for _, r in ipairs(ac.rows) do
        if r[7] then out[#out + 1] = r end
      end
      local ord = {}
      for i, r in ipairs(out) do ord[r] = i end
      table.sort(out, function(a, b) if a[7] ~= b[7] then return a[7] > b[7] end return ord[a] < ord[b] end)     -- (the biggest deals first)
      if #out == 0 then out[1] = { "Nothing on sale", "", "none", 0, nil, "Back in a bit" } end
    else
      for _, r in ipairs(ac.rows) do
        if CAFE.tabOf(r) == CAFE.tab then out[#out + 1] = r end
      end
    end
    ac.tabs[CAFE.tab] = out
  end
  return out
end

CAFE.REVIEWS = {                                  -- what customers say about the things you've put out
  clock = "That wall clock keeps me on time for my coffee!", cuckoo = "The cuckoo clock made my whole day. Cuckoo!",
  calendar = "Handy calendar on the wall, I finally know the date.",
  plant = "That spiky plant gives the place real attitude.", cactus = "Love the cactus. Looks sharp!",
  fern = "The leafy fern makes it feel like a little jungle in here.", flowers = "The flower pot smells lovely.",
  tree = "A Christmas tree all year round? Yes please!", pumpkin = "That pumpkin is the best part of the cafe!",
  palm = "A palm tree inside a cafe, I feel like I'm on vacation.", snake = "The snake plant is stylish and low key.",
  sunflower = "Those sunflowers brighten up my morning.", bonsai = "The bonsai is so calm and peaceful.",
  monstera = "The monstera is huge and gorgeous.", saltlamp = "The salt lamp makes it so warm and cozy.",
  lavalamp = "I could watch that lava lamp for hours.", floorlamp = "The floor lamp makes it feel like home.",
  neoncup = "The neon cup sign is super cool at night.", tulips = "Fresh tulips on the counter, what a nice touch.",
  succ = "The little succulent on the counter is adorable.", daisies = "The daisy vase made me smile.",
  minicac = "That mini cactus is so cute!", herbs = "The herb pot makes the counter smell great.",
  candle1 = "That candle flickering on the table is so cozy.", candle2 = "The tall taper candle is so elegant.",
  candle3 = "Those little tealights make it feel like a spa.", candle4 = "The jar candle smells like heaven. Well, it looks like it does.",
  candle5 = "A candelabra! This place is fancy.", candle6 = "The little lantern candle is so charming.",
  candle7 = "Floating candles? Magical.",
  incense = "The incense makes this place smell calm and wonderful.",
  arclamp = "That arc lamp is so stylish.", torchiere = "The torchiere lamp lights the whole room beautifully.",
  tripodlamp = "The tripod lamp is such a cool piece.", globelamp = "The globe lamp glows like a little moon.",
  tiffany = "That Tiffany lamp is a work of art.", tiffanytab = "The little Tiffany lamp on my table is gorgeous.",
  itemstand = "The stand by the wall is the perfect place for a lamp.", streetlamp = "A street lamp inside a cafe? Love it.",
  paperlamp = "The paper lantern lamp is so soft and calming.", neonheart = "The neon heart sign gives me all the feels.",
  neonbolt = "The neon bolt sign is electric!", neonstar = "That neon star sign is a star itself.",
  neonmoon = "The neon moon sign is so dreamy at night.", neonarrow = "The neon arrow sign pointed me straight to the coffee.",
  discoball = "A disco ball in a cafe? Let's dance!", aquarium = "I watched the fish tank for twenty minutes.", snaketank = "The snake in the tank is so smooth. Kinda scary, kinda great.",
  turtle = "The little turtle is the sweetest thing ever.", boxturtle = "The box turtle hid in its shell when I waved.", tortoise = "That tortoise is so slow and so wise.", slider = "The red-ear turtle has so much attitude.",
  pinwheel = "The pinwheel on the wall is so fun.", radio = "The retro radio playing on the counter is a great touch.",
  boombox = "That boom box is pumping out the best tunes.", luckycat = "The lucky cat waved at me. I feel luckier already.",
  record = "A record player! The music sounds so warm.", snowglobe = "I shook the snow globe. Twice.",
  gumball = "A gumball machine in a cafe? I love it.", cradle = "I could watch that Newton's cradle click all day.",
  miniplaydate = "That little Pee-Dee has been cranking all day.", jukebox = "The juke box is a showstopper. I picked a song.",
  ivy = "Those ivy vines hanging off the shelf are lovely.", bloomvine = "The flowering vines are gorgeous.",
  fernvine = "The fern fronds by the shelf look so fresh.", heartvine = "Those little hearts hanging from the shelf are adorable.",
  berryvine = "The berry vines look good enough to eat.", starvine = "The twinkling vines by the shelf are magical.",
  moss = "The hanging moss gives the place a cozy forest feel.", beadvine = "The bead strands catch the light so nicely.",
  wisteria = "The wisteria hanging off the shelf is dreamy.", lanternvine = "Those tiny lanterns on the shelf are so sweet.",
  lights = "The string lights are so cozy.", fairylights = "The fairy lights make this place feel like a dream.",
  globelights = "Those big round bulbs are so retro. Love them.", lanternlights = "The paper lantern lights glow so softly.",
  heartlights = "The heart lights above the counter made me smile.", starlights = "The star-shaped lights are pure magic.", rug = "The welcome rug really does feel welcoming.",
  t1 = "The tiny landscape on the wall is so charming.", t2 = "That tiny heart on the wall made me smile.",
  t3 = "The tiny sunburst brightens up the wall.", t4 = "I love the tiny mug print. Very on brand!",
  t5 = "The cat portrait is hilarious. I love it.", t6 = "Nice little mirror, I checked my hair.",
  t7 = "The party bunting makes every day feel like a party.", t8 = "Those little stars on the wall are so sweet.",
  t9 = "The music notes on the wall go with the vibe.", t10 = "The moon and stars on the wall are dreamy.",
  t12 = "That sailboat on the wall is calming.", cp1 = "Flowers on my table, how sweet!",
  cp2 = "The candle on my table was so cozy.", cp3 = "The little sprig on my table is a nice touch.",
  cp4 = "A cactus on my table. Don't touch!", cp5 = "A pumpkin on my table! Love it.",
  cp6 = "A tiny Christmas tree on my table, so festive!", cattree = "The cat tree is the best seat in the house, says the cat.",
  dogbed = "The dog bed looks so comfy, I almost took a nap.", cat = "The cat napping by my table made my day.",
  dog = "The dog said hello when I walked in!",
  hmus = { "It's so spooky in here and I love it!", "That spooky swing music with the leaves falling outside is perfect.",
           "The fall vibes in here are unreal. Pumpkin spice and spooky tunes!", "Rain on the window and spooky music? Cozy and creepy, I'm in.",
           "Happy Halloween! This place has the best fall vibes in town.", "The haunted waltz had me grinning over my pumpkin spice." },
  xmus = { "I love the snow in the window, so peaceful.", "Jingly music and snow at the window. It feels like the holidays in here.",
           "The festive vibes are so nice, I never want to leave.", "Hot cocoa, snowfall and ice skating music. Pure magic!",
           "It feels like Christmas in here. I love it!", "The snow falling outside while that waltz plays is so cozy." },
}

function CAFE.reviewFor(it, name, skip)
  local who = CAFE.WHO
  local txt = CAFE.REVIEWS[it.id]
  if type(txt) == "table" then                    -- several lines to pick from (skip = one already used, so a second review differs)
    local n = math.random(#txt)
    if skip and #txt > 1 then while txt[n] == skip do n = math.random(#txt) end end
    txt = txt[n]
    CAFE.lastReview = txt
  end
  local low = string.lower(it.name)
  if txt == nil then
    local k = it.kind
    if k == "hat" then txt = "Love the " .. low .. " on the barista!"
    elseif k == "glasses" then txt = "Those " .. low .. " look great on the barista."
    elseif k == "pet" then txt = "The " .. low .. " is adorable. I came back just for them!"
    elseif k == "frame" then txt = "Love the " .. low .. " by the window."
    elseif k == "curtain" then txt = "Those " .. low .. " are so pretty."
    elseif k == "runner" then txt = "The " .. low .. " is a lovely touch on the floor."
    elseif k == "orug" then txt = "The " .. low .. " ties the tables together."
    elseif k == "cloth" then txt = "My table had a " .. low .. ". So fancy!"
    elseif k == "rug" then txt = "The " .. low .. " is so cozy underfoot."
    else txt = "I love the " .. low .. " at " .. name .. "." end
  end
  return "Review: \"" .. txt .. "\" - " .. who[math.random(#who)]
end

CAFE.WHO = { "Dana", "Marcus", "Priya", "Leo", "Jo", "Sam", "Ines", "Theo", "Mia", "Ravi", "Zoe", "Omar", "Christian", "Grace", "Bella", "Jay", "Kelly",
             "Aiden", "Amara", "Beatrice", "Caleb", "Chloe", "Dmitri", "Elena", "Felix", "Fatima", "Gus", "Hana", "Hugo", "Imani", "Isaac", "Jasmine", "Kai",
             "Lena", "Lucas", "Maya", "Mateo", "Nadia", "Noah", "Olive", "Oscar", "Penny", "Quinn", "Rosa", "Rhys", "Sasha", "Sofia", "Tariq", "Uma",
             "Victor", "Wendy", "Xavier", "Yara", "Zane", "Abe", "Birdie", "Cleo", "Dev", "Edie", "Finn", "Greta", "Harper", "Ivy", "Jun", "Kofi",
             "Lola", "Milo", "Nora", "Otis", "Pia", "Remy", "Stella", "Tomas", "Una", "Vera", "Walt", "Yuki" }
function CAFE.who() return CAFE.WHO[math.random(#CAFE.WHO)] end

function CAFE.shopMsgs()                         -- welcome lines, what's on sale, and customer reviews of what you own
  if CAFE.msgList and CAFE.msgChecked and frames - CAFE.msgChecked < 40 then return CAFE.msgList end   -- (checked twice a second, not every frame)
  CAFE.msgChecked = frames
  local d = CAFE.cur
  local name = (d.name and d.name ~= "") and d.name or "your cafe"
  local sg = CAFE.rowSig()
  if CAFE.msgKey == sg and CAFE.msgName == name and CAFE.msgList then return CAFE.msgList end
  local ownedIds = {}
  for _, it in ipairs(CAFE.ITEMS) do if d.decor[it.id] == "on" and not it.copyOf then ownedIds[#ownedIds + 1] = it.id end end
  local key = sg
  local sale, half, rest = {}, {}, {}
  if CAFE.sale then
    for id in pairs(CAFE.sale.ids) do
      local it = CAFE.byId[id]
      if it then
        local pct = CAFE.salePct(id)
        sale[#sale + 1] = it.name
        if pct >= 50 then half[#half + 1] = it.name else rest[#rest + 1] = { it.name, pct } end
      end
    end
    table.sort(sale); table.sort(half)
    table.sort(rest, function(a, b) if a[2] ~= b[2] then return a[2] > b[2] end return a[1] < b[1] end)
  end
  local function andList(t)
    if #t == 1 then return t[1] end
    return table.concat(t, ", ", 1, #t - 1) .. " & " .. t[#t]
  end
  local m = { "Welcome to Coffee Supply, " .. name .. "!" }
  if #half >= 1 then m[#m + 1] = "HALF PRICE: " .. andList(half) .. (#half == 1 and " is" or " are") .. " 50% off!" end
  if #rest >= 1 then
    local top = {}
    for i = 1, math.min(3, #rest) do top[i] = rest[i][1] .. " " .. rest[i][2] .. "% off" end
    m[#m + 1] = "ALSO ON SALE: " .. andList(top) .. (#rest > 3 and " and more!" or "!")
  end
  if #sale >= 2 then m[#m + 1] = #sale .. " things are marked down, 10% to 50% off. Open the Sale tab!" end
  -- reviews: about things you really have out (up to 6, picked at random), plus the odd general one
  local pool = {}
  for _, id in ipairs(ownedIds) do pool[#pool + 1] = CAFE.byId[id] end
  local picked = 0
  while #pool > 0 and picked < 6 do
    local it = table.remove(pool, math.random(#pool))
    m[#m + 1] = CAFE.reviewFor(it, name)
    if it.kind == "music" then m[#m + 1] = CAFE.reviewFor(it, name, CAFE.lastReview) end        -- (the season's music gets two, it's what people notice)
    picked = picked + 1
  end
  local general = {
    "\"Best coffee in town at " .. name .. "!\"",
    "\"" .. name .. " is my happy place.\"",
    "\"Five stars, would crank again.\"",
    "\"I come to " .. name .. " every single day.\"",
    "\"Fast service at " .. name .. "!\"",
    "\"The baristas at " .. name .. " know my order.\"",
    "\"Smells amazing the second you walk in.\"",
    "\"My new favorite spot, thanks to " .. name .. ".\"",
    "\"I brought my whole family to " .. name .. ".\"",
    "\"Worth the trip across town.\"",
  }
  if (d.seatStep or 0) >= 1 then general[#general + 1] = "\"Lots of cozy places to sit at " .. name .. ".\"" end
  m[#m + 1] = "Review: " .. general[math.random(#general)] .. " - " .. CAFE.who()
  m[#m + 1] = "New stuff in every tab. Take a look around!"
  if #sale >= 2 then m[#m + 1] = "Deals change every few minutes. Check back soon!" end
  m[#m + 1] = "Thanks for shopping at Coffee Supply!"
  gfx.setFont(fontBold)
  local list, dur, total, wid = {}, {}, 0, {}
  for i, t in ipairs(m) do                      -- a long one stays up long enough to scroll all the way across
    local w = gfx.getTextSize(t)
    list[i] = t
    wid[i] = w
    dur[i] = (w <= 372) and 6000 or math.floor((w + 372) / 55 * 1000)
    total = total + dur[i]
  end
  CAFE.msgKey, CAFE.msgName, CAFE.msgList, CAFE.msgDur, CAFE.msgTotal, CAFE.msgW = key, name, list, dur, total, wid
  return list
end

function CAFE.fitOne(str, maxW, bold)           -- one line cut short with "..." if it can't fit the box
  CAFE.fitCache = CAFE.fitCache or {}
  local key = (bold and "b" or "n") .. maxW .. "|" .. str
  local c = CAFE.fitCache[key]
  if c then return c end
  gfx.setFont(bold and fontBold or fontNormal)
  local out = str
  if gfx.getTextSize(out) > maxW then
    while #out > 1 and gfx.getTextSize(out .. "...") > maxW do out = string.sub(out, 1, #out - 1) end
    out = out .. "..."
  end
  CAFE.fitCache[key] = out
  return out
end

function CAFE.fitLines(str, maxW, bold, maxLines)  -- words wrapped to whole lines no wider than the box (the last line ends in "..." if it still runs over)
  CAFE.fitCache = CAFE.fitCache or {}
  local key = (bold and "B" or "N") .. maxW .. ":" .. maxLines .. "|" .. str
  local c = CAFE.fitCache[key]
  if c then return c end
  gfx.setFont(bold and fontBold or fontNormal)
  local lines, line = {}, ""
  for word in string.gmatch(str, "%S+") do
    local try = (line == "") and word or (line .. " " .. word)
    if gfx.getTextSize(try) > maxW and line ~= "" then lines[#lines + 1] = line; line = word else line = try end
  end
  if line ~= "" then lines[#lines + 1] = line end
  if #lines == 0 then lines[1] = "" end
  if #lines > maxLines then
    local rest = table.concat(lines, " ", maxLines)
    lines = { table.unpack(lines, 1, maxLines) }
    lines[maxLines] = rest
  end
  for i = 1, #lines do lines[i] = CAFE.fitOne(lines[i], maxW, bold) end
  CAFE.fitCache[key] = lines
  return lines
end

-- little 5x7 letters and digits for the sale stickers, each one thickened by a pixel (so 6 wide, 7 with its gap)
UI.PIXG = {
  S = { ".####", "#...#", "#....", ".###.", "....#", "#...#", ".###." },
  A = { ".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
  L = { "#....", "#....", "#....", "#....", "#....", "#....", "#####" },
  E = { "#####", "#....", "#....", "####.", "#....", "#....", "#####" },
  O = { ".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
  F = { "#####", "#....", "#....", "####.", "#....", "#....", "#...." },
  ["0"] = { ".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###." },
  ["1"] = { "..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###." },
  ["2"] = { ".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####" },
  ["3"] = { ".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###." },
  ["4"] = { "...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#." },
  ["5"] = { "#####", "#....", "####.", "....#", "....#", "#...#", ".###." },
  ["6"] = { ".###.", "#....", "#....", "####.", "#...#", "#...#", ".###." },
  ["7"] = { "#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..." },
  ["8"] = { ".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###." },
  ["9"] = { ".###.", "#...#", "#...#", ".####", "....#", "....#", ".###." },
  ["%"] = { "##..#", "##..#", "...#.", "..#..", ".#...", "#..##", "#..##" },
  B = { "####.", "#...#", "#...#", "####.", "#...#", "#...#", "####." },
  C = { ".###.", "#...#", "#....", "#....", "#....", "#...#", ".###." },
  D = { "####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####." },
  G = { ".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".###." },
  H = { "#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
  I = { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "#####" },
  J = { "..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.." },
  K = { "#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#" },
  M = { "#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#" },
  N = { "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", "#...#" },
  P = { "####.", "#...#", "#...#", "####.", "#....", "#....", "#...." },
  Q = { ".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#" },
  R = { "####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#" },
  T = { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.." },
  U = { "#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
  V = { "#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.." },
  W = { "#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#" },
  X = { "#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#" },
  Y = { "#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.." },
  Z = { "#####", "....#", "...#.", "..#..", ".#...", "#....", "#####" },
  [":"] = { ".....", "..#..", "..#..", ".....", "..#..", "..#..", "....." },
  ["!"] = { "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.." },
  ["/"] = { "....#", "...#.", "...#.", "..#..", ".#...", ".#...", "#...." },
}
function UI.pixWidth(str)
  local w = 0
  for i = 1, #str do
    w = w + (string.sub(str, i, i) == " " and 4 or 7)
  end
  return w - 1
end
function UI.pixText(str, x, y)                       -- in the current colour; x, y = top-left
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    local g = UI.PIXG[ch]
    if g then
      for ry = 1, 7 do
        local row = g[ry]
        local c = 1
        while c <= 5 do
          if string.sub(row, c, c) == "#" then
            local c2 = c
            while c2 < 5 and string.sub(row, c2 + 1, c2 + 1) == "#" do c2 = c2 + 1 end
            gfx.fillRect(gx + c - 1, y + ry - 1, c2 - c + 2, 1)      -- (one pixel wider than the run: the thickening)
            c = c2 + 1
          else
            c = c + 1
          end
        end
      end
    end
    gx = gx + (ch == " " and 4 or 7)
  end
end

-- the same letters with single-pixel strokes (6 across each, a space is 3): a long cafe name still fits its sign
function UI.thinWidth(str)
  local w = 0
  for i = 1, #str do w = w + (string.sub(str, i, i) == " " and 3 or 6) end
  return w - 1
end
function UI.thinText(str, x, y)                      -- in the current colour; x, y = top-left
  local gx = x
  for i = 1, #str do
    local ch = string.sub(str, i, i)
    local g = UI.PIXG[ch]
    if g then
      for ry = 1, 7 do
        local row = g[ry]
        local c = 1
        while c <= 5 do
          if string.sub(row, c, c) == "#" then
            local c2 = c
            while c2 < 5 and string.sub(row, c2 + 1, c2 + 1) == "#" do c2 = c2 + 1 end
            gfx.fillRect(gx + c - 1, y + ry - 1, c2 - c + 1, 1)
            c = c2 + 1
          else
            c = c + 1
          end
        end
      end
    end
    gx = gx + (ch == " " and 3 or 6)
  end
end

-- the sale sticker: how much is off. Half price ones are solid, the rest are outlined. x, y = top-left; 60 wide, 17 tall.
UI.SALE_W = 60
function UI.saleSticker(x, y, pct, ink, bg)
  local txt = pct .. "% OFF"
  gfx.setColor(bg); gfx.fillRoundRect(x, y, UI.SALE_W, 17, 6)
  gfx.setColor(ink)
  if pct >= 50 then
    gfx.fillRoundRect(x, y, UI.SALE_W, 17, 6)
    gfx.setColor(bg)
  else
    gfx.drawRoundRect(x, y, UI.SALE_W, 17, 6)
  end
  UI.pixText(txt, x + math.floor((UI.SALE_W - UI.pixWidth(txt)) / (2)), y + 5)
  gfx.setColor(BLACK)
end

function CAFE.salePct(id)                           -- how much off an item is right now (nil when it isn't on sale)
  local v = CAFE.sale and CAFE.sale.ids[id]
  if not v then return nil end
  if CAFE.sale.flash then return 50 end            -- (a Flash Sale from the daily gift: all of it half price)
  return (type(v) == "number") and v or 50
end

function CAFE.rowName(name, price, sale)          -- a list row's name, kept clear of its price and the SALE sticker
  CAFE.fitCache = CAFE.fitCache or {}
  local key = "R" .. name .. "|" .. price .. "|" .. (sale and 1 or 0)
  local c = CAFE.fitCache[key]
  if c then return c[1], c[2] end
  gfx.setFont(fontBold)
  local pw = (price ~= "") and gfx.getTextSize(price) or 0
  local tx = 275 - pw - 4 - UI.SALE_W              -- the sticker's left edge
  local right = sale and (tx - 5) or (275 - pw - 8)
  local txt = CAFE.fitOne(name, right - 20, false)
  CAFE.fitCache[key] = { txt, tx }
  return txt, tx
end

function CAFE.drawShopMsg()                      -- one line a little below the address bar; long ones scroll right to left
  local list = CAFE.shopMsgs()
  local durs = CAFE.msgDur
  local total = 0
  for i = 1, #list do total = total + math.floor(durs[i] * 3 / (100)) end      -- (milliseconds to frames at 30 per second)
  CAFE.msgFr = ((CAFE.msgFr or 0) + 1) % math.max(total, 1)       -- counted in frames, so the scroll moves the same whole pixels every frame
  local t = CAFE.msgFr
  local idx = 1
  while idx < #list and t >= math.floor(durs[idx] * 3 / (100)) do t = t - math.floor(durs[idx] * 3 / (100)); idx = idx + 1 end
  local str = list[idx]
  local w = CAFE.msgW[idx]
  gfx.setColor(BLACK)
  if w <= 372 then
    drawTC(str, 200, UI.shopBgImg() and 30 or 31, true)
  else
    local imgs = CAFE.msgImgs
    if not imgs or CAFE.msgImgsFor ~= list then imgs = {}; CAFE.msgImgs = imgs; CAFE.msgImgsFor = list end
    local im = imgs[idx]
    if im == nil then                                -- the long line is drawn once into a picture; scrolling it is then a single draw per frame
      im = CAFE.snap(function() gfx.setColor(BLACK); drawT(str, 2, 2, true) end, 0, 22, 0, w + 6) or false
      imgs[idx] = im
    end
    if im then
      if UI.shopBgImg() then gfx.setClipRect(10, 29, 380, 17); im:draw(400 - t * 2 - 2, 28); gfx.clearClipRect()
      else im:draw(400 - t * 2 - 2, 29) end
    else
      gfx.setClipRect(0, 29, 400, 22)
      drawT(str, 400 - t * 2, 31, true)
      gfx.clearClipRect()
    end
  end
end

function CAFE.rollSale()                       -- ten things go on sale: two or four of them half price, the rest 10 to 45 percent off
  local d, pool = CAFE.cur, {}
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    local tab = CAFE.tabOf({ nil, nil, "buy", 0, it.id })
    if tab >= 3 and not it.copyOf and d.decor[it.id] == nil and (it.needs == nil or CAFE.hasNeed(d, it.needs)) then
      pool[#pool + 1] = it.id
    end
  end
  local count = math.min(10, #pool)
  local old = CAFE.sale and CAFE.sale.ids or {}
  local fresh = {}
  for _, id in ipairs(pool) do if not old[id] then fresh[#fresh + 1] = id end end
  if #fresh < count then fresh = pool end          -- (nearly everything was on sale last time: nothing else to pick)
  local nHalf = math.min((math.random() < 0.5) and 2 or 4, count)
  local ids = {}
  for k = 1, count do
    if #fresh == 0 then break end
    local id = table.remove(fresh, math.random(#fresh))
    ids[id] = (k <= nHalf) and 50 or (5 * math.random(2, 9))        -- 10, 15 ... 45 percent off
  end
  CAFE.sale = { ids = ids, nextMs = pd.getCurrentTimeMilliseconds() + (240 + math.random() * 120) * 1000 }
end

function CAFE.allRows()
  if CAFE.sale and pd.getCurrentTimeMilliseconds() >= CAFE.sale.nextMs then CAFE.rollSale() end
  local d = CAFE.cur
  local rows = {}
  if d.seatStep < 5 then
    local cost = math.floor(CAFE.SEAT_COST[d.seatStep + 1] * 100 * CAFE.PRICE + 0.5)
    local nxt = CAFE.SEAT_N[d.seatStep + 1]
    local label = (d.seatStep == 4) and "Corner booth (L-table)" or ("Add a table  " .. CAFE.seatsOf(d.seatStep) .. " > " .. nxt .. " seats")
    if d.seatStep == 0 then
      rows[#rows + 1] = { "Dine-in starting kit", money(cost), "seat", cost, nil, "Comes with 1 table and 2 cups" }
    else
      rows[#rows + 1] = { label, money(cost), "seat", cost, nil, "More seats, bigger tips" }
    end
  else
    rows[#rows + 1] = { "Seats  " .. CAFE.seatsOf(5), "MAX", "none", 0, nil, "Your cafe is full of tables!", pv = "table" }
  end
  if d.seatStep == 0 then
    -- (no cups to buy until you have the dine-in starting kit)
  elseif d.cups < 10 then
    local cost = CAFE.CUP_COST[math.max(1, d.cups - 1)] * 100 * CAFE.PRICE
    rows[#rows + 1] = { "More cups  " .. d.cups .. " > " .. (d.cups + 1), money(cost), "cup", cost, nil, "Cups for dine-in drinks" }
  else
    rows[#rows + 1] = { "Cups  " .. d.cups, "MAX", "none", 0, nil, "You own every cup there is!", pv = "cup" }
  end
  if d.char == 3 then rows[#rows + 1] = { "Hair bow", d.nobow and "OFF" or "ON", "bow", 0, nil, "Hides under any hat" } end
  rows[#rows + 1] = { "Cafe sign", d.sign == false and "OFF" or "ON", "sign", 0, nil, "Off frees up wall space" }
  if (d.stars or 0) >= 4.999 then
    table.insert(rows, 1, { "Prestige: Barista Lv " .. (UI.lvl(d) + 1), "GO!", "prestige", 0, nil, "Stars back to 0, bigger tips" })
  end
  for _, it in ipairs(CAFE.ITEMS) do
    if not it.copyOf and (it.needs == nil or CAFE.hasNeed(d, it.needs)) then
      local st = d.decor[it.id]
      local multi = CAFE.multiOK(it) and CAFE.countOf(d, it.id) or nil
      if multi and multi.tot > 0 then                      -- owned: how many, and a row to buy another
        local label = (multi.tot == 1) and (multi.placed == 1 and "ON" or "OFF") or (multi.placed == 0 and "OFF" or (multi.placed .. "/" .. multi.tot .. " ON"))
        rows[#rows + 1] = { it.name, label, "toggle", 0, it.id, CAFE.DESC[it.id], multi = multi }
        local cost = it.cost * 100 * CAFE.PRICE
        rows[#rows + 1] = { "Buy another", money(cost), "more", cost, it.id, CAFE.DESC[it.id], multi = multi, more = true }
      elseif st == nil then
        local cost = it.cost * 100 * CAFE.PRICE
        local pct = CAFE.salePct(it.id)
        if pct then
          cost = math.floor(cost * (100 - pct) / 100 + 0.5)
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id], pct }
        else
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id] }
        end
      else
        rows[#rows + 1] = { it.name, st == "on" and "ON" or "OFF", "toggle", 0, it.id, CAFE.DESC[it.id] }
      end
    end
  end
  if d.seatStep >= 1 then
    rows[#rows + 1] = { "Edit table layout", "", "layout", 0, nil, "Move or hide tables" }
  end
  return rows
end

function CAFE.say(str) CAFE.msg, CAFE.msgT = str, 2.4 end

-- put a wall/floor piece on the grid (picking the spot if there's a choice)
function CAFE.putOut(id)
  local d, it = CAFE.cur, CAFE.byId[id]
  if it.kind == "orug" or it.kind == "rug" then       -- a table rug and the runway rug in front of the counter cover the same floor: one or the other
    local other = (it.kind == "orug") and "rug" or "orug"
    for _, o in ipairs(CAFE.ITEMS) do
      if o.kind == other and d.decor[o.id] == "on" then
        d.decor[id] = "off"
        CAFE.note = { "Rugs overlap!", (it.kind == "orug") and "Toggle runway rug off" or "Toggle oval rugs off", "to enable this." }
        CAFE.write()
        return
      end
    end
  end
  if it.kind == "shelf" then                          -- vines: choose the left or the right end of the cup shelf
    local free = CAFE.vineSidesFree(d, id)
    d.decor[id] = "off"
    if #free == 0 then
      CAFE.say("Shelf ends are full: turn a vine off first.")
    else
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
    end
    CAFE.write()
    return
  end
  if CAFE.isGrid(it) then
    local free = CAFE.freeSlots(d, it.kind, id)
    if #free == 0 then
      d.decor[id] = "off"
      local wide = false                           -- (a counter spot is free, but this one is too wide for it)
      if it.kind == "counter" then for i = 1, #CAFE.CSLOT do if not CAFE.slotTaken(d, "counter", i) then wide = true end end end
      CAFE.say((it.kind == "wall" or it.kind == "tiny") and "Wall's full: turn something off first." or (it.kind == "counter" and (wide and "No wide spot left: turn something off first." or "Counter and tables are full: turn something off first.") or "Floor's full: turn something off first."))
    else                                           -- even one free spot goes to the placing screen so you see where it lands
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      d.decor[id] = "off"
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
      return
    end
  elseif it.species then                           -- one cat and one dog at a time (the new one takes over)
    for _, o in ipairs(CAFE.ITEMS) do
      if o.species == it.species and d.decor[o.id] == "on" then d.decor[o.id] = "off" end
    end
    d.decor[id] = "on"
  elseif it.kind == "hat" or it.kind == "glasses" or it.kind == "rug" or it.kind == "runner" or it.kind == "orug" or it.kind == "cloth" or it.kind == "frame" or it.kind == "curtain" or it.kind == "ceiling" or it.kind == "music" then        -- one of each kind at a time
    for _, o in ipairs(CAFE.ITEMS) do
      if o.kind == it.kind and d.decor[o.id] == "on" then
        d.decor[o.id] = "off"
        if it.kind == "music" then CAFE.say(o.name .. " is off: one season at a time.") end        -- (each season has its own weather)
      end
    end
    d.decor[id] = "on"
  else
    d.decor[id] = "on"
  end
  CAFE.write()
end

-- The season's drink takes the matcha slot, so the music can't change while an order is being made: from the moment its receipt is printed
-- (the order is taken) until the bell at pick up. (People who have not ordered yet just ask for what is on the menu when the shift goes on.)
function CAFE.musicLocked(row)
  local it = CAFE.byId[row[5] or ""]
  if not (it and it.kind == "music") then return false end
  local g = CAFE.keep
  return g ~= nil and g.cust ~= nil and (g.cust.stage or 0) >= 2
end

function CAFE.buy(row)
  local d = CAFE.cur
  if CAFE.musicLocked(row) then sfxWrong(); CAFE.say("Finish the order in progress first: music can't change until it is served."); return end
  if row[3] == "more" then                         -- another copy of something you own
    local cid = (d.money >= row[4]) and CAFE.nextCopy(d, row[5]) or nil
    row = { row[1], row[2], "buy", row[4], cid or row[5], row[6] }
  end
  if d.money < row[4] then
    sfxWrong()
    CAFE.say("Not enough money yet.")
    return
  end
  if row[3] == "seat" and d.seatStep < 4 then       -- a table: choose where it goes, pay when it's down
    local used, free = {}, {}
    for k = 1, 4 do if d.tables[k] then used[d.tables[k]] = true end end
    for _, i in ipairs(CAFE.tableSpots(d.seatStep + 1)) do if not used[i] then free[#free + 1] = i end end
    if #free == 0 then sfxWrong(); CAFE.say("No room for another table."); return end
    CAFE.pend, CAFE.spots, CAFE.spotSel, CAFE.pendCost = "table", free, 1, row[4]
    transitionTo(function()
      G = CAFE.stageG()
      CAFE.mode = "place"
    end)
    return
  end
  d.money = d.money - row[4]
  local it = CAFE.byId[row[5] or ""]
  if UI.lvl(d) <= 1 then d.stars = clamp(d.stars + (it and ((it.kind == "hat" or it.kind == "glasses") and 0 or (it.kind == "pet" and 0.2 or 0.08)) or 0.2), 0, 5) end    -- upgrades earn stars (until the first prestige: then only reviews do)
  UI.statAdd("spent", row[4])
  if CAFE.sale and CAFE.sale.flash and row[7] then UI.statAdd("flash", 1) end
  sfxPlay("tip", false, 1.0)
  if row[3] == "cup" then d.cups = d.cups + 1; CAFE.say("Bought!")
  elseif row[3] == "seat" then d.seatStep = d.seatStep + 1; CAFE.say("Bought!")
  else
    d.decor[row[5]] = "off"
    CAFE.say("Bought!")
    CAFE.putOut(row[5])
    return
  end
  CAFE.write()
end

function CAFE.toggle(row)
  local d = CAFE.cur
  if row[3] == "sign" then
    if d.sign == false then
      if CAFE.slotTaken(d, "wall", 2) or CAFE.slotTaken(d, "wall", 3) then
        -- (sign is off, so the slot test is just about the other decor)
      end
      local blocked = false
      for _, it in ipairs(CAFE.ITEMS) do
        if CAFE.gk(it.kind) == "wall" and d.decor[it.id] == "on" and (d.place[it.id] == 2 or d.place[it.id] == 3) then blocked = true end
      end
      if blocked then sfxWrong(); CAFE.say("Take down the wall decor in its spot first."); return end
      d.sign = true
    else
      d.sign = false
    end
    sfxClick()
    CAFE.write()
    return
  end
  local id = CAFE.toggleTarget(d, row[5])
  if CAFE.musicLocked(row) then sfxWrong(); CAFE.say("Finish the order in progress first: music can't change until it is served."); return end
  if d.decor[id] == "on" then
    d.decor[id] = "off"
    d.place[id] = nil
    if id == "itemstand" or CAFE.byId[id].copyOf == "itemstand" then CAFE.fixTops(d) end     -- (what stood on it moves to the counter)
    sfxClick()
    CAFE.write()
  else
    sfxClick()
    CAFE.putOut(id)
  end
end

-- a stand-in for the cafe with nobody in it (for choosing where things go)
function CAFE.stageG()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  return { mode = "cafe", cafe = d, t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
           px = -300, moving = false, walk = 0, sel = "down", st = nil, cust = nil,
           cupMax = d.cups, seatLimit = CAFE.seatsOf(d.seatStep), seatOff = CAFE.seatOffOf(d), seatCount = CAFE.seatCountOf(d),
           cups = { shelf = d.cups, dirty = 0, hand = 0 },
           sink = { state = "empty", progress = 0, angle = 0, t = 0 },
           win = CAFE.newWindowFor(d), line = {}, others = {}, seats = {}, door = 0, popups = {}, ending = true }
end

function CAFE.spotRect(kind, i)
  if kind == "shelf" then                       -- the two ends of the cup shelf
    return (i == 1) and 92 or 172, 42, 28, 36
  end
  if kind == "counter" then
    if i > 20 then                               -- the top of an Item stand
      local sl = CAFE.FSLOT[i - 20]
      return sl[1] - 15, sl[2] - 27, 30, 34
    end
    if i > 10 then                               -- the middle of a table
      local t = TABLES[i - 10]
      return t.x - 15, t.y - 24, 30, 34
    end
    local sl, cap = CAFE.CSLOT[i], CAFE.SCAP[i]
    local hw = cap and math.min(14, math.max(-cap[1], cap[2]) + 1) or 14         -- (the narrow spots by the sink and the jar get a narrower box)
    return sl[1] - hw, 69, hw * 2, 24
  end
  if kind == "tiny" or kind == "wall" then
    local sl = CAFE.TILES[i]
    return sl[1], sl[2], sl[3], sl[4]
  end
  if kind == "table" then
    local sl = CAFE.TSLOT[i]
    return sl[1] - 27, sl[2] - 19, 54, 38
  end
  local sl = CAFE.FSLOT[i]
  return sl[1] - 16, sl[2] - 18, 32, 36
end

function CAFE.leavePlace(placed)
  local id = CAFE.pend
  if placed then
    local d = CAFE.cur
    if id == "table" then
      d.money = d.money - CAFE.pendCost
      if d.seatStep == 0 then d.cups = math.max(d.cups, 2) end        -- the starting kit comes with two cups
      d.seatStep = d.seatStep + 1
      d.tables[d.seatStep] = CAFE.spots[CAFE.spotSel]
      if UI.lvl(d) <= 1 then d.stars = clamp(d.stars + 0.2, 0, 5) end
      UI.statAdd("spent", CAFE.pendCost or 0)
    else
      d.place[id] = CAFE.spots[CAFE.spotSel]
      d.decor[id] = "on"
    end
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  transitionTo(function()
    G = nil
    CAFE.pend = nil
    CAFE.mode = "shop"
  end)
end

-- move a cursor between spots the way the screen looks: left goes to the spot on the left, up to the one above
function CAFE.spatial(pts, cur, dir)           -- pts = list of {x, y} centres; returns the new index (or the same one)
  local cx, cy = pts[cur][1], pts[cur][2]
  local best, bs
  for i, p in ipairs(pts) do
    if i ~= cur then
      local dx, dy = p[1] - cx, p[2] - cy
      local along, across
      if dir == "R" then along, across = dx, math.abs(dy)
      elseif dir == "L" then along, across = -dx, math.abs(dy)
      elseif dir == "D" then along, across = dy, math.abs(dx)
      else along, across = -dy, math.abs(dx) end
      if along > 2 then
        local sc = along + across * 2.5
        if bs == nil or sc < bs then best, bs = i, sc end
      end
    end
  end
  return best or cur
end

function CAFE.spotPts(kind, list)
  local pts = {}
  for i, sl in ipairs(list) do
    local x, y, w, h = CAFE.spotRect(kind, sl)
    pts[i] = { x + w / 2, y + h / 2 }
  end
  return pts
end

-- ---- the door: turn the sign from CLOSED to OPEN with the crank, then the cafe opens --------------------
CAFE.GREETS = { "Welcome back!", "Hope your day is good!", "Have a good day!", "Coffee heads welcome!",
                "Good to see you again!", "Rise and grind!", "Fresh beans, fresh start!", "Your cafe missed you!",
                "Another day, another cup!", "Let's brew something great!", "Smells like a good day!", "Glad you're here!" }

function CAFE.openDoor()
  CAFE.keep = nil
  CAFE.sale = CAFE.sale and { ids = {}, nextMs = 0 } or nil
  CAFE.rollSale()
  CAFE.door = { p = 0, done = 0, tick = 0 }
  crankHelpStart()
  CAFE.greet, CAFE.greetF, CAFE.report = CAFE.GREETS[math.random(#CAFE.GREETS)], nil, nil
  CAFE.gift = UI.giftReady() and { phase = "box", t = 0, crank = 0 } or nil       -- (today's daily gift, if it hasn't been opened yet)
  transitionTo(function()
    G = { win = WIN.newWindow() }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.closeDoor()                      -- Save & quit: the door shows OPEN, flips to CLOSED, then the title
  transitionTo(function()
    if G and G.mode then closeStation() end
    CAFE.keep = nil
    setShiftMenu(false, false)
    G = { win = WIN.newWindow() }
    CAFE.door = { p = 1, done = 0, tick = 0, closing = true, hold = 0 }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.signFace(open)                   -- the hanging sign, drawn once for each side
  CAFE.signImgs = CAFE.signImgs or {}
  local k = open and "open" or "closed"
  if not CAFE.signImgs[k] then
    local W, H = 164, 56
    local word = open and "OPEN" or "CLOSED"
    local t = gfx.image.new(60, 20, gfx.kColorClear)       -- the word, drawn small then blown up 2x
    gfx.pushContext(t)
    gfx.setColor(BLACK)
    gfx.setFont(fontBold)
    gfx.drawTextAligned(word, 30, 1, kTextAlignment.center)
    gfx.popContext()
    local im = gfx.image.new(W, H, gfx.kColorClear)
    gfx.pushContext(im)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(0, 0, W, H, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(3)
    gfx.drawRoundRect(1, 1, W - 2, H - 2, 9)
    gfx.setLineWidth(1)
    gfx.drawRoundRect(6, 6, W - 12, H - 12, 5)
    local tw = (word == "OPEN") and 2.4 or 2
    local x0, y0 = math.floor(W / 2 - 30 * tw), math.floor(H / 2 - 10 * tw)
    t:drawScaled(x0, y0, tw, tw)
    t:drawScaled(x0 + 1, y0, tw, tw)                       -- drawn twice, a pixel apart: chunkier letters
    gfx.popContext()
    CAFE.signImgs[k] = im
  end
  return CAFE.signImgs[k]
end

function CAFE.doorUpdate(dt, B_)
  local dr = CAFE.door
  WIN.updateWindow(dt)
  if dr.closing then                                    -- it turns itself over, then back to the title
    if dr.done > 0 then
      dr.done = dr.done - dt
      if dr.done <= 0 then
        dr.done = -1
        transitionTo(function() G = nil; state = STATE_MENU end)
      end
    elseif dr.done == 0 then
      dr.hold = dr.hold + dt
      if dr.hold > 0.7 then
        dr.p = math.max(0, dr.p - dt * 0.7)
        if dr.p <= 0 then dr.done = 1.0 end                  -- (no sounds on this screen)
      end
    end
    return
  end
  if dr.done > 0 then
    dr.done = dr.done - dt
    if dr.done <= 0 then dr.done = -1; CAFE.begin() end
    return
  elseif dr.done < 0 then return end
  if B_ then
    sfxClick()
    transitionTo(function() G = nil; CAFE.mode = "slots"; UI.bgSet("slots") end)
    return
  end
  local before = dr.p
  dr.p = dr.p + pd.getCrankChange() / 200                -- about half a turn flips the sign
  if pd.buttonJustPressed(pd.kButtonA) then dr.auto = true end           -- a press of A turns the sign all the way over by itself
  if dr.auto or pd.buttonIsPressed(pd.kButtonRight) or pd.buttonIsPressed(pd.kButtonA) then dr.p = dr.p + dt * 0.9 end
  if pd.buttonIsPressed(pd.kButtonLeft) then dr.p = dr.p - dt * 0.6 end
  dr.p = clamp(dr.p, 0, 1)
  if math.floor(dr.p * 12) ~= math.floor(before * 12) then sfxClick() end
  if dr.p >= 1 then
    sfxPlay("bell", false, 1.0)
    dr.done = 1.0
  end
end

function CAFE.doorArt()                          -- the storefront pictures, loaded once (false if any are missing: the old plain door is drawn)
  local art = CAFE.doorImgs
  if art == nil then
    art = {}
    for k, f in pairs({ bg = "door_bg", win = "door_win", open = "door_open", closed = "door_closed" }) do
      local ok, im = pcall(function() return gfx.image.new("images/" .. f) end)
      if ok and im then art[k] = im else art = false; break end
    end
    CAFE.doorImgs = art
  end
  return art
end

function CAFE.doorDrawArt(art)
  local dr = CAFE.door
  art.bg:draw(0, 0)                                      -- brick walls, lantern, plants, the door, the board for the name, the mat
  WIN.drawView(G.win, 122, 48, 3, true)                  -- the live view through the glass (sky and weather, nobody walking by)
  art.win:draw(118, 42)                                  -- window bars and the little cafe curtain
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)           -- the cafe's name, in white on the board
  do
    local nm = CAFE.cafeName()
    gfx.setFont(fontBold)
    if gfx.getTextSize(nm) <= 176 then
      drawTC(nm, 200, 11, true)
    else                                                  -- a very wide name: chunky capitals, so all of it shows
      local up = string.upper(nm)
      gfx.setColor(WHITE)
      UI.pixText(up, 200 - math.floor(UI.pixWidth(up) / (2)), 15)
      gfx.setColor(BLACK)
    end
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  local fl = (math.floor(frames / (3))) % 3                           -- the lantern flame flickers
  UI.ink("flame")
  gfx.fillPolygon(43, 88, 49, 88, 46, 76 - (fl == 1 and 1 or 0))
  gfx.fillCircleAtPoint(46, 88, 3)
  UI.ink("none")
  local hr = dr.closing and 2 or 7                       -- the clock: seven when you open, two when you close
  local ha = math.rad(hr * 30)
  gfx.setLineWidth(2)
  gfx.drawLine(352, 82, math.floor(352 + math.sin(ha) * 8 + 0.5), math.floor(82 - math.cos(ha) * 8 + 0.5))
  gfx.drawLine(352, 82, 352, 70)
  gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(352, 82, 2)
  -- the sign hangs from a hook and flips over
  UI.ink("brass")
  gfx.fillCircleAtPoint(200, 134, 3)
  local ease = dr.p * dr.p * (3 - 2 * dr.p)
  local ang = ease * math.pi
  local sx = math.abs(math.cos(ang))
  if sx < 0.05 then
    gfx.fillRect(199, 134, 3, 63)
  else
    gfx.drawLine(200, 134, math.floor(200 - 70 * sx), 141)
    gfx.drawLine(200, 134, math.floor(200 + 70 * sx), 141)
    local im = (ang >= math.pi / 2) and art.open or art.closed
    im:drawScaled(math.floor(200 - 82 * sx), 141, sx, 1)
  end
  UI.ink("none")
  gfx.setColor(BLACK)
  if not dr.closing and dr.p < 0.5 and dr.done == 0 then       -- the reminder: spin the crank (or press A)
    local label = UI.color and "Hold SPACE!" or "Press A or crank!"
    gfx.setFont(fontBold)
    local bw = gfx.getTextSize(label) + (UI.color and 28 or 58)          -- (PC: just the words, no crank picture)
    local bx, by = 200 - math.floor(bw / (2)), 200
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, 36, 10)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(bx, by, bw, 36, 10)
    gfx.setLineWidth(1)
    if UI.color then
      drawTC(label, 200, by + 9, true)
    else
      local ix, iy = bx + 22, by + 18                              -- a little crank, turning round
      local a = frames * 0.18
      gfx.drawCircleAtPoint(ix, iy, 7)
      gfx.setLineWidth(3)
      gfx.drawLine(ix, iy, math.floor(ix + math.cos(a) * 11), math.floor(iy + math.sin(a) * 11))
      gfx.setLineWidth(1)
      gfx.fillCircleAtPoint(math.floor(ix + math.cos(a) * 12), math.floor(iy + math.sin(a) * 12), 3)
      gfx.fillCircleAtPoint(ix, iy, 2)
      drawT(label, bx + 40, by + 9, true)
    end
    crankHelpDraw()                                              -- (and the system's own crank picture, if the crank is tucked in)
  end
end

function CAFE.doorDraw()
  local dr = CAFE.door
  local art = CAFE.doorArt()
  if art then CAFE.doorDrawArt(art); return end
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 0, 400, 240)                          -- the wall either side
  gfx.setColor(BLACK)
  gfx.fillRect(92, 0, 216, 240)                         -- the door frame
  gfx.setColor(WHITE)
  gfx.fillRect(98, 0, 204, 240)                         -- the door
  gfx.setColor(BLACK)
  gfx.fillRect(98, 0, 204, 6)
  -- the window in the door: the same view as the one in the cafe, bigger
  gfx.fillRect(118, 14, 164, 82)
  gfx.setColor(WHITE)
  gfx.fillRect(122, 20, 156, 72)
  WIN.drawView(G.win, 122, 20, 3, true)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawLine(200, 20, 200, 92)
  gfx.drawLine(122, 56, 278, 56)
  gfx.setLineWidth(1)
  -- door panels, and the handle
  gfx.setLineWidth(2)
  gfx.drawRoundRect(114, 172, 76, 58, 4)
  gfx.drawRoundRect(210, 172, 76, 58, 4)
  gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(286, 150, 6)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(286, 150, 2)
  -- the sign hangs on the glass and flips over
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(200, 100, 3)
  gfx.drawLine(200, 100, 200, 108)
  local ease = dr.p * dr.p * (3 - 2 * dr.p)
  local ang = ease * math.pi
  local sx = math.abs(math.cos(ang))
  if sx < 0.05 then
    gfx.fillRect(199, 108, 3, 56)
  else
    local im = CAFE.signFace(ang >= math.pi / 2)
    im:drawScaled(math.floor(200 - 82 * sx), 108, sx, 1)
  end
  gfx.setColor(BLACK)
  if not dr.closing and dr.p < 0.5 and dr.done == 0 then       -- the reminder: spin the crank
    local label = UI.color and "Hold SPACE!" or "Press A or crank!"
    gfx.setFont(fontBold)
    local bw = gfx.getTextSize(label) + 58
    local bx, by = 200 - math.floor(bw / (2)), 188
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, 36, 10)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(bx, by, bw, 36, 10)
    gfx.setLineWidth(1)
    if UI.color then
      drawTC(label, 200, by + 9, true)
    else
      local ix, iy = bx + 22, by + 18                              -- a little crank, turning round
      local a = frames * 0.18
      gfx.drawCircleAtPoint(ix, iy, 7)
      gfx.setLineWidth(3)
      gfx.drawLine(ix, iy, math.floor(ix + math.cos(a) * 11), math.floor(iy + math.sin(a) * 11))
      gfx.setLineWidth(1)
      gfx.fillCircleAtPoint(math.floor(ix + math.cos(a) * 12), math.floor(iy + math.sin(a) * 12), 3)
      gfx.fillCircleAtPoint(ix, iy, 2)
      drawT(label, bx + 40, by + 9, true)
    end
    crankHelpDraw()                                              -- (and the system's own crank picture, if the crank is tucked in)
  end
end

-- ---- the table layout editor: pick a table up, then put it down on any empty square ------------------
function CAFE.tableAtSlot(d, i)                -- which of your tables stands on square i (or nil)
  for k = 1, math.min(d.seatStep, 4) do
    if d.tables[k] == i and not d.off[k] then return k end
  end
  return nil
end

function CAFE.layoutSpots(d)                    -- the squares shown while you move tables around
  local all = {}
  for i, f in ipairs(CAFE.TFREE) do all[i] = f end
  return all
end

function CAFE.tablesInHand(d)
  local n = 0
  for k = 1, math.min(d.seatStep, 4) do if d.off[k] then n = n + 1 end end
  return n
end

function CAFE.openLayout()
  local d = CAFE.cur
  for k = 1, math.min(d.seatStep, 4) do          -- (a table that was switched off is simply one in your hand)
    if d.off[k] then d.tables[k] = 0 end
  end
  CAFE.lay, CAFE.grab = d.tables[1] and d.tables[1] > 0 and d.tables[1] or 1, false
  transitionTo(function()
    G = CAFE.stageG()
    CAFE.mode = "layout"
  end)
end

function CAFE.layoutRefresh()                  -- the floor picture is drawn once, so redo it after a change
  local d = CAFE.cur
  CAFE.applyLayout(d)
  CAFE.fixTops(d)
  G.scn, G.tops = nil, nil
  G.seatOff, G.seatCount = CAFE.seatOffOf(d), CAFE.seatCountOf(d)
end

function CAFE.layoutUpdate(L, R, U, D, A_, B_)
  local d = CAFE.cur
  local n = math.min(d.seatStep, 4)
  if n < 1 then B_ = true end
  local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
  if dir then
    local all = CAFE.layoutSpots(d)
    local cur = 1
    for i, v in ipairs(all) do if v == CAFE.lay then cur = i end end
    local nat = CAFE.spatial(CAFE.spotPts("table", all), cur, dir)
    if all[nat] ~= CAFE.lay then CAFE.lay = all[nat]; sfxClick() end
  elseif A_ then
    local k = CAFE.tableAtSlot(d, CAFE.lay)
    if k then                                   -- a table: it goes into your hand
      d.tables[k] = 0; d.off[k] = true
      CAFE.layoutRefresh(); sfxClick()
    else                                        -- an empty square: put a table from your hand down
      local hk
      for j = 1, n do if d.off[j] then hk = j; break end end
      if hk then
        d.tables[hk] = CAFE.lay; d.off[hk] = nil
        CAFE.layoutRefresh(); sfxPlay("tip", false, 1.0)
      else
        sfxWrong(); CAFE.say("No tables in your hand. Pick one up first.")
      end
    end
  elseif B_ then
    CAFE.write()
    transitionTo(function()
      G = nil
      CAFE.mode = "shop"
      CAFE.rc = nil
    end)
  end
end

function CAFE.layoutDraw()
  local d = CAFE.cur
  CAFE.sceneTop()
  CAFE.sceneBottom()
  UI.drawDoor()
  for _, i in ipairs(CAFE.layoutSpots(d)) do
    local x, y, w, h = CAFE.spotRect("table", i)
    local sel = (i == CAFE.lay)
    if not CAFE.tableAtSlot(d, i) then            -- a clear box round every empty square
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, h, 5)
      gfx.setColor(BLACK)
      gfx.setLineWidth(sel and 3 or 2)
      gfx.drawRoundRect(x, y, w, h, 5)
      gfx.setLineWidth(1)
      if CAFE.tablesInHand(d) > 0 then drawTC("+", x + math.floor(w / (2)), y + math.floor(h / (2)) - 8, true) end
    elseif sel then
      gfx.setColor(BLACK)
      gfx.setLineWidth(3)
      gfx.drawRoundRect(x - 2, y - 2, w + 4, h + 4, 6)
      gfx.setLineWidth(1)
    end
  end
  local x, y, w, h = CAFE.spotRect("table", CAFE.lay)
  CAFE.pointer(x + math.floor(w / (2)) + 4, y + math.floor(h / (2)) - 2)         -- the mouse arrow rests on the chosen square
  gfx.setColor(WHITE)
  local label = "Tables in hand: " .. CAFE.tablesInHand(d)
  gfx.setFont(fontBold)
  local bw = gfx.getTextSize(label) + 28                       -- the bubble hugs the words
  gfx.fillRoundRect(200 - math.floor(bw / (2)), 100, bw, 24, 6)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(200 - math.floor(bw / (2)), 100, bw, 24, 6)
  drawTC(label, 200, 104, true)
  if CAFE.msg then
    local ml = CAFE.fitLines(CAFE.msg, 324, true, 3)
    local mh = 6 + 16 * #ml
    gfx.setColor(WHITE)
    gfx.fillRoundRect(30, 130, 340, mh, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(30, 130, 340, mh, 6)
    for li = 1, #ml do drawTC(ml[li], 200, 133 + (li - 1) * 16, true) end
  end
end

-- ---- owning more than one: floor and table-top decor can be bought again (as many as you like) ----------------------
-- A second copy is its own item called "<id>#2" (and so on): it has its own spot and its own on / off, and draws like the first.
function CAFE.copyCount(d, id)                 -- how many copies of this piece you own (they are numbered one after the other, so no limit)
  local n = 0
  while d.decor[CAFE.copyId(id, n + 1)] ~= nil do n = n + 1 end
  return n
end
function CAFE.copyId(id, k) return (k == 1) and id or (id .. "#" .. k) end
function CAFE.multiOK(it)                       -- floor and table-top pieces only (no pets or pet things, music, clothes, cloths, rugs, window or wall decor)
  return it ~= nil and not it.copyOf and (it.kind == "floor" or it.kind == "counter") and not it.needs and not it.pettab and not it.species
end
function CAFE.ensureCopy(id, k)                 -- make the item for copy k (it only exists once someone owns it)
  local cid = CAFE.copyId(id, k)
  if CAFE.byId[cid] then return cid end
  local base = CAFE.byId[id]
  local it = {}
  for key, v in pairs(base) do it[key] = v end
  it.id, it.copyOf = cid, id
  CAFE.ITEMS[#CAFE.ITEMS + 1] = it
  CAFE.byId[cid] = it
  CAFE.art[cid] = function(...) return CAFE.art[id](...) end
  CAFE.ANIM[cid], CAFE.ADX[cid], CAFE.AEXT[cid] = CAFE.ANIM[id], CAFE.ADX[id], CAFE.AEXT[id]
  return cid
end
function CAFE.ensureCopies(d)                   -- a saved cafe: bring back the copies it owns
  for key in pairs(d.decor) do
    local base, k = string.match(key, "^(.-)#(%d+)$")
    if base and CAFE.byId[base] then CAFE.ensureCopy(base, tonumber(k)) end
  end
end
function CAFE.countOf(d, id)                    -- how many you own, how many are out in the cafe, how many are in your hand
  local tot, placed = 0, 0
  for k = 1, CAFE.copyCount(d, id) do
    local st = d.decor[CAFE.copyId(id, k)]
    if st ~= nil then tot = tot + 1; if st == "on" then placed = placed + 1 end end
  end
  return { tot = tot, placed = placed, hand = tot - placed }
end
function CAFE.nextCopy(d, id)                   -- the first copy number you don't own yet
  return CAFE.ensureCopy(id, CAFE.copyCount(d, id) + 1)
end
function CAFE.toggleTarget(d, id)               -- tapping A on an owned row: put one out of your hand, or when none are, pick the last one up
  if not CAFE.multiOK(CAFE.byId[id]) then return id end
  local lastOn
  for k = 1, CAFE.copyCount(d, id) do
    local cid = CAFE.copyId(id, k)
    local st = d.decor[cid]
    if st == "off" then return CAFE.ensureCopy(id, k) end
    if st == "on" then lastOn = cid end
  end
  return lastOn or id
end

-- The decor editor (hold A on an owned piece in the shop): the cafe with every spot this piece can use; put one down or pick one up.
function CAFE.openEdit(id)
  local d = CAFE.cur
  CAFE.edit = { id = id, slot = nil }
  CAFE.hold = nil
  transitionTo(function()
    G = CAFE.stageG()
    CAFE.mode = "edit"
  end)
end
function CAFE.editSpots()                       -- every spot this piece could stand on: where its copies are now, plus the free ones
  local d, id = CAFE.cur, CAFE.edit.id
  local it = CAFE.byId[id]
  local mine, list = {}, {}
  for k = 1, CAFE.copyCount(d, id) do
    local cid = CAFE.copyId(id, k)
    if d.decor[cid] == "on" and d.place[cid] then mine[d.place[cid]] = cid; list[#list + 1] = d.place[cid] end
  end
  for _, sl in ipairs(CAFE.freeSlots(d, it.kind, id)) do list[#list + 1] = sl end
  return list, mine
end
function CAFE.editRefresh()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  CAFE.fixTops(d)
  G.scn, G.own, G.winOv, G.vineImgs, G.tops = nil, nil, nil, nil, nil
  for key in pairs(G) do
    if type(key) == "string" and (key:find("Img$") or key:find("^vine")) then G[key] = nil end
  end
end
function CAFE.editUpdate(L, R, U, D, A_, B_)
  local d, e = CAFE.cur, CAFE.edit
  local it = CAFE.byId[e.id]
  local list, mine = CAFE.editSpots()
  local have = false
  for _, sl in ipairs(list) do if sl == e.slot then have = true end end
  if not have then e.slot = list[1] end
  local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
  if dir and #list > 0 then
    local cur = 1
    for i, v in ipairs(list) do if v == e.slot then cur = i end end
    local nat = CAFE.spatial(CAFE.spotPts(it.kind, list), cur, dir)
    if list[nat] ~= e.slot then e.slot = list[nat]; sfxClick() end
  elseif A_ and e.slot then
    local cid = mine[e.slot]
    if cid then                                              -- one of yours is here: it goes into your hand
      d.decor[cid] = "off"; d.place[cid] = nil
      CAFE.editRefresh(); sfxClick()
    else
      local c = CAFE.countOf(d, e.id)
      if c.hand > 0 then                                     -- a free spot: put one from your hand down
        for k = 1, CAFE.copyCount(d, e.id) do
          local hid = CAFE.copyId(e.id, k)
          if d.decor[hid] == "off" then d.decor[hid] = "on"; d.place[hid] = e.slot; break end
        end
        CAFE.editRefresh(); sfxPlay("tip", false, 1.0)
      else
        sfxWrong(); CAFE.say("None in your hand. Pick one up first.")
      end
    end
  elseif B_ then
    CAFE.write()
    transitionTo(function()
      G = nil
      CAFE.edit = nil
      CAFE.mode = "shop"
      CAFE.rc = nil
    end)
  end
end
function CAFE.editDraw()
  local d, e = CAFE.cur, CAFE.edit
  local it = CAFE.byId[e.id]
  CAFE.sceneTop()
  CAFE.sceneBottom()
  UI.drawDoor()
  local list, mine = CAFE.editSpots()
  local c = CAFE.countOf(d, e.id)
  for _, sl in ipairs(list) do
    local x, y, w, h = CAFE.spotRect(it.kind, sl)
    local sel = (sl == e.slot)
    if mine[sl] then                                         -- one of yours: a heavy outline on the selected one
      if sel then
        gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(x - 2, y - 2, w + 4, h + 4, 6); gfx.setLineWidth(1)
      end
    elseif sel then                                          -- a free spot: a preview of the piece standing there
      gfx.setColor(WHITE); gfx.fillRoundRect(x, y, w, h, 4)
      gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(x, y, w, h, 4); gfx.setLineWidth(1)
      if c.hand > 0 then CAFE.art[e.id](x + math.floor(w / (2)) + ((it.kind == "counter" and sl <= 10) and (CAFE.ADX[e.id] or 0) or 0), y + math.floor(h / (2))) end
    else                                                     -- the rest: dotted boxes
      gfx.setColor(WHITE)
      for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
      for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
      gfx.setColor(BLACK)
      for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
      for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
    end
  end
  if e.slot then
    local x, y, w, h = CAFE.spotRect(it.kind, e.slot)
    CAFE.pointer(x + math.floor(w / (2)) + 4, y + math.floor(h / (2)) - 2)
  end
  -- one neat plate at the top: the name, how many are in your hand, and what the buttons do
  gfx.setFont(fontBold)
  local top = it.name .. "   In hand: " .. c.hand
  local mid = (e.slot and mine[e.slot]) and "A: pick it up" or (c.hand > 0 and "A: put one here" or "None in hand")
  local sub = mid .. "     B: back"
  local pw = math.max(gfx.getTextSize(top), gfx.getTextSize(sub)) + 30
  pw = math.min(pw, 360)
  gfx.setColor(WHITE); gfx.fillRoundRect(200 - math.floor(pw / (2)), 3, pw, 38, 7)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(200 - math.floor(pw / (2)), 3, pw, 38, 7); gfx.setLineWidth(1)
  drawTC(CAFE.fitOne(top, pw - 16, true), 200, 6, true)
  drawTC(CAFE.fitOne(sub, pw - 16, false), 200, 24)
  if CAFE.msg then
    local ml = CAFE.fitLines(CAFE.msg, 324, true, 2)
    local mh = 6 + 16 * #ml
    gfx.setColor(WHITE); gfx.fillRoundRect(30, 130, 340, mh, 6)
    gfx.setColor(BLACK); gfx.drawRoundRect(30, 130, 340, mh, 6)
    for li = 1, #ml do drawTC(ml[li], 200, 133 + (li - 1) * 16, true) end
  end
end

-- ---- screens -------------------------------------------------------------------------------------------
function CAFE.update(dt)
  do                                           -- the tab strip slides to the chosen tab (the short way round)
    local n = #CAFE.TABS
    local dl = (CAFE.tab - CAFE.tabPos + n / 2) % n - n / 2
    if math.abs(dl) < 0.02 then CAFE.tabPos = CAFE.tab else CAFE.tabPos = (CAFE.tabPos + dl * math.min(1, dt * 12) - 1) % n + 1 end
  end
  if CAFE.msgT > 0 then CAFE.msgT = CAFE.msgT - dt; if CAFE.msgT <= 0 then CAFE.msg = nil end end
  local A_, B_ = pd.buttonJustPressed(pd.kButtonA), pd.buttonJustPressed(pd.kButtonB)
  local U, D = pd.buttonJustPressed(pd.kButtonUp), pd.buttonJustPressed(pd.kButtonDown)
  local L, R = pd.buttonJustPressed(pd.kButtonLeft), pd.buttonJustPressed(pd.kButtonRight)
  if CAFE.mode == "slots" then
    if CAFE.erase then
      if L or R then CAFE.eraseSel = 3 - (CAFE.eraseSel or 2); sfxClick()           -- 1 = delete, 2 = cancel
      elseif A_ then
        if CAFE.eraseSel == 1 then
          CAFE.pre = nil
          pcall(pd.datastore.delete, "cafe" .. CAFE.erase)
          CAFE.slots[CAFE.erase] = nil
        end
        CAFE.erase = nil
        sfxClick()
      elseif B_ then CAFE.erase = nil; sfxClick() end
      return
    end
    if D then CAFE.sel = CAFE.sel % 3 + 1; sfxClick()
    elseif U then CAFE.sel = (CAFE.sel + 1) % 3 + 1; sfxClick()
    elseif R and CAFE.slots[CAFE.sel] then CAFE.erase = CAFE.sel; CAFE.eraseSel = 2; sfxClick()      -- (it starts on Cancel, to be safe)
    elseif B_ then CAFE.goTitle()
    elseif A_ then
      sfxClick()
      local i = CAFE.sel
      CAFE.slot = i
      if CAFE.slots[i] then
        CAFE.cur = CAFE.slots[i]
        CAFE.openDoor()
      else
        UI.fast(function() CAFE.mode, CAFE.name, CAFE.letter, CAFE.onDone = "name", "", 0, false; UI.bgSet("name") end)
      end
    end
  elseif CAFE.mode == "char" then
    if L then CAFE.charSel = (CAFE.charSel + 1) % 3 + 1; sfxClick()
    elseif R then CAFE.charSel = CAFE.charSel % 3 + 1; sfxClick()
    elseif B_ then
      sfxClick()
      UI.fast(function() CAFE.mode, CAFE.onDone = "name", false; UI.bgSet("name") end)
    elseif A_ then
      CAFE.cur = CAFE.fresh(CAFE.pendName)
      CAFE.cur.char = CAFE.charSel
      CAFE.write()
      CAFE.openDoor()
    end
  elseif CAFE.mode == "name" then
    if CAFE.onDone then
      if L or U or B_ then CAFE.onDone = false; sfxClick()
      elseif A_ then
        local nm = CAFE.name:gsub("%s+$", "")
        if #nm >= 1 then
          CAFE.pendName, CAFE.charSel = nm, 1               -- next: pick who's behind the counter
          UI.fast(function() CAFE.mode = "char"; UI.bgSet("char") end)
        else
          sfxWrong()
          CAFE.onDone = false
        end
      end
      return
    end
    CAFE.crank = CAFE.crank + pd.getCrankChange()
    local step = 0                                         -- only the crank turns the wheel: A-Z, then the word CAFE, then a space
    while CAFE.crank >= 24 do CAFE.crank = CAFE.crank - 24; step = step + 1 end
    while CAFE.crank <= -24 do CAFE.crank = CAFE.crank + 24; step = step - 1 end
    if L then step = step - 1 elseif R then step = step + 1 end         -- left / right turn the wheel too, if you'd rather not crank
    if step ~= 0 then CAFE.letter = (CAFE.letter + step) % 28; sfxClick() end
    if D then
      CAFE.onDone = true                                   -- down: on to the DONE button below
      sfxClick()
    elseif A_ then
      local nm = CAFE.name
      if CAFE.letter == 26 then                            -- the word
        local add = (#nm > 0 and string.sub(nm, -1) ~= " ") and " CAFE" or "CAFE"
        if #nm + #add <= CAFE.NAME_MAX then CAFE.name = nm .. add; sfxClick() else sfxWrong() end
      elseif #nm < CAFE.NAME_MAX then
        local ch = (CAFE.letter == 27) and " " or string.char(65 + CAFE.letter)
        if not (ch == " " and #nm == 0) then CAFE.name = nm .. ch; sfxClick() else sfxWrong() end
      else
        sfxWrong()
      end
    elseif B_ then
      if #CAFE.name > 0 then
        CAFE.name = CAFE.name:sub(1, -2)
        sfxClick()
      else
        sfxClick()
        UI.fast(function() CAFE.mode = "slots"; UI.bgSet("slots") end)
      end
    end
  elseif CAFE.mode == "door" then
    if CAFE.gift and not CAFE.door.closing then UI.giftUpdate(dt) else CAFE.doorUpdate(dt, B_) end
  elseif CAFE.mode == "layout" then
    CAFE.layoutUpdate(L, R, U, D, A_, B_)
  elseif CAFE.mode == "edit" then
    CAFE.editUpdate(L, R, U, D, A_, B_)
  elseif CAFE.mode == "place" then
    local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
    if dir then
      local kind = (CAFE.byId[CAFE.pend] or { kind = "table" }).kind
      local nsel = CAFE.spatial(CAFE.spotPts(kind, CAFE.spots), CAFE.spotSel, dir)
      if nsel ~= CAFE.spotSel then CAFE.spotSel = nsel; sfxClick() end
    elseif A_ then CAFE.leavePlace(true)
    elseif B_ then CAFE.leavePlace(false) end
  else   -- shop
    if CAFE.note then                                 -- a little message box: A or B closes it
      if A_ or B_ then CAFE.note = nil; sfxClick() end
      return
    end
    if CAFE.ask then UI.askUpdate(); return end
    local rows = CAFE.rows()
    local n = #rows
    -- the crank scrolls too: every 70 degrees is one step
    CAFE.crankAcc = CAFE.crankAcc + pd.getCrankChange()
    local step = 0
    if CAFE.crankAcc >= 70 then CAFE.crankAcc = CAFE.crankAcc - 70; step = 1
    elseif CAFE.crankAcc <= -70 then CAFE.crankAcc = CAFE.crankAcc + 70; step = -1 end
    if D then step = 1 elseif U then step = -1 end
    local function click() if frames - (CAFE.lastClick or -9) >= 3 then CAFE.lastClick = frames; sfxClick() end end
    local function turn(t)                                              -- switch tabs; the pointer goes back up to them
      CAFE.tab = t; CAFE.shopSel, CAFE.scroll, CAFE.focus = 1, 0, "tabs"
      CAFE.rc = nil
      click()
    end
    if CAFE.hold then                                                   -- A is down on an owned piece: held a moment opens the editor, let go before that is a tap
      local hr = CAFE.hold.row
      if U or D or L or R or B_ or CAFE.focus ~= "list" or rows[CAFE.shopSel] ~= hr then CAFE.hold = nil
      elseif pd.buttonIsPressed(pd.kButtonA) then
        if frames - CAFE.hold.t >= 14 then CAFE.hold = nil; sfxClick(); CAFE.openEdit(hr[5]); return end
      else CAFE.hold = nil; CAFE.toggle(hr) end
    end
    if B_ then                                                          -- B hops between the list and the Back to cafe button
      CAFE.focus = (CAFE.focus == "back" or CAFE.focus == "quit") and "list" or "back"
      if CAFE.focus == "list" then CAFE.shopSel = math.max(1, math.min(CAFE.shopSel, n)) end
      sfxClick()
    elseif CAFE.focus == "tabs" or CAFE.focus == "list" then
      if L then turn((CAFE.tab - 2) % #CAFE.TABS + 1)                   -- the tabs wrap around
      elseif R then turn(CAFE.tab % #CAFE.TABS + 1)
      elseif CAFE.focus == "tabs" then
        if step == 1 then CAFE.focus, CAFE.shopSel = "list", 1; click() end
      else
        if step == 1 then
          if CAFE.shopSel < n then CAFE.shopSel = CAFE.shopSel + 1; click() end     -- (only B takes you down to the buttons)
        elseif step == -1 then
          if CAFE.shopSel > 1 then CAFE.shopSel = CAFE.shopSel - 1; click()
          else CAFE.focus = "tabs"; click() end                         -- back up to the tabs
        elseif A_ then
          local row = rows[CAFE.shopSel]
          local k = row[3]
          if k == "toggle" and row.multi then CAFE.hold = { t = frames, row = row }       -- (tap = put out / pick up, hold = edit; decided on release)
          elseif k == "cup" or k == "seat" or k == "buy" or k == "more" then CAFE.buy(row)
          elseif k == "bow" then CAFE.cur.nobow = (CAFE.cur.nobow ~= true) or nil; sfxClick(); CAFE.write()
          elseif k == "toggle" or k == "sign" then CAFE.toggle(row)
          elseif k == "layout" then CAFE.openLayout()
          elseif k == "prestige" then CAFE.ask = { sel = 2 }; sfxClick()      -- (it asks first, on "Not yet")
          else sfxWrong() end
        end
      end
    else                                                                -- the two buttons in the bottom bar
      if step == -1 then CAFE.focus = "list"; CAFE.shopSel = math.max(1, n); click()
      elseif L and CAFE.focus == "quit" then CAFE.focus = "back"; sfxClick()
      elseif R and CAFE.focus == "back" then CAFE.focus = "quit"; sfxClick()
      elseif A_ then
        CAFE.write()
        if CAFE.focus == "back" then sfxClick(); CAFE.begin()
        else CAFE.closeDoor() end
      end
    end
    -- keep the highlighted row in view (7 rows fit)
    if CAFE.shopSel <= CAFE.scroll then CAFE.scroll = CAFE.shopSel - 1 end
    if CAFE.shopSel > CAFE.scroll + CAFE.visRows() then CAFE.scroll = CAFE.shopSel - CAFE.visRows() end
    if CAFE.scroll < 0 then CAFE.scroll = 0 end
  end
end

function CAFE.band(title)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(title, 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

-- a little box showing the highlighted item, inside a wobbly animated border
function CAFE.wobbleBox(bx, by, bw, bh)            -- a round-cornered box edge drawn as slowly moving squiggly lines
  local t = frames * 0.18
  local r = 12
  local sw, sh, al = bw - 2 * r, bh - 2 * r, math.pi * r / 2
  local per = 2 * sw + 2 * sh + 4 * al
  local n = 80
  local fx, fy, lx, ly
  gfx.setLineWidth(2)
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < sw then x, y, nx, ny = bx + r + d, by, 0, -1
    elseif d < sw + al then
      local a = -math.pi / 2 + (d - sw) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + bw - r + r * nx, by + r + r * ny
    elseif d < sw + al + sh then x, y, nx, ny = bx + bw, by + r + (d - sw - al), 1, 0
    elseif d < sw + 2 * al + sh then
      local a = (d - sw - al - sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + bw - r + r * nx, by + bh - r + r * ny
    elseif d < 2 * sw + 2 * al + sh then x, y, nx, ny = bx + bw - r - (d - sw - 2 * al - sh), by + bh, 0, 1
    elseif d < 2 * sw + 3 * al + sh then
      local a = math.pi / 2 + (d - 2 * sw - 2 * al - sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + r + r * nx, by + bh - r + r * ny
    elseif d < 2 * sw + 3 * al + 2 * sh then x, y, nx, ny = bx, by + bh - r - (d - 2 * sw - 3 * al - sh), -1, 0
    else
      local a = math.pi + (d - 2 * sw - 3 * al - 2 * sh) / r
      nx, ny = math.cos(a), math.sin(a); x, y = bx + r + r * nx, by + r + r * ny
    end
    local o = math.sin(i * 1.1 + t) * 1.6
    local px, py = x + nx * o, y + ny * o
    if lx then gfx.drawLine(lx, ly, px, py) else fx, fy = px, py end
    lx, ly = px, py
  end
  gfx.drawLine(lx, ly, fx, fy)
  gfx.setLineWidth(1)
end

function CAFE.pointer(mx, my)
  if PC and PC.mouseOn then return end                  -- a little mouse arrow, bobbing
  mx = math.floor(mx) + math.floor(math.sin(frames * 0.15) * 2 + 0.5)
  my = math.floor(my) + math.floor(math.sin(frames * 0.15 + 1) * 1.5 + 0.5)
  gfx.setColor(WHITE)
  gfx.fillPolygon(mx, my, mx, my + 13, mx + 3, my + 10, mx + 6, my + 15, mx + 8, my + 14, mx + 5, my + 9, mx + 9, my + 9)
  gfx.setColor(BLACK)
  gfx.drawLine(mx, my, mx, my + 13); gfx.drawLine(mx, my + 13, mx + 3, my + 10)
  gfx.drawLine(mx + 3, my + 10, mx + 6, my + 15); gfx.drawLine(mx + 6, my + 15, mx + 8, my + 14)
  gfx.drawLine(mx + 8, my + 14, mx + 5, my + 9); gfx.drawLine(mx + 5, my + 9, mx + 9, my + 9)
  gfx.drawLine(mx + 9, my + 9, mx, my)
end

-- where each kind of thing can go, as a word in a little bubble on the shop's picture
CAFE.RUGWHERE = { runner = "Register rug", orug = "Table section rug", rug = "Cafe pickup rug" }     -- (flashed under the rugs' previews)
CAFE.WHERE = { floor = "Floor", counter = "Table", cloth = "Table", wall = "Wall", tiny = "Wall", frame = "Window", curtain = "Window",
               shelf = "Shelf", ceiling = "Ceiling", rug = "Floor", orug = "Floor", runner = "Floor" }
CAFE.bubM = {}
function CAFE.bubbleMeasure(word)                  -- where the real letters sit inside the text box (measured from the drawn pixels, once per word)
  local m = CAFE.bubM[word]
  if m then return m end
  gfx.setFont(fontBold)
  local tw, th = gfx.getTextSize(word)
  m = { w = tw, dx = tw / 2, dy = th / 2 }       -- (what to use if the pixels can't be read: the middle of the text box)
  local function scan(str)                       -- the box the real letters fill, from the drawn pixels
    local sw, sh = gfx.getTextSize(str)
    local im = gfx.image.new(sw + 8, sh + 8, gfx.kColorClear)
    gfx.pushContext(im)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    gfx.setFont(fontBold)
    gfx.drawText(str, 4, 4)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.popContext()
    local x0, x1, y0, y1 = 9999, -1, 9999, -1
    for y = 0, sh + 7 do
      for x = 0, sw + 7 do
        if im:sample(x, y) ~= gfx.kColorClear then
          if x < x0 then x0 = x end
          if x > x1 then x1 = x end
          if y < y0 then y0 = y end
          if y > y1 then y1 = y end
        end
      end
    end
    return x0, x1, y0, y1
  end
  local ok = pcall(function()
    local x0, x1, y0, y1 = scan(word)
    if x1 >= x0 and y1 >= y0 then
      m.w = x1 - x0 + 1
      m.dx = (x0 + x1 + 1) / 2 - 4              -- the middle of the letters, measured from where the text was drawn
      m.dy = (y0 + y1 + 1) / 2 - 4
    end
    -- the tails of g, j, p, q and y hang below the line and would drag the middle down ("Ceiling" sat too high),
    -- so the up-and-down middle is taken from the same word with those letters swapped for round ones
    local flat = word:gsub("[gjpqy]", "o")
    if flat ~= word then
      local _, _, fy0, fy1 = scan(flat)
      if fy1 >= fy0 then m.dy = (fy0 + fy1 + 1) / 2 - 4 end
    end
  end)
  CAFE.bubM[word] = m
  return m
end

function CAFE.whereBubble(word, cx, mid)             -- a round black bubble with bold white words, centred on x = cx and on the line y = mid
  local m = CAFE.bubbleMeasure(word)
  local w, h = math.max(46, m.w + 18), 17
  local x, top = cx - math.floor(w / (2)), mid - 8
  gfx.setColor(WHITE)                                            -- a white rim so it stands out from dark pictures too
  gfx.fillRoundRect(x - 1, top - 1, w + 2, h + 2, 9)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x, top, w, h, 8)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  gfx.setFont(fontBold)
  gfx.drawText(word, math.floor(cx - m.dx + 0.5), math.floor(top + h / 2 - m.dy + 0.5))      -- (the letters' own middle lands on the bubble's middle)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

CAFE.MOREDESC = { hmus = { "Changes the weather", "Adds Pumpkin Spice" },          -- (more lines the card cycles through)
                  xmus = { "Changes the weather", "Adds Hot Cocoa" } }
function CAFE.drawPreview(row)
  if row == nil or row[3] == "start" or row[3] == "quit" or (row[3] == "none" and not row.pv) then return end
  local id = row[5]
  if row[3] == "seat" or row.pv == "table" then id = (row[3] == "seat" and CAFE.cur and CAFE.cur.seatStep == 4) and "booth" or "table" end
  local art = id and CAFE.art[id]
  local bx, by, bw, bh = 298, 68, 92, 70
  local plate = UI.shopBgImg()
  if not plate then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, bh, 8)
  end
  gfx.setColor(BLACK)
  -- squiggly border: points on the rectangle edge pushed in/out by a moving sine
  local t = frames * 0.25
  local per = 2 * (bw + bh)
  local n = 40
  local qx, qy = {}, {}
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < bw then x, y, nx, ny = bx + d, by, 0, -1
    elseif d < bw + bh then x, y, nx, ny = bx + bw, by + (d - bw), 1, 0
    elseif d < 2 * bw + bh then x, y, nx, ny = bx + bw - (d - bw - bh), by + bh, 0, 1
    else x, y, nx, ny = bx, by + bh - (d - 2 * bw - bh), -1, 0 end
    local o = math.sin(i * 1.3 + t) * 1.8
    qx[i], qy[i] = x + nx * o, y + ny * o
  end
  if plate then                                  -- on the dark page the white card IS the squiggle (no straight white box showing behind it)
    local pts = {}
    for i = 0, n - 1 do pts[#pts + 1] = math.floor(qx[i] + 0.5); pts[#pts + 1] = math.floor(qy[i] + 0.5) end
    gfx.setColor(WHITE)
    gfx.fillPolygon(table.unpack(pts))
    gfx.setColor(BLACK)
  end
  gfx.setLineWidth(2)
  for i = 1, n do gfx.drawLine(qx[i - 1], qy[i - 1], qx[i], qy[i]) end
  gfx.drawLine(qx[n], qy[n], qx[0], qy[0])
  gfx.setLineWidth(1)
  gfx.setClipRect(bx + 4, by + 4, bw - 8, bh - 8)
  local cx, cy = bx + math.floor(bw / (2)), by + math.floor(bh / (2)) + 2
  local it = id and CAFE.byId[id]
  local function drawAs(fn, ox, oy)             -- run a "draw what's owned" routine as if only this id were on
    local save, saveG = CAFE.decorOn, G
    CAFE.decorOn = function(q) return q == id end
    G = { mode = "cafe", cafe = { decor = { [id] = "on" } } }
    gfx.setDrawOffset(ox, oy)
    pcall(fn)
    gfx.setDrawOffset(0, 0)
    G = saveG
    CAFE.decorOn = save
  end
  if it and it.kind == "runner" then
    local h = bh - 22                            -- shrunk to fit the box, whole
    local w = math.floor(h * 36 / 118 + 0.5)
    CAFE.runnerAt(id, cx - math.floor(w / (2)), by + 12, w, h)              -- (a little lower, clear of the top edge)
  elseif it and it.kind == "orug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 76 / 162 + 0.5)
    CAFE.ovalAt(id, cx - math.floor(w / (2)), by + 10 + math.floor((bh - 22 - h) / (2)), w, h)
  elseif it and it.kind == "rug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 44 / 190 + 0.5) + 4
    CAFE.rugAt(id, cx - math.floor(w / (2)), by + 10 + math.floor((bh - 22 - h) / (2)), w, h)
  elseif it and it.kind == "shelf" then
    local n = #CAFE.VINES[id]                    -- hanging from a bit of shelf, drawn small and blown up
    CAFE.vinePrev = CAFE.vinePrev or gfx.image.new(42, 30, gfx.kColorClear)
    CAFE.vinePrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.vinePrev)
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 42, 3)
    CAFE.vineDraw(id, 21 - (n - 1) * 2, 3, (math.floor(frames / (4))) % 16)
    gfx.popContext()
    gfx.setClipRect(bx + 1, by + 1, bw - 2, bh - 2)
    CAFE.vinePrev:drawScaled(cx - 42, by + 8, 2, 2)
  elseif it and it.kind == "ceiling" then
    gfx.setColor(BLACK)                          -- (the real lights are white on the dark wall: here it's black on the white card)
    local nb, gap, x0 = 4, 22, bx + 14
    if id == "fairylights" then nb, gap, x0 = 6, 15, bx + 9 end
    local wy0 = by + 24
    local px0, py0
    for x = bx + 4, bx + bw - 4, 3 do
      local y = wy0 + math.floor(4 * math.sin(math.pi * ((x - bx) % 30) / 30) + 0.5)
      if px0 then gfx.drawLine(px0, py0, x, y) end
      px0, py0 = x, y
    end
    local ph = (math.floor(frames / (CAFE.LSTY[id][2]))) % CAFE.LSTY[id][1]
    for i = 0, nb - 1 do
      local x = x0 + i * gap
      local wy = wy0 + math.floor(4 * math.sin(math.pi * ((x - bx) % 30) / 30) + 0.5)
      CAFE.lightBulb(id, x, wy, CAFE.lightLit(id, i, ph), 1.5, true)
    end
  elseif it and it.kind == "cloth" then
    CAFE.tableAt(cx, cy, 22, id)
  elseif it and it.species then                   -- pets: drawn small, then blown up so you can see the coat
    CAFE.petPrev = CAFE.petPrev or {}
    local im = CAFE.petPrev[id]
    if im == nil then im = gfx.image.new(50, 36, gfx.kColorClear); CAFE.petPrev[id] = im end
    im:clear(gfx.kColorClear)
    gfx.pushContext(im)
    CAFE.pet(it.species, 25, 32, 1, "sit", id)
    gfx.popContext()
    gfx.setClipRect(bx + 1, by + 1, bw - 2, bh - 2)
    im:drawScaled(cx - 50, cy - 38, 2, 2)
  elseif row[3] == "prestige" then
    UI.drawPrestigePreview(cx, cy)
  elseif row[3] == "layout" then                  -- a cardboard package with the mouse arrow resting on it
    local x0, y0 = cx - 26, cy - 8                 -- front face
    local fw, fh, dx, dy = 44, 28, 12, 9           -- (front width/height, and how far the top leans back)
    gfx.setColor(WHITE)
    gfx.fillPolygon(x0, y0, x0 + dx, y0 - dy, x0 + fw + dx, y0 - dy, x0 + fw, y0)           -- top
    gfx.fillPolygon(x0 + fw, y0, x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy, x0 + fw, y0 + fh)   -- side
    gfx.fillRect(x0, y0, fw, fh)
    gfx.setPattern(CHECK)                          -- the side is shaded
    gfx.fillPolygon(x0 + fw, y0, x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy, x0 + fw, y0 + fh)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(x0, y0, fw, fh)
    gfx.drawLine(x0, y0, x0 + dx, y0 - dy); gfx.drawLine(x0 + dx, y0 - dy, x0 + fw + dx, y0 - dy)
    gfx.drawLine(x0 + fw, y0, x0 + fw + dx, y0 - dy)
    gfx.drawLine(x0 + fw + dx, y0 - dy, x0 + fw + dx, y0 + fh - dy); gfx.drawLine(x0 + fw, y0 + fh, x0 + fw + dx, y0 + fh - dy)
    gfx.setLineWidth(1)
    local mx = x0 + math.floor(fw / (2))                         -- packing tape down the middle of the lid and the front
    gfx.setPattern(CHECK)
    gfx.fillPolygon(mx - 4, y0, mx - 4 + dx, y0 - dy, mx + 4 + dx, y0 - dy, mx + 4, y0)
    gfx.fillRect(mx - 4, y0, 8, 11)
    gfx.setColor(BLACK)
    gfx.drawRect(mx - 4, y0, 8, 11)
    gfx.drawRect(x0 + 6, y0 + 16, 16, 8)            -- a little shipping label
    gfx.drawLine(x0 + 9, y0 + 19, x0 + 19, y0 + 19)
    gfx.drawLine(x0 + 9, y0 + 22, x0 + 15, y0 + 22)
    CAFE.pointer(x0 + fw - 12, y0 + 6)
  elseif row[3] == "bow" then                     -- the barista, with or without the bow
    CAFE.wearPrev = CAFE.wearPrev or gfx.image.new(40, 40, gfx.kColorClear)
    CAFE.wearPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wearPrev)
    UI.noBow = CAFE.cur.nobow == true
    drawPerson(20, 24, 12, false, 2)
    UI.noBow = false
    gfx.popContext()
    CAFE.wearPrev:drawScaled(cx - 40, by + 5, 2, 2)
  elseif row[3] == "sign" then                    -- the sign you actually have, name and all
    gfx.setClipRect(cx - 43, by + 4, 86, bh - 8)            -- (a little wider than the card's usual picture area, so 13 letters sit inside the sign)
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 43, cy - 14, 86, 28)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(cx - 43, cy - 14, 86, 28)
    gfx.setLineWidth(1)
    CAFE.fitText(CAFE.cafeName(), cx, cy, 66, 18, 79)
  elseif row[3] == "cup" or row.pv == "cup" then    -- a big steaming mug (also on the "MAX" cups row)
    UI.ink("mugc")
    gfx.setColor(BLACK)
    gfx.setLineWidth(3)
    gfx.drawCircleAtPoint(cx + 24, cy + 2, 8)
    gfx.setLineWidth(1)
    gfx.setColor(WHITE); gfx.fillRoundRect(cx - 20, cy - 12, 40, 32, 5)
    gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(cx - 20, cy - 12, 40, 32, 5); gfx.setLineWidth(1)
    UI.ink("none")
    gfx.setPattern(DRINK_PATTERN.coffee); gfx.fillRect(cx - 17, cy - 8, 34, 11); gfx.setColor(BLACK)
    UI.ink("gray")
    for i = -1, 1 do
      local px, py
      for yy = cy - 16, cy - 30, -2 do
        local xx = cx + i * 9 + math.floor(math.sin(frames * 0.2 + yy * 0.5 + i * 2) * 3 + 0.5)
        if px then gfx.drawLine(px, py, xx, yy) end
        px, py = xx, yy
      end
    end
    UI.ink("mugc")
    gfx.fillRect(cx - 26, cy + 22, 52, 3)
    UI.ink("none")
  elseif it and (it.kind == "wall" or it.kind == "tiny") and art then      -- wall decor: blown up so you can see it
    CAFE.wallPrev = CAFE.wallPrev or gfx.image.new(70, 50, gfx.kColorClear)
    CAFE.wallPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wallPrev)
    art(35, 25)
    gfx.popContext()
    CAFE.wallPrev:drawScaled(cx - 70, cy - 50, 2, 2)
  elseif it and (it.kind == "hat" or it.kind == "glasses") then          -- clothes: the barista wearing it, blown up
    CAFE.wearPrev = CAFE.wearPrev or gfx.image.new(40, 40, gfx.kColorClear)
    CAFE.wearPrev:clear(gfx.kColorClear)
    gfx.pushContext(CAFE.wearPrev)
    local blook = UI.BARISTA[CAFE.cur.char or 1] or 5
    UI.glasses = (it.kind == "glasses")
    UI.noBow = (it.kind == "hat") or CAFE.cur.nobow == true
    drawPerson(20, 24, blook, false, 2)
    UI.glasses = false; UI.noBow = false
    if it.kind == "glasses" then CAFE.WEAR[id](20, 24 + UI.eyeRow(blook, true)) else CAFE.drawHat(id, 20, 24, blook) end
    gfx.popContext()
    CAFE.wearPrev:drawScaled(cx - 40, by + 5, 2, 2)
  elseif art then
    art(cx, cy)
  else
    local label = (row[3] == "cup") and "CUPS" or (row[3] == "sign") and "SIGN" or ""
    gfx.setColor(BLACK)
    if label ~= "" then drawTC(label, cx, cy - 8, true) end
  end
  gfx.clearClipRect()
  local where = it and CAFE.WHERE[it.kind]
  if where then CAFE.whereBubble(where, cx, by) end     -- "Floor", "Wall", "Table"...: where this one can go (sits on the frame's top line)
  gfx.setColor(BLACK)
  if plate then gfx.setImageDrawMode(gfx.kDrawModeFillWhite) end   -- (white words on the black plate)
  local PW = plate and 84 or (bw + 12)                           -- widest line that fits the plate
  if row[2] ~= "" then drawTC(CAFE.fitOne(row[2], PW, true), bx + math.floor(bw / (2)), by + bh + 6, true) end   -- the price, always in view
  local sub = row[6]
  local rw = it and CAFE.RUGWHERE[it.kind]
  if sub and rw and (math.floor(frames / (50))) % 2 == 0 then sub = rw end       -- rugs: the words flash between where it goes and the usual line
  local more = sub and id and CAFE.MOREDESC[id]
  if more then                                                                   -- the music records: the usual line, then what else they do
    local ph = (math.floor(frames / (50))) % (#more + 1)
    if ph > 0 then sub = more[ph] end
  end
  local mu = row.multi
  local mlines = nil
  if mu then                                      -- something you can own more than one of: how many you have, and how to edit them
    local ph = (math.floor(frames / (50))) % (row.more and 2 or 3)
    local owned = "Owned: " .. mu.tot
    if ph == 0 then mlines = (mu.tot == 1) and { owned, (mu.hand == 1) and "in your hand" or "out in the cafe" } or { owned, mu.placed .. " out", mu.hand .. " in hand" }
    elseif ph == 1 and not row.more then mlines = { "Hold A", "to edit" } end
  end
  if sub or mlines then                           -- a few words under it, wrapped to the box
    local lines = mlines or CAFE.fitLines(sub, PW, false, 4)
    local pitch, y0 = 14, by + bh + 24
    if #lines > 3 then pitch, y0 = 12, by + bh + 20 end        -- a fourth line squeezes in by tightening the gaps
    for li = 1, #lines do drawTC(lines[li], bx + math.floor(bw / (2)), y0 + (li - 1) * pitch) end
  end
  if CAFE.hold and CAFE.hold.row == row and frames - CAFE.hold.t >= 3 then       -- A is held: a little bar fills up, and then the editor opens
    local f = math.min(1, (frames - CAFE.hold.t) / 14)
    local x0 = bx + math.floor(bw / (2)) - 36
    if not plate then gfx.setColor(BLACK) else gfx.setColor(WHITE) end
    gfx.fillRect(x0, 226, math.floor(72 * f), 4)
    gfx.drawRect(x0 - 1, 225, 74, 6)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)         -- (always back to normal, even when there was no description)
end

-- a little sticker plate with a few pieces of help in it, spaced evenly and centred as a group on the plate
function UI.hintPlate(parts, y)
  gfx.setFont(fontNormal)
  local widths, total = {}, 0
  for i, t in ipairs(parts) do widths[i] = gfx.getTextSize(t); total = total + widths[i] end
  local gap = 22
  local span = total + gap * (#parts - 1)
  local hw = math.min(span + 32, 372)
  UI.stickerBox(200 - math.floor(hw / (2)), y, hw, 22, false)
  local x = 200 - math.floor(span / (2))
  for i, t in ipairs(parts) do
    drawT(t, x, y + 3)
    x = x + widths[i] + gap
  end
  gfx.setColor(BLACK)
end

-- a white arrow with a black edge, pointing left (d = -1) or right (d = 1)
function UI.sideArrow(x, y, d, big)
  local w, h = big and 15 or 12, big and 15 or 12
  local tip, base = x + d * w, x
  gfx.setColor(BLACK)
  gfx.fillTriangle(tip + d * 2, y, base - d * 2, y - h - 2, base - d * 2, y + h + 2)
  gfx.setColor(WHITE)
  gfx.fillTriangle(tip, y, base, y - h, base, y + h)
  gfx.setColor(BLACK)
end

function UI.drawNameNew()                                  -- NAME YOUR CAFE, on the sunburst
  -- the name so far, on a white sticker
  UI.stickerBox(50, 54, 300, 38, false)
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(CAFE.name)
  local x0 = 200 - math.floor(w / (2))
  drawT(CAFE.name, x0, 62, true)
  if (math.floor(frames / (10))) % 2 == 0 and #CAFE.name < CAFE.NAME_MAX then gfx.setColor(BLACK); gfx.fillRect(x0 + w + 2, 77, 9, 3) end
  drawTR(#CAFE.name .. "/" .. CAFE.NAME_MAX, 340, 74)
  -- the letter wheel (A-Z, the word CAFE, a space), then DONE below it
  local lc = (CAFE.letter == 26) and "CAFE" or ((CAFE.letter == 27) and "space" or string.char(65 + CAFE.letter))
  local dialOn = not CAFE.onDone
  local nudge = dialOn and ((math.floor(frames / (6))) % 2) or 0         -- the arrows tick in and out while the wheel is chosen
  UI.stickerBox(150, 104, 100, 36, dialOn)
  drawTC(lc, 200, 114, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  UI.stickerBox(150, 152, 100, 30, CAFE.onDone)
  drawTC("DONE", 200, 159, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
  CAFE.pointer(232, CAFE.onDone and 164 or 118)
  UI.hintPlate(CAFE.onDone and { "A: next", "B: back to the letters" } or { "Crank: letter", "A: add", "B: delete" }, 202)
end

function UI.drawCharNew()                                  -- PICK YOUR BARISTA, on the sunburst
  CAFE.charImgs = CAFE.charImgs or {}
  for i = 1, 3 do
    local bx, by, bw, bh = 36 + (i - 1) * 116, 58, 100, 112
    local on = (CAFE.charSel == i)
    if on then                                             -- the chosen card: a white edge round a heavy black line
      gfx.setColor(WHITE); gfx.fillRoundRect(bx - 4, by - 4, bw + 8, bh + 8, 12)
      gfx.setColor(BLACK); gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 10)
      gfx.setColor(WHITE); gfx.fillRoundRect(bx + 2, by + 2, bw - 4, bh - 4, 7)
    else
      UI.stickerBox(bx, by, bw, bh, false)
    end
    local im = CAFE.charImgs[i]
    if im == nil then
      im = gfx.image.new(40, 40, gfx.kColorClear)
      gfx.pushContext(im)
      drawPerson(20, 14, UI.BARISTA[i], false, 2)
      gfx.popContext()
      CAFE.charImgs[i] = im
    end
    im:drawScaled(bx + 10, by + 12, 2.0)
    gfx.setColor(BLACK)
    if on then CAFE.pointer(bx + 70, by + 95) end
  end
  gfx.setColor(BLACK)
  UI.hintPlate({ "Left / Right: choose", "A: pick", "B: back" }, 202)
end

function CAFE.draw()
  if CAFE.mode == "door" then
    CAFE.doorDraw()
    if CAFE.gift and not CAFE.door.closing then UI.giftDraw() end
    return
  end
  if CAFE.mode == "layout" then CAFE.layoutDraw(); return end
  if CAFE.mode == "edit" then CAFE.editDraw(); return end
  if CAFE.mode == "place" then
    CAFE.sceneTop()
    CAFE.sceneBottom()
    UI.drawDoor()
    local it = CAFE.byId[CAFE.pend] or { kind = "table", name = "table" }
    for i, sp in ipairs(CAFE.spots) do
      local x, y, w, h = CAFE.spotRect(it.kind, i == CAFE.spotSel and sp or sp)
      x, y, w, h = CAFE.spotRect(it.kind, sp)
      if i == CAFE.spotSel then
        gfx.setColor(WHITE)
        gfx.fillRoundRect(x, y, w, h, 4)
        gfx.setColor(BLACK)
        gfx.setLineWidth(2)
        gfx.drawRoundRect(x, y, w, h, 4)
        gfx.setLineWidth(1)
        CAFE.art[CAFE.byId[CAFE.pend] and CAFE.pend or "table"](x + math.floor(w / (2)) + ((it.kind == "counter" and sp <= 10) and (CAFE.ADX[CAFE.pend] or 0) or 0), y + math.floor(h / (2)))
      else
        gfx.setColor(WHITE)
        for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
        for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
        gfx.setColor(BLACK)
        for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
        for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w - 1, yy, x + w - 1, yy + 2) end
      end
    end
    gfx.setColor(WHITE)
    local by = (it.kind == "table" or it.kind == "counter") and 112 or 196        -- keep the box off the spots (tables sit low, the counter high)
    local pl = CAFE.fitLines((it.kind == "shelf") and ("Which end for the " .. it.name .. "?") or ("Where should the " .. it.name .. " go?"), 284, true, 2)
    local ph = 4 + 16 * (#pl + 1)
    if by + ph > 236 then by = 236 - ph end
    gfx.fillRoundRect(50, by, 300, ph, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(50, by, 300, ph, 6)
    for li = 1, #pl do drawTC(pl[li], 200, by + 2 + (li - 1) * 16, true) end
    drawTC(CAFE.fitOne("D-pad: choose   A: place   B: cancel", 284, false), 200, by + 2 + #pl * 16)
    return
  end
  if CAFE.mode == "slots" then
    local art = UI.bgSet("slots")
    if art then
      art[frames % UI.TITLE_N + 1]:draw(0, 0)                                -- the turning sunburst and the lettering
    else
      UI.beanFrame()
      CAFE.band("CAFE  -  CHOOSE A SAVE")
    end
    for i = 1, 3 do
      local y = (art and 54 or 42) + (i - 1) * 50
      local d = CAFE.slots[i]
      local sel = CAFE.sel == i
      if art then
        UI.stickerBox(60, y, 280, 44, sel)                                   -- the same sticker boxes as the title screen
      else
        gfx.setColor(BLACK)
        if sel then
          gfx.fillRoundRect(60, y, 280, 44, 8)
          gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
        else
          gfx.setLineWidth(2)
          gfx.drawRoundRect(60, y, 280, 44, 8)
          gfx.setLineWidth(1)
        end
      end
      local col = sel and WHITE or BLACK
      drawT(tostring(i), 70, y + 13, true)
      if d then
        drawT(d.name, 88, y + 4, true)
        drawT(string.format("%s  %d cups  %d seats", money(d.money), d.cups, CAFE.seatsOf(d.seatStep)), 88, y + 24)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        CAFE.drawStars(280, y + 12, 5, 11, d.stars, col, UI.lvl(d))
        if UI.lvl(d) >= 2 then UI.levelBadge(270, y + 12, UI.lvl(d), col == WHITE) end
      else
        drawT("NEW CAFE", 88, y + 13, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if sel and not CAFE.erase then CAFE.pointer(316, y + 24) end            -- the mouse arrow rests on the chosen save
    end
    if art then
      local hint = "B: back      Right: erase"                               -- on a little sticker plate at the bottom
      gfx.setFont(fontNormal)
      local hw = math.min(gfx.getTextSize(hint) + 28, 330)
      UI.stickerBox(200 - math.floor(hw / (2)), 206, hw, 22, false)
      drawTC(hint, 200, 209)
    else
      drawTC("B: back      Right: erase", 200, 208)
    end
    if CAFE.erase then
      local bx, by, bw, bh = 66, 58, 268, 124
      gfx.setColor(WHITE)
      gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14)
      gfx.setColor(BLACK)
      CAFE.wobbleBox(bx, by, bw, bh)                        -- squiggly edge
      drawTC("Are you sure you want to", 200, by + 22)
      if CAFE.delW == nil then                              -- the letters of "delete", measured once
        gfx.setFont(fontBold)
        CAFE.delW, CAFE.delTotal = {}, 0
        for i = 1, 6 do
          CAFE.delW[i] = (gfx.getTextSize(string.sub("delete", i, i)))
          CAFE.delTotal = CAFE.delTotal + CAFE.delW[i]
        end
        gfx.setFont(fontNormal)
        CAFE.delRest = (gfx.getTextSize(" this save file?"))
      end
      local x0 = 200 - math.floor((CAFE.delTotal + CAFE.delRest) / (2))
      local lx = x0
      for i = 1, 6 do                                       -- "delete" in bold, every letter wiggling
        drawT(string.sub("delete", i, i), lx, by + 42 + math.floor(math.sin(frames * 0.4 + i * 0.9) * 2 + 0.5), true)
        lx = lx + CAFE.delW[i]
      end
      drawT(" this save file?", lx, by + 42)
      for i = 1, 2 do                                       -- Delete and Cancel, each a button
        local x = (i == 1) and 86 or 206
        local on = (CAFE.eraseSel == i)
        gfx.setColor(BLACK)
        if on then
          gfx.fillRoundRect(x, by + 74, 108, 28, 8)
          gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
        else
          gfx.setLineWidth(2); gfx.drawRoundRect(x, by + 74, 108, 28, 8); gfx.setLineWidth(1)
        end
        drawTC(i == 1 and "Delete" or "Cancel", x + 54, by + 81, true)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        gfx.setColor(BLACK)
        if on then CAFE.pointer(x + 80, by + 94) end         -- the mouse arrow rests on the chosen button
      end
    end
  elseif CAFE.mode == "char" and UI.bgSet("char") then
    UI.bgSet("char")[frames % UI.TITLE_N + 1]:draw(0, 0)
    UI.drawCharNew()
  elseif CAFE.mode == "char" then
    UI.beanFrame()
    CAFE.band("PICK YOUR BARISTA")
    gfx.setColor(BLACK)
    CAFE.charImgs = CAFE.charImgs or {}
    for i = 1, 3 do
      local bx = 40 + (i - 1) * 112
      local on = (CAFE.charSel == i)
      gfx.setColor(WHITE); gfx.fillRoundRect(bx, 52, 96, 120, 10)
      gfx.setColor(BLACK)
      gfx.setLineWidth(on and 4 or 2)
      gfx.drawRoundRect(bx, 52, 96, 120, 10)
      gfx.setLineWidth(1)
      local im = CAFE.charImgs[i]
      if im == nil then
        im = gfx.image.new(40, 40, gfx.kColorClear)
        gfx.pushContext(im)
        drawPerson(20, 14, UI.BARISTA[i], false, 2)
        gfx.popContext()
        CAFE.charImgs[i] = im
      end
      im:drawScaled(bx + 8, 62, 2.0)
      if on then CAFE.pointer(bx + 62, 150) end
    end
    gfx.setColor(BLACK)
  elseif CAFE.mode == "name" and UI.bgSet("name") then
    UI.bgSet("name")[frames % UI.TITLE_N + 1]:draw(0, 0)
    UI.drawNameNew()
  elseif CAFE.mode == "name" then
    UI.beanFrame()
    CAFE.band("NAME YOUR CAFE")
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(64, 42, 272, 38, 8)
    gfx.setLineWidth(1)
    gfx.setFont(fontBold)
    local w = gfx.getTextSize(CAFE.name)
    local x0 = 200 - math.floor((w + 10) / (2))
    drawT(CAFE.name, x0, 52, true)
    if (math.floor(frames / (10))) % 2 == 0 and #CAFE.name < CAFE.NAME_MAX then gfx.fillRect(x0 + w + 2, 70, 9, 3) end
    -- the letter wheel (A-Z, the word CAFE, a space), then DONE below it
    local lc = (CAFE.letter == 26) and "CAFE" or ((CAFE.letter == 27) and "space" or string.char(65 + CAFE.letter))
    gfx.setColor(BLACK)
    gfx.fillTriangle(140, 102, 140, 126, 128, 114)           -- left and right turn the wheel
    gfx.fillTriangle(260, 102, 260, 126, 272, 114)
    local dialOn = not CAFE.onDone
    if not dialOn then gfx.setLineWidth(2); gfx.drawRoundRect(150, 96, 100, 36, 8); gfx.setLineWidth(1)
    else gfx.fillRoundRect(150, 96, 100, 36, 8) end
    gfx.setImageDrawMode(dialOn and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC(lc, 200, 106, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if CAFE.onDone then gfx.fillRoundRect(150, 152, 100, 28, 8) else gfx.setLineWidth(2); gfx.drawRoundRect(150, 152, 100, 28, 8); gfx.setLineWidth(1) end
    gfx.setImageDrawMode(CAFE.onDone and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC("DONE", 200, 158, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)

  else
    -- the shop is a web page: address bar on top, tabs, a list of links, a bar of buttons below
    local shopBg = UI.shopBgImg()
    if shopBg then
      shopBg:draw(0, 0)                                      -- the dark backdrop, the white sheet, address bar and bottom bar: one picture
      UI.drawShopBeans()                                     -- (three beans in the corner, drifting up and down)
    else
      gfx.setColor(WHITE)
      gfx.fillRoundRect(8, 4, 384, 24, 12)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(8, 4, 384, 24, 12)
      gfx.setLineWidth(1)
      -- back / forward arrows
      gfx.fillTriangle(14, 16, 22, 10, 22, 22)
      gfx.fillTriangle(38, 16, 30, 10, 30, 22)
      gfx.setLineWidth(2)                                    -- refresh: a circle of arrow
      for a = 40, 320, 20 do
        local r1, r2 = math.rad(a), math.rad(a + 20)
        gfx.drawLine(math.floor(56 + math.cos(r1) * 6 + 0.5), math.floor(16 + math.sin(r1) * 6 + 0.5),
                     math.floor(56 + math.cos(r2) * 6 + 0.5), math.floor(16 + math.sin(r2) * 6 + 0.5))
      end
      gfx.setLineWidth(1)
      gfx.fillTriangle(56 + 6, 16 - 7, 56 + 6, 16 + 1, 56 + 13, 16 - 2)
      gfx.drawCircleAtPoint(82, 16, 7)                       -- globe
      gfx.drawEllipseInRect(79, 9, 6, 14)
      gfx.drawLine(75, 16, 89, 16)

    end
    do                                                     -- the address, cut off with "..." if it can't all fit in the bar
      gfx.setFont(fontNormal)
      CAFE.urlCache = CAFE.urlCache or {}
      local url = CAFE.urlCache[CAFE.tab]
      if url == nil then
        url = "https://www.coffeesupply.com/" .. CAFE.TABPATH[CAFE.tab]
        local maxW = 286
        if gfx.getTextSize(url) > maxW then
          while #url > 4 and gfx.getTextSize(url .. "...") > maxW do url = string.sub(url, 1, #url - 1) end
          url = url .. "..."
        end
        CAFE.urlCache[CAFE.tab] = url
      end
      UI.ink("gingham")                                    -- (PC: the address in link blue)
      drawT(url, 98, 8)
      UI.ink("none")
    end
    gfx.setColor(BLACK)
    UI.ink("inkpurple")
    CAFE.drawShopMsg()                                      -- the line under the address bar: a new message every 6 seconds
    UI.ink("none")
    -- the tabs: a strip that slides round, kept to the left of the preview picture
    gfx.setClipRect(8, 45, 280, 21)
    do
      local n = #CAFE.TABS
      for ti, name in ipairs(CAFE.TABS) do
        local dd = (ti - CAFE.tabPos + n / 2) % n - n / 2         -- -3 .. 3 tabs away from the middle
        local tx = math.floor(148 + dd * 76 - 36)
        if tx > -80 and tx < 300 then
          UI.ink(CAFE.TABINK[ti])                         -- (PC: every tab its own colour)
          gfx.setColor(BLACK)
          local on = (ti == CAFE.tab)
          if on then
            if shopBg then gfx.setColor(WHITE); gfx.fillRoundRect(tx - 1, 46, 74, 19, 6); gfx.setColor(BLACK) end
            gfx.fillRoundRect(tx, 47, 72, 17, 5)
            gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
          else
            gfx.setColor(WHITE); gfx.fillRoundRect(tx, 47, 72, 17, 5); gfx.setColor(BLACK)
            gfx.drawRoundRect(tx, 47, 72, 17, 5)
          end
          local cx1, cx2 = math.max(tx, 8), math.min(tx + 72, 288)          -- the letters are cut off at the bottom edge of their tab (so the tail of a "g" doesn't poke out)
          if cx2 > cx1 then
            gfx.setClipRect(cx1, 47, cx2 - cx1, 17)
            drawTC(name, tx + 36, 48, on)
            gfx.setClipRect(8, 45, 280, 21)
          end
          gfx.setImageDrawMode(gfx.kDrawModeCopy)
        end
      end
    end
    gfx.clearClipRect()
    UI.ink("none")
    gfx.setColor(BLACK)
    if CAFE.focus == "tabs" then CAFE.pointer(148 + 16, 51) end             -- the mouse rests on the chosen tab
    -- the bar along the bottom: stars on the left, two buttons, money on the right
    if not shopBg then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(8, 212, 384, 24, 12)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(8, 212, 384, 24, 12)
      gfx.setLineWidth(1)
    end
    CAFE.drawStars(26, 224, 5, 11, CAFE.cur.stars, BLACK, UI.lvl(CAFE.cur))
    CAFE.shopBtns = CAFE.shopBtns or { { "back", "Back to cafe", 82, 112 }, { "quit", "Save & quit", 198, 102 } }
    for bi = 1, 2 do
      local bn = CAFE.shopBtns[bi]
      UI.ink(CAFE.TABINK[CAFE.tab])
      gfx.setColor(BLACK)
      local on = (CAFE.focus == bn[1])
      if on then
        gfx.fillRoundRect(bn[3], 215, bn[4], 18, 6)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(bn[3], 215, bn[4], 18, 6)
      end
      drawTC(bn[2], bn[3] + math.floor(bn[4] / (2)) + 1, 216)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if on then CAFE.pointer(bn[3] + bn[4] - 12, 225) end
    end
    gfx.setColor(BLACK)
    if CAFE.moneyShown ~= CAFE.cur.money then CAFE.moneyShown = CAFE.cur.money; CAFE.moneyStr = money(CAFE.cur.money) end
    UI.ink("inkgreen")
    drawTR(CAFE.moneyStr, 381, 217, true)
    local rows = CAFE.rows()
    if CAFE.tab == CAFE.SALE_TAB then UI.ink(CAFE.TABINK[CAFE.tab]); UI.saleTimerRow(69); UI.ink("none") end
    for vi = 1, CAFE.visRows() do
      local i = CAFE.scroll + vi
      local row = rows[i]
      if row == nil then break end
      UI.ink(CAFE.TABINK[CAFE.tab])                       -- (PC: the rows take the colour of their tab)
      local y = CAFE.rowY(vi)                              -- (the sheet's white part runs y 68 to 208: rows 19 tall keep a pixel clear at the top and the bottom)
      gfx.setColor(BLACK)
      local sel = (CAFE.focus == "list" and CAFE.shopSel == i)
      local ind = row.more and 22 or 0                     -- "Buy another" hangs under its item: pushed in, with an elbow joining it to the item above
      if row.more then
        gfx.setLineWidth(2)
        gfx.drawLine(18, y - 1, 18, y + 9); gfx.drawLine(18, y + 9, 10 + ind - 1, y + 9)
        gfx.setLineWidth(1)
      end
      if sel then
        gfx.fillRoundRect(10 + ind, y, 273 - ind, 19, 5)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(10 + ind, y, 273 - ind, 19, 5)   -- every choice is a button with a border
      end
      local nameTxt, stickerX = CAFE.rowName(row[1], row[2], row[7])
      drawT(nameTxt, 20 + ind, y + 1)
      if row[7] then                                       -- how much is off (solid for half price, outlined for the rest)
        UI.saleSticker(stickerX, y + 1, row[7], sel and WHITE or BLACK, sel and BLACK or WHITE)
        gfx.setColor(BLACK)
      end
      if row[2] ~= "" then drawTR(row[2], 275, y + 2, true) end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if sel then                                          -- the mouse pointer, resting on the choice
        gfx.setFont(fontNormal)
        CAFE.pointer(20 + ind + math.min(gfx.getTextSize(row[1]) * 0.6, 150), y + 7)
      end
    end
    UI.ink("none")
    CAFE.drawPreview(rows[CAFE.shopSel])
    UI.ink(CAFE.TABINK[CAFE.tab])
    -- a scroll bar down the right of the list: the thumb slides as you move
    do
      local tx, ty, th = 285, 68, 138
      gfx.setColor(BLACK)
      gfx.drawRoundRect(tx, ty, 7, th, 3)
      local n = #rows
      local thumb = (n <= CAFE.visRows()) and th or math.max(14, math.floor(th * CAFE.visRows() / n))
      local pos = (n <= 1) and 0 or (CAFE.shopSel - 1) / (n - 1)
      if CAFE.focus == "tabs" then pos = 0 elseif CAFE.focus ~= "list" then pos = 1 end
      gfx.fillRoundRect(tx, ty + math.floor((th - thumb) * pos + 0.5), 7, thumb, 3)
    end
    UI.ink("none")
    local bmsg = CAFE.msg
    local hrow = rows[CAFE.shopSel]
    local hint = false
    if not bmsg and CAFE.focus == "list" and hrow and hrow.multi and not hrow.more and CAFE.shopSel > CAFE.scroll and CAFE.shopSel <= CAFE.scroll + CAFE.visRows() then
      bmsg, hint = "Hold A to edit item layout", true       -- (an owned piece: the same bubble that says "Bought!", while you rest on it)
    end
    if bmsg then
      local bx0, bw0 = 40, 320
      if hint then bx0, bw0 = 20, 254 end                    -- (the hint stays over the list, clear of the picture and its words)
      local ml = CAFE.fitLines(bmsg, bw0 - 16, true, 3)
      local mh = 4 + 16 * #ml
      local by0 = 204 - mh
      if hint then                                           -- keep it off the row you are on (and the "Buy another" row under it)
        local sy = CAFE.rowY(CAFE.shopSel - CAFE.scroll)
        if sy + 40 > by0 then by0 = 71 end
        if by0 == 71 and sy < 71 + mh then by0 = 204 - mh end
      end
      gfx.setColor(WHITE)
      gfx.fillRoundRect(bx0, by0, bw0, mh, 6)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(bx0, by0, bw0, mh, 6)
      for li = 1, #ml do drawTC(ml[li], bx0 + math.floor(bw0 / (2)), by0 + 2 + (li - 1) * 16, true) end
    end
    if CAFE.note then
      local bx, by, bw, bh = 70, 62, 260, 112
      gfx.setColor(WHITE)
      if shopBg then gfx.fillRoundRect(bx + 2, by + 2, bw - 4, bh - 4, 10) else gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14) end
      gfx.setColor(BLACK)
      CAFE.wobbleBox(bx, by, bw, bh)
      drawTC(CAFE.fitOne(CAFE.note[1], 236, true), 200, by + 14, true)
      drawTC(CAFE.fitOne(CAFE.note[2], 236, false), 200, by + 40)
      drawTC(CAFE.fitOne(CAFE.note[3], 236, false), 200, by + 58)
      gfx.setColor(BLACK)
      gfx.fillRoundRect(200 - 36, by + 80, 72, 24, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      drawTC("OK", 200, by + 85, true)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      CAFE.pointer(200 + 20, by + 98)
    end
    if CAFE.ask then UI.askDraw() end
  end
  gfx.setColor(BLACK)
end


-- System menu (the Menu button): jump back to the title screen
-- (the Cafe hides this item: there you only get End shift / Save & quit)
function UI.setTitleItem(on)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if on and UI.titleItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Title screen", function()
        if state ~= STATE_MENU then goTitle() end
      end)
    end)
    if ok then UI.titleItem = item end
  elseif (not on) and UI.titleItem ~= nil then
    pcall(function() menu:removeMenuItem(UI.titleItem) end)
    UI.titleItem = nil
  end
end
UI.setTitleItem(false)

-- the fade to black and back that covers every change of screen
local fadeImg = nil
do
  local ok, img = pcall(function() return gfx.image.new(400, 240, BLACK) end)
  if ok then fadeImg = img end
end

function UI.drawFade()
  if trans == nil then return end
  local k = clamp(trans.t / trans.dur, 0, 1)
  local a = (trans.phase == "out") and k or (1 - k)
  if a <= 0.02 then return end
  if a >= 0.98 then
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 400, 240)
    return
  end
  if fadeImg then
    fadeImg:drawFaded(0, 0, a, gfx.image.kDitherTypeBayer8x8)
    return
  end
  gfx.setColor(BLACK)                       -- fallback: a coarse checker fade
  if a > 0.3 then gfx.setPattern(CHECK) end
  if a > 0.3 then gfx.fillRect(0, 0, 400, 240) end
  gfx.setColor(BLACK)
end

function UI.anyButton()                         -- is a button being pressed?
  return pd.buttonIsPressed(pd.kButtonUp) or pd.buttonIsPressed(pd.kButtonDown) or pd.buttonIsPressed(pd.kButtonLeft) or pd.buttonIsPressed(pd.kButtonRight)
      or pd.buttonIsPressed(pd.kButtonA) or pd.buttonIsPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
      or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) or pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB)
end

UI.SEASON_TUNES = { hmus = { "skeleton", "haunted" }, xmus = { "skating", "snowfall" } }       -- the two records in the shop's Music tab and their tracks

function UI.pickTune(exclude)                   -- a random tune from the playlist, not the one just played (nor the one before it)
  local pl = UI.mus.list or UI.POOL
  local list = {}
  for _, n in ipairs(pl) do
    local r = UI.mus.recent
    if not UI.badTunes[n] and n ~= exclude and n ~= r[1] and n ~= r[2] then list[#list + 1] = n end
  end
  if #list == 0 then
    for _, n in ipairs(pl) do if not UI.badTunes[n] and n ~= exclude then list[#list + 1] = n end end
  end
  if #list == 0 then
    for _, n in ipairs(pl) do if not UI.badTunes[n] then list[#list + 1] = n end end         -- (a playlist of one: it goes round again)
  end
  if #list == 0 then return nil end
  return list[math.random(#list)]
end

function UI.freeTune(name)                      -- let a tune go (its memory comes back once the garbage is collected, which waits for a quiet moment)
  local p = UI.tunes[name]
  if p then pcall(function() p:stop() end); UI.tunes[name] = nil; UI.mus.gc = true end
end

function UI.inList(name, list)
  for _, n in ipairs(list) do if n == name then return true end end
  return false
end

function UI.musicStart(name, ctx)               -- play a tune once, twice or three times round, and choose the one that will follow it
  for _ = 1, 3 do
    local p = name and UI.tune(name)
    if p then
      local plays = weighted({ 40, 40, 20 }) + 1
      pcall(function() p:stop(); p:play(plays) end)
      local m = UI.mus
      local again = (name == m.cur)
      m.cur, m.t0, m.ctx = name, frames, ctx or m.ctx
      if not again then m.recent = { name, m.recent[1] } end
      local old = m.pick
      if again and old and old ~= name and not UI.badTunes[old] and UI.inList(old, m.list or UI.POOL) then
        return                                  -- (the same tune again, back from the settings or the shop: the one lined up after it stays, loaded or not)
      end
      m.pick = UI.pickTune(name)
      if old and old ~= m.pick and old ~= name then UI.freeTune(old) end      -- (a tune that was lined up and is not any more)
      return
    end
    name = UI.pickTune(name)                    -- (that one would not load: try another)
  end
end

function UI.musicSwitch(want, ctx, list, lkey)  -- a different kind of music is wanted: stop what plays and start the right thing
  local m = UI.mus
  if m.cur and UI.tunes[m.cur] then pcall(function() UI.tunes[m.cur]:stop() end) end
  if UI.tunes.shop then pcall(function() UI.tunes.shop:stop() end) end
  if UI.tunes.rush then pcall(function() UI.tunes.rush:stop() end) end
  if want == "shop" then
    if UI.tunes.shop then pcall(function() UI.tunes.shop:play(0) end) end
  elseif want == "rush" then                    -- Rush Hour has a tune of its own (90 seconds, looped); the playlist's tunes make room for it
    if m.cur then UI.freeTune(m.cur) end
    if m.pick then UI.freeTune(m.pick) end
    m.cur, m.pick = nil, nil
    local p = UI.tune("rush")
    if p then pcall(function() p:play(0) end) end
  elseif want == "pool" then
    UI.freeTune("rush")
    list = list or UI.POOL
    local same = (m.ctx == ctx and m.lkey == lkey)
    m.list, m.lkey = list, lkey
    if m.cur and UI.tunes[m.cur] and same and UI.inList(m.cur, list) then      -- (back from the shop: the same tune again)
      UI.musicStart(m.cur, ctx)
    else                                                        -- (a new place, or other tunes switched on: a new random tune, the one lined up if it is loaded and still on the list)
      local nx = (m.pick and UI.tunes[m.pick] and UI.inList(m.pick, list)) and m.pick or nil
      if m.cur and m.cur ~= nx then UI.freeTune(m.cur) end
      if m.pick and m.pick ~= nx then UI.freeTune(m.pick) end
      m.cur, m.pick = nil, nil
      UI.musicStart(nx or UI.pickTune(nil), ctx)
      m.lkey = lkey
    end
  end
end

function UI.musicQuiet()                        -- a moment when loading a tune would not be noticed: nothing pressed for a second, and no screen fade going
  if trans ~= nil then return false end           -- (a fade that stalls while a tune loads is just the hitch you would notice)
  if state == STATE_PLAY and G ~= nil and G.st ~= nil then return false end
  return frames - (UI.lastBtn or 0) >= 30
end

UI.SLISTS = {}                                  -- the playlists for each mix of records, made once
function UI.musicList()                         -- which tunes the title screen, cafe and Evening Chill choose from, and what they are called
  local cafe = nil
  if state == STATE_PLAY and G ~= nil and G.mode == "cafe" then cafe = CAFE.cur
  elseif state == CAFE.STATE and G ~= nil and (CAFE.mode == "place" or CAFE.mode == "layout" or CAFE.mode == "edit") then cafe = CAFE.cur end
  local d = cafe and cafe.decor
  local h, x = d and d.hmus == "on", d and d.xmus == "on"
  if h or x then                                -- the cafe's own music: only the records that are bought and switched on
    local key = h and (x and "HX" or "H") or "X"
    local list = UI.SLISTS[key]
    if not list then
      list = {}
      if h then for _, n in ipairs(UI.SEASON_TUNES.hmus) do list[#list + 1] = n end end
      if x then for _, n in ipairs(UI.SEASON_TUNES.xmus) do list[#list + 1] = n end end
      UI.SLISTS[key] = list
    end
    return list, key
  end
  return UI.POOL, ""
end

function UI.musicTick()                         -- title screen, cafe, Evening Chill: random tunes. Rush Hour: its own. The website: its own
  if UI.anyButton() then UI.lastBtn = frames end
  local want, ctx, list, lkey = "none", nil, nil, ""
  if UI.musicOn then
    if (state == CAFE.STATE and CAFE.mode == "shop") or (state == STATE_MENU and UI.settings ~= nil) then want = "shop"
    elseif (state == STATE_PLAY or state == STATE_ENTRY) and G ~= nil and G.mode == "rush" then want = "rush"
    else
      want = "pool"
      ctx = ((state == STATE_PLAY or state == STATE_ENTRY) and G ~= nil) and "shift" or "menus"
      list, lkey = UI.musicList()
    end
  end
  local key = want .. (ctx or "") .. lkey
  if key ~= UI.musicNow then
    UI.musicNow = key
    UI.musicSwitch(want, ctx, list, lkey)
    return
  end
  if want == "shop" or want == "rush" then
    if frames % 90 == 0 then                    -- (safety net: a tune that somehow ended starts again)
      local p = UI.tunes[want]
      if p then pcall(function() if not p:isPlaying() then p:play(0) end end) end
    end
  elseif want == "pool" then
    local m = UI.mus
    if frames % 6 == 0 then
      local p = m.cur and UI.tunes[m.cur]
      if p and not p:isPlaying() then           -- the tune has run its course: on to the next, or round again if that is not loaded yet
        local nx = m.pick
        if nx and nx ~= m.cur and UI.tunes[nx] then UI.freeTune(m.cur); UI.musicStart(nx) else UI.musicStart(m.cur) end
      elseif not p and UI.musicNow ~= nil then  -- (nothing playing at all: start something)
        UI.musicStart(UI.pickTune(nil))
      end
    end
    if m.pick and not UI.tunes[m.pick] and frames - (m.t0 or 0) > 240 then   -- (load the next tune in a quiet moment, or anyway if it has not come by the time the tune is nearly through)
      if UI.musicQuiet() or frames - (m.t0 or 0) > 1500 then UI.tune(m.pick) end
    end
  end
  if UI.mus.gc and frames % 10 == 0 and UI.musicQuiet() then      -- tunes that were let go give their memory back at a quiet moment
    UI.mus.gc = false
    collectgarbage("collect")
  end
end

----------------------------------------------------------------------
-- Barista levels, the star meter, order grades, the daily gift, achievements
----------------------------------------------------------------------
UI.hudTimeX = 6                                              -- (PC: moved over to make room for the phone)
function UI.noWait() return CAFE.rich() or (G ~= nil and G.mode == "chill") end      -- (Evening Chill: nobody runs out of patience, no meters)
function UI.lvl(d)                                           -- the barista level of a cafe (1 until its first prestige)
  d = d or (G and G.cafe) or CAFE.cur
  return math.max(1, math.floor(tonumber(d and d.lvl) or 1))
end
function UI.decorCount(d, owned)                             -- how much decor is out (or owned, out or not)
  local n = 0
  for _, v in pairs(d.decor or {}) do if v == "on" or (owned and v == "off") then n = n + 1 end end
  return n
end
function UI.decorReview(d) return 1 + math.min(0.5, 0.0125 * UI.decorCount(d)) end    -- a cosier cafe gets warmer reviews
function UI.tipMult(d)                                       -- Cafe tips: higher levels tip better; after a prestige the decor does too
  local lv = UI.lvl(d)
  local m = 1 + 0.1 * math.min(lv - 1, 10)
  if lv >= 2 then m = m * (1 + math.min(0.3, 0.01 * UI.decorCount(d))) end
  if (tonumber(d.boostT) or 0) > 0 then m = m * 2 end                                -- (the daily gift's tip boost)
  return m
end

-- ---- the little save shared by all three cafes: achievements, their counters, the daily gift ----
function UI.meta()
  local m = UI.metaT
  if m then return m end
  local ok, d = pcall(pd.datastore.read, "meta")
  if not ok or type(d) ~= "table" then d = {} end
  if type(d.got) ~= "table" then d.got = {} end
  if type(d.n) ~= "table" then d.n = {} end
  UI.metaT = d
  return d
end
function UI.metaSave() pcall(pd.datastore.write, UI.meta(), "meta") end
function UI.stat(k) return tonumber(UI.meta().n[k]) or 0 end
function UI.statAdd(k, v) local n = UI.meta().n; n[k] = (tonumber(n[k]) or 0) + v end
function UI.statMax(k, v) local n = UI.meta().n; if v > (tonumber(n[k]) or 0) then n[k] = v end end
function UI.flag(k) UI.meta().n[k] = 1 end

-- ---- achievements: { id, tab (1 Cafe, 2 Rush Hour), name, what to do, the counter, its goal } ----
UI.ACH = {
  { "first", 1, "First Pour", "Serve your first Cafe order", "served", 1 },
  { "serve100", 1, "Busy Morning", "Serve 100 Cafe orders", "served", 100 },
  { "serve500", 1, "Packed House", "Serve 500 Cafe orders", "served", 500 },
  { "serve1000", 1, "Coffee Machine", "Serve 1,000 Cafe orders", "served", 1000 },
  { "perfect10", 1, "Steady Hands", "10 perfect orders in a row", "pbest", 10 },
  { "perfect20", 1, "In the Zone", "20 perfect orders in a row", "pbest", 20 },
  { "perfect30", 1, "Barista Brain", "30 perfect orders in a row", "pbest", 30 },
  { "perfect40", 1, "Crema de la Crema", "40 perfect orders in a row", "pbest", 40 },
  { "perfect50", 1, "Flawless", "50 perfect orders in a row", "pbest", 50 },
  { "star1", 1, "Rising Star", "Earn your first full star", "starmax", 1 },
  { "star5", 1, "Five-Star Cafe", "Reach 5 out of 5 stars", "starmax", 5 },
  { "lv2", 1, "Fresh Start", "Prestige once (Barista Lv 2)", "lvl", 2 },
  { "lv4", 1, "Bean There", "Prestige 3 times (Barista Lv 4)", "lvl", 4 },
  { "lv6", 1, "Master Roaster", "Prestige 5 times (Barista Lv 6)", "lvl", 6 },
  { "lv11", 1, "Coffee Legend", "Prestige 10 times (Barista Lv 11)", "lvl", 11 },
  { "booth", 1, "Full House", "Get the corner booth (15 seats)", "seats", 5 },
  { "decor10", 1, "Decorator", "Own 10 decorations", "decor", 10 },
  { "decor40", 1, "Interior Designer", "Own 40 decorations", "decor", 40 },
  { "decor80", 1, "Showroom", "Own 80 decorations", "decor", 80 },
  { "pet", 1, "Best Friend", "Adopt your first pet", "pets", 1 },
  { "zoo", 1, "Petting Zoo", "A cat, a dog and a turtle out at once", "zoo", 1 },
  { "style", 1, "Dressed to Impress", "Wear a hat and glasses together", "style", 1 },
  { "spooky", 1, "Spooky Season", "Open with the Halloween music on", "spooky", 1 },
  { "jolly", 1, "Holly Jolly", "Open with the Christmas music on", "jolly", 1 },
  { "gift", 1, "Surprise!", "Open your first daily gift", "gifts", 1 },
  { "gift7", 1, "Loyal Barista", "Open daily gifts 7 days in a row", "gstreak", 7 },
  { "flash", 1, "Bargain Hunter", "Buy something in a Flash Sale", "flash", 1 },
  { "spend", 1, "Big Spender", "Spend $1,000 in the shop", "spent", 100000 },
  { "tips", 1, "Tip Jar Hero", "Earn $50 in tips in one shift", "tipshift", 5000 },
  { "night", 1, "Night Owl", "Work a shift between 12 and 4 AM", "night", 1 },
  { "early", 1, "Early Bird", "Work a shift between 5 and 8 AM", "early", 1 },
  { "rush1", 2, "Clocked In", "Finish a Rush Hour", "rushes", 1 },
  { "rush10", 2, "Rush Regular", "Finish 10 Rush Hours", "rushes", 10 },
  { "combo2", 2, "Combo Starter", "Reach a x2 combo", "combo", 5 },
  { "combo3", 2, "Combo King", "Reach the top x3 combo", "combo", 9 },
  { "rush40", 2, "Rush Pro", "Score $40 in one Rush Hour", "rushbest", 4000 },
  { "rush70", 2, "Rush Legend", "Score $70 in one Rush Hour", "rushbest", 7000 },
}
UI.ACH_TABS = { "CAFE", "RUSH HOUR" }
UI.achQ = {}                                                 -- unlocked, waiting to be shown
function UI.achProgress(a)                                   -- how far along (for counters that are worth showing as "7/10")
  local v = UI.stat(a[5])
  if a[5] == "spent" or a[5] == "tipshift" or a[5] == "rushbest" then return nil end
  if a[6] <= 1 then return nil end
  return math.floor(math.min(v, a[6])), a[6]                -- (whole numbers: saved counters can come back as 7.0)
end
function UI.achCheck()                                       -- anything newly earned is unlocked (and shown)
  local d = CAFE.cur
  if d and d.decor then                                      -- (the counters that come straight from the cafe you're in)
    UI.statMax("seats", d.seatStep or 0)
    UI.statMax("decor", UI.decorCount(d, true))
    UI.statMax("lvl", UI.lvl(d))
    UI.statMax("starmax", math.floor((d.stars or 0) + 0.001))
    local pets, kinds = 0, {}
    for _, it in ipairs(CAFE.ITEMS) do
      if it.species and d.decor[it.id] ~= nil then pets = pets + 1 end
      if it.species and d.decor[it.id] == "on" then kinds[it.species] = true end
    end
    UI.statMax("pets", pets)
    if kinds.cat and kinds.dog and kinds.turtle then UI.flag("zoo") end
    local hat, glass = false, false
    for id, v in pairs(d.decor) do
      if v == "on" then
        local it = CAFE.byId[id]
        if it and it.kind == "hat" then hat = true elseif it and it.kind == "glasses" then glass = true end
      end
    end
    if hat and glass then UI.flag("style") end
  end
  local m = UI.meta()
  local any = false
  for _, a in ipairs(UI.ACH) do
    if not m.got[a[1]] and UI.stat(a[5]) >= a[6] then
      m.got[a[1]] = true
      UI.achQ[#UI.achQ + 1] = { a = a, t = 0 }
      any = true
    end
  end
  if any then UI.metaSave() end
end
function UI.achCount(tab)
  local got, all = 0, 0
  for _, a in ipairs(UI.ACH) do
    if a[2] == tab then all = all + 1; if UI.meta().got[a[1]] then got = got + 1 end end
  end
  return got, all
end
function UI.clockAch()                                       -- Night Owl / Early Bird: by the Playdate's own clock
  local ok, t = pcall(pd.getTime)
  if not ok or type(t) ~= "table" or not t.hour then return end
  if t.hour < 4 then UI.flag("night") elseif t.hour >= 5 and t.hour < 8 then UI.flag("early") end
  UI.achCheck()
end
function UI.shiftStartAch(d)                                 -- a Cafe shift is starting
  if d.decor.hmus == "on" then UI.flag("spooky") end
  if d.decor.xmus == "on" then UI.flag("jolly") end
  UI.clockAch()
end

-- the trophy: a cup with two handles on a little stand (cx, cy = middle), ink on bg
function UI.trophy(cx, cy, ink, bg, shine)
  gfx.setColor(ink)
  gfx.fillRoundRect(cx - 6, cy - 8, 13, 9, 3)                -- the cup
  gfx.fillRect(cx - 6, cy - 8, 13, 4)
  gfx.drawCircleAtPoint(cx - 7, cy - 4, 3)                   -- handles
  gfx.drawCircleAtPoint(cx + 7, cy - 4, 3)
  gfx.fillRect(cx - 1, cy + 1, 3, 3)                         -- stem
  gfx.fillRoundRect(cx - 5, cy + 4, 11, 4, 1)                -- base
  gfx.setColor(bg)
  gfx.fillRect(cx - 6, cy - 4, 13, 1)                        -- a band round the cup
  gfx.drawPixel(cx - 3, cy - 7); gfx.drawPixel(cx - 3, cy - 6)   -- a glint
  gfx.fillRect(cx - 3, cy + 5, 7, 1)
  if shine then                                              -- a sparkle that winks
    local k = (math.floor(frames / (3))) % 10
    if k < 4 then
      gfx.setColor(ink)
      local sx, sy = cx + 9, cy - 10
      gfx.drawLine(sx - k, sy, sx + k, sy); gfx.drawLine(sx, sy - k, sx, sy + k)
    end
  end
  gfx.setColor(BLACK)
end
function UI.lock(cx, cy, ink)                                -- a padlock
  gfx.setColor(ink)
  gfx.drawRoundRect(cx - 4, cy - 8, 9, 9, 4)
  gfx.drawRoundRect(cx - 3, cy - 7, 7, 8, 3)
  gfx.fillRoundRect(cx - 6, cy - 3, 13, 10, 2)
  gfx.setColor(ink == BLACK and WHITE or BLACK)
  gfx.fillRect(cx, cy, 1, 4)
  gfx.drawPixel(cx - 1, cy + 1); gfx.drawPixel(cx + 1, cy + 1)
  gfx.setColor(BLACK)
end

-- ---- the popup when one is earned: it drops in at the top, rests, and slides away ----
function UI.achTick(dt)
  local q = UI.achQ[1]
  if not q then return end
  if q.t == 0 then                                           -- a little fanfare
    play(synthSine, 1047, 0.10, 0.30); play(synthSine, 1319, 0.10, 0.30, 0.09)
    play(synthSine, 1568, 0.10, 0.30, 0.18); play(synthSine, 2093, 0.25, 0.30, 0.27)
  end
  q.t = q.t + dt
  if q.life == nil then q.life = (#UI.achQ > 1) and 2.0 or 3.2 end         -- (a few at once: each one is quicker)
  if q.t >= q.life then table.remove(UI.achQ, 1) end
end
function UI.achDraw()
  local q = UI.achQ[1]
  if not q then return end
  local t = q.t
  local life = q.life or 3.2
  local k
  if t < 0.35 then k = 1 - (1 - t / 0.35) ^ 3                -- (eases in)
  elseif t > life - 0.4 then k = 1 - ((t - life + 0.4) / 0.4) ^ 2
  else k = 1 end
  local w, h = 268, 36
  local top = (state == STATE_PLAY) and 22 or 4             -- (in a shift it sits under the top bar, so the stars stay in view)
  local x, y = 200 - math.floor(w / (2)), math.floor(-h - 4 + (h + 4 + top) * k)
  UI.ink("achpop")
  gfx.setColor(WHITE); gfx.fillRoundRect(x - 2, y - 2, w + 4, h + 4, 11)
  gfx.setColor(BLACK); gfx.fillRoundRect(x, y, w, h, 9)
  gfx.setColor(WHITE); gfx.drawRoundRect(x + 3, y + 3, w - 6, h - 6, 7)
  UI.trophy(x + 22, y + 19, WHITE, BLACK, true)
  gfx.setColor(WHITE)
  UI.pixText("ACHIEVEMENT UNLOCKED", x + 40, y + 7)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(CAFE.fitOne(q.a[3], w - 52, true), x + 40, y + 16, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if t < 1.2 then                                            -- confetti specks off its corners
    gfx.setColor(WHITE)
    for i = 1, 6 do
      local a = i * 1.05 + 0.3
      local r = 6 + t * 40
      gfx.fillRect(math.floor(x + (i % 2 == 0 and w or 0) + math.cos(a) * r), math.floor(y + h / 2 + math.sin(a) * r * 0.6), 2, 2)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- the Achievements screen (the trophy box on the title screen) ----
function UI.openAch()
  sfxClick()
  UI.fast(function() UI.ach = { tab = 1, sel = 1, scroll = 0, crank = 0 }; UI.bgSet("achieve") end)
end
function UI.achList(tab)
  local out = {}
  for _, a in ipairs(UI.ACH) do if a[2] == tab then out[#out + 1] = a end end
  return out
end
UI.ACH_ROWS = 5
function UI.updateAch()
  local s = UI.ach
  local list = UI.achList(s.tab)
  local step = 0
  s.crank = s.crank + pd.getCrankChange()
  if s.crank >= 60 then s.crank = s.crank - 60; step = 1 elseif s.crank <= -60 then s.crank = s.crank + 60; step = -1 end
  if pd.buttonJustPressed(pd.kButtonDown) then step = 1 elseif pd.buttonJustPressed(pd.kButtonUp) then step = -1 end
  if step ~= 0 then
    local n = clamp(s.sel + step, 1, #list)
    if n ~= s.sel then s.sel = n; sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    s.tab = 3 - s.tab; s.sel, s.scroll = 1, 0; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
    sfxClick(); UI.fast(function() UI.ach = nil end)
  end
  if s.sel <= s.scroll then s.scroll = s.sel - 1 end
  if s.sel > s.scroll + UI.ACH_ROWS then s.scroll = s.sel - UI.ACH_ROWS end
end
function UI.drawAch()
  local s = UI.ach
  local art = UI.bgSet("achieve")
  if art then art[frames % UI.TITLE_N + 1]:draw(0, 0)
  else UI.beanFrame(); CAFE.band("ACHIEVEMENTS") end
  -- the two tabs, with how many of each are done
  for t = 1, 2 do
    local got, all = UI.achCount(t)
    local x = (t == 1) and 70 or 204
    local on = s.tab == t
    UI.ink(on and "achtab" or "none")
    UI.stickerBox(x, 46, 126, 18, on)
    gfx.setColor(on and WHITE or BLACK)
    local label = UI.ACH_TABS[t] .. "  " .. got .. "/" .. all
    UI.pixText(label, x + 63 - math.floor(UI.pixWidth(label) / (2)), 52)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    UI.ink("none")
  end
  -- the list: a white card, one row per achievement
  local px, py, pw, ph = 22, 71, 356, 160
  gfx.setColor(BLACK); gfx.fillRoundRect(px + 3, py + 3, pw, ph, 8)
  gfx.setColor(WHITE); gfx.fillRoundRect(px, py, pw, ph, 8)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRoundRect(px, py, pw, ph, 8); gfx.setLineWidth(1)
  local list = UI.achList(s.tab)
  local got = UI.meta().got
  for vi = 1, UI.ACH_ROWS do
    local i = s.scroll + vi
    local a = list[i]
    if a == nil then break end
    local y = py + 3 + (vi - 1) * 31
    local sel = s.sel == i
    local done = got[a[1]] == true
    UI.ink(done and "achgot" or "none")
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(px + 4, y, pw - 18, 29, 6)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    elseif vi > 1 then
      for xx = px + 10, px + pw - 20, 4 do gfx.drawPixel(xx, y - 2) end     -- dotted line between rows
    end
    local fg, bgc = sel and WHITE or BLACK, sel and BLACK or WHITE
    -- the badge tile: a trophy once done, a padlock until then
    if done then
      gfx.setColor(fg); gfx.fillRoundRect(px + 9, y + 3, 24, 23, 5)
      UI.trophy(px + 21, y + 15, bgc, fg, sel)
    else
      gfx.setColor(fg); gfx.drawRoundRect(px + 9, y + 3, 24, 23, 5)
      UI.lock(px + 21, y + 15, fg)
    end
    gfx.setImageDrawMode(sel and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    local cur, goal = UI.achProgress(a)
    local right = done and "DONE" or (cur and (cur .. "/" .. goal) or "")
    local rw = (right ~= "") and (UI.pixWidth(right) + 8) or 0
    local nm = CAFE.fitOne(a[3], pw - 70 - rw, true)
    drawT(nm, px + 40, y + 1, true)
    drawT(CAFE.fitOne(a[4], pw - 70 - rw, false), px + 40, y + 15)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    if right ~= "" then
      gfx.setColor(fg)
      UI.pixText(right, px + pw - 20 - UI.pixWidth(right), y + 11)
    end
    UI.ink("none")
    gfx.setColor(BLACK)
    if sel then gfx.setFont(fontBold); CAFE.pointer(px + 46 + gfx.getTextSize(nm), y + 4) end
  end
  -- a slim scroll bar down the right edge of the card
  local n = #list
  local tx, ty, th = px + pw - 10, py + 6, ph - 12
  gfx.setColor(BLACK)
  gfx.drawRoundRect(tx, ty, 5, th, 2)
  local thumb = (n <= UI.ACH_ROWS) and th or math.max(12, math.floor(th * UI.ACH_ROWS / n))
  local pos = (n <= 1) and 0 or (s.sel - 1) / (n - 1)
  gfx.fillRoundRect(tx, ty + math.floor((th - thumb) * pos + 0.5), 5, thumb, 2)
  gfx.setColor(BLACK)
end

-- ---- the daily gift (once a day, after midnight by the Playdate's clock, the first time you open a cafe) ----
function UI.dayNum(y, m, d)                                  -- days since 1 Jan 1970, from a calendar date
  if m <= 2 then y = y - 1 end
  local era = math.floor(y / 400)
  local yoe = y - era * 400
  local doy = math.floor((153 * ((m + 9) % 12) + 2) / 5) + d - 1
  local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
  return era * 146097 + doe - 719468
end
function UI.today()
  local ok, t = pcall(pd.getTime)
  if not ok or type(t) ~= "table" or not t.year then return nil end
  return UI.dayNum(t.year, t.month, t.day)
end
function UI.giftReady()
  local day = UI.today()
  return day ~= nil and tonumber(UI.meta().day) ~= day
end
UI.GIFTS = {
  tips = { "Tip Boost!", "Double tips for", "5 minutes of your shift" },
  stars = { "Review Boost!", "Reviews fill your star", "meter twice as fast for 5 min" },
  flash = { "FLASH SALE!", "Everything on sale is 50% off", "until the deals change" },
}
function UI.giftUpdate(dt)
  local g = CAFE.gift
  WIN.updateWindow(dt)
  g.t = g.t + dt
  if g.phase == "box" then
    g.crank = (g.crank or 0) + math.abs(pd.getCrankChange())
    if pd.buttonJustPressed(pd.kButtonB) then CAFE.gift = nil; sfxClick(); return end      -- (later: it waits for next time)
    if pd.buttonJustPressed(pd.kButtonA) or g.crank >= 120 then UI.giftOpen() end
  elseif g.t > 0.5 and (pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB)) then
    CAFE.gift = nil
    sfxClick()
  end
end
function UI.giftOpen()
  local g, d, m = CAFE.gift, CAFE.cur, UI.meta()
  local r = math.random()
  local kind = (r < 0.10) and "flash" or ((r < 0.55) and "tips" or "stars")
  if kind == "tips" then d.boostT = (tonumber(d.boostT) or 0) + 300
  elseif kind == "stars" then d.boostS = (tonumber(d.boostS) or 0) + 300
  else
    if not CAFE.sale then CAFE.rollSale() end
    if CAFE.sale then CAFE.sale.flash = true end
    CAFE.allC = nil
  end
  local day = UI.today() or 0
  local streak = (tonumber(m.day) == day - 1) and (math.floor(tonumber(m.streak) or 0) + 1) or 1
  m.day, m.streak = day, streak
  UI.statAdd("gifts", 1)
  UI.statMax("gstreak", streak)
  g.phase, g.t, g.kind, g.streak = "open", 0, kind, streak
  sfxPlay("tip", false, 1.0)
  play(synthSine, 1319, 0.08, 0.3, 0.05); play(synthSine, 1760, 0.18, 0.3, 0.13)
  CAFE.write()
  UI.metaSave()
  UI.achCheck()
end
function UI.giftBox(cx, cy, open)                          -- a present: a box with a ribbon and a bow
  local w, h = 44, 30
  gfx.setColor(BLACK); gfx.fillRect(cx - math.floor(w / (2)) + 3, cy - 9, w, h + 3)          -- shadow
  UI.ink("giftbox")
  gfx.setColor(WHITE); gfx.fillRect(cx - math.floor(w / (2)), cy - 12, w, h)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawRect(cx - math.floor(w / (2)), cy - 12, w, h); gfx.setLineWidth(1)
  UI.ink("giftrib")
  gfx.setColor(BLACK); gfx.fillRect(cx - 3, cy - 12, 7, h)                                   -- ribbon down the front
  local ly = open and (cy - 30) or (cy - 18)
  local tilt = open and 6 or 0
  UI.ink("giftbox")
  gfx.setColor(WHITE); gfx.fillRect(cx - math.floor(w / (2)) - 3 + tilt, ly, w + 6, 8)           -- the lid
  gfx.setColor(BLACK); gfx.drawRect(cx - math.floor(w / (2)) - 3 + tilt, ly, w + 6, 8)
  UI.ink("giftrib")
  gfx.setColor(BLACK); gfx.fillRect(cx - 3 + tilt, ly, 7, 8)
  gfx.drawEllipseInRect(cx - 13 + tilt, ly - 8, 12, 9); gfx.drawEllipseInRect(cx + 2 + tilt, ly - 8, 12, 9)   -- the bow
  gfx.drawEllipseInRect(cx - 12 + tilt, ly - 7, 10, 7); gfx.drawEllipseInRect(cx + 3 + tilt, ly - 7, 10, 7)
  gfx.fillRect(cx - 2 + tilt, ly - 4, 5, 5)
  UI.ink("none")
  gfx.setColor(BLACK)
end
function UI.giftDraw()
  local g = CAFE.gift
  local bx, by, bw, bh = 66, 46, 268, 150
  gfx.setColor(BLACK); gfx.fillRoundRect(bx + 4, by + 4, bw, bh, 12)
  UI.ink("giftcard")
  gfx.setColor(WHITE); gfx.fillRoundRect(bx, by, bw, bh, 12)
  gfx.setColor(BLACK); gfx.setLineWidth(3); gfx.drawRoundRect(bx, by, bw, bh, 12); gfx.setLineWidth(1)
  gfx.drawRoundRect(bx + 6, by + 6, bw - 12, bh - 12, 8)
  UI.ink("none")
  if g.phase == "box" then
    drawTC("Daily gift!", 200, by + 14, true)
    local bob = math.floor(math.sin(g.t * 6) * 2 + 0.5)
    local wig = ((g.crank or 0) > 0) and math.floor(math.sin(g.t * 30) * 2) or 0
    UI.giftBox(200 + wig, by + 76 + bob, false)
    drawTC(UI.color and "Press SPACE or click to open" or "Press A or crank to open!", 200, by + 108)
    drawTC("B: later", 200, by + 124)
  else
    local info = UI.GIFTS[g.kind]
    local pop = math.min(1, g.t / 0.25)
    UI.ink(g.kind == "flash" and "inkred" or (g.kind == "tips" and "inkgold" or "inkpink"))
    drawTC(info[1], 200, by + 14, true)
    UI.ink("none")
    local cx, cy = 200, by + 56
    if g.kind == "tips" then                                   -- a big coin
      UI.ink("gold2")
      gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, math.floor(14 * pop))
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, math.floor(11 * pop))
      UI.ink("none")
      if pop >= 1 then drawTC("$", cx + 1, cy - 8, true) end
    elseif g.kind == "stars" then
      UI.ink("star")
      CAFE.star(cx, cy, math.max(1, math.floor(12 * pop)), 1, BLACK)
      UI.ink("none")
    else
      UI.ink("a12")
      if pop >= 1 then UI.saleSticker(cx - 30, cy - 8, 50, BLACK, WHITE) end
      UI.ink("none")
    end
    for i = 1, 8 do                                            -- sparkles round it
      local a = i * math.pi / 4 + g.t * 1.5
      local r = 22 + math.min(g.t, 0.6) * 12
      gfx.setColor(BLACK)
      gfx.fillRect(math.floor(cx + math.cos(a) * r), math.floor(cy + math.sin(a) * r * 0.8), 2, 2)
    end
    drawTC(info[2], 200, by + 80)
    drawTC(info[3], 200, by + 96)
    if (g.streak or 1) >= 2 then UI.pixText("DAY " .. g.streak .. " IN A ROW", 200 - math.floor(UI.pixWidth("DAY " .. g.streak .. " IN A ROW") / (2)), by + 116) end
    drawTC(UI.color and "Press SPACE to go on" or "A: let's go!", 200, by + 127, true)
  end
  gfx.setColor(BLACK)
end

-- ---- grades: after every Cafe order a sticker pops up, then flies into the star meter ----
UI.GRADES = { { "PERFECT!", 0.95, 0.06, "gperfect" }, { "GREAT!", 0.85, 0.045, "ggreat" }, { "GOOD", 0.75, 0.03, "ggood" },
              { "OKAY", 0.5, 0, "gokay" }, { "OOPS!", -1, 0, "goops" } }
UI.STAMP_T = 1.3
function UI.gradeOf(q)
  for i, g in ipairs(UI.GRADES) do if q >= g[2] then return i end end
  return #UI.GRADES
end
function UI.review(c, q)                                     -- the customer's review: it moves the star meter
  local d = G.cafe
  local gi = UI.gradeOf(q)
  local before = d.stars
  if gi == 5 then CAFE.mistake(0.3)
  elseif UI.GRADES[gi][3] > 0 then
    local gain = (UI.GRADES[gi][3] + 0.02 * CAFE.petCount()) * UI.decorReview(d) / math.min(3, 1 + 0.2 * (UI.lvl(d) - 1))
    if (tonumber(d.boostS) or 0) > 0 then gain = gain * 2 end                    -- (the daily gift's review boost)
    CAFE.addStars(gain)
  end
  d.pstreak = (gi == 1) and ((tonumber(d.pstreak) or 0) + 1) or 0
  UI.statAdd("served", 1)
  UI.statMax("pbest", d.pstreak)
  if before < 5 and d.stars >= 5 then G.fiveT = UI.STAMP_T + 0.4 end            -- (once the sticker lands: tell them about prestige)
  G.stamp = { g = gi, t = 0 }
  G.meterHold = UI.STAMP_T - 0.05
  UI.achCheck()
end
function UI.stampImg(gi)
  UI.stampImgs = UI.stampImgs or {}
  local im = UI.stampImgs[gi]
  if im then return im end
  local g = UI.GRADES[gi]
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(g[1])
  local w, h = tw + 40, 30
  im = gfx.image.new(w, h, gfx.kColorClear)
  gfx.pushContext(im)
  UI.ink(g[4])
  gfx.setColor(BLACK); gfx.fillRoundRect(0, 0, w, h, 11)
  gfx.setColor(WHITE); gfx.fillRoundRect(2, 2, w - 4, h - 4, 9)
  gfx.setColor(BLACK)
  for xx = 8, w - 9, 3 do gfx.drawPixel(xx, 5); gfx.drawPixel(xx, h - 6) end      -- a stitched edge
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  drawTC(g[1], math.floor(w / (2)), 7, true)
  if gi <= 2 then CAFE.star(11, 15, 4, 1, BLACK); CAFE.star(w - 12, 15, 4, 1, BLACK)
  elseif gi == 3 then gfx.fillCircleAtPoint(11, 15, 3); gfx.fillCircleAtPoint(w - 12, 15, 3)
  else gfx.drawCircleAtPoint(11, 15, 3); gfx.drawCircleAtPoint(w - 12, 15, 3) end
  UI.ink("none")
  gfx.popContext()
  UI.stampImgs[gi] = im
  return im
end
UI.METER_X, UI.METER_Y, UI.METER_W = 234, 5, 36
function UI.drawStamp()
  local s = G and G.stamp
  if not s then return end
  local im = UI.stampImg(s.g)
  local w, h = im:getSize()
  local t = s.t
  local x, y, sc = 200, 152, 2
  if t < 0.14 then sc = 0.6 + 1.8 * (t / 0.14)                    -- it slaps down a bit big...
  elseif t < 0.24 then sc = 2.4 - 0.4 * ((t - 0.14) / 0.1)         -- ...settles...
  elseif t >= 0.85 then                                            -- ...then shrinks away into the star meter
    local k = math.min(1, (t - 0.85) / (UI.STAMP_T - 0.85))
    local e = k * k
    x = 200 + (UI.METER_X + math.floor(UI.METER_W / (2)) - 200) * e
    y = 152 + (UI.METER_Y + 4 - 152) * e
    sc = 2 - 1.85 * e
  end
  if sc == 2 then im:drawScaled(math.floor(x - w), math.floor(y - h), 2)
  else im:drawScaled(math.floor(x - w * sc / 2), math.floor(y - h * sc / 2), sc) end
end
function UI.playTick(dt)                                     -- (Cafe shifts) the meter, the sticker, the boosts
  local d = G.cafe
  if not d then return end
  if G.meterV == nil then G.meterV = d.stars end
  local s = G.stamp
  if s then
    s.t = s.t + dt
    if s.t >= UI.STAMP_T then G.stamp = nil; G.spark = 0.45 end
  end
  if G.spark then G.spark = G.spark - dt; if G.spark <= 0 then G.spark = nil end end
  if G.starPop then G.starPop.t = G.starPop.t + dt; if G.starPop.t > 0.6 then G.starPop = nil end end
  if (G.meterHold or 0) > 0 then G.meterHold = G.meterHold - dt
  else
    local diff = d.stars - G.meterV
    if math.abs(diff) < 0.003 then G.meterV = d.stars
    else
      local old = G.meterV
      local stepv = diff * math.min(1, dt * 3)
      if math.abs(stepv) < dt * 0.04 then stepv = (diff > 0 and 1 or -1) * math.min(math.abs(diff), dt * 0.04) end
      G.meterV = old + stepv
      if math.floor(G.meterV + 0.001) > math.floor(old + 0.001) then G.starPop = { i = math.floor(G.meterV + 0.001), t = 0 }; sfxGood() end
    end
  end
  if G.fiveT then
    G.fiveT = G.fiveT - dt
    if G.fiveT <= 0 then G.fiveT = nil; say("5 stars! Prestige in the shop's Cafe tab") end
  end
  for _, k in ipairs({ "boostT", "boostS" }) do               -- the daily gift's boosts run down while you play
    local v = tonumber(d[k])
    if v then
      v = v - dt
      if v <= 0 then d[k] = nil; say(k == "boostT" and "Tip boost is over" or "Review boost is over") else d[k] = v end
    end
  end
  UI.statMax("tipshift", G.tips or 0)
  G.achT = (G.achT or 0) - dt
  if G.achT <= 0 then G.achT = 30; UI.clockAch() end
end

-- ---- the top bar in the Cafe: the barista level, the stars, the meter to the next star ----
function UI.levelBadge(xr, cy, lv, onDark)                    -- "LV 2" on a little pill, right edge at xr
  local txt = "LV " .. lv
  local w = UI.pixWidth(txt) + 10
  local x = xr - w
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(onDark and WHITE or BLACK)
  gfx.fillRoundRect(x, cy - 6, w, 12, 5)
  gfx.setColor(onDark and BLACK or WHITE)
  UI.pixText(txt, x + 5, cy - 3)
  UI.ink("none")
  gfx.setColor(BLACK)
  return x
end
function UI.drawStarBar()
  local d = G.cafe
  local v = G.meterV or d.stars
  local lv = UI.lvl(d)
  local bx = UI.levelBadge(166, 9, lv, true)
  UI.drawBoostChip((UI.hudLeft or 60) + 6, bx - 5)
  CAFE.drawStars(178, 9, 5, 11, v, WHITE, lv)
  if G.starPop then                                           -- a new star: a ring of sparkles round it
    local i, t = G.starPop.i, G.starPop.t
    local sx = 178 + (i - 1) * 11
    gfx.setColor(WHITE)
    for k = 0, 5 do
      local a = k * math.pi / 3 + t * 3
      local r = 6 + t * 10
      gfx.drawPixel(math.floor(sx + math.cos(a) * r), math.floor(9 + math.sin(a) * r * 0.7))
    end
  end
  -- the meter: how far along the next star is
  local mx, my, mw = UI.METER_X, UI.METER_Y, UI.METER_W
  local frac = (v >= 4.999) and 1 or (v - math.floor(v + 0.001))
  if frac < 0 then frac = 0 end
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(WHITE)
  gfx.drawRoundRect(mx, my, mw, 9, 4)
  local fw = math.floor((mw - 4) * frac + 0.5)
  if fw > 0 then gfx.fillRoundRect(mx + 2, my + 2, math.max(fw, 3), 5, 2) end
  if v >= 4.999 then                                          -- full: a shine runs along it
    local sx = mx + 2 + (math.floor(frames * 1.2)) % (mw + 20) - 10
    gfx.setColor(BLACK)
    if sx > mx + 2 and sx < mx + mw - 3 then gfx.drawLine(sx, my + 2, sx - 2, my + 6) end
  end
  if G.spark then                                             -- the sticker just landed
    gfx.setColor(WHITE)
    local t = 0.45 - G.spark
    for k = 0, 3 do
      local a = k * math.pi / 2 + 0.6
      local r = 4 + t * 22
      local px, py = math.floor(mx + mw / 2 + math.cos(a) * r * 1.4), math.floor(my + 4 + math.sin(a) * r * 0.5)
      gfx.drawLine(px - 1, py, px + 1, py); gfx.drawLine(px, py - 1, px, py + 1)
    end
  end
  UI.ink("none")
  gfx.setColor(BLACK)
end
function UI.drawBoostChip(x, xmax)                                  -- a boost from the daily gift: what it is and how long it has left
  local d = G.cafe
  local bt, bs = tonumber(d.boostT) or 0, tonumber(d.boostS) or 0
  if bt <= 0 and bs <= 0 then return end
  local kind = (bt > 0 and (bs <= 0 or (math.floor(frames / (60))) % 2 == 0)) and "t" or "s"
  local left = math.ceil(kind == "t" and bt or bs)
  local txt = string.format("%d:%02d", math.floor(left / 60), left % 60)
  local w = UI.pixWidth(txt) + 22
  if x + w > xmax then return end                             -- (no room: a very long shift's clock)
  UI.ink(kind == "t" and "yellow" or "rose")
  gfx.setColor(WHITE)
  gfx.drawRoundRect(x, 3, w, 12, 5)
  if kind == "t" then                                          -- a little coin
    gfx.fillCircleAtPoint(x + 8, 9, 4)
    gfx.setColor(BLACK); gfx.fillRect(x + 8, 7, 1, 5); gfx.drawPixel(x + 7, 8); gfx.drawPixel(x + 9, 10)
  else
    CAFE.star(x + 8, 9, 3, 1, WHITE)
  end
  gfx.setColor(WHITE)
  UI.pixText(txt, x + 15, 6)
  UI.ink("none")
  gfx.setColor(BLACK)
end

-- ---- prestige: at 5 of 5 stars, start the stars again as the next barista level ----
function UI.drawPrestigePreview(cx, cy)
  local lv = UI.lvl(CAFE.cur) + 1
  local bob = math.floor(math.sin(frames * 0.12) * 2 + 0.5)
  UI.ink(UI.starRow and UI.starRow(lv) or "none")
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 24, cy - 22 + bob, 48, 30, 8)
  gfx.setColor(WHITE); gfx.drawRoundRect(cx - 21, cy - 19 + bob, 42, 24, 6)
  gfx.setColor(WHITE)
  local txt = "LV " .. lv
  UI.pixText(txt, cx - math.floor(UI.pixWidth(txt) / (2)), cy - 10 + bob)
  for i = 0, 4 do CAFE.star(cx - 22 + i * 11, cy + 18, 4, (i == 2) and 1 or 0, BLACK) end
  UI.ink("none")
  gfx.setColor(BLACK)
end
function UI.prestige()
  local d = CAFE.cur
  d.lvl = UI.lvl(d) + 1
  d.stars = 0
  CAFE.allC = nil
  CAFE.write()
  UI.metaSave()
  sfxStart()
  CAFE.say("You're a Level " .. d.lvl .. " barista! Stars start again; tips go up.")
end
function UI.askDraw()                                         -- "Prestige?" Yes / No
  local a = CAFE.ask
  local bx, by, bw, bh = 56, 54, 288, 132
  gfx.setColor(WHITE); gfx.fillRoundRect(bx - 2, by - 2, bw + 4, bh + 4, 14)
  gfx.setColor(BLACK)
  CAFE.wobbleBox(bx, by, bw, bh)
  local lv = UI.lvl(CAFE.cur)
  drawTC("Prestige to Barista Lv " .. (lv + 1) .. "?", 200, by + 14, true)
  drawTC("Your stars go back to 0 of 5.", 200, by + 36)
  drawTC("You keep your decor and money,", 200, by + 52)
  drawTC("and every tip is bigger from now on.", 200, by + 68)
  for i = 1, 2 do
    local x = (i == 1) and 86 or 206
    local on = (a.sel == i)
    gfx.setColor(BLACK)
    if on then
      gfx.fillRoundRect(x, by + 94, 108, 28, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2); gfx.drawRoundRect(x, by + 94, 108, 28, 8); gfx.setLineWidth(1)
    end
    drawTC(i == 1 and "Prestige!" or "Not yet", x + 54, by + 101, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if on then CAFE.pointer(x + 84, by + 114) end
  end
end
function UI.askUpdate()
  local a = CAFE.ask
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then a.sel = 3 - a.sel; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonA) then
    CAFE.ask = nil
    if a.sel == 1 then UI.prestige() else sfxClick() end
  elseif pd.buttonJustPressed(pd.kButtonB) then CAFE.ask = nil; sfxClick() end
end

-- ---- the Sale tab: its first line counts down to the next deals ----
function UI.saleTimerRow(y)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(10, y, 273, 19, 5)
  gfx.setColor(WHITE)
  local cx, cy = 22, y + 9                                     -- a little clock, its hand going round
  gfx.drawCircleAtPoint(cx, cy, 6)
  local a = (frames % 60) / 60 * 2 * math.pi
  gfx.drawLine(cx, cy, cx, cy - 4)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(a) * 4 + 0.5), math.floor(cy - math.cos(a) * 4 + 0.5))
  local txt
  local sl = CAFE.sale
  if sl then
    local left = math.max(0, math.ceil((sl.nextMs - pd.getCurrentTimeMilliseconds()) / 1000))
    local clock = string.format("%d:%02d", math.floor(left / 60), left % 60)
    txt = (sl.flash and "FLASH SALE! ALL 50% OFF  " or "NEW DEALS IN  ") .. clock
  else
    txt = "NEW DEALS SOON"
  end
  UI.pixText(txt, 147 - math.floor(UI.pixWidth(txt) / (2)) + 6, y + 6)
  gfx.setColor(BLACK)
end
function CAFE.visRows() return (CAFE.tab == CAFE.SALE_TAB) and 6 or 7 end      -- (the Sale tab's first line is its countdown)
function CAFE.rowY(vi) return 69 + (vi - 1 + 7 - CAFE.visRows()) * 20 end

function pd.update()
  local now = pd.getCurrentTimeMilliseconds()
  local dt = (now - lastMs) / 1000
  lastMs = now
  if dt > 0.1 then dt = 0.1 end
  if dt < 0 then dt = 0 end
  frames = frames + 1
  UI.applyDrinkLook()
  UI.musicTick()
  -- "Title screen" only exists in the menu while you're playing Rush Hour or Evening Chill
  UI.setTitleItem(state == STATE_PLAY and G ~= nil and G.mode ~= "cafe")
  if state ~= STATE_MENU then UI.settings = nil; UI.ach = nil end
  UI.achTick(dt)
  UI.bgSweep()
  UI.bgPreload()

  -- advance a screen fade: dark, switch screens, light again
  if trans then
    trans.t = trans.t + dt
    if trans.phase == "out" and trans.t >= trans.dur then
      trans.fn()
      trans.phase, trans.t = "in", 0
    elseif trans.phase == "in" and trans.t >= trans.dur then
      trans = nil
    end
  end

  -- only the screen we started the frame on reacts to the buttons, so one
  -- button press can't fall straight through into the next screen
  -- (nothing reacts while the screen is fading out)
  if trans == nil or trans.phase == "in" then
    if state == STATE_MENU then
      if UI.settings then UI.updateSettings() elseif UI.ach then UI.updateAch() else updateMenu() end
    elseif state == STATE_PLAY then updatePlay(dt)
    elseif state == STATE_ENTRY then updateEntry(dt)
    elseif state == CAFE.STATE then CAFE.update(dt)
    else updateBoard(dt) end
  end

  gfx.setBackgroundColor(WHITE)
  gfx.clear()
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if state == STATE_MENU then
    if UI.settings then UI.drawSettings() elseif UI.ach then UI.drawAch() else drawMenu() end
  elseif state == STATE_PLAY then
    drawPlay()
  elseif state == STATE_ENTRY then
    drawEntry()
  elseif state == CAFE.STATE then
    CAFE.draw()
  else
    drawBoard()
  end
  UI.drawFade()
  UI.achDraw()
  if pd.drawFPS and state == STATE_PLAY and CAFE.rich() then pd.drawFPS(372, 228) end     -- test cheat save: show the frame rate
end
