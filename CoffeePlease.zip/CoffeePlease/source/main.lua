-- Coffee Please!!!
-- by Christian G   (version 3.5)
--
-- A tiny coffee-shop game for the Playdate.
-- Ring them up, pour the coffee, mix in milk / sugar / espresso / ice, serve it,
-- ring the bell. Two ways to play:
--   RUSH HOUR    - open 7 AM to 2 PM, a fast time-limited shift
--   EVENING CHILL - open 4 PM to 12 AM, no timer: wash cups between customers

import "CoreLibs/graphics"
import "CoreLibs/ui"

local pd <const> = playdate
local gfx <const> = pd.graphics
local snd <const> = pd.sound

----------------------------------------------------------------------
-- Tuning knobs: change these numbers to adjust how the game feels
----------------------------------------------------------------------
local RUSH_SECONDS     <const> = 90    -- Rush Hour is a 90 second countdown
local PATIENCE_SECONDS <const> = 75    -- how long a customer waits at the counter
local LINE_PATIENCE    <const> = 2.0   -- people in line are this many times more patient
local LINE_MAX         <const> = 3     -- people who can wait behind the one ordering
local TIP_MAX          <const> = 250   -- best possible tip, in cents
local WALK_SPEED       <const> = 110   -- barista speed (pixels per second)
local CUST_SPEED       <const> = 140   -- customer speed (pixels per second)
local RECEIPT_CRANK    <const> = 360   -- crank degrees to print the receipt
local MIX_CRANK        <const> = 720   -- crank degrees to mix the drink
local BELL_CRANK       <const> = 270   -- crank degrees to ring the bell
local POUR_RATE_MIN    <const> = 0.25  -- coffee fill per second (gentle tilt)
local POUR_RATE_MAX    <const> = 0.36  -- coffee fill per second (full tilt)
local DINE_IN_CHANCE   <const> = 0.65  -- chance a customer wants to sit down
local STAY_MIN         <const> = 40    -- seconds a customer stays seated (min)
local STAY_MAX         <const> = 90    -- seconds a customer stays seated (max)
local MUSIC_VOLUME     <const> = 0.85   -- the cafe music (0 to 1)
local BEEP_GAIN        <const> = 0.45   -- how loud the little beeps are (0 to 1)

-- Evening Chill mode
local CHILL_ARRIVE_MIN   <const> = 22    -- seconds between customers (min)
local CHILL_ARRIVE_SPAN  <const> = 14    -- ...plus up to this much extra
local CHILL_PATIENCE     <const> = 110   -- how long a customer waits at the counter
local CHILL_DINE_IN      <const> = 0.85  -- chance a customer wants to sit down
local CHILL_STAY_MIN     <const> = 45
local CHILL_STAY_MAX     <const> = 100
local CUPS_TOTAL         <const> = 5     -- ceramic cups in the whole shop
local DISH_CRANK         <const> = 540   -- crank degrees to scrub one cup clean
local COFFEE_KINDS_IN_RUSH <const> = false   -- true = matcha/decaf in Rush Hour too
local KINDS        <const> = { "coffee", "matcha", "decaf", "tea" }
local KIND_WEIGHTS <const> = { 46, 20, 17, 17 }
local KIND_PRICE   <const> = { coffee = 0, matcha = 100, decaf = 0, tea = 50 }   -- cents extra
local WIN, UI, CAFE = {}, {}, {}      -- grouped to stay under the 200-locals limit
UI.SIZE_NAME = { "Small", "Medium", "Large" }
UI.SIZE_FILL = { 0.55, 0.78, 1.0 }          -- where the "fill to here" line sits for each cup size
UI.KIND_NAME = { coffee = "Coffee", matcha = "Matcha", decaf = "Decaf", tea = "Tea" }

-- How likely each amount is in an order (index 1 = none, 2 = one, 3 = two, ...)
local MILK_WEIGHTS  <const> = { 35, 35, 22, 8 }
local SUGAR_WEIGHTS <const> = { 35, 30, 25, 10 }
local SHOT_WEIGHTS  <const> = { 60, 30, 10 }
local ICE_WEIGHTS   <const> = { 55, 25, 14, 6 }

-- The starting high score table (scores are in cents)
local DEFAULT_SCORES <const> = {
  { n = "Grace",       s = 6000 },   -- needs a near-flawless day
  { n = "Christian",   s = 5300 },
  { n = "Kelly",       s = 4600 },
  { n = "Jay",         s = 3900 },
  { n = "Bellasmella", s = 3300 },
  { n = "Rosie",       s = 2700 },
  { n = "Otis",        s = 2200 },
  { n = "Juno",        s = 1700 },
  { n = "Mabel",       s = 1200 },
  { n = "Pip",         s = 800 },
}

-- Evening Chill has no timer, so its table is about how long you keep going
local DEFAULT_CHILL_SCORES <const> = {
  { n = "Grace",       s = 35000 },   -- roughly 25 minutes of near-perfect service
  { n = "Christian",   s = 27000 },
  { n = "Kelly",       s = 20500 },
  { n = "Jay",         s = 15500 },
  { n = "Bellasmella", s = 11500 },
  { n = "Rosie",       s = 8000 },
  { n = "Otis",        s = 5500 },
  { n = "Juno",        s = 3500 },
  { n = "Mabel",       s = 2000 },
  { n = "Pip",         s = 1000 },
}

----------------------------------------------------------------------
-- Basics
----------------------------------------------------------------------
local BLACK <const> = gfx.kColorBlack
local WHITE <const> = gfx.kColorWhite
local CHECK = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 }

local fontNormal = gfx.getSystemFont()
local fontBold = gfx.getSystemFont(gfx.font.kVariantBold)

local function clamp(v, lo, hi)
  if v < lo then return lo elseif v > hi then return hi end
  return v
end

-- cents -> "$3.75"
local function money(c)
  c = math.floor(c + 0.5)
  return string.format("$%d.%02d", c // 100, c % 100)
end

local function drawT(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawText(str, x, y)
end
local function drawTC(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.center)
end
local function drawTR(str, x, y, bold)
  gfx.setFont(bold and fontBold or fontNormal)
  gfx.drawTextAligned(str, x, y, kTextAlignment.right)
end

-- more fill patterns (the three drinks look different in the cup)
local DIAG   = { 0xEE, 0xDD, 0xBB, 0x77, 0xEE, 0xDD, 0xBB, 0x77 }
local STRIPE = { 0xCC, 0xCC, 0x33, 0x33, 0xCC, 0xCC, 0x33, 0x33 }
local TEA = { 0x77, 0xFF, 0xDD, 0xFF, 0x77, 0xFF, 0xDD, 0xFF }
local DRINK_PATTERN = { coffee = CHECK, matcha = DIAG, decaf = STRIPE, tea = TEA }

-- a little ceramic cup (x, y = top-left, s = size 1 small .. 3 big)
local function drawCup(x, y, s, dirty)
  local w, h = 8 * s, 8 * s
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(s >= 2 and 2 or 1)
  gfx.drawRect(x, y, w, h)
  gfx.drawCircleAtPoint(x + w + s, y + h // 2, s + 1)
  gfx.setLineWidth(1)
  if dirty then
    gfx.setPattern(CHECK)
    gfx.fillRect(x + 2, y + h // 2, w - 4, h // 2 - 2)
    gfx.setColor(BLACK)
  end
end

-- a coffee bean (x, y = centre)
local function drawBean(x, y, s)
  s = s or 1
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x - 5 * s, y - 3 * s, 10 * s, 6 * s)
  gfx.setColor(WHITE)
  gfx.drawLine(x - 4 * s, y + s, x + 4 * s, y - s)
  gfx.setColor(BLACK)
end

-- a dashed outline (the empty spot on a shelf)
local function dashedRect(x, y, w, h)
  gfx.setColor(BLACK)
  for dx = 0, w - 3, 6 do
    gfx.drawLine(x + dx, y, x + dx + 2, y)
    gfx.drawLine(x + dx, y + h, x + dx + 2, y + h)
  end
  for dy = 0, h - 3, 6 do
    gfx.drawLine(x, y + dy, x, y + dy + 2)
    gfx.drawLine(x + w, y + dy, x + w, y + dy + 2)
  end
end

----------------------------------------------------------------------
-- Sound: little synth blips, recorded-style effects, and the cafe music
----------------------------------------------------------------------
local function newSynth(wave)
  local ok, s = pcall(function() return snd.synth.new(wave) end)
  if ok then return s end
  return nil
end
local synthSq   = newSynth(snd.kWaveSquare)
local synthSine = newSynth(snd.kWaveSine)

local function play(synth, hz, len, vol, when)
  if synth == nil then return end
  vol = (vol or 0.3) * BEEP_GAIN          -- beeps stay quiet; the music is the star
  pcall(function()
    if when then synth:playNote(hz, vol, len, when) else synth:playNote(hz, vol, len) end
  end)
end

local function sfxTick()  play(synthSq, 1800, 0.02, 0.10) end
local function sfxPop()   play(synthSine, 520, 0.08, 0.30) end
local function sfxWrong() play(synthSq, 110, 0.25, 0.30) end
local function sfxGood()
  play(synthSq, 660, 0.07, 0.25)
  play(synthSq, 990, 0.10, 0.25, 0.08)
end
local function sfxHello()
  play(synthSine, 880, 0.10, 0.30)
  play(synthSine, 1175, 0.20, 0.30, 0.10)
end

-- sound effect files live in the "sounds" folder
local sfx = {}
for _, name in ipairs({ "receipt", "receipt2", "pour", "pour2", "mixer", "plate", "bell", "slide", "tip", "chime", "slurp", "click1", "click2", "click3", "click4", "cup1", "cup2", "dash1", "dash2", "ice1", "ice2", "ice3", "cleaning", "sink" }) do
  local ok, sp = pcall(function() return snd.sampleplayer.new("sounds/" .. (name == "receipt2" and "receipt" or name)) end)
  if ok and sp then sfx[name] = sp end
end

local function sfxPlay(name, loop, vol, rate)
  local sp = sfx[name]
  if sp == nil then return end
  pcall(function()
    if vol then sp:setVolume(vol) end
    if rate then sp:setRate(rate) end
    if loop then
      if not sp:isPlaying() then sp:play(0) end
    else
      sp:play(1)
    end
  end)
end

-- the pretty register chime when a shift starts
local function sfxStart()
  if sfx.chime then
    sfxPlay("chime", false, 0.9)
  else
    play(synthSine, 1568, 0.25, 0.5)
    play(synthSine, 2093, 0.25, 0.5, 0.12)
    play(synthSine, 2637, 0.40, 0.5, 0.24)
  end
end

local function sfxStop(name)
  local sp = sfx[name]
  if sp then pcall(function() sp:stop() end) end
  if name == "pour" and sfx.pour2 then pcall(function() sfx.pour2:stop() end) end
end

-- the coffee pour: one of the two pour recordings, left alone while it plays
local function sfxPour()
  local a, b = sfx.pour, sfx.pour2
  if (a and a:isPlaying()) or (b and b:isPlaying()) then return end
  local name = (b and math.random() < 0.5) and "pour2" or "pour"
  sfxPlay(name, false, 1.0, 1.0)
end

-- cups clinking and ice cubes: one of the recordings, picked at random
local function sfxRandom(names)
  local list = {}
  for _, n in ipairs(names) do if sfx[n] then list[#list + 1] = n end end
  if #list == 0 then return false end
  sfxPlay(list[math.random(#list)], false, 1.0)
  return true
end
local function sfxCup() if not sfxRandom({ "cup1", "cup2" }) then sfxPlay("plate", false, 0.6) end end
local function sfxClick()
  if not sfxRandom({ "click1", "click2", "click3", "click4" }) then play(synthSq, 1200, 0.03, 0.15) end
end
local function sfxDash() if not sfxRandom({ "dash1", "dash2" }) then sfxPop() end end   -- a second of pouring
local function sfxIce() if not sfxRandom({ "ice1", "ice2", "ice3" }) then sfxPop() end end

-- the slurp that greets you when the game launches
if sfx.slurp then sfxPlay("slurp", false, 1.0) end

-- background music (loops forever); the Menu button has a Music check box to switch it off
do
  local ok, fp = pcall(function() return snd.fileplayer.new("music/cafe") end)
  if ok and fp then
    UI.musicPlayer = fp
    UI.musicOn, UI.musicNow = true, nil
    local ok2, sp = pcall(function() return snd.fileplayer.new("music/shop") end)   -- the coffee supply website's tune
    if ok2 and sp then pcall(function() sp:setVolume(MUSIC_VOLUME) end); UI.shopPlayer = sp end
    pcall(function()
      fp:setVolume(MUSIC_VOLUME)
    end)
    pcall(function()
      local menu = pd.getSystemMenu()
      if menu and menu.addCheckmarkMenuItem then
        UI.musicItem = menu:addCheckmarkMenuItem("Music", true, function(on) UI.musicOn = on end)
      end
    end)
  end
end

----------------------------------------------------------------------
-- Layout
----------------------------------------------------------------------
local PLAYER_Y <const> = 58    -- the barista walks along behind the counter
local WALK_MIN <const> = 28
local WALK_MAX = 344
local JAR_X    = 368          -- the tip jar

local REG_X, REG_Y = 62, 136      -- where the customer being served stands
local PICK_X, PICK_Y = 308, 136   -- where they wait for their drink
local DOOR_X <const> = 28         -- customers walk in and out here (bottom left)
local LINE_SLOTS = { { 62, 166 }, { 62, 196 }, { 62, 226 } }
local DISH_X = 332                -- Evening Chill: where used cups get dropped off

local RUSH_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 62,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 144, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 226, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 308, stage = 4 },
}
-- Evening Chill squeezes in a dish bin, and the tip jar moves right
local CHILL_STATIONS = {
  { id = "register", name = "Register", label = "REGISTER", x = 56,  stage = 1 },
  { id = "coffee",   name = "Coffee",   label = "COFFEE",   x = 128, stage = 2 },
  { id = "mixer",    name = "Mixer",    label = "MIXER",    x = 200, stage = 3 },
  { id = "serve",    name = "Pick up",  label = "PICK UP",  x = 272, stage = 4 },
  { id = "dishes",   name = "Dishes",   label = "DISHES",   x = 332 },
}
local STATIONS = RUSH_STATIONS
local STAGE_ST = {}               -- STAGE_ST[1..4] = the station for each order step

local function stationById(id)
  for _, st in ipairs(STATIONS) do
    if st.id == id then return st end
  end
  return nil
end

local function setLayout(mode)
  do
    STATIONS = CHILL_STATIONS
    JAR_X, WALK_MAX = 384, 356
    REG_X, PICK_X, DISH_X = 56, 272, 332
    LINE_SLOTS = { { 56, 166 }, { 56, 196 }, { 56, 226 } }
  end
  STAGE_ST = {}
  for _, st in ipairs(STATIONS) do
    if st.stage then STAGE_ST[st.stage] = st end
  end
end
setLayout("rush")

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "ENT" }
local GREETS = { "Coffee please!", "One coffee, please!", "Morning! Coffee?", "Coffee time!" }

-- Round tables and where people sit (the last table is in the corner nook)
local TABLES = {
  { x = 132, y = 208, r = 13 }, { x = 186, y = 208, r = 13 },
  { x = 240, y = 208, r = 13 }, { x = 294, y = 208, r = 13 },
  { x = 350, y = 180, r = 13 },            -- the table inside the nook
}
local SEATS = {
  { x = 115, y = 208, t = 1 }, { x = 149, y = 208, t = 1 },
  { x = 169, y = 208, t = 2 }, { x = 203, y = 208, t = 2 },
  { x = 223, y = 208, t = 3 }, { x = 257, y = 208, t = 3 },
  { x = 277, y = 208, t = 4 }, { x = 311, y = 208, t = 4 },
  -- the L-shaped nook: three seats up the wall, two along the bottom
  { x = 386, y = 164, t = 5 }, { x = 386, y = 186, t = 5 }, { x = 386, y = 212, t = 5 },
  { x = 362, y = 218, t = 5 }, { x = 338, y = 218, t = 5 },
}

----------------------------------------------------------------------
-- High scores (saved on the Playdate)
----------------------------------------------------------------------
local boards = { rush = {}, chill = {} }     -- sorted lists of { n = name, s = cents }
local lastInitials = "AAA"

local function saveScores()
  pd.datastore.write({ v = 5, rush = boards.rush, chill = boards.chill, last = lastInitials, crank = UI.crankPour == true })
end

do
  local function take(dst, src)
    if type(src) ~= "table" then return end
    for _, e in ipairs(src) do
      if type(e) == "table" and type(e.n) == "string" and type(e.s) == "number" then
        dst[#dst + 1] = { n = e.n, s = e.s }
      end
    end
  end
  local saved = pd.datastore.read()
  if saved then
    if saved.v == 5 then
      take(boards.rush, saved.rush)
      take(boards.chill, saved.chill)
    elseif saved.v == 4 then
      take(boards.chill, saved.chill)     -- Rush Hour got harder in 2.3: fresh table
    elseif saved.v == 3 then
      take(boards.rush, saved.scores)       -- version 1.x saved only the Rush Hour table
    end
    if type(saved.last) == "string" and #saved.last == 3 then lastInitials = saved.last end
    if saved.crank == true then UI.crankPour = true end
  end
  if #boards.rush == 0 then
    for _, e in ipairs(DEFAULT_SCORES) do boards.rush[#boards.rush + 1] = { n = e.n, s = e.s } end
  end
  if #boards.chill == 0 then
    for _, e in ipairs(DEFAULT_CHILL_SCORES) do boards.chill[#boards.chill + 1] = { n = e.n, s = e.s } end
  end
  table.sort(boards.rush, function(a, b) return a.s > b.s end)
  table.sort(boards.chill, function(a, b) return a.s > b.s end)
end

-- returns the rank (1 = best) the new score landed at
local function insertScore(mode, name, s)
  local list = boards[mode]
  local rank = #list + 1
  for i, e in ipairs(list) do
    if s > e.s then rank = i; break end
  end
  table.insert(list, rank, { n = name, s = s })
  while #list > 100 do table.remove(list) end
  lastInitials = name
  saveScores()
  return rank
end

----------------------------------------------------------------------
-- Game state
----------------------------------------------------------------------
local STATE_MENU  <const> = 1
local STATE_PLAY  <const> = 2
local STATE_ENTRY <const> = 3   -- closing time: type your initials
local STATE_BOARD <const> = 4   -- the high score table

local state = STATE_MENU
local frames = 0
local lastMs = pd.getCurrentTimeMilliseconds()
local G = nil                   -- the current day (nil on the title screen)
local board = { mode = "view", rank = nil, m = "rush", view = "rush", t = 0 }
local entry = { letters = { 0, 0, 0 }, cur = 1, crank = 0 }
local menuSel = 1                   -- title screen: 1 Cafe, 2 Rush Hour, 3 Evening Chill, 4 High scores

-- screen fades: everything that changes screen goes through transitionTo()
local FADE_SECONDS <const> = 0.5
local trans = nil                   -- { phase = "out" or "in", t = seconds, fn = function }
local endDay, setShiftMenu          -- (defined further down)

local function transitionTo(fn)
  if trans == nil then trans = { phase = "out", t = 0, fn = fn } end
end

-- mix the clock and frame count into the random seed so every day differs
local function reseed()
  local secs, ms = pd.getSecondsSinceEpoch()
  local mixed = (secs or 0) + (ms or 0) * 7 + pd.getCurrentTimeMilliseconds() * 13 + frames * 101
  math.randomseed(math.floor(mixed))
  math.random(); math.random(); math.random()
end

-- The window: the weather changes now and then, people stroll past
WIN.FX = { "rain", "wind", "leaves", "snow", "clouds" }      -- (snow never mixes with rain or leaves; wind goes with anything)

function WIN.newWindow()
  local fx = { rain = false, wind = false, leaves = false, snow = false, clouds = false }
  local r, n = math.random(), 0
  if r < 0.22 then n = 0 elseif r < 0.67 then n = 1 elseif r < 0.90 then n = 2 else n = 3 end
  local pool = { 1, 2, 3, 4, 5 }
  for _ = 1, n do
    local k = table.remove(pool, math.random(#pool))
    fx[WIN.FX[k]] = true
  end
  if fx.snow then fx.rain = false; fx.leaves = false end
  local parts = {}
  if fx.clouds then                                  -- already cloudy when you arrive
    parts[1] = { k = "cloud", x = 22, y = 29, vx = 4 + math.random() * 3, vy = 0, s = 1 }
    parts[2] = { k = "cloud", x = 52, y = 31, vx = 4 + math.random() * 3, vy = 0, s = 0 }
  end
  return { fx = fx, nextChange = 70 + math.random() * 70, acc = { rain = 0, wind = 0, leaves = 0, snow = 0, clouds = 0 },
           parts = parts, walkers = {}, walkIn = 4 + math.random() * 8,
           skyIn = 12 + math.random() * 25 }
end

function WIN.updateWindow(dt)
  local w = G.win
  w.nextChange = w.nextChange - dt
  if w.nextChange <= 0 then                       -- slow: one effect flips every 70-140 s
    local k = WIN.FX[math.random(#WIN.FX)]
    w.fx[k] = not w.fx[k]
    if w.fx[k] then                                -- snow and rain/leaves never share a sky
      if k == "snow" then w.fx.rain = false; w.fx.leaves = false
      elseif k == "rain" or k == "leaves" then w.fx.snow = false end
    end
    w.nextChange = 70 + math.random() * 70
  end
  -- now and then the sun or the moon drifts slowly across the window
  if w.sky then
    w.sky.t = w.sky.t + dt
    if w.sky.t >= w.sky.dur or (w.sky.kind == "sun" and w.fx.snow) then w.sky = nil; w.skyIn = 40 + math.random() * 80 end
  else
    w.skyIn = w.skyIn - dt
    if w.skyIn <= 0 then
      local sun = math.random() < 0.5 and not (w.fx.rain or w.fx.snow)
      w.sky = { kind = sun and "sun" or "moon", t = 0, dur = 40 + math.random() * 20 }
    end
  end
  local rate = { rain = 16, wind = 1.5, leaves = 0.9, snow = 7, clouds = 0.16 }
  for _, k in ipairs(WIN.FX) do
    if w.fx[k] then w.acc[k] = w.acc[k] + rate[k] * dt end
    while w.acc[k] >= 1 do
      w.acc[k] = w.acc[k] - 1
      if k == "rain" then
        local sl = w.fx.wind and 14 or -3
        w.parts[#w.parts + 1] = { k = "rain", x = 12 + math.random() * 56, y = 21, vx = sl, vy = 70 + math.random() * 25 }
      elseif k == "clouds" then
        w.parts[#w.parts + 1] = { k = "cloud", x = 7, y = 27 + math.random() * 5, vx = 4 + math.random() * 3, vy = 0,
                                  s = math.random(0, 1) }
      elseif k == "snow" then
        w.parts[#w.parts + 1] = { k = "snow", x = 12 + math.random() * 56, y = 21, vx = 0,
                                  vy = 9 + math.random() * 8, ph = math.random() * 6 }
      elseif k == "wind" then
        w.parts[#w.parts + 1] = { k = "wind", x = 8, y = 26 + math.random() * 18, vx = 26 + math.random() * 14, vy = 0,
                                  ph = math.random() * 6 }
      else
        w.parts[#w.parts + 1] = { k = "leaf", x = 15 + math.random() * 50, y = 21, vx = 0,
                                  vy = 12 + math.random() * 8, ph = math.random() * 6 }
      end
    end
  end
  for i = #w.parts, 1, -1 do
    local q = w.parts[i]
    if q.k == "snow" then
      q.ph = q.ph + dt * 1.6
      q.x = q.x + math.sin(q.ph) * 6 * dt + (w.fx.wind and 14 * dt or 0)
    elseif q.k == "leaf" then
      q.ph = q.ph + dt * 2.2
      q.x = q.x + math.sin(q.ph) * 12 * dt + (w.fx.wind and 10 * dt or 0)
    elseif q.k == "wind" then
      q.ph = q.ph + dt * 4
      q.x = q.x + q.vx * dt
    else
      q.x = q.x + q.vx * dt
    end
    q.y = q.y + q.vy * dt
    if q.x > 76 or q.x < 6 or q.y > 49 then table.remove(w.parts, i) end
  end
  -- someone walks by now and then (never a crowd)
  w.walkIn = w.walkIn - dt
  if w.walkIn <= 0 and #w.walkers == 0 then
    local dir = (math.random() < 0.5) and 1 or -1
    w.walkers[1] = { x = dir == 1 and 6 or 76, dir = dir, speed = 15 + math.random() * 8, t = 0,
                     umbrella = w.fx.rain }
    w.walkIn = (w.gap or 14) + math.random() * (w.gapSpan or 18)
  end
  for i = #w.walkers, 1, -1 do
    local q = w.walkers[i]
    q.x = q.x + q.dir * q.speed * dt
    q.t = q.t + dt * 9
    if q.x < 2 or q.x > 80 then table.remove(w.walkers, i) end
  end
end

local function newGame(mode)
  mode = mode or "rush"
  reseed()
  local room = (mode ~= "cafe") and CAFE.randomRoom(mode) or nil      -- rush / chill: a new random room each time
  local dd = room or CAFE.cur
  CAFE.applyLayout(dd)
  setLayout(mode)
  G = {
    deco = room,
    mode = mode,
    t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
    px = STATIONS[1].x, moving = false, walk = 0,
    cupMax = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL,
    seatLimit = CAFE.seatsOf(dd.seatStep),
    seatOff = CAFE.seatOffOf(dd),
    seatCount = CAFE.seatCountOf(dd),
    cafe = (mode == "cafe") and CAFE.cur or nil,
    cups = { shelf = (mode == "cafe") and CAFE.cur.cups or CUPS_TOTAL, dirty = 0, hand = 0 },   -- dishes
    sink = { state = "empty", progress = 0, angle = 0, t = 0 },
    lastCount = nil, ending = false,
    flow = { m = 0.5, target = 0.5, timer = 20 },
    pets = (mode == "cafe") and CAFE.makePets() or nil,
    win = WIN.newWindow(),
    sel = "down",       -- Evening Chill: "up" = the wall shelf, "down" = the counter
    st = nil,           -- which station panel is open ("register", ...)
    cust = nil,         -- the customer being served right now
    line = {},          -- people waiting in line (line[1] is next)
    others = {},        -- people walking to a seat, sitting, or leaving
    seats = {},         -- seats[i] = the customer sitting there
    arriveIn = 0.8,     -- seconds until the next customer shows up
    stepT = 0,          -- short pause before the next person steps up
    door = 0,           -- 0 = closed, 1 = open
    popups = {},        -- floating "+$2.00" texts
    msg = nil, msgT = 0,
    endT = 0,
  }
  setShiftMenu(mode ~= "rush", mode == "cafe")
end

local function say(str)
  G.msg = str
  G.msgT = 2.2
end

local function addPopup(str, x, y, life, small)
  G.popups[#G.popups + 1] = { s = str, x = x, y = y, t = 0, life = life or 1.8, small = small }
end

----------------------------------------------------------------------
-- Crank helper (shows the "use the crank" hint if the crank is docked)
----------------------------------------------------------------------
local function crankHelpStart()
  local ci = pd.ui and pd.ui.crankIndicator
  if ci and ci.start then ci:start() end
end

local function crankHelpDraw()
  if not pd.isCrankDocked() then return end
  local ci = pd.ui and pd.ui.crankIndicator
  if ci == nil then return end
  if ci.update then ci:update() elseif ci.draw then ci:draw() end
end

----------------------------------------------------------------------
-- Customers
----------------------------------------------------------------------
local function weighted(w)
  local total = 0
  for _, v in ipairs(w) do total = total + v end
  local r = math.random() * total
  for i, v in ipairs(w) do
    r = r - v
    if r < 0 then return i - 1 end
  end
  return #w - 1
end

-- lines of text for the speech bubble (after the greeting)
local function orderLines(o)
  local lines = UI.orderLines0(o)
  table.insert(lines, 1, UI.SIZE_NAME[o.size or 3] .. " size")
  return lines
end

function UI.orderLines0(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. " espresso" end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 then
    if o.kind and o.kind ~= "coffee" then return { "Just plain, thanks!" } end
    return { "Just black, thanks!" }
  end
  if #items == 1 then return { "With " .. items[1] } end
  if #items == 2 then return { "With " .. items[1] .. " & " .. items[2] } end
  if #items == 3 then return { "With " .. items[1] .. ", " .. items[2], "& " .. items[3] } end
  return { "With " .. items[1] .. ", " .. items[2] .. ",", items[3] .. " & " .. items[4] }
end

-- short version for the panel headers
local function orderShort(o)
  local items = {}
  if o.shot > 0 then items[#items + 1] = o.shot .. (o.shot == 1 and " shot" or " shots") end
  if o.milk > 0 then items[#items + 1] = o.milk .. " milk" end
  if o.sugar > 0 then items[#items + 1] = o.sugar .. " sugar" end
  if o.ice > 0 then items[#items + 1] = o.ice .. " ice" end
  if #items == 0 and o.kind == "coffee" then return "Black coffee" end
  table.insert(items, 1, UI.SIZE_NAME[o.size or 3] .. " " .. UI.KIND_NAME[o.kind or "coffee"])
  return table.concat(items, ", ")
end

local function newCustomer()
  local o = { milk = weighted(MILK_WEIGHTS), sugar = weighted(SUGAR_WEIGHTS),
              shot = weighted(SHOT_WEIGHTS), ice = weighted(ICE_WEIGHTS), size = math.random(1, 3) }
  -- keep orders sensible: nobody wants more than 5 extras
  while o.milk + o.sugar + o.shot + o.ice > 5 do
    if o.sugar > 0 then o.sugar = o.sugar - 1
    elseif o.ice > 0 then o.ice = o.ice - 1
    elseif o.milk > 0 then o.milk = o.milk - 1
    else o.shot = o.shot - 1 end
  end
  local chill = (G ~= nil and G.mode ~= "rush")
  o.kind = KINDS[weighted(KIND_WEIGHTS) + 1]
  if o.kind == "matcha" or o.kind == "tea" or o.kind == "decaf" then o.shot = 0 end      -- no espresso in those
  local greet = GREETS[math.random(#GREETS)]
  if o.kind == "matcha" then greet = "One matcha, please!"
  elseif o.kind == "decaf" then greet = "Decaf, please!"
  elseif o.kind == "tea" then greet = "Tea, please!" end
  return {
    x = DOOR_X, y = 258, path = {}, walk = 0,
    state = "line",       -- line, active, toSeat, seated, leaving
    stage = 0,            -- 0 stepping up, 1 register, 2 coffee, 3 mixer, 4 serve
    order = o,
    price = 300 + o.milk * 50 + o.sugar * 25 + o.shot * 100 + o.ice * 25 + KIND_PRICE[o.kind],   -- cents
    greet = greet,
    look = math.random(1, 4),
    patience = 1.0,       -- 1 = fresh, 0 = walks out
    q = 1.0,              -- order quality (mistakes lower it, it decides the tip)
    dine = math.random() < (chill and CHILL_DINE_IN or DINE_IN_CHANCE) and (G == nil or (G.seatCount or G.seatLimit) > 0),
    hasCup = false,       -- Evening Chill: carrying one of the shop's ceramic cups
    seat = nil, stay = 0,
    reg = { digits = "", state = "type", cur = 5, crank = 0, flash = 0, tick = 0 },
    cof = { fill = 0, tilt = 0, base = nil,
            phase = "pick", pick = nil },
    mix = { milk = 0, sugar = 0, shot = 0, ice = 0, phase = 1, progress = 0, angle = 0, tick = 0, hold = 0 },
    srv = { phase = 1, slide = 0, crank = 0, ding = 0, tick = 0, recent = 0 },
  }
end

-- Walking around things: tables (with their chairs) and floor decor are obstacles that people and pets go round.
-- An obstacle is a short line with a thickness; one that you start or finish inside is ignored (your own seat, a pet's bed).
function CAFE.obstacles()
  local obs = {}
  local lim = G.seatLimit or 0
  for ti, t in ipairs(TABLES) do
    local fs = 2 * ti - 1
    if fs <= lim and not (G.seatOff and G.seatOff[fs]) then
      obs[#obs + 1] = { x1 = t.x - 17, y1 = t.y, x2 = t.x + 17, y2 = t.y, r = 15 }
    end
  end
  local d = G.cafe or G.deco
  if d then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] then
        local sl = CAFE.FSLOT[d.place[it.id]]
        obs[#obs + 1] = { x1 = sl[1], y1 = sl[2] + 6, x2 = sl[1], y2 = sl[2] + 6, r = 11 }
      end
    end
  end
  return obs
end

function CAFE.dist(o, px, py)                  -- how far a point is from an obstacle's line
  local dx, dy = o.x2 - o.x1, o.y2 - o.y1
  local len2 = dx * dx + dy * dy
  local t = 0
  if len2 > 0 then t = clamp(((px - o.x1) * dx + (py - o.y1) * dy) / len2, 0, 1) end
  local qx, qy = o.x1 + dx * t, o.y1 + dy * t
  return math.sqrt((px - qx) ^ 2 + (py - qy) ^ 2)
end

function CAFE.firstBlock(obs, skip, ax, ay, bx, by)     -- the first obstacle a straight walk would go through
  local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
  local n = math.max(1, math.floor(len / 3))
  for i = 1, n do
    local px, py = ax + (bx - ax) * i / n, ay + (by - ay) * i / n
    for _, o in ipairs(obs) do
      if not skip[o] and CAFE.dist(o, px, py) < o.r then return o end
    end
  end
  return nil
end

function CAFE.routeR(obs, skip, ax, ay, bx, by, depth)
  local hit = CAFE.firstBlock(obs, skip, ax, ay, bx, by)
  if not hit or depth >= 4 then return {} end
  local m = hit.r + 5
  local cx, cy = (hit.x1 + hit.x2) / 2, (hit.y1 + hit.y2) / 2
  local cand = {
    { hit.x1 - m, hit.y1 }, { hit.x2 + m, hit.y2 }, { cx, hit.y1 - m }, { cx, hit.y1 + m },
    { hit.x1 - m * 0.7, hit.y1 - m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 - m * 0.7 },
    { hit.x1 - m * 0.7, hit.y1 + m * 0.7 }, { hit.x2 + m * 0.7, hit.y1 + m * 0.7 },
  }
  local best, bc
  for _, w in ipairs(cand) do
    local wx, wy = clamp(w[1], 14, 392), clamp(w[2], 124, 238)
    local inside = false
    for _, o in ipairs(obs) do if not skip[o] and CAFE.dist(o, wx, wy) < o.r then inside = true end end
    if not inside and (wx - ax) ^ 2 + (wy - ay) ^ 2 > 9 and not CAFE.firstBlock(obs, skip, ax, ay, wx, wy) then
      local cost = math.sqrt((wx - ax) ^ 2 + (wy - ay) ^ 2) + math.sqrt((bx - wx) ^ 2 + (by - wy) ^ 2)
      if bc == nil or cost < bc then best, bc = { wx, wy }, cost end
    end
  end
  if not best then return {} end
  local out = { best }
  for _, w in ipairs(CAFE.routeR(obs, skip, best[1], best[2], bx, by, depth + 1)) do out[#out + 1] = w end
  return out
end

function CAFE.route(ax, ay, bx, by)            -- waypoints (not counting the start or the goal) that go round things
  if not G then return {} end
  local obs = CAFE.obstacles()
  local skip = {}
  for _, o in ipairs(obs) do
    if CAFE.dist(o, ax, ay) < o.r + 1 or CAFE.dist(o, bx, by) < o.r + 1 then skip[o] = true end
  end
  return CAFE.routeR(obs, skip, ax, ay, bx, by, 0)
end

function CAFE.pointBlocked(x, y)
  if not G then return false end
  for _, o in ipairs(CAFE.obstacles()) do if CAFE.dist(o, x, y) < o.r then return true end end
  return false
end

function CAFE.avoidPath(sx, sy, pts)           -- a list of stops, with the detours put in
  local out = {}
  for _, pt in ipairs(pts) do
    for _, w in ipairs(CAFE.route(sx, sy, pt[1], pt[2])) do out[#out + 1] = { w[1], w[2] } end
    out[#out + 1] = pt
    sx, sy = pt[1], pt[2]
  end
  return out
end

-- walking: customers follow a list of waypoints
local function routeTo(c, x, y)
  if c.y > 236 then
    c.path = CAFE.avoidPath(c.x, c.y, { { DOOR_X, 228 }, { x, y } })     -- still outside: come in through the door first
  else
    c.path = CAFE.avoidPath(c.x, c.y, { { x, y } })
  end
end

local function moveAlong(c, dt)
  local p = c.path[1]
  if p == nil then return end
  local dx, dy = p[1] - c.x, p[2] - c.y
  local d = math.sqrt(dx * dx + dy * dy)
  local step = CUST_SPEED * dt
  if d <= step then
    c.x, c.y = p[1], p[2]
    table.remove(c.path, 1)
    if p[3] == "drop" and c.hasCup then          -- leave the used cup in the dish bin
      c.hasCup = false
      G.cups.dirty = G.cups.dirty + 1
      sfxPlay("plate", false, 0.5)
    end
  else
    c.x = c.x + dx / d * step
    c.y = c.y + dy / d * step
  end
  c.walk = c.walk + dt * 14
end

local function leaveRoute(c)
  c.state = "leaving"
  local p = {}
  local sx, sy = c.x, c.y
  if c.hasCup then
    p[#p + 1] = { DISH_X, 152, "drop" }        -- bring the cup back to the dish bin first
    sx, sy = DISH_X, 152
  end
  local lx = sx
  if lx < 96 then
    lx = 96                                    -- slip out sideways, not through the line
    p[#p + 1] = { lx, sy }
  end
  if sy < 232 then p[#p + 1] = { lx, 232 } end
  p[#p + 1] = { DOOR_X, 234 }
  p[#p + 1] = { DOOR_X, 270 }
  c.path = CAFE.avoidPath(c.x, c.y, p)
end

local function relineup()
  for i, c in ipairs(G.line) do routeTo(c, LINE_SLOTS[i][1], LINE_SLOTS[i][2]) end
end

local function freeSeat()
  local free = {}
  for i = 1, G.seatLimit do
    if G.seats[i] == nil and not (G.seatOff and G.seatOff[i]) then free[#free + 1] = i end
  end
  if #free == 0 then return nil end
  return free[math.random(#free)]
end

----------------------------------------------------------------------
-- Stations
----------------------------------------------------------------------
local function stopLoops(keepMixer)
  sfxStop("pour")
  if not keepMixer then sfxStop("mixer") end
  sfxStop("sink")
  sfxStop("cleaning")
end

local function closeStation(keepMixer)
  if G and G.st == "coffee" then pcall(pd.stopAccelerometer) end
  stopLoops(keepMixer)
  if G then G.st = nil end
end

local function nearStation()
  for _, st in ipairs(STATIONS) do
    if math.abs(G.px - st.x) <= 22 then return st end
  end
  return nil
end

-- Evening Chill: the cup shelf hangs on the wall above the barista
local SHELF_X1, SHELF_X2 = 104, 194
local function nearWall()
  return G.px >= SHELF_X1 and G.px <= SHELF_X2
end

-- true when the shelf (up) is what A would open, false when it's the counter (down)
local function shelfSelected()
  if not nearWall() then return false end
  return G.sel == "up" or nearStation() == nil
end

local function tryOpen(st)
  if st.id == "dishes" then                          -- no customer needed
    local sk = G.sink
    if sk.state == "empty" and G.cups.dirty == 0 then
      say("No dirty cups right now.")
      sfxWrong()
      return
    end
    G.st = st.id
    sfxClick()
    if sk.state == "empty" then                      -- just crank: the first dirty cup is already in the sink
      G.cups.dirty = G.cups.dirty - 1
      sk.state, sk.progress, sk.angle = "washing", 0, 0
      sfxCup()
    end
    if sk.state == "washing" then crankHelpStart() end
    return
  end
  local c = G.cust
  if c == nil or c.stage < 1 then
    say("Waiting for a customer...")
    return
  end
  if c.stage ~= st.stage then
    if c.stage > st.stage then
      say(st.name .. " is already done!")
      if st.id == "mixer" then CAFE.mistake(0.03) end        -- clicked the mixer out of habit
    else
      say("Do the " .. STAGE_ST[c.stage].name .. " first!")
    end
    sfxWrong()
    return
  end
  if st.id == "serve" and #c.path > 0 then
    say("They're still walking over!")
    return
  end
  if st.id == "register" and G.cups.hand > 0 then
    say("Put the clean cups on the shelf first!")
    sfxWrong()
    return
  end
  if st.id == "coffee" and c.dine and not c.hasCup then
    if G.cups.shelf > 0 then                      -- grab a clean cup from the shelf
      G.cups.shelf = G.cups.shelf - 1
      c.hasCup = true
      sfxCup()
    else
      c.dine = false
    end
  end
  G.st = st.id
  sfxClick()
  if st.id == "serve" and c.srv.phase == 1 then
    c.srv.phase = 2                    -- A at the counter slides the plate right away
    sfxPlay("slide", false, 1.0)
  end
  if st.id == "coffee" then
    pd.startAccelerometer()
    c.cof.base = nil
  end
  if (st.id == "register" and c.reg.state == "crank")
      or (st.id == "mixer" and c.mix.phase == 2) then
    crankHelpStart()
  end
end

-- ---- the order is finished: pay, tip, send the customer off ----------
local function finishOrder(c)
  local q = clamp(c.q, 0, 1)
  c.final = q
  local tip = 0
  if q >= 0.5 then
    local f = 0.4 + 0.6 * c.patience
    local pm = (G.mode == "cafe") and (1 + 0.15 * CAFE.petCount()) or 1      -- pets help the tips
    if c.dine then pm = pm * 1.3 end                                           -- dining in tips better
    tip = math.floor(TIP_MAX * q * q * f * pm / 25 + 0.5) * 25
  end
  G.cash = G.cash + c.price
  G.tips = G.tips + tip
  G.served = G.served + 1
  if G.mode == "cafe" then
    if q >= 0.75 then CAFE.addStars(0.04 + 0.02 * CAFE.petCount()) elseif q < 0.5 then CAFE.mistake(0.3) end
  end
  addPopup("+" .. money(c.price), stationById("register").x, 54, 1.8)
  if tip > 0 then
    addPopup("+" .. money(tip), JAR_X, 54, 2.2, true)
    sfxPlay("tip")
  else
    addPopup("no tip", JAR_X, 54, 1.8, true)
  end
  if q >= 0.95 then say("Perfect order!")
  elseif q >= 0.75 then say("Nice work!")
  elseif q >= 0.5 then say("Good enough.")
  else say("Ouch... that was off.") end

  closeStation()
  G.cust = nil
  G.stepT = 0.7
  -- some people sit down with their drink, some take it to go
  if c.dine then
    local s = freeSeat()
    if s then
      G.seats[s] = c
      c.seat = s
      c.state = "toSeat"
      c.path = CAFE.avoidPath(c.x, c.y, { { SEATS[s].x, SEATS[s].y } })
    else
      leaveRoute(c)           -- no free seat: they head out
    end
  else
    leaveRoute(c)
  end
  G.others[#G.others + 1] = c
end

-- ---- 1. register -----------------------------------------------------
local function regPress(c, key)
  local r = c.reg
  if key == "DEL" then
    r.digits = string.sub(r.digits, 1, -2)
    sfxClick()
  elseif key == "ENT" then
    local val = tonumber(r.digits) or 0
    if val == c.price then
      r.state = "crank"
      crankHelpStart()
      sfxGood()
    else
      c.q = c.q - 0.2
      CAFE.mistake(0.05)
      r.digits = ""
      r.flash = 0.9
      sfxWrong()
    end
  else
    if #r.digits < 4 then r.digits = r.digits .. key end
    sfxClick()
  end
end

local function updateRegister(c, dt)
  local r = c.reg
  if r.flash > 0 then r.flash = r.flash - dt end
  if r.state == "type" then
    local col = (r.cur - 1) % 3
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if col == 0 then r.cur = r.cur + 2 else r.cur = r.cur - 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if col == 2 then r.cur = r.cur - 2 else r.cur = r.cur + 1 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      r.cur = r.cur - 3
      if r.cur < 1 then r.cur = r.cur + 12 end
      sfxClick()
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      r.cur = r.cur + 3
      if r.cur > 12 then r.cur = r.cur - 12 end
      sfxClick()
    end
    if pd.buttonJustPressed(pd.kButtonA) then regPress(c, KEYS[r.cur]) end
  else
    local ch = math.abs(pd.getCrankChange())
    r.crank = r.crank + ch
    r.tick = r.tick + ch
    if ch > 0.8 then
      r.hold = 0.15
      if not (sfx.receipt and sfx.receipt:isPlaying()) then sfxPlay("receipt", false, 1.0, 1.0) end   -- plays once, no loop
    else
      r.hold = (r.hold or 0) - dt
      if r.hold <= 0 and r.crank < RECEIPT_CRANK then sfxStop("receipt") end
    end
    if r.tick >= 30 then r.tick = r.tick - 30; sfxTick() end
    if r.crank >= RECEIPT_CRANK then
      c.stage = 2
      closeStation()
      routeTo(c, PICK_X, PICK_Y)      -- the customer drifts over to the pickup end
      say("Receipt printed!")
    end
  end
end

-- ---- 2. coffee ------------------------------------------------------
local PICK_BUTTONS = {
  { pd.kButtonUp, "coffee" }, { pd.kButtonRight, "matcha" },
  { pd.kButtonDown, "decaf" }, { pd.kButtonLeft, "tea" },
}

local function updateCoffee(c, dt)
  local f = c.cof
  if f.phase == "pick" then
    for _, pb in ipairs(PICK_BUTTONS) do
      if pd.buttonJustPressed(pb[1]) then f.pick = pb[2]; sfxClick() end
    end
    if pd.buttonJustPressed(pd.kButtonA) then
      if f.pick == nil then
        say("Pick a drink first!")
        sfxWrong()
      else
        f.phase = "pour"
        f.base = nil
        if UI.crankPour then crankHelpStart() end
        if f.pick ~= c.order.kind then c.q = c.q - 0.35; CAFE.mistake(0.12) end    -- wrong drink!
        sfxClick()
      end
    end
    return
  end
  local t = 0
  if UI.crankPour then
    -- crank option: only turning it clockwise pours, and the faster you turn the faster it flows
    local ch = pd.getCrankChange() or 0
    local want = clamp(math.max(ch, 0) / 14, 0, 1)
    f.tilt = f.tilt + (want - f.tilt) * math.min(1, dt * 14)
    t = f.tilt < 0.04 and 0 or f.tilt
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  else
    local ax, ay = 0, 0
    if pd.accelerometerIsRunning() then
      local x, y = pd.readAccelerometer()
      ax, ay = x or 0, y or 0
    end
    -- the pose you were holding when you stepped up counts as "level"
    if f.base == nil then f.base = { ax, ay } end
    local d = math.sqrt((ax - f.base[1]) ^ 2 + (ay - f.base[2]) ^ 2)
    t = clamp((d - 0.2) / 0.5, 0, 1)
    if pd.buttonIsPressed(pd.kButtonDown) then t = 1 end   -- Simulator fallback
    f.tilt = t
  end
  if t > 0 and f.fill < 1.25 then
    local rate = POUR_RATE_MIN + (POUR_RATE_MAX - POUR_RATE_MIN) * t
    f.fill = math.min(1.25, f.fill + rate * dt)
    sfxPour()
  else
    sfxStop("pour")
  end
  if pd.buttonJustPressed(pd.kButtonA) or pd.buttonJustPressed(pd.kButtonB) then
    if f.fill < 0.2 then
      say("Pour some coffee first!")
      sfxWrong()
    else
      local err = math.abs(f.fill - UI.SIZE_FILL[c.order.size or 3])
      local pen = 0
      if err > 0.06 then pen = math.min(0.45, (err - 0.06) * 1.6) end
      if f.fill > 1.2 then pen = pen + 0.1 end   -- it spilled over
      c.q = c.q - pen
      if pen > 0 then CAFE.mistake(0.04 + pen * 0.2) end     -- missed the mark / overflowed
      sfxClick()
      local o = c.order
      if o.milk + o.sugar + o.shot + o.ice == 0 then
        c.stage = 4                      -- nothing to mix in: straight to pick up
      else
        c.stage = 3
      end
      closeStation()
      sfxGood()
    end
  end
end

-- ---- 3. mixer --------------------------------------------------------
local function updateMixer(c, dt)
  local m = c.mix
  if m.phase == 1 then
    if pd.buttonJustPressed(pd.kButtonLeft) then
      if m.milk < 4 then m.milk = m.milk + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonRight) then
      if m.sugar < 4 then m.sugar = m.sugar + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonUp) then
      if m.shot < 4 then m.shot = m.shot + 1; sfxDash() end
    elseif pd.buttonJustPressed(pd.kButtonDown) then
      if m.ice < 4 then m.ice = m.ice + 1; sfxIce() end
    elseif pd.buttonJustPressed(pd.kButtonA) then
      m.phase = 2
      crankHelpStart()
      sfxClick()
    end
  else
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    m.angle = m.angle + change
    m.progress = m.progress + ch / MIX_CRANK
    m.tick = m.tick + ch
    if m.tick >= 40 then m.tick = m.tick - 40; sfxTick() end
    -- electric mixer noise while you crank (faster crank = higher whirr)
    if ch > 0.8 then
      m.hold = 0.15
      if not (sfx.mixer and sfx.mixer:isPlaying()) then sfxPlay("mixer", false, 1.0, 1.0) end
    else
      m.hold = m.hold - dt
      if m.hold <= 0 and m.progress < 1 then sfxStop("mixer") end
    end
    if m.progress >= 1 then
      m.progress = 1
      local o = c.order
      local off = math.abs(m.milk - o.milk) + math.abs(m.sugar - o.sugar)
                + math.abs(m.shot - o.shot) + math.abs(m.ice - o.ice)
      c.q = c.q - 0.2 * off
      if off > 0 then CAFE.mistake(math.min(0.2, 0.04 * off)) end   -- wrong or missing ingredients
      c.stage = 4
      closeStation(true)               -- the mixer winds down by itself
      sfxGood()
    end
  end
end

-- ---- 4. serve + bell -------------------------------------------------
local function updateServe(c, dt)
  local s = c.srv
  if s.phase == 1 then
    s.phase = 2                       -- (safety: never wait for a second A)
  elseif s.phase == 2 then
    s.slide = math.min(1, s.slide + dt / 0.35)
    s.recent = s.recent * 0.85
    -- the plate has to land before the bell can be rung
    if pd.buttonJustPressed(pd.kButtonA) and s.slide >= 1 then
      s.phase = 3
      s.ding = 0.9
      sfxPlay("bell", false, 1.0)                 -- ding!
    end
  else
    s.ding = s.ding - dt
    if s.ding <= 0 then finishOrder(c) end
  end
end

-- ---- Evening Chill: dish bin and cup shelf ------------------------------
local function updateDishes(dt)
  local s, cu = G.sink, G.cups
  sfxPlay("sink", true, 0.6)                    -- the tap is already dripping when you open it
  if s.state == "empty" then
    sfxStop("cleaning")
    if cu.dirty > 0 then                          -- (safety) a dirty cup hops straight in
      cu.dirty = cu.dirty - 1
      s.state, s.progress, s.angle = "washing", 0, 0
      sfxCup()
    else                                          -- all clean: the screen closes by itself
      closeStation()
    end
  elseif s.state == "washing" then
    local change = pd.getCrankChange()
    local ch = math.abs(change)
    s.angle = s.angle + change
    s.progress = s.progress + ch / DISH_CRANK
    s.tick = (s.tick or 0) + ch
    if s.tick >= 40 then s.tick = s.tick - 40; sfxTick() end
    if ch > 0.8 then sfxPlay("cleaning", true, 1.0) else sfxStop("cleaning") end
    if s.progress >= 1 then
      s.progress = 1
      s.state, s.t = "sparkle", 0
      cu.hand = cu.hand + 1                 -- the clean cup is in your hand right now
      sfxStop("cleaning")
      sfxGood()
      sfxCup()
    end
  else
    s.t = s.t + dt
    if s.t >= 0.8 then
      if cu.dirty > 0 then                  -- the next dirty cup hops into the sink
        cu.dirty = cu.dirty - 1
        s.state, s.progress, s.angle = "washing", 0, 0
      else
        s.state = "empty"
      end
    end
  end
end

local function updateShelf(dt)
  local cu = G.cups
  if pd.buttonJustPressed(pd.kButtonA) then
    if cu.hand > 0 and cu.shelf < G.cupMax then
      cu.hand = cu.hand - 1
      cu.shelf = cu.shelf + 1
      sfxCup()
    else
      say("You're not holding any cups.")
      sfxWrong()
    end
  end
end

local function updateStation(dt)
  if G.st == "dishes" or G.st == "shelf" then
    -- shelf with nothing left to place: A, B or the d-pad all step away from it
    local anyPad = pd.buttonJustPressed(pd.kButtonUp) or pd.buttonJustPressed(pd.kButtonDown)
                or pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight)
    if G.st == "shelf" and G.cups.hand == 0 and (anyPad or pd.buttonJustPressed(pd.kButtonA)) then
      closeStation()
      sfxClick()
      return
    end
    if pd.buttonJustPressed(pd.kButtonB) or (G.st == "dishes" and anyPad) then   -- walk away any time
      sfxStop("cleaning")
      closeStation()
      sfxClick()
      return
    end
    if G.st == "dishes" then updateDishes(dt) else updateShelf(dt) end
    return
  end
  local c = G.cust
  if c == nil then closeStation(); return end
  local locked = (G.st == "serve" and c.srv.phase == 3)
  local pouring = (G.st == "coffee" and c.cof.phase == "pour")   -- B = A while pouring
  if pd.buttonJustPressed(pd.kButtonB) and not locked and not pouring then
    sfxStop("receipt")
    closeStation()
    sfxClick()
    return
  end
  if G.st == "register" then updateRegister(c, dt)
  elseif G.st == "coffee" then updateCoffee(c, dt)
  elseif G.st == "mixer" then updateMixer(c, dt)
  elseif G.st == "serve" then updateServe(c, dt) end
end

----------------------------------------------------------------------
-- Updating the shop: arrivals, the line, seating, the door
----------------------------------------------------------------------
-- customers arrive faster during the morning and lunch rushes
local function patienceSecs()
  if G.mode == "cafe" then return 60 + 20 * G.cafe.stars end      -- a minute, plus 20 s per star
  if G.mode ~= "rush" then return CHILL_PATIENCE end
  return 20                                  -- Fast Cafe: twenty seconds per customer
end

local function arrivalGap()
  if G.mode == "cafe" then return CAFE.gap(24 - 2.6 * G.cafe.stars, 10 - G.cafe.stars) end   -- more stars, more customers
  if G.mode == "chill" then return CAFE.gap(CHILL_ARRIVE_MIN, CHILL_ARRIVE_SPAN) end
  local hourF = G.t / RUSH_SECONDS * 7
  if (hourF >= 1 and hourF < 2.5) or (hourF >= 5 and hourF < 6.5) then
    return 5 + math.random() * 3
  end
  return 7 + math.random() * 4
end

local function updateOthers(dt)
  for i = #G.others, 1, -1 do
    local c = G.others[i]
    moveAlong(c, dt)
    if c.state == "toSeat" and #c.path == 0 then
      c.state = "seated"
      if G.mode ~= "rush" then
        c.stay = CHILL_STAY_MIN + math.random() * (CHILL_STAY_MAX - CHILL_STAY_MIN)
      else
        c.stay = STAY_MIN + math.random() * (STAY_MAX - STAY_MIN)
      end
    elseif c.state == "seated" then
      c.stay = c.stay - dt
      if c.stay <= 0 then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      end
    elseif c.state == "leaving" and #c.path == 0 then
      table.remove(G.others, i)
    end
  end
end

local function anyoneAtDoor()
  local function near(c)
    return #c.path > 0 and math.abs(c.x - DOOR_X) < 40 and c.y > 205
  end
  if G.cust and near(G.cust) then return true end
  for _, c in ipairs(G.line) do if near(c) then return true end end
  for _, c in ipairs(G.others) do if near(c) then return true end end
  return false
end

local function updateCustomers(dt)
  if G.mode ~= "rush" then CAFE.flowUpdate(dt) end
  -- someone new comes in (if the line has room)
  G.arriveIn = G.arriveIn - dt
  if G.arriveIn <= 0 then
    G.arriveIn = arrivalGap()
    local room = #G.line < LINE_MAX
    if room and G.mode == "cafe" and not CAFE.admit(#G.line + (G.cust and 1 or 0) + 1) then
      room = false
      G.arriveIn = 3 + math.random() * 4               -- (the street was quiet: try again in a few seconds)
    end
    if room then
      local c = newCustomer()
      G.line[#G.line + 1] = c
      routeTo(c, LINE_SLOTS[#G.line][1], LINE_SLOTS[#G.line][2])
    end
  end

  -- the next person in line steps up to the register
  if G.cust == nil then
    G.stepT = G.stepT - dt
    if G.stepT <= 0 and #G.line > 0 then
      local c = table.remove(G.line, 1)
      c.state = "active"
      G.cust = c
      routeTo(c, REG_X, REG_Y)
      relineup()
    end
  end

  -- people waiting in line slowly lose patience
  for i = #G.line, 1, -1 do
    local c = G.line[i]
    moveAlong(c, dt)
    if #c.path == 0 then
      if not CAFE.rich() then c.patience = c.patience - dt / (patienceSecs() * (G.mode == "rush" and 1.5 or LINE_PATIENCE)) end
      if c.patience <= 0 then
        table.remove(G.line, i)
        G.missed = G.missed + 1
        leaveRoute(c)
        G.others[#G.others + 1] = c
        relineup()
        say("Someone gave up waiting!")
      end
    end
  end

  -- the person at the counter
  local c = G.cust
  if c then
    moveAlong(c, dt)
    if c.stage == 0 and #c.path == 0 then
      c.stage = 1
      sfxHello()
    end
    if c.stage >= 1 then
      if not CAFE.rich() then c.patience = c.patience - dt / patienceSecs() end
      if c.patience <= 0 then
        c.patience = 0
        G.missed = G.missed + 1
        say("A customer walked out!")
        if G.mode == "cafe" then CAFE.mistake(0.4) end
        sfxWrong()
        if c.hasCup then c.hasCup = false; G.cups.shelf = G.cups.shelf + 1 end   -- the cup goes back
        closeStation()
        G.cust = nil
        G.stepT = 0.6
        leaveRoute(c)
        G.others[#G.others + 1] = c
      end
    end
  end

  updateOthers(dt)

  -- the door swings open when someone is coming or going
  local want = anyoneAtDoor() and 1 or 0
  if G.door < want then G.door = math.min(want, G.door + dt * 5)
  elseif G.door > want then G.door = math.max(want, G.door - dt * 5) end
end

local function updateWalking(dt)
  local dir = 0
  if pd.buttonIsPressed(pd.kButtonLeft) then dir = -1
  elseif pd.buttonIsPressed(pd.kButtonRight) then dir = 1 end
  G.moving = (dir ~= 0)
  if G.moving then
    G.px = clamp(G.px + dir * WALK_SPEED * dt, WALK_MIN, WALK_MAX)
    G.walk = G.walk + dt * 14
  end
  -- Up picks the wall shelf, Down picks the counter below (Evening Chill)
  if not nearWall() then
    G.sel = "down"
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    G.sel = "up"
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonDown) then
    G.sel = "down"
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonA) then
    if shelfSelected() then
      G.st = "shelf"
      sfxClick()
    else
      local st = nearStation()
      if st then tryOpen(st) end
    end
  end
end

endDay = function()
  closeStation()
  setShiftMenu(false)
  if G.mode == "cafe" then CAFE.finish(); return end
  G.total = G.cash + G.tips
  G.endT = 0
  entry.cur = 1
  entry.crank = 0
  for i = 1, 3 do
    entry.letters[i] = string.byte(lastInitials, i) - 65
    if entry.letters[i] < 0 or entry.letters[i] > 25 then entry.letters[i] = 0 end
  end
  state = STATE_ENTRY
end

-- Evening Chill and the Cafe have no clock: the Menu button has an "End shift" item
-- (and the Cafe adds "Save & quit" under it)
local shiftItem = nil
setShiftMenu = function(on, withSave)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if UI.setTitleItem then UI.setTitleItem(not withSave) end
  local title = withSave and "Go to Shop" or "End shift"      -- (in the Cafe it opens the shop)
  if shiftItem ~= nil and UI.shiftTitle ~= title then
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
  if on and shiftItem == nil then
    UI.shiftTitle = title
    local ok, item = pcall(function()
      return menu:addMenuItem(title, function()
        if state == STATE_PLAY and G and G.mode ~= "rush" and not G.ending then
          G.ending = true
          transitionTo(endDay)
        end
      end)
    end)
    if ok then shiftItem = item end
  elseif (not on) and shiftItem ~= nil then
    pcall(function() menu:removeMenuItem(shiftItem) end)
    shiftItem = nil
  end
  if withSave and CAFE.saveItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Save & quit", function() CAFE.saveQuit() end)
    end)
    if ok then CAFE.saveItem = item end
  elseif (not withSave) and CAFE.saveItem ~= nil then
    pcall(function() menu:removeMenuItem(CAFE.saveItem) end)
    CAFE.saveItem = nil
  end
end

local function updatePlay(dt)
  G.t = G.t + dt
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    if rem <= 10 and rem > 0 then              -- the closing countdown
      local n = math.ceil(rem)
      if n ~= G.lastCount then
        G.lastCount = n
        play(synthSq, n <= 3 and 1500 or 1000, 0.07, 0.35)
      end
    end
    if rem <= 0 then
      G.t = limit
      if not G.ending then
        G.ending = true
        transitionTo(endDay)
      end
      return
    end
  end
  if G.msgT > 0 then
    G.msgT = G.msgT - dt
    if G.msgT <= 0 then G.msg = nil end
  end
  for i = #G.popups, 1, -1 do
    local p = G.popups[i]
    p.t = p.t + dt
    if p.t >= p.life then table.remove(G.popups, i) end
  end
  WIN.updateWindow(dt)
  if G.pets then CAFE.updatePets(dt) end
  updateCustomers(dt)
  if G.st then updateStation(dt) else updateWalking(dt) end
end

----------------------------------------------------------------------
-- Drawing: people
----------------------------------------------------------------------
-- look 1..4 = customers, 5 = the barista
local function drawPerson(x, y, look, angry, mood)
  x, y = math.floor(x), math.floor(y)
  -- body
  if look == 5 then
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(WHITE)
    gfx.fillRect(x - 6, y + 10, 12, 12)
    gfx.setColor(BLACK)
    gfx.drawRect(x - 6, y + 10, 12, 12)
  else
    gfx.setColor(BLACK)
    if look == 2 then gfx.setPattern(CHECK) end
    if look == 3 then gfx.setColor(WHITE) end
    gfx.fillRoundRect(x - 12, y + 7, 24, 15, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(x - 12, y + 7, 24, 15, 6)
    if look == 4 then
      gfx.setColor(WHITE)
      gfx.fillRect(x - 10, y + 13, 20, 2)
    end
  end
  -- head
  if look == 1 or look == 5 then
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y + 3, 7)
  else
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawCircleAtPoint(x, y, 9)
    gfx.setLineWidth(1)
  end
  if look == 2 then          -- hat
    gfx.setColor(BLACK)
    gfx.fillRect(x - 12, y - 4, 24, 4)
    gfx.fillRect(x - 7, y - 11, 14, 8)
  elseif look == 4 then      -- beanie
    gfx.setPattern(CHECK)
    gfx.fillRect(x - 8, y - 9, 16, 6)
    gfx.setColor(BLACK)
    gfx.fillRect(x - 9, y - 4, 18, 2)
  end
  -- face
  gfx.setColor(BLACK)
  if look == 3 then          -- glasses
    gfx.drawCircleAtPoint(x - 4, y + 2, 3)
    gfx.drawCircleAtPoint(x + 4, y + 2, 3)
    gfx.drawLine(x - 1, y + 2, x + 1, y + 2)
  else
    gfx.fillRect(x - 4, y + 2, 2, 2)
    gfx.fillRect(x + 2, y + 2, 2, 2)
  end
  mood = mood or (angry and 0 or 2)
  if mood == 0 then                                -- a frown, with cross eyebrows
    gfx.drawLine(x - 6, y - 1, x - 2, y + 1)
    gfx.drawLine(x + 6, y - 1, x + 2, y + 1)
    gfx.drawLine(x - 3, y + 7, x - 2, y + 6)
    gfx.drawLine(x - 2, y + 6, x + 2, y + 6)
    gfx.drawLine(x + 2, y + 6, x + 3, y + 7)
  elseif mood == 1 then                            -- not impressed: a flat line
    gfx.drawLine(x - 3, y + 6, x + 3, y + 6)
  elseif mood == 3 then                            -- delighted: a big open grin
    gfx.drawLine(x - 4, y + 4, x - 3, y + 5)
    gfx.fillRect(x - 3, y + 5, 7, 3)
    gfx.drawLine(x + 4, y + 4, x + 3, y + 5)
  else
    gfx.drawLine(x - 3, y + 5, x - 2, y + 6)
    gfx.drawLine(x - 2, y + 6, x + 2, y + 6)
    gfx.drawLine(x + 2, y + 6, x + 3, y + 5)
  end
end

-- 3 = delighted, 2 = smiling, 1 = flat, 0 = frowning (patience running out, a bungled order, a walk-out)
function UI.mood(c)
  if c.state == "line" or c.state == "active" then
    local m = (c.patience > 0.6) and 2 or ((c.patience > 0.3) and 1 or 0)
    if c.stage >= 2 then
      if c.q < 0.5 then m = 0
      elseif c.q < 0.8 then m = math.min(m, 1)
      elseif c.q >= 0.97 and c.stage >= 4 and m >= 1 then m = 3 end
    end
    return m
  end
  if c.final then return (c.final >= 0.9 and 3) or (c.final >= 0.7 and 2) or (c.final >= 0.5 and 1) or 0 end
  return (c.patience <= 0) and 0 or 2
end

-- A little bar that shrinks as the customer gets impatient.
-- onDark = true draws it in white so it shows up on a black band.
local function drawPatience(x, y, p, w, onDark)
  if onDark then
    gfx.setColor(WHITE)
    gfx.drawRect(x, y, w, 6)
    gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
    gfx.setColor(BLACK)
    return
  end
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, 6)
  gfx.setColor(BLACK)
  gfx.drawRect(x, y, w, 6)
  gfx.fillRect(x + 1, y + 1, math.floor((w - 2) * p), 4)
end

local function drawCustomer(c, withBar)
  local bob = 0
  if #c.path > 0 then bob = math.floor(math.sin(c.walk) * 1.5 + 0.5) end
  local angry = c.patience < 0.3 and (c.state == "line" or c.state == "active")
  drawPerson(c.x, c.y + bob, c.look, angry, UI.mood(c))
  if withBar and c.stage >= 1 and c.stage <= 4 and not CAFE.rich() then
    drawPatience(math.floor(c.x) - 16, math.floor(c.y) - 20, c.patience, 32)
  elseif c.state == "line" and not CAFE.rich() and #c.path == 0 then      -- people waiting show a little bar beside them
    drawPatience(math.floor(c.x) + 16, math.floor(c.y) + 2, c.patience, 24)
  end
  if angry and (frames // 6) % 2 == 0 then
    gfx.setColor(BLACK)
    drawT("!", math.floor(c.x) + 12, math.floor(c.y) - 22, true)
  end
end

local function drawBubble(c)
  local lines = orderLines(c.order)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(c.greet)
  gfx.setFont(fontNormal)
  for _, line in ipairs(lines) do tw = math.max(tw, (gfx.getTextSize(line))) end
  local bw = math.min(206, tw + 28)                      -- hugs the words, with room at the sides
  local bh = 8 + 17 * (1 + #lines)
  local cx = math.floor(c.x)
  local right = cx < 200
  local bx = right and (cx + 26) or (cx - 26 - bw)
  local by = 122
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, by, bw, bh, 8)
  gfx.setLineWidth(1)
  -- little tail pointing at the customer
  local ex = right and bx or (bx + bw)
  local dir = right and -1 or 1
  gfx.setColor(WHITE)
  gfx.fillTriangle(ex, by + 8, ex, by + 22, ex + dir * 10, by + 15)
  gfx.fillRect(ex - 2, by + 9, 4, 12)
  gfx.setColor(BLACK)
  gfx.drawLine(ex, by + 8, ex + dir * 10, by + 15)
  gfx.drawLine(ex + dir * 10, by + 15, ex, by + 22)
  drawTC(c.greet, bx + bw // 2, by + 3, true)
  for i, line in ipairs(lines) do
    drawTC(line, bx + bw // 2, by + 3 + 17 * i)
  end
end

----------------------------------------------------------------------
-- Drawing: the shop
----------------------------------------------------------------------
-- the view out of a window: bx, by = the top-left of the glass on screen, k = how much bigger than the cafe's window
function WIN.sunAt(cx, cy, r, spin)                 -- a sun with little rays that turn
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, cy, r)
  for i = 0, 7 do
    local a = i * math.pi / 4 + spin
    gfx.drawLine(cx + math.cos(a) * (r + 2), cy + math.sin(a) * (r + 2), cx + math.cos(a) * (r + 4), cy + math.sin(a) * (r + 4))
  end
end

function WIN.moonAt(cx, cy, r)                      -- a crescent
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx, cy, r)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + math.max(1, r // 2 + 1), cy - 1, r - 1)
  gfx.setColor(BLACK)
end

function WIN.cloudAt(cx, cy, k, big)              -- a puffy cloud that covers whatever is behind it
  local b = big and 1 or 0
  local function blob(ex, fill)
    gfx.setColor(fill)
    gfx.fillCircleAtPoint(cx - 5 * k, cy + k, 3 * k + ex)
    gfx.fillCircleAtPoint(cx, cy - k, (4 + b) * k + ex)
    gfx.fillCircleAtPoint(cx + 5 * k, cy + k, 3 * k + ex)
    gfx.fillRect(cx - 8 * k - ex, cy + k - ex, 16 * k + 2 * ex, 3 * k + 2 * ex)
  end
  blob(1, BLACK); blob(0, WHITE)
  gfx.setColor(BLACK)
end

function WIN.drawView(w, bx, by, k)
  local function X(x) return math.floor(bx + (x - 15) * k) end
  local function Y(y) return math.floor(by + (y - 23) * k) end
  local function L(x0, y0, x1, y1) gfx.drawLine(X(x0), Y(y0), X(x1), Y(y1)) end
  gfx.setClipRect(bx, by, 52 * k, 24 * k)
  gfx.setColor(BLACK)
  gfx.setLineWidth(k)
  if w.sky then
    local p = w.sky.t / w.sky.dur
    local sx = X(8 + p * 66)
    local sy = Y(41 - math.sin(math.pi * p) * 15)
    if w.sky.kind == "sun" and w.fx.snow then
      -- no sun while it snows
    elseif w.sky.kind == "sun" then WIN.sunAt(sx, sy, 3 * k, (w.sky.t * 0.4) % 6.28)
    else WIN.moonAt(sx, sy, 4 * k) end
    gfx.setColor(BLACK)
  end
  for _, q in ipairs(w.parts) do                    -- clouds drift in front of the sun and moon
    if q.k == "cloud" then WIN.cloudAt(X(math.floor(q.x)), Y(math.floor(q.y)), k, q.s == 1) end
  end
  gfx.setColor(BLACK)
  for _, q in ipairs(w.walkers) do                  -- a person walking by
    local x = math.floor(q.x)
    local step = math.floor(math.sin(q.t) * 2)
    gfx.fillCircleAtPoint(X(x), Y(34), 3 * k)
    gfx.fillRoundRect(X(x - 4), Y(37), 8 * k, 8 * k, 2 * k)
    L(x - 1, 45, x - 1 + step, 49)
    L(x + 1, 45, x + 1 - step, 49)
    if q.umbrella then
      gfx.fillTriangle(X(x - 8), Y(31), X(x + 8), Y(31), X(x), Y(24))
    end
  end
  for _, q in ipairs(w.parts) do
    local x, y = math.floor(q.x), math.floor(q.y)
    if q.k == "cloud" then
      -- (drawn above, behind the people)
    elseif q.k == "rain" then
      L(x, y, x - (q.vx > 0 and -2 or 1), y + 3)
    elseif q.k == "snow" then                       -- a soft flake
      gfx.fillRect(X(x), Y(y), 2 * k, 2 * k)
      if (math.floor(q.ph * 2) % 2) == 0 then gfx.drawPixel(X(x) - 1, Y(y)); gfx.drawPixel(X(x) + 2 * k, Y(y) + 1) end
    elseif q.k == "wind" then                       -- a lazy, squiggly gust
      local px, py = x, y + math.floor(math.sin(q.ph) * 2.5)
      for j = 1, 7 do
        local nx = x - j * 3
        local ny = y + math.floor(math.sin(q.ph - j * 0.9) * 2.5)
        L(px, py, nx, ny)
        px, py = nx, ny
      end
      L(px, py, px - 2, py - 2)                     -- the curl at the tail
    else
      gfx.fillEllipseInRect(X(x), Y(y), 5 * k, 3 * k)             -- a falling leaf
      L(x - 1, y + 3, x + 1, y + 1)
    end
  end
  gfx.setLineWidth(1)
  gfx.clearClipRect()
  gfx.setColor(BLACK)
end

function WIN.drawWindowView() WIN.drawView(G.win, 33, 23, 1) end

local function drawWall()
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 18, 400, 52)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 68, 400, 3)
  CAFE.drawLights()

  -- window
  CAFE.drawWindowNow()

  -- shelf with cups (in Evening Chill these are the shop's real clean cups)
  do
    if shelfSelected() then
      local pad = ((frames // 10) % 2 == 0) and 0 or 3
      gfx.setColor(WHITE)
      gfx.fillRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(98 - pad, 25 - pad, 102 + pad * 2, 24 + pad * 2, 7)
      gfx.setLineWidth(1)
    end
    gfx.fillRect(102, 40, 92, 3)
    local two = G.cupMax > 5                      -- past 5 cups the shelf gets a second row behind the first
    local step = two and 17 or math.min(17, 88 // math.max(1, G.cupMax))
    for pass = 0, 1 do                            -- (the back row first, so the front row covers it)
      for i = 0, G.cupMax - 1 do
        local back = two and i >= 5
        if i < G.cups.shelf and ((pass == 0) == back) then
          local cx = 106 + (back and (i - 5) * step + 8 or i * step)
          local cy = back and 26 or 30
          gfx.setColor(WHITE)
          gfx.fillRect(cx, cy, 10, 10)
          gfx.setColor(BLACK)
          gfx.drawRect(cx, cy, 10, 10)
          gfx.fillRect(cx + 11, cy + 3, 2, 4)
        end
      end
    end
  end

  -- opening hours sign (in the Cafe it shows your cafe's name, and can be taken down)
  if G.mode ~= "cafe" or G.cafe.sign ~= false then      -- (the sign)
    gfx.setColor(WHITE)
    gfx.fillRect(272, 22, 90, 26)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(272, 22, 90, 26)
    gfx.setLineWidth(1)
    if G.mode == "cafe" then
      CAFE.fitText(G.cafe.name, 317, 35, 80, 18)
    else
      CAFE.fitText(G.mode == "chill" and "CHILL CAFE" or "FAST CAFE", 317, 35, 80, 18)
    end
  end
  if CAFE.dec() then CAFE.drawWallItems(); CAFE.drawTinyItems() end

  -- framed picture of the coffee mug from the title screen
  local fx, fy = 366, 21
  gfx.setColor(WHITE)
  gfx.fillRect(fx, fy, 30, 28)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(fx, fy, 30, 28)
  gfx.drawCircleAtPoint(fx + 22, fy + 16, 3)               -- handle
  gfx.setColor(WHITE)
  gfx.fillRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(fx + 6, fy + 10, 15, 12, 3)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(fx + 8, fy + 12, 11, 4)
  gfx.setColor(BLACK)
  gfx.fillRect(fx + 3, fy + 23, 22, 2)                      -- saucer
  gfx.drawLine(fx + 10, fy + 8, fx + 12, fy + 5)            -- steam
  gfx.drawLine(fx + 12, fy + 5, fx + 10, fy + 3)
  gfx.drawLine(fx + 16, fy + 8, fx + 18, fy + 5)
  gfx.drawLine(fx + 18, fy + 5, fx + 16, fy + 3)
  CAFE.drawVines()                                          -- hanging things go over everything below them
  CAFE.drawDangles()
end

local function drawCounter()
  gfx.setColor(WHITE)
  gfx.fillRect(0, 74, 400, 22)
  gfx.setColor(BLACK)
  gfx.fillRect(0, 74, 400, 2)
  gfx.fillRect(0, 96, 400, 18)
  CAFE.drawCounterItems()

  -- station signs on the front of the counter; the one you're standing at
  -- gets a white bubble that pulses
  local near = (not shelfSelected()) and nearStation() or nil
  for _, st in ipairs(STATIONS) do
    gfx.setFont(fontNormal)
    local tw = gfx.getTextSize(st.label)
    if near == st then
      local pad = ((frames // 10) % 2 == 0) and 0 or 2
      local bw = tw + 12
      gfx.setColor(WHITE)
      gfx.fillRoundRect(st.x - bw // 2 - pad, 98, bw + pad * 2, 14, 5)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
    else
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTC(st.label, st.x, 97)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC("TIPS", JAR_X - 3, 97)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)

  -- register
  local x = stationById("register").x
  gfx.setColor(BLACK)
  gfx.fillRect(x - 14, 78, 28, 16)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 10, 80, 14, 5)
  for i = 0, 2 do gfx.fillRect(x - 10 + i * 5, 88, 3, 3) end
  gfx.fillRect(x + 8, 80, 3, 11)

  -- coffee machine: hood, display, two spouts, a cup and a drip tray
  x = stationById("coffee").x
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x - 16, 76, 32, 18, 3)
  gfx.fillRect(x - 13, 74, 26, 3)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 12, 79, 11, 6)              -- display
  gfx.setColor(BLACK)
  gfx.fillRect(x - 10, 81, 3, 2)
  gfx.fillRect(x - 5, 81, 3, 2)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x - 9, 90, 1)          -- buttons
  gfx.fillCircleAtPoint(x - 5, 90, 1)
  gfx.fillRect(x + 1, 80, 12, 3)               -- brew head
  gfx.fillRect(x + 4, 83, 2, 3)                -- spouts
  gfx.fillRect(x + 9, 83, 2, 3)
  gfx.fillRect(x + 3, 88, 10, 5)               -- cup
  gfx.setColor(BLACK)
  gfx.fillRect(x + 5, 89, 6, 2)
  gfx.fillRect(x - 17, 93, 34, 2)              -- drip tray

  -- mixer: stand mixer with a head, dial, paddle and bowl
  x = stationById("mixer").x
  gfx.setColor(BLACK)
  gfx.fillRoundRect(x - 14, 90, 28, 5, 2)      -- base
  gfx.fillRect(x + 7, 78, 6, 13)               -- column
  gfx.fillRoundRect(x - 10, 76, 24, 8, 3)      -- head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x + 8, 80, 2)          -- dial
  gfx.setColor(BLACK)
  gfx.fillRect(x - 5, 84, 2, 5)                -- paddle shaft
  gfx.fillRect(x - 8, 87, 8, 2)
  gfx.fillRoundRect(x - 12, 85, 18, 7, 3)      -- bowl
  gfx.setColor(WHITE)
  gfx.fillRect(x - 9, 87, 12, 2)               -- bowl rim highlight
  gfx.setColor(BLACK)
  gfx.fillRect(x - 5, 84, 2, 4)

  -- pick-up area: a rectangular mat with a plate on it
  x = stationById("serve").x
  gfx.setColor(BLACK)
  gfx.fillRect(x - 17, 80, 34, 14)
  gfx.setColor(WHITE)
  gfx.fillRect(x - 14, 82, 28, 10)
  gfx.setColor(BLACK)
  gfx.drawRect(x - 12, 84, 24, 6)
  gfx.drawCircleAtPoint(x, 87, 3)

  -- Evening Chill: the dish bin
  local dishSt = stationById("dishes")
  if dishSt then
    x = dishSt.x
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x - 17, 82, 34, 13, 3)             -- the bin
    gfx.setColor(WHITE)
    gfx.fillRect(x - 14, 84, 28, 8)
    gfx.setColor(BLACK)
    for i = 1, math.min(G.cups.dirty, 5) do              -- dirty cups piled up in it
      gfx.fillRect(x - 15 + (i - 1) * 6, 85, 5, 6)
    end
    gfx.fillRect(x + 9, 76, 3, 7)                        -- little faucet
    gfx.fillRect(x + 4, 76, 8, 3)
  end

  -- the 8-bit tip jar (coins pile up as you earn tips)
  local jx = JAR_X
  gfx.setColor(BLACK)
  gfx.fillRect(jx - 12, 66, 24, 5)
  gfx.setColor(WHITE)
  gfx.fillRect(jx - 10, 71, 20, 23)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(jx - 10, 71, 20, 23)
  gfx.setLineWidth(1)
  local coins = math.min(12, G.tips // ((G.mode == "cafe") and 1200 or 400))       -- (fills up slowly)
  for i = 0, coins - 1 do
    gfx.fillRect(jx - 7 + (i % 3) * 5, 89 - (i // 3) * 5, 4, 3)
  end
end

-- tables, chairs, and the corner nook
local function drawFloorStatic()
  local lim = G.seatLimit
  CAFE.drawRunner()
  CAFE.drawRug()
  if lim >= 9 then
    -- the corner nook: an L-shaped bench up the right wall and along the bottom
    gfx.setColor(BLACK)
    gfx.fillRoundRect(372, 150, 26, 82, 8)
    gfx.fillRoundRect(322, 206, 76, 26, 8)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(376, 154, 18, 74, 5)
    gfx.fillRoundRect(326, 210, 68, 18, 5)
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(376, 154, 18, 74, 5)
    gfx.fillRoundRect(326, 210, 68, 18, 5)
    gfx.setColor(BLACK)
  end

  -- chairs
  for i, s in ipairs(SEATS) do
    if s.t <= 4 and i <= lim and not (G.seatOff and G.seatOff[i]) then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(s.x - 6, s.y - 9, 12, 18, 3)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(s.x - 6, s.y - 9, 12, 18, 3)
    end
  end

  -- round tables
  local firstSeat = { 1, 3, 5, 7, 9 }
  for ti, t in ipairs(TABLES) do
    if firstSeat[ti] <= lim and not (G.seatOff and G.seatOff[firstSeat[ti]]) then
      local cp = CAFE.ownedOf("centerpiece")
      if cp == "cp2" or cp == "cp5" or cp == "cp6" then cp = nil end     -- (the flame, pumpkin and tree twinkle, so they are drawn live)
      CAFE.tableAt(t.x, t.y, t.r, CAFE.ownedOf("cloth"), cp, 1)
    end
  end

  CAFE.drawFloorItems(false)
  gfx.setColor(BLACK)
end

-- the floor (rugs, chairs, tables, plants) never changes during a shift, so it is drawn once into a
-- picture and stamped on every frame: far fewer drawing calls
local function drawFloor()
  CAFE.cached("floorImg", drawFloorStatic, 70, 170)
  -- the things that move stay live: swaying plants, the blinking tree, candle flames
  CAFE.drawFloorItems(true)
  local live = CAFE.ownedOf("centerpiece")
  if live == "cp2" or live == "cp5" or live == "cp6" then
    local firstSeat = { 1, 3, 5, 7, 9 }
    for ti, t in ipairs(TABLES) do
      if firstSeat[ti] <= G.seatLimit and not (G.seatOff and G.seatOff[firstSeat[ti]]) then CAFE.centerAt(live, t.x, t.y, 1) end
    end
  end
  -- a coffee cup in front of everyone who is sitting down
  for i, s in ipairs(SEATS) do
    if G.seats[i] and G.seats[i].state == "seated" then
      local t = TABLES[s.t]
      local cx = math.floor(t.x + (s.x - t.x) * 0.45)
      local cy = math.floor(t.y + (s.y - t.y) * 0.45)
      gfx.setColor(BLACK)
      gfx.fillCircleAtPoint(cx, cy, 3)
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx, cy, 1)
    end
  end
  gfx.setColor(BLACK)
end

-- the front door, bottom left: a line that swings open and shut (seen from above)
function UI.drawDoor()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 238, 12, 2)
  gfx.fillRect(46, 238, 354, 2)
  gfx.fillRect(10, 235, 4, 5)
  local a = math.rad(G.door * 90)
  local ex = 14 + math.floor(32 * math.cos(a) + 0.5)
  local ey = 238 - math.floor(32 * math.sin(a) + 0.5)
  gfx.setLineWidth(3)
  gfx.drawLine(14, 238, ex, ey)
  gfx.setLineWidth(1)
end

local function drawPlayer()
  local bob = 0
  if G.moving then bob = math.floor(math.sin(G.walk) * 1.5 + 0.5) end
  drawPerson(G.px, PLAYER_Y + bob, 5, false)
  local n = G.cups and G.cups.hand or 0
  if n > 0 then                               -- clean cups held up in hand
    local x0 = math.floor(G.px) + 16               -- carried beside the barista
    for i = 1, n do drawCup(x0 + (i - 1) * 12, PLAYER_Y + 7 + bob, 1, false) end
  end
end

----------------------------------------------------------------------
-- Drawing: station panels (they pop up over the customer area)
----------------------------------------------------------------------
local function drawPanelFrame(c, title, text)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(6, 116, 388, 122, 8)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(6, 116, 388, 122, 8)
  gfx.setLineWidth(1)
  gfx.fillRect(10, 120, 380, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawT(title, 14, 121, true)
  gfx.setFont(fontBold)
  local tw = gfx.getTextSize(title)
  if c then
    drawT(text or orderShort(c.order), 14 + tw + 12, 121)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    if not CAFE.rich() then drawPatience(342, 126, c.patience, 46, true) end
  else
    if G.st == "dishes" then
      drawTR("Dirty: " .. G.cups.dirty .. "     In hand: " .. G.cups.hand, 384, 121, true)
    else
      drawTR("In hand: " .. G.cups.hand, 384, 121, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
end

local function drawRegister(c)
  local r = c.reg
  drawPanelFrame(c, "REGISTER")

  -- keypad
  local x0, y0, kw, kh = 250, 144, 44, 22
  for i = 1, 12 do
    local col, row = (i - 1) % 3, (i - 1) // 3
    local kx, ky = x0 + col * kw, y0 + row * kh
    gfx.setColor(BLACK)
    if r.state == "type" and r.cur == i then
      gfx.fillRect(kx, ky, kw, kh)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.drawRect(kx, ky, kw, kh)
    end
    drawTC(KEYS[i], kx + kw // 2, ky + 3, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end

  gfx.setColor(BLACK)
  if r.state == "type" then
    gfx.drawRoundRect(16, 144, 226, 26, 5)
    drawT("CHARGE", 24, 150)
    drawTR(money(c.price), 234, 150, true)
    gfx.fillRect(16, 176, 226, 30)
    gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    if r.flash > 0 then
      if (frames // 4) % 2 == 0 then drawTC("WRONG! Try again", 129, 183, true) end
    else
      drawT("TYPE", 24, 183)
      drawTR(money(tonumber(r.digits) or 0), 234, 183, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  else
    drawT("Correct!", 16, 144, true)
    drawT("Crank to print the receipt.", 16, 162)
    gfx.setColor(BLACK)
    gfx.fillRect(24, 186, 160, 8)
    local h = math.floor(clamp(r.crank / RECEIPT_CRANK, 0, 1) * 40)
    if h > 0 then
      gfx.setColor(WHITE)
      gfx.fillRect(44, 194, 120, h)
      gfx.setColor(BLACK)
      gfx.drawRect(44, 194, 120, h)
      for ly = 200, 194 + h - 4, 8 do
        gfx.drawLine(52, ly, 52 + 40 + ((ly * 7) % 50), ly)
      end
    end
  end
end

function UI.sunA(x, y)                          -- the A button: a ring round the A with little rays, like a sun
  local pulse = (frames // 6) % 2
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, 12)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, 12)
  gfx.setLineWidth(1)
  for i = 0, 11 do
    local ang = math.rad(i * 30 + (pulse == 0 and 0 or 7))
    local r0, r1 = 16, (i % 2 == 0) and 22 or 20
    if pulse == 1 then r1 = r1 - 1 end
    gfx.drawLine(math.floor(x + math.cos(ang) * r0 + 0.5), math.floor(y + math.sin(ang) * r0 + 0.5),
                 math.floor(x + math.cos(ang) * r1 + 0.5), math.floor(y + math.sin(ang) * r1 + 0.5))
  end
  drawTC("A", x, y - 8, true)
end

-- A small d-pad with the words around it (up above, down below, left and right
-- beside it). `on` = "up" / "down" / "left" / "right" boxes that word.
function UI.drawSmallPad(px, py, words, on)
  local function fillArm(x, y, w, h, lit)
    gfx.setColor(BLACK)
    gfx.fillRoundRect(x, y, w, h, 3)
    if lit then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x + 3, y + 3, w - 6, h - 6, 2)
      gfx.setColor(BLACK)
    end
  end
  gfx.setColor(BLACK)
  gfx.fillRect(px - 13, py - 9, 26, 18)                           -- centre
  fillArm(px - 13, py - 27, 26, 18, on == "up")
  fillArm(px - 13, py + 9, 26, 18, on == "down")
  fillArm(px - 39, py - 9, 26, 18, on == "left")
  fillArm(px + 13, py - 9, 26, 18, on == "right")
  gfx.fillRect(px - 13, py - 18, 26, 36)
  gfx.fillRect(px - 26, py - 9, 52, 18)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(px, py, 3)
  local function arrow(x1, y1, x2, y2, x3, y3, lit)
    gfx.setColor(lit and BLACK or WHITE)
    gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  end
  arrow(px, py - 25, px - 5, py - 18, px + 5, py - 18, on == "up")
  arrow(px, py + 25, px - 5, py + 18, px + 5, py + 18, on == "down")
  arrow(px - 36, py, px - 29, py - 5, px - 29, py + 5, on == "left")
  arrow(px + 36, py, px + 29, py - 5, px + 29, py + 5, on == "right")
  gfx.setColor(BLACK)
  -- the words
  local function word(txt, x, ty, align, lit)
    gfx.setFont(fontBold)
    local tw = gfx.getTextSize(txt)
    local left = x - tw // 2                      -- centred
    if align == "left" then left = x elseif align == "right" then left = x - tw end
    if lit then
      gfx.setColor(BLACK)
      gfx.fillRoundRect(left - 4, ty - 1, tw + 8, 17, 4)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawT(txt, left, ty, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end
  if words.up then word(words.up, px + (words.upDx or 0), py - 46, "center", on == "up") end
  if words.down then word(words.down, px, py + 30, "center", on == "down") end
  if words.left then word(words.left, px - 45, py - 8, "right", on == "left") end
  if words.right then word(words.right, px + 45, py - 8, "left", on == "right") end
end

UI.PICK_KEY_SIDE = { coffee = "up", decaf = "down", tea = "left", matcha = "right" }

local function drawCoffee(c)
  local f = c.cof
  drawPanelFrame(c, "COFFEE")

  if f.phase == "pick" then
    UI.drawSmallPad(116, 187, { up = "COFFEE", upDx = -2, down = "DECAF", left = "TEA", right = "MATCHA" },
                 f.pick and UI.PICK_KEY_SIDE[f.pick] or nil)
    -- A button
    gfx.setColor(BLACK)
    UI.sunA(262, 180)
    drawTC("POUR", 262, 206, true)
    -- a preview of what you picked
    gfx.setColor(WHITE)
    gfx.fillRect(318, 160, 36, 40)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(318, 160, 36, 40)
    gfx.setLineWidth(1)
    if f.pick then
      gfx.setPattern(DRINK_PATTERN[f.pick])
      gfx.fillRect(320, 168, 32, 30)
      gfx.setColor(BLACK)
    end
    return
  end

  if UI.crankPour then
    drawT("Crank to pour.", 16, 160, true)
    drawT("Faster = faster pour.", 16, 180)
  else
    drawT("Tilt Playdate", 16, 160, true)
    drawT("down to pour.", 16, 180, true)
  end

  -- cup
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(300, 196, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRect(242, 164, 56, 66)
  local surface = 228 - math.floor(f.fill * 52)
  if surface < 166 then surface = 166 end
  gfx.setColor(BLACK)
  if f.pick == "matcha" then gfx.setPattern(DIAG) elseif f.pick == "decaf" then gfx.setPattern(STRIPE) end
  gfx.fillRect(244, surface, 52, 228 - surface)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(242, 164, 56, 66)
  gfx.setLineWidth(1)

  -- the "fill to here" line
  local sz = c.order.size or 3
  local lineY = 228 - math.floor(UI.SIZE_FILL[sz] * 52)             -- every cup size has its own line
  if surface <= lineY and (f.pick == nil or f.pick == "coffee") then gfx.setColor(WHITE) else gfx.setColor(BLACK) end
  for dx = 246, 290, 8 do gfx.drawLine(dx, lineY, dx + 4, lineY) end
  gfx.setColor(BLACK)
  gfx.fillTriangle(230, lineY - 5, 230, lineY + 5, 239, lineY)
  drawTR(string.upper(UI.SIZE_NAME[sz]), 226, lineY - 7, true)

  -- spilled over
  if f.fill > 1.2 then
    gfx.fillRect(238, 200, 3, 24)
    gfx.fillRect(299, 214, 3, 14)
  end

  -- spout and stream
  gfx.fillRect(254, 142, 32, 8)
  gfx.fillRect(266, 150, 8, 6)
  if f.tilt > 0 and f.fill < 1.25 then
    gfx.fillRect(269, 156, 3, math.max(0, surface - 156))
  end

  -- tilt meter
  drawT(UI.crankPour and "CRANK" or "TILT", UI.crankPour and 338 or 340, 142)
  gfx.drawRect(346, 160, 22, 70)
  local h = math.floor(70 * f.tilt)
  gfx.fillRect(346, 230 - h, 22, h)
end

-- what's still missing from the order (they vanish from the black bar as you add them)
function UI.mixHeader(o, m)
  local items = {}
  local function need(n, one, many)
    if n > 0 then items[#items + 1] = n .. " " .. (n == 1 and one or many) end
  end
  need(o.shot - m.shot, "shot", "shots")
  need(o.milk - m.milk, "milk", "milk")
  need(o.sugar - m.sugar, "sugar", "sugar")
  need(o.ice - m.ice, "ice", "ice")
  if m.phase == 2 then return "Mixing it up!" end
  if #items == 0 then return "Ready to mix!" end
  return table.concat(items, ", ")
end

local function drawMixer(c)
  local m = c.mix
  drawPanelFrame(c, "MIXER", UI.mixHeader(c.order, m))

  -- the fridge
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(16, 144, 34, 88)
  gfx.setLineWidth(1)
  gfx.drawLine(18, 172, 47, 172)
  gfx.fillRect(40, 150, 3, 8)
  gfx.fillRect(40, 180, 3, 14)

  if m.phase == 1 then
    UI.drawSmallPad(160, 187, { up = "SHOT", down = "ICE", left = "MILK", right = "SUGAR" }, nil)
    -- the A button starts the mixing
    UI.sunA(288, 178)
    gfx.setColor(BLACK)
    drawTC("MIX", 288, 205, true)
  else
    drawT("Crank to mix!", 70, 144, true)
    gfx.setColor(BLACK)
    gfx.drawRect(70, 172, 150, 14)
    gfx.fillRect(72, 174, math.floor(146 * clamp(m.progress, 0, 1)), 10)
    drawT("Keep turning!", 70, 196)
  end

  -- the cup, seen from above
  local cx, cy = 348, 190
  local a = math.rad(m.angle)
  local mixed = m.progress >= 0.6
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx, cy, 34)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 30)
  gfx.setColor(BLACK)
  if mixed and m.milk > 0 then gfx.setPattern(CHECK) end
  gfx.fillCircleAtPoint(cx, cy, 28)
  gfx.setColor(WHITE)
  if not mixed then
    for i = 1, m.milk do
      local t = a + (i - 1) * (2 * math.pi / m.milk)
      gfx.fillCircleAtPoint(math.floor(cx + 16 * math.cos(t)), math.floor(cy + 16 * math.sin(t)), 6)
    end
    for i = 1, m.sugar do
      local t = -a * 0.7 + (i - 1) * (2 * math.pi / m.sugar) + 0.5
      gfx.fillRect(math.floor(cx + 22 * math.cos(t)) - 2, math.floor(cy + 22 * math.sin(t)) - 2, 4, 4)
    end
    for i = 1, m.shot do
      local t = a * 1.3 + (i - 1) * (2 * math.pi / m.shot) + 2.0
      gfx.drawCircleAtPoint(math.floor(cx + 11 * math.cos(t)), math.floor(cy + 11 * math.sin(t)), 4)
    end
  end
  -- ice cubes float on top, mixed or not
  for i = 1, m.ice do
    local t = a * 0.4 + (i - 1) * (2 * math.pi / m.ice) + 1.0
    gfx.drawRect(math.floor(cx + 19 * math.cos(t)) - 3, math.floor(cy + 19 * math.sin(t)) - 3, 7, 7)
  end
  gfx.setLineWidth(3)
  gfx.drawLine(cx, cy, math.floor(cx + 25 * math.cos(a)), math.floor(cy + 25 * math.sin(a)))
  gfx.drawLine(cx, cy, math.floor(cx - 25 * math.cos(a)), math.floor(cy - 25 * math.sin(a)))
  gfx.setLineWidth(1)
  gfx.setColor(BLACK)
end

local function drawServe(c)
  local s = c.srv
  drawPanelFrame(c, "PICK UP")
  if s.phase <= 2 then
    if s.slide < 1 then
      drawT("Here it comes...", 16, 146, true)
    else
      drawT("Press A to ring", 16, 146, true)
      drawT("the bell!", 16, 164, true)
    end
  else
    drawT("Order up!", 16, 146, true)
  end

  -- the drink slides along the counter
  gfx.setColor(BLACK)
  gfx.fillRect(16, 226, 200, 4)
  local cx = 40 + math.floor(s.slide * 140)
  if c.order.ice > 0 then
    -- iced coffee: tall glass, ice cubes and a straw
    gfx.setColor(WHITE)
    gfx.fillPolygon(cx - 12, 190, cx + 12, 190, cx + 9, 226, cx - 9, 226)
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"])
    gfx.fillPolygon(cx - 11, 198, cx + 11, 198, cx + 9, 225, cx - 9, 225)
    gfx.setColor(WHITE)
    for _, q in ipairs({ { -7, 200 }, { 1, 204 }, { -5, 212 }, { 2, 216 } }) do
      gfx.fillRect(cx + q[1], q[2], 7, 7)
    end
    gfx.setColor(BLACK)
    for _, q in ipairs({ { -7, 200 }, { 1, 204 }, { -5, 212 }, { 2, 216 } }) do
      gfx.drawRect(cx + q[1], q[2], 7, 7)
    end
    gfx.setLineWidth(2)
    gfx.drawPolygon(cx - 12, 190, cx + 12, 190, cx + 9, 226, cx - 9, 226)
    gfx.setLineWidth(3)
    gfx.drawLine(cx + 3, 208, cx + 8, 178)
    gfx.drawLine(cx + 8, 178, cx + 14, 175)
    gfx.setLineWidth(1)
  else
    -- hot coffee: cup with a handle and steam
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 12, 198, 24, 28)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(cx - 12, 198, 24, 28)
    gfx.drawCircleAtPoint(cx + 14, 210, 6)
    gfx.setLineWidth(1)
    gfx.setPattern(DRINK_PATTERN[c.order.kind or "coffee"])
    gfx.fillRect(cx - 10, 202, 20, 22)
    gfx.setColor(BLACK)
    for i = -1, 1, 2 do
      local sx = cx + i * 5
      gfx.drawLine(sx, 194, sx + 2, 190)
      gfx.drawLine(sx + 2, 190, sx, 186)
    end
  end
  gfx.setColor(BLACK)

  -- the bell (sitting low on the counter)
  local bx, by = 310, 224                              -- by = where the dome meets its base
  if s.phase == 3 then bx = bx + ((frames // 2) % 2 == 0 and 2 or -2) end   -- the bell rings
  gfx.setColor(BLACK)
  gfx.setClipRect(0, 0, 400, by)                       -- only the top half of the circle: the dome
  gfx.fillCircleAtPoint(bx, by, 30)
  gfx.clearClipRect()
  gfx.fillRect(bx - 38, by, 77, 7)                     -- the base, sitting inside the panel frame
  gfx.fillCircleAtPoint(bx, by - 33, 5)                -- the knob
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(bx - 11, by - 14, 4)           -- a shine
  gfx.setColor(BLACK)
  if s.phase == 2 and s.slide >= 1 then
    -- the A button above the bell: a ring round the A with little rays, like a sun
    UI.sunA(bx, 160)
  elseif s.phase == 3 then
    drawTC("DING!", bx, by - 68, true)
    for i = -2, 2 do
      local ang = math.rad(i * 25 - 90)
      gfx.drawLine(math.floor(bx + math.cos(ang) * 32), math.floor(by + math.sin(ang) * 32),
                   math.floor(bx + math.cos(ang) * 44), math.floor(by + math.sin(ang) * 44))
    end
  end
end

-- Evening Chill: the dish bin (left) and sink (right)
local function drawDishes()
  local s, cu = G.sink, G.cups
  drawPanelFrame(nil, "DISHES")

  -- dirty cups waiting in the bin
  drawT("DIRTY CUPS", 16, 142, true)
  if cu.dirty == 0 then drawT("none", 16, 168) end
  for i = 1, cu.dirty do
    local col, row = (i - 1) % 3, (i - 1) // 3
    drawCup(20 + col * 44, 164 + row * 26, 2, true)
  end

  -- the sink: a counter rim, a basin, a tall curved faucet and two taps
  local wx = 292                                        -- where the water falls
  gfx.setColor(BLACK)
  gfx.fillRoundRect(214, 186, 156, 48, 8)               -- basin
  gfx.setColor(WHITE)
  gfx.fillRoundRect(219, 190, 146, 38, 6)
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(221, 210, 142, 16)                       -- the water
  gfx.setColor(BLACK)
  local wave = math.floor(math.sin(frames * 0.3) * 1.5)
  gfx.drawLine(221, 210 + wave, 361, 210 - wave)
  gfx.fillRect(206, 182, 172, 6)                        -- rim of the sink
  gfx.fillRect(262, 150, 12, 34)                        -- faucet pipe
  gfx.fillRoundRect(262, 144, 40, 10, 5)                -- the curve over the sink
  gfx.fillRect(292 - 4, 144, 8, 16)                     -- spout
  gfx.fillRect(wx - 6, 158, 12, 5)                      -- nozzle
  gfx.fillRect(238, 174, 4, 10)                         -- hot tap
  gfx.fillCircleAtPoint(240, 172, 5)
  gfx.fillRect(342, 174, 4, 10)                         -- cold tap
  gfx.fillCircleAtPoint(344, 172, 5)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(240, 172, 2)
  gfx.fillCircleAtPoint(344, 172, 2)
  gfx.setColor(BLACK)

  -- the stream of water
  local flow = (frames * 2) % 8
  for y = 164 + flow - 8, 188, 8 do
    if y >= 164 then gfx.drawLine(wx, y, wx, math.min(188, y + 4)) end
  end

  -- the cup being scrubbed
  if s.state ~= "empty" then
    local cx, cy = wx, 198
    drawCup(cx - 12, cy - 14, 3, false)
    if s.state == "washing" then
      local h = math.floor(10 * (1 - s.progress))          -- the dirt wears away
      if h > 0 then
        gfx.setPattern(CHECK)
        gfx.fillRect(cx - 10, cy + 6 - h + 2, 20, h)
        gfx.setColor(BLACK)
      end
      local a = math.rad(s.angle)
      local sx = math.floor(cx + 30 * math.cos(a))
      local sy = math.floor(cy + 12 * math.sin(a))
      gfx.setColor(BLACK)
      gfx.fillRoundRect(sx - 8, sy - 5, 16, 10, 3)         -- the sponge
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(sx - 3, sy - 1, 1)
      gfx.fillCircleAtPoint(sx + 3, sy + 2, 1)
      gfx.setColor(BLACK)
      for i = 0, 2 do                                       -- soap bubbles
        local bx = cx - 26 + ((frames * 0.7 + i * 23) % 56)
        gfx.drawCircleAtPoint(math.floor(bx), cy - 6 - ((frames // 3 + i * 5) % 12), 2 + i % 2)
      end
    else
      -- squeaky clean: sparkles
      gfx.setColor(BLACK)
      local big = ((frames // 3) % 2 == 0)
      for _, o in ipairs({ { -20, -12 }, { 22, -8 }, { -16, 10 }, { 20, 12 } }) do
        local r = big and 5 or 3
        gfx.drawLine(cx + o[1] - r, cy + o[2], cx + o[1] + r, cy + o[2])
        gfx.drawLine(cx + o[1], cy + o[2] - r, cx + o[1], cy + o[2] + r)
      end
    end
  end

  -- what to do (bottom left, away from the faucet)
  if s.state == "empty" then
    drawT("All clean!", 16, 214, true)
  elseif s.state == "washing" then
    drawT("Crank to scrub!", 16, 214, true)
    drawT("B or D-pad: back", 16, 196)
    gfx.setColor(BLACK)
    gfx.drawRect(312, 148, 72, 8)
    gfx.fillRect(314, 150, math.floor(68 * clamp(s.progress, 0, 1)), 4)
  else
    drawT("Squeaky clean!", 16, 214, true)
  end
end

-- Evening Chill: the cup shelf on the wall
local function drawShelf()
  local cu = G.cups
  drawPanelFrame(nil, "SHELF")
  gfx.setColor(BLACK)
  gfx.fillRect(20, 190, 300, 6)
  gfx.fillRect(28, 196, 6, 8)
  gfx.fillRect(306, 196, 6, 8)
  local two = G.cupMax > 5
  local gap = two and 56 or math.min(56, 270 // math.max(1, G.cupMax))
  for pass = 0, 1 do                               -- back row (cups 6 and up) first, the front row sits over it
    for i = 0, G.cupMax - 1 do
      local back = two and i >= 5
      if (pass == 0) == back then
        local x = back and (68 + (i - 5) * gap) or (40 + i * gap)
        local y = back and 128 or 164
        if i < cu.shelf then
          drawCup(x, y, 3, false)
        else
          dashedRect(x - 2, y - 2, 36, 28)
        end
      end
    end
  end
  drawT(string.format("%d of %d cups on the shelf", cu.shelf, G.cupMax), 20, two and 100 or 142, true)
  if cu.hand > 0 then
    drawT("A: put a cup up", 20, 210, true)
    for i = 1, cu.hand do drawCup((two and 340 or 310) + ((i - 1) % (two and 2 or 3)) * 24, 150 + ((i - 1) // (two and 2 or 3)) * 24, 2, false) end
  else
    drawT("Hold a clean cup to place it.", 20, 210)
  end
  drawTR("B: back", 384, 216)
end

local function drawStationPanel()
  if G.st == "dishes" then drawDishes(); return end
  if G.st == "shelf" then drawShelf(); return end
  local c = G.cust
  if c == nil then return end
  if G.st == "register" then drawRegister(c)
  elseif G.st == "coffee" then drawCoffee(c)
  elseif G.st == "mixer" then drawMixer(c)
  elseif G.st == "serve" then drawServe(c) end
end

----------------------------------------------------------------------
-- Drawing: HUD, popups, messages
----------------------------------------------------------------------
function UI.stopwatch(t)
  local secs = math.floor(t)
  if secs >= 3600 then
    return string.format("%d:%02d:%02d", secs // 3600, (secs % 3600) // 60, secs % 60)
  end
  return string.format("%d:%02d", secs // 60, secs % 60)
end

local function drawHUD()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 0, 400, 18)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTR(money(G.cash + G.tips), 394, 1, true)
  if G.mode == "rush" then
    local limit = RUSH_SECONDS
    local rem = limit - G.t
    drawT(UI.stopwatch(math.max(0, math.ceil(rem))), 6, 1, true)           -- counting down from 1:30
    if rem <= 10 and rem > 0 then               -- closing countdown: 10, 9, 8...
      drawTC("Closing in " .. math.ceil(rem), 200, 1, true)
    end
  else
    drawT(UI.stopwatch(G.t), 6, 1, true)           -- how long you've been playing
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if G.mode == "cafe" then CAFE.drawStars(170, 9, 6, 15, G.cafe.stars, WHITE) end
  if G.mode == "rush" then
    local prog = clamp(G.t / RUSH_SECONDS, 0, 1)
    gfx.setColor(WHITE)
    gfx.fillRect(0, 16, math.floor(400 * prog), 2)
  end
  gfx.setColor(BLACK)
end

function UI.drawPopups()
  for _, p in ipairs(G.popups) do
    local k = p.t / p.life
    local y = math.floor(p.y - 22 * k)
    -- small popups (tips over the jar) use the thin font and tight padding
    local pad = p.small and 3 or 5
    gfx.setFont(p.small and fontNormal or fontBold)
    local w = gfx.getTextSize(p.s)
    local bw = w + pad * 2
    local bx = clamp(p.x - bw // 2, 2, 398 - bw)
    local bh = p.small and 20 or 20
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, y - 2, bw, bh, 4)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(bx, y - 2, bw, bh, 4)
    drawT(p.s, bx + pad, p.small and y + 1 or y, not p.small)
  end
end

function UI.drawMessage()
  if G.msg == nil then return end
  gfx.setFont(fontBold)
  local w = gfx.getTextSize(G.msg)
  local bw = w + 20
  local bx = 200 - bw // 2
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, 188, bw, 22, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(bx, 188, bw, 22, 6)
  gfx.setLineWidth(1)
  drawTC(G.msg, 200, 191, true)
end

local function needsCrank()
  if G.st == "dishes" then return G.sink.state == "washing" end
  local c = G.cust
  if c == nil or G.st == nil then return false end
  if G.st == "register" then return c.reg.state == "crank" end
  if G.st == "coffee" then return UI.crankPour == true and c.cof.phase == "pour" end
  if G.st == "mixer" then return c.mix.phase == 2 end
  return false
end

local function drawPlay()
  drawWall()
  drawPlayer()                                 -- the barista stands behind the counter and the machines
  drawCounter()
  drawFloor()
  UI.drawDoor()
  if G.pets then CAFE.drawPets() end
  -- people, back of the line first so the front of the line is on top
  for i = #G.line, 1, -1 do drawCustomer(G.line[i], false) end
  for _, c in ipairs(G.others) do drawCustomer(c, false) end
  local c = G.cust
  if c then drawCustomer(c, true) end
  if c and c.stage == 1 and G.st == nil then drawBubble(c) end           -- (gone once the order has been rung in)
  if G.st then drawStationPanel() end
  UI.drawPopups()
  drawHUD()
  UI.drawMessage()
  if needsCrank() then crankHelpDraw() end
end

----------------------------------------------------------------------
-- Title screen
----------------------------------------------------------------------
-- Big headline text: drawn once into an image of exactly the text's size, then
-- scaled up to fill the box (boxH tall, as wide as the screen allows) and centred.
local bigTextCache = {}
local function bigText(str, boxY, boxH, maxScale)
  local e = bigTextCache[str]
  if e == nil then
    gfx.setFont(fontBold)
    local w, h = gfx.getTextSize(str)
    local img = nil
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setFont(fontBold)
      gfx.drawText(str, 0, 0)
      gfx.popContext()
    end)
    e = { img = ok and img or nil, w = w, h = h }
    bigTextCache[str] = e
  end
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  if e.img then
    local scale = math.min(maxScale, 376 / e.w, boxH / e.h)
    local x = math.floor((400 - e.w * scale) / 2 + 0.5)
    local y = math.floor(boxY + (boxH - e.h * scale) / 2 + 0.5)
    e.img:drawScaled(x, y, scale)
  else
    drawTC(str, 200, boxY + boxH // 2 - 8, true)
  end
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
end

-- the big steaming mug (ox, oy move it around the screen)
function UI.drawBigMug(ox, oy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawCircleAtPoint(224 + ox, 164 + oy, 9)
  gfx.setLineWidth(1)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(178 + ox, 146 + oy, 46, 38, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(182 + ox, 150 + oy, 38, 10)
  gfx.setColor(BLACK)
  gfx.fillRect(166 + ox, 186 + oy, 70, 4)
  for k = -1, 1 do
    local px, py = 0, 0
    for i = 0, 8 do
      local yy = 140 + oy - i * 2.5
      local xx = 200 + ox + k * 10 + math.sin(frames * 0.15 + i * 0.7 + k) * 3
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

local function drawMenu()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 10, 400, 84)
  bigText("Coffee Please!!!", 14, 56, 5)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC("by Christian G", 200, 72, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)

  UI.drawBigMug(-100, 6)

  -- four boxes: three game modes and the high scores
  local opts = { { "CAFE", "build your own cafe" },
                 { "RUSH HOUR", "90 sec, high score chaser" },
                 { "EVENING CHILL", "time free mode, relax" },
                 { "HIGH SCORES" } }
  for i, o in ipairs(opts) do
    local y = 100 + (i - 1) * 35
    gfx.setColor(BLACK)
    if menuSel == i then
      gfx.fillRoundRect(196, y, 196, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(196, y, 196, 31, 8)
      gfx.setLineWidth(1)
    end
    if o[2] then
      drawT(o[1], 206, y + 1, true)
      drawT(o[2], 206, y + 15)
    else
      drawT(o[1], 206, y + 8, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if menuSel == i then CAFE.pointer(358, y + 11) end           -- the same mouse arrow the shop uses, resting on the box
  end
end

-- ---- settings (from the Menu button on the title screen) ------------------
function UI.decoCup(x, y)
  gfx.setColor(WHITE); gfx.fillRect(x, y + 3, 8, 7)
  gfx.setColor(BLACK); gfx.drawRect(x, y + 3, 8, 7)
  gfx.drawCircleAtPoint(x + 9, y + 6, 2)
  gfx.fillRect(x + 1, y + 4, 6, 2)
  gfx.drawPixel(x + 3, y); gfx.drawPixel(x + 2, y + 1); gfx.drawPixel(x + 4, y + 1)
end

function UI.decoBean(x, y)
  gfx.setColor(BLACK)
  gfx.fillEllipseInRect(x, y + 1, 8, 7)
  gfx.setColor(WHITE)
  gfx.drawLine(x + 2, y + 7, x + 5, y + 2)
  gfx.setColor(BLACK)
end

function UI.drawSettings()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 16, 400, 34)
  bigText("Settings", 19, 28, 3)
  -- cups and beans all round the border
  local n = 0
  for x = 6, 386, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoCup(x, 2); UI.decoCup(x, 226) else UI.decoBean(x, 3); UI.decoBean(x, 227) end
  end
  n = 0
  for y = 58, 206, 24 do
    n = n + 1
    if n % 2 == 1 then UI.decoBean(4, y); UI.decoBean(388, y) else UI.decoCup(3, y); UI.decoCup(386, y) end
  end
  local rows = { { "Pour with", UI.crankPour and "CRANK" or "TILT" },
                 { "Music", UI.musicOn and "ON" or "OFF" },
                 { "Back" } }
  for i, r in ipairs(rows) do
    local y = 72 + (i - 1) * 40
    local sel = UI.settings.sel == i
    gfx.setColor(BLACK)
    if sel then
      gfx.fillRoundRect(100, y, 200, 31, 8)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRoundRect(100, y, 200, 31, 8)
      gfx.setLineWidth(1)
    end
    if r[2] then
      drawT(r[1], 112, y + 8, true)
      drawTR(r[2], 262, y + 8, true)
    else
      drawTC(r[1], 200, y + 8, true)
    end
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    if sel then CAFE.pointer(272, y + 12) end
  end
  drawTC(UI.settings.sel == 1 and (UI.crankPour and "Turn the crank to pour (clockwise)" or "Tilt the Playdate to pour") or " ", 200, 196, false)
end

function UI.updateSettings()
  local st = UI.settings
  local function toggle()
    if st.sel == 1 then
      UI.crankPour = not UI.crankPour
      saveScores()
    elseif st.sel == 2 then
      UI.musicOn = not UI.musicOn
      pcall(function() if UI.musicItem then UI.musicItem:setValue(UI.musicOn) end end)
    end
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonDown) then st.sel = st.sel % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then st.sel = (st.sel + 1) % 3 + 1; sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    if st.sel < 3 then toggle() end
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if st.sel == 3 then UI.settings = nil; sfxClick() else toggle() end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    UI.settings = nil; sfxClick()
  end
end

function UI.setSettingsItem(on)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if on and UI.settingsItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Settings", function()
        if state == STATE_MENU and UI.settings == nil then UI.settings = { sel = 1 } end
      end)
    end)
    if ok then UI.settingsItem = item end
  elseif (not on) and UI.settingsItem ~= nil then
    pcall(function() menu:removeMenuItem(UI.settingsItem) end)
    UI.settingsItem = nil
  end
end

----------------------------------------------------------------------
-- Closing time: initials entry, then the high score board
----------------------------------------------------------------------
local function drawEntry()
  gfx.setColor(BLACK)
  gfx.fillRect(0, 6, 400, 40)
  bigText(G.mode == "chill" and "Shift Over!" or "Closing Time!", 9, 34, 3)

  local rows = {
    { "Customers served", tostring(G.served) },
    { "Sales", money(G.cash) },
    { "Tips", money(G.tips) },
    { "Walked out", tostring(G.missed) },
  }
  for i, row in ipairs(rows) do
    local y = 50 + (i - 1) * 15
    drawT(row[1], 90, y)
    drawTR(row[2], 310, y)
  end
  gfx.setColor(BLACK)
  gfx.fillRect(80, 112, 240, 2)
  drawT("TOTAL MADE", 90, 116, true)
  drawTR(money(G.total), 310, 116, true)

  drawTC("ENTER YOUR INITIALS", 200, 138, true)
  for i = 1, 3 do
    local bx = 200 - 54 + (i - 1) * 40
    gfx.setColor(BLACK)
    if i == entry.cur then
      gfx.fillRect(bx, 174, 32, 32)
      gfx.fillTriangle(bx + 10, 170, bx + 22, 170, bx + 16, 163)
      gfx.fillTriangle(bx + 10, 210, bx + 22, 210, bx + 16, 217)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    else
      gfx.setLineWidth(2)
      gfx.drawRect(bx, 174, 32, 32)
      gfx.setLineWidth(1)
    end
    drawTC(string.char(65 + entry.letters[i]), bx + 16, 180, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
  end
  gfx.setColor(BLACK)
  drawTC("Up/Down or crank: letter    A: next", 200, 222)
end

-- a small steaming mug for the corners of the board
function UI.drawSmallMug(x, y)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y + 10, 26, 20, 4)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRoundRect(x, y + 10, 26, 20, 4)
  gfx.drawCircleAtPoint(x + 30, y + 20, 6)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillRect(x + 3, y + 13, 20, 5)
  gfx.setColor(BLACK)
  gfx.fillRect(x - 4, y + 31, 38, 3)
  for k = 0, 1 do
    local px, py = 0, 0
    for i = 0, 5 do
      local yy = y + 6 - i * 2
      local xx = x + 8 + k * 9 + math.sin(frames * 0.15 + i * 0.8 + k * 2) * 2
      if i > 0 then gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), math.floor(yy)) end
      px, py = xx, yy
    end
  end
end

-- the high-score look: double border, bobbing beans, steam rising from two cups
function UI.beanFrame()
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawRoundRect(2, 2, 396, 236, 10)
  gfx.setLineWidth(1)
  gfx.drawRoundRect(7, 7, 386, 226, 7)
  for i = 0, 5 do
    local bob = math.floor(math.sin(frames * 0.12 + i * 1.1) * 3 + 0.5)
    drawBean(22 + (i % 2) * 16, 50 + i * 24 + bob, 1)
    drawBean(378 - (i % 2) * 16, 50 + i * 24 - bob, 1)
  end
  for _, bx in ipairs({ 26, 35, 358, 367 }) do
    local px, py
    for yy = 204, 40, -3 do
      local xx = bx + math.sin(frames * 0.12 + yy * 0.09 + bx) * 3
      if px and (yy // 3 + (frames // 6)) % 6 ~= 0 then
        gfx.drawLine(math.floor(px), math.floor(py), math.floor(xx), yy)
      end
      px, py = xx, yy
    end
  end
  UI.drawSmallMug(18, 198)
  UI.drawSmallMug(350, 198)
  gfx.setColor(BLACK)
end

local function drawBoard()
  local list = boards[board.view]
  local name = (board.view == "chill") and "EVENING CHILL" or "RUSH HOUR"

  UI.beanFrame()

  -- title band with arrows to switch boards
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(name .. " HIGH SCORES", 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(WHITE)
  gfx.fillTriangle(24, 23, 32, 17, 32, 29)
  gfx.fillTriangle(376, 23, 368, 17, 368, 29)
  gfx.setColor(BLACK)

  local function row(i, y, label)
    local e = list[i]
    local mine = (board.rank == i and board.view == board.m)
    if mine and (frames // 8) % 2 == 0 then
      gfx.setColor(BLACK)
      gfx.fillRect(58, y - 2, 286, 17)
      gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
    end
    drawTR(label or tostring(i), 92, y - 1, true)
    drawT(e.n, 104, y - 1, true)
    drawTR(money(e.s), 336, y - 1, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
  end

  for i = 1, math.min(10, #list) do row(i, 39 + (i - 1) * 16) end

  -- didn't make the top 10? your score is shown just below it
  if board.rank and board.view == board.m and board.rank > 10 then
    for x = 60, 340, 6 do gfx.drawLine(x, 198, x + 2, 198) end
    row(board.rank, 199, "#" .. board.rank)
  end

  drawTC("B: back", 200, 216, true)
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------
local function goTitle()
  sfxClick()
  transitionTo(function()
    if G then closeStation() end
    setShiftMenu(false, false)
    state = STATE_MENU
  end)
end

CAFE.goTitle = function() goTitle() end

local function startGame(mode)
  sfxClick()
  sfxStart()
  transitionTo(function()
    newGame(mode)
    state = STATE_PLAY
  end)
end

function UI.openBoard(m)
  transitionTo(function()
    board = { mode = "view", rank = nil, m = m, view = m, t = 0 }
    state = STATE_BOARD
  end)
end

local function updateMenu()
  if pd.buttonJustPressed(pd.kButtonDown) then
    menuSel = menuSel % 4 + 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonUp) then
    menuSel = (menuSel + 2) % 4 + 1
    sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonA) then
    if menuSel == 4 then
      sfxClick()
      UI.openBoard("rush")
    elseif menuSel == 1 then
      sfxClick()
      CAFE.open()
    else
      startGame(menuSel == 3 and "chill" or "rush")
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    sfxClick()
    UI.openBoard("rush")
  end
end

local function updateEntry(dt)
  G.endT = G.endT + dt
  if G.endT < 1.5 then return end   -- ignore button mashing as the shift ends
  local e = entry
  local function bump(d)
    e.letters[e.cur] = (e.letters[e.cur] + d) % 26
    sfxClick()
  end
  if pd.buttonJustPressed(pd.kButtonUp) then bump(1)
  elseif pd.buttonJustPressed(pd.kButtonDown) then bump(-1)
  elseif pd.buttonJustPressed(pd.kButtonLeft) then e.cur = math.max(1, e.cur - 1); sfxClick()
  elseif pd.buttonJustPressed(pd.kButtonRight) then e.cur = math.min(3, e.cur + 1); sfxClick() end

  -- the crank spins through the alphabet too
  e.crank = e.crank + pd.getCrankChange()
  while e.crank >= 30 do e.crank = e.crank - 30; bump(1) end
  while e.crank <= -30 do e.crank = e.crank + 30; bump(-1) end

  if pd.buttonJustPressed(pd.kButtonA) then
    if e.cur < 3 then
      e.cur = e.cur + 1
      sfxPop()
    else
      local name = string.char(65 + e.letters[1], 65 + e.letters[2], 65 + e.letters[3])
      local rank = insertScore(G.mode, name, G.total)
      sfxGood()
      local m = G.mode
      transitionTo(function()
        board = { mode = "after", rank = rank, m = m, view = m, t = 0 }
        state = STATE_BOARD
      end)
    end
  elseif pd.buttonJustPressed(pd.kButtonB) then
    if e.cur > 1 then e.cur = e.cur - 1; sfxClick() end
  end
end

local function updateBoard(dt)
  board.t = board.t + dt
  -- (after a game the buttons stay locked a moment so a mashed A can't restart it)
  if board.t < (board.mode == "after" and 1.2 or 0.2) then return end
  if pd.buttonJustPressed(pd.kButtonLeft) or pd.buttonJustPressed(pd.kButtonRight) then
    board.view = (board.view == "rush") and "chill" or "rush"
    sfxClick()
    return
  end
  if board.mode == "after" then
    if pd.buttonJustPressed(pd.kButtonA) then
      startGame(board.m)
    elseif pd.buttonJustPressed(pd.kButtonB) then
      sfxClick()
      goTitle()
    end
  else
    if pd.buttonJustPressed(pd.kButtonB) or pd.buttonJustPressed(pd.kButtonA) then
      sfxClick()
      goTitle()
    end
  end
end

----------------------------------------------------------------------
-- CAFE mode: three save files, a shop between shifts, stars, decorations, pets
----------------------------------------------------------------------
CAFE.STATE = 5
CAFE.PRICE = 3          -- every shop price is multiplied by this
CAFE.CUP_COST  = { 10, 20, 35, 50, 70, 90, 110, 130 }   -- dollars (x PRICE): cup 3, 4 ... 10
CAFE.SEAT_N    = { 2, 4, 6, 8, 13 }           -- seats after each seating upgrade (the last one is the corner booth)
CAFE.SEAT_COST = { 60 / CAFE.PRICE, 40, 60, 85, 120 }     -- (the first table, in the starting kit, is $60 in the shop)
-- everything you can buy for the looks. kind: wall / floor (placed on a grid spot),
-- rug (one at a time), ceiling, pet.
CAFE.ITEMS = {
  { id = "clock",    name = "Wall clock",     kind = "wall",    cost = 25 },
  { id = "cuckoo",   name = "Cuckoo clock",   kind = "wall",    cost = 55 },
  { id = "calendar", name = "Calendar",       kind = "wall",    cost = 20 },
  { id = "plant",    name = "Spiky plant",    kind = "floor",   cost = 30 },
  { id = "cactus",   name = "Cactus",         kind = "floor",   cost = 25 },
  { id = "fern",     name = "Leafy fern",     kind = "floor",   cost = 30 },
  { id = "flowers",  name = "Flower pot",     kind = "floor",   cost = 35 },
  { id = "tree",     name = "Christmas tree", kind = "floor",   cost = 80 },
  { id = "pumpkin",  name = "Pumpkin",        kind = "floor",   cost = 20 },
  { id = "palm",     name = "Palm tree",      kind = "floor",   cost = 45 },
  { id = "snake",    name = "Snake plant",    kind = "floor",   cost = 30 },
  { id = "sunflower", name = "Sunflowers",    kind = "floor",   cost = 35 },
  { id = "bonsai",   name = "Bonsai",         kind = "floor",   cost = 40 },
  { id = "monstera", name = "Monstera",       kind = "floor",   cost = 40 },
  { id = "saltlamp", name = "Salt lamp",      kind = "counter", cost = 16 },
  { id = "lavalamp", name = "Lava lamp",      kind = "counter", cost = 18 },
  { id = "floorlamp", name = "Floor lamp",    kind = "floor",   cost = 35 },
  { id = "neoncup",  name = "Neon cup sign",  kind = "wall",    cost = 40 },
  { id = "wf1", name = "Single pane", kind = "frame", cost = 25 },
  { id = "wf2", name = "Six panes", kind = "frame", cost = 30 },
  { id = "wf3", name = "Diamond panes", kind = "frame", cost = 35 },
  { id = "wf4", name = "Windowsill", kind = "frame", cost = 35 },
  { id = "wf5", name = "Arched window", kind = "frame", cost = 40 },
  { id = "wf6", name = "Shutters", kind = "frame", cost = 45 },
  { id = "wc1", name = "Plain curtains", kind = "curtain", cost = 15 },
  { id = "wc2", name = "Checker curtains", kind = "curtain", cost = 18 },
  { id = "wc3", name = "Striped curtains", kind = "curtain", cost = 18 },
  { id = "wc4", name = "Scalloped valance", kind = "curtain", cost = 20 },
  { id = "wc5", name = "Lace curtains", kind = "curtain", cost = 22 },
  { id = "wc6", name = "Polka dot curtains", kind = "curtain", cost = 20 },
  { id = "wc7", name = "Coffee bean curtains", kind = "curtain", cost = 25 },
  { id = "wc8", name = "Window blinds", kind = "curtain", cost = 20 },
  { id = "wc9", name = "Heart curtains", kind = "curtain", cost = 22 },
  { id = "wc10", name = "Starry night curtains", kind = "curtain", cost = 28 },
  { id = "tulips",   name = "Tulip pot",      kind = "counter", cost = 15 },
  { id = "succ",     name = "Succulent",      kind = "counter", cost = 12 },
  { id = "daisies",  name = "Daisy vase",     kind = "counter", cost = 18 },
  { id = "minicac",  name = "Mini cactus",    kind = "counter", cost = 12 },
  { id = "herbs",    name = "Herb pot",       kind = "counter", cost = 15 },
  { id = "ivy",      name = "Ivy vines",      kind = "shelf",   cost = 25 },
  { id = "bloomvine", name = "Flowering vines", kind = "shelf", cost = 35 },
  { id = "lights",   name = "String lights",  kind = "ceiling", cost = 45 },
  { id = "rug",      name = "Welcome rug",    kind = "rug",     cost = 35 },
  { id = "rug2",     name = "Striped rug",    kind = "rug",     cost = 40 },
  { id = "rug3",     name = "Checker rug",    kind = "rug",     cost = 45 },
  { id = "rug4",     name = "Polka dot rug",  kind = "rug",     cost = 45 },
  { id = "rug5",     name = "Lattice rug",    kind = "rug",     cost = 50 },
  { id = "rug6",     name = "Plaid rug",      kind = "rug",     cost = 50 },
  { id = "rug7",     name = "Coffee bean rug", kind = "rug",    cost = 55 },
  { id = "run6",     name = "Polka dot runner", kind = "runner", cost = 38 },
  { id = "run7",     name = "Zigzag runner",  kind = "runner", cost = 40 },
  { id = "run8",     name = "Plaid runner",   kind = "runner", cost = 42 },
  { id = "run1",     name = "Red carpet runner", kind = "runner", cost = 40 },
  { id = "run2",     name = "Striped runner", kind = "runner", cost = 35 },
  { id = "run3",     name = "Checker runner", kind = "runner", cost = 35 },
  { id = "run4",     name = "Diamond runner", kind = "runner", cost = 40 },
  { id = "run5",     name = "Coffee bean runner", kind = "runner", cost = 45 },
  { id = "t1",       name = "Tiny landscape",  kind = "tiny", cost = 8 },
  { id = "t2",       name = "Tiny heart",      kind = "tiny", cost = 8 },
  { id = "t3",       name = "Tiny sunburst",   kind = "tiny", cost = 10 },
  { id = "t4",       name = "Tiny mug print",  kind = "tiny", cost = 10 },
  { id = "t5",       name = "Cat portrait",    kind = "tiny", cost = 12 },
  { id = "t6",       name = "Tiny mirror",     kind = "tiny", cost = 12 },
  { id = "t7",       name = "Party bunting",   kind = "tiny", cost = 14 },
  { id = "t8",       name = "Paper plane",     kind = "tiny", cost = 8 },
  { id = "t9",       name = "Music notes",     kind = "tiny", cost = 10 },
  { id = "t10",      name = "Moon and stars",  kind = "tiny", cost = 12 },
  { id = "t12",      name = "Sailboat",        kind = "tiny", cost = 10 },
  { id = "cloth1",   name = "Checker tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth2",   name = "Striped tablecloth", kind = "cloth", cost = 30 },
  { id = "cloth3",   name = "Lace tablecloth", kind = "cloth", cost = 40 },
  { id = "cp1",      name = "Table flowers",  kind = "centerpiece", cost = 20 },
  { id = "cp2",      name = "Table candle",   kind = "centerpiece", cost = 15 },
  { id = "cp3",      name = "Table sprig",    kind = "centerpiece", cost = 18 },
  { id = "cp4",      name = "Table cactus",   kind = "centerpiece", cost = 18 },
  { id = "cp5",      name = "Table pumpkin",  kind = "centerpiece", cost = 18 },
  { id = "cp6",      name = "Table Christmas tree", kind = "centerpiece", cost = 22 },
  { id = "cat",      name = "Black cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "tuxcat",   name = "Tuxedo cat",     kind = "pet",     cost = 150, species = "cat" },
  { id = "tabbycat", name = "Tabby cat",      kind = "pet",     cost = 150, species = "cat" },
  { id = "calicocat", name = "Calico cat",    kind = "pet",     cost = 160, species = "cat" },
  { id = "graycat",  name = "Gray cat",       kind = "pet",     cost = 150, species = "cat" },
  { id = "dog",      name = "Black dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "dalmatian", name = "Dalmatian",     kind = "pet",     cost = 160, species = "dog" },
  { id = "husky",    name = "Husky",          kind = "pet",     cost = 170, species = "dog" },
  { id = "patchdog", name = "Patch dog",      kind = "pet",     cost = 150, species = "dog" },
  { id = "goldendog", name = "Golden dog",    kind = "pet",     cost = 160, species = "dog" },
  { id = "cattree",  name = "Cat tree",       kind = "floor",   cost = 60, needs = "cat" },
  { id = "dogbed",   name = "Dog bed",        kind = "floor",   cost = 45, needs = "dog" },
}
CAFE.byId = {}
for _, it in ipairs(CAFE.ITEMS) do CAFE.byId[it.id] = it end
-- a few words under the price in the shop
CAFE.DESC = {
  clock = "Tick-tock!", cuckoo = "Cuckoo! Cuckoo!", calendar = "Every day counts",
  tree = "Ho ho ho!", pumpkin = "Spooky season!", palm = "Vacation vibes",
  cactus = "Ouch! Cute, though", flowers = "Smells lovely", plant = "Low maintenance",
  lights = "Cozy glow", ivy = "Hanging around", bloomvine = "In full bloom",
  rug = "Wipe your feet", rug2 = "Wipe your feet", rug3 = "Wipe your feet",
  run1 = "Roll out the red carpet", run2 = "Rolls out at the register", run3 = "Rolls out at the register",
  run4 = "Rolls out at the register", run5 = "Rolls out at the register",
  t1 = "Hang it up high", t2 = "Made with love", t3 = "Rise and shine", t4 = "Mug shot", t5 = "Meow",
  t6 = "Mirror, mirror", t7 = "Party time!", t8 = "Fly away", t9 = "La la la", t10 = "Sweet dreams",
  t12 = "Smooth sailing",
  cloth1 = "Dress up every table", cloth2 = "Dress up every table", cloth3 = "Dress up every table",
  cp1 = "A centrepiece for every table", cp2 = "Dinner by candlelight", cp3 = "A little green", cp4 = "Tiny and spiky",
  rug4 = "Wipe your feet", rug5 = "Wipe your feet", rug6 = "Wipe your feet", rug7 = "Wipe your feet",
  run6 = "Rolls out at the register", run7 = "Rolls out at the register", run8 = "Rolls out at the register",
  cp5 = "Spooky season, every table", cp6 = "Merry little tables",
  cat = "Boosts stars and tips", dog = "Boosts stars and tips",
  cattree = "The cat will love it", dogbed = "A nap spot for the dog",
  wf1 = "One big pane", wf2 = "Six little panes", wf3 = "Fancy diamonds", wf4 = "A ledge for plants", wf5 = "A rounded top", wf6 = "Open the shutters",
  wc1 = "Soft and simple", wc2 = "Checked and cozy", wc3 = "Stripes all the way", wc4 = "A frilly top", wc5 = "Light and lacy",
  wc6 = "Spot on", wc7 = "Smells like coffee", wc8 = "Half way down", wc9 = "Made with love", wc10 = "Twinkle twinkle",
  tuxcat = "Dressed for dinner", tabbycat = "Stripes and sass", calicocat = "Patches of everything", graycat = "Soft and silvery",
  dalmatian = "Spots on spots", husky = "Fluffy and loud", patchdog = "One patchy eye", goldendog = "A very good boy",
  saltlamp = "A warm, glowing rock", lavalamp = "Groovy, baby", floorlamp = "Soft, cozy light", neoncup = "Always open",
}
-- grid spots. The wall has three free spots (the name sign uses the last two).
CAFE.WSLOT = { { 3, 21, 24, 28 }, { 272, 21, 43, 28 }, { 319, 21, 43, 28 }, { 224, 21, 24, 28 }, { 200, 21, 24, 28 }, { 248, 21, 24, 28 } }   -- (the 4th is where the fridge used to be)   -- x, y, w, h
CAFE.XSLOT = { { 112, 61 }, { 150, 61 }, { 190, 61 }, { 230, 61 }, { 268, 61 }, { 304, 61 }, { 340, 61 } }   -- the lower row of the wall
-- All wall decor (clocks, pictures, signs) share one set of tiles: the six up by the ceiling, then the seven below them.
CAFE.TILES = {}
for i, sl in ipairs(CAFE.WSLOT) do CAFE.TILES[i] = { sl[1], sl[2], sl[3], sl[4] } end
for j, sl in ipairs(CAFE.XSLOT) do CAFE.TILES[#CAFE.WSLOT + j] = { sl[1] - 19, 51, 38, 20 } end
function CAFE.gk(kind) return (kind == "tiny") and "wall" or kind end         -- tiny pictures live on the same grid as wall decor
function CAFE.tileCenter(i) local t = CAFE.TILES[i]; return t[1] + t[3] // 2, t[2] + t[4] // 2 end
CAFE.CSLOT = { { 92, 86 }, { 164, 86 }, { 236, 86 }, { 302, 86 }, { 358, 86 } }   -- blank spots on the counter
-- floor spots hug the walls: down the left, in the right-hand corner, and along the counter
CAFE.FSLOT = { { 20, 134 }, { 20, 170 }, { 20, 204 }, { 382, 132 }, { 100, 130 }, { 200, 130 }, { 300, 130 } }
-- where the tables can go (the first four match the original row along the bottom)
CAFE.TSLOT = { { 132, 208 }, { 186, 208 }, { 240, 208 }, { 294, 208 }, { 150, 170 }, { 210, 170 }, { 270, 170 } }
function CAFE.applyLayout(d)
  if not CAFE.defT then
    CAFE.defT, CAFE.defS = {}, {}
    for i, t in ipairs(TABLES) do CAFE.defT[i] = { t.x, t.y } end
    for i, q in ipairs(SEATS) do CAFE.defS[i] = { q.x, q.y } end
  end
  for i, t in ipairs(CAFE.defT) do TABLES[i].x, TABLES[i].y = t[1], t[2] end
  for i, q in ipairs(CAFE.defS) do SEATS[i].x, SEATS[i].y = q[1], q[2] end
  if d then
    for k = 1, 4 do
      local sl = d.tables[k] and CAFE.TSLOT[d.tables[k]]
      if sl then
        TABLES[k].x, TABLES[k].y = sl[1], sl[2]
        SEATS[2 * k - 1].x, SEATS[2 * k - 1].y = sl[1] - 17, sl[2]
        SEATS[2 * k].x, SEATS[2 * k].y = sl[1] + 17, sl[2]
      end
    end
  end
end
CAFE.slots = {}
CAFE.sel, CAFE.mode, CAFE.erase = 1, "slots", nil
CAFE.name, CAFE.letter, CAFE.crank, CAFE.onDone = "", 0, 0, false
CAFE.shopSel, CAFE.scroll, CAFE.report, CAFE.msg, CAFE.msgT = 1, 0, nil, nil, 0
CAFE.tab, CAFE.focus, CAFE.crankAcc, CAFE.tabPos = 1, "tabs", 0, 1       -- shop: which tab, list or bottom buttons, crank scrolling
CAFE.cur, CAFE.slot = nil, 1
CAFE.pend, CAFE.spots, CAFE.spotSel = nil, {}, 1

function CAFE.seatsOf(step) if step <= 0 then return 0 end return CAFE.SEAT_N[step] end
function CAFE.seatOffOf(d)                     -- seats that belong to tables you've switched off
  local off = {}
  for k = 1, 4 do
    if d.off and d.off[k] then off[2 * k - 1] = true; off[2 * k] = true end
  end
  return off
end
function CAFE.seatCountOf(d)
  local n, off = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d)
  for i in pairs(off) do if i <= CAFE.seatsOf(d.seatStep) then n = n - 1 end end
  return n
end

function CAFE.fresh(name)
  local rich = (string.upper(name or "") == "RICH")      -- test cheat: $99999 to start, and nobody gets impatient
  return { v = 2, tv = 2, name = name, money = rich and 9999900 or 0, cups = 0, seatStep = 0, stars = 0, decor = {}, place = {}, tables = {}, off = {}, shifts = 0 }
end

-- ---- grid bookkeeping ----------------------------------------------------------------
function CAFE.slotTaken(d, kind, slot)
  kind = CAFE.gk(kind)
  if kind == "wall" and d.sign ~= false and (slot == 2 or slot == 3) then return true end
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.gk(it.kind) == kind and d.decor[it.id] == "on" and d.place[it.id] == slot then return true end
  end
  return false
end

function CAFE.isGrid(it) return it.kind == "wall" or it.kind == "floor" or it.kind == "counter" or it.kind == "tiny" end

function CAFE.freeSlots(d, kind, id)
  kind = CAFE.gk(kind)
  local n = (kind == "wall") and #CAFE.TILES or ((kind == "counter") and #CAFE.CSLOT or #CAFE.FSLOT)
  if kind == "wall" and id == "cuckoo" then n = #CAFE.WSLOT end        -- (its pendulum needs the tall tiles up top)
  local list = {}
  for i = 1, n do
    if not CAFE.slotTaken(d, kind, i) then list[#list + 1] = i end
  end
  if kind == "wall" then
    table.sort(list, function(a, b)
      local ta, tb = CAFE.TILES[a], CAFE.TILES[b]
      if ta[2] ~= tb[2] then return ta[2] < tb[2] end
      return ta[1] < tb[1]
    end)
  end
  return list
end

function CAFE.fixPlacement(d)               -- old saves / odd data: give everything a legal spot
  local old = {}
  for _, it in ipairs(CAFE.ITEMS) do
    if CAFE.isGrid(it) and d.decor[it.id] == "on" then
      old[it.id] = d.place[it.id]
      d.place[it.id] = nil
    end
  end
  for _, it in ipairs(CAFE.ITEMS) do
    if old[it.id] ~= nil or (CAFE.isGrid(it) and d.decor[it.id] == "on") then
      local want = old[it.id]
      local free = CAFE.freeSlots(d, it.kind, it.id)
      local ok = false
      for _, f in ipairs(free) do if f == want then ok = true end end
      if ok then d.place[it.id] = want
      elseif #free > 0 then d.place[it.id] = free[1]
      else d.decor[it.id] = "off" end
    end
  end
end

function CAFE.read(i)
  local ok, d = pcall(pd.datastore.read, "cafe" .. i)
  if not ok or type(d) ~= "table" or type(d.name) ~= "string" then return nil end
  d.money = tonumber(d.money) or 0
  d.cups = clamp(math.floor(tonumber(d.cups) or 2), 0, 10)
  d.seatStep = clamp(math.floor(tonumber(d.seatStep) or 0), 0, 5)
  d.stars = clamp(tonumber(d.stars) or 0, 0, 5)
  d.shifts = tonumber(d.shifts) or 0
  if type(d.decor) ~= "table" then d.decor = {} end
  if type(d.place) ~= "table" then d.place = {} end
  if type(d.tables) ~= "table" then d.tables = {} end
  if type(d.off) ~= "table" then d.off = {} end
  for k = 1, math.min(d.seatStep, 4) do
    if d.off[k] then d.tables[k] = 0
    elseif not CAFE.TSLOT[d.tables[k] or 0] then d.tables[k] = k end
  end
  if d.tv ~= 2 then                              -- older saves: the little pictures were numbered on their own row
    for _, it in ipairs(CAFE.ITEMS) do
      if it.kind == "tiny" and d.place[it.id] then d.place[it.id] = d.place[it.id] + #CAFE.WSLOT end
    end
    d.tv = 2
  end
  CAFE.fixPlacement(d)
  return d
end

function CAFE.rich() return G ~= nil and G.mode == "cafe" and G.cafe ~= nil and string.upper(G.cafe.name or "") == "RICH" end

function CAFE.write()
  CAFE.rc = nil
  if CAFE.cur then pcall(pd.datastore.write, CAFE.cur, "cafe" .. CAFE.slot) end
end

function CAFE.addStars(d)
  if G and G.cafe then G.cafe.stars = clamp(math.floor((G.cafe.stars + d) * 100 + 0.5) / 100, 0, 5) end
end

-- a slip-up costs a little of a star; the more you've decorated, the less customers mind
function CAFE.mistake(amt)
  if not (G and G.mode == "cafe" and G.cafe) then return end
  local n = G.cafe.seatStep or 0
  for _, v in pairs(G.cafe.decor) do if v == "on" then n = n + 1 end end
  local mult = clamp(1 - 0.025 * n, 0.25, 1)
  CAFE.addStars(-amt * mult)
end

function CAFE.petOn(d, species)                 -- which cat / dog (if any) is out in the cafe
  for _, it in ipairs(CAFE.ITEMS) do
    if it.species == species and d.decor[it.id] == "on" then return it.id end
  end
  return nil
end

function CAFE.hasNeed(d, need)                  -- cat tree wants a cat of any coat, dog bed any dog
  if need == "cat" or need == "dog" then
    for _, it in ipairs(CAFE.ITEMS) do
      if it.species == need and d.decor[it.id] ~= nil then return true end
    end
    return false
  end
  return d.decor[need] ~= nil
end

function CAFE.petCount()
  local d = G and G.cafe
  if not d then return 0 end
  return (CAFE.petOn(d, "cat") and 1 or 0) + (CAFE.petOn(d, "dog") and 1 or 0)
end

-- ---- customer flow: it ebbs and flows, but never goes dead ---------------------------------------
function CAFE.flowUpdate(dt)
  local f = G.flow
  f.timer = f.timer - dt
  if f.timer <= 0 then
    f.target = math.random()
    f.timer = 25 + math.random() * 40
  end
  f.m = f.m + (f.target - f.m) * math.min(1, dt * 0.15)
  -- nobody here at all? don't leave the shop empty for long
  if #G.line == 0 and G.cust == nil and G.arriveIn > 16 then G.arriveIn = 16 end
end

-- how likely a new customer is to join, given how many people the line would hold with them in it:
-- a new cafe keeps short lines, and only a well-liked one gets a long queue
function CAFE.admit(n)
  local st = G.cafe.stars or 0
  local t
  if st < 2 then t = { 1, 0.5, 0.1, 0 }
  elseif st < 3 then t = { 1, 0.9, 0.3, 0 }
  elseif st < 4 then t = { 1, 1, 0.7, 0.2 }
  else t = { 1, 1, 1, 0.6 } end
  return math.random() < (t[n] or 0)
end

function CAFE.gap(lo, span)
  local f = G.flow
  local factor = 1.55 - 1.0 * f.m                      -- quiet spell 1.55x, rush 0.55x
  if math.random() < 0.14 then return 2.5 + math.random() * 3 end   -- a friend tags along
  return (lo + math.random() * span) * factor
end

-- ---- stars ---------------------------------------------------------------------------------------
function CAFE.star(cx, cy, r, fill, color)
  local pts = {}
  for i = 0, 9 do
    local a = -math.pi / 2 + i * math.pi / 5
    local rr = (i % 2 == 0) and r or r * 0.45
    pts[#pts + 1] = math.floor(cx + math.cos(a) * rr + 0.5)
    pts[#pts + 1] = math.floor(cy + math.sin(a) * rr + 0.5)
  end
  gfx.setColor(color)
  if fill >= 0.75 then
    gfx.fillPolygon(table.unpack(pts))
  else
    gfx.drawPolygon(table.unpack(pts))
    if fill >= 0.25 then
      gfx.setClipRect(cx - r - 1, cy - r - 1, r + 1, r * 2 + 2)     -- the left half
      gfx.fillPolygon(table.unpack(pts))
      gfx.clearClipRect()
    end
  end
end

function CAFE.drawStars(x0, cy, r, gap, value, color)
  for i = 1, 5 do
    CAFE.star(x0 + (i - 1) * gap, cy, r, clamp(value - (i - 1), 0, 1), color)
  end
  gfx.setColor(BLACK)
end

-- text squeezed to fit a box (scaled down if it's too wide)
CAFE.fitCache = {}
function CAFE.fitText(str, cx, cy, maxW, maxH)
  gfx.setFont(fontBold)
  local w, h = gfx.getTextSize(str)
  if w <= maxW then
    drawTC(str, cx, cy - h // 2, true)
    return
  end
  local img = CAFE.fitCache[str]
  if img == nil then
    local ok = pcall(function()
      img = gfx.image.new(w, h)
      gfx.pushContext(img)
      gfx.setColor(BLACK)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      drawT(str, 0, 0, true)
      gfx.popContext()
    end)
    if not ok then img = false end
    CAFE.fitCache[str] = img
  end
  if img then
    local k = maxW / w
    local ok = pcall(function() img:drawScaled(cx - math.floor(w * k / 2), cy - math.floor(h * k / 2), k) end)
    if ok then gfx.setImageDrawMode(gfx.kDrawModeCopy); return end
  end
  drawTC(string.sub(str, 1, 7) .. "..", cx, cy - h // 2, true)
end

-- ---- decoration art: every piece is drawn around a centre point ----------------------------------
CAFE.art = {}
local function A() return CAFE.art end

function CAFE.art.clock(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 11)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 11)
  gfx.setLineWidth(1)
  for h = 0, 11 do
    local a = h * math.pi / 6
    gfx.drawLine(math.floor(cx + math.sin(a) * 8), math.floor(cy - math.cos(a) * 8),
                 math.floor(cx + math.sin(a) * 9.5), math.floor(cy - math.cos(a) * 9.5))
  end
  local t = (G and G.t) or 0
  local am = t * 0.105
  local ah = am / 12 + 1
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 8), math.floor(cy - math.cos(am) * 8))
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 5), math.floor(cy - math.cos(ah) * 5))
  gfx.setLineWidth(1)
end

function CAFE.art.cuckoo(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 11, cy - 3, cx, cy - 14, cx + 11, cy - 3)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 9, cy - 3, 18, 14)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 9, cy - 3, 18, 14)
  local t = (G and G.t) or 0
  if t % 30 < 2 then                                  -- the little bird pops out
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy + 2, 2)
    gfx.fillTriangle(cx + 2, cy + 1, cx + 6, cy + 2, cx + 2, cy + 3)
  else
    gfx.fillRect(cx - 3, cy - 1, 6, 6)
  end
  local sw = math.floor(math.sin(frames * 0.08) * 4)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)
  gfx.fillCircleAtPoint(cx + sw, cy + 17, 2)
end

function CAFE.art.calendar(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 10, cy - 12, 20, 24)
  gfx.setColor(BLACK)
  gfx.drawRect(cx - 10, cy - 12, 20, 24)
  gfx.fillRect(cx - 10, cy - 12, 20, 6)
  gfx.fillRect(cx - 6, cy - 14, 2, 4)
  gfx.fillRect(cx + 4, cy - 14, 2, 4)
  for r = 0, 2 do
    for c = 0, 3 do
      gfx.fillRect(cx - 8 + c * 4, cy - 3 + r * 5, 2, 2)
    end
  end
  gfx.drawRect(cx + 2, cy + 6, 5, 4)
end

local function pot(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 9, cy + 5, cx + 9, cy + 5, cx + 6, cy + 14, cx - 6, cy + 14)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 7, cy + 7, 14, 2)
  gfx.setColor(BLACK)
end

function CAFE.art.plant(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx, cy + 5, cx - 9 + sw, cy - 9, cx - 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + 9 + sw, cy - 10, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx + sw, cy - 15, cx + 3, cy + 5)
  gfx.fillTriangle(cx, cy + 5, cx - 13 + sw, cy - 2, cx - 4, cy + 6)
  gfx.fillTriangle(cx, cy + 5, cx + 13 + sw, cy - 3, cx + 4, cy + 6)
  pot(cx, cy)
end

function CAFE.art.cactus(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 4, cy - 14, 8, 22, 3)
  gfx.fillRoundRect(cx - 11, cy - 7, 6, 3, 1)
  gfx.fillRoundRect(cx - 11, cy - 11, 3, 7, 1)
  gfx.fillRoundRect(cx + 5, cy - 3, 6, 3, 1)
  gfx.fillRoundRect(cx + 8, cy - 8, 3, 8, 1)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 1, cy - 10)
  gfx.drawPixel(cx + 1, cy - 4)
  gfx.drawPixel(cx - 1, cy + 1)
  pot(cx, cy)
end

function CAFE.art.fern(cx, cy)
  local sw = math.floor(math.sin(frames * 0.06) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  for k = -2, 2 do
    gfx.drawLine(cx, cy + 5, cx + k * 5, cy - 5)
    gfx.drawLine(cx + k * 5, cy - 5, cx + k * 8 + sw, cy - 11)
  end
  gfx.setLineWidth(1)
  pot(cx, cy)
end

function CAFE.art.flowers(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 2, cy + 5, cx + k * 7, cy - 7)
  end
  for k = -1, 1 do
    local fx, fy = cx + k * 7, cy - 9 - (k == 0 and 3 or 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(fx, fy, 4)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(fx, fy, 4)
    gfx.fillCircleAtPoint(fx, fy, 1)
  end
  pot(cx, cy)
end

function CAFE.art.tree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy + 9, 4, 6)
  gfx.fillTriangle(cx, cy - 15, cx - 8, cy - 3, cx + 8, cy - 3)
  gfx.fillTriangle(cx, cy - 8, cx - 11, cy + 4, cx + 11, cy + 4)
  gfx.fillTriangle(cx, cy - 2, cx - 13, cy + 10, cx + 13, cy + 10)
  local spots = { { -3, -8 }, { 3, -1 }, { -7, 2 }, { 6, 6 }, { -3, 7 } }
  for i, sp in ipairs(spots) do
    if (i + frames // 20) % 2 == 0 then
      gfx.setColor(WHITE)
      gfx.fillCircleAtPoint(cx + sp[1], cy + sp[2], 2)
    end
  end
  gfx.setColor(WHITE)
  gfx.fillTriangle(cx, cy - 19, cx - 2, cy - 15, cx + 2, cy - 15)
  gfx.setColor(BLACK)
end

function CAFE.art.pumpkin(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 11, cy - 3, 22, 16)
  gfx.setLineWidth(1)
  gfx.drawLine(cx, cy - 3, cx, cy + 13)
  gfx.fillRect(cx - 1, cy - 7, 3, 5)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 2, cy + 5, cx - 4, cy + 1)
  gfx.fillTriangle(cx + 2, cy + 5, cx + 6, cy + 5, cx + 4, cy + 1)
  gfx.fillRect(cx - 4, cy + 8, 8, 2)
end

-- ---- tiny wall art (about 20 x 16, hung on the open wall above the counter) -------------------------
local function tinyFrame(cx, cy, w, h)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - w // 2, cy - h // 2, w, h)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawRect(cx - w // 2, cy - h // 2, w, h)
  gfx.setLineWidth(1)
end
function CAFE.art.t1(cx, cy)                      -- landscape: mountains and a sun
  tinyFrame(cx, cy, 22, 16)
  gfx.fillTriangle(cx - 8, cy + 5, cx - 3, cy - 3, cx + 2, cy + 5)
  gfx.fillTriangle(cx - 1, cy + 5, cx + 4, cy - 1, cx + 9, cy + 5)
  gfx.drawCircleAtPoint(cx + 5, cy - 4, 2)
end
function CAFE.art.t2(cx, cy)                      -- heart
  tinyFrame(cx, cy, 18, 18)
  gfx.fillCircleAtPoint(cx - 3, cy - 2, 3)
  gfx.fillCircleAtPoint(cx + 3, cy - 2, 3)
  gfx.fillTriangle(cx - 6, cy - 1, cx + 6, cy - 1, cx, cy + 6)
end
function CAFE.art.t3(cx, cy)                      -- sunburst
  tinyFrame(cx, cy, 20, 16)
  gfx.setColor(BLACK)
  for a = 0, 315, 45 do
    local r = math.rad(a)
    gfx.drawLine(cx + math.floor(3 * math.cos(r) + 0.5), cy + math.floor(3 * math.sin(r) + 0.5),
                 cx + math.floor(6 * math.cos(r) + 0.5), cy + math.floor(6 * math.sin(r) + 0.5))
  end
  gfx.fillCircleAtPoint(cx, cy, 2)
end
function CAFE.art.t4(cx, cy)                      -- a mug print
  tinyFrame(cx, cy, 20, 18)
  gfx.fillRect(cx - 5, cy - 3, 9, 8)
  gfx.drawCircleAtPoint(cx + 5, cy + 1, 2)
  gfx.drawLine(cx - 3, cy - 6, cx - 3, cy - 4)
  gfx.drawLine(cx + 1, cy - 6, cx + 1, cy - 4)
end
function CAFE.art.t5(cx, cy)                      -- round cat portrait
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, cy, 9)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawCircleAtPoint(cx, cy, 9); gfx.setLineWidth(1)
  gfx.fillTriangle(cx - 6, cy - 1, cx - 5, cy - 7, cx - 2, cy - 3)
  gfx.fillTriangle(cx + 6, cy - 1, cx + 5, cy - 7, cx + 2, cy - 3)
  gfx.fillCircleAtPoint(cx, cy + 1, 6)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx - 2, cy, 1); gfx.fillCircleAtPoint(cx + 2, cy, 1)
  gfx.setColor(BLACK)
end
function CAFE.art.t6(cx, cy)                      -- oval mirror with a shine
  gfx.setColor(WHITE); gfx.fillEllipseInRect(cx - 7, cy - 9, 14, 18)
  gfx.setColor(BLACK); gfx.setLineWidth(2); gfx.drawEllipseInRect(cx - 7, cy - 9, 14, 18); gfx.setLineWidth(1)
  gfx.drawLine(cx - 3, cy - 4, cx - 1, cy - 6)
  gfx.drawLine(cx - 4, cy, cx + 1, cy - 7)
end
function CAFE.art.t7(cx, cy)                      -- bunting: a string of little flags
  tinyFrame(cx, cy, 34, 16)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 14, cy - 5, cx, cy - 2); gfx.drawLine(cx, cy - 2, cx + 14, cy - 5)
  for i = -2, 2 do
    local x = cx + i * 6
    local y = cy - 5 + (2 - math.abs(i)) * 1 + math.floor(math.abs(2 - math.abs(i)) * 0.5)
    y = cy - 5 + math.floor((2 - math.abs(i)) * 1.5 + 0.5)
    if i % 2 == 0 then gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
    else
      gfx.setColor(WHITE); gfx.fillTriangle(x - 3, y, x + 3, y, x, y + 6)
      gfx.setColor(BLACK); gfx.drawLine(x - 3, y, x, y + 6); gfx.drawLine(x + 3, y, x, y + 6)
    end
  end
end
function CAFE.art.t8(cx, cy)                      -- paper plane
  tinyFrame(cx, cy, 22, 16)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 7, cy - 1, cx + 7, cy - 5, cx, cy + 4)
  gfx.setColor(WHITE); gfx.drawLine(cx - 7, cy - 1, cx + 2, cy - 1); gfx.drawLine(cx + 2, cy - 1, cx, cy + 4)
  gfx.setColor(BLACK)
end
function CAFE.art.t9(cx, cy)                      -- music notes
  tinyFrame(cx, cy, 18, 18)
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(cx - 3, cy + 4, 2); gfx.fillCircleAtPoint(cx + 3, cy + 3, 2)
  gfx.drawLine(cx - 1, cy + 4, cx - 1, cy - 4); gfx.drawLine(cx + 5, cy + 3, cx + 5, cy - 5)
  gfx.setLineWidth(2); gfx.drawLine(cx - 1, cy - 4, cx + 5, cy - 5); gfx.setLineWidth(1)
end
function CAFE.art.t10(cx, cy)                     -- moon and stars
  gfx.setColor(BLACK); gfx.fillRoundRect(cx - 12, cy - 9, 24, 18, 4)
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx - 3, cy, 6)
  gfx.setColor(BLACK); gfx.fillCircleAtPoint(cx - 1, cy - 1, 5)
  gfx.setColor(WHITE)
  gfx.drawPixel(cx + 5, cy - 4); gfx.drawPixel(cx + 8, cy + 3); gfx.drawPixel(cx + 4, cy + 5)
  gfx.drawLine(cx + 6, cy - 6, cx + 6, cy - 2)
  gfx.setColor(BLACK)
end
function CAFE.art.t12(cx, cy)                     -- sailboat
  tinyFrame(cx, cy, 22, 18)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 1, cy - 6, cx - 1, cy + 2, cx - 6, cy + 2)
  gfx.drawLine(cx + 1, cy - 4, cx + 1, cy + 2); gfx.drawLine(cx + 1, cy - 4, cx + 6, cy + 2); gfx.drawLine(cx + 1, cy + 2, cx + 6, cy + 2)
  gfx.fillPolygon(cx - 7, cy + 4, cx + 7, cy + 4, cx + 5, cy + 7, cx - 5, cy + 7)
end

function CAFE.art.table(cx, cy)
  for k = -1, 1, 2 do
    gfx.setColor(WHITE)
    gfx.fillRoundRect(cx + k * 17 - 6, cy - 9, 12, 18, 3)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(cx + k * 17 - 6, cy - 9, 12, 18, 3)
  end
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(cx, cy, 13)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(cx, cy, 13)
  gfx.setLineWidth(1)
end

local function smallPot(cx, cy)                -- a little pot for the counter
  gfx.setColor(BLACK)
  gfx.fillPolygon(cx - 6, cy + 4, cx + 6, cy + 4, cx + 4, cy + 10, cx - 4, cy + 10)
  gfx.setColor(WHITE)
  gfx.fillRect(cx - 5, cy + 5, 10, 1)
  gfx.setColor(BLACK)
end

local function bloom(x, y, r)                  -- a flower head
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.fillCircleAtPoint(x, y, math.max(1, r - 2))
end

function CAFE.art.tulips(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do
    gfx.drawLine(cx + k * 3, cy + 4, cx + k * 4, cy - 4)
    gfx.fillTriangle(cx + k * 4 - 3, cy - 2, cx + k * 4 + 3, cy - 2, cx + k * 4, cy - 9)
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx, cy - 4)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.succ(cx, cy)
  gfx.setColor(BLACK)
  for k = -2, 2 do
    gfx.fillTriangle(cx, cy + 4, cx + k * 3 - 2, cy - 5 + math.abs(k), cx + k * 3 + 2, cy - 5 + math.abs(k))
  end
  gfx.setColor(WHITE)
  gfx.drawLine(cx, cy + 2, cx, cy - 3)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.daisies(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillRoundRect(cx - 4, cy + 1, 8, 9, 2)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(cx - 4, cy + 1, 8, 9, 2)
  for k = -1, 1 do
    gfx.drawLine(cx + k, cy + 1, cx + k * 5, cy - 6)
    bloom(cx + k * 5, cy - 7 - (k == 0 and 2 or 0), 3)
  end
end

function CAFE.art.minicac(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(cx - 2, cy - 7, 5, 12, 2)
  gfx.fillRoundRect(cx - 6, cy - 3, 3, 2, 1)
  gfx.fillRoundRect(cx - 6, cy - 6, 2, 5, 1)
  gfx.fillRoundRect(cx + 3, cy - 1, 3, 2, 1)
  gfx.fillRoundRect(cx + 5, cy - 4, 2, 5, 1)
  smallPot(cx, cy)
end

function CAFE.art.herbs(cx, cy)
  gfx.setColor(BLACK)
  for k = -1, 1 do gfx.fillCircleAtPoint(cx + k * 4, cy - 1 - (k == 0 and 3 or 0), 3) end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 4, cy - 1)
  gfx.drawPixel(cx, cy - 4)
  gfx.drawPixel(cx + 4, cy - 1)
  gfx.setColor(BLACK)
  smallPot(cx, cy)
end

function CAFE.art.palm(cx, cy)
  local sw = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 5, cx + 1, cy - 8)
  gfx.setLineWidth(1)
  for k = -3, 3 do
    gfx.drawLine(cx + 1, cy - 8, cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2)
    gfx.drawLine(cx + 1 + k * 4 + sw, cy - 14 + math.abs(k) * 2, cx + 1 + k * 5 + sw, cy - 11 + math.abs(k) * 3)
  end
  pot(cx, cy)
end

function CAFE.art.snake(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillTriangle(cx - 6, cy + 5, cx - 3, cy + 5, cx - 5, cy - 12)
  gfx.fillTriangle(cx - 3, cy + 5, cx + 1, cy + 5, cx - 1, cy - 15)
  gfx.fillTriangle(cx + 1, cy + 5, cx + 4, cy + 5, cx + 3, cy - 10)
  gfx.fillTriangle(cx + 3, cy + 5, cx + 7, cy + 5, cx + 7, cy - 6)
  gfx.setColor(WHITE)
  gfx.drawLine(cx - 1, cy + 3, cx - 1, cy - 10)
  gfx.setColor(BLACK)
  pot(cx, cy)
end

function CAFE.art.sunflower(cx, cy)
  gfx.setColor(BLACK)
  gfx.drawLine(cx - 3, cy + 5, cx - 5, cy - 6)
  gfx.drawLine(cx + 3, cy + 5, cx + 6, cy - 3)
  gfx.fillTriangle(cx - 3, cy + 1, cx - 9, cy - 2, cx - 3, cy - 2)
  for _, f in ipairs({ { -5, -9, 5 }, { 6, -6, 4 } }) do
    for a = 0, 7 do
      local an = a * math.pi / 4
      gfx.fillCircleAtPoint(cx + f[1] + math.floor(math.cos(an) * (f[3] + 1)), cy + f[2] + math.floor(math.sin(an) * (f[3] + 1)), 1)
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 1)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx + f[1], cy + f[2], f[3] - 2)
  end
  pot(cx, cy)
end

function CAFE.art.bonsai(cx, cy)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy + 6, cx - 2, cy + 1)
  gfx.drawLine(cx - 2, cy + 1, cx + 2, cy - 5)
  gfx.drawLine(cx + 2, cy - 5, cx - 1, cy - 9)
  gfx.setLineWidth(1)
  for _, c in ipairs({ { -7, -6, 5 }, { 0, -12, 6 }, { 8, -7, 5 }, { -2, -7, 4 } }) do
    gfx.fillCircleAtPoint(cx + c[1], cy + c[2], c[3])
  end
  gfx.setColor(WHITE)
  gfx.drawPixel(cx - 7, cy - 6); gfx.drawPixel(cx + 1, cy - 12); gfx.drawPixel(cx + 8, cy - 7)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 9, cy + 6, 18, 2)
  gfx.fillRect(cx - 8, cy + 8, 3, 6)
  gfx.fillRect(cx + 5, cy + 8, 3, 6)
  gfx.fillRect(cx - 10, cy + 6, 20, 1)
end

function CAFE.art.monstera(cx, cy)
  gfx.setColor(BLACK)
  local leaves = { { -8, -4, 7, 5 }, { 1, -12, 8, 6 }, { 8, -3, 7, 5 }, { -2, -3, 6, 5 } }
  for _, l in ipairs(leaves) do
    gfx.fillEllipseInRect(cx + l[1] - l[3], cy + l[2] - l[4], l[3] * 2, l[4] * 2)
    gfx.setColor(WHITE)
    gfx.drawLine(cx + l[1] - 2, cy + l[2], cx + l[1] + 2, cy + l[2])         -- the leaf's splits
    gfx.drawPixel(cx + l[1], cy + l[2] - 2)
    gfx.setColor(BLACK)
  end
  gfx.drawLine(cx, cy + 5, cx - 6, cy - 2)
  gfx.drawLine(cx, cy + 5, cx + 7, cy - 2)
  pot(cx, cy)
end

function CAFE.art.cattree(cx, cy)
  gfx.setColor(BLACK)
  gfx.fillRect(cx - 2, cy - 13, 4, 26)
  gfx.fillRect(cx - 10, cy + 12, 20, 3)
  gfx.fillRect(cx - 10, cy - 14, 20, 3)
  gfx.fillRect(cx - 9, cy - 1, 18, 3)
  gfx.setColor(WHITE)
  for k = -8, 6, 4 do gfx.drawPixel(cx + k, cy - 13) end
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy - 1, cx + 7, cy + 5)            -- a hanging toy
  gfx.fillCircleAtPoint(cx + 7, cy + 6, 2)
end

function CAFE.art.dogbed(cx, cy)
  gfx.setColor(WHITE)
  gfx.fillEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawEllipseInRect(cx - 14, cy, 28, 15)
  gfx.setLineWidth(1)
  gfx.setPattern(CHECK)
  gfx.fillEllipseInRect(cx - 9, cy + 3, 18, 8)
  gfx.setColor(BLACK)
end

CAFE.SPR = {
  plant = { "...........kk...........", "...........kk...........", "..........kwkk..........", "....k.....kwwk....kk....", "...kwk....kwkk...kwk....", "...kwkk..kwwwkk.kwwk....", "...kwwkk.kwwkwk.kwkk....", "...kwwwk.kwwwkkkwwwk....", "...kwwkwkkwwkwkkwwkk....", "kk..kwwkkkwwwkkwwkwk.kk.", "kwkkkwwwkkwwkwkwwwkkkwk.", "kwwkkwwkwkwwwkkwwkkwwkk.", ".kwwkkwwkkwwkwkwkwkwkk..", ".kwwwkwwwkkwwkkwwkwkwk..", "..kwwwkwkkkwkkkwkkkwk...", "...kwwkwwkkwwkkkkkwk....", "....kkwkwk.kk.kwkkk.....", "......kkkk.kk.kkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  fern = { "........................", "........................", "...........kk...........", "...........kk...........", "...........kk...........", "..........kwwk..........", "..........kwkk..........", "..........kwwk..........", "...kkk....kwkk....kkk...", "....kkkk..kwwk..kkwk....", "....kwkwk.kwkk.kkwkk....", ".....kwkwkkwwkkwwkk.....", ".....kwwkkkwkkkwkwk.....", "......kwwkkwwkwkwk......", "..kkkkkkkwkwkkwwkkkkkk..", ".kwwwwwkkkkkkwkkwwwkwkk.", "kkkkwkkwkkkkkkkkkwkkkkkk", "....kkkkkkkkkkwwkkkk....", "....kkkkkkkkkkkkkkkk....", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  flowers = { "...........kkk..........", "........kkkwwwk.........", "......k.kwwkkkkk........", ".....kwkkwkkkkwwk.k.....", "..kkkwwwkkkkwkwk.kwk....", "..kwwkkkkwwkkwkkkwwwk...", "..kwkkkkkwwkwwkwwkkkkk..", "..kkkkwkwkkkkkkwkkkkwwk.", "..kwwkkwkk..k.kkkkwkwk..", "..kwwkwwk...k.kwwkkwkk..", "...kkkkkk...k.kwwkwwk...", ".......k....k..kkkkkk...", ".....kkkkk..k.kkkkk.....", ".....kwwwwk.kkwwwwk.....", ".....kwwwwk.kkwwwwk.....", "......kwwwwkkwwwwk......", "......kwwwwkkwwwwk......", ".......kkkkkkkkkk.......", ".........k..k..k........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  pumpkin = { "................kk......", "...........kkk.k........", "...........kkk..........", "..........kkkk..........", "......kkkkwwwwkkkk......", ".....kwwkwwwwwwkwkk.....", "...kkwwkwwwwwwwwkwkkk...", "..kwwwkwkwwwwwwkwkwkwk..", "..kwwwkkkkwwwwkkkkkwkk..", ".kwwwwkkkkkwwkkkkkwkwkk.", ".kwwwwkwwwwwwwwwkkkwkwk.", ".kwwwwkwwwwkkwwwwkwkwkk.", ".kwwwwkkkwwwwwwkkkkwkwk.", "..kwwwkkkkkkkkkkkkwkwk..", "..kwwwkwwkkwwkkwkkkwkk..", "...kkwwkwwwwwwwwkkwkk...", ".....kwwkwwwwwwkkwk.....", "......kkkkwwwwkkkk......", "..........kkkk.........." },
  snake = { "...........kk...........", ".......kk..kk...........", ".......kkkkwkk..........", ".......kwkkwwk.kk.......", "..kk..kwkkkwkwkwk.......", "..kkk.kwwkkwwkkwk...kk..", "..kwk.kwwkwwkwkwkk.kwk..", "..kwwkkwwkwwwkkkwk.kwk..", "..kwkkkwwkwwkwkwkkkwkk..", "..kwwkkwwkwwwkkkwkkwwk..", "...kwwkwwkwwkwkwkkwwkk..", "...kwkkkwkwwwkkkwkwkk...", "...kwwkkwwkwkwkwkkwwk...", "...kwwwkwkkwwkkkkwwkk...", "....kwkkwwkwkwkwkwkk....", "....kwwkkwkwwkkkkwwk....", ".....kkkkwkkkkkkkwk.....", ".....kwkkwkkwkwkkkk.....", "......kk.kk.kkk.kk......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  tree0 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kkkwkk.........", "........kwkkkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwwwkwk.......", "......kkwkwkwwkkwk......", ".....kkkkwwwkwkkkkk.....", ".......kwwwkwkwkk.......", ".......kkwkwkwkwk.......", "......kkkkkkwkwkwk......", ".....kkkkkkwkwwwkwk.....", "....kkwkkkwkwwwkkkwk....", "...kkkkkkwkwwwkkkkkkk...", "......kkwkwwwkwkkk......", "......kwkwkkkwkwwwk.....", "....kkwkwkwkwkwkwwwk....", "...kkkkwkwkkkwkwkwkkk...", "..kkwkkkwwwkkkwwwkkkwk..", ".kkkkkkkwkkkkkwwkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  tree1 = { "...........k............", "..........kwk...........", "........kkkwkkk.........", ".........kwwwk..........", ".........kwkwk..........", ".........kk.kk..........", "...........kk...........", "..........kkwk..........", "..........kwkk..........", ".........kwwwkk.........", "........kwwwkwkk........", ".......kwkwkkkwkk.......", ".......kkkkwkkkwk.......", "......kkwkwkkkwwwk......", ".....kkkkkkwkwwwkkk.....", ".......kwkkkwkwkk.......", ".......kkwkwkwkwk.......", "......kwwkkkwkwkwk......", ".....kkwwkkwkkkwkwk.....", "....kkwkkkwkwkkwwkwk....", "...kkkkkkwkkkwkwwkkkk...", "......kkwkwkkkwkkk......", "......kwkwkkkwkwkkk.....", "....kkwkwkwkwkwkkkwk....", "...kkwwwkwkwwwkwkwwwk...", "..kkwwwkkkwwwkkkwkwwwk..", ".kkkkkkkkkkkkkkkkkkkkkk.", "..........kkkk..........", "..........kkkk..........", "..........kkkk.........." },
  monstera = { "..........kkkk..........", "........kkwwwwkk........", ".......kwwwwwwwwkk......", ".......kwwwkwwwwwk......", "...kkkk.kwwkwwwwkk.kkkk.", ".kkwwwwkkwwkwwwkwkkwwwkk", "kwwwwkwwkwwkwwwwkwwkwwwk", "kwwwkwwwwkwkwwwkkwwwkwwk", ".kwwwwwwwwkkkwkwkwwwwwkk", "..kkwwwwwkkkkkwkkwwwwkk.", "....kkkkkwkkkkkwkkkkkk..", ".......kkkkkkkkkkk......", ".........kk.kk.kk.......", "..........kk.k.kk.......", "...........kkkk.........", "............kk..........", "............kk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  palm = { ".......kkkk......kkkk...", ".....kkwwwwkk..kkwwwwkk.", "...kkwwwwwwwkkkkwwwwwwkk", "..kwwwwkwwwwwkkwwwwkwwwk", ".kwwkkkkkkwwwkwwwkkkkkwk", "kwwk......kkwwkkk.....kk", "kk..........kkk.........", "......kkkk..kwk..kkkk...", "....kkwwwwkkkwkkkwwwwkk.", "...kwwwkwkwwkwkwwkwkwwwk", "..kwkkk.kwwwkkwwwk.kkkwk", ".kk......kkwkkwkk.....kk", "...........kkk..........", "..........kwkkk.........", "..........kwkwk.........", "...........kwk..........", "..........kwkwk.........", "..........kkkwk.........", "...........kkk..........", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  sunflower = { ".........kkkkkk.........", "......kk.kwwwwk.kk......", ".....kwwkkwwwwkkwwk.....", "..kk..kwwkkkwkkwwk..kk..", ".kwwk.kkkkkwkwkkkk.kwwk.", ".kwwwkkkwkkkwkwkkkkwwwk.", "..kwwwkkkkkkkwkwkkwwwk..", "...kkwwkkkwkwkkkwkwwkk..", ".....kkwkkkwkwkkkkwkk...", ".......kkwwkkkkwwkk.....", ".........kkkkkkkk.......", "...........kk...........", "...........kkk..........", "....kkk....kwk....kkk...", "..kkwwwkk..kkk..kkwwwkk.", ".kwwwkwwwkkkwkkkwwwkwwwk", "..kkkkkwwwkkkkkwwwkkkkk.", ".......kkkkkwkkkk.......", "...........kk...........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  cactus = { "..........kkkk..........", ".........kwwwwk.........", "........kwwwwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", "........kwwkwwwk...kkk..", "..kkk...kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwk..kwwkk.", ".kwwkk..kwwkwwkk..kwwwk.", ".kwwwk..kwwkwwwkkkkwwkk.", ".kwwkk..kwwkwwkkwwwwwwk.", ".kwwwkkkkwwkwwwkkkkkkkk.", ".kwwwwwwkwwkwwkk..kkkk..", "..kkkkkwkwwkwwwk........", ".......kkwwkwwkk........", "........kwwkwwwk........", "........kwwkwwkk........", ".........kwwwkk.........", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", "......kwwwwwwwwkwk......", ".......kwwwwwwkwk.......", ".......kwwwwwkwkk.......", ".......kkkkkkkkkk......." },
  bonsai = { "........................", ".........kkkkkkkk.......", ".......kkwwwwwwwwkk.....", "......kwwwwkwwwkwwwk....", "..kkkkwwwwkwwwkwwwwwkkk.", ".kwwwwkwwwwwwwwwwwwwwwwk", "kwwwkwwkkkkkkkkkwwwwwwwk", "kwwwwwwwkkwwkkwwwwwwwkwk", ".kkkwwwkkkwwwkkwwwwkkkk.", "....kkkk..kwwk..kkkk....", "..........kwwk..........", "..........kkwk..........", ".........kwwk...........", "........kkwkk...........", "........kwwwkk..........", ".......kkwwkkkk.........", "......kkkkkkkkkkk.......", ".....kkkkkkkkkkkkkk.....", ".....kwwwwwwwwwwwwk.....", ".....kkkkkkkkkkkkkk.....", "......kwwwwwwwwwkk......", "......kwwwwwwwwkwk......", "......kwwwwwwwkwkk......", ".......kwwwwwkwkk.......", ".......kwwwwwwkwk.......", ".......kkkkkkkkkk......." },
  daisies = { ".....kkkkk......", ".....kwkkkk.....", "....kkkkkkwk....", ".kkkkwkkkkk.k...", ".kwkkkkkkkkkwk..", ".kkkkkkwkkwkkkk.", "kwkkkkkkkkkkkkwk", ".kkkkwk.kwkkkkk.", "..kwkkk.kkkkkwk.", "...kk...k.kwkkk.", ".....k..k..kk...", ".....k..k..k....", "....kkkkkkkk....", "....kwkwkkkk....", "....kwwwwwkk....", "....kwwwwkwk....", "....kwwwwwkk....", "....kwwwwkwk....", ".....kwwwwk.....", ".....kwwwkk.....", ".....kwwwwk.....", ".....kkkkkk....." },
  tulips = { "......kk.k......", ".....kwwkkk.....", ".....kwwkwk.....", "..kk.kwwwkk.....", ".kwwkwkwkkkk.k..", ".kwwwkkkkkwwkkk.", ".kwwkwk.kkwwkwk.", "..kwwk..kkwwwkk.", "..kkkk..k.kwkk..", "..kwwkk.kkkkkk..", "...kwwk.kkwwk...", "...kkwwkkwwkk...", ".....kkkkkk.....", "......k.k.k.....", ".......kk.......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  succ = { ".......kk.......", ".......kk.......", "......kwkk......", "...kk.kwwk.kk...", "..kwkkkwkkkwkk..", "..kwwkwwwkkwwk..", ".kkwwkwwkwkwkkk.", ".kwkwkwwwkkkkwk.", ".kwkwwkwkkkwkwk.", "..kkwwkwwkwkkk..", "..kwkwkwkkkkkk..", "...kkkwkkkkkk...", ".....kkkkkk.....", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  minicac = { "................", "......kkkk......", "......kwkk......", ".....kwwkkk.....", "...kkkwwkwk.....", "...kkkwwwkk.kk..", "...kkkwwkwk.kk..", "...kwkwwkkk.kk..", "...kkkwwkwkkwk..", ".....kwwwkkkkk..", ".....kwwkwk.....", "......kwkk......", "......kkkk......", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  herbs = { "................", "................", "......kkkk......", ".....kwwwkk.....", "....kwwwkwkk....", "....kwwkwkwk....", "....kwwwkwkk....", "..kkkwkkkkwkkk..", ".kwwkkwwkwkwkwk.", ".kwwwkwwwkkkwkk.", ".kwwkkwwkkkwkwk.", ".kwwwkwwwkkwwkk.", "..kkkkkkkkkkkk..", "...kkkkkkkkkk...", "...kwwwwwwwwk...", "...kkkkkkkkkk...", "....kwwwwwwk....", "....kwwwwkwk....", "....kwwwwwkk....", ".....kkkkkk....." },
  clock = { "........................", ".......kkkkkkkkkk.......", "......kwwwwwwwwwwk......", "....kkwwkkkkkkkkwwkk....", "...kwwwkwwwwwwwwkwwwk...", "...kwkkwwwwwkwwwwkkwk...", "..kwwkwwkwwwwwwwkwkwwk..", ".kwwkwwwwwwwwwwwwwwkwwk.", ".kwkwwkwwwwwwwwwwwkwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwkwwwwwwwwwwwwwkkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwkwwwwwwwwwwwwwwwwkwk.", ".kwwkwkwwwwwwwwwwwkkwwk.", "..kwwkwwwwwwwwwwwwkwwk..", "...kwkkwkwwwwwwwkkkwk...", "...kwwwkwwwwkwwwkwwwk...", "....kkwwkkkkkkkkwwkk....", "......kwwwwwwwwwwk......", ".......kkkkkkkkkk.......", "........................" },
  cuckoo = { "...........kk...........", "..........kwwk..........", ".........kwwkwk.........", "........kkkkkkkk........", ".......kwkkkkkkwk.......", ".....kkwwkkkkkkkwk......", "....kwwwwkkkkkkwkwk.....", "...kwkwkwkkkkkkkwkwk....", "..kwwwwwwkkkkkkwkwkwk...", ".kkkkkkkkkkkkkkkkkkkkk..", "..kkkkkkkkkkkkkkkkkkk...", "..kwwwwwwwwkkwwwwwwkk...", "..kwwkwwwkkwwkkwwwkwk...", "..kwwwwwkwwwkwwkwwwkk...", "..kwwwwkwwwwwwwwkwkwk...", "..kwwwwkwwwwwwwwkwwkk...", "..kwwwkwwwwwwwwwwkkwk...", "..kwwwkwkwwwwwwwkkwkk...", "..kwwwwkwwwwwwwwkwkwk...", "..kwwwwkwwwwwwwwkwwkk...", "..kwwwwwkwwwwwwkwwkwk...", "..kwwwwwwkkwkkkwwwwkk...", "..kwwwwwwwwkkwwwwwkwk...", "..kkkkkkkkkkkkkkkkkkk...", "........................" },
  calendar = { "......k........k......", "......k........k......", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkwkwkwkwkwkwkwkwkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kkkkkkkkkkkkkkkkkkkk.", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwwwwwwwwwwwwwwwwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kwwkkwwkkwwkkwwkkwk..", ".kkkkkkkkkkkkkkkkkkk..", "......................", "......................" },
  cattree = { "........................", ".kkkkkkkkkkkkkkkkkkkkk..", ".kwkwkwkwkwkwkwkwkwkwk..", ".kkkkkkkkkkkkkkkkkkkkk..", "..........kkk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "..........kwk...........", "...kkkkkkkkkkkkkkkkk....", "...kwwwwwwwwwwwwwwwk....", "...kkkkkkkkkkkkkkkkk....", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..........kwk...........", "..........kkk...........", "..kkkkkkkkkkkkkkkkkkk...", "..kwwwwwwwwwwwwwwwwwk...", "..kkkkkkkkkkkkkkkkkkk...", "........................" },
  dogbed = { "..............................", "..............................", "..............................", ".......kkkkkkkkkkkkkkkk.......", ".....kkwwwwwwwwwwwwwwwwkk.....", "...kkwwwwkkkkkkkkkkkkwwwwkk...", "..kwwwkkkwkwkwkwkwkwkkkkwwwk..", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kwwwkkwkwkwkwkwkwkwkwkwkwwwk.", ".kwwwkwkwkwkwkwkwkwkwkwkkwwwk.", ".kkwkwkkkwkwkwkwkwkwkkkkkwkwk.", "..kkwkwkwkkkkkkkkkkkkkwkwkwk..", "...kkwkwkwkwkwkwkwkwkwkwkkk...", ".....kkkwkwkwkwkwkwkwkwkk.....", ".......kkkkkkkkkkkkkkkk.......", ".............................." },
}
CAFE.SPRPOT = { plant = 18, fern = 19, flowers = 20, snake = 20, palm = 20, monstera = 18, sunflower = 19, bonsai = 17, cactus = 18, tulips = 15, succ = 13, minicac = 13, herbs = 13, daisies = 12 }

-- ---- pixel-art sprites: drawn once from the text pictures above into images, then just stamped ------
CAFE.SPRIMG = {}
CAFE.SPR.saltlamp = {
  "......kkkk......",
  ".....kwwwwk.....",
  "....kwwwwwwk....",
  "...kwwwkwwwwk...",
  "..kwwwwkwwwwwk..",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkkwwwk.",
  ".kwwwkwwwkwkwwk.",
  ".kwwwkwwwkkwkwk.",
  ".kwwwwkwwwkwkwk.",
  ".kwwwwkwwwkkwwk.",
  "..kwwwwkwwwkwk..",
  "..kwwwwwkwwwwk..",
  "...kkwwwwwwkk...",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk.",
  "..kkkkkkkkkkkk.."
}
CAFE.SPR.lavalamp = {
  ".....kk.....",
  "....kwwk....",
  "...kwwwwk...",
  "..kkkkkkkk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  "..kwwwwwwk..",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  ".kwwwwwwwwk.",
  "..kkkkkkkk..",
  "...kkkkkk...",
  "..kkkkkkkk..",
  ".kkkkkkkkkk.",
  "kkkkkkkkkkkk",
  "kkkkkkkkkkkk"
}
CAFE.SPR.neoncup = {
  ".kkkkkkkkkkkkkkkkkk.",
  "kkkkkkkkkkkkkkkkkkkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkkkkkkkkkkkkkwkk",
  "kkwkkwwwwwwwwwwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwkkwkk",
  "kkwkkwkkkkkkkkwwwwkk",
  "kkwkkkwwwwwwwwkkkwkk",
  "kkwkwwwwwwwwwwwwkwkk",
  "kkwwwwwwwwwwwwwwwwkk",
  "kkkkkkkkkkkkkkkkkkkk",
  ".kkkkkkkkkkkkkkkkkk."
}

CAFE.SPR.floorlamp = {
  ".....kkkkkk.....",
  "....kwwwwwwk....",
  "...kwwkwwkwwk...",
  "..kwwwkwwkwwwk..",
  ".kwwwwkwwkwwwwk.",
  ".kwwwwkwwkwwwwk.",
  "kkkkkkkkkkkkkkkk",
  "..kkkkkkkkkkkk..",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  ".......kk.......",
  "......kkkk......",
  "....kkkkkkkk....",
  "..kkkkkkkkkkkk..",
  ".kkkkkkkkkkkkkk.",
  ".kkwkkkkkkkkwkk."
}

CAFE.SPR.cp5 = {
  "......kk......",
  "......kk......",
  "...kkkkkkkk...",
  ".kkwwwkkwwwkk.",
  "kwwwwwkkwwwwwk",
  "kwwkkwwwwkkwwk",
  "kwwkkwwwwkkwwk",
  "kwwwwwwwwwwwwk",
  "kwwwkwkwkwkwwk",
  "kwwwwkwkwkwwwk",
  ".kwwwwkkwwwwk.",
  "..kkkkkkkkkk.."
}
CAFE.SPR.cp6 = {
  "......k......",
  ".....kkk.....",
  "...kkkkkkk...",
  "....kkkkk....",
  "....kk.kk....",
  "......k......",
  ".....kkk.....",
  "....kkwkk....",
  ".....kkk.....",
  "....kwkkk....",
  "...kkkkkwk...",
  "....kkkkk....",
  "...kwkkkkk...",
  "..kkkkkwkkk..",
  "...kkkkkkk...",
  "..kkkkwkkwk..",
  ".kkwkkkkkkkk.",
  ".....kkk.....",
  ".....kkk....."
}

function CAFE.spr(key, part)
  local ck = part and (key .. part) or key
  local im = CAFE.SPRIMG[ck]
  if im == nil then
    local rows = CAFE.SPR[key]
    local w, h = #rows[1], #rows
    local y0, y1 = 1, h
    if part and CAFE.SPRPOT[key] then
      if part == "top" then y1 = CAFE.SPRPOT[key] else y0 = CAFE.SPRPOT[key] + 1 end
    end
    im = gfx.image.new(w, y1 - y0 + 1, gfx.kColorClear)
    gfx.pushContext(im)
    for y = y0, y1 do
      local r = rows[y]
      for x = 1, w do
        local c = string.sub(r, x, x)
        if c == "k" then gfx.setColor(BLACK); gfx.drawPixel(x - 1, y - y0)
        elseif c == "w" then gfx.setColor(WHITE); gfx.drawPixel(x - 1, y - y0) end
      end
    end
    gfx.popContext()
    CAFE.SPRIMG[ck] = im
  end
  return im
end

function CAFE.stamp(key, cx, bottom, dx)         -- centred on cx, standing on y = bottom
  local im = CAFE.spr(key)
  local w, h = im:getSize()
  im:draw(cx - w // 2 + (dx or 0), bottom - h + 1)
end

function CAFE.stampSway(key, cx, bottom, sw)     -- the leaves sway, the pot stays put
  local top, bot = CAFE.spr(key, "top"), CAFE.spr(key, "bot")
  local w, h = top:getSize()
  local _, h2 = bot:getSize()
  top:draw(cx - w // 2 + sw, bottom - h2 - h + 1)
  bot:draw(cx - w // 2, bottom - h2 + 1)
end

function CAFE.swayOf(speed, cx) return math.floor(math.sin(frames * speed + cx * 0.13) * 1.5 + 0.5) end
CAFE.FL = { plant = true, cactus = true, fern = true, flowers = true, palm = true, snake = true,
            sunflower = true, bonsai = true, monstera = true }
function CAFE.defFloor()
  for id in pairs(CAFE.FL) do
    CAFE.art[id] = function(cx, cy)
      CAFE.stampSway(id, cx, cy + 14, CAFE.swayOf(id == "fern" and 0.06 or 0.05, cx))
    end
  end
end
CAFE.defFloor()
function CAFE.art.tree(cx, cy)
  CAFE.stamp("tree" .. ((frames // 20) % 2), cx, cy + 15)
  gfx.setColor(BLACK)                                   -- the star twinkles
  if (frames // 10) % 2 == 0 then
    gfx.drawPixel(cx - 5, cy - 12); gfx.drawPixel(cx + 5, cy - 12); gfx.drawPixel(cx, cy - 17)
  else
    gfx.drawPixel(cx - 6, cy - 13); gfx.drawPixel(cx + 6, cy - 13); gfx.drawPixel(cx - 5, cy - 10); gfx.drawPixel(cx + 5, cy - 10)
  end
end
function CAFE.art.pumpkin(cx, cy)
  CAFE.stamp("pumpkin", cx, cy + 13)
  if (frames + cx) % 90 < 6 then                        -- it blinks
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 6, cy + 2, 5, 3); gfx.fillRect(cx + 1, cy + 2, 5, 3)
    gfx.setColor(BLACK)
    gfx.drawLine(cx - 6, cy + 3, cx - 2, cy + 3); gfx.drawLine(cx + 1, cy + 3, cx + 5, cy + 3)
  end
end
function CAFE.art.cattree(cx, cy)
  CAFE.stamp("cattree", cx, cy + 15)
  local sw = math.floor(math.sin(frames * 0.1) * 2 + 0.5)       -- the toy swings
  gfx.setColor(BLACK)
  gfx.drawLine(cx + 7, cy + 3, cx + 7 + sw, cy + 9)
  gfx.fillCircleAtPoint(cx + 7 + sw, cy + 10, 2)
end
function CAFE.art.dogbed(cx, cy)
  CAFE.stamp("dogbed", cx, cy + 15)
  gfx.setColor(BLACK)                                    -- little sleepy z's drift up
  for k = 0, 1 do
    local ph = (frames // 6 + k * 4) % 8
    local x, y = cx + 6 + k * 4, cy - 1 - ph
    if ph < 7 then
      gfx.drawLine(x, y, x + 2, y); gfx.drawPixel(x + 1, y + 1); gfx.drawLine(x, y + 2, x + 2, y + 2)
    end
  end
end
function CAFE.defCounter()
  for _, id in ipairs({ "tulips", "succ", "daisies", "minicac", "herbs" }) do
    CAFE.art[id] = function(cx, cy) CAFE.stampSway(id, cx, cy + 10, CAFE.swayOf(0.07, cx)) end
  end
end
CAFE.defCounter()
function CAFE.art.calendar(cx, cy)
  CAFE.stamp("calendar", cx, cy + 13)
  if (frames // 15) % 2 == 1 then                         -- a page corner flutters
    gfx.setColor(WHITE); gfx.fillRect(cx + 8, cy + 10, 3, 3)
    gfx.setColor(BLACK); gfx.drawLine(cx + 8, cy + 10, cx + 10, cy + 12)
  end
end

function CAFE.art.clock(cx, cy)
  CAFE.stamp("clock", cx, cy + 12)
  gfx.setColor(BLACK)
  local t = frames / 30                                  -- (always alive, here and in the shop preview)
  local am = t * 0.3                                     -- the minute hand sweeps round
  local ah = am / 12 + 1
  local sa = math.floor(t * 2) * (math.pi / 6)           -- the second hand ticks: a jump every half second
  gfx.setLineWidth(2)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(am) * 6), math.floor(cy - math.cos(am) * 6))
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(ah) * 4), math.floor(cy - math.cos(ah) * 4))
  gfx.setLineWidth(1)
  gfx.drawLine(cx, cy, math.floor(cx + math.sin(sa) * 8), math.floor(cy - math.cos(sa) * 8))
  gfx.fillCircleAtPoint(cx, cy, 2)
  if math.floor(t * 2) % 2 == 0 then gfx.fillRect(cx - 1, cy + 5, 2, 2) end   -- a tick-tock dot under the middle
end

function CAFE.art.saltlamp(cx, cy)             -- a glowing crystal on a dark base, its glow rays breathe
  CAFE.stamp("saltlamp", cx, cy + 10)
  gfx.setColor(BLACK)
  local big = (frames // 12) % 2 == 0
  local r = big and 3 or 1
  gfx.drawLine(cx - 10, cy - 3, cx - 12 - r, cy - 5 - r // 2)
  gfx.drawLine(cx + 10, cy - 3, cx + 12 + r, cy - 5 - r // 2)
  gfx.drawLine(cx - 7, cy - 9, cx - 8 - r, cy - 11 - r)
  gfx.drawLine(cx + 7, cy - 9, cx + 8 + r, cy - 11 - r)
  if big then gfx.drawPixel(cx, cy - 11); gfx.drawPixel(cx, cy - 13) else gfx.drawPixel(cx, cy - 12) end
end

function CAFE.art.lavalamp(cx, cy)             -- blobs of wax drift up and down inside the glass
  CAFE.stamp("lavalamp", cx, cy + 11)
  gfx.setColor(BLACK)
  gfx.setClipRect(cx - 4, cy - 7, 8, 13)
  local a = frames * 0.045
  gfx.fillCircleAtPoint(cx - 1 + math.floor(math.sin(a * 1.3) * 1.5), cy + 3 - math.floor((math.sin(a) + 1) * 4.5), 3)
  gfx.fillCircleAtPoint(cx + 1, cy + 3 - math.floor((math.sin(a * 0.7 + 2.2) + 1) * 4.5), 2)
  gfx.fillRect(cx - 4, cy + 4, 8, 2)                                    -- the pool at the bottom
  gfx.clearClipRect()
end

function CAFE.art.floorlamp(cx, cy)            -- a pleated shade on a slim pole: its light flickers on and off
  CAFE.stamp("floorlamp", cx, cy + 14)
  local lit = (frames // 24) % 9 ~= 8                                   -- (an occasional flicker)
  if lit then
    gfx.setColor(BLACK)
    local r = ((frames // 10) % 2 == 0) and 3 or 1
    gfx.drawLine(cx - 9, cy - 6 + 1, cx - 12 - r, cy - 3 + r)
    gfx.drawLine(cx + 8, cy - 6 + 1, cx + 11 + r, cy - 3 + r)
    gfx.drawLine(cx - 4, cy - 5, cx - 5, cy - 2 + r)
    gfx.drawLine(cx + 3, cy - 5, cx + 4, cy - 2 + r)
  end
  gfx.setColor(BLACK)
end

function CAFE.art.neoncup(cx, cy)              -- a glowing cup sign on a dark plate, with blinking steam
  CAFE.stamp("neoncup", cx, cy + 12)
  gfx.setColor(WHITE)
  local ph = (frames // 12) % 2
  for i = 0, 1 do
    if (i + ph) % 2 == 0 then
      local x = cx - 3 + i * 5
      gfx.drawLine(x, cy - 1, x + 1, cy - 3); gfx.drawLine(x + 1, cy - 3, x, cy - 5); gfx.drawLine(x, cy - 5, x + 1, cy - 7)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.art.cuckoo(cx, cy)
  CAFE.cuckooBody(cx, cy)
  CAFE.cuckooDangle(cx, cy)
end

function CAFE.drawDangles()                    -- the cuckoo's pendulum and weights, drawn last so they hang in front
  local d = CAFE.dec()
  if not d or d.decor.cuckoo ~= "on" or not d.place.cuckoo then return end
  local cx, cy = CAFE.tileCenter(d.place.cuckoo)
  CAFE.cuckooDangle(cx, cy)
  gfx.setColor(BLACK)
end

function CAFE.cuckooBody(cx, cy)
  CAFE.stamp("cuckoo", cx, cy + 10)
  gfx.setColor(BLACK)
  local t = (G and G.t) or 0
  local am = t * 0.105
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am) * 4), math.floor(cy + 3 - math.cos(am) * 4))
  gfx.drawLine(cx, cy + 3, math.floor(cx + math.sin(am / 12 + 1) * 2), math.floor(cy + 3 - math.cos(am / 12 + 1) * 2))
  if t % 30 < 2 then                                  -- the little bird pops out of the door
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 2, cy - 10, 5, 5)
    gfx.setColor(BLACK)
    gfx.fillCircleAtPoint(cx, cy - 8, 2)
    gfx.fillTriangle(cx + 2, cy - 9, cx + 5, cy - 8, cx + 2, cy - 7)
  end
end

function CAFE.cuckooDangle(cx, cy)
  gfx.setColor(BLACK)
  local sw = math.floor(math.sin(frames * 0.08) * 3)
  local s2 = math.floor(math.sin(frames * 0.05) * 1.5 + 0.5)
  gfx.setColor(BLACK)
  gfx.drawLine(cx, cy + 11, cx + sw, cy + 17)                      -- pendulum
  gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx + sw, cy + 19, 3)
  gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx + sw, cy + 19, 3)
  gfx.drawLine(cx - 8, cy + 11, cx - 8 + s2, cy + 18)             -- chains with pine-cone weights
  gfx.drawLine(cx + 8, cy + 11, cx + 8 - s2, cy + 16)
  gfx.fillTriangle(cx - 11 + s2, cy + 18, cx - 5 + s2, cy + 18, cx - 8 + s2, cy + 25)
  gfx.fillTriangle(cx + 5 - s2, cy + 16, cx + 11 - s2, cy + 16, cx + 8 - s2, cy + 23)
end

-- draw something that stays the same for the whole shift into a picture once, then just stamp it
-- (only the strip of the screen that holds the thing, y0 .. y0+h, is kept, so stamping it is cheap)
function CAFE.cached(key, drawfn, y0, h)
  local c = G[key]
  if c == nil then
    G[key] = false
    local ok, img = pcall(function() return gfx.image.new(400, h, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      gfx.setDrawOffset(0, -y0)
      drawfn()
      gfx.setDrawOffset(0, 0)
      gfx.popContext()
      G[key] = img
    end
    c = G[key]
  end
  if c then c:draw(0, y0) else drawfn() end
end

function CAFE.wallItemsRaw(live)               -- live = the moving ones (clocks), otherwise the still ones
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if (it.kind == "wall" or it.kind == "tiny") and d.decor[it.id] == "on" and d.place[it.id] and CAFE.TILES[d.place[it.id]]
       and ((it.id == "clock" or it.id == "cuckoo" or it.id == "neoncup") == live) then
      local cx, cy = CAFE.tileCenter(d.place[it.id])
      local fn = (it.id == "cuckoo") and CAFE.cuckooBody or CAFE.art[it.id]     -- (the cuckoo's dangly bits come later)
      fn(cx, cy)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawWallItems()
  CAFE.cached("wallImg", function() CAFE.wallItemsRaw(false) end, 14, 64)
  CAFE.wallItemsRaw(true)
end

function CAFE.drawTinyItems() end                -- (the little pictures are drawn with the rest of the wall decor now)

function CAFE.tinyRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "tiny" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.XSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawCounterItems()
  if not CAFE.dec() then return end
  CAFE.counterRaw()
end

function CAFE.counterRaw()
  local d = CAFE.dec()
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "counter" and d.decor[it.id] == "on" and d.place[it.id] then
      local sl = CAFE.CSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

-- leafy vines hanging off the cup shelf's ends
function CAFE.drawVines()
  local d = CAFE.dec()
  if not d then return end
  if d.decor.ivy ~= "on" and d.decor.bloomvine ~= "on" then return end
  local ph = (frames // 4) % 16                -- sixteen sway poses, each drawn once into a picture
  CAFE.cached("vine" .. ph, function() CAFE.vinesRaw(ph) end, 40, 44)
end

function CAFE.vinesRaw(ph)
  local d = CAFE.dec()
  local function vine(x0, lens, flowers)
    for i, len in ipairs(lens) do
      local x = x0 + (i - 1) * 4
      local px, py = x, 43
      for yy = 45, 43 + len, 3 do
        local xx = x + math.floor(math.sin(ph * 0.3927 + yy * 0.3 + i) * 1.5 + 0.5)
        gfx.setColor(BLACK)
        gfx.drawLine(px, py, xx, yy)
        px, py = xx, yy
        if (yy // 3) % 2 == 0 then
          gfx.setColor(WHITE)
          gfx.fillCircleAtPoint(xx + ((i % 2 == 0) and 2 or -2), yy, 2)
          gfx.setColor(BLACK)
          gfx.drawCircleAtPoint(xx + ((i % 2 == 0) and 2 or -2), yy, 2)
        elseif flowers then                     -- the flowering vine has little blossoms between the leaves
          local fx = xx + ((i % 2 == 0) and -3 or 3)
          gfx.setColor(WHITE)
          gfx.fillCircleAtPoint(fx, yy, 3)
          gfx.setColor(BLACK)
          gfx.drawCircleAtPoint(fx, yy, 3)
          gfx.fillCircleAtPoint(fx, yy, 1)
          gfx.drawPixel(fx, yy - 4); gfx.drawPixel(fx, yy + 4); gfx.drawPixel(fx - 4, yy); gfx.drawPixel(fx + 4, yy)
        end
      end
    end
    gfx.setColor(BLACK)
  end
  if d.decor.ivy == "on" then vine(100, { 14, 24, 18 }, false) end
  if d.decor.bloomvine == "on" then vine(180, { 20, 14, 26 }, true) end
end

CAFE.ANIM = { plant = true, fern = true, tree = true, palm = true, cactus = true, flowers = true, snake = true,
              sunflower = true, bonsai = true, monstera = true, pumpkin = true, cattree = true, dogbed = true, floorlamp = true }      -- floor pieces that sway / blink
function CAFE.drawFloorItems(live)             -- live = just the moving ones (the rest are in the floor picture)
  local d = CAFE.dec()
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == "floor" and d.decor[it.id] == "on" and d.place[it.id] and ((CAFE.ANIM[it.id] == true) == (live == true)) then
      local sl = CAFE.FSLOT[d.place[it.id]]
      CAFE.art[it.id](sl[1], sl[2])
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.shuffle(t)
  for i = #t, 2, -1 do local j = math.random(i); t[i], t[j] = t[j], t[i] end
  return t
end

-- Rush Hour and Evening Chill: a different little cafe every time (3 or more tables, some decor)
function CAFE.randomRoom(mode)
  local d = { decor = {}, place = {}, tables = {}, off = {}, sign = true, cups = 5, stars = 0, name = "" }
  local n = (mode == "chill") and 3 or (3 + math.random(0, 1))
  local pool = {}
  for i = 1, #CAFE.TSLOT do pool[i] = i end
  CAFE.shuffle(pool)
  for k = 1, n do d.tables[k] = pool[k] end
  d.seatStep = n
  local function fill(kind, slots, lo, hi)
    local ids = {}
    for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind and not it.needs then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    for i = 1, math.min(math.random(lo, hi), #ids, #slots) do
      d.decor[ids[i]] = "on"; d.place[ids[i]] = slots[i]
    end
  end
  do                                            -- wall decor: clocks and pictures on any of the free tiles
    local ids, slots = {}, { 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 }
    for _, it in ipairs(CAFE.ITEMS) do if (it.kind == "wall" or it.kind == "tiny") and not it.needs then ids[#ids + 1] = it.id end end
    CAFE.shuffle(ids); CAFE.shuffle(slots)
    local put = 0
    for _, id in ipairs(ids) do
      if put >= math.random(3, 6) then break end
      for si, sl in ipairs(slots) do
        if sl ~= false and (id ~= "cuckoo" or sl <= #CAFE.WSLOT) then
          d.decor[id] = "on"; d.place[id] = sl; slots[si] = false; put = put + 1
          break
        end
      end
    end
  end
  fill("counter", { 1, 2, 3, 4, 5 }, 1, 3)
  fill("floor", { 1, 2, 3, 4, 5, 6, 7 }, 2, 4)
  for _, kind in ipairs({ "rug", "runner", "cloth", "centerpiece", "frame", "curtain" }) do
    if math.random() < 0.5 then
      local ids = {}
      for _, it in ipairs(CAFE.ITEMS) do if it.kind == kind then ids[#ids + 1] = it.id end end
      d.decor[ids[math.random(#ids)]] = "on"
    end
  end
  if math.random() < 0.35 then d.decor.ivy = "on" end
  if math.random() < 0.35 then d.decor.bloomvine = "on" end
  if math.random() < 0.5 then d.decor.lights = "on" end
  return d
end

function CAFE.decorOn(id)
  local d = CAFE.dec()
  return d ~= nil and d.decor[id] == "on"
end

function CAFE.dec() return G ~= nil and (G.cafe or G.deco) or nil end      -- the decor being shown (a cafe save, or a random room)

-- the string of lights is drawn once into a picture (one for each blink phase) and just stamped on
function CAFE.lightsRaw(phase)
  local prev
  for x = 0, 400, 4 do
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5)
    gfx.setColor(WHITE)
    if prev then gfx.drawLine(prev[1], prev[2], x, y) end
    prev = { x, y }
  end
  for i = 0, 20 do
    local x = i * 20 + 10
    local y = 21 + math.floor(3 * math.sin(math.pi * (x % 40) / 40) + 0.5) + 3
    local lit = ((i + phase) % 2 == 0)
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, lit and 3 or 2)
    gfx.setColor(BLACK)
    gfx.drawCircleAtPoint(x, y, lit and 3 or 2)
  end
  gfx.setColor(BLACK)
end

function CAFE.drawLights()
  if not CAFE.decorOn("lights") then return end
  local phase = (frames // 24) % 2
  CAFE.limg = CAFE.limg or {}
  if CAFE.limg[phase] == nil then
    local ok, img = pcall(function() return gfx.image.new(400, 24, gfx.kColorClear) end)
    if ok and img then
      gfx.pushContext(img)
      gfx.setDrawOffset(0, -14)
      CAFE.lightsRaw(phase)
      gfx.setDrawOffset(0, 0)
      gfx.popContext()
      CAFE.limg[phase] = img
    else
      CAFE.limg[phase] = false
    end
  end
  local im = CAFE.limg[phase]
  if im then im:draw(0, 14) else CAFE.lightsRaw(phase) end
  gfx.setColor(BLACK)
end

-- a long runner rolled out in front of the register, down the line (drawn at any size, so the
-- shop preview can shrink it to fit its box)
function CAFE.runnerAt(which, x, y, w, h)
  local big = w >= 30
  local r = big and 5 or 2
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 4 or 2                      -- border width
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  local cx = x + w // 2
  if which == "run1" then                       -- red carpet
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(WHITE)
    if big then gfx.drawRoundRect(x + 7, y + 7, w - 14, h - 14, 2) end
    local step = math.max(4, h // 14)
    for yy = y + step + m, y + h - step - m, step do gfx.fillRect(cx - 1, yy, big and 3 or 2, big and 3 or 2) end
  elseif which == "run2" then                   -- stripes
    local step = math.max(3, h // 15)
    for yy = iy, iy + ih - 2, step do gfx.fillRect(ix, yy, iw, math.max(1, step // 2)) end
  elseif which == "run3" then                   -- checker
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(ix, iy, iw, ih, big and 3 or 1)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(ix, iy, iw, ih, big and 3 or 1)
  elseif which == "run4" then                   -- diamonds
    local step = math.max(6, h * 14 // 118)
    local hw, hh = math.max(3, w * 8 // 36), math.max(3, step * 6 // 14)
    for yy = y + step, y + h - step + 1, step do
      gfx.drawLine(cx, yy - hh, cx + hw, yy)
      gfx.drawLine(cx + hw, yy, cx, yy + hh)
      gfx.drawLine(cx, yy + hh, cx - hw, yy)
      gfx.drawLine(cx - hw, yy, cx, yy - hh)
      gfx.fillCircleAtPoint(cx, yy, big and 2 or 1)
    end
  elseif which == "run6" then                   -- polka dots
    local st = math.max(5, h // 12)
    for yy = y + st, y + h - st // 2, st do
      local off = ((yy // st) % 2 == 0) and -w // 6 or w // 6
      gfx.fillCircleAtPoint(cx + off, yy, big and 3 or 1)
    end
  elseif which == "run7" then                   -- zigzag
    local st = math.max(6, h // 10)
    local hw = math.max(3, w // 3)
    local px, py = cx - hw, y + m + 1
    for yy = y + m + 1 + st, y + h - m, st do
      local nx = (px < cx) and (cx + hw) or (cx - hw)
      gfx.drawLine(px, py, nx, yy)
      if big then gfx.drawLine(px, py + 1, nx, yy + 1) end
      px, py = nx, yy
    end
  elseif which == "run8" then                   -- plaid
    local st = math.max(6, h // 9)
    gfx.setPattern(CHECK)
    for yy = iy + 1, iy + ih - 3, st do gfx.fillRect(ix, yy, iw, big and 5 or 2) end
    gfx.setColor(BLACK)
    gfx.drawLine(cx, iy, cx, iy + ih)
    if big then gfx.drawLine(cx - 8, iy, cx - 8, iy + ih); gfx.drawLine(cx + 8, iy, cx + 8, iy + ih) end
  else                                          -- coffee beans
    local n = big and 7 or 5
    for i = 0, n - 1 do
      local bx = cx + ((i % 2 == 0) and -w // 5 or w // 5)
      local by = y + (h * (i + 0.5)) // n
      if big then drawBean(bx, by, 1) else gfx.fillCircleAtPoint(bx, by, 2) end
    end
  end
  gfx.setColor(BLACK)
  if big then for xx = x + 3, x + w - 3, 5 do gfx.drawLine(xx, y + h, xx, y + h + 3) end end   -- fringe at the door end
end

function CAFE.drawRunner()
  for _, id in ipairs({ "run1", "run2", "run3", "run4", "run5", "run6", "run7", "run8" }) do
    if CAFE.decorOn(id) then CAFE.runnerAt(id, 38, 116, 36, 118) end
  end
end

-- the big centre rug
function CAFE.rugAt(which, x, y, w, h)
  local big = w >= 100
  local r = big and 8 or 3
  gfx.setColor(WHITE)
  gfx.fillRoundRect(x, y, w, h, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(big and 2 or 1)
  gfx.drawRoundRect(x, y, w, h, r)
  gfx.setLineWidth(1)
  local m = big and 6 or 2
  local ix, iy, iw, ih = x + m, y + m, w - 2 * m, h - 2 * m
  if big then gfx.drawRoundRect(ix, iy, iw, ih, 5) end
  local m2 = big and 2 or 1
  local fx, fy, fw, fh = ix + m2, iy + m2, iw - 2 * m2, ih - 2 * m2
  if which == "rug" then
    gfx.setPattern(TEA)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
  elseif which == "rug2" then
    gfx.setColor(BLACK)
    local step = big and 6 or 3
    for yy = fy + 1, fy + fh - 2, step do gfx.fillRect(fx, yy, fw, big and 3 or 1) end
  elseif which == "rug4" then                   -- polka dots
    gfx.setColor(BLACK)
    local st = big and 11 or 5
    local row = 0
    for yy = fy + st // 2 + 1, fy + fh - 2, st do
      for xx = fx + st // 2 + (row % 2) * (st // 2) + 1, fx + fw - (big and 6 or 3), st do gfx.fillCircleAtPoint(xx, yy, big and 3 or 1) end
      row = row + 1
    end
  elseif which == "rug5" then                   -- a lattice of diamonds
    gfx.setColor(BLACK)
    gfx.setClipRect(fx, fy, fw, fh)
    local st = big and 14 or 6
    for xx = fx - fh, fx + fw, st do
      gfx.drawLine(xx, fy, xx + fh, fy + fh)
      gfx.drawLine(xx + fh, fy, xx, fy + fh)
    end
    gfx.clearClipRect()
  elseif which == "rug6" then                   -- plaid
    local st = big and 18 or 8
    local bw = big and 6 or 3
    gfx.setPattern(CHECK)
    for xx = fx + 2, fx + fw - bw, st do gfx.fillRect(xx, fy, bw, fh) end
    for yy = fy + 2, fy + fh - bw, st do gfx.fillRect(fx, yy, fw, bw) end
    gfx.setColor(BLACK)
    for xx = fx + 2 + bw // 2, fx + fw - 1, st do gfx.drawLine(xx, fy, xx, fy + fh) end
    for yy = fy + 2 + bw // 2, fy + fh - 1, st do gfx.drawLine(fx, yy, fx + fw, yy) end
  elseif which == "rug7" then                   -- scattered coffee beans
    gfx.setColor(BLACK)
    local st = big and 14 or 8
    local row = 0
    for yy = fy + st // 2, fy + fh - 2, st do
      for xx = fx + st // 2 + (row % 2) * (st // 2), fx + fw - (big and 8 or 3), st do
        if big then drawBean(xx, yy, 1) else gfx.fillCircleAtPoint(xx, yy, 1) end
      end
      row = row + 1
    end
  else
    gfx.setPattern(CHECK)
    gfx.fillRoundRect(fx, fy, fw, fh, big and 4 or 1)
    gfx.setColor(BLACK)
    local k = big and 6 or 2
    gfx.drawRoundRect(fx + k, fy + k, fw - 2 * k, fh - 2 * k, big and 3 or 1)
  end
  gfx.setColor(BLACK)
  if big then
    for xx = x + 6, x + w - 8, 12 do            -- fringe
      gfx.drawLine(xx, y, xx, y - 3)
      gfx.drawLine(xx, y + h, xx, y + h + 3)
    end
  end
end

-- ---- table dressing: cloths and centrepieces ----------------------------------------------------------
function CAFE.ownedOf(kind)
  for _, it in ipairs(CAFE.ITEMS) do
    if it.kind == kind and CAFE.decorOn(it.id) then return it.id end
  end
  return nil
end

function CAFE.clothAt(id, x, y, r)
  local R = r + math.max(2, r // 3)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, R)
  gfx.setColor(BLACK)
  if id == "cloth1" then                         -- checker
    gfx.setPattern(CHECK)
    gfx.fillCircleAtPoint(x, y, R)
    gfx.setColor(BLACK)
  elseif id == "cloth2" then                     -- stripes
    for dy = -R + 1, R - 1, 3 do
      local hw = math.floor(math.sqrt(R * R - dy * dy))
      gfx.fillRect(x - hw, y + dy, 2 * hw, 2)
    end
  else                                           -- lace: scalloped edge and a dotted ring
    for a = 0, 330, 30 do
      local rad = math.rad(a)
      local sx, sy = x + math.floor(R * math.cos(rad) + 0.5), y + math.floor(R * math.sin(rad) + 0.5)
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(sx, sy, math.max(2, r // 6))
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(sx, sy, math.max(2, r // 6))
    end
    gfx.setColor(WHITE)
    gfx.fillCircleAtPoint(x, y, R - 1)
    gfx.setColor(BLACK)
    for a = 0, 345, 15 do
      local rad = math.rad(a)
      gfx.drawPixel(x + math.floor((r + 1) * math.cos(rad) + 0.5), y + math.floor((r + 1) * math.sin(rad) + 0.5))
    end
  end
  gfx.setColor(BLACK)
  gfx.drawCircleAtPoint(x, y, R)
end

function CAFE.centerAt(id, x, y, k)              -- a tiny thing in the middle of a table (k = size)
  gfx.setColor(BLACK)
  if id == "cp1" then                            -- flowers in a vase
    gfx.fillRect(x - k, y, 2 * k, 3 * k)
    for _, o in ipairs({ { -2, -2 }, { 0, -3 }, { 2, -2 } }) do
      gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + o[1] * k, y + o[2] * k, k)
      gfx.setColor(BLACK); gfx.drawCircleAtPoint(x + o[1] * k, y + o[2] * k, k)
    end
  elseif id == "cp2" then                        -- candle
    local ph = (frames // 5) % 3                    -- the flame dances: lean left, upright, lean right
    local lean, hgt = (ph - 1) * k, (ph == 1) and 0 or -k
    gfx.fillRoundRect(x - 5 * k, y + 3 * k, 10 * k, 2 * k, k)                 -- the little dish
    gfx.setColor(WHITE); gfx.fillRect(x - 3 * k, y - 3 * k, 6 * k, 7 * k)    -- a fat wax candle
    gfx.setColor(BLACK); gfx.drawRect(x - 3 * k, y - 3 * k, 6 * k, 7 * k)
    gfx.drawLine(x - k, y - 3 * k, x - k, y); gfx.drawLine(x + 2 * k, y - 3 * k, x + 2 * k, y - k)   -- drips
    gfx.drawLine(x, y - 3 * k, x, y - 5 * k)                                  -- the wick
    gfx.fillCircleAtPoint(x + lean // 2, y - 6 * k, 2 * k)                    -- the flame: a round base and a pointed top
    gfx.fillTriangle(x - 2 * k, y - 6 * k, x + 2 * k, y - 6 * k, x + lean, y - 11 * k - hgt)
    gfx.setColor(WHITE); gfx.fillCircleAtPoint(x + lean // 2, y - 6 * k, math.max(1, k // 2))
    gfx.setColor(BLACK)
    if ph ~= 1 then gfx.drawPixel(x - 6 * k, y - 9 * k); gfx.drawPixel(x + 6 * k, y - 8 * k)   -- glow sparkles
    else gfx.drawPixel(x + 6 * k, y - 9 * k); gfx.drawPixel(x - 6 * k, y - 8 * k) end
  elseif id == "cp3" then                        -- sprig in a pot
    gfx.fillPolygon(x - 2 * k, y, x + 2 * k, y, x + k, y + 3 * k, x - k, y + 3 * k)
    gfx.drawLine(x, y, x, y - 3 * k)
    gfx.drawLine(x, y - k, x - 2 * k, y - 3 * k)
    gfx.drawLine(x, y - 2 * k, x + 2 * k, y - 4 * k)
  elseif id == "cp5" or id == "cp6" then         -- the pumpkin and the tree are little pixel pictures, with a twinkle
    local im = CAFE.spr(id)
    local w, h = im:getSize()
    local x0, y0 = x - w * k // 2, y - h * k // 2
    if k == 1 then im:draw(x0, y0) else im:drawScaled(x0, y0, k, k) end
    local ph = (frames // 12) % 2
    if id == "cp5" then                          -- the candle inside makes the eyes flicker
      if ph == 1 then
        gfx.setColor(WHITE)
        for _, ex in ipairs({ 3, 9 }) do
          gfx.fillRect(x0 + ex * k, y0 + 5 * k, 2 * k, k)
          gfx.fillRect(x0 + (ex + 1) * k, y0 + 6 * k, k, k)
        end
      end
      gfx.setColor(BLACK)
      gfx.fillRect(x0 + (ph == 0 and 9 or 10) * k, y0 + (ph == 0 and 0 or -k), k, k)                 -- a wisp of smoke from the stem
    else                                         -- baubles take turns, and the star sparkles
      local lights = { { 6, 7 }, { 5, 9 }, { 8, 10 }, { 4, 12 }, { 7, 13 }, { 9, 15 }, { 3, 16 }, { 6, 15 } }
      for i, p in ipairs(lights) do
        gfx.setColor(((i + ph) % 2 == 0) and WHITE or BLACK)
        gfx.fillRect(x0 + p[1] * k, y0 + p[2] * k, k, k)
      end
      gfx.setColor(BLACK)
      if ph == 0 then gfx.fillRect(x0 + 1 * k, y0 + k, k, k); gfx.fillRect(x0 + 11 * k, y0 + k, k, k)
      else gfx.fillRect(x0, y0 + 2 * k, k, k); gfx.fillRect(x0 + 12 * k, y0 + 2 * k, k, k) end
    end
    gfx.setColor(BLACK)
  else                                           -- cactus
    gfx.fillRect(x - k, y - 3 * k, 2 * k, 6 * k)
    gfx.fillRect(x - 3 * k, y - 2 * k, 2 * k, k)
    gfx.fillRect(x - 3 * k, y - 3 * k, k, 2 * k)
    gfx.fillRect(x + k, y - k, 2 * k, k)
    gfx.fillRect(x + 2 * k, y - 2 * k, k, 2 * k)
  end
  gfx.setColor(BLACK)
end

function CAFE.tableAt(x, y, r, cloth, cp, k)
  if cloth then CAFE.clothAt(cloth, x, y, r) end
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(x, y, r)
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  gfx.drawCircleAtPoint(x, y, r)
  gfx.setLineWidth(1)
  if cp then CAFE.centerAt(cp, x, y, k) end
end

function CAFE.drawRug()
  for _, id in ipairs({ "rug", "rug2", "rug3", "rug4", "rug5", "rug6", "rug7" }) do
    if CAFE.decorOn(id) then CAFE.rugAt(id, 112, 128, 190, 44) end
  end
end

-- ---- the window: frames and curtains -------------------------------------------------------------------
CAFE.FRAMES = { "wf1", "wf2", "wf3", "wf4", "wf5", "wf6" }
CAFE.CURTAINS = { "wc1", "wc2", "wc3", "wc4", "wc5", "wc6", "wc7", "wc8", "wc9", "wc10" }

function CAFE.drape(x0, y0, wd, h, dir, style, sway)   -- one side curtain, tied back in the middle; dir = 1 hangs from the left edge
  local function X(dx) return dir == 1 and (x0 + dx) or (x0 - dx) end
  local pinch = 3 + sway
  local pts = { X(0), y0, X(wd), y0, X(wd - pinch), y0 + 13, X(wd + 1), y0 + h, X(0), y0 + h }
  gfx.setColor(WHITE)
  gfx.fillPolygon(table.unpack(pts))
  gfx.setColor(BLACK)
  if style == "wc2" then                                  -- checker
    gfx.setPattern(CHECK); gfx.fillPolygon(table.unpack(pts)); gfx.setColor(BLACK)
  elseif style == "wc3" then                              -- stripes
    for dx = 1, wd - 1, 4 do gfx.drawLine(X(dx), y0, X(dx), y0 + h) end
  elseif style == "wc10" then                             -- night sky with stars
    gfx.fillPolygon(table.unpack(pts))
    gfx.setColor(WHITE)
    for _, p in ipairs({ { 2, 4 }, { 6, 9 }, { 3, 15 }, { 7, 20 }, { 4, 23 } }) do
      if p[1] < wd - 1 then gfx.drawPixel(X(p[1]), y0 + p[2]); gfx.drawPixel(X(p[1]) + 1, y0 + p[2]) end
    end
    gfx.setColor(BLACK)
  elseif style == "wc6" then                              -- polka dots
    for _, p in ipairs({ { 3, 4 }, { 7, 9 }, { 3, 14 }, { 7, 19 }, { 3, 23 } }) do
      if p[1] < wd - 1 then gfx.fillCircleAtPoint(X(p[1]), y0 + p[2], 1) end
    end
  elseif style == "wc7" then                              -- coffee beans
    for _, p in ipairs({ { 3, 5 }, { 7, 11 }, { 3, 17 }, { 7, 22 } }) do
      if p[1] < wd - 1 then gfx.fillEllipseInRect(X(p[1]) - 2, y0 + p[2] - 1, 4, 3) end
    end
  elseif style == "wc9" then                              -- little hearts
    for _, p in ipairs({ { 3, 5 }, { 7, 12 }, { 3, 19 } }) do
      if p[1] < wd - 1 then
        local hx, hy = X(p[1]), y0 + p[2]
        gfx.drawPixel(hx - 1, hy); gfx.drawPixel(hx + 1, hy)
        gfx.drawLine(hx - 1, hy + 1, hx + 1, hy + 1); gfx.drawPixel(hx, hy + 2)
      end
    end
  else                                                    -- plain: soft folds
    gfx.drawLine(X(3), y0, X(3), y0 + 12); gfx.drawLine(X(6), y0 + 14, X(6), y0 + h)
  end
  gfx.setColor(BLACK)
  gfx.drawLine(pts[1], pts[2], pts[3], pts[4]); gfx.drawLine(pts[3], pts[4], pts[5], pts[6])
  gfx.drawLine(pts[5], pts[6], pts[7], pts[8])
  gfx.fillRect(math.min(X(wd - pinch) - 1, X(wd - pinch) + 1), y0 + 12, 3, 3)        -- the tie-back
end

function CAFE.windowAt(x, y, frame, curtain, preview)
  local w, h = 54, 26
  gfx.setColor(WHITE)
  gfx.fillRect(x, y, w, h)
  if preview then                                         -- (a little sky for the shop picture)
    gfx.setColor(BLACK)
    gfx.drawLine(x + 6, y + 18, x + 20, y + 16); gfx.drawLine(x + 30, y + 8, x + 44, y + 9)
    WIN.sunAt(x + 40, y + 14, 3, 0.3)
  else
    WIN.drawView(G.win, x + 1, y + 1, 1)
  end
  gfx.setColor(BLACK)
  gfx.setLineWidth(2)
  if frame == "wf5" then gfx.drawRoundRect(x, y, w, h, 12) else gfx.drawRect(x, y, w, h) end
  gfx.setLineWidth(1)
  if frame == nil or frame == "wf4" or frame == "wf5" then   -- the usual four panes
    gfx.drawLine(x + 27, y, x + 27, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf2" then                              -- six panes
    gfx.drawLine(x + 18, y, x + 18, y + h); gfx.drawLine(x + 36, y, x + 36, y + h); gfx.drawLine(x, y + 13, x + w, y + 13)
  elseif frame == "wf3" then                              -- diamond panes
    gfx.setClipRect(x + 1, y + 1, w - 2, h - 2)
    for xx = x - h, x + w, 11 do
      gfx.drawLine(xx, y, xx + h, y + h); gfx.drawLine(xx + h, y, xx, y + h)
    end
    gfx.clearClipRect()
  elseif frame == "wf6" then                              -- shutters folded open at both sides
    for _, sx in ipairs({ x + 1, x + w - 10 }) do
      gfx.setColor(WHITE); gfx.fillRect(sx, y + 1, 9, h - 2)
      gfx.setColor(BLACK); gfx.drawRect(sx, y + 1, 9, h - 2)
      for yy = y + 4, y + h - 4, 3 do gfx.drawLine(sx + 1, yy, sx + 7, yy) end
    end
  end
  if frame == "wf4" then                                  -- a sill with two little brackets
    gfx.fillRect(x - 3, y + h, w + 6, 3)
    gfx.fillRect(x + 5, y + h + 3, 5, 2); gfx.fillRect(x + w - 10, y + h + 3, 5, 2)
  end
  if curtain then
    local sway = 0
    if not preview and G and G.win and G.win.fx and G.win.fx.wind then sway = (frames // 14) % 2 end   -- they stir in the wind
    if curtain == "wc4" then                              -- a scalloped valance across the top
      gfx.setColor(WHITE); gfx.fillRect(x, y, w, 6)
      gfx.setColor(BLACK)
      for cx = x + 4, x + w - 3, 8 do
        gfx.setColor(WHITE); gfx.fillCircleAtPoint(cx, y + 5, 4)
        gfx.setColor(BLACK); gfx.drawCircleAtPoint(cx, y + 5, 4)
      end
      gfx.setColor(WHITE); gfx.fillRect(x + 1, y - 1, w - 2, 5); gfx.setColor(BLACK)
      gfx.drawLine(x, y + 3, x + w, y + 3)
      for cx = x + 4, x + w - 3, 8 do gfx.drawPixel(cx, y + 6); gfx.drawPixel(cx, y + 8) end
    elseif curtain == "wc5" then                          -- lace across the whole window
      gfx.setColor(BLACK)
      for yy = y + 3, y + h - 3, 3 do
        for xx = x + 3 + ((yy // 3) % 2) * 2, x + w - 3, 4 do gfx.drawPixel(xx, yy) end
      end
      for cx = x + 3, x + w - 3, 6 do gfx.drawCircleAtPoint(cx, y + h - 2, 2) end
      gfx.drawLine(x + 1, y + 2, x + w - 1, y + 2)
    elseif curtain == "wc8" then                          -- blinds, pulled down a little over half way
      gfx.setColor(WHITE); gfx.fillRect(x + 1, y + 1, w - 2, 15)
      gfx.setColor(BLACK)
      for yy = y + 2, y + 15, 3 do gfx.drawLine(x + 1, yy, x + w - 1, yy) end
      gfx.drawLine(x + 1, y + 16, x + w - 1, y + 16)
      gfx.drawLine(x + w - 6, y + 16, x + w - 6, y + 21); gfx.fillCircleAtPoint(x + w - 6, y + 22, 2)   -- the pull cord
    else                                                  -- two drapes with tie-backs
      CAFE.drape(x + 1, y + 1, 11, h - 2, 1, curtain, sway)
      CAFE.drape(x + w - 1, y + 1, 11, h - 2, -1, curtain, sway)
      gfx.setColor(BLACK)
      gfx.fillRect(x - 2, y - 2, w + 4, 2)                -- the curtain rod
      gfx.fillCircleAtPoint(x - 3, y - 1, 2); gfx.fillCircleAtPoint(x + w + 3, y - 1, 2)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawWindowNow()
  CAFE.windowAt(32, 22, CAFE.ownedOf("frame"), CAFE.ownedOf("curtain"), false)
end

function CAFE.windowPreview(id, cx, cy)                 -- the shop picture: the window at 1.6 times its size
  CAFE.WPREV = CAFE.WPREV or {}
  local im = CAFE.WPREV[id]
  if im == nil then
    im = gfx.image.new(66, 40, gfx.kColorClear)
    gfx.pushContext(im)
    local isFrame = CAFE.byId[id].kind == "frame"
    CAFE.windowAt(6, 8, isFrame and id or nil, (not isFrame) and id or nil, true)
    gfx.popContext()
    CAFE.WPREV[id] = im
  end
  im:drawScaled(cx - 52, cy - 32, 1.6, 1.6)
end

for _, id in ipairs(CAFE.FRAMES) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end
for _, id in ipairs(CAFE.CURTAINS) do CAFE.art[id] = function(cx, cy) CAFE.windowPreview(id, cx, cy) end end

-- ---- pets --------------------------------------------------------------------------------------------
function CAFE.homeOf(kind)               -- where the pet's own furniture is (if you've put it out)
  local d = G.cafe
  local id = (kind == "cat") and "cattree" or "dogbed"
  if d.decor[id] == "on" and d.place[id] then
    local sl = CAFE.FSLOT[d.place[id]]
    return sl[1], sl[2]
  end
  return nil
end

function CAFE.makePets()
  local pets = {}
  local d = CAFE.cur
  for _, kind in ipairs({ "cat", "dog" }) do
    local var = CAFE.petOn(d, kind)
    if var then
      pets[kind] = { var = var, x = 60 + math.random() * 280, y = 130 + math.random() * 90, tx = 0, ty = 0,
                     mode = "idle", wait = 1 + math.random() * 3, dir = 1, home = false,
                     pose = (kind == "cat") and "sit" or "sit" }
    end
  end
  return pets
end

function CAFE.updatePets(dt)
  for kind, p in pairs(G.pets) do
    local speed = (kind == "cat") and 20 or 26
    if p.mode == "walk" then
      local gx, gy = p.tx, p.ty
      local via = p.wp and p.wp[1]
      if via then gx, gy = via[1], via[2] end
      local dx, dy = gx - p.x, gy - p.y
      local dist = math.sqrt(dx * dx + dy * dy)
      if via and dist <= speed * dt then          -- reached a corner of the detour: carry on to the next
        p.x, p.y = gx, gy
        table.remove(p.wp, 1)
      elseif dist <= speed * dt then
        p.x, p.y = p.tx, p.ty
        p.mode = p.home and "rest" or "idle"
        if kind == "cat" then
          p.pose = (math.random() < (p.home and 0.7 or 0.45)) and "sleep" or "sit"
        else
          p.pose = p.home and "lie" or ((math.random() < 0.55) and "sit" or "lie")
        end
        local sleepy = (p.pose == "sleep" or p.pose == "lie")
        p.wait = p.home and (12 + math.random() * 14) or (sleepy and (7 + math.random() * 9) or (2 + math.random() * 5))
      else
        p.x = p.x + dx / dist * speed * dt
        p.y = p.y + dy / dist * speed * dt
        if math.abs(dx) > 1 then p.dir = dx > 0 and 1 or -1 end
      end
    else
      p.wait = p.wait - dt
      if p.wait <= 0 then
        local hx, hy = CAFE.homeOf(kind)
        if hx and not p.home and math.random() < ((kind == "dog") and 0.65 or 0.45) then
          p.tx, p.ty, p.home = hx, hy + ((kind == "cat") and 14 or 10), true
        else
          for _ = 1, 8 do                          -- somewhere clear (not on a table or a plant)
            p.tx, p.ty, p.home = 50 + math.random() * 330, 126 + math.random() * 100, false
            if not CAFE.pointBlocked(p.tx, p.ty) then break end
          end
        end
        p.wp = CAFE.route(p.x, p.y, p.tx, p.ty)
        p.mode = "walk"
      end
    end
  end
end

-- a floating "z" for sleepers
function CAFE.zzz(x, y)
  local k = (frames // 18) % 3
  for i = 0, 1 do
    local zy = y - 5 - i * 6 - k
    local sz = 2 + i
    gfx.drawLine(x + i * 4, zy, x + i * 4 + sz, zy)
    gfx.drawLine(x + i * 4 + sz, zy, x + i * 4, zy + sz)
    gfx.drawLine(x + i * 4, zy + sz, x + i * 4 + sz, zy + sz)
  end
end

-- an ear: black, with a thin white edge so it shows up against the black head
function CAFE.ear(x1, y1, x2, y2, x3, y3)
  gfx.setColor(BLACK)
  gfx.fillTriangle(x1, y1, x2, y2, x3, y3)
  gfx.setColor(WHITE)
  gfx.drawLine(x1, y1, x3, y3)
  gfx.setColor(BLACK)
end

-- x, y = where the feet are. cat: walk / sit / sleep.  dog: walk / sit / lie
function CAFE.pet(kind, x, y, dir, pose, var)
  CAFE.petBody(kind, x, y, dir, pose, var)
  if var and var ~= "cat" and var ~= "dog" then CAFE.petCoat(kind, var, math.floor(x), math.floor(y), dir, pose) end
end

-- coat markings drawn over the plain black pet (white marks, or a grey dither)
function CAFE.petCoat(kind, var, x, y, dir, pose)
  local bx, by, hw, hh, hx, hy                      -- body centre and half sizes, head centre
  if kind == "cat" then
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 5, 6, 3, x + dir * 7, y - 9
    elseif pose == "sleep" then bx, by, hw, hh, hx, hy = x, y - 4, 8, 3, x + dir * 6, y - 5
    else bx, by, hw, hh, hx, hy = x, y - 5, 4, 4, x + dir, y - 12 end
  else
    local sp = CAFE.PETSPEC[var] or CAFE.PETSPEC.dog
    if pose == "walk" then bx, by, hw, hh, hx, hy = x, y - 8 - sp.up, 9 + sp.bl, 4, x + dir * (10 + sp.bl), y - 14 - sp.up
    elseif pose == "lie" then bx, by, hw, hh, hx, hy = x, y - 4, 9 + sp.bl, 3, x + dir * (10 + sp.bl), y - 4
    else bx, by, hw, hh, hx, hy = x - 2, y - 6, 5, 4, x + dir * 3, y - 19 - sp.up // 2 end
  end
  local function grey(cx, cy, w, h)
    gfx.setColor(BLACK); gfx.setPattern(CHECK)
    gfx.fillEllipseInRect(cx - w, cy - h, w * 2, h * 2)
    gfx.setColor(BLACK)
  end
  gfx.setColor(WHITE)
  if var == "tuxcat" then                          -- white bib, belly and a pale nose
    gfx.fillEllipseInRect(bx - 2, by, 5, hh)
    gfx.drawPixel(hx + dir, hy + 1)
    gfx.drawLine(hx, hy + 2, hx + dir, hy + 2)
  elseif var == "tabbycat" then                    -- stripes across the back
    for i = -2, 2, 2 do gfx.drawLine(bx + i, by - hh + 1, bx + i, by + hh - 1) end
  elseif var == "calicocat" then                   -- patches
    gfx.fillEllipseInRect(bx - hw + 1, by - hh + 1, 4, 3)
    gfx.fillEllipseInRect(bx + 1, by, 4, 3)
    gfx.drawPixel(hx - dir, hy - 2)
  elseif var == "graycat" then
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1); grey(hx, hy, 3, 3)
  elseif var == "dalmatian" then                   -- spots all over
    gfx.fillCircleAtPoint(bx - hw + 2, by - 1, 1); gfx.fillCircleAtPoint(bx + 1, by + 1, 1)
    gfx.fillCircleAtPoint(bx + hw - 3, by - 1, 1); gfx.drawPixel(hx, hy - 2)
  elseif var == "husky" then                       -- grey coat, white face mask and belly
    gfx.setColor(BLACK); grey(bx, by, hw + 1, hh + 1); gfx.setColor(WHITE)
    gfx.fillEllipseInRect(hx - 1 + dir, hy, 4, 3)
    gfx.fillEllipseInRect(bx - 3, by + 1, 7, 2)
  elseif var == "patchdog" then                    -- one white patch and a white chest
    gfx.fillEllipseInRect(bx + dir * 2 - 2, by - hh + 1, 5, 4)
    gfx.drawLine(hx, hy - 3, hx, hy)
    gfx.fillEllipseInRect(hx - dir * 4 - 1, hy + 2, 3, 3)
  elseif var == "goldendog" then                   -- a pale golden coat (ears and nose stay dark)
    gfx.setColor(BLACK)
    grey(bx, by, hw + 1, hh + 1); grey(hx, hy, 3, 3)
  end
  gfx.setColor(BLACK)
end

CAFE.PETSPEC = {                                    -- every coat has its own ears, tail and shape
  cat      = { ears = "point", fat = 0, tail = "long" },
  tuxcat   = { ears = "tall",  fat = 0, tail = "hook" },
  tabbycat = { ears = "tuft",  fat = 1, tail = "bob" },
  calicocat = { ears = "round", fat = 1, tail = "bush" },
  graycat  = { ears = "fold",  fat = 2, tail = "long" },
  dog       = { ears = "floppy", up = 0,  sn = 5, tail = "wag",  bl = 0, thick = 0 },
  dalmatian = { ears = "fold",   up = 3,  sn = 6, tail = "wag",  bl = 0, thick = 0 },
  husky     = { ears = "point",  up = 0,  sn = 4, tail = "curl", bl = 1, thick = 1 },
  patchdog  = { ears = "long",   up = -2, sn = 5, tail = "stub", bl = 3, thick = 0 },
  goldendog = { ears = "floppy", up = 0,  sn = 6, tail = "bush", bl = 2, thick = 2 },
}

function CAFE.catEars(hx, hy, d, kind, sit, tipH)
  local tall = (kind == "tall") and 3 or 0
  if sit then
    if kind == "round" then
      gfx.fillCircleAtPoint(hx - 3, hy - 4, 2); gfx.fillCircleAtPoint(hx + 3, hy - 4, 2)
    elseif kind == "fold" then
      gfx.fillRect(hx - 5, hy - 5, 4, 2); gfx.fillRect(hx + 2, hy - 5, 4, 2)
    else
      CAFE.ear(hx - 3, hy - 2, hx - 3, hy - 6 - tall, hx, hy - 3)
      CAFE.ear(hx + 3, hy - 2, hx + 3, hy - 6 - tall, hx, hy - 3)
      if kind == "tuft" then gfx.drawPixel(hx - 3, hy - 8); gfx.drawPixel(hx + 3, hy - 8) end
    end
    return
  end
  if kind == "round" then
    gfx.fillCircleAtPoint(hx - d, hy - 4, 2); gfx.fillCircleAtPoint(hx + d * 2, hy - 3, 2)
  elseif kind == "fold" then
    gfx.fillRoundRect(hx - 2, hy - 5, 5, 3, 1)
  else
    CAFE.ear(hx - d * 2, hy - 2, hx - d, hy - 2 - tipH - tall, hx + d, hy - 2)
    CAFE.ear(hx + d, hy - 2, hx + d * 3, hy - 1 - tipH - tall, hx + d * 3, hy - 1)
    if kind == "tuft" then gfx.drawPixel(hx - d, hy - 3 - tipH); gfx.drawPixel(hx + d * 3, hy - 2 - tipH) end
  end
end

function CAFE.catTail(kind, d, bx, by, mx, my, ex, ey)
  if kind == "bob" then
    gfx.fillCircleAtPoint(bx - d * 2, by, 2)
    return
  end
  gfx.drawLine(bx, by, mx, my); gfx.drawLine(mx, my, ex, ey)
  if kind == "bush" then
    gfx.drawLine(bx, by + 1, mx, my + 1); gfx.drawLine(mx, my + 1, ex, ey + 1)
    gfx.fillCircleAtPoint(ex, ey, 2)
  elseif kind == "hook" then
    gfx.drawLine(ex, ey, ex + d * 3, ey - 1); gfx.drawPixel(ex + d * 3, ey)
  end
end

function CAFE.dogEars(hx, hy, d, kind)
  if kind == "point" then
    CAFE.ear(hx - 2 * d, hy - 3, hx - d, hy - 9, hx + d, hy - 3)
    CAFE.ear(hx + d, hy - 3, hx + 3 * d, hy - 8, hx + 3 * d, hy - 2)
  elseif kind == "long" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 3 * d, hy - 3, hx - d, hy + 8)
  elseif kind == "fold" then
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 4, hx + 2 * d, hy + 1)
  else
    CAFE.ear(hx - 2 * d, hy - 4, hx + 2 * d, hy - 3, hx, hy + 5)
  end
end

function CAFE.dogTail(kind, d, bx, by, ex, ey)
  if kind == "stub" then
    gfx.fillRect(bx - d * 2 - 1, by - 2, 3, 3)
  elseif kind == "curl" then
    gfx.drawLine(bx, by, bx - d * 3, by - 3)
    gfx.drawCircleAtPoint(bx - d * 3, by - 5, 3)
  elseif kind == "bush" then
    gfx.drawLine(bx, by, ex, ey); gfx.drawLine(bx, by + 1, ex, ey + 1)
    gfx.fillCircleAtPoint(ex, ey, 2)
  else
    gfx.drawLine(bx, by, ex, ey)
  end
end

function CAFE.petBody(kind, x, y, dir, pose, var)
  x, y = math.floor(x), math.floor(y)
  local sp = CAFE.PETSPEC[var or kind] or CAFE.PETSPEC[kind]
  gfx.setColor(BLACK)
  local step = math.floor(math.sin(frames * 0.5) * 1.5)
  local wag = math.floor(math.sin(frames * 0.35) * 3)
  local breathe = math.floor(math.sin(frames * 0.12) + 0.5)
  local d = dir
  if kind == "cat" then
    local f = sp.fat
    if pose == "walk" then
      gfx.fillEllipseInRect(x - 7 - f, y - 8 - f, 14 + 2 * f, 7 + f)
      gfx.fillCircleAtPoint(x + d * 7, y - 9, 3)
      CAFE.catEars(x + d * 7, y - 9, d, sp.ears, false, 5)
      CAFE.catTail(sp.tail, d, x - d * 7, y - 6, x - d * 9, y - 9, x - d * 11, y - 12 + step)
      gfx.drawLine(x - 4, y - 2, x - 4 + step, y)
      gfx.drawLine(x + 4, y - 2, x + 4 - step, y)
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 8, y - 10); gfx.setColor(BLACK)
    elseif pose == "sleep" then                     -- curled up in a ball
      gfx.fillEllipseInRect(x - 9 - f, y - 8 - f - breathe, 18 + 2 * f, 8 + f + breathe)
      gfx.fillCircleAtPoint(x + d * 6, y - 5, 3)
      CAFE.catEars(x + d * 6, y - 5, d, sp.ears, false, 4)
      gfx.setColor(WHITE)
      gfx.drawLine(x + d * 5, y - 5, x + d * 7, y - 5)         -- closed eyes
      if sp.tail ~= "bob" then gfx.drawLine(x - 6, y - 3, x + 3, y - 1) end   -- the tail wrapped round
      gfx.setColor(BLACK)
      CAFE.zzz(x + d * 9, y - 8)
    else                                            -- sitting, looking out
      gfx.fillEllipseInRect(x - 5 - f, y - 9 - f, 10 + 2 * f, 9 + f)
      gfx.fillCircleAtPoint(x + d, y - 12 - f // 2, 4)
      CAFE.catEars(x + d, y - 12 - f // 2, d, sp.ears, true, 4)
      CAFE.catTail(sp.tail, d, x - d * 5, y - 2, x - d * 10, y - 6, x - d * 9, y - 10 + wag // 2)
      gfx.setColor(WHITE); gfx.drawPixel(x + d - 1, y - 12 - f // 2); gfx.drawPixel(x + d + 2, y - 12 - f // 2); gfx.setColor(BLACK)
    end
  else
    local up, sn, bl, th = sp.up, sp.sn, sp.bl, sp.thick
    local function snout(hx, hy) gfx.fillRect(d > 0 and (hx + 2) or (hx - 2 - sn), hy, sn, 3) end
    if pose == "walk" then
      local hx, hy = x + d * (10 + bl), y - 14 - up
      gfx.fillEllipseInRect(x - 10 - bl, y - 12 - up - th, 20 + 2 * bl, 9 + th)
      gfx.fillCircleAtPoint(hx, hy, 4)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 10 - up, x - d * (15 + bl), y - 15 - up + wag)
      gfx.drawLine(x - 7 - bl, y - 4 - up, x - 7 - bl + step, y)
      gfx.drawLine(x - 3, y - 4 - up, x - 3 - step, y)
      gfx.drawLine(x + 4, y - 4 - up, x + 4 + step, y)
      gfx.drawLine(x + 8 + bl, y - 4 - up, x + 8 + bl - step, y)
      gfx.setColor(WHITE)
      gfx.drawPixel(x + d * (11 + bl), y - 15 - up)                                  -- eye
      gfx.fillEllipseInRect(x - 3, y - 7 - up, 8, 3)                                  -- pale belly
      gfx.setColor(BLACK)
    elseif pose == "sit" then
      local hx, hy = x + d * 3, y - 19 - up // 2
      gfx.fillEllipseInRect(x - 10 - bl // 2, y - 10 - th, 14 + bl // 2, 10 + th)     -- haunches
      gfx.fillRoundRect(x + (d > 0 and 0 or -6), y - 16 - up // 2, 6, 16 + up // 2, 2)   -- chest and front legs
      gfx.fillCircleAtPoint(hx, hy, 4)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * 9, y - 2, x - d * 14, y - 3 + wag)
      gfx.setColor(WHITE); gfx.drawPixel(x + d * 4, hy - 1); gfx.drawLine(x + d * 3, y - 10, x + d * 3, y - 3); gfx.setColor(BLACK)
    else                                                                          -- lying down, asleep
      local hx, hy = x + d * (10 + bl), y - 4
      gfx.fillEllipseInRect(x - 10 - bl, y - 7 - breathe - th, 20 + 2 * bl, 7 + breathe + th)
      gfx.fillCircleAtPoint(hx, hy, 4)
      snout(hx, hy)
      CAFE.dogEars(hx, hy, d, sp.ears)
      CAFE.dogTail(sp.tail, d, x - d * (10 + bl), y - 3, x - d * (14 + bl), y - 5)
      gfx.setColor(WHITE); gfx.drawLine(x + d * (9 + bl), y - 5, x + d * (11 + bl), y - 5); gfx.setColor(BLACK)
      CAFE.zzz(x + d * 4, y - 8)
    end
  end
  gfx.setColor(BLACK)
end

function CAFE.drawPets()
  for kind, p in pairs(G.pets) do
    if p.mode == "walk" then
      CAFE.pet(kind, p.x, p.y, p.dir, "walk", p.var)
    elseif p.mode == "rest" and p.home then
      local hx, hy = CAFE.homeOf(kind)
      if hx and kind == "cat" then CAFE.pet("cat", hx, hy - 14, p.dir, p.pose, p.var)
      elseif hx then CAFE.pet("dog", hx, hy + 10, 1, "lie", p.var)            -- curled up on the dog bed
      else CAFE.pet(kind, p.x, p.y, p.dir, p.pose, p.var) end
    else
      CAFE.pet(kind, p.x, p.y, p.dir, p.pose, p.var)
    end
  end
end

-- ---- going in and out --------------------------------------------------------------------------------
function CAFE.open()
  transitionTo(function()
    for i = 1, 3 do CAFE.slots[i] = CAFE.read(i) end
    CAFE.mode, CAFE.erase, CAFE.sel = "slots", nil, 1
    UI.setTitleItem(false)
    state = CAFE.STATE
  end)
end

function CAFE.begin()                          -- off to the store
  CAFE.write()                                 -- starting a shift saves the game
  sfxStart()
  transitionTo(function()
    if CAFE.keep then CAFE.resume() else newGame("cafe") end
    state = STATE_PLAY
  end)
end

function CAFE.resume()                         -- back from the shop: same people, same clock, new purchases
  local g, d = CAFE.keep, CAFE.cur
  CAFE.keep = nil
  CAFE.applyLayout(d)
  setLayout("cafe")
  G = g
  G.ending, G.cafe, G.msg = false, d, nil
  G.cups.shelf = math.max(0, G.cups.shelf + d.cups - G.cupMax)
  G.cupMax = d.cups
  G.seatLimit, G.seatOff, G.seatCount = CAFE.seatsOf(d.seatStep), CAFE.seatOffOf(d), CAFE.seatCountOf(d)
  for key in pairs(G) do                        -- every cached picture (wall, floor, vines...) is drawn again with the new decor
    if type(key) == "string" and (key:find("Img$") or key:find("^vine")) then G[key] = nil end
  end
  G.pets = CAFE.makePets()
  for i = #G.others, 1, -1 do                   -- tables may have moved or been switched off
    local c = G.others[i]
    if c.seat then
      if c.seat > G.seatLimit or G.seatOff[c.seat] then
        G.seats[c.seat] = nil
        c.seat = nil
        leaveRoute(c)
      elseif c.state == "seated" then
        c.x, c.y = SEATS[c.seat].x, SEATS[c.seat].y
      elseif c.state == "toSeat" then
        c.path = { { SEATS[c.seat].x, SEATS[c.seat].y } }
      end
    end
  end
  setShiftMenu(true, true)
end

function CAFE.finish()                         -- the shift is over: bank it, open the shop
  G.total = G.cash + G.tips - (G.banked or 0)
  local d = CAFE.cur
  d.money = d.money + G.total
  d.shifts = d.shifts + 1
  CAFE.report = "Shift: " .. money(G.total) .. " from " .. (G.served - (G.servedBank or 0)) .. " customers"
  CAFE.keep = G                                -- the cafe waits as it is: the line, the diners, the clock, the tip jar
  G.banked = G.cash + G.tips                   -- (what has been paid into your money so far; the totals on screen carry on)
  G.servedBank = G.served
  CAFE.write()
  CAFE.mode, CAFE.shopSel, CAFE.scroll, CAFE.msg = "shop", 1, 0, nil
  CAFE.tab, CAFE.focus, CAFE.tabPos = 1, "tabs", 1
  state = CAFE.STATE
end

function CAFE.saveQuit()                       -- Menu button: bank what you've made so far
  if state ~= STATE_PLAY or not G or G.mode ~= "cafe" or G.ending then return end
  G.ending = true
  CAFE.cur.money = CAFE.cur.money + G.cash + G.tips - (G.banked or 0)
  G.banked = G.cash + G.tips
  CAFE.write()
  CAFE.closeDoor()
end

-- ---- the shop ----------------------------------------------------------------------------------------
-- the shop's pages, like browser tabs (Left / Right to switch)
CAFE.TABS = { "Cafe", "Plants", "Wall", "Window", "Rugs", "Tables", "Pets" }
CAFE.TABPATH = { "cafe", "plants", "wall", "window", "rugs", "tables", "pets" }
CAFE.TABKIND = { floor = 2, counter = 2, shelf = 2, wall = 3, tiny = 3, ceiling = 3, frame = 4, curtain = 4, rug = 5, runner = 5, cloth = 6, centerpiece = 6 }
function CAFE.tabOf(row)
  local k = row[3]
  if k == "seat" or k == "cup" or k == "sign" or k == "layout" then return 1 end
  local it = CAFE.byId[row[5] or ""]
  if not it then return 1 end
  if it.needs or it.kind == "pet" then return 7 end
  return CAFE.TABKIND[it.kind] or 2
end

function CAFE.rows()                           -- the rows on the tab you're looking at
  local rc = CAFE.rc                           -- (worked out once per frame: scrolling fast stays smooth)
  if rc and rc.frame == frames and rc.tab == CAFE.tab and rc.cur == CAFE.cur then return rc.rows end
  local out = {}
  for _, r in ipairs(CAFE.allRows()) do
    if CAFE.tabOf(r) == CAFE.tab then out[#out + 1] = r end
  end
  CAFE.rc = { frame = frames, tab = CAFE.tab, cur = CAFE.cur, rows = out }
  return out
end

function CAFE.rollSale()                       -- two wall / rug / table / pet things go half price
  local d, pool = CAFE.cur, {}
  if not d then return end
  for _, it in ipairs(CAFE.ITEMS) do
    local tab = CAFE.tabOf({ nil, nil, "buy", 0, it.id })
    if tab >= 3 and d.decor[it.id] == nil and (it.needs == nil or CAFE.hasNeed(d, it.needs)) then
      pool[#pool + 1] = it.id
    end
  end
  local old = CAFE.sale and CAFE.sale.ids or {}
  local fresh = {}
  for _, id in ipairs(pool) do if not old[id] then fresh[#fresh + 1] = id end end
  if #fresh < 2 then fresh = pool end              -- (nearly everything bought: nothing else to pick)
  local ids = {}
  for _ = 1, 2 do
    if #fresh == 0 then break end
    ids[table.remove(fresh, math.random(#fresh))] = true
  end
  CAFE.sale = { ids = ids, nextMs = pd.getCurrentTimeMilliseconds() + (240 + math.random() * 120) * 1000 }
end

function CAFE.allRows()
  if CAFE.sale and pd.getCurrentTimeMilliseconds() >= CAFE.sale.nextMs then CAFE.rollSale() end
  local d = CAFE.cur
  local rows = {}
  if d.seatStep < 5 then
    local cost = math.floor(CAFE.SEAT_COST[d.seatStep + 1] * 100 * CAFE.PRICE + 0.5)
    local nxt = CAFE.SEAT_N[d.seatStep + 1]
    local label = (d.seatStep == 4) and "Corner booth (L-table)" or ("Add a table  " .. CAFE.seatsOf(d.seatStep) .. " > " .. nxt .. " seats")
    if d.seatStep == 0 then
      rows[#rows + 1] = { "Dine-in starting kit", money(cost), "seat", cost, nil, "Comes with 1 table and 2 cups" }
    else
      rows[#rows + 1] = { label, money(cost), "seat", cost, nil, "More seats, bigger tips" }
    end
  else
    rows[#rows + 1] = { "Seats  " .. CAFE.seatsOf(5), "MAX", "none" }
  end
  if d.seatStep == 0 then
    -- (no cups to buy until you have the dine-in starting kit)
  elseif d.cups < 10 then
    local cost = CAFE.CUP_COST[math.max(1, d.cups - 1)] * 100 * CAFE.PRICE
    rows[#rows + 1] = { "More cups  " .. d.cups .. " > " .. (d.cups + 1), money(cost), "cup", cost, nil, "Cups for dine-in drinks" }
  else
    rows[#rows + 1] = { "Cups  " .. d.cups, "MAX", "none" }
  end
  rows[#rows + 1] = { "Cafe sign", d.sign == false and "OFF" or "ON", "sign", 0, nil, "Toggling this allows for more space" }
  for _, it in ipairs(CAFE.ITEMS) do
    if it.needs == nil or CAFE.hasNeed(d, it.needs) then
      local st = d.decor[it.id]
      if st == nil then
        local cost = it.cost * 100 * CAFE.PRICE
        if CAFE.sale and CAFE.sale.ids[it.id] then
          cost = cost // 2
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id], true }
        else
          rows[#rows + 1] = { it.name, money(cost), "buy", cost, it.id, CAFE.DESC[it.id] }
        end
      else
        rows[#rows + 1] = { it.name, st == "on" and "ON" or "OFF", "toggle", 0, it.id, CAFE.DESC[it.id] }
      end
    end
  end
  if d.seatStep >= 1 then
    rows[#rows + 1] = { "Edit table layout", "", "layout", 0, nil, "Move tables, or turn some off" }
  end
  return rows
end

function CAFE.say(str) CAFE.msg, CAFE.msgT = str, 2.4 end

-- put a wall/floor piece on the grid (picking the spot if there's a choice)
function CAFE.putOut(id)
  local d, it = CAFE.cur, CAFE.byId[id]
  if CAFE.isGrid(it) then
    local free = CAFE.freeSlots(d, it.kind, id)
    if #free == 0 then
      d.decor[id] = "off"
      CAFE.say((it.kind == "wall" or it.kind == "tiny") and "Wall's full: turn something off first." or (it.kind == "counter" and "Counter's full: turn something off first." or "Floor's full: turn something off first."))
    elseif #free == 1 then
      d.place[id] = free[1]
      d.decor[id] = "on"
    else
      CAFE.pend, CAFE.spots, CAFE.spotSel = id, free, 1
      d.decor[id] = "off"
      transitionTo(function()
        G = CAFE.stageG()
        CAFE.mode = "place"
      end)
      return
    end
  elseif it.species then                           -- one cat and one dog at a time (the new one takes over)
    for _, o in ipairs(CAFE.ITEMS) do
      if o.species == it.species and d.decor[o.id] == "on" then d.decor[o.id] = "off" end
    end
    d.decor[id] = "on"
  elseif it.kind == "rug" or it.kind == "runner" or it.kind == "cloth" or it.kind == "centerpiece" or it.kind == "frame" or it.kind == "curtain" then        -- one of each kind at a time
    for _, o in ipairs(CAFE.ITEMS) do
      if o.kind == it.kind and d.decor[o.id] == "on" then d.decor[o.id] = "off" end
    end
    d.decor[id] = "on"
  else
    d.decor[id] = "on"
  end
  CAFE.write()
end

function CAFE.buy(row)
  local d = CAFE.cur
  if d.money < row[4] then
    sfxWrong()
    CAFE.say("Not enough money yet.")
    return
  end
  if row[3] == "seat" and d.seatStep < 4 then       -- a table: choose where it goes, pay when it's down
    local used, free = {}, {}
    for k = 1, 4 do if d.tables[k] then used[d.tables[k]] = true end end
    for i = 1, #CAFE.TSLOT do if not used[i] then free[#free + 1] = i end end
    CAFE.pend, CAFE.spots, CAFE.spotSel, CAFE.pendCost = "table", free, 1, row[4]
    transitionTo(function()
      G = CAFE.stageG()
      CAFE.mode = "place"
    end)
    return
  end
  d.money = d.money - row[4]
  local it = CAFE.byId[row[5] or ""]
  d.stars = clamp(d.stars + (it and (it.kind == "pet" and 0.2 or 0.08) or 0.2), 0, 5)    -- upgrades earn stars
  sfxPlay("tip", false, 1.0)
  if row[3] == "cup" then d.cups = d.cups + 1; CAFE.say("Bought!")
  elseif row[3] == "seat" then d.seatStep = d.seatStep + 1; CAFE.say("Bought!")
  else
    d.decor[row[5]] = "off"
    CAFE.say("Bought!")
    CAFE.putOut(row[5])
    return
  end
  CAFE.write()
end

function CAFE.toggle(row)
  local d = CAFE.cur
  if row[3] == "sign" then
    if d.sign == false then
      if CAFE.slotTaken(d, "wall", 2) or CAFE.slotTaken(d, "wall", 3) then
        -- (sign is off, so the slot test is just about the other decor)
      end
      local blocked = false
      for _, it in ipairs(CAFE.ITEMS) do
        if CAFE.gk(it.kind) == "wall" and d.decor[it.id] == "on" and (d.place[it.id] == 2 or d.place[it.id] == 3) then blocked = true end
      end
      if blocked then sfxWrong(); CAFE.say("Take down the wall decor in its spot first."); return end
      d.sign = true
    else
      d.sign = false
    end
    sfxClick()
    CAFE.write()
    return
  end
  local id = row[5]
  if d.decor[id] == "on" then
    d.decor[id] = "off"
    d.place[id] = nil
    sfxClick()
    CAFE.write()
  else
    sfxClick()
    CAFE.putOut(id)
  end
end

-- a stand-in for the cafe with nobody in it (for choosing where things go)
function CAFE.stageG()
  local d = CAFE.cur
  CAFE.applyLayout(d)
  return { mode = "cafe", cafe = d, t = 0, cash = 0, tips = 0, served = 0, missed = 0, total = 0,
           px = -300, moving = false, walk = 0, sel = "down", st = nil, cust = nil,
           cupMax = d.cups, seatLimit = CAFE.seatsOf(d.seatStep), seatOff = CAFE.seatOffOf(d), seatCount = CAFE.seatCountOf(d),
           cups = { shelf = d.cups, dirty = 0, hand = 0 },
           sink = { state = "empty", progress = 0, angle = 0, t = 0 },
           win = WIN.newWindow(), line = {}, others = {}, seats = {}, door = 0, popups = {}, ending = true }
end

function CAFE.spotRect(kind, i)
  if kind == "counter" then
    local sl = CAFE.CSLOT[i]
    return sl[1] - 14, 74, 28, 24
  end
  if kind == "tiny" or kind == "wall" then
    local sl = CAFE.TILES[i]
    return sl[1], sl[2], sl[3], sl[4]
  end
  if kind == "table" then
    local sl = CAFE.TSLOT[i]
    return sl[1] - 27, sl[2] - 19, 54, 38
  end
  local sl = CAFE.FSLOT[i]
  return sl[1] - 16, sl[2] - 18, 32, 36
end

function CAFE.leavePlace(placed)
  local id = CAFE.pend
  if placed then
    local d = CAFE.cur
    if id == "table" then
      d.money = d.money - CAFE.pendCost
      if d.seatStep == 0 then d.cups = math.max(d.cups, 2) end        -- the starting kit comes with two cups
      d.seatStep = d.seatStep + 1
      d.tables[d.seatStep] = CAFE.spots[CAFE.spotSel]
      d.stars = clamp(d.stars + 0.2, 0, 5)
    else
      d.place[id] = CAFE.spots[CAFE.spotSel]
      d.decor[id] = "on"
    end
    CAFE.write()
    sfxPlay("tip", false, 1.0)
  end
  transitionTo(function()
    G = nil
    CAFE.pend = nil
    CAFE.mode = "shop"
  end)
end

-- move a cursor between spots the way the screen looks: left goes to the spot on the left, up to the one above
function CAFE.spatial(pts, cur, dir)           -- pts = list of {x, y} centres; returns the new index (or the same one)
  local cx, cy = pts[cur][1], pts[cur][2]
  local best, bs
  for i, p in ipairs(pts) do
    if i ~= cur then
      local dx, dy = p[1] - cx, p[2] - cy
      local along, across
      if dir == "R" then along, across = dx, math.abs(dy)
      elseif dir == "L" then along, across = -dx, math.abs(dy)
      elseif dir == "D" then along, across = dy, math.abs(dx)
      else along, across = -dy, math.abs(dx) end
      if along > 2 then
        local sc = along + across * 2.5
        if bs == nil or sc < bs then best, bs = i, sc end
      end
    end
  end
  return best or cur
end

function CAFE.spotPts(kind, list)
  local pts = {}
  for i, sl in ipairs(list) do
    local x, y, w, h = CAFE.spotRect(kind, sl)
    pts[i] = { x + w / 2, y + h / 2 }
  end
  return pts
end

-- ---- the door: turn the sign from CLOSED to OPEN with the crank, then the cafe opens --------------------
CAFE.GREETS = { "Welcome back!", "Hope your day is good!", "Have a good day!", "Coffee heads welcome!",
                "Good to see you again!", "Rise and grind!", "Fresh beans, fresh start!", "Your cafe missed you!",
                "Another day, another cup!", "Let's brew something great!", "Smells like a good day!", "Glad you're here!" }

function CAFE.openDoor()
  CAFE.keep = nil
  CAFE.sale = CAFE.sale and { ids = {}, nextMs = 0 } or nil
  CAFE.rollSale()
  CAFE.door = { p = 0, done = 0, tick = 0 }
  crankHelpStart()
  CAFE.greet, CAFE.greetF, CAFE.report = CAFE.GREETS[math.random(#CAFE.GREETS)], nil, nil
  transitionTo(function()
    G = { win = WIN.newWindow() }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.closeDoor()                      -- Save & quit: the door shows OPEN, flips to CLOSED, then the title
  transitionTo(function()
    if G and G.mode then closeStation() end
    CAFE.keep = nil
    setShiftMenu(false, false)
    G = { win = WIN.newWindow() }
    CAFE.door = { p = 1, done = 0, tick = 0, closing = true, hold = 0 }
    G.win.walkIn, G.win.gap, G.win.gapSpan = 1.5, 5, 7
    CAFE.mode = "door"
    state = CAFE.STATE
  end)
end

function CAFE.signFace(open)                   -- the hanging sign, drawn once for each side
  CAFE.signImgs = CAFE.signImgs or {}
  local k = open and "open" or "closed"
  if not CAFE.signImgs[k] then
    local W, H = 164, 56
    local word = open and "OPEN" or "CLOSED"
    local t = gfx.image.new(60, 20, gfx.kColorClear)       -- the word, drawn small then blown up 2x
    gfx.pushContext(t)
    gfx.setColor(BLACK)
    gfx.setFont(fontBold)
    gfx.drawTextAligned(word, 30, 1, kTextAlignment.center)
    gfx.popContext()
    local im = gfx.image.new(W, H, gfx.kColorClear)
    gfx.pushContext(im)
    gfx.setColor(WHITE)
    gfx.fillRoundRect(0, 0, W, H, 9)
    gfx.setColor(BLACK)
    gfx.setLineWidth(3)
    gfx.drawRoundRect(1, 1, W - 2, H - 2, 9)
    gfx.setLineWidth(1)
    gfx.drawRoundRect(6, 6, W - 12, H - 12, 5)
    local tw = (word == "OPEN") and 2.4 or 2
    local x0, y0 = math.floor(W / 2 - 30 * tw), math.floor(H / 2 - 10 * tw)
    t:drawScaled(x0, y0, tw, tw)
    t:drawScaled(x0 + 1, y0, tw, tw)                       -- drawn twice, a pixel apart: chunkier letters
    gfx.popContext()
    CAFE.signImgs[k] = im
  end
  return CAFE.signImgs[k]
end

function CAFE.doorUpdate(dt, B_)
  local dr = CAFE.door
  WIN.updateWindow(dt)
  if dr.closing then                                    -- it turns itself over, then back to the title
    if dr.done > 0 then
      dr.done = dr.done - dt
      if dr.done <= 0 then
        dr.done = -1
        transitionTo(function() G = nil; state = STATE_MENU end)
      end
    elseif dr.done == 0 then
      dr.hold = dr.hold + dt
      if dr.hold > 0.7 then
        dr.p = math.max(0, dr.p - dt * 0.7)
        if dr.p <= 0 then dr.done = 1.0 end                  -- (no sounds on this screen)
      end
    end
    return
  end
  if dr.done > 0 then
    dr.done = dr.done - dt
    if dr.done <= 0 then dr.done = -1; CAFE.begin() end
    return
  elseif dr.done < 0 then return end
  if B_ then
    sfxClick()
    transitionTo(function() G = nil; CAFE.mode = "slots" end)
    return
  end
  local before = dr.p
  dr.p = dr.p + pd.getCrankChange() / 200                -- about half a turn flips the sign
  if pd.buttonIsPressed(pd.kButtonRight) or pd.buttonIsPressed(pd.kButtonA) then dr.p = dr.p + dt * 0.6 end
  if pd.buttonIsPressed(pd.kButtonLeft) then dr.p = dr.p - dt * 0.6 end
  dr.p = clamp(dr.p, 0, 1)
  if math.floor(dr.p * 12) ~= math.floor(before * 12) then sfxClick() end
  if dr.p >= 1 then
    sfxPlay("bell", false, 1.0)
    dr.done = 1.0
  end
end

function CAFE.doorDraw()
  local dr = CAFE.door
  gfx.setColor(BLACK)
  gfx.setPattern(CHECK)
  gfx.fillRect(0, 0, 400, 240)                          -- the wall either side
  gfx.setColor(BLACK)
  gfx.fillRect(92, 0, 216, 240)                         -- the door frame
  gfx.setColor(WHITE)
  gfx.fillRect(98, 0, 204, 240)                         -- the door
  gfx.setColor(BLACK)
  gfx.fillRect(98, 0, 204, 6)
  -- the window in the door: the same view as the one in the cafe, bigger
  gfx.fillRect(118, 14, 164, 82)
  gfx.setColor(WHITE)
  gfx.fillRect(122, 20, 156, 72)
  WIN.drawView(G.win, 122, 20, 3)
  gfx.setColor(BLACK)
  gfx.setLineWidth(3)
  gfx.drawLine(200, 20, 200, 92)
  gfx.drawLine(122, 56, 278, 56)
  gfx.setLineWidth(1)
  -- door panels, and the handle
  gfx.setLineWidth(2)
  gfx.drawRoundRect(114, 172, 76, 58, 4)
  gfx.drawRoundRect(210, 172, 76, 58, 4)
  gfx.setLineWidth(1)
  gfx.fillCircleAtPoint(286, 150, 6)
  gfx.setColor(WHITE)
  gfx.fillCircleAtPoint(286, 150, 2)
  -- the sign hangs on the glass and flips over
  gfx.setColor(BLACK)
  gfx.fillCircleAtPoint(200, 100, 3)
  gfx.drawLine(200, 100, 200, 108)
  local ease = dr.p * dr.p * (3 - 2 * dr.p)
  local ang = ease * math.pi
  local sx = math.abs(math.cos(ang))
  if sx < 0.05 then
    gfx.fillRect(199, 108, 3, 56)
  else
    local im = CAFE.signFace(ang >= math.pi / 2)
    im:drawScaled(math.floor(200 - 82 * sx), 108, sx, 1)
  end
  gfx.setColor(BLACK)
  if not dr.closing and dr.p < 0.5 and dr.done == 0 then       -- the reminder: spin the crank
    local label = "Spin the crank!"
    gfx.setFont(fontBold)
    local bw = gfx.getTextSize(label) + 58
    local bx, by = 200 - bw // 2, 188
    gfx.setColor(WHITE)
    gfx.fillRoundRect(bx, by, bw, 36, 10)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(bx, by, bw, 36, 10)
    gfx.setLineWidth(1)
    local ix, iy = bx + 22, by + 18                              -- a little crank, turning round
    local a = frames * 0.18
    gfx.drawCircleAtPoint(ix, iy, 7)
    gfx.setLineWidth(3)
    gfx.drawLine(ix, iy, math.floor(ix + math.cos(a) * 11), math.floor(iy + math.sin(a) * 11))
    gfx.setLineWidth(1)
    gfx.fillCircleAtPoint(math.floor(ix + math.cos(a) * 12), math.floor(iy + math.sin(a) * 12), 3)
    gfx.fillCircleAtPoint(ix, iy, 2)
    drawT(label, bx + 40, by + 9, true)
    crankHelpDraw()                                              -- (and the system's own crank picture, if the crank is tucked in)
  end
end

-- ---- the table layout editor: pick a table up, then put it down on any empty square ------------------
function CAFE.tableAtSlot(d, i)                -- which of your tables stands on square i (or nil)
  for k = 1, math.min(d.seatStep, 4) do
    if d.tables[k] == i and not d.off[k] then return k end
  end
  return nil
end

function CAFE.tablesInHand(d)
  local n = 0
  for k = 1, math.min(d.seatStep, 4) do if d.off[k] then n = n + 1 end end
  return n
end

function CAFE.openLayout()
  local d = CAFE.cur
  for k = 1, math.min(d.seatStep, 4) do          -- (a table that was switched off is simply one in your hand)
    if d.off[k] then d.tables[k] = 0 end
  end
  CAFE.lay, CAFE.grab = d.tables[1] and d.tables[1] > 0 and d.tables[1] or 1, false
  transitionTo(function()
    G = CAFE.stageG()
    CAFE.mode = "layout"
  end)
end

function CAFE.layoutRefresh()                  -- the floor picture is drawn once, so redo it after a change
  local d = CAFE.cur
  CAFE.applyLayout(d)
  G.floorImg = nil
  G.seatOff, G.seatCount = CAFE.seatOffOf(d), CAFE.seatCountOf(d)
end

function CAFE.layoutUpdate(L, R, U, D, A_, B_)
  local d = CAFE.cur
  local n = math.min(d.seatStep, 4)
  if n < 1 then B_ = true end
  local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
  if dir then
    local all = {}
    for i = 1, #CAFE.TSLOT do all[i] = i end
    local nat = CAFE.spatial(CAFE.spotPts("table", all), CAFE.lay, dir)
    if nat ~= CAFE.lay then CAFE.lay = nat; sfxClick() end
  elseif A_ then
    local k = CAFE.tableAtSlot(d, CAFE.lay)
    if k then                                   -- a table: it goes into your hand
      d.tables[k] = 0; d.off[k] = true
      CAFE.layoutRefresh(); sfxClick()
    else                                        -- an empty square: put a table from your hand down
      local hk
      for j = 1, n do if d.off[j] then hk = j; break end end
      if hk then
        d.tables[hk] = CAFE.lay; d.off[hk] = nil
        CAFE.layoutRefresh(); sfxPlay("tip", false, 1.0)
      else
        sfxWrong(); CAFE.say("No tables in your hand. Pick one up first.")
      end
    end
  elseif B_ then
    CAFE.write()
    transitionTo(function()
      G = nil
      CAFE.mode = "shop"
      CAFE.rc = nil
    end)
  end
end

function CAFE.layoutDraw()
  local d = CAFE.cur
  drawWall()
  drawCounter()
  drawFloor()
  UI.drawDoor()
  for i = 1, #CAFE.TSLOT do
    local x, y, w, h = CAFE.spotRect("table", i)
    local sel = (i == CAFE.lay)
    if not CAFE.tableAtSlot(d, i) then            -- a clear box round every empty square
      gfx.setColor(WHITE)
      gfx.fillRoundRect(x, y, w, h, 5)
      gfx.setColor(BLACK)
      gfx.setLineWidth(sel and 3 or 2)
      gfx.drawRoundRect(x, y, w, h, 5)
      gfx.setLineWidth(1)
      if CAFE.tablesInHand(d) > 0 then drawTC("+", x + w // 2, y + h // 2 - 8, true) end
    elseif sel then
      gfx.setColor(BLACK)
      gfx.setLineWidth(3)
      gfx.drawRoundRect(x - 2, y - 2, w + 4, h + 4, 6)
      gfx.setLineWidth(1)
    end
  end
  local x, y, w, h = CAFE.spotRect("table", CAFE.lay)
  CAFE.pointer(x + w // 2 + 4, y + h // 2 - 2)         -- the mouse arrow rests on the chosen square
  gfx.setColor(WHITE)
  local label = "Tables in hand: " .. CAFE.tablesInHand(d)
  gfx.setFont(fontBold)
  local bw = gfx.getTextSize(label) + 28                       -- the bubble hugs the words
  gfx.fillRoundRect(200 - bw // 2, 100, bw, 24, 6)
  gfx.setColor(BLACK)
  gfx.drawRoundRect(200 - bw // 2, 100, bw, 24, 6)
  drawTC(label, 200, 104, true)
  if CAFE.msg then
    gfx.setColor(WHITE)
    gfx.fillRoundRect(30, 130, 340, 22, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(30, 130, 340, 22, 6)
    drawTC(CAFE.msg, 200, 133, true)
  end
end

-- ---- screens -------------------------------------------------------------------------------------------
function CAFE.update(dt)
  do                                           -- the tab strip slides to the chosen tab (the short way round)
    local n = #CAFE.TABS
    local dl = (CAFE.tab - CAFE.tabPos + n / 2) % n - n / 2
    if math.abs(dl) < 0.02 then CAFE.tabPos = CAFE.tab else CAFE.tabPos = (CAFE.tabPos + dl * math.min(1, dt * 12) - 1) % n + 1 end
  end
  if CAFE.msgT > 0 then CAFE.msgT = CAFE.msgT - dt; if CAFE.msgT <= 0 then CAFE.msg = nil end end
  local A_, B_ = pd.buttonJustPressed(pd.kButtonA), pd.buttonJustPressed(pd.kButtonB)
  local U, D = pd.buttonJustPressed(pd.kButtonUp), pd.buttonJustPressed(pd.kButtonDown)
  local L, R = pd.buttonJustPressed(pd.kButtonLeft), pd.buttonJustPressed(pd.kButtonRight)
  if CAFE.mode == "slots" then
    if CAFE.erase then
      if A_ then
        pcall(pd.datastore.delete, "cafe" .. CAFE.erase)
        CAFE.slots[CAFE.erase] = nil
        CAFE.erase = nil
        sfxClick()
      elseif B_ then CAFE.erase = nil; sfxClick() end
      return
    end
    if D then CAFE.sel = CAFE.sel % 3 + 1; sfxClick()
    elseif U then CAFE.sel = (CAFE.sel + 1) % 3 + 1; sfxClick()
    elseif R and CAFE.slots[CAFE.sel] then CAFE.erase = CAFE.sel; sfxClick()
    elseif B_ then CAFE.goTitle()
    elseif A_ then
      sfxClick()
      local i = CAFE.sel
      CAFE.slot = i
      if CAFE.slots[i] then
        CAFE.cur = CAFE.slots[i]
        CAFE.openDoor()
      else
        transitionTo(function() CAFE.mode, CAFE.name, CAFE.letter, CAFE.onDone = "name", "", 0, false end)
      end
    end
  elseif CAFE.mode == "name" then
    if CAFE.onDone then
      if L or U or B_ then CAFE.onDone = false; sfxClick()
      elseif A_ then
        local nm = CAFE.name:gsub("%s+$", "")
        if #nm >= 1 then
          CAFE.cur = CAFE.fresh(nm)
          CAFE.write()
          CAFE.openDoor()
        else
          sfxWrong()
          CAFE.onDone = false
        end
      end
      return
    end
    CAFE.crank = CAFE.crank + pd.getCrankChange()
    local step = 0                                         -- only the crank turns the wheel: A-Z, then the word CAFE, then a space
    while CAFE.crank >= 24 do CAFE.crank = CAFE.crank - 24; step = step + 1 end
    while CAFE.crank <= -24 do CAFE.crank = CAFE.crank + 24; step = step - 1 end
    if L then step = step - 1 elseif R then step = step + 1 end         -- left / right turn the wheel too, if you'd rather not crank
    if step ~= 0 then CAFE.letter = (CAFE.letter + step) % 28; sfxClick() end
    if D then
      CAFE.onDone = true                                   -- down: on to the DONE button below
      sfxClick()
    elseif A_ then
      local nm = CAFE.name
      if CAFE.letter == 26 then                            -- the word
        local add = (#nm > 0 and string.sub(nm, -1) ~= " ") and " CAFE" or "CAFE"
        if #nm + #add <= 14 then CAFE.name = nm .. add; sfxClick() else sfxWrong() end
      elseif #nm < 14 then
        local ch = (CAFE.letter == 27) and " " or string.char(65 + CAFE.letter)
        if not (ch == " " and #nm == 0) then CAFE.name = nm .. ch; sfxClick() else sfxWrong() end
      else
        sfxWrong()
      end
    elseif B_ then
      if #CAFE.name > 0 then
        CAFE.name = CAFE.name:sub(1, -2)
        sfxClick()
      else
        sfxClick()
        transitionTo(function() CAFE.mode = "slots" end)
      end
    end
  elseif CAFE.mode == "door" then
    CAFE.doorUpdate(dt, B_)
  elseif CAFE.mode == "layout" then
    CAFE.layoutUpdate(L, R, U, D, A_, B_)
  elseif CAFE.mode == "place" then
    local dir = (R and "R") or (L and "L") or (D and "D") or (U and "U") or nil
    if dir then
      local kind = (CAFE.byId[CAFE.pend] or { kind = "table" }).kind
      local nsel = CAFE.spatial(CAFE.spotPts(kind, CAFE.spots), CAFE.spotSel, dir)
      if nsel ~= CAFE.spotSel then CAFE.spotSel = nsel; sfxClick() end
    elseif A_ then CAFE.leavePlace(true)
    elseif B_ then CAFE.leavePlace(false) end
  else   -- shop
    local rows = CAFE.rows()
    local n = #rows
    -- the crank scrolls too: every 70 degrees is one step
    CAFE.crankAcc = CAFE.crankAcc + pd.getCrankChange()
    local step = 0
    if CAFE.crankAcc >= 70 then CAFE.crankAcc = CAFE.crankAcc - 70; step = 1
    elseif CAFE.crankAcc <= -70 then CAFE.crankAcc = CAFE.crankAcc + 70; step = -1 end
    if D then step = 1 elseif U then step = -1 end
    local function click() if frames - (CAFE.lastClick or -9) >= 3 then CAFE.lastClick = frames; sfxClick() end end
    local function turn(t)                                              -- switch tabs; the pointer goes back up to them
      CAFE.tab = t; CAFE.shopSel, CAFE.scroll, CAFE.focus = 1, 0, "tabs"
      CAFE.rc = nil
      click()
    end
    if B_ then                                                          -- B hops between the list and the Back to cafe button
      CAFE.focus = (CAFE.focus == "back" or CAFE.focus == "quit") and "list" or "back"
      if CAFE.focus == "list" then CAFE.shopSel = math.max(1, math.min(CAFE.shopSel, n)) end
      sfxClick()
    elseif CAFE.focus == "tabs" or CAFE.focus == "list" then
      if L then turn((CAFE.tab - 2) % #CAFE.TABS + 1)                   -- the tabs wrap around
      elseif R then turn(CAFE.tab % #CAFE.TABS + 1)
      elseif CAFE.focus == "tabs" then
        if step == 1 then CAFE.focus, CAFE.shopSel = "list", 1; click() end
      else
        if step == 1 then
          if CAFE.shopSel < n then CAFE.shopSel = CAFE.shopSel + 1; click()
          else CAFE.focus = "back"; click() end                         -- on down to the buttons
        elseif step == -1 then
          if CAFE.shopSel > 1 then CAFE.shopSel = CAFE.shopSel - 1; click()
          else CAFE.focus = "tabs"; click() end                         -- back up to the tabs
        elseif A_ then
          local row = rows[CAFE.shopSel]
          local k = row[3]
          if k == "cup" or k == "seat" or k == "buy" then CAFE.buy(row)
          elseif k == "toggle" or k == "sign" then CAFE.toggle(row)
          elseif k == "layout" then CAFE.openLayout()
          else sfxWrong() end
        end
      end
    else                                                                -- the two buttons in the bottom bar
      if step == -1 then CAFE.focus = "list"; CAFE.shopSel = math.max(1, n); click()
      elseif L and CAFE.focus == "quit" then CAFE.focus = "back"; sfxClick()
      elseif R and CAFE.focus == "back" then CAFE.focus = "quit"; sfxClick()
      elseif A_ then
        CAFE.write()
        if CAFE.focus == "back" then sfxClick(); CAFE.begin()
        else CAFE.closeDoor() end
      end
    end
    -- keep the highlighted row in view (7 rows fit)
    if CAFE.shopSel <= CAFE.scroll then CAFE.scroll = CAFE.shopSel - 1 end
    if CAFE.shopSel > CAFE.scroll + 7 then CAFE.scroll = CAFE.shopSel - 7 end
    if CAFE.scroll < 0 then CAFE.scroll = 0 end
  end
end

function CAFE.band(title)
  gfx.setColor(BLACK)
  gfx.fillRoundRect(12, 12, 376, 22, 6)
  gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
  drawTC(title, 200, 14, true)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  gfx.setColor(BLACK)
end

-- a little box showing the highlighted item, inside a wobbly animated border
function CAFE.pointer(mx, my)                  -- a little mouse arrow, bobbing
  mx = math.floor(mx) + math.floor(math.sin(frames * 0.15) * 2 + 0.5)
  my = math.floor(my) + math.floor(math.sin(frames * 0.15 + 1) * 1.5 + 0.5)
  gfx.setColor(WHITE)
  gfx.fillPolygon(mx, my, mx, my + 13, mx + 3, my + 10, mx + 6, my + 15, mx + 8, my + 14, mx + 5, my + 9, mx + 9, my + 9)
  gfx.setColor(BLACK)
  gfx.drawLine(mx, my, mx, my + 13); gfx.drawLine(mx, my + 13, mx + 3, my + 10)
  gfx.drawLine(mx + 3, my + 10, mx + 6, my + 15); gfx.drawLine(mx + 6, my + 15, mx + 8, my + 14)
  gfx.drawLine(mx + 8, my + 14, mx + 5, my + 9); gfx.drawLine(mx + 5, my + 9, mx + 9, my + 9)
  gfx.drawLine(mx + 9, my + 9, mx, my)
end

function CAFE.drawPreview(row)
  if row == nil or row[3] == "start" or row[3] == "quit" or row[3] == "none" then return end
  local id = row[5]
  if row[3] == "seat" then id = "table" end
  local art = id and CAFE.art[id]
  local bx, by, bw, bh = 298, 68, 92, 70
  gfx.setColor(WHITE)
  gfx.fillRoundRect(bx, by, bw, bh, 8)
  gfx.setColor(BLACK)
  -- squiggly border: points on the rectangle edge pushed in/out by a moving sine
  local t = frames * 0.25
  local pts = {}
  local per = 2 * (bw + bh)
  local n = 40
  for i = 0, n do
    local d = per * i / n
    local x, y, nx, ny
    if d < bw then x, y, nx, ny = bx + d, by, 0, -1
    elseif d < bw + bh then x, y, nx, ny = bx + bw, by + (d - bw), 1, 0
    elseif d < 2 * bw + bh then x, y, nx, ny = bx + bw - (d - bw - bh), by + bh, 0, 1
    else x, y, nx, ny = bx, by + bh - (d - 2 * bw - bh), -1, 0 end
    local o = math.sin(i * 1.3 + t) * 1.8
    pts[#pts + 1] = { x + nx * o, y + ny * o }
  end
  gfx.setLineWidth(2)
  for i = 1, #pts - 1 do gfx.drawLine(pts[i][1], pts[i][2], pts[i + 1][1], pts[i + 1][2]) end
  gfx.drawLine(pts[#pts][1], pts[#pts][2], pts[1][1], pts[1][2])
  gfx.setLineWidth(1)
  gfx.setClipRect(bx + 4, by + 4, bw - 8, bh - 8)
  local cx, cy = bx + bw // 2, by + bh // 2 + 2
  local it = id and CAFE.byId[id]
  local function drawAs(fn, ox, oy)             -- run a "draw what's owned" routine as if only this id were on
    local save, saveG = CAFE.decorOn, G
    CAFE.decorOn = function(q) return q == id end
    G = { mode = "cafe", cafe = { decor = { [id] = "on" } } }
    gfx.setDrawOffset(ox, oy)
    pcall(fn)
    gfx.setDrawOffset(0, 0)
    G = saveG
    CAFE.decorOn = save
  end
  if it and it.kind == "runner" then
    local h = bh - 22                            -- shrunk to fit the box, whole
    local w = math.floor(h * 36 / 118 + 0.5)
    CAFE.runnerAt(id, cx - w // 2, by + 8, w, h)
  elseif it and it.kind == "rug" then
    local w = bw - 16                            -- shrunk to fit the box, whole
    local h = math.floor(w * 44 / 190 + 0.5) + 4
    CAFE.rugAt(id, cx - w // 2, by + 10 + (bh - 22 - h) // 2, w, h)
  elseif it and it.kind == "shelf" then
    drawAs(CAFE.drawVines, cx - (id == "ivy" and 104 or 188), by + 10 - 43)
  elseif it and it.kind == "ceiling" then
    gfx.setColor(BLACK)                          -- (the real lights are white on the dark wall)
    local prev
    for x = bx + 4, bx + bw - 4, 3 do
      local y = cy - 6 + math.floor(4 * math.sin(math.pi * (x % 30) / 30) + 0.5)
      if prev then gfx.drawLine(prev[1], prev[2], x, y) end
      prev = { x, y }
    end
    for i = 0, 3 do
      local x, lit = bx + 12 + i * 22, ((i + frames // 24) % 2 == 0)
      local y = cy - 2
      if lit then gfx.fillCircleAtPoint(x, y, 4) else gfx.drawCircleAtPoint(x, y, 3) end
    end
  elseif it and it.kind == "cloth" then
    CAFE.tableAt(cx, cy, 22, id, nil, 2)
  elseif it and it.kind == "centerpiece" then
    CAFE.tableAt(cx, cy, 22, nil, id, 2)
  elseif it and it.species then                   -- pets: drawn small, then blown up so you can see the coat
    CAFE.petPrev = CAFE.petPrev or {}
    local im = CAFE.petPrev[id]
    if im == nil then im = gfx.image.new(50, 36, gfx.kColorClear); CAFE.petPrev[id] = im end
    im:clear(gfx.kColorClear)
    gfx.pushContext(im)
    CAFE.pet(it.species, 25, 32, 1, "sit", id)
    gfx.popContext()
    gfx.setClipRect(bx + 1, by + 1, bw - 2, bh - 2)
    im:drawScaled(cx - 50, cy - 38, 2, 2)
  elseif row[3] == "sign" then                    -- the sign you actually have, name and all
    gfx.setColor(WHITE)
    gfx.fillRect(cx - 38, cy - 14, 76, 28)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRect(cx - 38, cy - 14, 76, 28)
    gfx.setLineWidth(1)
    CAFE.fitText(CAFE.cur.name, cx, cy, 66, 18)
  elseif art then
    art(cx, cy)
  else
    local label = (row[3] == "cup") and "CUPS" or (row[3] == "sign") and "SIGN" or ""
    gfx.setColor(BLACK)
    if label ~= "" then drawTC(label, cx, cy - 8, true) end
  end
  gfx.clearClipRect()
  gfx.setColor(BLACK)
  if row[2] ~= "" then drawTC(row[2], bx + bw // 2, by + bh + 6, true) end   -- the price, always in view
  if row[6] then                                  -- a few words under it, wrapped to the box
    gfx.setFont(fontNormal or gfx.getSystemFont())
    local line, ly = "", by + bh + 24
    local function flush() if line ~= "" then drawTC(line, bx + bw // 2, ly); ly = ly + 14; line = "" end end
    for word in string.gmatch(row[6], "%S+") do
      local try = (line == "") and word or (line .. " " .. word)
      if gfx.getTextSize(try) > bw + 12 then flush(); line = word else line = try end
    end
    flush()
  end
end

function CAFE.draw()
  if CAFE.mode == "door" then CAFE.doorDraw(); return end
  if CAFE.mode == "layout" then CAFE.layoutDraw(); return end
  if CAFE.mode == "place" then
    drawWall()
    drawCounter()
    drawFloor()
    UI.drawDoor()
    local it = CAFE.byId[CAFE.pend] or { kind = "table", name = "table" }
    for i, sp in ipairs(CAFE.spots) do
      local x, y, w, h = CAFE.spotRect(it.kind, i == CAFE.spotSel and sp or sp)
      x, y, w, h = CAFE.spotRect(it.kind, sp)
      if i == CAFE.spotSel then
        gfx.setColor(WHITE)
        gfx.fillRoundRect(x, y, w, h, 4)
        gfx.setColor(BLACK)
        gfx.setLineWidth(2)
        gfx.drawRoundRect(x, y, w, h, 4)
        gfx.setLineWidth(1)
        CAFE.art[CAFE.byId[CAFE.pend] and CAFE.pend or "table"](x + w // 2, y + h // 2)
      else
        gfx.setColor(WHITE)
        for xx = x, x + w - 4, 6 do gfx.drawLine(xx, y, xx + 2, y); gfx.drawLine(xx, y + h, xx + 2, y + h) end
        for yy = y, y + h - 4, 6 do gfx.drawLine(x, yy, x, yy + 2); gfx.drawLine(x + w, yy, x + w, yy + 2) end
        gfx.setColor(BLACK)
        for xx = x + 1, x + w - 4, 6 do gfx.drawLine(xx, y + 1, xx + 2, y + 1); gfx.drawLine(xx, y + h - 1, xx + 2, y + h - 1) end
        for yy = y + 1, y + h - 4, 6 do gfx.drawLine(x + 1, yy, x + 1, yy + 2); gfx.drawLine(x + w - 1, yy, x + w - 1, yy + 2) end
      end
    end
    gfx.setColor(WHITE)
    local by = (it.kind == "table") and 114 or 196              -- keep the box off the spots
    gfx.fillRoundRect(60, by, 280, 36, 6)
    gfx.setColor(BLACK)
    gfx.drawRoundRect(60, by, 280, 36, 6)
    drawTC("Where should the " .. it.name .. " go?", 200, by + 2, true)
    drawTC("D-pad: choose    A: place    B: cancel", 200, by + 18)
    return
  end
  if CAFE.mode == "slots" then
    UI.beanFrame()
    CAFE.band("CAFE  -  CHOOSE A SAVE")
    for i = 1, 3 do
      local y = 42 + (i - 1) * 50
      local d = CAFE.slots[i]
      gfx.setColor(BLACK)
      if CAFE.sel == i then
        gfx.fillRoundRect(60, y, 280, 44, 8)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.setLineWidth(2)
        gfx.drawRoundRect(60, y, 280, 44, 8)
        gfx.setLineWidth(1)
      end
      local col = (CAFE.sel == i) and WHITE or BLACK
      drawT(tostring(i), 70, y + 13, true)
      if d then
        drawT(d.name, 88, y + 4, true)
        drawT(string.format("%s  %d cups  %d seats", money(d.money), d.cups, CAFE.seatsOf(d.seatStep)), 88, y + 24)
        gfx.setImageDrawMode(gfx.kDrawModeCopy)
        CAFE.drawStars(280, y + 12, 4, 10, d.stars, col)
      else
        drawT("NEW CAFE", 88, y + 13, true)
      end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
    end
    drawTC("B: back      Right: erase", 200, 208)
    if CAFE.erase then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(60, 80, 280, 70, 8)
      gfx.setColor(BLACK)
      gfx.setLineWidth(2)
      gfx.drawRoundRect(60, 80, 280, 70, 8)
      gfx.setLineWidth(1)
      drawTC("Erase " .. CAFE.slots[CAFE.erase].name .. "?", 200, 92, true)
      drawTC("A: erase it     B: keep it", 200, 118)
    end
  elseif CAFE.mode == "name" then
    UI.beanFrame()
    CAFE.band("NAME YOUR CAFE")
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(64, 42, 272, 38, 8)
    gfx.setLineWidth(1)
    gfx.setFont(fontBold)
    local w = gfx.getTextSize(CAFE.name)
    local x0 = 200 - (w + 10) // 2
    drawT(CAFE.name, x0, 52, true)
    if (frames // 10) % 2 == 0 and #CAFE.name < 14 then gfx.fillRect(x0 + w + 2, 70, 9, 3) end
    -- the letter wheel (A-Z, the word CAFE, a space), then DONE below it
    local lc = (CAFE.letter == 26) and "CAFE" or ((CAFE.letter == 27) and "space" or string.char(65 + CAFE.letter))
    gfx.setColor(BLACK)
    gfx.fillTriangle(188, 92, 212, 92, 200, 85)
    local dialOn = not CAFE.onDone
    if not dialOn then gfx.setLineWidth(2); gfx.drawRoundRect(150, 96, 100, 36, 8); gfx.setLineWidth(1)
    else gfx.fillRoundRect(150, 96, 100, 36, 8) end
    gfx.setImageDrawMode(dialOn and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC(lc, 200, 106, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)
    gfx.fillTriangle(188, 136, 212, 136, 200, 143)
    if CAFE.onDone then gfx.fillRoundRect(150, 152, 100, 28, 8) else gfx.setLineWidth(2); gfx.drawRoundRect(150, 152, 100, 28, 8); gfx.setLineWidth(1) end
    gfx.setImageDrawMode(CAFE.onDone and gfx.kDrawModeFillWhite or gfx.kDrawModeCopy)
    drawTC("DONE", 200, 158, true)
    gfx.setImageDrawMode(gfx.kDrawModeCopy)
    gfx.setColor(BLACK)

  else
    -- the shop is a web page: address bar on top, tabs, a list of links, a bar of buttons below
    gfx.setColor(WHITE)
    gfx.fillRoundRect(8, 4, 384, 24, 12)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(8, 4, 384, 24, 12)
    gfx.setLineWidth(1)
    -- back / forward arrows
    gfx.fillTriangle(30, 16, 38, 10, 38, 22)
    gfx.fillTriangle(54, 16, 46, 10, 46, 22)
    gfx.setLineWidth(2)                                    -- refresh: a circle of arrow
    for a = 40, 320, 20 do
      local r1, r2 = math.rad(a), math.rad(a + 20)
      gfx.drawLine(math.floor(72 + math.cos(r1) * 6 + 0.5), math.floor(16 + math.sin(r1) * 6 + 0.5),
                   math.floor(72 + math.cos(r2) * 6 + 0.5), math.floor(16 + math.sin(r2) * 6 + 0.5))
    end
    gfx.setLineWidth(1)
    gfx.fillTriangle(72 + 6, 16 - 7, 72 + 6, 16 + 1, 72 + 13, 16 - 2)
    gfx.drawCircleAtPoint(98, 16, 7)                       -- globe
    gfx.drawEllipseInRect(95, 9, 6, 14)
    gfx.drawLine(91, 16, 105, 16)
    do                                                     -- the address, cut off with "..." if it can't all fit in the bar
      gfx.setFont(fontNormal)
      local url = "https://www.coffeesupply.com/" .. CAFE.TABPATH[CAFE.tab]
      local maxW = 262
      if gfx.getTextSize(url) > maxW then
        while #url > 4 and gfx.getTextSize(url .. "...") > maxW do url = string.sub(url, 1, #url - 1) end
        url = url .. "..."
      end
      drawT(url, 112, 8)
    end
    gfx.setColor(BLACK)
    local top = CAFE.report
    if CAFE.greet then                                      -- a friendly line when you first get to the shop
      CAFE.greetF = CAFE.greetF or frames
      if frames - CAFE.greetF < 150 then top = CAFE.greet else CAFE.greet = nil end
    end
    if top then drawTC(top, 200, 30, true) end
    -- the tabs: a strip that slides round, kept to the left of the preview picture
    gfx.setClipRect(8, 45, 280, 21)
    do
      local n = #CAFE.TABS
      for ti, name in ipairs(CAFE.TABS) do
        local dd = (ti - CAFE.tabPos + n / 2) % n - n / 2         -- -3 .. 3 tabs away from the middle
        local tx = math.floor(148 + dd * 76 - 36)
        if tx > -80 and tx < 300 then
          gfx.setColor(BLACK)
          local on = (ti == CAFE.tab)
          if on then
            gfx.fillRoundRect(tx, 47, 72, 17, 5)
            gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
          else
            gfx.drawRoundRect(tx, 47, 72, 17, 5)
          end
          drawTC(name, tx + 36, 48, on)
          gfx.setImageDrawMode(gfx.kDrawModeCopy)
        end
      end
    end
    gfx.clearClipRect()
    gfx.setColor(BLACK)
    if CAFE.focus == "tabs" then CAFE.pointer(148 + 16, 51) end             -- the mouse rests on the chosen tab
    -- the bar along the bottom: stars on the left, two buttons, money on the right
    gfx.setColor(WHITE)
    gfx.fillRoundRect(8, 212, 384, 24, 12)
    gfx.setColor(BLACK)
    gfx.setLineWidth(2)
    gfx.drawRoundRect(8, 212, 384, 24, 12)
    gfx.setLineWidth(1)
    CAFE.drawStars(26, 224, 5, 11, CAFE.cur.stars, BLACK)
    for bi, bn in ipairs({ { "back", "Back to cafe", 82, 112 }, { "quit", "Save & quit", 198, 102 } }) do
      gfx.setColor(BLACK)
      local on = (CAFE.focus == bn[1])
      if on then
        gfx.fillRoundRect(bn[3], 215, bn[4], 18, 6)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(bn[3], 215, bn[4], 18, 6)
      end
      drawTC(bn[2], bn[3] + bn[4] // 2 + 1, 216)
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if on then CAFE.pointer(bn[3] + bn[4] - 12, 225) end
    end
    gfx.setColor(BLACK)
    drawTR(money(CAFE.cur.money), 381, 217, true)
    local rows = CAFE.rows()
    for vi = 1, 7 do
      local i = CAFE.scroll + vi
      local row = rows[i]
      if row == nil then break end
      local y = 68 + (vi - 1) * 20
      gfx.setColor(BLACK)
      local sel = (CAFE.focus == "list" and CAFE.shopSel == i)
      if sel then
        gfx.fillRoundRect(10, y, 270, 22, 5)
        gfx.setImageDrawMode(gfx.kDrawModeFillWhite)
      else
        gfx.drawRoundRect(10, y, 270, 22, 5)               -- every choice is a button with a border
      end
      drawT(row[1], 20, y + 2)
      if row[7] then                                       -- a half-off sticker
        gfx.setFont(fontBold)
        local tx = 272 - gfx.getTextSize(row[2]) - 56
        gfx.setColor(sel and WHITE or BLACK)
        gfx.drawRoundRect(tx, y + 2, 46, 18, 6)
        gfx.setFont(fontNormal)
        gfx.drawTextAligned("SALE", tx + 23, y + 3, kTextAlignment.center)
        gfx.setColor(BLACK)
      end
      if row[2] ~= "" then drawTR(row[2], 272, y + 3, true) end
      gfx.setImageDrawMode(gfx.kDrawModeCopy)
      gfx.setColor(BLACK)
      if sel then                                          -- the mouse pointer, resting on the choice
        gfx.setFont(fontNormal)
        CAFE.pointer(20 + math.min(gfx.getTextSize(row[1]) * 0.6, 150), y + 8)
      end
    end
    CAFE.drawPreview(rows[CAFE.shopSel])
    -- a scroll bar down the right of the list: the thumb slides as you move
    do
      local tx, ty, th = 285, 68, 138
      gfx.setColor(BLACK)
      gfx.drawRoundRect(tx, ty, 7, th, 3)
      local n = #rows
      local thumb = (n <= 7) and th or math.max(14, math.floor(th * 7 / n))
      local pos = (n <= 1) and 0 or (CAFE.shopSel - 1) / (n - 1)
      if CAFE.focus == "tabs" then pos = 0 elseif CAFE.focus ~= "list" then pos = 1 end
      gfx.fillRoundRect(tx, ty + math.floor((th - thumb) * pos + 0.5), 7, thumb, 3)
    end
    if CAFE.msg then
      gfx.setColor(WHITE)
      gfx.fillRoundRect(40, 184, 320, 20, 6)
      gfx.setColor(BLACK)
      gfx.drawRoundRect(40, 184, 320, 20, 6)
      drawTC(CAFE.msg, 200, 186, true)
    end
  end
  gfx.setColor(BLACK)
end


-- System menu (the Menu button): jump back to the title screen
-- (the Cafe hides this item: there you only get End shift / Save & quit)
function UI.setTitleItem(on)
  local menu = pd.getSystemMenu()
  if menu == nil then return end
  if on and UI.titleItem == nil then
    local ok, item = pcall(function()
      return menu:addMenuItem("Title screen", function()
        if state ~= STATE_MENU then goTitle() end
      end)
    end)
    if ok then UI.titleItem = item end
  elseif (not on) and UI.titleItem ~= nil then
    pcall(function() menu:removeMenuItem(UI.titleItem) end)
    UI.titleItem = nil
  end
end
UI.setTitleItem(false)

-- the fade to black and back that covers every change of screen
local fadeImg = nil
do
  local ok, img = pcall(function() return gfx.image.new(400, 240, BLACK) end)
  if ok then fadeImg = img end
end

function UI.drawFade()
  if trans == nil then return end
  local k = clamp(trans.t / FADE_SECONDS, 0, 1)
  local a = (trans.phase == "out") and k or (1 - k)
  if a <= 0.02 then return end
  if a >= 0.98 then
    gfx.setColor(BLACK)
    gfx.fillRect(0, 0, 400, 240)
    return
  end
  if fadeImg then
    local ok = pcall(function() fadeImg:drawFaded(0, 0, a, gfx.image.kDitherTypeBayer8x8) end)
    if ok then return end
  end
  gfx.setColor(BLACK)                       -- fallback: a coarse checker fade
  if a > 0.3 then gfx.setPattern(CHECK) end
  if a > 0.3 then gfx.fillRect(0, 0, 400, 240) end
  gfx.setColor(BLACK)
end

function UI.musicTick()                        -- cafe tune everywhere, the shop's tune only on the website
  local want = "none"
  if UI.musicOn then
    local shopTune = (state == CAFE.STATE and CAFE.mode == "shop") or (state == STATE_MENU and UI.settings ~= nil)
    want = shopTune and "shop" or "cafe"
  end
  if want == UI.musicNow then return end
  UI.musicNow = want
  local function go(p, on)
    if not p then return end
    pcall(function() if on then p:play(0) else p:pause() end end)
  end
  go(UI.musicPlayer, want == "cafe")
  go(UI.shopPlayer, want == "shop")
end

function pd.update()
  local now = pd.getCurrentTimeMilliseconds()
  local dt = (now - lastMs) / 1000
  lastMs = now
  if dt > 0.1 then dt = 0.1 end
  if dt < 0 then dt = 0 end
  frames = frames + 1
  UI.musicTick()
  -- "Title screen" only exists in the menu while you're playing Rush Hour or Evening Chill
  UI.setTitleItem(state == STATE_PLAY and G ~= nil and G.mode ~= "cafe")
  UI.setSettingsItem(state == STATE_MENU)               -- (Settings lives in the Menu button on the title screen)
  if state ~= STATE_MENU then UI.settings = nil end

  -- advance a screen fade: dark, switch screens, light again
  if trans then
    trans.t = trans.t + dt
    if trans.phase == "out" and trans.t >= FADE_SECONDS then
      trans.fn()
      trans.phase, trans.t = "in", 0
    elseif trans.phase == "in" and trans.t >= FADE_SECONDS then
      trans = nil
    end
  end

  -- only the screen we started the frame on reacts to the buttons, so one
  -- button press can't fall straight through into the next screen
  -- (nothing reacts while the screen is fading out)
  if trans == nil or trans.phase == "in" then
    if state == STATE_MENU then
      if UI.settings then UI.updateSettings() else updateMenu() end
    elseif state == STATE_PLAY then updatePlay(dt)
    elseif state == STATE_ENTRY then updateEntry(dt)
    elseif state == CAFE.STATE then CAFE.update(dt)
    else updateBoard(dt) end
  end

  gfx.setBackgroundColor(WHITE)
  gfx.clear()
  gfx.setColor(BLACK)
  gfx.setImageDrawMode(gfx.kDrawModeCopy)
  if state == STATE_MENU then
    if UI.settings then UI.drawSettings() else drawMenu() end
  elseif state == STATE_PLAY then
    drawPlay()
  elseif state == STATE_ENTRY then
    drawEntry()
  elseif state == CAFE.STATE then
    CAFE.draw()
  else
    drawBoard()
  end
  UI.drawFade()
  if pd.drawFPS and state == STATE_PLAY and CAFE.rich() then pd.drawFPS(372, 228) end     -- test cheat save: show the frame rate
end
